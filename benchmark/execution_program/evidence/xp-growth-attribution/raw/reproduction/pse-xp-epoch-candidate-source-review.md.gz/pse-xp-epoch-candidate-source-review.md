# XP candidate source review — epoch cohort

Source-only review, 2026-10-31. No Julia execution or timing qualification by this agent.

- Epoch source `execution_group_epoch_lookup.jl` SHA256 `2fe4415e74c972bf5910eae6ee9a3dd600621d7de01cabd012d12b96416b887e` validates index length, every nonempty current application identity, exact group count, unique list slots, and exact list/index group identity. A copied same-application ghost cannot pass the last proof.
- A rejected epoch retains `validated_applications === nothing`; every query goes directly to the original ID dictionary, built lazily from `previous.groups`. It does not reuse an unvalidated v1 slot. Canonical query identity is checked against both the saved application-reference snapshot and current vector.
- Trusted empty is a separate completed lookup, not a slot miss or dictionary lookup. The candidate harness v2 enforces total lookups = nonempty slot hits + ID-fallback misses + trusted empty. Epoch query fallbacks equal ID lookups; misses partition by original reason.
- No blocker found for the internal refresh-scoped use: no scientific values, target memberships, environments, bindings, or schedules are cached by this optimization. Ordinary current group reuse and refresh decisions remain downstream. The proof assumes these private index/list containers are not arbitrarily mutated during one synchronous refresh; public lifecycle refreshes create/revalidate a new wrapper.
- Validation copies application references, scans the index and group list, and allocates a seen-bitset. Its work counters are retained. Dictionary elimination is not itself a runtime benefit claim.

The seven-arm harness remains independent: two identical bounded controls, bounded sequence, graph only, epoch lookup only, graph+epoch, graph+epoch+sequence. All enablement/preparation is charged. Graph coverage requires completed returned tables/rows; each XP lookup instance additionally requires epoch-owned successful validation and nonempty hits, not fallback-only v1 work. Base/NBS counters, graph operations, v1 query partitions, and epoch proof operations are retained separately and never treated as scientific kernel counts. Full per-instance scientific/RNG/work/identity checks remain outside timing.

Harness SHA256: `3f0c694b757312638fe9f3104919d1a4775875c66eeddb53301f3c9189ab52a3`. Exact pre-epoch source SHA256 `3514883b51ed7856958dcdeecdf0c67c8ce7827b94594ead3dbf40b1c8de83f0` is preserved under `results/xp-growth-attribution/source-before-epoch/`. Protocol is `xp_graph_lookup_candidates_v2`.
