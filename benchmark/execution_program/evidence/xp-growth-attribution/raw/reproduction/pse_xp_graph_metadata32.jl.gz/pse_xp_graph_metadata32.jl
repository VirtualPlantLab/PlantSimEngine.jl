include(joinpath(pwd(),"benchmark/native_downstream/graph_row_projection_scaling.jl"))
Base.invokelatest() do
    report=GraphRowScaling.graph_row_scaling(32;cycles=4)
    sources=[(path=p,sha256=bytes2hex(GraphRowScaling.SHA.sha256(read(p)))) for p in
        ("src/composite_model/compilation.jl","benchmark/native_downstream/bounded_preparation.jl",
         "benchmark/native_downstream/graph_row_projection.jl","benchmark/native_downstream/graph_row_projection_scaling.jl")]
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/graph-metadata32.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),sources,report),2)
    end
    (;passed=true,pid=getpid())
end
