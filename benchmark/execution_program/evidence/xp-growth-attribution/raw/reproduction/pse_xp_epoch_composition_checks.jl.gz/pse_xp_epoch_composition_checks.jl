include(joinpath(pwd(),"benchmark/native_downstream/xp_growth_candidate_measurements.jl"))
Base.invokelatest() do
    checks=Any[]
    for (kind,arm) in ((:xp,:lookup_only),(:xp,:graph_lookup),(:xp,:graph_lookup_sequence),(:pb,:graph_lookup_sequence))
        result=XPGrowthCandidateMeasurements.candidate_checks(kind;arm,steps=2,outputs=:all)
        push!(checks,(;kind,arm,result))
        open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/epoch-composition-checks.json"),"w") do io
            PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
        end
    end
    report=GraphRowScaling.graph_row_scaling(512;cycles=4)
    sources=[(path=p,sha256=bytes2hex(NativeDownstreamMeasurements.SHA.sha256(read(p)))) for p in
        ("src/composite_model/compilation.jl","benchmark/native_downstream/bounded_preparation.jl",
         "benchmark/native_downstream/graph_row_projection.jl","benchmark/native_downstream/graph_row_projection_scaling.jl")]
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/graph-metadata512.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),sources,report),2)
    end
    (;passed=true,cases=length(checks),metadata_applications=512)
end
