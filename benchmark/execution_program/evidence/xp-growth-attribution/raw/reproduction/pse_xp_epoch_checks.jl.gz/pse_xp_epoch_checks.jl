Base.invokelatest() do
    ast=Meta.parse(read(joinpath(pwd(),"benchmark/native_downstream/execution_group_lookup.jl"),String))
    wanted=Set([:_try_epoch_lookup,:_previous_execution_groups_for_refresh])
    function definition_name(expr)
        expr isa Expr || return nothing
        if expr.head===:macrocall
            for a in expr.args
                name=definition_name(a);name===nothing||return name
            end
        elseif expr.head===:function || expr.head===:(=)
            signature=expr.args[1]
            if signature isa Expr && signature.head===:call
                name=signature.args[1]
                return name isa Symbol ? name : name isa Expr && name.head===:. ? name.args[end].value : nothing
            end
        end
        return nothing
    end
    changed=Symbol[]
    for expr in ast.args[3].args
        name=definition_name(expr)
        if name in wanted
            Core.eval(ExecutionGroupLookup,expr);push!(changed,name)
        end
    end
    @assert Set(changed)==wanted
end
include(joinpath(pwd(),"benchmark/native_downstream/execution_group_epoch_lookup.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/execution_group_epoch_lookup_checks.jl"))
Base.invokelatest() do
    checks=Any[]
    for (name,fn) in (
        (:unit,ExecutionGroupEpochLookupChecks.epoch_lookup_unit_checks),
        (:xp,()->ExecutionGroupEpochLookupChecks.epoch_lookup_parity_checks(:xp)),
        (:first_membership,()->ExecutionGroupEpochLookupChecks.epoch_lookup_parity_checks(:first_membership)),
        (:generic,()->ExecutionGroupEpochLookupChecks.epoch_lookup_parity_checks(:generic)),
        (:initializer,()->ExecutionGroupEpochLookupChecks.epoch_lookup_parity_checks(:initializer)),
        (:mixed_cadence,()->ExecutionGroupEpochLookupChecks.epoch_lookup_parity_checks(:mixed_cadence)),
        (:distributed,()->ExecutionGroupEpochLookupChecks.epoch_lookup_parity_checks(:distributed)),
        (:pb,()->ExecutionGroupEpochLookupChecks.epoch_lookup_parity_checks(:pb)),
        (:recompile,ExecutionGroupEpochLookupChecks.epoch_lookup_recompile_checks))
        result=fn();push!(checks,(;name,result))
        open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/epoch-checks.json"),"w") do io
            PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
        end
    end
    (;passed=true,cases=length(checks))
end
