include(joinpath(pwd(), "benchmark/native_downstream/load_newborn_binding_experiment.jl"))
Base.invokelatest() do
    PSE=PlantSimEngine
    environment=(pid=getpid(),julia=string(VERSION),project=Base.active_project(),
        pse=(path=Base.pathof(PSE),version=string(Base.pkgversion(PSE))),
        pb=(path=Base.pathof(NativePBDriver.PB),version=string(Base.pkgversion(NativePBDriver.PB))),
        xp=(path=Base.pathof(NativeXPDriver.XPalm),version=string(Base.pkgversion(NativeXPDriver.XPalm))))
    checks=[NewbornBindingSequenceMeasurements.newborn_sequence_checks(:xp;arm,steps=2,outputs=:all)
        for arm in (:binding_sequence,:bounded_sequence)]
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/fresh-small-checks.json"),"w") do io
        PSE.JSON.print(io,(;environment,checks),2)
    end
    (;passed=true,environment)
end
