# XP growth attribution and candidate audit

Source/results review only. No Julia execution by this agent. All numerical statements below come from the current stored cohorts; old NBS samples and profile elapsed measurements are not pooled with these timings.

## candidate-small-screen.json

2 independently constructed simulations per sample × 2 days, 4 alternating forward/reverse cycles; one timing observation per batch. PID 76207, Julia 1.13.1. All stored full state/RNG/history/topology observations, work, case/config, digests, phase sums and actual counter partitions match. Each sample has disjoint model/status/canonical-reference proof. Weather is read once at registration and copied per instance; that common read is outside complete timing. Construction, enablement, normal preparation and execution are charged.

CPU controller file candidate-small-20261031T203654-cpu.json: qualified=True; 3 observations with no competing Julia >=5% listed. Formal promotion still requires the explicit artifact/SHA qualification manifest.

| Arm | Execution / A | Complete / A | Execution / B | Complete / B | Prep / A |
|---|---:|---:|---:|---:|---:|
| bounded_a | 1.0000 | 1.0000 | 1.0351 | 1.0575 | 1.0000 |
| bounded_b | 0.9669 | 0.9472 | 1.0000 | 1.0000 | 0.9300 |
| bounded_sequence | 0.9419 | 1.0322 | 0.9758 | 1.0901 | 1.0895 |
| graph_only | 0.9550 | 0.8048 | 1.0013 | 0.8405 | 0.7084 |
| lookup_only | 0.9487 | 0.9707 | 0.9774 | 1.0112 | 0.9797 |
| graph_lookup | 0.9471 | 0.8084 | 0.9915 | 0.8521 | 0.7136 |
| graph_lookup_sequence | 0.9123 | 0.8826 | 0.9493 | 0.9326 | 0.8580 |

All execution phases report zero compilation, recompilation and GC. All construction/lowering phases also have zero events. Sequence arms have small preparation compilation/recompilation events; all recorded GC is zero. Exact events are retained in the summarizer rather than subtracted.

The A/A execution ratio B/A is 0.9669 (3/4 wins), range 0.8918–1.0210. Graph-only preparation wins 4/4 against both controls; its execution against B is 1.0013 (2/4), so the clear result is preparation. Epoch-only is 0.9775 execution but 1.0112 complete against B: a small execution difference with no complete win. Graph+epoch+sequence improves both phases versus controls but remains worse in complete cost than graph-only.
Each lookup batch completes 4 validated epochs, 156 nonempty hits and 44 trusted empty returns, with zero ID misses/dictionaries. Graph batches complete 4 returned tables, 244 rows and 220 edges. Counters are actual sums over both independent instances, not inferred work.

## candidate-moderate-screen.json

4 independently constructed simulations per sample × 12 days, 6 alternating forward/reverse cycles; one timing observation per batch. PID 76207, Julia 1.13.1. All stored full state/RNG/history/topology observations, work, case/config, digests, phase sums and actual counter partitions match. Each sample has disjoint model/status/canonical-reference proof. Weather is read once at registration and copied per instance; that common read is outside complete timing. Construction, enablement, normal preparation and execution are charged.

CPU controller file candidate-moderate-20261031T203936-cpu.json: qualified=True; 5 observations with no competing Julia >=5% listed. Formal promotion still requires the explicit artifact/SHA qualification manifest.

| Arm | Execution / A | Complete / A | Execution / B | Complete / B | Prep / A |
|---|---:|---:|---:|---:|---:|
| bounded_a | 1.0000 | 1.0000 | 0.9772 | 0.9849 | 1.0000 |
| bounded_b | 1.0233 | 1.0154 | 1.0000 | 1.0000 | 1.0132 |
| bounded_sequence | 1.0010 | 1.0536 | 0.9579 | 1.0305 | 1.1730 |
| graph_only | 0.9985 | 0.9433 | 0.9580 | 0.9129 | 0.7469 |
| lookup_only | 1.0406 | 1.0483 | 1.0332 | 1.0396 | 1.0359 |
| graph_lookup | 0.9916 | 0.9308 | 0.9690 | 0.9133 | 0.7349 |
| graph_lookup_sequence | 0.9715 | 0.9531 | 0.9328 | 0.9256 | 0.8863 |

All execution phases report zero compilation, recompilation and GC. All construction/lowering phases also have zero events. Sequence arms have small preparation compilation/recompilation events; all recorded GC is zero. Exact events are retained in the summarizer rather than subtracted.

The A/A execution ratio B/A is 1.0233 (2/6 wins), range 0.9674–1.1435. Graph-only preparation wins 6/6 against both A/B; complete wins 5/6. Its execution is 0.9985 against A, so no runtime gain is established for graph-only.
Epoch-only is 1.0406 execution / 1.0483 complete against A (1/6 and 0/6 wins), despite eliminating maps. Thus dictionary elimination is not a standalone performance result. Graph+epoch versus graph-only is 0.9940 execution / 0.9832 complete (4/6 wins): incremental attribution is weak relative to placebo variability.
Plain sequence versus A is 1.0010 execution (3/6) with leave-one median 0.9858 or 1.0161; an execution regression is not established. Its preparation is 1.1730 (0/6 wins) and complete 1.0536 (0/6), consistent with repeated extra preparation work.
Adding sequence to graph+epoch yields 0.9729 execution (5/6), 1.1957 preparation (0/6), 1.0181 complete (2/6). It does not improve complete cost in this cohort.
Each lookup batch completes 48 validated epochs, 1872 nonempty hits and 528 trusted empty returns, with zero ID misses/dictionaries. It snapshots 2928 application references, checks 2928 index slots and 1872 prior groups. Graph batches complete 8 tables, 488 rows and 440 edges. Work is 48 simulated steps, 144 actual births and 176 final objects across four scenes.

## Attribution and provenance limits

The valid 12-day growth profiles and zero-step preparation profiles use entry-selected source-operation sampling, separate fresh CPU/allocation companions, and reported scientific/RNG/reference parity. Four records have >=100 operation samples, a non-full buffer and no trailing raw words. Nearest source sites are not exact exclusive guard or line costs. Instrumented framework timers overlap and the controller scientific-kernel timer includes nested framework work. None of the profiler elapsed/JIT/allocated diagnostic measurements qualifies as application timing. Allocation samples alone do not establish why runtime changes.

The first four-day profiles and the allocation warmup remain preliminary. The first control inventory accidentally included 901 historical result-source copies; the old manifests and failed receipts remain unchanged. The new archiver explicitly excludes only those irrelevant nested source copies, listing every path/size/SHA, while keeping all active before-source files and current/exact scientific sources. It does not silently replace source epochs or claim the old attempts passed.

The strongest current candidate is graph-row projection for preparation. The source algorithm avoids repeated full application filtering while preserving the original bounded table shape/order. Whole-application gains and their limits are established by the paired fresh-instance cohorts, not by helper microbenchmarks or allocation sampling. There is no cold compilation, peak-memory, million-organ, AMAPSim or MAESPA qualification in this experiment.
