include(joinpath(pwd(),"benchmark/native_downstream/xp_growth_candidate_measurements.jl"))
Base.invokelatest() do
    checks=Any[]
    for (kind,arm) in ((:xp,:graph_only),(:xp,:lookup_only),(:xp,:graph_lookup),(:xp,:graph_lookup_sequence),
                       (:pb,:graph_only),(:pb,:graph_lookup_sequence))
        result=XPGrowthCandidateMeasurements.candidate_checks(kind;arm,steps=2,outputs=:all)
        push!(checks,(;kind,arm,result))
        open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/candidate-scientific-checks.json"),"w") do io
            PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
        end
    end
    (;passed=true,cases=length(checks))
end
