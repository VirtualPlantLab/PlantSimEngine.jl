Base.invokelatest() do
    @assert isdefined(PlantSimEngine,:_try_freeze_scenario_relation_rows)
    @assert isdefined(PlantSimEngine,:_previous_execution_groups_for_refresh)
    checks=Any[]
    for (kind,arm) in ((:xp,:bounded_sequence),(:pb,:binding_sequence))
        push!(checks,NewbornBindingSequenceMeasurements.newborn_sequence_checks(kind;arm,steps=2,outputs=:all))
    end
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/core-hook-smoke.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
    end
    (;passed=true,cases=length(checks))
end
