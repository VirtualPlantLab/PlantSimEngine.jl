# XP allocation/runtime discrepancy: independent timing audit and controls

Current evidence is the frozen consumer-sequence four-day and twelve-day cohorts in `results/newborn-binding`, source epoch 8d556937e9403b192be1452548566fa0e73654afbda7fb4778fb38166a0cba74. No Julia execution by this agent. Counts, scientific snapshots/RNG, source/config/work and order were previously independently checked; allocation reductions are measured, but exclusive CPU causality was not established.

## What the timing evidence says

For bounded_sequence versus bounded_preparation:

| XP case | Paired execution ratios | Median | Paired complete median | Preparation losses |
| --- | --- | ---: | ---: | ---: |
| Four days |0.860734,0.904111,0.882461,0.835552 |0.871597 |0.989602 |4/4 |
| Twelve days |0.938206,0.987369,1.051202,0.983735,1.023553,1.179952 |1.005461 |1.053591 |6/6 |

Four-day execution improves in all four pairs, including both order directions (odd/even medians 0.871597/0.869832). That observation should be retained. The twelve-day near-zero median effect is fragile: deleting one cycle changes the paired median to 0.987369 or 1.023553, reversing its sign. This is descriptive leave-one-cycle sensitivity, not a confidence interval or formal significance test.

Twelve-day paired execution deltas span -3.029 to +7.274 ms. Bounded control execution ranges 40.422–49.869ms, median 43.743 ms and median absolute deviation 3.188 ms; sequence ranges 40.026–49.239ms, median 46.355 ms and MAD 1.855 ms. The paired median execution delta is only about +0.223 ms, much smaller than this fresh-instance repeatability spread. Do not call it an established execution regression. That spread includes memory-layout/cache/OS/case variation and cannot be labeled pure timer noise from these data alone. No cause is established.

Preparation is more repeatable evidence of extra work. The twelve-day candidate loses all six preparation pairs, by +1.205 to +3.805 ms (paired median about +2.409 ms); four-day losses are +0.854 to +2.403 ms. Twelve-day preparation allocation is roughly 7.23 MB versus 5.63 MB, with small occasional compiler-event additions. This demonstrates additional candidate preparation cost, without separating certificate inference, sequence construction, guards and bookkeeping into exclusive causes. Individual per-cycle phase deltas sum to complete cost; sums of independently computed medians need not.

Execution allocation reductions remain real and nearly deterministic despite time variation: at twelve days bounded uses 21,808,896 bytes (occasionally+2,080), sequence 20,622,144 bytes; ordinary 38,285,888 versus plain sequence 34,461,056 (small event-sized variants). All execution GC/JIT counters are zero. Fewer allocated bytes therefore did not translate into a stable execution-time win here. It does not prove fewer instructions, better locality, lower retained memory or a reduction in GC-heavy large runs.

## Profiling controls

The first four-day CPU companions use five independent scenes, sampled only after zero-step preparation. They preserve full science/RNG/work/reference transitions. Their 1470/1261 active samples include background/Kaimon stacks; only 95/74 are recognized, so no stable guard-share conclusion follows. Allocation profiling was disabled in those initial files. The first bounded framework companion compiled instrumentation (about 4.356 s JIT/4.382 s wall across steps), whereas sequence was already warm (~15.4ms). Those framework timings are not a valid control/candidate speed comparison.

The revised profiler keeps entry-selected source-operation samples separately and requires at least 100 operations for coarse shares. Its preparation API constructs independent scenes before sampling, warms the prepare helper once, then samples zero-step preparation only. Its source version and population differ from the preliminary classifier; do not pool category percentages across versions. Nested timers and inclusive stack shares remain overlapping; controller scientific-kernel time can include framework/initializer work. Do not subtract them to invent pure physics time.

## Prepared-batch A/A control

NEW source-only harness: `benchmark/native_downstream/xp_prepared_batch_timing.jl`, module `XPPreparedBatchTiming`, frozen SHA 30aa12f939b40be1f859787419b51fdcfe880bc3750c3670b1230e5b9ca68c44.

`register_xp_prepared_batch_case!(name;batch_size=4,steps=12)` supplies bounded_a/bounded_b (identical bounded_preparation backend) and bounded_sequence/details=false. `screen_xp_prepared_batch(spec;repetitions=6)` alternates forward/reverse orders with bounded_a as baseline. Four independently constructed/prepared simulations execute once each under a single execution timer (~0.2s expected, not asserted). Construction, enablement and all preparation are still charged to complete cost; division by four only normalizes batch totals for display. Statistical replication is six batch samples, not 24 independent timing samples.

Full per-instance observations/RNG are read after timing. Identical observations are merged only after full equality comparison and retain an ordered per-instance mapping; this is lossless evidence deduplication. Models/statuses/canonical Refs must be disjoint across instances; sequence-owned actual producer-newborn counts are summed from every instance, never inferred by multiplication. The two A/A aliases must have disabled instruction policies and zero completion counts. A small `prepared_batch_checks(batch_size=2,steps=2)` gate precedes timing.

Compare candidate against BOTH A/A controls within each cycle and compare its saved-time magnitude with A/A differences. A useful heuristic is a stable sign against both controls, most pairs winning and a saving clearly larger than the placebo difference; this is not a formal statistical test. If candidate timing remains within placebo variation, report runtime unresolved rather than explaining a regression from allocation profiles. Complete cost still determines short-run value, while execution and preparation are separately reported.

## Falsifiable fix directions

Use the new profiles first. If declaration/certificate work dominates preparation, investigate a value-free names/local-port projection certificate or separately an epoch-invalidated type-only cache; neither may cache defaults or skip RNG/effect behavior. If generic plan access/dynamic dispatch or repeated status/view assembly dominates execution, optimize that measured boundary rather than adding a broader cache. Direct scalar-carrier assembly can be tested independently on the ordinary path with exact missing/multiple-source/error-order parity.

No new fix, runtime explanation, cold-compilation benefit, full-suite qualification or general XP speedup is established by this audit. Existing frozen files were not edited; the original in-progress batch source used by preliminary profiling was preserved before finishing the separate harness.
