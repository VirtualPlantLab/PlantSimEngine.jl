Base.invokelatest() do
    M=NativeDownstreamMeasurements; PSE=PlantSimEngine
    before=M.source_manifest(pkgdir(PSE))
    report=nothing; failure=nothing
    try
        report=XPGrowthAttribution.profile_xp_growth_attribution(:bounded_preparation;
            steps=2,repetitions=1,run_cpu=false,run_allocations=true,include_framework=false,
            allocation_sample_rate=.001)
    catch error
        failure=sprint(showerror,error)
    end
    after=M.source_manifest(pkgdir(PSE))
    a=Dict(row.path=>row.sha256 for row in before.files)
    b=Dict(row.path=>row.sha256 for row in after.files)
    differences=[(path=k,before=get(a,k,nothing),after=get(b,k,nothing)) for k in union(keys(a),keys(b)) if get(a,k,nothing)!=get(b,k,nothing)]
    provenance=M.process_provenance(;packages=(PSE,NativePBDriver.PB,NativeXPDriver.XPalm))
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/source-guard-diagnostic.json"),"w") do io
        PSE.JSON.print(io,(;pid=getpid(),before,after,differences,failure,report,provenance),2)
    end
    (;failure,outer_equal=isequal(before,after),differences)
end
