Base.invokelatest() do
    spec=XPGrowthCandidateMeasurements.register_xp_candidate_batch_case!(:xp_candidate_small;batch_size=2,steps=2)
    screen=XPGrowthCandidateMeasurements.screen_xp_candidate_batch(spec;repetitions=4)
    report=(;pid=getpid(),screen,summary=NativeDownstreamMeasurements.summarize_screen(screen))
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/candidate-small-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,report,2)
    end
    (;passed=true,arms=length(screen.orders[1]),cycles=screen.repetitions)
end
