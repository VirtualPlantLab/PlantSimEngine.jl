Base.invokelatest() do
    for n in (32,128)
        report=GraphRowScaling.graph_row_scaling(n;cycles=4)
        sources=[(path=p,sha256=bytes2hex(NativeDownstreamMeasurements.SHA.sha256(read(p)))) for p in
            ("src/composite_model/compilation.jl","benchmark/native_downstream/bounded_preparation.jl",
             "benchmark/native_downstream/graph_row_projection.jl","benchmark/native_downstream/graph_row_projection_scaling.jl")]
        path=joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/graph-metadata"*string(n)*".json")
        @assert !isfile(path)
        open(path,"w") do io
            PlantSimEngine.JSON.print(io,(;pid=getpid(),sources,report),2)
        end
    end
    (;passed=true,pid=getpid(),sizes=(32,128))
end
