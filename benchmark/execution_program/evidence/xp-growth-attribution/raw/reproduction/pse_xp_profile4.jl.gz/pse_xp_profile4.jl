include(joinpath(pwd(),"benchmark/native_downstream/xp_growth_attribution.jl"))
Base.invokelatest() do
    gate=XPGrowthAttribution.classifier_checks()
    expected=nothing; outputs=String[]
    for arm in (:bounded_preparation,:bounded_sequence)
        path=joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/profile4-"*string(arm)*".json")
        @assert !isfile(path)
        report=XPGrowthAttribution.profile_xp_growth_attribution(arm;steps=4,repetitions=5,
            run_cpu=true,run_allocations=false,include_framework=true,expected_digest=expected,
            progress_path=joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/profile-stages.tsv"))
        expected=report.oracle.digest
        open(path,"w") do io
            PlantSimEngine.JSON.print(io,(;gate,report),2)
        end
        push!(outputs,path)
    end
    (;passed=true,pid=getpid(),outputs)
end
