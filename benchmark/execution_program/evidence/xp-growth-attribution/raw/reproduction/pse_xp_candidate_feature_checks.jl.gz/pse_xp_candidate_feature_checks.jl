include(joinpath(pwd(),"benchmark/native_downstream/graph_row_projection.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/graph_row_projection_checks.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/execution_group_lookup_checks.jl"))
Base.invokelatest() do
    checks=Any[]
    for (name,fn) in (
        (:graph_metadata,GraphRowProjectionChecks.graph_row_projection_checks),
        (:lookup_growth,ExecutionGroupLookupChecks.execution_group_lookup_growth_checks),
        (:lookup_recompile,ExecutionGroupLookupChecks.execution_group_lookup_recompile_checks),
        (:first_membership,()->ExecutionGroupLookupChecks.execution_group_lookup_feature_checks(:first_membership)),
        (:initializer,()->ExecutionGroupLookupChecks.execution_group_lookup_feature_checks(:initializer)),
        (:mixed_cadence,()->ExecutionGroupLookupChecks.execution_group_lookup_feature_checks(:mixed_cadence)),
        (:distributed,()->ExecutionGroupLookupChecks.execution_group_lookup_feature_checks(:distributed)),
        (:xp,()->ExecutionGroupLookupChecks.execution_group_lookup_downstream_checks(:xp;steps=2)),
        (:pb,()->ExecutionGroupLookupChecks.execution_group_lookup_downstream_checks(:pb;steps=2)))
        result=fn();push!(checks,(;name,result))
        open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/candidate-feature-checks.json"),"w") do io
            PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
        end
    end
    (;passed=true,cases=length(checks))
end
