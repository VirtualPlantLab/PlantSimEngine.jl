Base.invokelatest() do
    spec=XPGrowthCandidateMeasurements.register_xp_candidate_batch_case!(:xp_candidate_moderate;batch_size=4,steps=12)
    screen=XPGrowthCandidateMeasurements.screen_xp_candidate_batch(spec;repetitions=6)
    report=(;pid=getpid(),screen,summary=NativeDownstreamMeasurements.summarize_screen(screen))
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/candidate-moderate-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,report,2)
    end
    (;passed=true,cycles=screen.repetitions)
end
