include(joinpath(pwd(),"benchmark/native_downstream/xp_growth_attribution.jl"))
Base.invokelatest() do
    gate=XPGrowthAttribution.classifier_checks()
    root=joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution")
    warm=XPGrowthAttribution.profile_xp_growth_attribution(:bounded_preparation;
        steps=2,repetitions=1,run_cpu=false,run_allocations=true,include_framework=false,
        allocation_sample_rate=.001,progress_path=joinpath(root,"profile-stages.tsv"))
    open(joinpath(root,"allocation-profiler-warmup.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;gate,report=warm),2)
    end
    expected=nothing
    for arm in (:bounded_preparation,:bounded_sequence)
        path=joinpath(root,"profile12-"*string(arm)*".json");@assert !isfile(path)
        report=XPGrowthAttribution.profile_xp_growth_attribution(arm;steps=12,repetitions=5,
            run_cpu=true,run_allocations=true,include_framework=true,
            allocation_sample_rate=.01,cpu_delay=.0002,expected_digest=expected,
            progress_path=joinpath(root,"profile-stages.tsv"))
        expected=report.oracle.digest
        open(path,"w") do io
            PlantSimEngine.JSON.print(io,(;gate,report),2)
        end
    end
    expected=nothing
    for arm in (:bounded_preparation,:bounded_sequence)
        path=joinpath(root,"preparation-"*string(arm)*".json");@assert !isfile(path)
        report=XPGrowthAttribution.profile_xp_preparation(arm;steps=12,repetitions=8,
            cpu_delay=.0002,expected_digest=expected,progress_path=joinpath(root,"profile-stages.tsv"))
        expected=report.oracle.digest
        open(path,"w") do io
            PlantSimEngine.JSON.print(io,(;gate,report),2)
        end
    end
    (;passed=true,pid=getpid(),cases=5)
end
