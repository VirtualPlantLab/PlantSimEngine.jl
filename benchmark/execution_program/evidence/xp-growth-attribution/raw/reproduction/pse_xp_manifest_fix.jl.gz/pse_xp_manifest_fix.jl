Base.invokelatest() do
    M=NativeDownstreamMeasurements
    ast=Meta.parse(read(joinpath(pwd(),"benchmark/native_downstream/measurements.jl"),String))
    matches=Expr[]
    function visit(expr)
        expr isa Expr || return
        if expr.head===:function && expr.args[1] isa Expr && expr.args[1].head===:call && expr.args[1].args[1]===:source_manifest
            push!(matches,expr)
        else
            foreach(visit,expr.args)
        end
    end
    visit(ast)
    @assert length(matches)==1
    Core.eval(M,only(matches))
end
Base.invokelatest() do
    first=NativeDownstreamMeasurements.source_manifest(pwd())
    second=NativeDownstreamMeasurements.source_manifest(pwd())
    @assert isequal(first,second)
    @assert all(row->!in("results",splitpath(row.path)),first.files)
    (;passed=true,files=length(first.files),aggregate=first.aggregate_sha256)
end
