for (name,file) in ((:GrowthInputReuseChecks,"growth_input_reuse_checks.jl"),
    (:NewbornBindingProgramChecks,"newborn_binding_program_checks.jl"),
    (:NewbornPreparation,"newborn_preparation.jl"),
    (:NewbornPreparationChecks,"newborn_preparation_checks.jl"),
    (:NewbornDistributedChecks,"newborn_distributed_checks.jl"),
    (:ExecutionGroupLookup,"execution_group_lookup.jl"),
    (:ExecutionGroupLookupChecks,"execution_group_lookup_checks.jl"))
    isdefined(Main,name)||include(joinpath(pwd(),"benchmark/native_downstream",file))
end
Base.invokelatest() do
    checks=Any[]
    for fn in (ExecutionGroupLookupChecks.execution_group_lookup_unit_checks,
        ExecutionGroupLookupChecks.execution_group_lookup_growth_checks,
        ()->ExecutionGroupLookupChecks.execution_group_lookup_feature_checks(:first_membership),
        ()->ExecutionGroupLookupChecks.execution_group_lookup_feature_checks(:initializer),
        ()->ExecutionGroupLookupChecks.execution_group_lookup_feature_checks(:mixed_cadence),
        ()->ExecutionGroupLookupChecks.execution_group_lookup_feature_checks(:distributed),
        ()->ExecutionGroupLookupChecks.execution_group_lookup_downstream_checks(:xp;steps=2),
        ()->ExecutionGroupLookupChecks.execution_group_lookup_downstream_checks(:pb;steps=2))
        push!(checks,fn())
    end
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/lookup-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
    end
    (;passed=true,cases=length(checks))
end
