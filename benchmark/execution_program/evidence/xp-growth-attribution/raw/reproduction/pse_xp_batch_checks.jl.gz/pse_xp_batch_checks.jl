include(joinpath(pwd(),"benchmark/native_downstream/xp_prepared_batch_timing.jl"))
Base.invokelatest() do
    result=XPPreparedBatchTiming.prepared_batch_checks(;batch_size=2,steps=2)
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-growth-attribution/batch-small-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),result),2)
    end
    (;passed=true,pid=getpid())
end
