Base.invokelatest() do
    results=Any[]
    for (name,fn) in ((:pb128,()->PBPreparationScaling.pb_preparation_checks(;nobjects=128,steps=8,arms=(:bounded_graph,:typed_graph))),
        (:xp64_accelerated,()->XPPreparationScalingChecks.xp_preparation_scaling_checks(;days=64,profile=:accelerated,allow_large=true,arms=(:ordinary_a,:typed_graph))),
        (:xp64_defaults,()->XPPreparationScalingChecks.xp_preparation_scaling_checks(;days=64,profile=:package_defaults,allow_large=true,arms=(:ordinary_a,:typed_graph))))
        result=fn();push!(results,(;name,result))
        open(joinpath(pwd(),"benchmark/native_downstream/results/preparation-scaling/stage3-checks.json"),"w") do io
            PlantSimEngine.JSON.print(io,(;pid=getpid(),results),2)
        end
    end
    (;passed=true,cases=length(results))
end
