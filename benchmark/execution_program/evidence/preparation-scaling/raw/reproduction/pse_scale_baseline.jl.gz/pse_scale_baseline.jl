include(joinpath(pwd(),"benchmark/native_downstream/load_newborn_binding_experiment.jl"))
for file in ("graph_row_projection.jl","typed_output_preparation.jl","execution_group_lookup.jl",
    "execution_group_epoch_lookup.jl","trusted_execution_group_index.jl","xp_prepared_batch_timing.jl",
    "xp_dispatch_refresh_measurements.jl")
    include(joinpath(pwd(),"benchmark/native_downstream",file))
end
Base.invokelatest() do
    results=Any[]
    for kind in (:xp,:pb)
        result=XPDispatchRefreshMeasurements.dispatch_refresh_checks(kind;arm=:typed_graph,steps=2,outputs=:all)
        push!(results,(;kind,result))
    end
    environment=(pid=getpid(),julia=string(VERSION),project=Base.active_project(),
        packages=[(name=string(nameof(mod)),path=Base.pathof(mod),version=string(Base.pkgversion(mod)))
            for mod in (PlantSimEngine,NativePBDriver.PB,NativeXPDriver.XPalm)])
    open(joinpath(pwd(),"benchmark/native_downstream/results/preparation-scaling/baseline-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;passed=true,environment,results),2)
    end
    (;passed=true,environment)
end
