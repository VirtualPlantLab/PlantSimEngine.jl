"""Six sequential Kaimon-only first-use pilots. Default is a read-only plan.

ROOT alone may invoke --run after warm workers are shut down. No automatic
retry, restart-as-cold, Julia subprocess or direct scientific execution path.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import subprocess
import threading
import time


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


client = load_module('pse_cold_kaimon_client', '/private/tmp/pse_kaimon_client.py')
cpu = load_module('pse_cold_cpu', '/private/tmp/pse_future_cpu.py')
CELLS = (('pb', 'ordinary_a'), ('pb', 'typed_graph'), ('pb', 'bounded_graph'),
    ('xp', 'typed_graph'), ('xp', 'ordinary_a'), ('xp', 'bounded_graph'))
DRIVER_REL = 'benchmark/native_downstream/preparation_scaling_cold_case.jl'
PROTOCOL = 'preparation_scaling_cold_v1'


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n')


def jl_string(value):
    # JSON string escaping alone does not suppress Julia interpolation.
    return json.dumps(str(value), ensure_ascii=False).replace('$', r'\$')


SOURCE_ROOTS = ('src', 'ext', 'benchmark/native_downstream',
    'benchmark/compiled_regions', 'benchmark/generated_program')
EXCLUDED_DIRECTORY_NAMES = {'.git', 'results', 'evidence', '__pycache__'}


def source_image(root):
    paths = set()
    for name in ('Project.toml', 'Manifest.toml'):
        path = root / name
        if not path.is_file() or path.is_symlink():
            raise RuntimeError('Missing or symlink project input: ' + str(path))
        paths.add(path)
    for directory in SOURCE_ROOTS:
        pending = [root / directory]
        while pending:
            path = pending.pop()
            if path.is_symlink():
                continue
            if path.is_dir():
                if path.name in EXCLUDED_DIRECTORY_NAMES:
                    continue
                pending.extend(sorted(path.iterdir(), reverse=True))
            elif path.is_file() and path.suffix == '.jl':
                paths.add(path)
    if root / DRIVER_REL not in paths:
        raise RuntimeError('Copy the frozen cold driver into the active source cohort first')
    return {path.relative_to(root).as_posix(): sha(path.read_bytes()) for path in sorted(paths)}


def strict_cpu_sample(own_pid):
    result = subprocess.run(['ps', '-axo', 'pid,ppid,pcpu,rss,comm'],
        capture_output=True, text=True, check=True, timeout=10)
    rows = []
    for line in result.stdout.splitlines()[1:]:
        parts = line.split(None, 4)
        if len(parts) != 5:
            continue
        pid, parent, load, rss, command = parts
        rows.append(dict(pid=int(pid), parent=int(parent), cpu=float(load),
            rss_kb=int(rss), julia='julia' in command.lower()))
    if not rows or own_pid not in {row['pid'] for row in rows}:
        raise RuntimeError('CPU sample did not observe the owned Julia PID')
    owned = {own_pid}
    while True:
        added = {row['pid'] for row in rows if row['parent'] in owned} - owned
        if not added:
            break
        owned.update(added)
    return dict(at=utc(), owned_cpu=sum(row['cpu'] for row in rows if row['pid'] in owned), other_busy=[{key: value for key, value in row.items() if key != 'julia'}
        for row in rows if row['julia'] and row['pid'] not in owned and row['cpu'] >= 5])


class StrictMonitor(cpu.Monitor):
    """Same CPU population as frozen helper, fail-closed on sampler failure."""
    def __init__(self, pid):
        super().__init__(pid)
        self.sampler_errors = []
        self.thread_entered = False
        self.thread_exited = False
        self.start_at = None

    def start(self):
        self.start_at = utc()
        # Require a real initial sample before dispatching any scientific job.
        self.observations.append(strict_cpu_sample(self.pid))
        super().start()

    def run(self):
        self.thread_entered = True
        try:
            while not self.done.wait(5):
                self.observations.append(strict_cpu_sample(self.pid))
        except BaseException as error:
            self.sampler_errors.append(dict(at=utc(), error=repr(error)))
        finally:
            self.thread_exited = True

    def finish(self):
        self.done.set()
        if self.thread.ident is not None:
            self.thread.join(timeout=12)
        stopped = not self.thread.is_alive()
        if not stopped:
            self.sampler_errors.append(dict(at=utc(), error='CPU sampler thread did not stop'))
        if stopped:
            try:
                self.observations.append(strict_cpu_sample(self.pid))
            except BaseException as error:
                self.sampler_errors.append(dict(at=utc(), error=repr(error)))
        times = [datetime.fromisoformat(row['at']).timestamp() for row in self.observations]
        gaps = [b-a for a, b in zip(times, times[1:])]
        largest_gap = max(gaps, default=0.0)
        healthy = self.thread_entered and self.thread_exited and stopped and not self.sampler_errors and \
            len(self.observations) >= 2 and all(gap >= 0 for gap in gaps) and largest_gap <= 15
        health = dict(healthy=healthy, thread_entered=self.thread_entered,
            thread_exited=self.thread_exited, thread_stopped=stopped,
            initial_and_final_samples_required=True, observations=len(self.observations),
            maximum_observed_gap_seconds=largest_gap, allowed_maximum_gap_seconds=15,
            sampler_errors=self.sampler_errors, sample_command_timeout_seconds=10)
        return dict(qualified=healthy and not any(row['other_busy'] for row in self.observations),
            observations=self.observations, sampler_health=health,
            scope='other Julia CPU >=5 percent; own process and descendants excluded; strict healthy sampling')


def content(response):
    return '\n'.join(item.get('text', '') for item in response.get('result', {}).get('content', [])
        if item.get('type') == 'text')


def response_state(response):
    result = response.get('result', {})
    message = content(response)
    if 'error' in response or result.get('isError') is True:
        return 'failed'
    status = result.get('status')
    if status in ('failed', 'cancelled', 'canceled', 'interrupted'):
        return 'failed'
    if re.search(r'(?mi)^\s*(?:ERROR:|failed\s*[,\n]|cancelled\s*[,\n]|canceled\s*[,\n])', message):
        return 'failed'
    if re.search(r'(?mi)^\s*completed\s*[,\n]', message) or status == 'completed':
        return 'completed'
    if 'promoted to background' in message.lower() or status == 'running' or \
            re.search(r'(?mi)^\s*running\s*[,\n]', message):
        return 'running'
    if re.search(r'(?i)no (?:background )?(?:job|eval|session)|unknown eval|not connected', message):
        return 'failed'
    return 'immediate'



def started_private_key(response):
    """Authoritative positive creation marker; unseen PID alone is insufficient."""
    if response_state(response) == 'failed':
        raise RuntimeError('Kaimon start failed: ' + content(response)[:2000])
    match = re.match(r'(?i)^\s*(?:new )?private session started\.\s*Session key:\s*([A-Za-z0-9_-]{8})\b', content(response))
    if not match:
        raise RuntimeError('No authoritative new-private-session marker; reject reused/unowned start before environment/science')
    return match.group(1)


def identity_expression():
    return """let scientific=(:PlantSimEngine,:PlantBiophysics,:XPalm,:PlantGeom),
        fixtures=(:NativeDownstreamMeasurements,:DirectPlannerMeasurements,:NativePBDriver,
            :NativeXPDriver,:DirectPlannerFixtures,:PBPreparationScaling,:XPPreparationScaling,
            :CompiledRegionsExperiment,:GeneratedProgramExperiment,:XPDispatchRefreshMeasurements,
            :PreparationScalingColdCase),
        loaded=Set(nameof(value) for value in values(Base.loaded_modules))
        (pid=getpid(),julia=string(VERSION),project=Base.active_project(),cwd=pwd(),
            main_scientific_absent=all(name->!isdefined(Main,name),scientific),
            loaded_scientific_absent=all(name->!(name in loaded),scientific),
            main_fixtures_absent=all(name->!isdefined(Main,name),fixtures),
            main_scientific=NamedTuple{scientific}(Tuple(isdefined(Main,name) for name in scientific)),
            loaded_scientific=NamedTuple{scientific}(Tuple(name in loaded for name in scientific)),
            main_fixture_presence=Tuple(name for name in fixtures if isdefined(Main,name)))
    end"""


def validate_identity(response, root):
    if response_state(response) == 'failed':
        raise RuntimeError('Identity evaluation failed: ' + content(response)[:2000])
    text = content(response)
    if str(root) not in text:
        raise RuntimeError('Identity does not report expected project')
    for key in ('main_scientific_absent', 'loaded_scientific_absent', 'main_fixtures_absent'):
        if not re.search(r'\b' + key + r'\s*=\s*true\b', text):
            raise RuntimeError('Cold pilot requires positive absence proof: ' + key + ': ' + text[:2500])
    match = re.search(r'\bpid\s*=\s*(\d+)', text)
    if not match:
        raise RuntimeError('Cannot verify actual worker PID')
    return int(match.group(1))


def eval_id(response):
    value = response.get('result', {}).get('eval_id')
    if value:
        return value
    match = re.search(r'(?:Job ID|Eval ID):\s*([A-Za-z0-9_-]+)', content(response))
    return match.group(1) if match else None


def phase_sum(record):
    phases = record['phases']
    expected = {'construction', 'pse_preparation', 'backend_lowering', 'first_execution', 'remaining_execution'}
    if set(phases) != expected:
        raise RuntimeError('Cold model phases differ from protocol')
    for phase in phases.values():
        for key in ('seconds', 'allocated_bytes', 'gc_seconds', 'compilation_seconds', 'recompilation_seconds'):
            if not isinstance(phase.get(key), (int, float)) or not math.isfinite(phase[key]) or phase[key] < 0:
                raise RuntimeError('Missing/invalid measured phase counter')
    if not math.isclose(sum(v['seconds'] for v in phases.values()), record['complete_seconds'], rel_tol=1e-12, abs_tol=1e-8):
        raise RuntimeError('First-use model phase sum differs')
    if sum(v['allocated_bytes'] for v in phases.values()) != record['complete_allocated_bytes']:
        raise RuntimeError('First-use model allocation sum differs')


def validate_artifact(data, kind, arm, pid, image):
    if data['protocol'] != PROTOCOL or (data['kind'], data['arm']) != (kind, arm):
        raise RuntimeError('Wrong cold case/protocol')
    if data['worker']['pid'] != pid or data['worker']['freshness']['pid'] != pid:
        raise RuntimeError('Wrong artifact worker PID')
    if data['source_image'] != image or data['source_image_verified_before_after'] is not True:
        raise RuntimeError('Cold source image drift/missing guard')
    for population in ('in_main', 'in_loaded_modules'):
        if any(data['worker']['preimport'][population].values()):
            raise RuntimeError('Scientific package was present before the cold import phase')
    required = ('passed', 'full_snapshot_rng_history_types_equal', 'work_equal', 'independent_models',
        'canonical_status_types_equal', 'canonical_reference_types_equal',
        'cross_instance_statuses_disjoint', 'cross_instance_canonical_references_disjoint')
    if any(data['parity'].get(key) is not True for key in required):
        raise RuntimeError('Cold/fresh-warm semantic or identity check failed')
    first, warm = data['record'], data['warm_companion']
    for record in (first, warm):
        phase_sum(record)
        if record['arm'] != arm:
            raise RuntimeError('Wrong record arm')
    if first['temperature'] != 'first_use' or warm['temperature'] != 'warm_fresh_instance_after_first_case_and_diagnostics':
        raise RuntimeError('Wrong first/warm freshness scope')
    for key in ('digest', 'snapshot', 'work', 'config'):
        if canonical(first[key]) != canonical(warm[key]):
            raise RuntimeError('Cold/fresh-warm mismatch: ' + key)
    p = first['coverage']['dispatch_policies']
    graph = arm in ('bounded_graph', 'typed_graph')
    typed = arm == 'typed_graph'
    if p['bounded'] != graph or p['graph'] != graph or p['typed_output_preparation'] != typed or p['trusted_index']:
        raise RuntimeError('Wrong cold candidate policies')
    if typed:
        counts = first['coverage']['typed_output_preparation']['counters']
        if counts['applications_completed'] <= 0 or counts['objects_prepared'] <= 0:
            raise RuntimeError('No actual typed preparation work')
    if graph and first['coverage']['graph_projection']['counters']['projections_completed'] <= 0:
        raise RuntimeError('No actual graph projection work')
    if any(first['coverage'][key] for key in ('native_fields', 'driver_units', 'native_driver_units')):
        raise RuntimeError('Ordinary numerical executor was replaced')
    accounted = data['bootstrap_phase']['seconds'] + sum(v['seconds'] for v in data['setup_phases'].values()) + first['complete_seconds']
    if not math.isclose(accounted, data['accounted_first_use_phase_seconds'], rel_tol=1e-12, abs_tol=1e-8):
        raise RuntimeError('Inclusive first-use phase accounting differs')
    if data['first_use_elapsed_seconds'] + 1e-6 < accounted or not math.isclose(
            data['first_use_elapsed_seconds'] - accounted, data['unassigned_first_use_overhead_seconds'], rel_tol=1e-10, abs_tol=1e-6):
        raise RuntimeError('First-use inclusive clock omits setup/overhead')
    return data


def scientific_source_projection(data):
    return {package['name']: dict(root=package.get('root'), revision=package.get('revision'),
        source_manifest_sha256=package.get('sources', {}).get('aggregate_sha256'))
        for package in data['provenance']['packages']}


class Pilot:
    def __init__(self, args):
        self.args = args
        self.root = args.root.resolve()
        self.out = self.root / 'benchmark/native_downstream/results/preparation-scaling'
        self.receipts = self.out / 'receipts'
        self.reproduction = self.out / 'reproduction'
        self.image = source_image(self.root)
        self.transport = json.loads(client.STATE.read_text())['session'] if client.STATE.exists() else client.initialize()
        self.seen = {args.previous_pid} if args.previous_pid else set()
        self.previous = args.previous_pid
        self.observed = {}
        self.sources = None
        self.receipt_counter = 0
        self.label = ''
        self.attempt = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')
        self.controller = dict(protocol='sequential_Kaimon_first_use_pilot_v1', started_at=utc(),
            plan=[dict(kind=k, arm=a) for k, a in CELLS], source_image_sha256=sha(canonical(self.image).encode()),
            cells=[], status='running', no_automatic_retries=True,
            cache_state='new distinct workers; normal disk/package caches retained',
            source_image_policy=dict(roots=SOURCE_ROOTS, excluded_directories=sorted(EXCLUDED_DIRECTORY_NAMES),
                symlinks_excluded=True, traversal='explicit_directory_stack_no_recursive_result_archives'),
            startup_scope='Kaimon startup/environment/identity RPC wall times separate from Julia first-use')
        self.controller_path = self.out / f'cold-pilot-{self.attempt}-controller.json'
        if self.controller_path.exists():
            raise RuntimeError('Never overwrite an earlier controller attempt')

    def call(self, name, arguments):
        self.receipt_counter += 1
        started_at, started = utc(), time.monotonic()
        try:
            response, _ = client.post('tools/call', {'name': name, 'arguments': arguments}, self.transport)
        except Exception as error:
            path = self.receipts / f'{self.label}-{self.attempt}-{self.receipt_counter:02}-{name}.json'
            write_json(path, dict(started_at=started_at, completed_at=utc(), elapsed_seconds=time.monotonic()-started,
                tool=name, arguments=arguments, transport_error=repr(error)))
            raise
        elapsed = time.monotonic()-started
        path = self.receipts / f'{self.label}-{self.attempt}-{self.receipt_counter:02}-{name}.json'
        write_json(path, dict(started_at=started_at, completed_at=utc(), elapsed_seconds=elapsed,
            tool=name, arguments=arguments, response=response))
        return response, path, elapsed

    def finish(self, response, receipt, *, budget, phase, monitor=None):
        state = response_state(response)
        if state == 'failed':
            raise RuntimeError(f'{phase} failed: {content(response)[:4000]}')
        if state != 'running':
            return response, receipt
        job = eval_id(response)
        if not job:
            raise RuntimeError(f'{phase}: background response has no eval ID')
        deadline = time.monotonic() + budget
        while True:
            # Kaimon requires >=30 s between checks; never wait 15 minutes merely
            # for a file after a failed job. A successful job without file fails
            # immediately in the caller. Running checks use a 30 s interval.
            time.sleep(30)
            if monitor is not None and monitor.sampler_errors:
                self.call('cancel_eval', {'eval_id': job})
                raise RuntimeError('CPU sampler failed during the running case; no timing qualification')
            if time.monotonic() >= deadline:
                self.call('cancel_eval', {'eval_id': job})
                raise RuntimeError(f'{phase} exceeded bounded {budget}s job budget')
            if phase == 'first_use' and monitor is not None:
                target = self.out / (self.label + '.json')
                recent = monitor.observations[-2:]
                idle = len(recent) == 2 and all(row.get('owned_cpu', float('inf')) <= 1 for row in recent)
                if not target.exists() and not idle:
                    print(json.dumps(dict(stage='active_worker_wait_no_RPC', label=self.label, eval_id=job)), flush=True)
                    continue
            response, receipt, _ = self.call('check_eval', {'eval_id': job})
            state = response_state(response)
            if state == 'failed':
                raise RuntimeError(f'{phase} failed: {content(response)[:4000]}')
            if state == 'completed':
                return response, receipt
            if state == 'immediate':
                raise RuntimeError(f'{phase}: unknown check_eval status; fail closed: {content(response)[:2000]}')
            print(json.dumps(dict(stage='running', label=self.label, phase=phase, eval_id=job)), flush=True)
            if time.monotonic() >= deadline:
                self.call('cancel_eval', {'eval_id': job})
                raise RuntimeError(f'{phase} exceeded bounded {budget}s job budget')

    def compare(self, data):
        kind = data['kind']
        projection = scientific_source_projection(data)
        if self.sources is not None and projection != self.sources:
            raise RuntimeError('PSE/PB/XP/PlantGeom source cohort changed between cold workers')
        self.sources = projection
        previous = self.observed.get(kind)
        if previous:
            for key in ('digest', 'snapshot', 'work', 'config'):
                if canonical(data['record'][key]) != canonical(previous['record'][key]):
                    raise RuntimeError('Cross-arm cold scientific/config mismatch: ' + key)
        self.observed[kind] = data

    def qualification(self, target, cpu_path, script, successful_receipt):
        path = self.out / 'qualification.json'
        manifest = json.loads(path.read_text()) if path.exists() else dict(
            protocol='explicit_controller_whole_RPC_artifact_to_CPU_binding_v1', artifacts=[])
        name = target.relative_to(self.out).as_posix()
        if any(row['artifact'] == name for row in manifest['artifacts']):
            raise RuntimeError('Qualification entry already exists; never overwrite')
        manifest['artifacts'].append(dict(artifact=name, artifact_sha256=sha(target.read_bytes()),
            cpu_record=cpu_path.relative_to(self.out).as_posix(), cpu_sha256=sha(cpu_path.read_bytes()),
            script=dict(path=script.relative_to(self.out).as_posix(), sha256=sha(script.read_bytes())),
            receipt=dict(path=successful_receipt.relative_to(self.out).as_posix(), sha256=sha(successful_receipt.read_bytes()))))
        temporary = path.with_suffix('.new.json')
        write_json(temporary, manifest)
        temporary.replace(path)

    def script(self, kind, arm, pid, target):
        previous = str(self.previous) if self.previous is not None else 'nothing'
        prior_pids = '[' + ','.join(str(p) for p in sorted(self.seen)) + ']'
        image = 'Dict{String,String}(' + ',\n'.join(jl_string(k) + '=>' + jl_string(v) for k, v in self.image.items()) + ')'
        expected = self.observed.get(kind, {}).get('record', {}).get('digest')
        expected_julia = jl_string(expected) if expected else 'nothing'
        code = f'''# Single uninterrupted eval: no package or scientific helper before clock.
@assert getpid()=={pid}
@assert all(name->!isdefined(Main,name),(:PlantSimEngine,:PlantBiophysics,:XPalm,:PlantGeom,:NativeDownstreamMeasurements,:DirectPlannerMeasurements,:NativePBDriver,:NativeXPDriver,:PreparationScalingColdCase))
@assert all(name->!(name in Set(nameof(value) for value in values(Base.loaded_modules))),(:PlantSimEngine,:PlantBiophysics,:XPalm,:PlantGeom))
pse_cold_entry_ns=time_ns()
pse_cold_bootstrap=@timed Base.include(Main,joinpath({jl_string(self.root)},{jl_string(DRIVER_REL)}))
Base.invokelatest(PreparationScalingColdCase.run_preparation_scaling_cold_case,
    :{kind},:{arm};root={jl_string(self.root)},steps=2,nobjects=2,profile=:accelerated,
    outputs=:none,seed=1,output_path={jl_string(target)},
    entry_started_ns=pse_cold_entry_ns,bootstrap_measurement=pse_cold_bootstrap,
    freshness=(new_process=true,no_prior_case_execution=true,no_prior_ir_probe=true,
        pid=getpid(),previous_pid={previous},prior_pids={prior_pids},
        method=:sequential_start_session_environment_and_distinct_PID_verification),
    expected_source_hashes={image},expected_digest={expected_julia})
'''
        path = self.reproduction / f'{self.label}-{self.attempt}.jl'
        if path.exists():
            raise RuntimeError('Never overwrite a reproduction script')
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(code)
        return path

    def one(self, kind, arm):
        self.label = f'cold-{kind}-{arm}'
        target = self.out / f'{self.label}.json'
        if target.exists():
            raise RuntimeError('Existing cold result must be preserved: ' + str(target))
        if source_image(self.root) != self.image:
            raise RuntimeError('Active source changed before starting worker')
        cpu.quiet(self.label, budget=self.args.quiet_budget)
        worker, owned, pid, monitor = None, False, None, None
        cell = dict(kind=kind, arm=arm, started_at=utc(), status='starting', rpc_seconds={}, setup_wall_seconds={})
        self.controller['cells'].append(cell)
        write_json(self.controller_path, self.controller)
        try:
            response, receipt, elapsed = self.call('start_session', dict(project_path=str(self.root),
                name='Preparation cold pilot '+kind+' '+arm+' '+self.attempt, private=True))
            cell['rpc_seconds']['start_session'] = elapsed
            worker = started_private_key(response)
            owned = True  # Set ONLY by the authoritative positive creation marker.
            cell['worker_session'] = worker
            setup_started = time.monotonic()
            response, receipt, elapsed = self.call('investigate_environment', {'session': worker})
            cell['rpc_seconds']['investigate_environment_initial'] = elapsed
            response, receipt = self.finish(response, receipt, budget=120, phase='environment')
            cell['setup_wall_seconds']['investigate_environment_sequence'] = time.monotonic()-setup_started
            if str(self.root) not in content(response):
                raise RuntimeError('Kaimon environment does not report the expected project')
            identity_code = identity_expression()
            setup_started = time.monotonic()
            response, receipt, elapsed = self.call('ex', dict(ses=worker, e=identity_code, q=False, max_output=2200))
            cell['rpc_seconds']['identity_initial'] = elapsed
            response, receipt = self.finish(response, receipt, budget=90, phase='identity')
            cell['setup_wall_seconds']['identity_sequence'] = time.monotonic()-setup_started
            identity_job = eval_id(response)
            if not identity_job:
                raise RuntimeError('Identity response has no eval ID for controller prewarm')
            identity_response = response
            ready, ready_receipt, ready_elapsed = self.call('check_eval', {'eval_id': identity_job})
            if response_state(ready) != 'completed':
                raise RuntimeError('Completed identity job did not prewarm completion polling')
            cell['rpc_seconds']['completion_poll_prewarm'] = ready_elapsed
            response = identity_response
            pid = validate_identity(response, self.root)
            if pid in self.seen:
                owned = False  # Do not shut down a reused/unrelated warm worker.
                raise RuntimeError('start_session returned an already-used PID; no cold case run')
            cell.update(pid=pid, status='executing_first_use')
            script = self.script(kind, arm, pid, target)
            # Setup may compile Kaimon's controller; wait for it to settle before model-first-use.
            cpu.quiet(self.label+'-after-identity', budget=self.args.quiet_budget)
            monitor = StrictMonitor(pid)
            monitor.start()
            request_started = time.monotonic()
            response, successful_receipt, elapsed = self.call('ex', dict(ses=worker,
                e='include('+jl_string(script)+')', q=False, max_output=3500))
            cell['rpc_seconds']['first_use_ex_initial'] = elapsed
            response, successful_receipt = self.finish(response, successful_receipt,
                budget=self.args.case_budget, phase='first_use', monitor=monitor)
            cell['first_use_request_wall_seconds'] = time.monotonic()-request_started
            isolation = monitor.finish(); monitor = None
            cpu_path = self.out / f'{self.label}-{self.attempt}-cpu.json'
            write_json(cpu_path, isolation)
            if not target.exists():
                raise RuntimeError('Successful job produced no artifact; do not wait for absent file')
            data = validate_artifact(json.loads(target.read_text()), kind, arm, pid, self.image)
            self.compare(data)
            if not isolation['qualified'] or not isolation['observations']:
                raise RuntimeError('CPU controller excludes this artifact from timing qualification')
            if source_image(self.root) != self.image:
                raise RuntimeError('Source changed during cold case')
            self.qualification(target, cpu_path, script, successful_receipt)
            self.seen.add(pid); self.previous = pid
            cell.update(status='qualified', artifact=target.relative_to(self.out).as_posix(),
                artifact_sha256=sha(target.read_bytes()), cpu_record=cpu_path.name,
                successful_receipt=successful_receipt.relative_to(self.out).as_posix(),
                digest=data['record']['digest'], first_use_elapsed_seconds=data['first_use_elapsed_seconds'],
                model_first_use_seconds=data['record']['complete_seconds'],
                warm_fresh_model_seconds=data['warm_companion']['complete_seconds'])
            print(json.dumps(dict(stage='qualified_cold_cell', **{k:cell[k] for k in
                ('kind','arm','pid','artifact','first_use_elapsed_seconds','model_first_use_seconds')})), flush=True)
        except Exception as error:
            cell.update(status='failed_no_automatic_retry', error=repr(error))
            raise
        finally:
            if monitor is not None:
                write_json(self.out / f'{self.label}-{self.attempt}-cpu-incomplete.json', monitor.finish())
            if worker and owned:
                try:
                    response, receipt, elapsed = self.call('manage_repl', {'session':worker, 'command':'shutdown'})
                    cell['rpc_seconds']['shutdown'] = elapsed
                    if response_state(response) == 'failed':
                        raise RuntimeError('Kaimon shutdown failed: '+content(response)[:1000])
                    if pid:
                        for _ in range(15):
                            state = subprocess.run(['ps','-p',str(pid),'-o','stat='],capture_output=True,text=True).stdout.strip()
                            if not state or state.startswith('Z'):
                                cell['shutdown_verified'] = True
                                break
                            time.sleep(2)
                        else:
                            raise RuntimeError('Owned Julia worker did not terminate after shutdown')
                except Exception as cleanup_error:
                    cell['cleanup_error'] = repr(cleanup_error)
                    if cell.get('status') == 'qualified':
                        cell['status'] = 'shutdown_failed_stop_before_next_worker'
                        raise
            cell['completed_at'] = utc()
            write_json(self.controller_path, self.controller)

    def run(self):
        self.out.mkdir(parents=True, exist_ok=True)
        image_path = self.out / f'cold-pilot-{self.attempt}-source-image.json'
        write_json(image_path, self.image)
        try:
            for kind, arm in CELLS:
                self.one(kind, arm)
            self.controller['status'] = 'completed_six_distinct_workers_one_case_per_arm'
        except Exception as error:
            self.controller.update(status='failed_fast_no_automatic_retry', error=repr(error))
            raise
        finally:
            self.controller['completed_at'] = utc()
            write_json(self.controller_path, self.controller)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path('/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine'))
    parser.add_argument('--run',action='store_true',help='ROOT only: start the six sequential Kaimon pilots')
    parser.add_argument('--previous-pid',type=int)
    parser.add_argument('--case-budget',type=int,default=480)
    parser.add_argument('--quiet-budget',type=int,default=300)
    args=parser.parse_args()
    if not args.run:
        image=source_image(args.root.resolve())
        print(json.dumps(dict(plan_only=True,cells=[dict(kind=k,arm=a) for k,a in CELLS],
            source_files=len(image),driver_sha256=image[DRIVER_REL],
            run_requires='--run --previous-pid <closed warm PID>',no_Julia_started=True),sort_keys=True))
        return
    if args.previous_pid is None:
        parser.error('--run requires --previous-pid of the closed warm worker')
    Pilot(args).run()


if __name__=='__main__':
    main()
