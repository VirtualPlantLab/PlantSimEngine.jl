# Independent scaling audit — 2026-11-01

Source-only/Python review; no Julia execution or .jl edits. Current PSE commit
ffa720ad85677da541c12789202cb8a27751155c. XP harness hashes remain
a79126b30db39820b344b052a48ce56623911f6177d43a12dd57fbf488731a88 and
5b5e86bed0b80a0086c2e1af92432ad03c840c72008c22dff158fa1937670dc2.

## Source and correctness scope

Each XP sample advances one original Palm in one registry; it is not an
aggregate of independent replicas. Duration increases both numerical work and
realized scene size. Package-default profile leaves all parameters unchanged;
initiation_age=0 and architecture=false remain explicit scenario choices.
Accelerated profile changes only production_speed_initial/mature to 0.2.

Fresh default parameters, Palm, forcing copy, candidate enablement, normal PSE
preparation and ordinary continuation are charged. XP weather file reading and
hashing are declared registration work outside timers. Complete cost sums
construction + PSE preparation + empty backend lowering + execution. Imports
and diagnostics have separate scope. This differs from PB's synthetic forcing
construction timing; absolute cross-package complete times are not comparable.

Untimed :all gates compare full state/raw retained history, RNG, status/carrier
shape, canonical-reference lifecycle and actual work after every step. Timed
:none samples compare final exact state/RNG/work. Do not describe timed :none as
retaining full histories. Reproduction of XP checks requires explicitly loading
growth_input_reuse_checks.jl before xp_preparation_scaling_checks.jl because
live_binding_checks=true uses GrowthInputReuseChecks._live_bindings.

The four-arm default matrix isolates typed preparation *within bounded+graph*
through typed_graph vs bounded_graph. typed_graph vs ordinary is a combined
policy result; it does not prove standalone typed preparation. Trusted lookup,
newborn instructions, native state and typed numerical drivers stay disabled.

Saved initial/stage1 checks passed. Actual XP dimensions:

| Profile | Days | Initial objects | Final objects | Added objects |
|---|---:|---:|---:|---:|
| accelerated | 2 | 8 | 14 | 6 |
| accelerated | 12 | 8 | 44 | 36 |
| package defaults | 2 | 8 | 8 | 0 |
| package defaults | 12 | 8 | 11 | 3 |

Default 2-day zero growth receives no newborn credit. PB 2/4/16-object gates
passed; PB is static original Monteith/Fvcb/Medlyn physics, with no newborn work.

## First completed screen: PB16 × 4 steps

Source: results/preparation-scaling/pb16-screen.json and its CPU qualification.
All 20 warmup+sample digests and work reports agree. All 178 source-manifest
files still match disk. All measured phase JIT/re-JIT counters are zero; CPU
qualification passed. Complete cost equals the sum of its four phase records.

Per-cycle median ratios versus ordinary_a:

| Arm | Execution | Preparation | Complete | Complete wins |
|---|---:|---:|---:|---:|
| ordinary_b | 0.9988 | 0.9762 | 0.9832 | 3/4 |
| bounded_graph | 1.1213 | 1.0261 | 1.0265 | 2/4 |
| typed_graph | 1.0916 | 0.7971 | 0.8180 | 4/4 |

Ordinary median execution is 0.0692 ms and complete 2.6368 ms. This supports a
preparation benefit from the combined typed_graph policy at this size; it is
not a numerical execution improvement, and bounded_graph alone is inconclusive.
PB32 is a proportionate next attribution check. XP64/128 decisions remain
pending actual XP12/32 costs and exact-work outcomes.

## XP12 accelerated single-trajectory screen

All 20 warmup+sample digests and actual work reports agree. One palm grows from
8 to 44 objects: 13 leaves, 13 internodes and 13 phytomers plus the 5 fixed
scene/plant/root/soil/stem objects, with 36 added IDs. All measured JIT/re-JIT is
zero, source files still match, CPU is qualified, and every qualification
artifact/CPU/script/receipt SHA binding checks out.

Ordinary median execution is 44.9158 ms and complete 66.9812 ms. Cycle-paired
median ratios versus ordinary_a:

| Arm | Execution | Preparation | Complete | Complete wins |
|---|---:|---:|---:|---:|
| ordinary_b | 0.9738 | 0.9815 | 0.9808 | 3/4 |
| bounded_graph | 0.9225 | 0.6870 | 0.8538 | 4/4 |
| typed_graph | 0.8317 | 0.7070 | 0.8188 | 4/4 |

The ordinary-B complete ratios span 0.9162–1.0010, so do not portray four cycles
as precise uncertainty estimates. Typed_graph versus bounded_graph has median
complete ratio 0.9620 and execution 0.9406, winning 3/4 cycles. The combined
policy gain versus ordinary is clearer than the incremental typed advantage.

Continue to XP32. The observed per-sample cost is comfortably small, but this
is not yet approval to spend time benchmarking every 64/128/profile combination.

## Stage2 exact gates

Saved stage2-checks.json passes PB32 and both 32-day XP profiles. Accelerated XP
is a single 104-object scene (33 leaves/phytomers, 96 added objects), with 1,987
retained streams in the separate :all gate. Defaults end at 17 objects (4
leaves/phytomers, 9 added objects), with 305 retained streams and no changed
parameters. These gates exercise every-step histories/reference transitions at
the actual larger dimensions. Warm32 results remain pending.

## PB32 × 8 steps

The completed screen passes exact digest/work, CPU and zero-JIT checks. All
qualification SHA bindings still reconcile. Ordinary median complete is 4.2179
ms, execution 0.2316 ms. Cycle-paired ratios:

| Arm | Execution | Preparation | Complete | Complete wins |
|---|---:|---:|---:|---:|
| ordinary_b | 1.0765 | 1.0043 | 1.0073 | 2/4 |
| bounded_graph | 1.0847 | 1.0158 | 1.0231 | 1/4 |
| typed_graph | 1.0924 | 0.7721 | 0.8163 | 4/4 |

The same preparation pattern holds at PB16 and PB32. Another warm PB size is a
lower priority than cold qualification and XP64; extra size should answer a
specific remaining memory/cost question rather than fill the ladder.

## XP32 accelerated screen and next-scale decision

All 20 records have matching exact digests/work, the actual single scene ends
at 104 objects/33 leaves, CPU qualification passes and source hashes still
match. Timed :none retention has 202 dependency streams, distinct from the
separate :all gate's 1,987 streams. Complete cost sums all phase records.

| Arm | Execution ratio | Preparation ratio | Complete ratio | Complete wins |
|---|---:|---:|---:|---:|
| ordinary_b | 0.9427 | 0.9971 | 0.9457 | 4/4 |
| bounded_graph | 0.9235 | 0.7015 | 0.8975 | 3/4 |
| typed_graph | 0.8651 | 0.6962 | 0.8484 | 4/4 |

Ordinary_a median complete is 135.2402 ms and execution 113.3572 ms. Relative to
ordinary_b, typed_graph still has median complete ratio 0.8984, winning 4/4;
bounded_graph is 0.9500, winning 3/4. Relative to bounded_graph, typed_graph is
0.9375 complete and 0.9197 execution, winning 4/4. A/A's systematic 5.4% median
difference is material; four cycles do not support a precise effect estimate.
One ordinary_b cycle4 PSE-preparation phase records 112.458 microseconds of
compilation, all other sample phase JIT/re-JIT counters zero. Report this tiny
residual rather than claiming strict zero compilation.

Recommendation: continue to ONE accelerated 64-day exact gate and four-arm
screen. Actual 32-day cost is comfortably within the proposed staged budget;
64 answers whether the benefit persists as one canopy grows further. Do not
automatically add 128 days or a full warm default-profile ladder. The default
32-day exact companion already demonstrates unchanged-parameter applicability;
choose a default warm companion only if its distinct scientific/default question
remains useful. Decide 128 from observed 64 cost, work and A/A uncertainty.
