import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('artifact');p.add_argument('script');a=p.parse_args()
r=Path('/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine/benchmark/native_downstream/results/preparation-scaling')
s=Path(a.script);dst=r/'reproduction'/s.name
if dst.exists(): assert dst.read_bytes()==s.read_bytes()
else: dst.write_bytes(s.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cs=list(r.glob(a.label+'-*-cpu.json'));rs=list((r/'receipts').glob(a.label+'-*-01-ex.json'));assert len(cs)==len(rs)==1
f=r/'qualification.json';d=json.loads(f.read_text()) if f.exists() else dict(protocol='explicit_controller_whole_RPC_artifact_to_CPU_binding_v1',artifacts=[])
assert not any(v['artifact']==a.artifact for v in d['artifacts'])
d['artifacts'].append(dict(artifact=a.artifact,artifact_sha256=sha(r/a.artifact),cpu_record=cs[0].name,cpu_sha256=sha(cs[0]),script=dict(path=str(dst.relative_to(r)),sha256=sha(dst)),receipt=dict(path=str(rs[0].relative_to(r)),sha256=sha(rs[0]))))
f.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(artifact=a.artifact,CPUqualified=json.loads(cs[0].read_text())['qualified'])))
