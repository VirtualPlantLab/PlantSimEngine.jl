Base.invokelatest() do
    spec=XPPreparationScaling.register_xp_preparation_scaling_case!(:xp_prep128;days=128,profile=:accelerated,allow_large=true)
    screen=XPPreparationScaling.screen_xp_preparation_scaling(spec;repetitions=6)
    report=(;pid=getpid(),screen,summary=NativeDownstreamMeasurements.summarize_screen(screen))
    open(joinpath(pwd(),"benchmark/native_downstream/results/preparation-scaling/xp128-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,report,2)
    end
    (;passed=true,case=screen.case,cycles=screen.repetitions)
end
