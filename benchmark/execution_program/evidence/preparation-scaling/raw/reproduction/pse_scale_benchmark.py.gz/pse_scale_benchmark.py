import argparse,importlib.util,json,re,time
from pathlib import Path
from datetime import datetime,timezone
import pse_future_cpu as cpu
spec=importlib.util.spec_from_file_location('client','/private/tmp/pse_kaimon_client.py')
client=importlib.util.module_from_spec(spec);spec.loader.exec_module(client)
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('script');p.add_argument('result');p.add_argument('--worker',default='ac86b70f');p.add_argument('--pid',type=int,default=96134);a=p.parse_args()
out=Path('/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine/benchmark/native_downstream/results/preparation-scaling')
attempt=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S');step=0
expected=Path(a.result)
if expected.exists(): raise RuntimeError('Refuse to overwrite existing evidence')
session=json.loads(client.STATE.read_text())['session']
def content(r): return '\n'.join(x.get('text','') for x in r.get('result',{}).get('content',[]) if x.get('type')=='text')
def call(name,arguments):
 global step
 step+=1;r,_=client.post('tools/call',{'name':name,'arguments':arguments},session)
 (out/'receipts'/f'{a.label}-{attempt}-{step:02}-{name}.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'tool':name,'arguments':arguments,'response':r},indent=2)+'\n')
 return r
cpu.quiet(a.label,budget=180)
monitor=cpu.Monitor(a.pid);monitor.start()
try:
 expression='@assert getpid()=='+str(a.pid)+'; include('+json.dumps(str(Path(a.script).resolve()))+')'
 r=call('ex',{'ses':a.worker,'e':expression,'q':False,'max_output':3000})
 text=content(r)
 if 'promoted to background' in text:
  match=re.search(r'Job ID:\s*([a-zA-Z0-9_-]+)',text)
  job=r.get('result',{}).get('eval_id') or (match.group(1) if match else None)
  if not job: raise RuntimeError(text)
  deadline=time.monotonic()+900
  while True:
   time.sleep(15)
   if not expected.exists() and time.monotonic()<deadline:
    print(json.dumps({'stage':'waiting_for_case_file','label':a.label}),flush=True);continue
   r=call('check_eval',{'eval_id':job});text=content(r)
   print(json.dumps({'stage':'evaluation','label':a.label,'status':text[:160]}),flush=True)
   if '\ncompleted,' in text: break
   if '\nfailed,' in text or '\ncancelled,' in text: raise RuntimeError(text[:3000])
   if time.monotonic()>deadline: raise RuntimeError('Benchmark budget exceeded; inspect live job '+job)
 if not expected.exists(): raise RuntimeError('No result artifact: '+text[:3000])
 print(json.dumps({'stage':'completed','label':a.label,'result':str(expected)}),flush=True)
finally:
 isolation=monitor.finish()
 (out/f'{a.label}-{attempt}-cpu.json').write_text(json.dumps(isolation,indent=2)+'\n')
 print(json.dumps({'stage':'cpu_qualification','qualified':isolation['qualified']}),flush=True)
