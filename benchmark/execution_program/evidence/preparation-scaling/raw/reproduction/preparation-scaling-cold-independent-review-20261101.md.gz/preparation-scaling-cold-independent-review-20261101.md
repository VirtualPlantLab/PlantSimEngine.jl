# Independent cold protocol review — 2026-11-01

Source/Python review only; no Julia execution, active source edits or controller
execution. Active driver SHA:
3a3469918102324bb7cfc896293551ec5624d2d66b132d0b626713791e8f0c85.

## Julia driver: clear on reviewed boundaries

- Bootstrap file imports no package and executes no fixture/model/IR probe.
  Caller clock begins before include and bootstrap measurement is preserved.
- Common PSE/PB/XP/PlantGeom union imports and definition-only loaders use the
  same measured setup phases for every kind/arm. Registration is charged,
  including XP weather IO that warm registration normally excludes.
- All scientific phase entry helpers cross invokelatest. Construction,
  preparation, empty numerical lowering, first step and remaining steps have
  separate timers. Internal current_step checks enforce 0→1→requested days.
- Wrapper/helper compilation and validation/stage IO outside those timers still
  fall inside caller-before-include through first-scientific-finish elapsed
  time. They appear as explicit unassigned overhead. Model-only/accounted and
  inclusive clocks must both be reported; inclusive excludes Kaimon startup.
- No fingerprint, RNG probe, identity scan, source rendering or IR precedes
  first scientific completion. Expected root source image is checked before
  fixture preparation and again after the companion/diagnostics.
- The first record and one fresh warm companion share the registered forcing
  data through independent copies and fresh construction. Full state/history/
  numeric-type/RNG/work parity is enforced after execution. Models, Statuses and
  every canonical Ref are checked disjoint. Warm scope explicitly follows
  first-case diagnostics and is not a steady-state sample.
- Preparation uses original ordinary numerical execution and canonical refs.
  Coverage rejects unrelated native/typed driver/newborn/trusted policies;
  lower must return nothing. Loaded optional definitions are not enablement.
- Distinct PID/prior-PID, project and package-path checks, fixture-loader absence
  before imports and zero harness counters enforce first use conditional on
  the controller's fresh-worker/no-prior-science attestation.
- Normal OS/package caches remain available and preload facts are recorded;
  fresh worker does not mean empty filesystem caches.

No concrete Julia-driver blocker found. Controller-level review is pending the
private runner: unique PID/startup+environment evidence, same expected source
image before/after each worker, forcing/case equality across arms, no scientific
warmup/IR, expected-digest comparison, CPU qualification and cleanup handling.

## Private Python controller review (initial SHA 03c297ce…)

Do not execute this initial revision until these controller issues are resolved:

1. `one()` extracts package-in-Main flags but never validates them. More
   seriously, it changes `owned` to true based solely on an unseen PID, even
   when start_session did not positively identify a new session. Require new
   owned-worker evidence and pristine/idle identity facts before attestation;
   do not shut down a reused/unrelated worker.
2. `--start-at` accepts prior scientifically valid artifacts without verifying
   their CPU qualification/receipt/script hashes or successful prior cleanup.
   A CPU-rejected file could be skipped as completed. Remove resume for this
   bounded pilot or validate the full qualified/closed prior-cell record.
3. Imported `pse_future_cpu.Monitor.run` can silently die on a sampling error.
   A nonempty prefix of observations still yields qualified=true. Record health
   and reject sampler failure/incomplete monitoring.
4. The source image should include loaded compiled_regions/generated_program
   sources (excluding archived results), not only src/ext/top-level native.

Positive controller properties: fixed six cells; identical 2-step original
cases and common loader; command scripts contain only identity→caller clock→
include→one first-use call; distinct PID and source/config/digest/work comparison
are explicit; first/warm phase sums are validated; original numerical executor
and actual metadata coverage are checked; qualification binds artifact, CPU,
script and successful receipt hashes; failures stop without automatic retries.
Freshness and monitoring proof must be enforced rather than merely recorded.
