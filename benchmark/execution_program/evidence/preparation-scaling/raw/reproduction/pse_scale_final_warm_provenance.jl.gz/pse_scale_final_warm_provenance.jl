Base.invokelatest() do
    M=NativeDownstreamMeasurements;PSE=PlantSimEngine
    provenance=M.process_provenance(;packages=(PSE,NativePBDriver.PB,NativeXPDriver.XPalm,PlantGeom))
    weather_path=joinpath(pkgdir(NativeXPDriver.XPalm),"0-data","meteo.csv")
    forcing=(path=weather_path,sha256=bytes2hex(M.SHA.sha256(read(weather_path))),
        rows_used_up_to=128,source=:first_original_daily_rows,independent_copy_per_scenario=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/preparation-scaling/final-warm-provenance.json"),"w") do io
        PSE.JSON.print(io,(;passed=true,pid=getpid(),provenance,forcing),2)
    end
    (;passed=true,pid=getpid(),package_count=length(provenance.packages))
end
