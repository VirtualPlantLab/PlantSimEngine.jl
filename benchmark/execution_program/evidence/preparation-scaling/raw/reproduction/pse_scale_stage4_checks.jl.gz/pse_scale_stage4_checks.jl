# Private, untimed retention=:none gate. Root executes through Kaimon only.
using Test
# Prerequisites: frozen common loader; XPPreparationScaling; GrowthInputReuseChecks.
let PSE=Main.PlantSimEngine, XPS=Main.XPPreparationScaling,
    F=Main.DirectPlannerFixtures, D=Main.XPDispatchRefreshMeasurements,
    CR=Main.CompiledRegionsExperiment, C=Main.GrowthInputReuseChecks
    days=128
    config=XPS.xp_scaling_config(;days,profile=:accelerated,outputs=:none,allow_large=true)
    weather=CR._xpalm_fixture_weather(days)
    left=Base.invokelatest(XPS.construct_xp_scaling_fixture,config;weather)
    right=Base.invokelatest(XPS.construct_xp_scaling_fixture,config;weather)
    reference=Base.invokelatest(XPS.prepare_xp_scaling,left.model,:ordinary_a;outputs=:none)
    candidate=Base.invokelatest(XPS.prepare_xp_scaling,right.model,:typed_graph;outputs=:none)
    old_left=Base.invokelatest(F.identities,left.model)
    old_right=Base.invokelatest(F.identities,right.model)
    evidence=Dict{Symbol,Any}()
    summary=nothing
    @testset "XP128 single trajectory: every-step measured retention parity" begin
        @test left.model!==right.model
        @test left.model.environment!==right.model.environment
        @test left.initial_ids==right.initial_ids
        @test D._same_status_shapes(old_left,old_right)
        @test all(key->old_left.statuses[key]!==old_right.statuses[key],keys(old_left.statuses))
        @test all(key->old_left.references[key]!==old_right.references[key],keys(old_left.references))
        @test isequal(Base.invokelatest(F.snapshot,reference,:xp),
            Base.invokelatest(F.snapshot,candidate,:xp))
        @test Base.invokelatest(F.scientific_rngs,left.model)==Base.invokelatest(F.scientific_rngs,right.model)
        Base.invokelatest(C._live_bindings,reference)
        Base.invokelatest(C._live_bindings,candidate)
        for day in 1:days
            Base.invokelatest(PSE.step!,reference)
            Base.invokelatest(PSE.step!,candidate)
            @test isequal(Base.invokelatest(F.snapshot,reference,:xp),
                Base.invokelatest(F.snapshot,candidate,:xp))
            @test Base.invokelatest(F.scientific_rngs,left.model)==
                Base.invokelatest(F.scientific_rngs,right.model)
            next_left=Base.invokelatest(F.identities,left.model)
            next_right=Base.invokelatest(F.identities,right.model)
            @test D._same_status_shapes(next_left,next_right)
            @test F.same_identity_transitions(old_left,old_right,next_left,next_right)
            Base.invokelatest(C._live_bindings,reference)
            Base.invokelatest(C._live_bindings,candidate)
            old_left,old_right=next_left,next_right
            if day in (32,64,96,128)
                @info "XP128 retention-none exact gate" day objects=length(PSE.object_ids(candidate.model))
            end
        end
        work=Base.invokelatest(XPS.xp_scaling_work,candidate,right,config)
        @test work==Base.invokelatest(XPS.xp_scaling_work,reference,left,config)
        @test work.steps==days
        @test work.scene_count==work.palm_count==work.independent_replicas_per_sample==1
        @test work.final_objects>work.initial_objects
        @test work.added_objects>0
        evidence[:ordinary_a]=Base.invokelatest(XPS.xp_scaling_coverage,reference,left,config,:ordinary_a)
        evidence[:typed_graph]=Base.invokelatest(XPS.xp_scaling_coverage,candidate,right,config,:typed_graph)
        @test !evidence[:ordinary_a].typed_output_preparation.enabled
        @test !evidence[:ordinary_a].graph_projection.enabled
        @test evidence[:typed_graph].actual_typed_output.growth_objects_prepared>0
        @test evidence[:typed_graph].actual_graph.rows_projected>0
        @test iszero(evidence[:typed_graph].native_fields)
        @test iszero(evidence[:typed_graph].driver_units)
        result=(;passed=true,days,profile=:accelerated,outputs=:none,
            arms=(:ordinary_a,:typed_graph),work,evidence,
            exact_every_step_state_rng_status_ref_shapes_reference_transitions_and_live_bindings=true,
            disjoint_initial_models_statuses_and_canonical_refs=true,
            history_scope=:exact_retention_none_dependency_streams_as_measured,
            largest_separate_full_history_gate_days=64,
            benchmark_claim=false)
        path=joinpath(pwd(),"benchmark","native_downstream","results","preparation-scaling","stage4-checks.json")
        mkpath(dirname(path))
        open(path,"w") do io
            PSE.JSON.print(io,(;pid=getpid(),results=[(;name=:xp128_accelerated_outputs_none,result)]),2)
        end
        summary=(;passed=true,pid=getpid(),days,objects=work.final_objects,added=work.added_objects,
            outputs=:none,path)
    end
    summary
end
