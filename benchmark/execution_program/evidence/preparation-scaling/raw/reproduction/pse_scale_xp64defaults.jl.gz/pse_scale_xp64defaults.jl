Base.invokelatest() do
    spec=XPPreparationScaling.register_xp_preparation_scaling_case!(:xp_prep64defaults;days=64,profile=:package_defaults,allow_large=true)
    screen=XPPreparationScaling.screen_xp_preparation_scaling(spec;repetitions=4)
    report=(;pid=getpid(),screen,summary=NativeDownstreamMeasurements.summarize_screen(screen))
    open(joinpath(pwd(),"benchmark/native_downstream/results/preparation-scaling/xp64defaults-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,report,2)
    end
    (;passed=true,case=screen.case,cycles=screen.repetitions)
end
