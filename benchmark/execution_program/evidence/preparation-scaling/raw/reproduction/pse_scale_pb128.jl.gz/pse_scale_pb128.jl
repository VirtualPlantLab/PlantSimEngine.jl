Base.invokelatest() do
    spec=PBPreparationScaling.register_pb_preparation_case!(:pb_prep128;nobjects=128,steps=8)
    screen=PBPreparationScaling.screen_pb_preparation(spec;repetitions=4)
    report=(;pid=getpid(),screen,summary=NativeDownstreamMeasurements.summarize_screen(screen))
    open(joinpath(pwd(),"benchmark/native_downstream/results/preparation-scaling/pb128-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,report,2)
    end
    (;passed=true,case=screen.case,cycles=screen.repetitions)
end
