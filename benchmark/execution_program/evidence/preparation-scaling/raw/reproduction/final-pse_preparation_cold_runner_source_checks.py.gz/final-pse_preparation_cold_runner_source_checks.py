"""Source-only runner helper checks; network and Julia startup are forbidden."""
import importlib.util
import json
import tempfile
from pathlib import Path

spec=importlib.util.spec_from_file_location('cold_runner_freeze_source_check','/private/tmp/pse_preparation_scaling_cold_pilot.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.client.post=lambda *a,**k: (_ for _ in ()).throw(AssertionError('Network forbidden in source check'))
def response(text,**rest):return {'result':{'content':[{'type':'text','text':text}],**rest}}
assert m.started_private_key(response('Private session started. Session key: abcd1234. No other agent.'))=='abcd1234'
assert m.started_private_key(response('New private session started. Session key: 1234abcd.'))=='1234abcd'
for text in ['Private session already running. Session key: abcd1234.', 'Session key: abcd1234. PID 98765', 'Shared session started. Session key: abcd1234.', 'Warning: Private session started. Session key: abcd1234.']:
    try:m.started_private_key(response(text))
    except RuntimeError:pass
    else:raise AssertionError('Unowned/reused start accepted')
root=Path('/test/project')
valid='(pid = 98765, project = "/test/project/Project.toml", main_scientific_absent = true, loaded_scientific_absent = true, main_fixtures_absent = true)'
assert m.validate_identity(response(valid),root)==98765
for key in ['main_scientific_absent', 'loaded_scientific_absent', 'main_fixtures_absent']:
    try:m.validate_identity(response(valid.replace(key+' = true',key+' = false')),root)
    except RuntimeError:pass
    else:raise AssertionError('Preloaded identity accepted')
m.strict_cpu_sample=lambda pid:{'at':m.utc(),'other_busy':[]}
x=m.StrictMonitor(99999);x.start();assert x.finish()['qualified']
x=m.StrictMonitor(99999);x.start();x.sampler_errors.append({'at':m.utc(),'error':'synthetic ps failure'});assert not x.finish()['qualified']
class ImmediateDone:
    def wait(self,seconds):return False
    def set(self):pass
def broken(pid):raise SystemExit('synthetic sampler BaseException')
m.strict_cpu_sample=broken;x=m.StrictMonitor(99999);x.done=ImmediateDone();x.run();assert not x.finish()['qualified']
with tempfile.TemporaryDirectory(prefix='pse-cold-source-test-',dir='/private/tmp') as tmp:
    root=Path(tmp)
    wanted=['Project.toml','Manifest.toml','src/a.jl','ext/a.jl',m.DRIVER_REL,'benchmark/compiled_regions/a.jl','benchmark/generated_program/a.jl']
    for name in wanted+['src/.git/ignored.jl','benchmark/native_downstream/results/old/ignored.jl','benchmark/compiled_regions/results/old.jl']:
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('source-only test')
    (root/'src/link.jl').symlink_to(root/'ext/a.jl')
    (root/'src/link_dir').symlink_to(root/'ext',target_is_directory=True)
    assert set(m.source_image(root))==set(wanted)
x=m.Pilot.__new__(m.Pilot);x.label='source-only'
x.call=lambda *a,**k:(response('This job is not completed yet'),Path('/private/tmp/fake-receipt'),0.0)
original_sleep=m.time.sleep;m.time.sleep=lambda _:None
try:
    try:x.finish(response('promoted to background',eval_id='abc12345'),Path('/private/tmp/fake'),budget=1,phase='source-only')
    except RuntimeError:pass
    else:raise AssertionError('Unknown background status accepted')
finally:m.time.sleep=original_sleep
assert m.response_state(response('ERROR: LoadError: @nospecialize annotation applied to a non-argument'))=='failed'
result=dict(passed=True,source_only=True,ownership_identity_checks=10,strict_sampler_checks=3,
    source_traversal_checks=1,background_failure_checks=2,no_network_calls=True,no_Julia_started=True,
    runner_sha256=m.sha(Path('/private/tmp/pse_preparation_scaling_cold_pilot.py').read_bytes()))
Path('/private/tmp/pse_preparation_cold_runner_source_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
