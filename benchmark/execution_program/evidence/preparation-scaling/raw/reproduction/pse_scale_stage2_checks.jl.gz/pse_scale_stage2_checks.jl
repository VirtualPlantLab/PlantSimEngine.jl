Base.invokelatest() do
    results=Any[]
    for (name,fn) in ((:pb32,()->PBPreparationScaling.pb_preparation_checks(;nobjects=32,steps=8)),
        (:xp32_accelerated,()->XPPreparationScalingChecks.xp_preparation_scaling_checks(;days=32,profile=:accelerated)),
        (:xp32_defaults,()->XPPreparationScalingChecks.xp_preparation_scaling_checks(;days=32,profile=:package_defaults)))
        result=fn();push!(results,(;name,result))
        open(joinpath(pwd(),"benchmark/native_downstream/results/preparation-scaling/stage2-checks.json"),"w") do io
            PlantSimEngine.JSON.print(io,(;pid=getpid(),results),2)
        end
    end
    (;passed=true,cases=length(results))
end
