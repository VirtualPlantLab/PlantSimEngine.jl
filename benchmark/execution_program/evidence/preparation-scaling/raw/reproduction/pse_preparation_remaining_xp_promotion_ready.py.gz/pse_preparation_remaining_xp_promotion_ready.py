"""PRIVATE draft: five cold cases, one positively owned Kaimon CLI per case.

ROOT only. Reuses frozen778 Pilot.one and scientific validation unchanged.
No direct Julia subprocesses; CLI controller startup is outside scientific clocks.
"""
import argparse
import importlib.util
import json
import math
from pathlib import Path
import re
import socket
import subprocess
import sys
import time

ROOT=Path('/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine')
BASE=Path('/private/tmp/pse_preparation_scaling_cold_promotion_ready.py')
STARTER=Path('/private/tmp/pse_growth_start_kaimon.py')
BASE_SHA='30dc2ffd4497b3c4b4ca98b66a9d76b191cad0d03a9ed2597ee272fab408465e'
STARTER_SHA='d9d57264e3ca677c849338893dc0bff9c8070666e35cb7e8632fa6d6e8dc09d3'
GIT='8114326662c393bae737d80a0482387f21124103'
DRIVER_SHA='8dfbd912ada8d8f0a57c16e5179b31fc47eaa23a95a72db95da292d17518b0b9'
CELLS=(('xp','typed_graph'),('xp','ordinary_a'),('xp','bounded_graph'))
import hashlib


def sha(raw):return hashlib.sha256(raw).hexdigest()
def load_frozen():
    if sha(BASE.read_bytes())!=BASE_SHA or sha(STARTER.read_bytes())!=STARTER_SHA:
        raise RuntimeError('Frozen runner/controller launcher changed')
    spec=importlib.util.spec_from_file_location('frozen778',BASE)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def bound(out,meta):
    path=(out/meta['path']).resolve()
    if not path.is_relative_to(out.resolve()) or not path.is_file() or sha(path.read_bytes())!=meta['sha256']:
        raise RuntimeError('Missing/stale/unsafe bound bytes: '+meta['path'])
    return path


def validate_prior(f,out,path,image):
    name=path.name;data=json.loads(path.read_text());pid=data['worker']['pid']
    f.validate_artifact(data,data['kind'],data['arm'],pid,image)
    manifest=json.loads((out/'qualification.json').read_text())
    rows=[r for r in manifest['artifacts'] if r['artifact']==name]
    if len(rows)!=1:raise RuntimeError('Prior case lacks one exact qualification binding')
    row=rows[0]
    bound(out,dict(path=name,sha256=row['artifact_sha256']))
    cpu_path=bound(out,dict(path=row['cpu_record'],sha256=row['cpu_sha256']))
    script=bound(out,row['script']);receipt=bound(out,row['receipt'])
    cpu=json.loads(cpu_path.read_text());health=cpu.get('sampler_health',{});obs=cpu.get('observations',[])
    for key in ('healthy','thread_entered','thread_exited','thread_stopped','initial_and_final_samples_required'):
        if health.get(key) is not True:raise RuntimeError('Prior CPU sampler health missing: '+key)
    times=[f.datetime.fromisoformat(x['at']).timestamp() for x in obs]
    gaps=[b-a for a,b in zip(times,times[1:])]
    if cpu.get('qualified') is not True or len(obs)<2 or any(x['other_busy'] for x in obs) or health.get('sampler_errors') or \
            health.get('observations')!=len(obs) or health.get('sample_command_timeout_seconds')!=10 or \
            health.get('allowed_maximum_gap_seconds')!=15 or any(x<0 or x>15 for x in gaps) or \
            not math.isclose(max(gaps,default=0),health['maximum_observed_gap_seconds'],abs_tol=1e-6):
        raise RuntimeError('Prior CPU qualification is not strict/quiet')
    completion=json.loads(receipt.read_text());response=completion['response'];text=f.content(response)
    if f.response_state(response) not in ('completed','immediate') or not re.search(r'\bpid\s*=\s*'+str(pid)+r'\b',text) or \
            not re.search(r'\bparity\s*=\s*true\b',text) or data['record']['digest'] not in text:
        raise RuntimeError('Prior completion receipt is not positive/matching')
    if str(path) not in script.read_text() or str(pid) not in script.read_text():
        raise RuntimeError('Prior reproduction script does not name this case/PID')
    matches=[]
    for controller in sorted(out.glob('cold-pilot-*-controller.json')):
        body=json.loads(controller.read_text())
        if body.get('status')=='running':continue
        for cell in body.get('cells',[]):
            if cell.get('artifact')==name and cell.get('status')=='qualified' and cell.get('pid')==pid and \
                    cell.get('artifact_sha256')==row['artifact_sha256'] and cell.get('shutdown_verified') is True and \
                    not cell.get('cleanup_error') and cell.get('successful_receipt')==row['receipt']['path'] and \
                    body.get('source_image_sha256')==sha(f.canonical(image).encode()):
                matches.append((controller,body,cell))
    if len(matches)!=1:raise RuntimeError('Prior case lacks unique completed ownership/cleanup controller proof')
    controller,body,cell=matches[0];session=cell['worker_session']
    prefix=receipt.name.rsplit('-',2)[0]
    actions={}
    for candidate in sorted((out/'receipts').glob(prefix+'-*.json')):
        value=json.loads(candidate.read_text());tool=value.get('tool');args=value.get('arguments',{})
        if tool=='start_session' and args.get('private') is True:
            if f.started_private_key(value['response'])==session:actions['start_session']=candidate
        elif tool=='investigate_environment' and args.get('session')==session:
            if f.response_state(value['response'])!='failed' and str(ROOT) in f.content(value['response']):actions['environment']=candidate
        elif tool=='ex' and args.get('ses')==session and 'main_scientific_absent' in args.get('e',''):
            if f.validate_identity(value['response'],ROOT)==pid:actions['identity']=candidate
        elif tool=='manage_repl' and args==dict(command='shutdown',session=session):
            if f.response_state(value['response'])!='failed' and 'Its process was stopped.' in f.content(value['response']):actions['shutdown']=candidate
    if set(actions)!={'start_session','environment','identity','shutdown'}:
        raise RuntimeError('Prior owned start/environment/identity/shutdown receipt chain incomplete')
    return data,dict(artifact=name,pid=pid,artifact_sha256=row['artifact_sha256'],
        qualification_sha256=sha((out/'qualification.json').read_bytes()),
        cpu_record=cpu_path.name,cpu_sha256=sha(cpu_path.read_bytes()),
        script=script.relative_to(out).as_posix(),script_sha256=sha(script.read_bytes()),
        receipt=receipt.relative_to(out).as_posix(),receipt_sha256=sha(receipt.read_bytes()),
        controller=controller.name,controller_sha256=sha(controller.read_bytes()),
        action_receipts={k:dict(path=p.relative_to(out).as_posix(),sha256=sha(p.read_bytes())) for k,p in actions.items()},
        shutdown_verified=True)


def listening_pids():
    result=subprocess.run(['lsof','-nP','-iTCP:2828','-sTCP:LISTEN','-t'],capture_output=True,text=True,timeout=10)
    if result.returncode not in (0,1):raise RuntimeError('Unable to establish MCP listener ownership')
    return {int(x) for x in result.stdout.split()}


def assert_frozen(f,image):
    head=subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,text=True,check=True,timeout=10).stdout.strip()
    if head!=GIT or sha(BASE.read_bytes())!=BASE_SHA or sha(STARTER.read_bytes())!=STARTER_SHA or \
            sha((ROOT/f.DRIVER_REL).read_bytes())!=DRIVER_SHA or f.source_image(ROOT)!=image:
        raise RuntimeError('Frozen Git/source/controller image changed')


def zero_ping(f,response):
    if f.response_state(response)=='failed' or not re.search(r'Sessions:\s*0 connected\s*/\s*0 total',f.content(response)):
        raise RuntimeError('Require positive zero-connected/zero-total Kaimon session proof')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',action='store_true')
    parser.add_argument('--case-budget',type=int,default=480)
    parser.add_argument('--quiet-budget',type=int,default=300)
    args=parser.parse_args();f=load_frozen();image=f.source_image(ROOT)
    assert_frozen(f,image)
    out=ROOT/'benchmark/native_downstream/results/preparation-scaling'
    prior,proof=validate_prior(f,out,out/'cold-pb-ordinary_a.json',image)
    prior_proofs=[proof]
    for prior_arm in ('typed_graph','bounded_graph'):
        other,other_proof=validate_prior(f,out,out/f'cold-pb-{prior_arm}.json',image)
        if f.scientific_source_projection(other)!=f.scientific_source_projection(prior):
            raise RuntimeError('Qualified PB sources differ')
        for key in ('digest','snapshot','work','config'):
            if f.canonical(other['record'][key])!=f.canonical(prior['record'][key]):
                raise RuntimeError('Qualified PB scientific/config mismatch')
        prior_proofs.append(other_proof)
    for kind,arm in CELLS:
        if (out/f'cold-{kind}-{arm}.json').exists():raise RuntimeError('Remaining cell already exists; never index-resume or overwrite')
    if not args.run:
        print(json.dumps(dict(plan_only=True,prior_pid=prior['worker']['pid'],prior_validation=proof,all_PB_proofs=prior_proofs,
            cells=CELLS,no_Julia_started=True),sort_keys=True));return
    tag=f.datetime.now(f.timezone.utc).strftime('%Y%m%dT%H%M%S')
    ledger_path=out/f'remaining-cold-{tag}-controllers.json'
    if ledger_path.exists():raise RuntimeError('Never overwrite an attempt ledger')
    ledger=dict(protocol='fresh_owned_Kaimon_CLI_per_cold_cell_v1',started_at=f.utc(),
        frozen_runner_sha256=BASE_SHA,starter_sha256=STARTER_SHA,driver_sha256=DRIVER_SHA,git_head=GIT,
        wrapper_sha256=sha(Path(__file__).read_bytes()),prior_qualification=proof,all_PB_proofs=prior_proofs,cells=[],status='running',
        external_controller_setup_excluded_from_Julia_clocks=True,no_automatic_retries=True)
    observed={'pb':prior};sources=f.scientific_source_projection(prior);seen={prior['worker']['pid']}
    for p in out.glob('cold-pilot-*-controller.json'):
        for cell in json.loads(p.read_text()).get('cells',[]):
            if isinstance(cell.get('pid'),int):seen.add(cell['pid'])
    previous=prior['worker']['pid']
    try:
        for kind,arm in CELLS:
            assert_frozen(f,image)
            if listening_pids():raise RuntimeError('An existing MCP listener is present; never stop/reuse it')
            cell=dict(kind=kind,arm=arm,started_at=f.utc(),status='launching_owned_controller')
            ledger['cells'].append(cell);f.write_json(ledger_path,ledger)
            proc=None;pilot=None;transport=None;may_stop=False
            log_path=Path('/private/tmp')/f'pse-owned-controller-{kind}-{arm}-{tag}.log'
            def rpc(name,arguments,suffix):
                started=time.monotonic();response,_=f.client.post('tools/call',dict(name=name,arguments=arguments),transport)
                path=out/'receipts'/f'owned-controller-{kind}-{arm}-{tag}-{suffix}.json'
                f.write_json(path,dict(recorded_at=f.utc(),tool=name,arguments=arguments,response=response,
                    elapsed_seconds=time.monotonic()-started,owned_controller_pid=proc.pid))
                return response,path
            try:
                started=time.monotonic()
                with log_path.open('xb') as log:
                    proc=subprocess.Popen([sys.executable,str(STARTER)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
                cell['owned_controller_pid']=proc.pid;cell['controller_log']=log_path.name;cell['controller_log_archived']=False
                deadline=time.monotonic()+120
                while True:
                    if proc.poll() is not None:raise RuntimeError('Owned Kaimon CLI exited during startup')
                    listeners=listening_pids()
                    if listeners:
                        if listeners!={proc.pid}:raise RuntimeError('MCP port listener is not the positively owned CLI PID')
                        break
                    if time.monotonic()>deadline:raise RuntimeError('Bounded Kaimon CLI readiness deadline')
                    time.sleep(1)
                transport=f.client.initialize()
                response,path=rpc('ping',{},'before-worker-ping')
                zero_ping(f,response);may_stop=True
                cell['before_worker_ping']=path.relative_to(out).as_posix()
                cell['controller_startup_seconds']=time.monotonic()-started
                pargs=argparse.Namespace(root=ROOT,previous_pid=previous,case_budget=args.case_budget,quiet_budget=args.quiet_budget)
                pilot=f.Pilot(pargs)
                pilot.image=image;pilot.seen=set(seen);pilot.previous=previous
                pilot.observed=dict(observed);pilot.sources=sources
                pilot.controller['plan']=[dict(kind=kind,arm=arm)]
                pilot.controller['orchestration_scope']='one_cell_with_separate_owned_Kaimon_CLI'
                # Unchanged frozen method performs ownership, environment, PID,
                # absence, quietness, first-use, science, CPU binding and cleanup.
                may_stop=False
                pilot.one(kind,arm)
                pilot.controller['status']='completed_single_requested_cell'
                pilot.controller['completed_at']=f.utc();f.write_json(pilot.controller_path,pilot.controller)
                observed=dict(pilot.observed);sources=pilot.sources;seen=set(pilot.seen);previous=pilot.previous
                cell['worker_controller']=pilot.controller_path.name
                cell['worker_pid']=pilot.controller['cells'][0]['pid']
                if pilot.controller['cells'][0].get('shutdown_verified') is not True:
                    raise RuntimeError('Frozen worker cleanup proof missing')
                cell['status']='qualified_worker_shutdown_verified'
            except Exception as error:
                cell['status']='failed_stop_no_retry';cell['error']=repr(error)
                if pilot is not None:
                    pilot.controller.update(status='failed_single_requested_cell',completed_at=f.utc(),outer_error=repr(error))
                    f.write_json(pilot.controller_path,pilot.controller)
                raise
            finally:
                try:
                    if proc is not None and proc.poll() is None:
                        # Never stop a listener merely because it occupies the port.
                        if listening_pids()!={proc.pid}:raise RuntimeError('Owned CLI listener identity changed; no stop signal sent')
                        if transport is None:raise RuntimeError('No initialized MCP authority; retain owned CLI for inspection')
                        response,path=rpc('ping',{},'after-worker-ping')
                        zero_ping(f,response);may_stop=True
                        cell['after_worker_zero_ping']=path.relative_to(out).as_posix()
                        stop_started=time.monotonic();proc.terminate()
                        try:proc.wait(timeout=20)
                        except subprocess.TimeoutExpired:
                            # Positively owned, unchanged listener and verified0 sessions.
                            proc.kill();proc.wait(timeout=10);cell['owned_controller_stop_escalated']=True
                        cell['controller_stop_seconds']=time.monotonic()-stop_started
                        cell['owned_controller_stopped']=True
                        if listening_pids():raise RuntimeError('MCP port still has a listener after owned controller stopped')
                    elif proc is not None:
                        cell['owned_controller_exited']=True
                except Exception as cleanup:
                    cell['controller_cleanup_error']=repr(cleanup)
                    raise
                finally:
                    cell['completed_at']=f.utc();f.write_json(ledger_path,ledger)
            assert_frozen(f,image)
        ledger['status']='completed_remaining_three_distinct_workers_controllers'
    except Exception as error:
        ledger.update(status='failed_fast_no_automatic_retry',error=repr(error))
        raise
    finally:
        ledger['completed_at']=f.utc();f.write_json(ledger_path,ledger)


if __name__=='__main__':main()
