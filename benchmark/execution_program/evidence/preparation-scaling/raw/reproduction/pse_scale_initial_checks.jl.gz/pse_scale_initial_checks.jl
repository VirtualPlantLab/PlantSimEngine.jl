for file in ("growth_input_reuse_checks.jl","pb_preparation_scaling.jl","xp_preparation_scaling.jl","xp_preparation_scaling_checks.jl")
    include(joinpath(pwd(),"benchmark/native_downstream",file))
end
Base.invokelatest() do
    results=Any[]
    cases=((:xp_config,()->XPPreparationScalingChecks.xp_scaling_config_checks()),
        (:xp_fixture,()->XPPreparationScalingChecks.xp_scaling_fixture_checks(;days=2)),
        (:xp_accelerated,()->XPPreparationScalingChecks.xp_preparation_scaling_checks(;days=2,profile=:accelerated)),
        (:xp_defaults,()->XPPreparationScalingChecks.xp_preparation_scaling_checks(;days=2,profile=:package_defaults)),
        (:pb2,()->PBPreparationScaling.pb_preparation_checks(;nobjects=2,steps=2)),
        (:pb4,()->PBPreparationScaling.pb_preparation_checks(;nobjects=4,steps=2)))
    for (name,fn) in cases
        result=fn();push!(results,(;name,result))
        open(joinpath(pwd(),"benchmark/native_downstream/results/preparation-scaling/initial-checks.json"),"w") do io
            PlantSimEngine.JSON.print(io,(;pid=getpid(),results),2)
        end
    end
    (;passed=true,cases=length(results),pid=getpid())
end
