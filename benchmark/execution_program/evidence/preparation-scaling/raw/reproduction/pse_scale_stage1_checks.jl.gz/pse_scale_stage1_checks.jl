Base.invokelatest() do
    results=Any[]
    for (name,fn) in ((:pb16,()->PBPreparationScaling.pb_preparation_checks(;nobjects=16,steps=4)),
        (:xp12_accelerated,()->XPPreparationScalingChecks.xp_preparation_scaling_checks(;days=12,profile=:accelerated)),
        (:xp12_defaults,()->XPPreparationScalingChecks.xp_preparation_scaling_checks(;days=12,profile=:package_defaults)))
        result=fn();push!(results,(;name,result))
        open(joinpath(pwd(),"benchmark/native_downstream/results/preparation-scaling/stage1-checks.json"),"w") do io
            PlantSimEngine.JSON.print(io,(;pid=getpid(),results),2)
        end
    end
    (;passed=true,cases=length(results))
end
