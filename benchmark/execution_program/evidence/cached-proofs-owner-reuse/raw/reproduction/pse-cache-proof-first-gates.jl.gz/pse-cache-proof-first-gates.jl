include(joinpath(pwd(),"benchmark/native_downstream/load_persistent_experiment.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/cached_declaration_proofs.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/cached_declaration_proofs_checks.jl"))
let out=joinpath(pwd(),"benchmark/native_downstream/results/cached-proofs-owner-reuse"), results=Dict{String,Any}()
    open(joinpath(out,"proof-first-gates-test-output.txt"),"w") do io
        redirect_stdout(io) do
            for (label,fn) in (("cache",CachedDeclarationProofChecks.cached_proof_checks),("world",CachedDeclarationProofChecks.cached_proof_world_checks),("admission",CachedDeclarationProofChecks.cached_proof_admission_checks))
                results[label]=try
                    (passed=true,result=Base.invokelatest(fn))
                catch error
                    (passed=false,error=sprint(showerror,error,catch_backtrace()))
                end
                open(joinpath(out,"proof-first-gates.json"),"w") do target
                    PlantSimEngine.JSON.print(target,results,2)
                end
                results[label].passed || break
            end
        end
    end
end
nothing
