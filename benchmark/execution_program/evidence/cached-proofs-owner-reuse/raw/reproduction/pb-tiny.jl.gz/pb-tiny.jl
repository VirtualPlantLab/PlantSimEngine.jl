let spec=CachedOwnerMeasurements.register_cached_owner_case!(:pb_tiny,:pb;steps=2,nobjects=2,outputs=:none)
    screen=CachedOwnerMeasurements.screen_cached_owner(spec;repetitions=2,measure_retained=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/cached-proofs-owner-reuse/pb-tiny-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,screen,2)
    end
end
nothing
