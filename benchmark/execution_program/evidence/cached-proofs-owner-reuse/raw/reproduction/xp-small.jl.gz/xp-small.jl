let spec=CachedOwnerMeasurements.register_cached_owner_case!(:xp_small,:xp;steps=4,nobjects=2,outputs=:none)
    screen=CachedOwnerMeasurements.screen_cached_owner(spec;repetitions=2,measure_retained=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/cached-proofs-owner-reuse/xp-small-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,screen,2)
    end
end
nothing
