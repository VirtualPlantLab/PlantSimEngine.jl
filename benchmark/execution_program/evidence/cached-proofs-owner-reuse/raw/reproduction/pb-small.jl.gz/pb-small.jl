let spec=CachedOwnerMeasurements.register_cached_owner_case!(:pb_small,:pb;steps=8,nobjects=16,outputs=:none)
    screen=CachedOwnerMeasurements.screen_cached_owner(spec;repetitions=2,measure_retained=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/cached-proofs-owner-reuse/pb-small-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,screen,2)
    end
end
nothing
