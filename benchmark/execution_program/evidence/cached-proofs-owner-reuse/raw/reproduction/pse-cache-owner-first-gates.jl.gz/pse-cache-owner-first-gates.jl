include(joinpath(pwd(),"benchmark/native_downstream/cold_owner_program.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/cached_owner_measurements.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/cached_owner_checks.jl"))
let out=joinpath(pwd(),"benchmark/native_downstream/results/cached-proofs-owner-reuse"), results=Dict{String,Any}()
    open(joinpath(out,"owner-first-gates-test-output.txt"),"w") do io
        redirect_stdout(io) do
            for (label,fn) in (("partial_matrix",()->CachedOwnerChecks.cached_owner_partial_failure_matrix()),
                ("owner_small",()->CachedOwnerChecks.cached_owner_small_checks(:owner_only)),
                ("combo_small",()->CachedOwnerChecks.cached_owner_small_checks(:combined)),
                ("proof_small",()->CachedOwnerChecks.cached_owner_small_checks(:proof_only)))
                results[label]=try
                    (passed=true,result=Base.invokelatest(fn))
                catch error
                    (passed=false,error=sprint(showerror,error,catch_backtrace()))
                end
                open(joinpath(out,"owner-first-gates.json"),"w") do target
                    PlantSimEngine.JSON.print(target,results,2)
                end
            end
        end
    end
end
nothing
