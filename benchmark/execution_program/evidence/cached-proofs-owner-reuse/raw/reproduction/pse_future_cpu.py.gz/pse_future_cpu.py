import subprocess,time,json,threading
from datetime import datetime,timezone

def sample(own_pid=None):
 rows=[]
 for line in subprocess.check_output(['ps','-axo','pid,ppid,pcpu,rss,comm'],text=True).splitlines()[1:]:
  parts=line.split(None,4)
  if len(parts)!=5:continue
  pid,parent,cpu,rss,command=parts
  rows.append(dict(pid=int(pid),parent=int(parent),cpu=float(cpu),rss_kb=int(rss),julia='julia' in command.lower()))
 owned={own_pid} if own_pid else set()
 changed=True
 while changed:
  added={x['pid'] for x in rows if x['parent'] in owned}-owned;changed=bool(added);owned.update(added)
 return dict(at=datetime.now(timezone.utc).isoformat(),other_busy=[{k:v for k,v in row.items() if k!='julia'} for row in rows if row['julia'] and row['pid'] not in owned and row['cpu']>=5])

def quiet(label,budget=1800):
 deadline=time.monotonic()+budget;stable=0
 while True:
  obs=sample()
  if obs['other_busy']:
   stable=0;print(json.dumps(dict(stage='waiting_for_quiet',label=label,other_busy=obs['other_busy'])),flush=True)
  else:
   stable+=1
   if stable>=2:return
  if time.monotonic()>deadline:raise RuntimeError('No quiet Julia benchmark window within budget')
  time.sleep(15)

class Monitor:
 def __init__(self,pid):self.pid=pid;self.observations=[];self.done=threading.Event();self.thread=threading.Thread(target=self.run,daemon=True)
 def run(self):
  while not self.done.is_set():
   self.observations.append(sample(self.pid));self.done.wait(5)
 def start(self):self.thread.start()
 def finish(self):self.done.set();self.thread.join();return dict(qualified=not any(x['other_busy'] for x in self.observations),observations=self.observations,scope='other Julia CPU >=5 percent; own process and descendants excluded')
