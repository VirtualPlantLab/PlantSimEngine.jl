let out=joinpath(pwd(),"benchmark/native_downstream/results/cached-proofs-owner-reuse"), stages=Dict{String,Any}()
    open(joinpath(out,"gradual-gates-test-output.txt"),"w") do io
        redirect_stdout(io) do
            for kind in (:pb,:xp)
                stages[string(kind)]=try
                    (passed=true,result=CachedOwnerMeasurements.cached_owner_downstream_checks(kind;steps=4,nobjects=4))
                catch error
                    (passed=false,error=sprint(showerror,error,catch_backtrace()))
                end
                open(joinpath(out,"gradual-gates.json"),"w") do target
                    PlantSimEngine.JSON.print(target,stages,2)
                end
                stages[string(kind)].passed || break
            end
        end
    end
end
nothing
