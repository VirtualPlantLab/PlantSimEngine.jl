# Reload only prototype modules; scientific fixtures and kernels stay original.
for file in ("persistent_tight_program.jl","cached_declaration_proofs.jl",
    "cached_declaration_proofs_checks.jl","cold_owner_program.jl",
    "persistent_downstream_measurements.jl","persistent_targetless_checks.jl",
    "cached_owner_measurements.jl","cached_owner_checks.jl","cached_owner_identity_checks.jl")
    include(joinpath(pwd(),"benchmark/native_downstream",file))
end
function pse_cached_owner_require_partial_matrix()
    result=CachedOwnerChecks.cached_owner_partial_failure_matrix()
    @assert result.passed
    return result
end
let out=joinpath(pwd(),"benchmark/native_downstream/results/cached-proofs-owner-reuse"), stages=Dict{String,Any}()
    tests=Any[
        ("proof_cache",()->CachedDeclarationProofChecks.cached_proof_checks()),
        ("proof_world",()->CachedDeclarationProofChecks.cached_proof_world_checks()),
        ("unknown_capability",()->CachedDeclarationProofChecks.cached_proof_admission_checks()),
        ("partial_matrix",pse_cached_owner_require_partial_matrix),
    ]
    for arm in (:persistent,:proof_only,:owner_only,:combined)
        push!(tests,("small_"*string(arm),()->CachedOwnerChecks.cached_owner_small_checks(arm)))
    end
    for arm in (:proof_only,:owner_only,:combined)
        push!(tests,("float64_none_"*string(arm),()->CachedOwnerChecks.cached_owner_lifecycle_checks(arm;T=Float64,outputs=:none)))
        push!(tests,("targetless_"*string(arm),()->CachedOwnerChecks.cached_owner_targetless_checks(arm)))
        for case in (:evaluate_accept,:stale_accept,:backend_override)
            push!(tests,("fallback_"*string(arm)*"_"*string(case),()->CachedOwnerChecks.cached_owner_fallback_checks(arm;case)))
        end
    end
    for arm in (:owner_only,:combined)
        push!(tests,("identity_"*string(arm),()->CachedOwnerIdentityChecks.cached_owner_identity_checks(arm)))
        push!(tests,("expose_zero_"*string(arm),()->CachedOwnerChecks.cached_owner_epoch_checks(arm;inspect_step=0)))
    end
    for kind in (:pb,:xp)
        push!(tests,("downstream_"*string(kind),()->CachedOwnerMeasurements.cached_owner_downstream_checks(kind;steps=2,nobjects=2)))
    end
    open(joinpath(out,"final-small-gates-test-output.txt"),"w") do io
        redirect_stdout(io) do
            for (label,check) in tests
                stages[label]=try
                    (passed=true,result=Base.invokelatest(check))
                catch error
                    (passed=false,error=sprint(showerror,error,catch_backtrace()))
                end
                open(joinpath(out,"final-small-gates.json"),"w") do target
                    PlantSimEngine.JSON.print(target,stages,2)
                end
                stages[label].passed || break
            end
        end
    end
end
nothing
