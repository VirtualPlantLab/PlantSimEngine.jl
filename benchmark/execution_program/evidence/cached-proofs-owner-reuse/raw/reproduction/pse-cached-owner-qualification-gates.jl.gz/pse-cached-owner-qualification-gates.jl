# Function-only reload after removing an unused duplicate keyword. Layouts and constants are unchanged.
module CachedOwnerWarmReload
function ismethod(ex)
    ex isa Expr || return false
    ex.head===:function && return true
    ex.head===:(=) && return ex.args[1] isa Expr && ex.args[1].head in (:call,:where)
    ex.head===:macrocall && return any(ismethod,ex.args)
    return false
end
function reload!(mod,path)
    parsed=Meta.parseall(read(path,String);filename=path)
    tree=only(ex for ex in parsed.args if ex isa Expr && ex.head===:module)
    for ex in tree.args[end].args
        ismethod(ex) && Core.eval(mod,ex)
    end
end
end
CachedOwnerWarmReload.reload!(ColdOwnerProgram,joinpath(pwd(),"benchmark/native_downstream/cold_owner_program.jl"))
function pse_cached_owner_require_partial_matrix()
    result=CachedOwnerChecks.cached_owner_partial_failure_matrix()
    @assert result.passed
    return result
end
let out=joinpath(pwd(),"benchmark/native_downstream/results/cached-proofs-owner-reuse"), stages=Dict{String,Any}()
    tests=Any[
        ("proof_cache",()->CachedDeclarationProofChecks.cached_proof_checks()),
        ("proof_world",()->CachedDeclarationProofChecks.cached_proof_world_checks()),
        ("unknown_capability",()->CachedDeclarationProofChecks.cached_proof_admission_checks()),
        ("partial_matrix",pse_cached_owner_require_partial_matrix),
    ]
    for arm in (:persistent,:proof_only,:owner_only,:combined)
        push!(tests,("small_"*string(arm),()->CachedOwnerChecks.cached_owner_small_checks(arm)))
    end
    for arm in (:proof_only,:owner_only,:combined)
        push!(tests,("float64_none_"*string(arm),()->CachedOwnerChecks.cached_owner_lifecycle_checks(arm;T=Float64,outputs=:none)))
        push!(tests,("targetless_"*string(arm),()->CachedOwnerChecks.cached_owner_targetless_checks(arm)))
        for case in (:evaluate_accept,:stale_accept,:backend_override)
            push!(tests,("fallback_"*string(arm)*"_"*string(case),()->CachedOwnerChecks.cached_owner_fallback_checks(arm;case)))
        end
    end
    for arm in (:owner_only,:combined)
        push!(tests,("identity_"*string(arm),()->CachedOwnerIdentityChecks.cached_owner_identity_checks(arm)))
        push!(tests,("expose_zero_"*string(arm),()->CachedOwnerChecks.cached_owner_epoch_checks(arm;inspect_step=0)))
    end
    for kind in (:pb,:xp)
        push!(tests,("downstream_"*string(kind),()->CachedOwnerMeasurements.cached_owner_downstream_checks(kind;steps=2,nobjects=2)))
    end
    open(joinpath(out,"qualification-gates-test-output.txt"),"w") do io
        redirect_stdout(io) do
            for (label,check) in tests
                stages[label]=try
                    (passed=true,result=Base.invokelatest(check))
                catch error
                    (passed=false,error=sprint(showerror,error,catch_backtrace()))
                end
                open(joinpath(out,"qualification-gates.json"),"w") do target
                    PlantSimEngine.JSON.print(target,stages,2)
                end
                stages[label].passed || break
            end
        end
    end
end
nothing
