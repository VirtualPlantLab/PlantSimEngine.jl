module PlantSimEngineGraphEditorExt

import HTTP
import JSON
import Dates
import PlantSimEngine
import PlantSimEngine.GraphEditor: edit_graph, current_model, apply_edit!, undo!, redo!

mutable struct GraphEditorSession <: PlantSimEngine.GraphEditor.AbstractModelGraphEditorSession
    model::PlantSimEngine.CompositeModel
    templates::Dict{Symbol,Any}
    environments::Dict{Symbol,Any}
    history::Vector{Any}
    future::Vector{Any}
    server::Any
    host::String
    port::Int
    token::String
    url::String
    autosave_path::Union{Nothing,String}
    save_path::Union{Nothing,String}
    allow_julia_eval::Bool
    recent_paths::Vector{String}
end

current_model(session::GraphEditorSession) = session.model

function _normalize_named_catalog(catalog, label)
    entries = if catalog isa NamedTuple
        collect(pairs(catalog))
    elseif catalog isa AbstractDict
        collect(pairs(catalog))
    else
        error("$(label) catalog must be a NamedTuple or dictionary.")
    end
    normalized = Dict{Symbol,Any}()
    for (name_, value) in entries
        name_ isa Symbol || error("$(label) catalog names must be symbols, got `$(repr(name_))`.")
        name = name_
        Base.isidentifier(String(name)) || error(
            "$(label) catalog name `$(name)` must be a valid Julia identifier.",
        )
        haskey(normalized, name) && error("$(label) catalog contains duplicate name `$(name)`.")
        normalized[name] = value
    end
    return normalized
end

function _normalize_template_catalog(catalog)
    normalized = _normalize_named_catalog(catalog, "Template")
    for (name, template) in normalized
        template isa PlantSimEngine.CompositeModelTemplate || error(
            "Template catalog entry `$(name)` must be a CompositeModelTemplate.",
        )
    end
    return normalized
end

_normalize_environment_catalog(catalog) = _normalize_named_catalog(catalog, "Environment")

function Base.close(session::GraphEditorSession)
    try
        isopen(session.server) && close(session.server)
    catch
        close(session.server)
    end
    return nothing
end

function Base.show(io::IO, session::GraphEditorSession)
    print(io, "GraphEditorSession(url=$(repr(session.url)), applications=$(length(session.model.applications)))")
end

function Base.show(io::IO, ::MIME"text/plain", session::GraphEditorSession)
    println(io, "PlantSimEngineGraphEditorExt.GraphEditorSession")
    println(io, "  Open in browser: $(session.url)")
    println(io, "  State JSON: $(_state_url(session))")
    println(io, "  Current model: GraphEditor.current_model(session)")
    println(io, "  Quit session: close(session)")
    isnothing(session.autosave_path) || println(io, "  Recovery autosave: $(session.autosave_path)")
    isnothing(session.save_path) || println(io, "  Saving changes to: $(session.save_path)")
end

"""
    edit_graph([model]; templates=NamedTuple(), environments=NamedTuple(),
               host="127.0.0.1", port=0, open_browser=true,
               autosave=true, allow_remote=false, allow_julia_eval=nothing)

Start a local Model graph editor. Julia owns the current Composite model and applies all
semantic edits received from the browser. Call `edit_graph()` to start from an
empty Composite model and `close(session)` to stop the server. `templates` is a
named catalog of `CompositeModelTemplate` presets. `environments` is a named
catalog of server-side environment values; these values are referenced by name
and are never serialized to the browser.
"""
function edit_graph(
    model::PlantSimEngine.CompositeModel=PlantSimEngine.CompositeModel();
    host::AbstractString="127.0.0.1",
    port::Integer=0,
    open_browser::Bool=true,
    autosave::Bool=true,
    autosave_path::Union{Nothing,AbstractString}=nothing,
    save_path::Union{Nothing,AbstractString}=nothing,
    allow_remote::Bool=false,
    allow_julia_eval::Union{Nothing,Bool}=nothing,
    recover_path::Union{Nothing,AbstractString}=nothing,
    recent_paths=nothing,
    templates=NamedTuple(),
    environments=NamedTuple(),
)
    _is_loopback_host(host) || allow_remote || error(
        "Graph editor sessions are limited to localhost by default. Pass `allow_remote=true` only for a trusted network.",
    )
    effective_allow_julia_eval = isnothing(allow_julia_eval) ? !allow_remote : allow_julia_eval
    template_catalog = _normalize_template_catalog(templates)
    environment_catalog = _normalize_environment_catalog(environments)
    catalog_values = (
        values(template_catalog)...,
        values(environment_catalog)...,
    )
    initial_model = isnothing(recover_path) ? PlantSimEngine._model_graph_deepcopy(
        model,
        catalog_values,
    ) : _load_model_file(
        _normalized_path(recover_path);
        allow_julia_eval=effective_allow_julia_eval,
        environments=environment_catalog,
    )
    session_ref = Ref{Any}()
    handler = stream -> _handle_http(session_ref[], stream)
    server = HTTP.listen!(handler, host, port; listenany=true, verbose=false)
    actual_port = HTTP.port(server)
    token = _session_token()
    autosave_file = autosave ? _normalized_path(
        isnothing(autosave_path) ? _default_autosave_path() : autosave_path,
    ) : nothing
    remembered_paths = isnothing(recent_paths) ? _load_recent_paths() : String.(recent_paths)
    session = GraphEditorSession(
        initial_model,
        template_catalog,
        environment_catalog,
        Any[],
        Any[],
        server,
        String(host),
        actual_port,
        token,
        "http://$(host):$(actual_port)/?token=$(token)",
        autosave_file,
        isnothing(save_path) ? nothing : _normalized_path(save_path),
        effective_allow_julia_eval,
        String[_normalized_path(path) for path in remembered_paths],
    )
    session_ref[] = session
    isnothing(session.save_path) || _remember_path!(session, session.save_path)
    isnothing(recover_path) || _remember_path!(session, _normalized_path(recover_path))
    _persist_model!(session)
    open_browser && _open_in_default_browser(session.url)
    return session
end

function apply_edit!(session::GraphEditorSession, edit::PlantSimEngine.GraphEditor.AbstractModelGraphEdit)
    candidate = PlantSimEngine.GraphEditor.apply_model_graph_edit(
        session.model,
        edit;
        preserve=(values(session.templates)..., values(session.environments)...),
    )
    if edit isa Union{
        PlantSimEngine.GraphEditor.SetCompositeModelEnvironment,
        PlantSimEngine.GraphEditor.SetModelApplicationEnvironment,
    }
        report = PlantSimEngine.Authoring.validate_scenario(candidate).compilation
        _, environment_plans_by_id =
            PlantSimEngine._compile_environment_application_plans(
                candidate,
                report.applications;
                prepare_runtime=false,
            )
        bindings = PlantSimEngine._compile_environment_bindings_for_applications(
            candidate,
            report.applications,
            environment_plans_by_id,
        )
        PlantSimEngine._validate_model_environment_inputs!(
            bindings,
            Dict(application.id => application for application in report.applications),
        )
    end
    push!(session.history, session.model)
    empty!(session.future)
    session.model = candidate
    _persist_model!(session)
    return session.model
end

function undo!(session::GraphEditorSession)
    isempty(session.history) && return session.model
    push!(session.future, session.model)
    session.model = pop!(session.history)
    _persist_model!(session)
    return session.model
end

function redo!(session::GraphEditorSession)
    isempty(session.future) && return session.model
    push!(session.history, session.model)
    session.model = pop!(session.future)
    _persist_model!(session)
    return session.model
end

_session_token() = PlantSimEngine._graph_editor_session_token()

function _is_loopback_host(host)
    return lowercase(strip(String(host))) in (
        "127.0.0.1",
        "localhost",
        "::1",
        "[::1]",
        "0:0:0:0:0:0:0:1",
    )
end

_base_url(session) = "http://$(session.host):$(session.port)"
_state_url(session) = "$(_base_url(session))/state?token=$(session.token)"
_websocket_url(session) = "ws://$(session.host):$(session.port)/ws?token=$(session.token)"

function _handle_http(session::GraphEditorSession, stream::HTTP.Stream)
    request = stream.message
    path = HTTP.URI(request.target).path

    if HTTP.WebSockets.isupgrade(request)
        _authorized_request(session, request) || return _write_response(stream, 403, "text/plain", "Forbidden session token.")
        _authorized_origin(session, request) || return _write_response(stream, 403, "text/plain", "Forbidden websocket origin.")
        return HTTP.WebSockets.upgrade(stream) do websocket
            _handle_websocket(session, websocket)
        end
    end

    if path == "/health"
        return _write_response(stream, 200, "application/json", JSON.json(Dict("ok" => true)))
    end
    _authorized_request(session, request) || return _write_response(stream, 403, "text/plain", "Forbidden session token.")
    if path == "/" || path == "/index.html"
        return _write_response(stream, 200, "text/html; charset=utf-8", _editor_html(session))
    elseif path == "/static"
        view = PlantSimEngine.GraphEditor.model_graph_view(
            session.model;
            templates=session.templates,
            environments=session.environments,
        )
        return _write_response(
            stream,
            200,
            "text/html; charset=utf-8",
            PlantSimEngine.GraphEditor.model_graph_view_html(view),
        )
    elseif path == "/state"
        return _write_response(stream, 200, "application/json", _state_json(session))
    end
    return _write_response(stream, 404, "text/plain", "Not found")
end

function _write_response(stream, status, content_type, body)
    HTTP.setstatus(stream, status)
    HTTP.setheader(stream, "Content-Type" => content_type)
    HTTP.setheader(stream, "Connection" => "close")
    HTTP.setheader(stream, "Content-Length" => string(sizeof(body)))
    HTTP.startwrite(stream)
    write(stream, body)
    return nothing
end

function _authorized_request(session, request)
    token = HTTP.header(request, "X-PlantSimEngine-Graph-Token", "")
    isempty(token) && (token = something(_query_parameter(request.target, "token"), ""))
    return token == session.token
end

function _query_parameter(target, requested_name)
    query = String(HTTP.URI(target).query)
    isempty(query) && return nothing
    for component in split(query, '&')
        pair = split(component, '='; limit=2)
        length(pair) == 2 || continue
        first(pair) == requested_name && return last(pair)
    end
    return nothing
end

function _authorized_origin(session, request)
    origin = HTTP.header(request, "Origin", "")
    return isempty(origin) || origin == _base_url(session)
end

function _handle_websocket(session, websocket)
    _send_websocket(websocket, _state_json(session)) || return nothing
    try
        for raw_message in websocket
            command = JSON.parse(String(raw_message))
            response = _handle_command!(session, command)
            _send_websocket(websocket, JSON.json(response)) || return nothing
        end
    catch err
        _is_close_error(err) || _send_websocket(
            websocket,
            JSON.json(Dict("ok" => false, "diagnostics" => [sprint(showerror, err)])),
        )
    end
    return nothing
end

function _send_websocket(websocket, payload)
    try
        HTTP.WebSockets.send(websocket, payload)
        return true
    catch err
        _is_close_error(err) && return false
        rethrow()
    end
end

_is_close_error(err) = err isa EOFError || err isa Base.IOError

function _handle_command!(session, command)
    action = String(get(command, "action", ""))
    try
        if action == "undo"
            undo!(session)
        elseif action == "redo"
            redo!(session)
        elseif action == "edit"
            apply_edit!(session, _edit_from_command(session, command))
        elseif action == "save_model_code"
            session.save_path = _normalized_path(String(command["path"]))
            _remember_path!(session, session.save_path)
            _persist_model!(session)
        elseif action == "open_model_code"
            path = _normalized_path(String(command["path"]))
            candidate = _load_model_file(
                path;
                allow_julia_eval=session.allow_julia_eval,
                environments=session.environments,
            )
            push!(session.history, session.model)
            empty!(session.future)
            session.model = candidate
            session.save_path = path
            _remember_path!(session, path)
            _persist_model!(session)
        elseif action == "preview_input_binding"
            return _preview_input_binding_payload(session, command)
        elseif action == "preview_application_targets"
            return _preview_application_targets_payload(session, command)
        elseif action == "preview_instance"
            return _preview_instance_payload(session, command)
        elseif action in ("open_add_application", "begin_add_application")
            # This command only focuses/prefills frontend state. The Composite model is
            # changed by a subsequent add_application edit.
        else
            error("Unsupported graph editor command action `$(action)`.")
        end
        return _state_payload(session)
    catch err
        return _state_payload(session; ok=false, diagnostics=[sprint(showerror, err)])
    end
end

function _preview_instance_payload(session, command)
    candidate = PlantSimEngine.GraphEditor.apply_model_graph_edit(
        session.model,
        _add_instance_edit(session, command),
    )
    name = Symbol(command["name"])
    instance = only(item for item in candidate.instances if item.name == name)
    report = PlantSimEngine.Authoring.validate_scenario(candidate).compilation
    application_ids = PlantSimEngine._instance_application_ids(candidate, instance)
    payload = _state_payload(session)
    payload["instancePreview"] = Dict{String,Any}(
        "name" => string(name),
        "objectIds" => [
            PlantSimEngine._model_graph_object_id_value(id.value)
            for id in PlantSimEngine._instance_object_ids(candidate, instance)
        ],
        "applications" => [
            Dict(
                "applicationId" => string(application.id),
                "targetIds" => [
                    PlantSimEngine._model_graph_object_id_value(id.value)
                    for id in application.target_ids
                ],
            )
            for application in report.applications if application.id in application_ids
        ],
        "diagnostics" => [diagnostic.message for diagnostic in report.diagnostics],
    )
    return payload
end

function _preview_application_targets_payload(session, command)
    selector = _selector_from_payload(command["selector"])
    groups = Dict{String,Any}[]
    target_ids = if haskey(command, "applicationRef")
        application = _application_ref_from_command(command)
        if application.scope == :template
            _, selected = PlantSimEngine._model_edit_instance(
                session.model,
                something(application.instance),
            )
            ids = PlantSimEngine.ObjectId[]
            for instance in session.model.instances
                instance.template === selected.template || continue
                scoped = PlantSimEngine._selector_with_scope(
                    selector,
                    PlantSimEngine.Scope(instance.name),
                )
                selected_ids = PlantSimEngine.resolve_object_ids(session.model, scoped)
                append!(ids, selected_ids)
                push!(groups, Dict(
                    "instance" => string(instance.name),
                    "objectIds" => [PlantSimEngine._model_graph_object_id_value(id) for id in selected_ids],
                ))
            end
            unique(ids)
        else
            PlantSimEngine.resolve_object_ids(session.model, selector)
        end
    else
        PlantSimEngine.resolve_object_ids(session.model, selector)
    end
    payload = _state_payload(session)
    payload["targetPreview"] = Dict{String,Any}(
        "objectIds" => [PlantSimEngine._model_graph_object_id_value(id.value) for id in target_ids],
        "count" => length(target_ids),
        "groups" => groups,
    )
    return payload
end

function _preview_input_binding_payload(session, command)
    application = _application_ref_from_command(command)
    application_ids = PlantSimEngine._model_edit_compiled_application_ids(
        session.model,
        application,
    )
    input = Symbol(command["input"])
    candidate = PlantSimEngine.GraphEditor.apply_model_graph_edit(
        session.model,
        PlantSimEngine.GraphEditor.SetModelInputBinding(
            application,
            input,
            _selector_for_application(session, application, command["selector"]),
        ),
    )
    report = PlantSimEngine.Authoring.validate_scenario(candidate).compilation
    bindings = [
        binding for binding in report.input_bindings
        if binding.application_id in application_ids && binding.input == input
    ]
    payload = _state_payload(session)
    payload["selectorPreview"] = Dict{String,Any}(
        "applicationRef" => _application_ref_payload(application),
        "input" => string(input),
        "consumerObjectIds" => unique([
            PlantSimEngine._model_graph_object_id_value(binding.consumer_id.value)
            for binding in bindings
        ]),
        "sourceObjectIds" => unique([
            PlantSimEngine._model_graph_object_id_value(source_id.value)
            for binding in bindings for source_id in binding.source_ids
        ]),
        "sourceApplicationIds" => unique([
            string(source_id) for binding in bindings
            for source_id in binding.source_application_ids
        ]),
        "bindingCount" => length(bindings),
        "diagnostics" => [diagnostic.message for diagnostic in report.diagnostics],
    )
    return payload
end

function _application_ref_payload(application)
    return Dict{String,Any}(
        "scope" => string(application.scope),
        "applicationId" => string(application.application_id),
        "instance" => isnothing(application.instance) ? nothing : string(application.instance),
    )
end

function _application_ref_from_command(command)
    payload = get(command, "applicationRef", nothing)
    payload isa AbstractDict || error("Application commands require an `applicationRef` object.")
    scope = Symbol(get(payload, "scope", ""))
    application_id = Symbol(get(payload, "applicationId", ""))
    scope == :global && return PlantSimEngine.GraphEditor.GlobalApplicationRef(application_id)
    scope == :template && return PlantSimEngine.GraphEditor.TemplateApplicationRef(
        payload["instance"],
        application_id,
    )
    error("Unsupported application owner scope `$(scope)`.")
end

function _model_local_templates(session)
    templates = Any[]
    for instance in session.model.instances
        any(template -> template === instance.template, values(session.templates)) && continue
        any(template -> template === instance.template, templates) || push!(templates, instance.template)
    end
    return templates
end

function _template_from_id(session, template_id)
    text = String(template_id)
    if startswith(text, "catalog:")
        name = Symbol(chopprefix(text, "catalog:"))
        haskey(session.templates, name) || error("Unknown template catalog entry `$(name)`.")
        return session.templates[name]
    elseif startswith(text, "model:")
        index = parse(Int, chopprefix(text, "model:"))
        templates = _model_local_templates(session)
        checkbounds(Bool, templates, index) || error("Unknown model-local template `$(text)`.")
        return templates[index]
    end
    error("Unsupported template id `$(text)`.")
end

function _environment_from_id(session, environment_id)
    isnothing(environment_id) && return nothing
    text = String(environment_id)
    text == "none" && return nothing
    startswith(text, "environment:") || error("Unsupported environment id `$(text)`.")
    name = Symbol(chopprefix(text, "environment:"))
    haskey(session.environments, name) || error("Unknown environment catalog entry `$(name)`.")
    return session.environments[name]
end

function _edit_from_command(session, command)
    kind = String(get(command, "kind", ""))
    kind == "add_instance" && return _add_instance_edit(session, command)
    kind == "remove_instance" && return PlantSimEngine.GraphEditor.RemoveModelInstance(command["name"])
    kind == "set_model_environment" && return PlantSimEngine.GraphEditor.SetCompositeModelEnvironment(
        _environment_from_id(session, get(command, "environmentId", nothing)),
    )
    application = kind in (
        "remove_application", "mark_previous_timestep", "unmark_previous_timestep",
        "break_cycle", "set_application_targets", "set_input_binding",
        "remove_input_binding", "set_call_binding", "remove_call_binding",
        "set_application_cadence", "set_application_environment", "set_output_routing",
        "set_update_ordering", "set_instance_override", "remove_instance_override",
        "set_object_override", "remove_object_override", "update_application",
        "replace_application_model", "set_output_destinations",
    ) ? _application_ref_from_command(command) : nothing
    kind == "remove_application" && return PlantSimEngine.GraphEditor.RemoveModelApplication(application)
    kind == "mark_previous_timestep" && return PlantSimEngine.GraphEditor.MarkModelPreviousTimeStep(
        application,
        Symbol(command["input"]),
    )
    kind == "unmark_previous_timestep" && return PlantSimEngine.GraphEditor.UnmarkModelPreviousTimeStep(
        application,
        Symbol(command["input"]),
    )
    kind == "break_cycle" && return PlantSimEngine.GraphEditor.BreakModelCycle(
        application,
        Symbol(command["input"]),
        Bool(get(command, "initializeMissing", false)),
        _parameter_value(session, get(command, "initialValue", nothing)),
    )
    kind == "set_application_targets" && return PlantSimEngine.GraphEditor.SetModelApplicationTargets(
        application,
        _selector_for_application(session, application, command["selector"]),
    )
    kind == "set_input_binding" && return PlantSimEngine.GraphEditor.SetModelInputBinding(
        application,
        Symbol(command["input"]),
        _selector_for_application(session, application, command["selector"]),
    )
    kind == "remove_input_binding" && return PlantSimEngine.GraphEditor.RemoveModelInputBinding(
        application,
        Symbol(command["input"]),
    )
    if kind == "set_call_binding"
        selector = _selector_for_application(
            session,
            application,
            command["selector"],
        )
        mode = Symbol(get(command, "mode", "manual"))
        mode in (:manual, :initializer) || error(
            "Call binding mode must be `manual` or `initializer`, got `$(mode)`.",
        )
        binding = mode === :initializer ?
                  PlantSimEngine.Initializer(selector) : selector
        return PlantSimEngine.GraphEditor.SetModelCallBinding(
            application,
            Symbol(command["call"]),
            binding,
        )
    end
    kind == "remove_call_binding" && return PlantSimEngine.GraphEditor.RemoveModelCallBinding(
        application,
        Symbol(command["call"]),
    )
    kind == "set_application_cadence" && return PlantSimEngine.GraphEditor.SetModelApplicationCadence(
        application,
        _period_from_payload(get(command, "cadence", nothing)),
    )
    kind == "set_application_environment" && return PlantSimEngine.GraphEditor.SetModelApplicationEnvironment(
        application,
        _application_environment_from_payload(session, get(command, "configuration", nothing)),
    )
    kind == "set_output_routing" && return PlantSimEngine.GraphEditor.SetModelOutputRouting(
        application,
        Symbol(command["output"]),
        Symbol(command["route"]),
    )
    if kind == "set_output_destinations"
        payload = command["destinations"]
        payload isa AbstractVector || error("Output destinations must be an array.")
        destinations = Tuple(map(payload) do destination
            vars = get(destination, "vars", nothing)
            isnothing(vars) || (vars isa AbstractVector && all(value -> value isa AbstractString, vars)) ||
                error("Output destination vars must be null or an array of variable names.")
            PlantSimEngine.OutputTo(
                _selector_for_application(session, application, destination["selector"]);
                vars=isnothing(vars) ? nothing : Tuple(Symbol.(vars)),
                coverage=Symbol(get(destination, "coverage", "exact")),
            )
        end)
        return PlantSimEngine.GraphEditor.SetModelOutputDestinations(application, destinations)
    end
    kind == "set_update_ordering" && return PlantSimEngine.GraphEditor.SetModelUpdateOrdering(
        application,
        _updates_from_payload(application, get(command, "updates", Any[])),
    )
    kind == "set_object_status" && return PlantSimEngine.GraphEditor.SetModelObjectStatus(
        _object_id_from_payload(command["objectId"]),
        Symbol(command["variable"]),
        _parameter_value(session, command["value"]),
    )
    kind == "set_object_statuses" && return PlantSimEngine.GraphEditor.SetModelObjectStatuses(
        [_object_id_from_payload(id) for id in command["objectIds"]],
        Symbol(command["variable"]),
        _parameter_value(session, command["value"]),
    )
    kind == "remove_object_status" && return PlantSimEngine.GraphEditor.RemoveModelObjectStatus(
        _object_id_from_payload(command["objectId"]),
        Symbol(command["variable"]),
    )
    kind in ("set_object_metadata", "update_object") && return PlantSimEngine.GraphEditor.SetModelObjectMetadata(
        _object_id_from_payload(command["objectId"]),
        _metadata_from_payload(get(command, "configuration", Dict())),
    )
    kind == "add_object" && return PlantSimEngine.GraphEditor.AddModelObject(
        _object_from_command(session, command),
    )
    kind == "remove_object" && return PlantSimEngine.GraphEditor.RemoveModelObject(
        _object_id_from_payload(command["objectId"]);
        recursive=Bool(get(command, "recursive", true)),
    )
    kind == "reparent_object" && return PlantSimEngine.ReparentModelObject(
        _object_id_from_payload(command["objectId"]),
        _optional_object_id_from_payload(get(command, "parentId", nothing)),
    )
    kind == "set_instance_override" && return PlantSimEngine.GraphEditor.SetModelInstanceOverride(
        command["instance"],
        application.application_id,
        _construct_model(session, command["modelType"], get(command, "parameters", Dict())),
    )
    kind == "remove_instance_override" && return PlantSimEngine.GraphEditor.RemoveModelInstanceOverride(
        command["instance"],
        application.application_id,
    )
    kind == "set_object_override" && return PlantSimEngine.GraphEditor.SetModelObjectOverride(
        command["instance"],
        _object_id_from_payload(command["objectId"]),
        application.application_id,
        _construct_model(session, command["modelType"], get(command, "parameters", Dict())),
    )
    kind == "remove_object_override" && return PlantSimEngine.GraphEditor.RemoveModelObjectOverride(
        command["instance"],
        _object_id_from_payload(command["objectId"]),
        application.application_id,
    )
    kind == "add_application" && return _add_application_edit(session, command)
    kind == "update_application" && return _update_application_edit(session, command)
    kind == "replace_application_model" && return PlantSimEngine.GraphEditor.ReplaceModelApplicationModel(
        application,
        _construct_model(session, command["modelType"], get(command, "parameters", Dict())),
    )
    error("Unsupported Model graph edit kind `$(kind)`.")
end

function _add_instance_edit(session, command)
    root_payload = get(command, "rootObject", nothing)
    root = isnothing(root_payload) ? nothing : _object_from_command(session, root_payload)
    root_id = isnothing(root) ? _object_id_from_payload(command["rootId"]) : root.id
    return PlantSimEngine.GraphEditor.AddModelInstance(
        command["name"],
        _template_from_id(session, command["templateId"]),
        root_id;
        root_object=root,
    )
end

function _selector_for_application(session, application, payload)
    selector = _selector_from_payload(payload)
    application.scope == :global && return selector
    _, instance = PlantSimEngine._model_edit_instance(
        session.model,
        something(application.instance),
    )
    return PlantSimEngine._model_edit_unmount_selector(selector, instance)
end

function _application_environment_from_payload(session, payload)
    isnothing(payload) && return nothing
    payload isa AbstractDict || error("Application environment configuration must be an object.")
    values = Pair{Symbol,Any}[]
    backend_id = get(payload, "backendId", "scene")
    backend_id in (nothing, "scene") || push!(values, :backend => _environment_from_id(session, backend_id))
    provider = get(payload, "provider", nothing)
    isnothing(provider) || isempty(strip(String(provider))) || push!(values, :provider => Symbol(provider))
    sources = get(payload, "sources", Dict())
    isempty(sources) || push!(values, :sources => (; (
        Symbol(key) => Symbol(value) for (key, value) in pairs(sources)
        if !isempty(strip(String(value)))
    )...))
    sink = get(payload, "sink", nothing)
    isnothing(sink) || isempty(strip(String(sink))) || push!(values, :sink => Symbol(sink))
    extra = _configuration_from_payload(session, get(payload, "extra", Dict()))
    append!(values, pairs(extra))
    return (; values...)
end

function _symbol_keyed_namedtuple(payload)
    payload isa AbstractDict || error("Expected an object-valued configuration payload.")
    return (; (Symbol(key) => value for (key, value) in payload)...)
end

const _OBJECT_ID_NUMERIC_TYPES = Dict{String,Type}(
    string(type) => type for type in (
        Int8, Int16, Int32, Int64, Int128, UInt8, UInt16, UInt32, UInt64,
        UInt128, BigInt, Float16, Float32, Float64,
    )
)

function _typed_object_id_value_from_payload(payload)
    payload isa AbstractDict || begin
        payload isa Union{Bool,Integer,AbstractString} && return payload
        error("Unsupported scalar value in a typed object ID.")
    end
    type = String(get(payload, "type", ""))
    type == "Symbol" && return Symbol(payload["value"])
    type == "Char" && return only(String(payload["value"]))
    type == "Tuple" && return Tuple(_typed_object_id_value_from_payload(item) for item in payload["items"])
    type == "NamedTuple" && return NamedTuple{Tuple(Symbol.(payload["names"]))}(
        Tuple(_typed_object_id_value_from_payload(item) for item in payload["items"]),
    )
    type == "Pair" && return _typed_object_id_value_from_payload(payload["first"]) =>
        _typed_object_id_value_from_payload(payload["second"])
    type == "ObjectId" && return PlantSimEngine.ObjectId(_typed_object_id_value_from_payload(payload["value"]))
    if haskey(_OBJECT_ID_NUMERIC_TYPES, type)
        return parse(_OBJECT_ID_NUMERIC_TYPES[type], String(payload["value"]))
    end
    type == "Opaque" && error(
        "The graph editor can display custom object IDs of type `$(payload["juliaType"])`, ",
        "but cannot reconstruct them. Edit this object from Julia.",
    )
    error("Unsupported typed object ID `$(type)`.")
end

function _object_id_from_payload(payload)
    if payload isa AbstractDict
        get(payload, "type", nothing) == "ObjectId" || error("Expected a tagged ObjectId payload.")
        return PlantSimEngine.ObjectId(_typed_object_id_value_from_payload(payload["value"]))
    end
    payload isa Union{Bool,Integer,AbstractString} || error("Expected a scalar object ID or a tagged ObjectId payload.")
    return PlantSimEngine.ObjectId(payload)
end

_optional_object_id_from_payload(payload) = isnothing(payload) ? nothing : _object_id_from_payload(payload)

function _metadata_from_payload(payload)
    payload isa AbstractDict || error("Expected an object metadata payload.")
    return (; (
        Symbol(key) => (value isa AbstractString && isempty(strip(value)) ? nothing :
            Symbol(key) == :parent ? _optional_object_id_from_payload(value) : value)
        for (key, value) in payload
    )...)
end

function _configuration_from_payload(session, payload)
    isnothing(payload) && return nothing
    payload isa AbstractDict || return payload
    values = Pair{Symbol,Any}[]
    for (key, value) in payload
        parsed = if value isa AbstractDict && haskey(value, "type") && haskey(value, "value")
            _parameter_value(session, value)
        elseif value isa AbstractDict
            _configuration_from_payload(session, value)
        elseif value isa AbstractVector
            [_configuration_from_payload(session, item) for item in value]
        else
            value
        end
        push!(values, Symbol(key) => parsed)
    end
    return (; values...)
end

function _updates_from_payload(application, payload)
    payload isa AbstractVector || error("Update ordering must be an array.")
    prefix = application.scope == :template ? string(application.instance, "__") : ""
    return Tuple(
        PlantSimEngine.Updates(
            Symbol.(get(item, "variables", Any[]))...;
            after=Symbol[
                Symbol(
                    !isempty(prefix) && startswith(String(value), prefix) ?
                    chopprefix(String(value), prefix) : String(value),
                )
                for value in get(item, "after", Any[])
            ],
        )
        for item in payload
    )
end

function _object_from_command(session, command)
    configuration = get(command, "configuration", Dict())
    status_payload = get(command, "status", Dict())
    status = if isempty(status_payload)
        nothing
    else
        PlantSimEngine.Status((; (
            Symbol(name) => _parameter_value(session, value)
            for (name, value) in status_payload
        )...))
    end
    return PlantSimEngine.Object(
        _object_id_from_payload(command["objectId"]);
        scale=get(configuration, "scale", nothing),
        kind=get(configuration, "kind", nothing),
        species=get(configuration, "species", nothing),
        name=get(configuration, "name", nothing),
        parent=_optional_object_id_from_payload(get(configuration, "parent", nothing)),
        status=status,
    )
end

function _update_application_edit(session, command)
    application = _application_ref_from_command(command)
    model = _construct_model(session, command["modelType"], get(command, "parameters", Dict()))
    return PlantSimEngine.GraphEditor.UpdateModelApplication(
        application,
        model,
        Symbol(get(command, "name", string(application.application_id))),
        _selector_for_application(session, application, command["selector"]),
        _period_from_payload(get(command, "cadence", nothing)),
    )
end

function _add_application_edit(session, command)
    model = _construct_model(session, command["modelType"], get(command, "parameters", Dict()))
    name = Symbol(command["name"])
    selector = _selector_from_payload(command["selector"])
    cadence = _period_from_payload(get(command, "cadence", nothing))
    spec = PlantSimEngine.ModelSpec(model;
        name=name,
        on=selector,
        every=cadence,)
    return PlantSimEngine.GraphEditor.AddModelApplication(spec)
end

function _resolve_model_type(label)
    text = String(label)
    for model_type in PlantSimEngine.Authoring.available_models()
        text in (string(model_type), string(nameof(model_type))) && return model_type
    end
    error("No loaded model type matches `$(text)`. Load the defining package with `using PackageName` first.")
end

function _construct_model(session, label, parameters)
    model_type = _resolve_model_type(label)
    description = PlantSimEngine.Authoring.describe_model(model_type)
    fields = description.constructor["fields"]
    isempty(fields) && return model_type()
    default_instance = try
        model_type()
    catch
        nothing
    end
    values = Any[]
    for field in fields
        name = field["name"]
        if haskey(parameters, name)
            push!(values, _parameter_value(session, parameters[name]))
        elseif !isnothing(default_instance)
            push!(values, getfield(default_instance, Symbol(name)))
        else
            error("Missing constructor parameter `$(name)` for model `$(model_type)`.")
        end
    end
    return model_type(values...)
end

function _parameter_value(session, payload)
    payload isa AbstractDict || return payload
    choice = Symbol(get(payload, "type", "julia"))
    raw = get(payload, "value", nothing)
    choice == :float && return parse(Float64, string(raw))
    choice == :integer && return parse(Int, string(raw))
    choice == :boolean && return parse(Bool, string(raw))
    choice == :symbol && return Symbol(raw)
    choice == :string && return String(raw)
    choice == :nothing && return nothing
    choice == :julia && session.allow_julia_eval || choice != :julia || error(
        "Raw Julia parameter values are disabled for this session.",
    )
    choice == :julia && return Core.eval(Main, Meta.parse(String(raw)))
    return raw
end

function _selector_from_payload(payload)
    payload isa AbstractDict || error("A selector payload must be an object.")
    multiplicity = Symbol(get(payload, "multiplicity", "many"))
    criteria = get(payload, "criteria", Dict())
    selectors = PlantSimEngine.AbstractObjectSelector[
        _selector_atom_from_payload(value)
        for value in get(criteria, "selectors", Any[])
    ]
    keyword_pairs = Pair{Symbol,Any}[]
    for (key, value) in criteria
        key == "selectors" && continue
        value === nothing && continue
        push!(keyword_pairs, Symbol(key) => _selector_value(Symbol(key), value))
    end
    keywords = (; keyword_pairs...)
    multiplicity == :one && return PlantSimEngine.One(selectors...; keywords...)
    multiplicity == :optional_one && return PlantSimEngine.OptionalOne(selectors...; keywords...)
    multiplicity == :many && return PlantSimEngine.Many(selectors...; keywords...)
    error("Unsupported selector multiplicity `$(multiplicity)`.")
end

function _selector_value(key, value)
    key == :id && return value isa AbstractVector ?
        Tuple(_object_id_from_payload(id) for id in value) : _object_id_from_payload(value)
    key in (:scale, :kind, :species, :process, :var, :relation, :application) &&
        return value isa AbstractVector ? Symbol.(value) : Symbol(value)
    key == :within && return _selector_atom_from_payload(value)
    key == :policy && return _policy_from_payload(value)
    key == :window && return _period_from_payload(value)
    return value
end

function _selector_atom_from_payload(payload)
    payload isa AbstractDict || error("A structured object selector must be an object.")
    type = String(get(payload, "type", ""))
    type == "SceneScope" && return PlantSimEngine.SceneScope()
    type == "Self" && return PlantSimEngine.Self()
    type == "Subtree" && return PlantSimEngine.Subtree()
    type == "SelfPlant" && return PlantSimEngine.SelfPlant()
    type == "Ancestor" && return PlantSimEngine.Ancestor(; scale=get(payload, "scale", nothing))
    if type == "Scope"
        return haskey(payload, "id") ?
            PlantSimEngine.Scope(_object_id_from_payload(payload["id"])) :
            PlantSimEngine.Scope(payload["name"])
    end
    type == "Relation" && return PlantSimEngine.Relation(payload["relation"])
    error("Unsupported structured object selector type `$(type)`.")
end

function _policy_from_payload(payload)
    payload isa AbstractDict || error("A temporal policy must be a structured object.")
    type = String(get(payload, "type", ""))
    type == "PreviousTimeStep" && return PlantSimEngine.PreviousTimeStep(
        Symbol(payload["variable"]),
        Symbol(get(payload, "process", "unknown")),
    )
    type == "HoldLast" && return PlantSimEngine.HoldLast()
    type == "Interpolate" && return PlantSimEngine.Interpolate(
        ;
        mode=Symbol(get(payload, "mode", "linear")),
        extrapolation=Symbol(get(payload, "extrapolation", "linear")),
    )
    type == "Integrate" && return PlantSimEngine.Integrate()
    type == "Aggregate" && return PlantSimEngine.Aggregate()
    error("Unsupported temporal policy type `$(type)`.")
end

function _period_from_payload(payload)
    isnothing(payload) && return nothing
    payload isa AbstractDict || error("A cadence or window payload must be an object.")
    mode = String(get(payload, "mode", "default"))
    mode == "default" && return nothing
    mode == "period" || error("Unsupported cadence/window mode `$(mode)`.")
    value = parse(Int, string(payload["value"]))
    value > 0 || error("Cadence/window values must be positive.")
    unit = String(payload["unit"])
    constructors = Dict(
        "Second" => Dates.Second,
        "Minute" => Dates.Minute,
        "Hour" => Dates.Hour,
        "Day" => Dates.Day,
    )
    haskey(constructors, unit) || error(
        "Unsupported period unit `$(unit)`. Use Second, Minute, Hour, or Day.",
    )
    return constructors[unit](value)
end

function _state_payload(session; ok=true, diagnostics=String[])
    graph = JSON.parse(PlantSimEngine.GraphEditor.model_graph_view_json(
        session.model;
        templates=session.templates,
        environments=session.environments,
    ))
    return Dict{String,Any}(
        "ok" => ok,
        "diagnostics" => diagnostics,
        "graph" => graph,
        "canUndo" => !isempty(session.history),
        "canRedo" => !isempty(session.future),
        "url" => session.url,
        "modelCode" => PlantSimEngine.Authoring.scenario_source(
            session.model;
            environments=session.environments,
        ),
        "autosavePath" => session.autosave_path,
        "savePath" => session.save_path,
        "recentPaths" => session.recent_paths,
    )
end

function _remember_path!(session, path)
    normalized = _normalized_path(path)
    filter!(!=(normalized), session.recent_paths)
    pushfirst!(session.recent_paths, normalized)
    length(session.recent_paths) > 12 && resize!(session.recent_paths, 12)
    _persist_recent_paths!(session.recent_paths)
    return normalized
end

function _recent_paths_file()
    return joinpath(tempdir(), "PlantSimEngineGraphEditor", "recent-models.json")
end

function _load_recent_paths()
    path = _recent_paths_file()
    isfile(path) || return String[]
    try
        values = JSON.parse(read(path, String))
        values isa AbstractVector || return String[]
        return String[_normalized_path(value) for value in values if value isa AbstractString]
    catch
        return String[]
    end
end

function _persist_recent_paths!(paths)
    path = _recent_paths_file()
    mkpath(dirname(path))
    _atomic_write(path, JSON.json(collect(paths)))
    return path
end

function _load_model_file(path; allow_julia_eval::Bool, environments=Dict{Symbol,Any}())
    allow_julia_eval || error("Opening Julia Composite model files is disabled for this editor session.")
    isfile(path) || error("Composite model file `$(path)` does not exist.")
    source = read(path, String)
    required_match = match(
        r"(?m)^# Requires `scenario_environments` with named values: ([^.]+)\.$",
        source,
    )
    if !isnothing(required_match)
        required = Set(Symbol(strip(name)) for name in split(required_match.captures[1], ','))
        missing = sort!(collect(setdiff(required, Set(keys(environments)))); by=string)
        isempty(missing) || error(
            "Composite model file `$(path)` requires environment catalog keys $(missing).",
        )
    end
    module_name = Symbol("PlantSimEngineGraphRecovery_", string(time_ns(); base=16))
    workspace = Module(module_name)
    Core.eval(workspace, :(using PlantSimEngine))
    environment_values = (; (
        name => value for (name, value) in sort!(collect(environments); by=first)
    )...)
    Core.eval(workspace, :(scenario_environments = $environment_values))
    included = Base.include(workspace, path)
    model = isdefined(workspace, :model) ? getfield(workspace, :model) : included
    model isa PlantSimEngine.CompositeModel || error(
        "Composite model file `$(path)` must assign its final PlantSimEngine.CompositeModel to `model`.",
    )
    return model
end

_state_json(session) = JSON.json(_state_payload(session))

function _editor_html(session)
    view = PlantSimEngine.GraphEditor.model_graph_view(
        session.model;
        templates=session.templates,
        environments=session.environments,
    )
    html = PlantSimEngine.GraphEditor.model_graph_view_html(view)
    config = replace(JSON.json(Dict("websocketUrl" => _websocket_url(session))), "</" => "<\\/")
    script = "<script type=\"application/json\" id=\"pse-editor-config\">$(config)</script>"
    return replace(html, "</head>" => "$(script)</head>")
end

function _persist_model!(session)
    code = PlantSimEngine.Authoring.scenario_source(
        session.model;
        environments=session.environments,
    ) * "\n"
    isnothing(session.autosave_path) || _atomic_write(session.autosave_path, code)
    isnothing(session.save_path) || _atomic_write(session.save_path, code)
    return nothing
end

function _atomic_write(path, content)
    path = _normalized_path(path)
    mkpath(dirname(path))
    temporary = tempname(dirname(path))
    try
        write(temporary, content)
        mv(temporary, path; force=true)
    finally
        isfile(temporary) && rm(temporary; force=true)
    end
    return path
end

_normalized_path(path) = isabspath(String(path)) ? normpath(String(path)) : normpath(joinpath(pwd(), String(path)))

function _default_autosave_path()
    return joinpath(
        tempdir(),
        "PlantSimEngineGraphEditor",
        string("session-", time_ns()),
        "model.autosave.jl",
    )
end

function _open_in_default_browser(url)
    try
        if Sys.isapple()
            run(`open $url`)
        elseif Sys.iswindows()
            run(`cmd /c start "" $url`)
        elseif !isnothing(Sys.which("xdg-open"))
            run(`xdg-open $url`)
        else
            @warn "Could not locate a default-browser command." url
            return false
        end
        return true
    catch err
        @warn "Could not open the graph editor automatically." url exception=(err, catch_backtrace())
        return false
    end
end

end
