# using PlantSimEngine, PlantMeteo # Import the necessary packages, PlantMeteo is used for the meteorology

PlantSimEngine.@process "leaf_surface" verbose = false

"""
    ToyLeafSurfaceModel(SLA)

Computes the individual leaf surface from its biomass using the SLA.

# Arguments

- `SLA`: the specific leaf area, usually in **m² gC⁻¹**. Should be understood as the surface area of a leaf per unit of carbon biomass.
Values typically range from 0.002 to 0.027 m² gC⁻¹.

# Inputs

- `carbon_biomass`: the carbon biomass of the leaf, usually in gC

# Outputs

- `surface`: the leaf surface, usually in m²

"""
struct ToyLeafSurfaceModel{T} <: AbstractLeaf_SurfaceModel
    SLA::T
end

# Define inputs:
function PlantSimEngine.inputs_(::ToyLeafSurfaceModel)
    (carbon_biomass=Required(Real),)
end

# Define outputs:
function PlantSimEngine.outputs_(model::ToyLeafSurfaceModel)
    (surface=oftype(float(model.SLA), -Inf),)
end

function PlantSimEngine.run!(m::ToyLeafSurfaceModel, status, environment, constants, context)
    status.surface = status.carbon_biomass * m.SLA
end

# Can be parallelized over organs and time-steps:



# At plant scale:
"""
    ToyPlantLeafSurfaceModel()

Computes the leaf surface at plant scale by summing the individual leaf surfaces.

# Inputs

- `leaf_surfaces`: a vector of leaf surfaces, usually in m²

# Outputs

- `surface`: the leaf surface at plant scale, usually in m²

"""
struct ToyPlantLeafSurfaceModel <: AbstractLeaf_SurfaceModel end

# Define inputs:
function PlantSimEngine.inputs_(::ToyPlantLeafSurfaceModel)
    (leaf_surfaces=Required(AbstractVector{<:Real}),)
end

# Define outputs:
function PlantSimEngine.outputs_(::ToyPlantLeafSurfaceModel)
    (surface=-Inf,)
end

function PlantSimEngine.run!(m::ToyPlantLeafSurfaceModel, status, environment, constants, context)
    status.surface = sum(status.leaf_surfaces)
end
