# Independent warm direct-planner audit

Inspected `results/direct-planner/warm-small.json` and its CPU monitor, plus persisted PB/XP, synthetic boundary and direct adversarial correctness records. This audit used Python/source inspection only; no Julia ran here. Cold measurements and upcoming growth profiles are outside this finding.

## Qualification

- Four balanced forward/reverse cycles per package: 24 PB samples (six arms), 20 XP samples (five arms), one independent scenario per sample. Warmups are separate. All same-package recorded digests, full stored snapshots and work records agree, including copied scientific RNG next draws. PB executes 32 objects ×128 steps; XP executes four days, adds 12 objects, ends with 20 and retains34 temporal/output streams despite outputs=:none.
- Recomputed within-cycle medians reproduce every published execution/complete ratio. Normal execution has no profiling/performance instrumentation. Timed child/root counters are missing by design; actual entered driver batches are reported instead.
- CPU monitor reports qualified=true with no observed other busy Julia process (threshold5%, sampled about every5seconds). This bounded monitor is not proof against every brief or non-Julia competing task.
- All PB measured phases have zero compilation/recompilation/GC. XP has one 126.875 µs compilation event in selected-driver preparation, cycle 1; all other XP measured phases have zero compilation/recompilation/GC. Do not describe the whole screen as entirely JIT-free.
- Both package provenance manifests list 140 source files; every recorded hash matches the current file. No source drift found. Reachable retained size was not measured (`retained=null`); process lifetime high-water RSS is not a per-case memory comparison.
- Persisted correctness files are passed: PB 44, XP 40, synthetic 247, direct adversarial 243 targeted assertions (574 total). These are targeted gates, not a completed full PSE suite.

## Paired timing evidence

| Package / arm | Execution median | Paired execution ratio (range; wins/4) | Complete median | Paired complete ratio (wins/4) |
|---|---:|---:|---:|---:|
| pb / bounded_preparation | 4.067 ms | 0.9866 (0.9471–1.0257; 2/4) | 8.592 ms | 1.0333 (0/4) |
| pb / planner_boundaries | 4.002 ms | 0.9669 (0.9334–0.9986; 4/4) | 8.407 ms | 0.9984 (2/4) |
| pb / selected_driver | 2.784 ms | 0.6718 (0.6428–0.6873; 4/4) | 8.909 ms | 1.0661 (0/4) |
| pb / combined | 2.860 ms | 0.6834 (0.6437–0.7202; 4/4) | 9.121 ms | 1.0886 (0/4) |
| pb / prior_typed | 2.803 ms | 0.6906 (0.6432–0.6935; 4/4) | 9.113 ms | 1.0719 (0/4) |
| xp / bounded_preparation | 13.576 ms | 0.9211 (0.9002–0.9564; 4/4) | 36.004 ms | 0.9707 (3/4) |
| xp / planner_boundaries | 15.008 ms | 1.0314 (0.9531–1.0868; 1/4) | 37.168 ms | 1.0005 (2/4) |
| xp / selected_driver | 14.972 ms | 0.9994 (0.9641–1.0717; 2/4) | 37.092 ms | 0.9956 (2/4) |
| xp / combined | 14.941 ms | 1.0187 (0.9438–1.0408; 1/4) | 37.433 ms | 1.0075 (2/4) |

PB ordinary medians are 4.168 ms execution /8.475 ms complete. XP ordinary medians are 15.078 ms /37.582 ms. Ratios are medians of matched cycle ratios, not ratios of independent medians.

## Interpretation

The selected direct plan preserves the existing PB numerical gain: about 33% lower execution time in every pair, with actual 128 selected batch entries, 32 prepared rows and zero fallback. It creates no Shared fallback frames, rich targets or public wrappers in this workload. Execution allocation is 114,784 bytes versus 1,487,040 ordinary (92.3% less), and versus 190,560 prior typed (39.8% less). Prepared row count is not presented as observed root/child work.

Compared directly with prior typed execution, selected has median paired execution ratio 0.9836 (range 0.9694–0.9994; 4/4 wins); complete ratio 0.9821 (range 0.9416–1.0286; 2/4 wins). This is a small incremental timing difference, not evidence of a large new speedup. Complete allocations fall only about 1.15% relative to prior typed. Both typed arms remain slower than ordinary for this 128-step complete task: selected 1.0661 and prior 1.0719, with 0/4 complete wins each. Selected preparation allocates 10.032 MB versus 2.984 MB ordinary, and total allocation remains 2.20× ordinary. Avoid claiming that removing fallback-frame construction has solved preparation cost.

Planner boundaries add no convincing warm benefit or synergy: PB combined is 1.0283 execution and 1.0239 complete relative to selected (only 1/4 wins each). Planner-only PB has a small execution signal but complete is essentially unchanged, and the planner changes no numerical kernel path. Cold data is required for its intended compilation hypothesis.

XP selected and combined prepare and execute zero selected driver batches: 39 ordinary targets/batches are prepared instead. Their paired ratios are near 1 with mixed wins, so no XP numerical-driver benefit is demonstrated. The independent bounded-container anchor has 0.9211 execution (4/4 wins) and 0.9707 complete (3/4 wins), plus strong allocation reduction: execution 12.204→7.028 MB, complete 24.304→13.613 MB. This is a promising bounded-metadata signal from a small warm screen, not a benefit of direct construction or the new inference boundaries.

All arms share the new cold dispatch trampolines; ordinary specialized bodies remain the same shared source. This is an internally fair same-source factorial, but it must not be compared with earlier ordinary cold seconds as if the source baseline were unchanged. Warm screen forcing file I/O is outside samples, while fresh model/RNG/state construction and forcing copies are timed. The separate cold runner includes forcing setup in construction, so do not compare absolute phase scopes without that qualifier.
