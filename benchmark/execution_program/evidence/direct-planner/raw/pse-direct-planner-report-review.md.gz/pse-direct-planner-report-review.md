# Independent main-report review

Reviewed `benchmark/execution_program/direct_planner.md` (SHA256 `35c5ba555c9b7296778bc5bf227bc5ddd8a3d0af3ead870269c02e09d31d9692`) and the index paragraph against frozen warm/cold records, qualifications, bridge source and previous independent audits. No Julia or source edits were performed.

No blocking evidence or correctness overclaim found. The report accurately separates the existing roughly 30% PB gain over ordinary execution from the much smaller, inconsistent increment over prior typed execution. It distinguishes short complete-run regressions, longer-run wins, allocation volume and unmeasured retained memory. Warm paired ratios, the 11 distinct cold PID/phase values, and targeted correctness counts match the persisted data.

Same-source cold-hook scope is explicit: all arms share cold trampolines, parent-source timing is unavailable, and the common default-hook effect is not quantified. Failed parent export/import and stalled inspection attempts are not promoted to simulations. The footer now correctly says selected policies are opt-in while shared cold hooks are present in the experimental branch.

CPU adjudication is described correctly: original false RPC flags remain false; independently bounded warm screens and staged growth diagnostics qualify at monitor resolution; older contaminated embedded warm ratios remain excluded. The XP admission bridge is clearly a changed cohort, genuinely exercised, then conservatively retired at growth, with no whole-run gain. The repository bridge/check files exactly match the source hashes recorded for the private files used in that cohort.

Growth wording stays within the observations: inclusive categories overlap, ordinary diagnostics include JIT, instrumented phase timers nest, and the XP fan-out counts do not prove unnecessary work. The generic result is properly limited to delta-sized refresh on that supported path, not arbitrary or million-organ scaling. The proposed next sub-attribution is appropriately a next experiment.

Two minor editorial refinements before archive:

1. The opening “Direct construction is a small improvement over the previous typed call driver” is slightly stronger than the later long-case evidence (only two of four direct/prior timing wins). Prefer “Direct construction reduces allocations and preserves the previous typed driver's benefit; its incremental timing difference is small.” The body already gives the correct limitation.
2. XP cold complete reduction is 28.352388%, so standard one-decimal rounding is **28.4%**, or simply “about 28%”, rather than 28.3%. This does not change the interpretation of a single-observation screen.
