using PlantSimEngine, Test
include(joinpath(pwd(), "benchmark/native_downstream/load_direct_planner_experiment.jl"))
gate_reports = Any[]
gate_tests = @testset "PB original kernels selected plan and planner smoke" begin
    for arm in (:selected_driver, :combined, :planner_boundaries, :bounded_preparation)
        @info "Small PB correctness gate" arm
        push!(gate_reports, Base.invokelatest(DirectPlannerMeasurements.direct_planner_checks,
            :pb; arm, nobjects=2, steps=2))
    end
end
open(pse_direct_expected, "w") do io
    PlantSimEngine.JSON.print(io, (; passed=true, process_id=getpid(),
        test_counts=repr(Test.get_test_counts(gate_tests)), reports=gate_reports,
        provenance=NativeDownstreamMeasurements.process_provenance(
            packages=(PlantSimEngine, PlantBiophysics, XPalm, PlantGeom))), 2)
end
