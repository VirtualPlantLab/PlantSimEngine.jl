direct_parent_export_root="/private/tmp/pse-direct-parent-fd49-qtb_uhmf";
direct_parent_repo_root="/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine";
direct_parent_revision="fd49eaf66cfc2cbaf89f01f8d520e6beaa13b6c5";
direct_parent_kind=:pb;
direct_parent_freshness=(new_process=true,pid=getpid(),no_prior_case_execution=true,no_prior_ir_probe=true,method=:new_Kaimon_worker);
direct_parent_output_path=pse_direct_expected;
direct_parent_expected_digest="9873e4f2ce520fc45e6a5759a5733be150c26b83e7124e8a4fdb8d42b1a1ce76";
include("/private/tmp/pse_direct_parent_cold.jl")
