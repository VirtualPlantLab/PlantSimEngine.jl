using PlantSimEngine, Test
include(joinpath(pwd(), "benchmark/native_downstream/bounded_preparation.jl"))
include(joinpath(pwd(), "benchmark/native_downstream/bounded_preparation_checks.jl"))
include(joinpath(pwd(), "benchmark/native_downstream/planner_boundaries.jl"))
smoke_reports = Any[]
@testset "Initial independent cold planner boundary smoke" begin
    for use_bounded in (false, true)
        left = BoundedPreparationChecks.bounded_width_fixture(; nmodels=4, nobjects=2)
        right = BoundedPreparationChecks.bounded_width_fixture(; nmodels=4, nobjects=2)
        PlannerBoundaries.enable_planner_boundaries!(right)
        use_bounded && BoundedPreparation.enable_bounded_preparation!(right)
        reference = run!(left; steps=0, outputs=:all)
        candidate = run!(right; steps=0, outputs=:all)
        @test isequal(BoundedPreparationChecks._snapshot(reference), BoundedPreparationChecks._snapshot(candidate))
        for _ in 1:2
            step!(reference); step!(candidate)
            @test isequal(BoundedPreparationChecks._snapshot(reference), BoundedPreparationChecks._snapshot(candidate))
        end
        r = PlannerBoundaries.planner_boundary_report(candidate)
        @test r.enabled
        @test r.scene_entries == r.application_assemblies == r.scenario_assemblies == 1
        @test PlannerBoundaries.planner_boundary_report(reference).scene_entries == 0
        push!(smoke_reports, (; bounded_containers=use_bounded, boundary=r))
    end
end
open(pse_direct_expected, "w") do io
    PlantSimEngine.JSON.print(io, (; passed=true, process_id=getpid(),
        source=pathof(PlantSimEngine), project=Base.active_project(), reports=smoke_reports), 2)
end
