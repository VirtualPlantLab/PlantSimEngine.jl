import argparse, json, subprocess, sys
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('kind', choices=('pb', 'xp'))
p.add_argument('--arms', nargs='+')
a = p.parse_args()
root = Path('/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine')
out = root / 'benchmark/native_downstream/results/direct-planner'
arms = a.arms or ['reference_executor', 'bounded_preparation', 'planner_boundaries',
                 'selected_driver', 'combined']
for arm in arms:
    label = f'cold-{a.kind}-{arm}'
    target = out / (label + '.json')
    if target.exists():
        raise RuntimeError('Preserve previous record before retry: ' + str(target))
    script = Path('/private/tmp') / (label + '.jl')
    script.write_text('direct_case_kind=:' + a.kind + '; direct_case_arm=:' + arm + ';\n'
        'direct_case_freshness=(new_process=true,pid=getpid(),no_prior_case_execution=true,'
        'no_prior_ir_probe=true,method=:new_Kaimon_worker);\n'
        'direct_case_output_path=pse_direct_expected;\n'
        'include(joinpath(pwd(),"benchmark/native_downstream/direct_planner_cold_case.jl"))\n')
    for attempt in range(1, 4):
        run = subprocess.run([sys.executable, '/private/tmp/pse_direct_run.py',
            label + '-attempt' + str(attempt), str(script), str(target), '--budget', '360', '--timing'])
        if run.returncode == 0:
            break
        if target.exists():
            raise RuntimeError('Failed attempt produced a record; inspect before continuing')
        print(json.dumps({'stage': 'retrying_fresh_worker', 'kind': a.kind,
                          'arm': arm, 'attempt': attempt}), flush=True)
    else:
        raise RuntimeError('Three attempts failed; inspect setup/measurement failure')
    record = json.loads(target.read_text())['record']
    prior = []
    for f in out.glob('cold-*.json'):
        if 'unqualified' in f.name or f == target:
            continue
        data = json.loads(f.read_text())
        if 'record' in data:
            prior.append(data['record'])
    if any(x['pid'] == record['pid'] for x in prior):
        raise RuntimeError('Cold PID reused')
    same_kind = [x for x in prior if x['config']['kind'] == a.kind]
    if same_kind and record['digest'] != same_kind[0]['digest']:
        raise RuntimeError('Cold scientific digest differs')
    print(json.dumps({'stage': 'cold_arm_completed', 'kind': a.kind, 'arm': arm,
        'pid': record['pid'], 'complete_seconds': record['complete_seconds'],
        'phases': {k: v['seconds'] for k, v in record['phases'].items()},
        'digest': record['digest']}), flush=True)
