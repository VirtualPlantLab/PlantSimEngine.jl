using PlantSimEngine, Test
include(joinpath(pwd(), "benchmark/native_downstream/load_direct_planner_experiment.jl"))
gate_reports = Any[]
gate_tests = @testset "XP original kernels growth independent and combined prototypes" begin
    for arm in (:selected_driver, :planner_boundaries, :combined, :bounded_preparation)
        @info "Small XP correctness gate" arm
        push!(gate_reports, Base.invokelatest(DirectPlannerMeasurements.direct_planner_checks,
            :xp; arm, steps=2))
    end
end
open(pse_direct_expected, "w") do io
    PlantSimEngine.JSON.print(io, (; passed=true, process_id=getpid(),
        test_counts=repr(Test.get_test_counts(gate_tests)), reports=gate_reports,
        provenance=NativeDownstreamMeasurements.process_provenance(
            packages=(PlantSimEngine, PlantBiophysics, XPalm, PlantGeom))), 2)
end
