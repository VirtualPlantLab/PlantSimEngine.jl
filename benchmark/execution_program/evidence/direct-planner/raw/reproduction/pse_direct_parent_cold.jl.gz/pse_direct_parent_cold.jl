# Kaimon-controlled parent-source attribution run. The controller first exports
# the tracked parent Project/src/ext byte-for-byte, then pushfirst!s that project
# onto LOAD_PATH BEFORE loading PlantSimEngine. This helper changes no sources.
for name in (:direct_parent_export_root, :direct_parent_repo_root,
    :direct_parent_revision, :direct_parent_kind, :direct_parent_freshness,
    :direct_parent_output_path)
    isdefined(Main, name) || error("Missing parent cold configuration: $name")
end
abspath(first(LOAD_PATH)) == abspath(direct_parent_export_root) ||
    error("Put the parent export first on LOAD_PATH before loading PlantSimEngine")
direct_parent_kind in (:pb, :xp) || error("Use the tiny PB or XP attribution case")
direct_parent_freshness.new_process && direct_parent_freshness.pid == getpid() &&
    direct_parent_freshness.no_prior_case_execution &&
    direct_parent_freshness.no_prior_ir_probe || error("Use one fresh Kaimon worker per parent arm")
hasproperty(direct_parent_freshness, :previous_pid) &&
    direct_parent_freshness.previous_pid == getpid() && error("Parent worker reused the previous PID")

using PlantSimEngine
realpath(pkgdir(PlantSimEngine)) == realpath(direct_parent_export_root) ||
    error("PlantSimEngine was loaded from another project")
realpath(Base.pathof(PlantSimEngine)) == realpath(joinpath(direct_parent_export_root,
    "src", "PlantSimEngine.jl")) || error("Unexpected loaded parent PlantSimEngine source")
isdefined(PlantSimEngine, :_ColdPlannerBoundaryPolicy) &&
    error("The parent attribution source already contains the new cold trampolines")
isdefined(Main, :PlannerBoundaries) && error("Do not load PlannerBoundaries into the parent worker")
isdefined(Main, :DirectPlannerMeasurements) && error("Load one parent case in a fresh worker")

# Same definition loader as the current factorial, except the absent new policy.
# These definitions execute no scientific kernels and are charged outside the
# measured case through the same experimental-module loader field.
let started = time_ns(), native = joinpath(direct_parent_repo_root, "benchmark", "native_downstream")
    include(joinpath(native, "load_experiments.jl"))
    for (name, file) in (
        (:LeanNativeCompiler, "lean_compiler.jl"),
        (:DirectCallCompiler, "direct_calls.jl"),
        (:SharedCallProgram, "shared_call_program.jl"),
        (:TightCallProgram, "tight_call_program.jl"),
        (:BoundedPreparation, "bounded_preparation.jl"),
        (:DirectPlanConstruction, "direct_plan_construction.jl"),
        (:DirectPlannerFixtures, "direct_planner_fixtures.jl"),
        (:DirectPlannerMeasurements, "direct_planner_measurements.jl"),
        (:DirectPlannerGrowthProfile, "direct_planner_growth_profile.jl"),
    )
        isdefined(Main, name) || include(joinpath(native, file))
    end
    global direct_parent_loader_seconds = (time_ns() - started) / 1e9
end

Base.@nospecializeinfer @noinline function _run_direct_parent_case(kind::Symbol,
    freshness, output_path; expected_digest=nothing)
    DPM = Main.DirectPlannerMeasurements
    F = Main.DirectPlannerFixtures
    CR = Main.CompiledRegionsExperiment
    PSE = Main.PlantSimEngine
    arm = :reference_executor
    iszero(DPM.COLD_COUNT[]) || error("One cold case per fresh parent worker")
    DPM.COLD_COUNT[] += 1
    policy = DPM.policies(arm)
    config = merge(DPM.construct_config(kind; steps=2, nobjects=2, additions=3,
        seed=1, emission_speed=0.2, outputs=:none), (policies=policy,))
    phases = Dict{Symbol,Any}()
    DPM._stage(output_path * ".pid$(getpid()).stages.tsv", kind, arm, "before_construction")
    measured = DPM._timed(F.construct_fixture, kind, config)
    fixture = measured.value
    phases[:construction] = DPM._phase(measured)
    DPM._stage(output_path * ".pid$(getpid()).stages.tsv", kind, arm, "after_construction")
    DPM._stage(output_path * ".pid$(getpid()).stages.tsv", kind, arm, "before_preparation")
    measured = DPM._timed(DPM.prepare_arm, fixture.model, arm; outputs=:none)
    simulation = measured.value
    phases[:preparation] = DPM._phase(measured)
    DPM._stage(output_path * ".pid$(getpid()).stages.tsv", kind, arm, "after_preparation")
    DPM._stage(output_path * ".pid$(getpid()).stages.tsv", kind, arm, "before_first_execution")
    measured = DPM._timed(PSE.step!, simulation)
    phases[:first_execution] = DPM._phase(measured)
    DPM._stage(output_path * ".pid$(getpid()).stages.tsv", kind, arm, "after_first_execution")
    DPM._stage(output_path * ".pid$(getpid()).stages.tsv", kind, arm, "before_remaining_execution")
    measured = DPM._timed(PSE.continue!, simulation; steps=1)
    phases[:remaining_execution] = DPM._phase(measured)
    DPM._stage(output_path * ".pid$(getpid()).stages.tsv", kind, arm, "after_remaining_execution")
    DPM._stage(output_path * ".pid$(getpid()).stages.tsv", kind, arm, "before_diagnostics")
    observed = (state=Base.invokelatest(F.snapshot, simulation, kind),
        scientific_rngs=Base.invokelatest(F.scientific_rngs, simulation.model))
    digest = bytes2hex(DPM.sha256(repr(observed)))
    expected_digest === nothing || digest == expected_digest || error("Parent scientific digest differs")
    work = Base.invokelatest(CR.downstream_work_report, simulation, fixture.initial_ids)
    # The current coverage method requires PlannerBoundaries. Do not define an
    # alias/shim merely to run it against a parent that lacks those hooks.
    coverage = (available=false,
        reason=:current_factorial_coverage_requires_absent_parent_boundary_hooks,
        requested_executor=:ordinary_reference_executor,
        new_planner_boundary_counters=:unavailable_in_parent,
        selected_driver_counters=:not_requested)
    DPM._stage(output_path * ".pid$(getpid()).stages.tsv", kind, arm, "after_diagnostics")
    return (; config, arm, policies=policy, freshness, pid=getpid(), julia=string(VERSION),
        source=Base.pathof(PSE), phases,
        complete_seconds=sum(row.seconds for row in values(phases)),
        complete_allocated_bytes=sum(row.allocated_bytes for row in values(phases)),
        digest, snapshot=observed, coverage, work,
        forcing_setup=:inside_measured_construction, diagnostics=:after_execution_only,
        temperature=:first_use, source_variant=:parent_without_shared_cold_trampolines)
end

direct_parent_record = Base.invokelatest(_run_direct_parent_case,
    direct_parent_kind, direct_parent_freshness, direct_parent_output_path;
    expected_digest=isdefined(Main, :direct_parent_expected_digest) ? direct_parent_expected_digest : nothing)
direct_parent_provenance = NativeDownstreamMeasurements.process_provenance(
    packages=(PlantSimEngine, PlantBiophysics, XPalm, PlantGeom))
direct_parent_harness_sources = [(path=file,
    sha256=bytes2hex(DirectPlannerMeasurements.sha256(read(joinpath(direct_parent_repo_root,
        "benchmark", "native_downstream", file)))))
    for file in ("direct_planner_cold_case.jl", "direct_planner_fixtures.jl",
        "direct_planner_measurements.jl", "load_direct_planner_experiment.jl")]
mkpath(dirname(abspath(direct_parent_output_path)))
open(direct_parent_output_path, "w") do io
    PlantSimEngine.JSON.print(io, (
        loader_seconds=direct_parent_loader_seconds,
        loader_scope=:same_experimental_definitions_except_absent_PlannerBoundaries_module,
        record=direct_parent_record, provenance=direct_parent_provenance,
        parent_attribution=(export_root=realpath(direct_parent_export_root),
            export_revision=direct_parent_revision, loaded_source=Base.pathof(PlantSimEngine),
            shared_cold_trampolines_present=false, planner_boundaries_module_loaded=false,
            harness_sources=direct_parent_harness_sources,
            helper_sha256=bytes2hex(DirectPlannerMeasurements.sha256(read(@__FILE__))),
            interpretation=:one_parent_source_observation_not_an_additional_optimization_arm)), 2)
end
