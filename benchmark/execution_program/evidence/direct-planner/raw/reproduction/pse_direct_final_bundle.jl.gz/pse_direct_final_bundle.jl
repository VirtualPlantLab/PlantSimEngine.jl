using PlantSimEngine, Test, SHA
include(joinpath(pwd(), "benchmark/native_downstream/load_direct_planner_experiment.jl"))
bundle_reports = Any[]
pb_case = DirectPlannerMeasurements.register_direct_planner_pb_case!(
    :direct_planner_pb_long_qualified; nobjects=32, steps=2048,
    arms=(:reference_executor, :bounded_preparation, :selected_driver,
        :combined, :prior_typed, :bounded_selected, :bounded_combined))
@info "Qualified longer PB warm comparison"
pb_screen = Base.invokelatest(NativeDownstreamMeasurements.screen_case,
    pb_case; repetitions=4, measure_retained=false)
push!(bundle_reports, (; kind=:pb_long, screen=pb_screen,
    summary=NativeDownstreamMeasurements.summarize_screen(pb_screen)))

# A separate changed-admission cohort: register before every compared XP arm.
include("/private/tmp/local_ports_selected_bridge.jl")
registration = Base.invokelatest(LocalPortsSelectedBridge.register_xpalm_local_ports!)
@assert registration.registered_types == 4
include("/private/tmp/local_ports_selected_bridge_checks.jl")
bridge_checks = Any[]
bundle_tests = @testset "Optional local-port admission full XP correctness" begin
    push!(bridge_checks, Base.invokelatest(
        LocalPortsSelectedBridgeChecks.registration_rejection_checks))
    for arm in (:selected_driver, :combined)
        push!(bridge_checks, Base.invokelatest(
            LocalPortsSelectedBridgeChecks.local_ports_xp_checks; steps=2, arm))
    end
end
xp_case = DirectPlannerMeasurements.register_direct_planner_xp_case!(
    :local_ports_selected_xp_warm; steps=4,
    arms=(:reference_executor, :selected_driver, :combined,
        :bounded_preparation, :bounded_selected, :bounded_combined))
@info "Small XP changed-admission warm comparison"
xp_screen = Base.invokelatest(NativeDownstreamMeasurements.screen_case,
    xp_case; repetitions=4, measure_retained=false)
push!(bundle_reports, (; kind=:xp_local_ports, screen=xp_screen,
    summary=NativeDownstreamMeasurements.summarize_screen(xp_screen)))
open(pse_direct_expected, "w") do io
    PlantSimEngine.JSON.print(io, (; process_id=getpid(), reports=bundle_reports,
        bridge_registration=registration, bridge_checks,
        bridge_test_counts=repr(Test.get_test_counts(bundle_tests)),
        admission_sources=[(path=file, sha256=bytes2hex(sha256(read(file))))
            for file in ("/private/tmp/local_ports_selected_bridge.jl",
                "/private/tmp/local_ports_selected_bridge_checks.jl")]), 2)
end
