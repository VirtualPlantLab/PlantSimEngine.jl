using PlantSimEngine, Test
include(joinpath(pwd(), "benchmark/native_downstream/load_direct_planner_experiment.jl"))
extra_checks = Any[]
for arm in (:bounded_selected, :bounded_combined)
    push!(extra_checks, Base.invokelatest(DirectPlannerMeasurements.direct_planner_checks,
        :pb; arm, nobjects=2, steps=2))
end
long_pb_case = DirectPlannerMeasurements.register_direct_planner_pb_case!(
    :direct_planner_pb_32x2048; nobjects=32, steps=2048,
    arms=(:reference_executor, :bounded_preparation, :selected_driver, :combined,
        :prior_typed, :bounded_selected, :bounded_combined))
@info "Confirming longer PB complete-run cost"
long_pb_screen = Base.invokelatest(NativeDownstreamMeasurements.screen_case,
    long_pb_case; repetitions=4, measure_retained=false)
long_pb_report = (; kind=:pb_long, screen=long_pb_screen,
    summary=NativeDownstreamMeasurements.summarize_screen(long_pb_screen))
profile_reports = Any[]
framework_warmups = Any[]
for arm in (:reference_executor, :combined)
    @info "Warming separate instrumented XP companion" arm
    push!(framework_warmups, Base.invokelatest(
        DirectPlannerGrowthProfile.framework_growth_companion, :xp, arm; steps=4))
    @info "Sampling normal XP execution" arm
    push!(profile_reports, Base.invokelatest(
        DirectPlannerGrowthProfile.profile_growth_case, :xp, arm;
        steps=4, repetitions=10,
        progress_path=pse_direct_expected * ".stages.tsv"))
end
for arm in (:bounded_selected, :bounded_combined)
    push!(extra_checks, Base.invokelatest(DirectPlannerMeasurements.direct_planner_checks,
        :xp; arm, steps=2))
end
xp_extra_case = DirectPlannerMeasurements.register_direct_planner_xp_case!(
    :direct_planner_xp_bounded_composition; steps=4,
    arms=(:reference_executor, :bounded_preparation, :bounded_selected, :bounded_combined))
xp_extra_screen = Base.invokelatest(NativeDownstreamMeasurements.screen_case,
    xp_extra_case; repetitions=4, measure_retained=false)
xp_extra_report = (; kind=:xp_bounded_composition, screen=xp_extra_screen,
    summary=NativeDownstreamMeasurements.summarize_screen(xp_extra_screen))
generic_reports = Any[]
for nobjects in (128, 1024)
    @info "Fixed three-organ growth refresh diagnostic" nobjects
    # First invocation prepares instrumentation code; report a second fresh pair.
    Base.invokelatest(DirectPlannerGrowthProfile.generic_growth_differential;
        nobjects, additions=3)
    push!(generic_reports, Base.invokelatest(
        DirectPlannerGrowthProfile.generic_growth_differential;
        nobjects, additions=3))
end
open(pse_direct_expected, "w") do io
    PlantSimEngine.JSON.print(io, (; process_id=getpid(), reports=[long_pb_report, xp_extra_report], extra_checks, profiles=profile_reports,
        framework_warmups, generic_differentials=generic_reports,
        provenance=NativeDownstreamMeasurements.process_provenance(
            packages=(PlantSimEngine, PlantBiophysics, XPalm, PlantGeom))), 2)
end
