using PlantSimEngine, Test
include(joinpath(pwd(), "benchmark/native_downstream/bounded_preparation.jl"))
include(joinpath(pwd(), "benchmark/native_downstream/planner_boundaries.jl"))
include(joinpath(pwd(), "benchmark/native_downstream/planner_boundary_checks.jl"))
gate_reports = Any[]
gate_tests = @testset "Planner boundary synthetic and growth checks" begin
    push!(gate_reports, PlannerBoundaryChecks.planner_width_checks())
    push!(gate_reports, PlannerBoundaryChecks.planner_width_checks(; widths=(4,), outputs=(:all,), bounded=true))
    push!(gate_reports, PlannerBoundaryChecks.planner_growth_checks())
    push!(gate_reports, PlannerBoundaryChecks.planner_growth_checks(; bounded=true))
end
open(pse_direct_expected, "w") do io
    PlantSimEngine.JSON.print(io, (; passed=true, process_id=getpid(),
        test_counts=repr(Test.get_test_counts(gate_tests)), reports=gate_reports), 2)
end
