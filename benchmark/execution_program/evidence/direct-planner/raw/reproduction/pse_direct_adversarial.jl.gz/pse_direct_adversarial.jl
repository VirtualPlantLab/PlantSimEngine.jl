using PlantSimEngine, Test
include(joinpath(pwd(), "benchmark/native_downstream/load_direct_planner_experiment.jl"))
include(joinpath(pwd(), "benchmark/native_downstream/direct_plan_checks.jl"))
gate_reports = Any[]
gate_tests = @testset "Direct plan protocol and fallback correctness" begin
    push!(gate_reports, DirectPlanChecks.selected_pb_checks(;
        nobjects=2, steps=2, storage_modes=(false,), output_modes=(:none, :all),
        bounded_modes=(false, true)))
    push!(gate_reports, DirectPlanChecks.selected_exception_checks())
    push!(gate_reports, DirectPlanChecks.selected_partial_exception_checks())
    push!(gate_reports, DirectPlanChecks.selected_retirement_checks())
    push!(gate_reports, DirectPlanChecks.selected_public_fallback_checks())
    push!(gate_reports, DirectPlanChecks.selected_mixed_union_rejection_check())
end
open(pse_direct_expected, "w") do io
    PlantSimEngine.JSON.print(io, (; passed=true, process_id=getpid(),
        test_counts=repr(Test.get_test_counts(gate_tests)), reports=gate_reports), 2)
end
