using PlantSimEngine
include(joinpath(pwd(), "benchmark/native_downstream/load_direct_planner_experiment.jl"))
warm_reports = Any[]
warm_arms = (:reference_executor, :bounded_preparation, :planner_boundaries,
    :selected_driver, :combined, :prior_typed)
@info "Starting small PB balanced warm screen"
pb_case = DirectPlannerMeasurements.register_direct_planner_pb_case!(
    :direct_planner_pb_32x128; nobjects=32, steps=128, arms=warm_arms)
pb_screen = Base.invokelatest(NativeDownstreamMeasurements.screen_case,
    pb_case; repetitions=4, measure_retained=false)
push!(warm_reports, (; kind=:pb, screen=pb_screen,
    summary=NativeDownstreamMeasurements.summarize_screen(pb_screen)))
@info "Starting small XP balanced warm screen"
xp_case = DirectPlannerMeasurements.register_direct_planner_xp_case!(
    :direct_planner_xp_4days; steps=4,
    arms=(:reference_executor, :bounded_preparation, :planner_boundaries, :selected_driver, :combined))
xp_screen = Base.invokelatest(NativeDownstreamMeasurements.screen_case,
    xp_case; repetitions=4, measure_retained=false)
push!(warm_reports, (; kind=:xp, screen=xp_screen,
    summary=NativeDownstreamMeasurements.summarize_screen(xp_screen)))
open(pse_direct_expected, "w") do io
    PlantSimEngine.JSON.print(io, (; process_id=getpid(), reports=warm_reports), 2)
end
