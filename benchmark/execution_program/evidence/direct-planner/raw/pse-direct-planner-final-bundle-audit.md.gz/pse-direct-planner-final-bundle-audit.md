# Independent final-bundle adjudication

Two warm screens are qualified independently at the CPU monitor's resolution. The original `final-bundle-unqualified-cpu-20261031T125402.json` and its overall false CPU flag remain unchanged. Exact raw/CPU/script/receipt hashes, filesystem timestamp evidence, canonical config/cohort hashes, quiet-observation indices, source checks and recomputed per-cycle statistics are in `results/direct-planner/qualification_adjudication.json`.

The serial script runs PB, then the bridge correctness testset, then XP, and writes the raw artifact after both screens. Julia Test computes elapsed wall time and rounds seconds to one decimal. The reported 138.1-second bridge duration safely exceeds the conservative 137-second minimum used here.

- PB bounds: 12:56:11.704–12:56:37.967 UTC, using XP's provenance time minus that 137-second minimum. Quiet CPU observations bracket the entire possible screen at 12:56:08.435029 / 12:56:38.722658; maximum observation gap is 5.050507 seconds.
- XP bounds: 12:58:54.967–12:59:37.026597 UTC. The upper bound is the unchanged raw output file's final-write mtime, after all science and screen diagnostics. Quiet observations bracket it at 12:58:49.946169 / 12:59:40.436768; maximum gap is 5.064037 seconds. The later completed receipt corroborates completion but is not needed to extend this interval beyond monitoring.
- The sole busy observation, at 12:58:34.801043 UTC, lies between both screens during correctness work. These are sampled observations, not proof of absolute continuous CPU silence.

Both screens use four balanced forward/reverse cycles. Recorded digest, stored snapshot, scientific RNG and work equality pass across all warmups and measured samples. Recomputed paired medians match every summary. All 140 source hashes match current files. PB measured phases have zero JIT/recompilation/GC. XP has only 122.5 microseconds of preparation JIT in selected-driver cycle 2; all other measured JIT, recompilation and GC entries are zero. Retained size was not measured; lifetime high-water RSS is not a case memory metric.

| Screen / arm | Execution median | Paired execution ratio | Complete median | Paired complete ratio |
|---|---:|---:|---:|---:|
| PB ordinary | 62.099 ms | 1.0000 | 69.412 ms | 1.0000 |
| PB selected | 43.484 ms | 0.6994 | 52.549 ms | 0.7565 |
| PB combined | 43.047 ms | 0.6932 | 52.260 ms | 0.7534 |
| PB prior typed | 44.432 ms | 0.7155 | 53.559 ms | 0.7721 |
| XP ordinary | 15.506 ms | 1.0000 | 37.977 ms | 1.0000 |
| XP selected bridge | 15.881 ms | 1.0415 | 39.142 ms | 1.0398 |
| XP combined bridge | 16.003 ms | 1.0785 | 39.780 ms | 1.0663 |
| XP bounded only | 14.436 ms | 0.9644 | 36.195 ms | 0.9680 |
| XP bounded selected | 14.609 ms | 0.9715 | 37.362 ms | 0.9908 |
| XP bounded combined | 15.097 ms | 1.0088 | 38.767 ms | 1.0365 |

PB selected/combined win all four execution and complete pairs. Selected execution allocates 1.884 MB versus 23.839 MB ordinary; complete allocation is 14.542 MB versus 29.449 MB. This is allocation volume, not retained-memory evidence. The incremental benefit over prior typed is small: directly paired selected/prior ratios are 0.9847 execution and 0.9877 complete, with only two of four wins each. Combined versus selected is likewise inconsistent. The new evidence supports the longer-run typed candidate, not a large new gain from planner boundaries or deferred fallback construction.

XP is a separate changed-admission cohort: four exact, audited original local-port model types are admitted before every compared arm. The 42-assertion bridge gate passes. Separate actual-work companions observe seven selected roots; timed samples observe seven selected batch entries, while timed root/child counters are absent. Eight fallback frames materialize after growth, and selected execution is not retained through the growing scene. Therefore this bridge is genuinely exercised but supplies no whole-run runtime gain. Bounded-selected versus bounded-only is 1.0048 execution / 1.0187 complete; bounded-combined loses every pair to bounded-only. Do not credit bounded-container gains to the bridge, or compare this new admission cohort with earlier zero-coverage screens as one unchanged experiment.
