# Independent growth-profile audit

Audited `growth-profile-unqualified-cpu-20261031T122632.json`, `growth-profile-retry2-20261031T122632-cpu.json` and `growth-profile.json.stages.tsv` using Python and source inspection only. No Julia or source edits occurred in this audit.

## Qualification

The complete RPC remains CPU-unqualified. The monitor observed PID 48929 at 59.8%, 31.3% and 9.8% CPU at 12:27:02, 12:27:32 and 12:28:02 UTC. Root identifies this as the controller. All warm timing comparisons embedded in that RPC remain excluded, including the long PB and XP bounded-composition screens. This audit does not rehabilitate their ratios.

The two actual XP CPU-sampling windows have quiet adjacent observations:

| Arm | Persisted sampling window (UTC) | Nearest preceding / following monitor observations | Observation |
|---|---|---|---|
| Ordinary | 12:29:51.696–12:29:52.184 | 12:29:48.932816 / 12:29:53.975338 | Both `other_busy=[]` |
| Combined | 12:29:59.795–12:30:00.268 | 12:29:59.018582 / 12:30:04.061749 | Both `other_busy=[]` |

These brackets support interval-qualified coarse diagnostic sampling. The monitor samples about every five seconds and cannot rule out every brief or non-Julia competing task. Keep this distinction beside the overall unqualified RPC status.

Each arm profiles ten independently constructed four-day XP scenarios after a separate same-arm warmup. All ten observations, both arms, and both instrumented companions have the same complete scientific/type/history/topology/RNG digest and stored snapshots. Every sample adds 12 organs, ends with 20 objects and retains 34 streams. Combined still executes zero selected-driver batches; it is an ordinary numerical path with planner-boundary selection. All four extra bounded-composition correctness checks passed. All 140 recorded source hashes match current files.

Ordinary diagnostic execution contains 8.761 ms reported compilation and 26.857 ms GC; combined has zero compilation and 22.977 ms GC. Neither profile is a steady-state benchmark. There are no unresolved or trailing instruction pointers. Ordinary/combined retain 177/182 selected samples: enough for broad categories, not fine differences or precise percentages.

## Measured bottleneck evidence

| Inclusive category | Ordinary | Combined |
|---|---:|---:|
| Runtime refresh | 74.6% | 73.1% |
| Logical extension | 54.8% | 50.5% |
| Targeted newborn preparation | 19.2% | 20.9% |
| Execution-group refresh | 15.8% | 16.5% |
| Input preparation | 22.0% | 25.3% |

These are overlapping inclusive CPU samples, not exclusive elapsed times. Do not add the rows or infer that the small differences between arms are real improvements.

Independent instrumented framework companions give a more actionable subdivision. XP's input-binding refresh takes roughly 0.9–1.2 ms per day inside roughly 1.6–2.1 ms binding refresh. Execution-plan refresh is roughly 0.49–0.88 ms per day. Timers nest, instrumentation adds work, and targeted preparation has no separate exact timer here. Each three-organ event replaces 24 input-binding targets, constructs 26 status views, replaces 26 environment bindings and constructs 20 execution targets while reusing 17 groups. These counts establish fan-out; they do not establish that those objects are unnecessary.

## Generic fixed-delta result

At both 128 and 1,024 existing source organs, +3 growth constructs exactly three views, three environment bindings and three execution targets, reuses two groups, updates one group in place and directly appends one Many carrier with three aligned sources. Science visits 133 versus 1,029 targets; no-growth controls visit 130 versus 1,026. Independent inspection confirms all source values are Float32 1, visits equal one, and collector totals are 131/1,027 with growth and 128/1,024 without it.

Single instrumented binding-refresh observations are 0.123/0.118 ms; execution-plan refresh is 0.039/0.040 ms. These are diagnostic observations, not a scaling benchmark or a proof for arbitrary selectors/cadences/topology. They show that this supported generic path already performs delta-sized refresh work while ordinary scientific visits and the global Many reduction grow with population.

## Next narrow experiment

Prioritize XP's input-binding phase, then execution-group construction. Add a bounded attribution companion splitting selector/source resolution, carrier/canonical wiring, and defaults/required validation before choosing an implementation. A candidate could remove repeated plan interpretation or temporary allocations across the genuinely affected newborn fan-out. That is a source-based optimization hypothesis, not a measured gain.

Do not assume generic full-scene rebuilding is the remaining problem, or expand the previously slower newborn binding-capture cache without identifying a larger removable cost. Preserve fresh affected Status identities, canonical refs, ordered Many membership, temporal/initializer semantics, late distributed writer ownership and external-refresh invalidation. Benchmark any implementation independently against the current ordinary executor after inexpensive parity gates.
