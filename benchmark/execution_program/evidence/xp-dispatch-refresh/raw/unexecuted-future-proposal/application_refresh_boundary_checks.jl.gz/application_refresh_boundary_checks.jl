module ApplicationRefreshBoundaryChecks

using Dates, Test, PlantSimEngine
const PSE=PlantSimEngine
_A()=getfield(Main,:ApplicationRefreshBoundary)
_C()=getfield(Main,:GrowthInputReuseChecks)
_L()=getfield(Main,:ExecutionGroupLookupChecks)
_E()=getfield(Main,:ExecutionGroupEpochLookupChecks)
_F()=getfield(Main,:DirectPlannerFixtures)
_B()=getfield(Main,:NewbornBindingProgramChecks)
_enable!(model)=Base.invokelatest(_A().enable_application_refresh_boundary!,model)
_report(value)=Base.invokelatest(_A().application_refresh_boundary_report,value)
export application_refresh_parity_checks

"""Ordinary executor both arms; exact science/RNG/live refs/batch/schedule oracle."""
function application_refresh_parity_checks(case::Symbol=:generic;steps=nothing)
    C,L,F=_C(),_L(),_F();kind=case in (:xp,:pb) ? case : :generic
    count=steps===nothing ? (case in (:generic,:mixed_cadence) ? 4 : case in (:initializer,:distributed) ? 3 : 2) : steps
    initial_ids=nothing
    if case in (:xp,:pb)
        H=getfield(Main,:DirectPlannerMeasurements)
        config=H.construct_config(case;steps=count,nobjects=2,outputs=:all)
        a,b=F.construct_fixture(case,config),F.construct_fixture(case,config)
        left,right=a.model,b.model;initial_ids=b.initial_ids
    else
        factory=if case===:generic
            ()->_B()._rng_fixture(1)
        elseif case===:first_membership
            L._empty_fixture
        elseif case in (:initializer,:mixed_cadence)
            N=getfield(Main,:NewbornPreparationChecks)
            cadence=case===:mixed_cadence ? Hour(2) : Hour(1)
            ()->N.preparation_fixture(;source_every=cadence).model
        elseif case===:distributed
            D=getfield(Main,:NewbornDistributedChecks)
            ()->D.distributed_fixture(:from_status)
        else
            throw(ArgumentError("Unknown boundary case: $case"))
        end
        left,right=factory(),factory()
    end
    reference=PSE.run!(left;steps=0,outputs=:all)
    candidate=C._prepare(right;enable! = _enable!,outputs=:all)
    @testset "Typed application refresh preserves $case" begin
        @test !_report(reference).enabled
        @test _report(candidate).enabled
        @test _report(candidate).counters.refresh_states_created==0
        previous=C._initial_pair(reference,candidate;kind)
        for step in 1:count
            _E()._mutate!(reference.model,step,case)
            _E()._mutate!(candidate.model,step,case)
            PSE.step!(reference);PSE.step!(candidate)
            previous=L._state(reference,candidate,previous;kind)
        end
        if case in (:xp,:pb)
            CR=getfield(Main,:CompiledRegionsExperiment)
            @test CR.downstream_work_report(candidate,initial_ids)==CR.downstream_work_report(reference,initial_ids)
        end
        report=_report(candidate);c=report.counters
        @test c.application_attempts==c.applications_completed
        @test all(x->x>=0,values(c))
        if case in (:generic,:first_membership,:xp)
            @test c.refresh_states_created>0
            @test c.applications_completed>0
            @test c.targets_constructed>0
        end
        @test report.numerical_executor===:ordinary
        @test !report.scientific_values_cached && !report.defaults_cached
        @test !report.memberships_cached && !report.environment_samples_cached
        return (;passed=true,case,steps=count,report,
            oracle=:ordinary_exact_state_history_rng_refs_execution_targets_and_schedule)
    end
end

end # module
