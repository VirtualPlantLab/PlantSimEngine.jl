# Private, unapplied future prototype

Nothing in this directory is loaded by the measured checkout. No Julia has
been run for it. The patch is based on baseline.sha256 and must be reviewed and
source-manifested as a NEW cohort before application.

## Mechanism

The existing general-refresh manual-application check and old-group lookup
stay in core in the original order. One optional hook then dispatches the
complete target merge/batch body on `CompiledModelApplication{P}`. All scene,
environment, retention, constants, old-plan, staging and change-set fields are
opaque invocation-local metadata. The existing pure-addition prepass and its
success path remain unchanged. The disabled path retains the original loop.

The enabled path runs the original control-refresh, delta, reusable-group,
old-target merge, change-reason, staged-target, target-constructor, rebuild
count, batch-constructor and append calls in the same order. Three original
application-loop `continue`s and the empty-batch exit become successful helper
returns. The two inner target-scan continues stay unchanged. No schema/default,
model, status, environment or membership result is cached. Exceptions propagate
without fallback/replay after entry. A single invocation state accumulates
three Int counts; core reads one aggregate tuple after the loop, rather than
allocating an application result per call.

## Proposed integration (not performed)

1. Preserve and hash the current core/module/fixture sources.
2. Check/apply application_refresh_boundary.core.patch.
3. Include application_refresh_boundary.jl uniformly for all comparison arms.
4. Enable only candidate models with
   ApplicationRefreshBoundary.enable_application_refresh_boundary!(model).
5. Include application_refresh_boundary_checks.jl.

Initial gates:

- application_refresh_parity_checks(:first_membership)
- application_refresh_parity_checks(:generic)
- :initializer, :mixed_cadence, :distributed, then original :pb/:xp (2 steps)
- same full state, raw history, RNG, live canonical reference and carrier
  identities, execution target/batch types+IDs, and schedule as ordinary.

Before any timing also add an effectful declaration/conversion fixture and a
thrown target-construction fixture: compare the exact declaration/conversion
call trace, original exception type/message, and partially mutated refs/streams.
No completed application credit after an exception; no replay is allowed.
Retain/reuse the bounded-both-arms reorder/replacement gate for logical changes.
These adversarial gates are required and NOT yet implemented in the small
private check module.

## Coverage and falsification

The report exposes actual refresh-state creations, application attempts and
completed applications, original targets/batches constructed and groups reused.
Require positive runtime deltas in states/completions/targets on generic growth
and XP. PB with no general refresh is an explicit zero-eligibility control.
Pure-append success can bypass the new boundary; do not count it as coverage.

First compare ordinary A/A against boundary-only with identical source,
workload, fresh scene, ordinary numerical executor, and independent model RNG.
Measure warm execution and fresh-complete time, allocations, cold compilation,
and peak RSS independently. Only then combine with typed output preparation or
bounded graph metadata. This is a CPU hypothesis, not a claimed improvement:
constructors already specialize, and making the scene fields opaque could
increase dynamic dispatch enough to lose. Reject if qualified A/A noise covers
the change, or if added cold/setup cost outweighs representative runtime savings.
