module ApplicationRefreshBoundary

using PlantSimEngine
const PSE=PlantSimEngine
for name in (:_begin_model_execution_application_refresh,
    :_try_refresh_model_execution_application!, :_model_execution_application_refresh_counts)
    isdefined(PSE,name) || error("Application refresh boundary requires its opt-in core hooks")
end
export enable_application_refresh_boundary!, application_refresh_boundary_report

mutable struct BoundaryCounters
    refresh_states_created::Int
    application_attempts::Int
    applications_completed::Int
    targets_constructed::Int
    batches_constructed::Int
    groups_reused::Int
end
BoundaryCounters()=BoundaryCounters(0,0,0,0,0,0)
const _enabled=WeakKeyDict{Any,BoundaryCounters}()
function enable_application_refresh_boundary!(model::PSE.CompositeModel)
    get!(_enabled,model) do
        BoundaryCounters()
    end
    return model
end

# Invocation-local assembly only: no memberships, scientific values, defaults,
# schemas or environment samples survive this refresh. Existing output arrays
# are shared with the original core loop. Every scene-wide field stays opaque.
mutable struct RefreshState
    previous::Any
    compiled::Any
    env_bindings::Any
    temporal_streams::Any
    output_retention::Any
    constants::Any
    performance::Any
    changed_application_ids::Any
    changed_execution_target_ids::Any
    changed_targets_by_application::Any
    staged_execution_targets::Any
    force_general_changed_groups::Bool
    groups::Vector{PSE.CompiledApplicationExecutionGroup}
    batches::Vector{PSE.AbstractExecutionBatch}
    targets_constructed::Int
    batches_constructed::Int
    groups_reused::Int
    counts::BoundaryCounters
end
Base.@nospecializeinfer @noinline function PSE._begin_model_execution_application_refresh(
    previous, compiled::PSE.CompiledCompositeModel, env_bindings, temporal_streams,
    output_retention, constants, performance, changed_application_ids,
    changed_execution_target_ids, changed_targets_by_application,
    staged_execution_targets, force_general_changed_groups, groups, batches,
)
    @nospecialize previous compiled env_bindings temporal_streams output_retention constants
    @nospecialize performance changed_application_ids changed_execution_target_ids
    @nospecialize changed_targets_by_application staged_execution_targets groups batches
    counts=get(_enabled,compiled.model,nothing)
    counts===nothing && return nothing
    counts.refresh_states_created+=1
    return RefreshState(previous,compiled,env_bindings,temporal_streams,
        output_retention,constants,performance,changed_application_ids,
        changed_execution_target_ids,changed_targets_by_application,
        staged_execution_targets,force_general_changed_groups,groups,batches,0,0,0,counts)
end
@inline function _complete!(state,targets::Int,batches::Int,reused::Int)
    state.targets_constructed+=targets
    state.batches_constructed+=batches
    state.groups_reused+=reused
    state.counts.targets_constructed+=targets
    state.counts.batches_constructed+=batches
    state.counts.groups_reused+=reused
    state.counts.applications_completed+=1
    return true
end

# The complete original application body, not a target-constructor wrapper.
# P is the only application specialization dimension. Scene-wide arguments
# stay opaque; every existing target/batch constructor sees its actual values.
# Once entered, the helper cannot decline: exceptions propagate without replay.
Base.@nospecializeinfer @noinline function PSE._try_refresh_model_execution_application!(
    state::RefreshState,application::PSE.CompiledModelApplication{P},previous_group,
) where {P}
    @nospecialize previous_group
    state.counts.application_attempts+=1
    previous=state.previous
    compiled=state.compiled
    env_bindings=state.env_bindings
    temporal_streams=state.temporal_streams
    output_retention=state.output_retention
    constants=state.constants
    performance=state.performance
    changed_application_ids=state.changed_application_ids
    changed_execution_target_ids=state.changed_execution_target_ids
    changed_targets_by_application=state.changed_targets_by_application
    staged_execution_targets=state.staged_execution_targets
    force_general_changed_groups=state.force_general_changed_groups
    groups=state.groups
    batches=state.batches
    targets_constructed=batches_constructed=groups_reused=0
    if !isnothing(previous_group)
        if !isnothing(changed_application_ids)
            if !(application.id in changed_application_ids)
                control = PSE._stage_model_execution_group_control_refresh(
                    previous_group, compiled, env_bindings, temporal_streams,
                    output_retention, constants)
                if control !== false
                    isnothing(control) ||
                        PSE._commit_model_execution_group_control_refresh!(control)
                    push!(groups, previous_group)
                    append!(batches, previous_group.batches)
                    groups_reused += 1
                    return _complete!(state, targets_constructed, batches_constructed, groups_reused)
                end
                # A compact control record cannot hold the new graph's
                # field types. Do not reconstruct old lazy snapshots and
                # accidentally carry that obsolete graph into rich rows.
                previous_group = nothing
            end
            if !force_general_changed_groups && !isnothing(previous_group)
                delta_group = PSE._refresh_model_execution_group_delta!(
                    previous_group,
                    compiled,
                    env_bindings,
                    application,
                    temporal_streams,
                    output_retention,
                    constants,
                    performance,
                    get(
                        changed_targets_by_application,
                        application.id,
                        (),
                    ),
                    previous.shared_target_plans,
                )
                if !isnothing(delta_group)
                    if !isnothing(delta_group.group)
                        push!(groups, delta_group.group)
                        append!(batches, delta_group.group.batches)
                    end
                    targets_constructed +=
                        delta_group.targets_constructed
                    batches_constructed +=
                        delta_group.batches_constructed
                    return _complete!(state, targets_constructed, batches_constructed, groups_reused)
                end
            end
        elseif PSE._model_execution_group_reusable(
            previous_group,
            compiled,
            env_bindings,
            application,
            output_retention,
            temporal_streams,
        )
            push!(groups, previous_group)
            append!(batches, previous_group.batches)
            groups_reused += 1
            return _complete!(state, targets_constructed, batches_constructed, groups_reused)
        end
    end

    targets = Any[]
    previous_batch_index = 1
    previous_target_index = 1
    for object_id in application.target_ids
        previous_target = nothing
        while !isnothing(previous_group) &&
              previous_batch_index <= length(previous_group.batches)
            previous_batch =
                previous_group.batches[previous_batch_index]
            if previous_target_index > length(previous_batch.targets)
                previous_batch_index += 1
                previous_target_index = 1
                continue
            end
            candidate_id = PSE._model_execution_target_id(
                previous_batch.targets,
                previous_target_index,
            )
            if candidate_id == object_id
                previous_target = previous_batch.targets[previous_target_index]
                previous_target_index += 1
                break
            elseif PSE._object_id_isless(candidate_id, object_id)
                previous_target_index += 1
                continue
            end
            break
        end
        target_key = (application.id, object_id)
        change_reason = if isnothing(previous_target)
            :new_target
        elseif !isnothing(changed_application_ids) &&
               !(target_key in changed_execution_target_ids)
            nothing
        else
            PSE._model_execution_target_change_reason(
                previous_target,
                compiled,
                env_bindings,
                application,
                output_retention,
                temporal_streams,
            )
        end
        if isnothing(change_reason)
            push!(targets, previous_target)
        else
            execution_target = isnothing(staged_execution_targets) ?
                               nothing :
                               get(
                staged_execution_targets,
                target_key,
                nothing,
            )
            if isnothing(execution_target)
                execution_target = PSE._compiled_model_execution_target(
                    compiled,
                    env_bindings,
                    application,
                    object_id,
                    temporal_streams,
                    output_retention,
                    constants;
                    shared_plan_cache=previous.shared_target_plans,
                )
            end
            push!(
                targets,
                execution_target,
            )
            PSE._count_model_execution_target_rebuild!(
                performance,
                change_reason,
            )
            targets_constructed += 1
        end
    end

    application_batches = PSE.AbstractExecutionBatch[]
    PSE._append_model_execution_batches!(
        application_batches,
        env_bindings,
        application,
        targets,
        output_retention,
    )
    isempty(application_batches) && return _complete!(state, targets_constructed, batches_constructed, groups_reused)
    push!(
        groups,
        PSE.CompiledApplicationExecutionGroup(
            application,
            application_batches,
        ),
    )
    append!(batches, application_batches)
    batches_constructed += length(application_batches)
    return _complete!(state, targets_constructed, batches_constructed, groups_reused)
end
PSE._model_execution_application_refresh_counts(state::RefreshState)=
    (state.targets_constructed,state.batches_constructed,state.groups_reused)

Base.@nospecializeinfer @noinline function application_refresh_boundary_report(value)
    @nospecialize value
    model=value isa PSE.Simulation ? value.model : value
    model isa PSE.CompositeModel || throw(ArgumentError("Expected CompositeModel or Simulation"))
    counts=get(_enabled,model,nothing)
    names=fieldnames(BoundaryCounters)
    return (;enabled=counts!==nothing,
        counters=NamedTuple{names}(Tuple(counts===nothing ? 0 : getfield(counts,name) for name in names)),
        numerical_executor=:ordinary,only_specialization=:single_compiled_application_plan,
        constructed_counter_scope=:completed_application_invocations,
        lifetime=:one_general_refresh,scientific_values_cached=false,
        defaults_cached=false,memberships_cached=false,environment_samples_cached=false,
        original_target_and_batch_constructors=true,
        partial_failure=:propagate_without_replay)
end

end # module
