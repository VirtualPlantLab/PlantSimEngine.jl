# Ordinary XP dispatch/refresh independent source review

Source-only review; no Julia execution by this agent. Timing conclusions require the new cohort and explicit CPU qualification.

- `xp_dispatch_refresh_measurements.jl` SHA256 `d7f8279f67a06253f469bf114d0bbec3f95732c41c4c2d78d0b88f11c2fa689d`.
- `typed_output_preparation.jl` SHA256 `d9b61b7c7ca7ccfe959e257ba37097a7616054a810737ace9cca1695b10a6cd5`.
- `trusted_execution_group_index.jl` SHA256 `8ceeb5e80ad40de1e854b99420bb7137c7f6d628c7dc7da3aba1a74b5f2d40cc`.

The harness uses `DirectPlannerMeasurements.prepare_arm(...,:reference_executor)` for both ordinary labels. Neither enables bounded metadata, graph, NBP/NBS, numerical drivers or prior lookups. The bounded+graph anchor is explicit and cannot be mistaken for ordinary execution. Optional trusted+typed and trusted+typed+bounded-graph arms are separately labeled. Enablement is inside charged preparation.

Typed output preparation executes one fresh original local-output declaration per application, including targetless applications. It retains target/port iteration order, canonical routing, status-recipe/default/private-copy/conversion functions and outer application of recipes. It caches no values or memberships. Completed body/object/port counters commit after successful helper completion. Growth means binding-cache publication has occurred, not a count of unique newborns. No source blocker found.

Trusted index construction observes the existing core fill loop, rejects duplicate/invalid slots, records weak canonical application identities once per retained logical token and certifies the exact group-list/index identities. Queries check canonical application identity before group or empty-slot returns. A missed certificate/query enters the separately reported conservative epoch/original-ID path; no recursive trusted factory is involved. Constructor/stamp work and bounded registry eviction are real, measured costs. No source blocker found for core-owned index use. The core does not mutate index entries after construction; in-place pure additions update batch contents while retaining group objects.

The harness requires actual certified index hits/nonempty/empty work on growing XP, actual growth-phase object preparation for the typed arm, and completed graph tables for the anchor. It validates query/certificate/initial-growth partitions and keeps trusted, epoch and original-ID namespaces separate. Disabled controls require zero candidate counters. Global FIFO occupancy is not per-model optimization credit.

Two-day feature gates compare full per-step state/history/numeric types, scientific RNG fingerprints, exact canonical Status/Ref concrete types, reference/status replacement transitions and actual work against independent ordinary instances. Timed batches reuse only the frozen fresh-construction/fingerprint/work helpers, never prior scientific simulations. Each instance is observed independently after timing with lossless equal-value deduplication; each batch remains one statistical observation.

No old timing result is a baseline for this round. The new Python summarizer accepts only `xp_ordinary_dispatch_refresh_v1`, preserves excluded old-worker attempts raw-only, and requires exact artifact/CPU hashes for timing promotion. No cold, full-suite, million-organ, optional-package or peak-memory claim follows from these gates.
