Base.invokelatest() do
    spec=XPDispatchRefreshMeasurements.register_xp_dispatch_refresh_case!(:xp_dispatch_moderate;batch_size=4,steps=12,
        arms=(XPDispatchRefreshMeasurements.DISPATCH_ARMS...,XPDispatchRefreshMeasurements.OPTIONAL_ARMS...))
    screen=XPDispatchRefreshMeasurements.screen_xp_dispatch_refresh(spec;repetitions=6)
    report=(;pid=getpid(),screen,summary=NativeDownstreamMeasurements.summarize_screen(screen))
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/moderate-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,report,2)
    end
    (;passed=true,arms=length(screen.orders[1]),cycles=screen.repetitions)
end
