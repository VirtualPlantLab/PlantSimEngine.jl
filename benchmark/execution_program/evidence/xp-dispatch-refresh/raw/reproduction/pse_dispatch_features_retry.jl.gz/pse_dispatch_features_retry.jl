let file=joinpath(pwd(),"benchmark/native_downstream/dispatch_refresh_feature_checks.jl")
    source=read(file,String)
    start=findfirst("function _override_fixture",source).start
    stop=findnext("\n\"\"\"Tiny ordinary",source,start).start
    Base.include_string(DispatchRefreshFeatureChecks,source[start:prevind(source,stop)],file)
end
Base.invokelatest() do
    result=DispatchRefreshFeatureChecks.dispatch_refresh_feature_checks()
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/combined-feature-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),result),2)
    end
    (;passed=result.passed,cases=length(result.evidence))
end
