Base.invokelatest() do
    results=Any[]
    for kind in (:xp,:pb)
        result=XPDispatchRefreshMeasurements.dispatch_refresh_checks(kind;arm=:trusted_barrier_graph,steps=2,outputs=:all)
        push!(results,(;kind,result))
    end
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/combined-graph-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),passed=true,results),2)
    end
    (;passed=true,cases=length(results))
end
