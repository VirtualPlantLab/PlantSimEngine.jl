for file in ("execution_group_lookup.jl", "execution_group_epoch_lookup.jl", "trusted_execution_group_index.jl", "growth_input_reuse_checks.jl", "newborn_binding_program_checks.jl", "newborn_preparation.jl", "newborn_preparation_checks.jl", "newborn_distributed_checks.jl", "execution_group_lookup_checks.jl", "execution_group_epoch_lookup_checks.jl", "trusted_execution_group_index_checks.jl", "xp_prepared_batch_timing.jl", "xp_dispatch_refresh_measurements.jl")
    include(joinpath(pwd(),"benchmark/native_downstream",file))
end
Base.invokelatest() do
    TIC=TrustedExecutionGroupIndexChecks
    results=Any[]
    for (name,fn) in ((:unit,TIC.trusted_index_unit_checks),
        (:first_membership,()->TIC.trusted_index_parity_checks(:first_membership)),
        (:generic,()->TIC.trusted_index_parity_checks(:generic)),
        (:recompile,TIC.trusted_index_recompile_checks))
        result=fn();push!(results,(;name,result))
        open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/trusted-semantic-checks.json"),"w") do io
            PlantSimEngine.JSON.print(io,(;pid=getpid(),results),2)
        end
    end
    (;passed=true,cases=length(results))
end
