# Ordinary XP dispatch/refresh timing audit

Independent Python/source audit; no Julia execution by this agent. Both completed screens have explicit matching artifact/CPU/script/receipt SHA bindings and no competing Julia listed in their controller samples. No old bounded-baseline timings are pooled with this round.

## factorial-screen.json

4 independent scenes × 12 days per sample; 6 alternating cycles. PID 84480, source epoch `6a16ef4053b24baca17e90749df7ad3902222a9e8381cdb3286730f80b6f16f3`. Full stored per-instance state/history/numeric types/RNG/topology observations, work, digests, case/config and phase sums match. No alternate numerical driver or binding program enters. Cross-instance model/Status/Ref ownership is checked; warm source/forcing/prepare costs are explicit.

| Arm | Exec / ordinary A | Complete / A | Exec / ordinary B | Complete / B |
|---|---:|---:|---:|---:|
| ordinary_b | 1.0429 | 1.0364 | 1.0000 | 1.0000 |
| typed_graph | 0.9290 | 0.8721 | 0.8766 | 0.8376 |
| bounded_graph | 0.9425 | 0.8891 | 0.8993 | 0.8526 |
| trusted_barrier_graph | 0.9347 | 0.8797 | 0.9016 | 0.8545 |
| trusted_graph | 0.9500 | 0.8826 | 0.8915 | 0.8379 |
| ordinary_a | 1.0000 | 1.0000 | 0.9599 | 0.9649 |

Exact actual work: 48 total steps, 144 births, 176 final objects. Construction, enablement and all normal preparation remain charged to complete cost. Weather is read once at registration and copied for each instance; that common read is outside timing. The statistical unit is one prepared batch, not each member simulation.

All measured phases have zero JIT, recompilation and GC. Ordinary B/A execution median0.9877, range0.9692–1.1684; complete median0.9957. The large cycle4 placebo excursion is retained.
The full combination versus bounded+graph is execution0.9592 and complete0.9650,6/6 wins each. Its odd/even execution medians are0.9708/0.9477; leave-one medians stay0.9477–0.9708. This survives both order directions, but does not identify which added component produces the improvement.
Typed alone versus A has execution median0.9692 (5/6) with odd/even medians0.9224/0.9917. Against B it is0.9714 but only3/6 wins. Thus the small isolated runtime gain is less stable than the full combination. Trusted alone remains effectively ordinary (execution1.0062, complete0.9994 versus A). Trusted+typed without graph also lacks a clear incremental gain over typed alone.
Trusted batches:52 indices certified,4 logical stamps,244 application references recorded,48 certificate hits,1872 group hits+528 empties, no fallback epoch/ID maps. Bounded FIFO evictions occur and their counts are retained; occupancy itself earns no coverage credit. Typed batches:2740 completed applications,2680 object visits and2496 growth-phase visits. Each graph arm returns8 tables/488 rows/440 edges.
Execution allocations: ordinary152,199,984 bytes/batch; typed149,180,248; bounded+graph86,782,000; full83,779,888. These are allocated bytes, not retained memory or proof of a causal timing share.

## moderate-screen.json

4 independent scenes × 12 days per sample; 6 alternating cycles. PID 84480, source epoch `d8b748c3921183739220cdc2be24ccedf11bd8d71c6fdbeb015895c034ce64a7`. Full stored per-instance state/history/numeric types/RNG/topology observations, work, digests, case/config and phase sums match. No alternate numerical driver or binding program enters. Cross-instance model/Status/Ref ownership is checked; warm source/forcing/prepare costs are explicit.

| Arm | Exec / ordinary A | Complete / A | Exec / ordinary B | Complete / B |
|---|---:|---:|---:|---:|
| ordinary_a | 1.0000 | 1.0000 | 1.0125 | 1.0044 |
| ordinary_b | 0.9877 | 0.9957 | 1.0000 | 1.0000 |
| bounded_graph | 0.9520 | 0.8924 | 0.9637 | 0.8999 |
| trusted_index | 1.0062 | 0.9994 | 1.0125 | 1.0054 |
| typed_barrier | 0.9692 | 0.9853 | 0.9714 | 0.9931 |
| trusted_barrier | 0.9852 | 0.9844 | 0.9791 | 0.9765 |
| trusted_barrier_graph | 0.9068 | 0.8626 | 0.9141 | 0.8605 |

Exact actual work: 48 total steps, 144 births, 176 final objects. Construction, enablement and all normal preparation remain charged to complete cost. Weather is read once at registration and copied for each instance; that common read is outside timing. The statistical unit is one prepared batch, not each member simulation.

All measured phases have zero JIT, recompilation and GC. Ordinary B/A execution median0.9877, range0.9692–1.1684; complete median0.9957. The large cycle4 placebo excursion is retained.
The full combination versus bounded+graph is execution0.9592 and complete0.9650,6/6 wins each. Its odd/even execution medians are0.9708/0.9477; leave-one medians stay0.9477–0.9708. This survives both order directions, but does not identify which added component produces the improvement.
Typed alone versus A has execution median0.9692 (5/6) with odd/even medians0.9224/0.9917. Against B it is0.9714 but only3/6 wins. Thus the small isolated runtime gain is less stable than the full combination. Trusted alone remains effectively ordinary (execution1.0062, complete0.9994 versus A). Trusted+typed without graph also lacks a clear incremental gain over typed alone.
Trusted batches:52 indices certified,4 logical stamps,244 application references recorded,48 certificate hits,1872 group hits+528 empties, no fallback epoch/ID maps. Bounded FIFO evictions occur and their counts are retained; occupancy itself earns no coverage credit. Typed batches:2740 completed applications,2680 object visits and2496 growth-phase visits. Each graph arm returns8 tables/488 rows/440 edges.
Execution allocations: ordinary152,199,984 bytes/batch; typed149,180,248; bounded+graph86,782,000; full83,779,888. These are allocated bytes, not retained memory or proof of a causal timing share.

## small-screen.json

2 independent scenes × 2 days per sample; 4 alternating cycles. PID 84480, source epoch `d8b748c3921183739220cdc2be24ccedf11bd8d71c6fdbeb015895c034ce64a7`. Full stored per-instance state/history/numeric types/RNG/topology observations, work, digests, case/config and phase sums match. No alternate numerical driver or binding program enters. Cross-instance model/Status/Ref ownership is checked; warm source/forcing/prepare costs are explicit.

| Arm | Exec / ordinary A | Complete / A | Exec / ordinary B | Complete / B |
|---|---:|---:|---:|---:|
| ordinary_a | 1.0000 | 1.0000 | 0.9773 | 0.9853 |
| ordinary_b | 1.0238 | 1.0149 | 1.0000 | 1.0000 |
| bounded_graph | 1.0254 | 0.8215 | 1.0062 | 0.8110 |
| trusted_index | 0.9988 | 1.0440 | 1.0341 | 1.0071 |
| typed_barrier | 0.9852 | 0.9910 | 0.9628 | 0.9764 |

Exact actual work: 4 total steps, 12 births, 28 final objects. Construction, enablement and all normal preparation remain charged to complete cost. Weather is read once at registration and copied for each instance; that common read is outside timing. The statistical unit is one prepared batch, not each member simulation.

A/A B/A execution spans 0.8940–1.1732 with median1.0238; complete median1.0149. Typed output alone is a small signal within this spread (execution0.9852, complete0.9910 versus A). Trusted index alone has no complete gain (1.0440). The bounded+graph anchor has a clear preparation/complete gain against both controls, not a runtime gain in this small screen.
All execution JIT/recompilation/GC counters are zero. Ordinary A preparation cycle1 records134.583µs compilation; all other measured phase events are zero. These events are retained, not subtracted.
Trusted batches:6 certified indices,4 certificate hits,156 actual group hits+44 trusted empties, no epoch/ID fallback. Typed batches:330 completed applications,300 object visits and208 growth-phase object visits; those are not unique newborn counts.

## Feature and claim boundaries

Passed current-round original XP/PB gates cover trusted, typed and combined flags. The combined feature artifact has five independent pairs covering initializer/multirate/PreviousTimeStep, distributed from-status ownership, spatial growth/movement/cached calls, conversions/templates/overrides, and BigFloat. External conversion/backend sampling observations and canonical reference transitions are checked by those gates. The typed semantic artifact additionally exercises targetless declaration calls, fresh parameter values, mutable-default privacy, routing, effect order, exception-without-replay and unsupported-plan fallback. Trusted unit/lifecycle/recompile artifacts verify canonical proof/fallback behavior. These focused gates do not claim a full suite pass.

A reduced six-arm confirmation adding graph+typed and graph+trust is justified to separate the consistent full-combination gain. It must retain a new source cohort, both ordinary controls, exact original science and charged proof/construction costs. No production/scientific-code change or stronger target-merge prototype is needed for that contrast. That confirmation is completed below; no further benchmark expansion is required.

No cold compilation, peak RSS, million-organ or optional AMAPSim/MAESPA performance claim is supported. The separate ordinary controls refer to the same source with candidate flags disabled; they are not a fresh comparison with an unpatched historical parent.

## Final factorial confirmation

`factorial-screen.json`: 4 independent scenes ×12days,6 alternating cycles, PID 84480. Recorded source epoch `6a16ef4053b24baca17e90749df7ad3902222a9e8381cdb3286730f80b6f16f3` is retained separately from the first two screens. The harness adds only explicit graph+typed/graph+trust policy names; the old harness bytes are preserved under `source-before-factorial`. Core/prototype/scientific source is unchanged. Full per-instance state/history/type/RNG/topology/work observations match, all metadata counters partition correctly and all phase sums include enablement/preparation. All measured phases report zero compilation, recompilation and GC.

| Arm | Exec / A | Complete / A | Exec / B | Complete / B | Exec / graph | Complete / graph |
|---|---:|---:|---:|---:|---:|---:|
| ordinary_b | 1.0429 | 1.0364 | 1.0000 | 1.0000 | 1.1123 | 1.1729 |
| typed_graph | 0.9290 | 0.8721 | 0.8766 | 0.8376 | 0.9749 | 0.9757 |
| bounded_graph | 0.9425 | 0.8891 | 0.8993 | 0.8526 | 1.0000 | 1.0000 |
| trusted_barrier_graph | 0.9347 | 0.8797 | 0.9016 | 0.8545 | 0.9948 | 0.9931 |
| trusted_graph | 0.9500 | 0.8826 | 0.8915 | 0.8379 | 0.9840 | 0.9771 |
| ordinary_a | 1.0000 | 1.0000 | 0.9599 | 0.9649 | 1.0611 | 1.1248 |

Typed+graph versus graph wins5/6 for execution and complete cost. Execution paired ratios are0.96695,0.98101,0.91567,1.02847,0.98640,0.96888. The odd/even medians are0.96695/0.98101; every leave-one median stays below1 (0.96888–0.98101). Complete leave-one medians also remain below1 (0.97231–0.97907). This is a modest additional benefit, not an established universal2.5% constant.

Trust added to typed+graph yields median execution≈1.00075 and complete≈1.00635,3/6 wins each. Its complete odd/even medians flip0.98850/1.02866. There is no demonstrated incremental trust benefit. The full-combination/graph contrast shrinks from0.9592execution/0.9650complete in the prior moderate cohort to0.9948/0.9931 here (3/6). Do not pool those cohorts or present the earlier4%increment as stable synergy.

The factorial A/A B/A execution median is1.0429, range0.9952–1.1802; complete is1.0364. Typed+graph still beats both ordinary labels in6/6 execution and complete pairs. Conservative baseline-A figures are0.9290 execution and0.8721 complete. The practical candidate is bounded metadata + graph projection + typed output preparation, with no trusted-index requirement.

Execution allocations per batch are83,762,264bytes for typed+graph versus86,783,040 for graph. Full combination uses83,783,960bytes, slightly more than typed+graph. Actual typed work is2740 completed application bodies,2680 object visits and2496 growth-phase object visits; trusted-enabled arms report52certified indices,48certificate hits,1872group hits+528empty returns and zero conservative fallbacks. No cached-group/port count is credited as a scientific kernel execution.

## Final archive readiness

Check-only validates 3 qualified warm cohorts, 21 structured current check records, one explicitly excluded older-worker attempt, and all full stored scientific observations. The old attempt remains raw-only. The unexecuted future target-boundary proposal is preserved with per-file SHA metadata and explicitly receives no applied/tested/timed credit. No archive was created by this agent.

Frozen summarizer SHA256 `90222a441aaa9a8679b66bcdb9ce232d26b22a71cc048c79e063d062601a836e`. Current check-only counts:74raw files,165source files,370exact scientific-source blobs,3qualified warm screens,0excluded warm screens,21structured checks. These are validator inventory counts, not a full-suite assertion total. Additional root receipts/report copies can increase inventory counts without changing science/timing cohorts.
