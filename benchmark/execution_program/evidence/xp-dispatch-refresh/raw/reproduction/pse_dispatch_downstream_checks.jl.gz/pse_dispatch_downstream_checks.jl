Base.invokelatest() do
    results=Any[]
    for kind in (:xp,:pb), arm in (:trusted_index,:typed_barrier,:trusted_barrier)
        result=XPDispatchRefreshMeasurements.dispatch_refresh_checks(kind;arm,steps=2,outputs=:all)
        push!(results,(;kind,arm,result))
        open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/downstream-checks.json"),"w") do io
            PlantSimEngine.JSON.print(io,(;pid=getpid(),results),2)
        end
    end
    (;passed=true,cases=length(results))
end
