include(joinpath(pwd(),"benchmark/native_downstream/xp_dispatch_refresh_measurements.jl"))
Base.invokelatest() do
    results=Any[]
    for arm in (:typed_graph,:trusted_graph),kind in (:xp,:pb)
        result=XPDispatchRefreshMeasurements.dispatch_refresh_checks(kind;arm,steps=2,outputs=:all)
        push!(results,(;kind,arm,result))
    end
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/factorial-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),passed=true,results),2)
    end
    (;passed=true,cases=length(results))
end
