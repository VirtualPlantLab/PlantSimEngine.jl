Base.invokelatest() do
    spec=XPDispatchRefreshMeasurements.register_xp_dispatch_refresh_case!(:xp_dispatch_graph_factorial;batch_size=4,steps=12,
        arms=(:ordinary_b,:typed_graph,:bounded_graph,:trusted_barrier_graph,:trusted_graph,:ordinary_a))
    screen=XPDispatchRefreshMeasurements.screen_xp_dispatch_refresh(spec;repetitions=6)
    report=(;pid=getpid(),screen,summary=NativeDownstreamMeasurements.summarize_screen(screen))
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/factorial-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,report,2)
    end
    (;passed=true,arms=length(screen.orders[1]),cycles=screen.repetitions)
end
