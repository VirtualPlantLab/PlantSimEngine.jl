include(joinpath(pwd(),"benchmark/native_downstream/typed_output_preparation.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/typed_output_preparation_checks.jl"))
Base.invokelatest() do
    result=TypedOutputPreparationChecks.typed_output_preparation_checks()
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/typed-semantic-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,result,2)
    end
    (;passed=result.passed,coverage=result.coverage)
end
