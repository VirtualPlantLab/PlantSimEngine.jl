Base.invokelatest() do
    M=NativeDownstreamMeasurements; PSE=PlantSimEngine
    provenance=M.process_provenance(;packages=(PSE,NativePBDriver.PB,NativeXPDriver.XPalm))
    weather_path=joinpath(pkgdir(NativeXPDriver.XPalm),"0-data","meteo.csv")
    weather=CompiledRegionsExperiment._xpalm_fixture_weather(12)
    columns=propertynames(weather)
    rows=[Dict(string(name)=>(type=string(typeof(row[name])),value=repr(row[name])) for name in columns) for row in eachrow(weather)]
    forcing=(path=weather_path,sha256=bytes2hex(M.SHA.sha256(read(weather_path))),
        selected_rows=12,columns=string.(columns),rows,
        added_duration=:Day_1_when_missing,seed=1,emission_speed=.2,
        diagnostic_fixture=:accelerated_growth_original_scientific_kernels)
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/final-provenance.json"),"w") do io
        PSE.JSON.print(io,(;pid=getpid(),provenance,forcing),2)
    end
    (;passed=true,pid=getpid(),package_count=length(provenance.packages),weather_rows=length(rows))
end
