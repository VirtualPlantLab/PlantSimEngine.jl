Base.invokelatest() do
    spec=XPDispatchRefreshMeasurements.register_xp_dispatch_refresh_case!(:xp_dispatch_small;batch_size=2,steps=2)
    screen=XPDispatchRefreshMeasurements.screen_xp_dispatch_refresh(spec;repetitions=4)
    report=(;pid=getpid(),screen,summary=NativeDownstreamMeasurements.summarize_screen(screen))
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/small-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,report,2)
    end
    (;passed=true,arms=length(screen.orders[1]),cycles=screen.repetitions)
end
