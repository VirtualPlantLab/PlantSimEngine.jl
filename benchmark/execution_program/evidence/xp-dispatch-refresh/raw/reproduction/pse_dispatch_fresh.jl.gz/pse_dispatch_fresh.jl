include(joinpath(pwd(),"benchmark/native_downstream/load_newborn_binding_experiment.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/graph_row_projection.jl"))
Base.invokelatest() do
    PSE=PlantSimEngine;F=DirectPlannerFixtures;H=DirectPlannerMeasurements
    config=H.construct_config(:xp;steps=2,nobjects=2,outputs=:all)
    left=F.construct_fixture(:xp,config);right=F.construct_fixture(:xp,config)
    control=H.prepare_arm(left.model,:reference_executor;outputs=:all)
    GraphRowProjection.enable_graph_row_projection!(right.model)
    candidate=H.prepare_arm(right.model,:bounded_preparation;outputs=:all)
    before_left=F.identities(left.model);before_right=F.identities(right.model)
    @assert isequal(F.snapshot(control,:xp),F.snapshot(candidate,:xp))
    for _ in 1:2
        PSE.step!(control);PSE.step!(candidate)
        @assert isequal(F.snapshot(control,:xp),F.snapshot(candidate,:xp))
        @assert F.scientific_rngs(left.model)==F.scientific_rngs(right.model)
        after_left=F.identities(left.model);after_right=F.identities(right.model)
        @assert F.same_identity_transitions(before_left,before_right,after_left,after_right)
        before_left,before_right=after_left,after_right
    end
    environment=(pid=getpid(),julia=string(VERSION),project=Base.active_project(),
        pse=(path=Base.pathof(PSE),version=string(Base.pkgversion(PSE))),
        pb=(path=Base.pathof(NativePBDriver.PB),version=string(Base.pkgversion(NativePBDriver.PB))),
        xp=(path=Base.pathof(NativeXPDriver.XPalm),version=string(Base.pkgversion(NativeXPDriver.XPalm))))
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/fresh-baseline-checks.json"),"w") do io
        PSE.JSON.print(io,(;passed=true,environment,control=F.snapshot(control,:xp),candidate=F.snapshot(candidate,:xp),
            graph=GraphRowProjection.graph_row_projection_report(candidate)),2)
    end
    (;passed=true,environment)
end
