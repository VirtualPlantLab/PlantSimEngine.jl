include(joinpath(pwd(),"benchmark/native_downstream/dispatch_refresh_feature_checks.jl"))
Base.invokelatest() do
    result=DispatchRefreshFeatureChecks.dispatch_refresh_feature_checks()
    open(joinpath(pwd(),"benchmark/native_downstream/results/xp-dispatch-refresh/combined-feature-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),result),2)
    end
    (;passed=result.passed,cases=length(result.evidence))
end
