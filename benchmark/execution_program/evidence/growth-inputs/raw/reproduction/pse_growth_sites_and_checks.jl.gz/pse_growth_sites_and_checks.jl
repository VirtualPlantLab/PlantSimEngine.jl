# Reload the definitions-only diagnostic after its bounded site extension.
include(joinpath(pwd(),"benchmark/native_downstream/growth_input_profile.jl"))
profiles=Any[]
for arm in (:reference_executor,:bounded_preparation)
    push!(profiles,Base.invokelatest(GrowthInputProfile.profile_growth_input_allocations;arm,steps=4,repetitions=3,allocation_sample_rate=0.01,progress_path=joinpath(pwd(),"benchmark/native_downstream/results/growth-input/sites-stages.tsv")))
end
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/allocation-sites.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;pid=getpid(),profiles,provenance=NativeDownstreamMeasurements.process_provenance(packages=(PlantSimEngine,PlantBiophysics,XPalm,PlantGeom))),2)
end
checks=Any[]
include(joinpath(pwd(),"benchmark/native_downstream/newborn_preparation.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/newborn_preparation_checks.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/newborn_distributed_checks.jl"))
push!(checks,Base.invokelatest(GrowthInputReuseChecks.growth_input_declaration_checks))
for case in (:initializer,:mixed_cadence,:distributed,:distributed_from_status)
    push!(checks,Base.invokelatest(GrowthInputReuseChecks.growth_input_feature_checks,case))
end
for kind in (:pb,:xp)
    push!(checks,Base.invokelatest(GrowthInputReuseChecks.growth_input_downstream_checks,kind;steps=2))
end
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/partition-feature-checks.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
end
(;passed=true,profiles=length(profiles),checks=length(checks))
