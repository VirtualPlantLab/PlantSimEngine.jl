include(joinpath(pwd(),"benchmark/native_downstream/growth_input_profile.jl"))
GrowthInputProfile.classifier_checks()
profile_result = Base.invokelatest(GrowthInputProfile.profile_growth_inputs; steps=4,repetitions=5,allocation_sample_rate=0.01,progress_path=joinpath(pwd(),"benchmark/native_downstream/results/growth-input/profile-stages.tsv"))
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/baseline-input-profile.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;profile=profile_result,provenance=NativeDownstreamMeasurements.process_provenance(packages=(PlantSimEngine,PlantBiophysics,XPalm,PlantGeom))),2)
end
(;passed=profile_result.passed,cpu_samples=profile_result.cpu.selected,allocation_records=profile_result.allocations.recorded)
