include(joinpath(pwd(),"benchmark/native_downstream/growth_input_reuse_checks.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/growth_plan_storage.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/growth_plan_storage_checks.jl"))
checks=Any[]
push!(checks,Base.invokelatest(GrowthInputReuseChecks.growth_input_declaration_checks))
push!(checks,Base.invokelatest(GrowthPlanStorageChecks.growth_plan_storage_checks))
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/heap-small-checks.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
end
(;passed=true,checks=length(checks))
