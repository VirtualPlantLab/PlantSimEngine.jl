include(joinpath(pwd(),"benchmark/native_downstream/growth_plan_access.jl"))
access=Base.invokelatest(GrowthPlanAccess.compare_plan_access,:xp;nlookups=500)
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/plan-access.json"),"w") do io
    PlantSimEngine.JSON.print(io,access,2)
end
arms=(:reference_executor,:partition,:heap_plan,:heap_partition,:bounded_preparation,:bounded_heap,:bounded_all)
spec=Base.invokelatest(GrowthInputMeasurements.register_growth_input_case!,:growth_xp_combinations,:xp;steps=4,arms)
DirectPlannerMeasurements._stage(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/combination-screen-stages.tsv"),:xp,:factorial,"before_screen")
screen=Base.invokelatest(NativeDownstreamMeasurements.screen_case,spec;repetitions=4,measure_retained=false)
DirectPlannerMeasurements._stage(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/combination-screen-stages.tsv"),:xp,:factorial,"after_screen")
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/combination-screen.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;kind=:xp,screen,summary=NativeDownstreamMeasurements.summarize_screen(screen)),2)
end
(;passed=true,cases=1,metadata_access_completed=true)
