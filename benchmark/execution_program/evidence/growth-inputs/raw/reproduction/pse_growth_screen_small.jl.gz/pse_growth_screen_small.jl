using Dates
results=Any[]
for (name,kind,steps,nobjects,arms) in (
    (:growth_xp_small,:xp,4,2,(:reference_executor,:partition,:heap_plan,:heap_partition,:bounded_preparation)),
    (:growth_pb_hot,:pb,128,32,(:reference_executor,:typed_driver,:typed_heap)),
)
    spec=Base.invokelatest(GrowthInputMeasurements.register_growth_input_case!,name,kind;steps,nobjects,arms)
    DirectPlannerMeasurements._stage(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/small-screen-stages.tsv"),kind,:factorial,"before_screen")
    screen=Base.invokelatest(NativeDownstreamMeasurements.screen_case,spec;repetitions=4,measure_retained=false)
    DirectPlannerMeasurements._stage(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/small-screen-stages.tsv"),kind,:factorial,"after_screen")
    report=(;kind,screen,summary=NativeDownstreamMeasurements.summarize_screen(screen))
    push!(results,report)
    open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/"*string(name)*".json"),"w") do io
        PlantSimEngine.JSON.print(io,report,2)
    end
end
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/small-screens.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;pid=getpid(),reports=results),2)
end
(;passed=true,cases=length(results))
