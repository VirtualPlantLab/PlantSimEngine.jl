checks=Any[]
for case in (:pb,:xp,:initializer,:mixed_cadence,:distributed)
    @info "Preboxed cold payload feature gate" case
    push!(checks,Base.invokelatest(PreboxedPlanChecks.preboxed_plan_checks,case))
end
push!(checks,Base.invokelatest(PreboxedPlanChecks.preboxed_plan_partition_checks))
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/preboxed-feature-checks.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;pid=getpid(),checks,provenance=NativeDownstreamMeasurements.process_provenance(packages=(PlantSimEngine,PlantBiophysics,XPalm,PlantGeom))),2)
end
(;passed=true,checks=length(checks))
