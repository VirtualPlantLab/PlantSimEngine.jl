include(joinpath(pwd(),"benchmark/native_downstream/growth_plan_storage.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/growth_input_measurements.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/growth_plan_access.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/preboxed_plan_checks.jl"))
check=Base.invokelatest(PreboxedPlanChecks.preboxed_plan_checks,:generic)
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/preboxed-small-checks.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;pid=getpid(),check),2)
end
(;passed=true,cases=1)
