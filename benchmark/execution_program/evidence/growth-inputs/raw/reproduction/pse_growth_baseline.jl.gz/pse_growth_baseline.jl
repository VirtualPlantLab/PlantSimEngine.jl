using Test
checks = Any[]
for kind in (:pb, :xp)
    @info "Small independent ordinary baseline parity" kind
    push!(checks, Base.invokelatest(DirectPlannerMeasurements.direct_planner_checks, kind; arm=:reference_executor,steps=2))
end
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/baseline-checks.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
end
(;passed=true,pid=getpid(),cases=length(checks))
