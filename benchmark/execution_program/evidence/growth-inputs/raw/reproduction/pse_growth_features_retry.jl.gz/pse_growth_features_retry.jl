checks=Any[]
for case in (:initializer,:mixed_cadence,:distributed,:distributed_from_status)
    push!(checks,Base.invokelatest(GrowthInputReuseChecks.growth_input_feature_checks,case))
end
for kind in (:pb,:xp)
    push!(checks,Base.invokelatest(GrowthInputReuseChecks.growth_input_downstream_checks,kind;steps=2))
end
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/partition-feature-checks.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
end
(;passed=true,checks=length(checks))
