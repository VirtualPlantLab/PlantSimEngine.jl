include(joinpath(pwd(),"benchmark/native_downstream/growth_input_cold_case.jl"))
expected_hashes=PlantSimEngine.JSON.parsefile(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/cold-source-image.json"))
GrowthInputColdCase.run_growth_input_cold_case(:xp,:bounded_preboxed;
    freshness=(new_process=true,no_prior_case_execution=true,no_prior_ir_probe=true,pid=getpid(),previous_pid=62896),
    expected_source_hashes=expected_hashes,output_path=pse_direct_expected,
    expected_digest="f5ef1910b80a83a12e9a36493fd54b8342567c097d71089c58fe8bfaf0a7530b")
