import argparse, importlib.util, json, re, time
from pathlib import Path
from datetime import datetime, timezone
import pse_future_cpu as cpu

spec = importlib.util.spec_from_file_location('client', '/private/tmp/pse_kaimon_client.py')
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)
parser = argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('script')
parser.add_argument('expected')
parser.add_argument('--budget', type=int, default=360)
parser.add_argument('--timing', action='store_true')
parser.add_argument('--package-source')
parser.add_argument('--controller-warmup', action='store_true')
args = parser.parse_args()
root = Path('/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine')
out = root / 'benchmark/native_downstream/results/growth-input'
receipts = out / 'receipts'
receipts.mkdir(parents=True, exist_ok=True)
expected = Path(args.expected)
if expected.exists():
    raise RuntimeError('Existing result must be preserved: ' + str(expected))
session = json.loads(client.STATE.read_text())['session']
attempt = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')
step = 0
worker = None
monitor = None

def content(response):
    return '\n'.join(x.get('text', '') for x in response.get('result', {}).get('content', []) if x.get('type') == 'text')

def call(name, arguments):
    global step
    step += 1
    response, _ = client.post('tools/call', {'name': name, 'arguments': arguments}, session)
    (receipts / f'{args.label}-{attempt}-{step:02}-{name}.json').write_text(json.dumps({
        'recorded_at': datetime.now(timezone.utc).isoformat(), 'tool': name,
        'arguments': arguments, 'response': response}, indent=2) + '\n')
    return response

def finish(response, budget, phase="evaluation"):
    message = content(response)
    if 'promoted to background' not in message:
        return response
    eval_id = response.get('result', {}).get('eval_id')
    if not eval_id:
        match = re.search(r'Job ID:\s*([a-zA-Z0-9_-]+)', message)
        eval_id = match.group(1) if match else None
    if not eval_id:
        raise RuntimeError('Missing background id: ' + message[:2000])
    deadline = time.monotonic() + budget
    environment_retried = False
    print(json.dumps({'stage': 'background', 'label': args.label, 'eval_id': eval_id, 'phase': phase}), flush=True)
    while True:
        time.sleep(30)
        response = call('check_eval', {'eval_id': eval_id})
        message = content(response)
        if '\ncompleted,' in message:
            return response
        if '\nfailed,' in message or '\ncancelled,' in message:
            raise RuntimeError(message[:3500])
        if phase == 'environment' and not environment_retried:
            environment_retried = True
            second = call('ex', {'ses': worker, 'e': 'sleep(1); (project=Base.active_project(), cwd=pwd(), julia=string(VERSION), revise_loaded=isdefined(Main,:Revise), pid=getpid())', 'q': False, 'max_output': 1600})
            if 'promoted to background' not in content(second) and str(root) in content(second):
                call('cancel_eval', {'eval_id': eval_id})
                print(json.dumps({'stage': 'environment_recovered', 'label': args.label}), flush=True)
                return second
            second_id = second.get('result', {}).get('eval_id')
            if not second_id:
                second_match = re.search(r'Job ID:\s*([a-zA-Z0-9_-]+)', content(second))
                second_id = second_match.group(1) if second_match else None
            if second_id:
                call('cancel_eval', {'eval_id': second_id})
        print(json.dumps({'stage': 'running', 'label': args.label, 'phase': phase}), flush=True)
        if time.monotonic() > deadline:
            call('cancel_eval', {'eval_id': eval_id})
            raise RuntimeError('Bounded evaluation budget exceeded')

try:
    if args.timing:
        cpu.quiet(args.label, budget=600)
    response = call('start_session', {'project_path': str(root), 'name': 'PSE growth cold ' + args.label})
    match = re.search(r'Session key: ([a-z0-9]+)', content(response))
    if not match:
        raise RuntimeError(content(response)[:3000])
    worker = match.group(1)
    print(json.dumps({'stage': 'worker_started', 'label': args.label, 'worker': worker}), flush=True)
    time.sleep(15)
    response = finish(call('investigate_environment', {'session': worker}), 90, phase='environment')
    if str(root) not in content(response):
        raise RuntimeError('Project verification failed: ' + content(response)[:2000])
    response = call('ping', {})
    line = next((x for x in content(response).splitlines() if worker in x), '')
    match = re.search(r'PID (\d+)', line)
    if not match:
        raise RuntimeError('Unable to identify owned worker: ' + content(response)[:1000])
    owned_pid = int(match.group(1))
    if args.controller_warmup:
        finish(call('ex', {'ses': worker, 'e': 'sleep(31); (pid=getpid(), completed=true)', 'q': False, 'max_output': 1000}), 120, phase='controller_warmup')
        if args.timing:
            cpu.quiet(args.label + '-after-controller-warmup', budget=300)
    if args.timing:
        monitor = cpu.Monitor(owned_pid)
        monitor.start()
    source_root = args.package_source or str(root)
    prefix = ('pushfirst!(LOAD_PATH, ' + json.dumps(source_root) + '); ') if args.package_source else ''
    expression = (prefix + 'using PlantSimEngine; @assert startswith(pathof(PlantSimEngine), ' + json.dumps(source_root) + '); '
        'pse_direct_owned_pid=' + str(owned_pid) + '; pse_direct_expected=' + json.dumps(str(expected)) + '; '
        'include(' + json.dumps(str(Path(args.script).resolve())) + '); (pid=getpid(),completed=true)')
    response = finish(call('ex', {'ses': worker, 'e': expression, 'q': False, 'max_output': 3500}), args.budget)
    if not expected.exists():
        raise RuntimeError('No completed result: ' + content(response)[:3500])
    if monitor:
        isolation = monitor.finish()
        monitor = None
        (out / f'{args.label}-{attempt}-cpu.json').write_text(json.dumps(isolation, indent=2) + '\n')
        if not isolation['qualified']:
            expected.rename(expected.with_name(expected.stem + '-unqualified-cpu-' + attempt + expected.suffix))
            raise RuntimeError('Competing Julia work: timing excluded')
    print(json.dumps({'stage': 'completed', 'label': args.label, 'pid': owned_pid, 'result': str(expected)}), flush=True)
finally:
    if monitor:
        (out / f'{args.label}-{attempt}-cpu-incomplete.json').write_text(json.dumps(monitor.finish(), indent=2) + '\n')
    if worker:
        call('manage_repl', {'session': worker, 'command': 'shutdown'})
