include(joinpath(pwd(),"benchmark/native_downstream/growth_input_reuse.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/growth_input_reuse_checks.jl"))
reports = Any[]
for check in (GrowthInputReuseChecks.growth_input_partition_checks, GrowthInputReuseChecks.growth_input_generic_checks)
    push!(reports,Base.invokelatest(check))
end
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/partition-small-checks.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;pid=getpid(),reports),2)
end
(;passed=true,cases=length(reports))
