include(joinpath(pwd(),"benchmark/native_downstream/growth_input_cold_case.jl"))
expected_hashes=PlantSimEngine.JSON.parsefile(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/cold-source-image.json"))
GrowthInputColdCase.run_growth_input_cold_case(:xp,:bounded_preparation;
    freshness=(new_process=true,no_prior_case_execution=true,no_prior_ir_probe=true,pid=getpid(),previous_pid=57399),
    expected_source_hashes=expected_hashes,output_path=pse_direct_expected)
