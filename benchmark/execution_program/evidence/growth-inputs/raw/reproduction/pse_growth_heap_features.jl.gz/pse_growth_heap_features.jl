include(joinpath(pwd(),"benchmark/native_downstream/growth_input_measurements.jl"))
checks=Any[]
for case in (:initializer,:mixed_cadence,:distributed_from_status)
    @info "Read-only heap plan feature gate" case
    push!(checks,Base.invokelatest(GrowthPlanStorageChecks.growth_plan_storage_feature_checks,case))
end
for kind in (:pb,:xp)
    @info "Read-only heap plan downstream gate" kind
    push!(checks,Base.invokelatest(GrowthPlanStorageChecks.growth_plan_storage_downstream_checks,kind;steps=2))
end
function growth_enable_both!(model)
    GrowthPlanStorage.enable_growth_plan_storage!(model)
    GrowthInputReuse.enable_growth_input_reuse!(model)
    return model
end
push!(checks,Base.invokelatest(GrowthInputReuseChecks.growth_input_generic_checks;enable! = growth_enable_both!))
for kind in (:pb,:xp)
    push!(checks,Base.invokelatest(GrowthInputReuseChecks.growth_input_downstream_checks,kind;steps=2,enable! = growth_enable_both!))
end
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/heap-and-combined-features.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;pid=getpid(),checks,provenance=NativeDownstreamMeasurements.process_provenance(packages=(PlantSimEngine,PlantBiophysics,XPalm,PlantGeom))),2)
end
(;passed=true,checks=length(checks))
