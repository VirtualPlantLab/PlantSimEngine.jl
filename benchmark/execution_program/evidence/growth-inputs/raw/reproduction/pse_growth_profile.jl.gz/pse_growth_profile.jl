using Profile
include("/private/tmp/pse_profile_compact.jl")

# Diagnostics only: fixture and preparation work is outside the profile.
# Keep performance=false, since instrumentation selects ordinary execution.
Base.@nospecializeinfer @noinline function pse_growth_profile(;
    case=:growth_medium, repeats=4,
    output_dir=joinpath(pwd(), "benchmark/native_downstream/results/call-growth"))
    M = Main.NativeDownstreamMeasurements
    spec = M.CASES[case]
    results = Any[]
    Profile.init(n=2_000_000, delay=0.0001)
    for name in (:reference_executor, :incremental_growth)
        variant = M._resolve_variant(spec, name)
        prepared = Any[]
        for _ in 1:repeats
            fixture = Base.invokelatest(spec.construct, spec.config, variant)
            sim = Base.invokelatest(spec.prepare, fixture, spec.config, variant)
            push!(prepared, (sim, fixture))
        end
        GC.gc()
        Profile.clear()
        Profile.@profile for (simulation, fixture) in prepared
            Base.invokelatest(spec.execute!, simulation, nothing, fixture, spec.config, variant)
        end
        compact_path = joinpath(output_dir, "growth-profile-$(name)-compact.tsv")
        compact = pse_profile_compact(limit=100, outfile=compact_path)
        digests = [M.bytes2hex(M.sha256(repr(Base.invokelatest(spec.fingerprint,
            sim, fixture, spec.config)))) for (sim, fixture) in prepared]
        all(==(first(digests)), digests) || error("Profile semantic mismatch within arm")
        coverage = [Base.invokelatest(spec.coverage, sim, nothing, fixture,
            spec.config, variant) for (sim, fixture) in prepared]
        push!(results, (variant=name, repeats, digest=first(digests),
            compact_path, compact, coverage, entries=length(Profile.fetch())))
    end
    results[1].digest == results[2].digest || error("Profile semantic mismatch across arms")
    return results
end
