# Separate source cohort after adding preboxed cold metadata fields.
preboxed_access=DirectPlannerFixtures.Helpers.preserve_task_rng() do
    config=DirectPlannerMeasurements.construct_config(:xp;steps=2,outputs=:none)
    fixture=Base.invokelatest(DirectPlannerFixtures.construct_fixture,:xp,config)
    simulation=Base.invokelatest(GrowthInputMeasurements.prepare_growth_input_arm,fixture.model,:preboxed_plan;outputs=:none)
    application=simulation.compiled.applications_by_id[:Phytomer__reproductive_organ_emission]
    rows=Any[]
    for field in (:plan,:spec,:id)
        Base.invokelatest(GrowthPlanAccess._measure_lookup,application,field,1)
        push!(rows,Base.invokelatest(GrowthPlanAccess._measure_lookup,application,field,500))
    end
    GrowthPlanAccess._escaped_sink[]=nothing
    (;rows,coverage=GrowthPlanStorage.growth_plan_storage_report(simulation),whole_application_claim=false)
end
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/preboxed-access.json"),"w") do io
    PlantSimEngine.JSON.print(io,preboxed_access,2)
end
reports=Any[]
for (name,kind,steps,nobjects,arms) in (
    (:growth_xp_preboxed,:xp,4,2,(:reference_executor,:heap_plan,:preboxed_plan,:preboxed_partition,:bounded_preparation,:bounded_preboxed)),
    (:growth_pb_preboxed,:pb,128,32,(:reference_executor,:typed_driver,:typed_preboxed)),
)
    spec=Base.invokelatest(GrowthInputMeasurements.register_growth_input_case!,name,kind;steps,nobjects,arms)
    DirectPlannerMeasurements._stage(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/preboxed-screen-stages.tsv"),kind,:factorial,"before_screen")
    screen=Base.invokelatest(NativeDownstreamMeasurements.screen_case,spec;repetitions=4,measure_retained=false)
    DirectPlannerMeasurements._stage(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/preboxed-screen-stages.tsv"),kind,:factorial,"after_screen")
    push!(reports,(;kind,screen,summary=NativeDownstreamMeasurements.summarize_screen(screen)))
end
open(joinpath(pwd(),"benchmark/native_downstream/results/growth-input/preboxed-screens.json"),"w") do io
    PlantSimEngine.JSON.print(io,(;pid=getpid(),reports),2)
end
(;passed=true,cases=length(reports))
