# Independent growth-input final audit

Audited the final `cold-bounded-qualified.json`, `cold-preboxed-qualified.json`, `qualification.json`, reproduction helpers, staged phase logs, completion receipts, and `benchmark/execution_program/growth_inputs.md`. Source-only audit; no Julia run or raw result modification.

## Cold cohort qualification

- All seven qualification entries have correct raw artifact, CPU record, reproduction script and receipt SHA-256 bindings. The two cold entries bind the dispatch receipts; separate preserved completion receipts confirm their same job IDs/PIDs completed successfully (`...bounded...-09-check_eval.json`, `...preboxed...-07-check_eval.json`).
- Both cold CPU records are qualified, contain 24 observations with no observed competing Julia activity, and bracket construction through diagnostics. Maximum observation gaps are 5.077980 s and 5.076137 s. This is sampled quietness, not proof of zero interference.
- PIDs are distinct: 62896 (bounded metadata), 63290 (bounded plus preboxed). Each attests a new process, no previous case/IR probe, correct current PID and different previous PID. Helper and shared harness counters reject reuse. Both run Julia 1.13.1 from the same active project/source.
- All 15 source-image entries are identical across records, equal the expected image, and match current file bytes. Scientific package provenance, full harness image and experimental-source provenance also match exactly. `f5ef1910...` is the scientific digest, not the source-image hash.
- Configurations differ only in intended policy: both use original XP science, two days, seed 1, emission speed 0.2, outputs none. Complete serialized snapshots (including state/history/topology/numeric types and model RNG fingerprints), digest and work are exactly equal: 14 final objects, six additions and 22 streams.
- Bounded metadata positive coverage matches in both. Baseline heap counts are zero; candidate has 61 actually constructed/current preboxed plans, zero concrete plans. Partition and numerical-driver counts are zero in both. No metadata work is credited as scientific execution.

## Timing audit

| Phase | Bounded metadata seconds | Bounded + preboxed seconds |
| --- | ---: | ---: |
| Construction | 11.361813042 | 11.412730000 |
| Preparation | 70.602523042 | 71.074243833 |
| First step | 12.749845875 | 12.745195041 |
| Remaining step | 0.007745958 | 0.008316375 |
| Complete | 94.721927917 | 95.240485249 |

Phase sums and allocation sums reproduce each complete field exactly. Preboxing adds 0.518557332 s complete (ratio 1.0054745) and 0.471720791 s preparation (ratio 1.0066814). Recorded preparation compilation time is also higher, 70.379059674 -> 70.850624947 s. Aggregate compilation counters are 94.787284074 -> 94.951715443 s; such counters need not be additive exclusive wall-clock phases. GC remains recorded separately. Allocation volume falls 12,470,644,392 -> 12,391,406,904 bytes, without a measured latency improvement.

Imports/definition loading are outside the four phases and are separately recorded (~5.46/~5.34 s definition loading). Source/PID/counter checks do not execute science. Policy enablement and ordinary logical preparation occur inside measured preparation; no package activation, explicit precompile request, future-layout catalogue or scientific warmup is run between first-use entry and execution. Diagnostics/provenance occur after all timed science. Package disk caches remain available. These are first-use simulation observations, not cold-depot/package-installation results.

## Claim review

The report's table, no-new-compilation-gain conclusion, per-arm single-observation limitation, warm/preboxed cohort separation and decision to retain bounded metadata/earlier PB driver as candidates are supported. The warm result still gives no new XP whole-run winner; PB typed-plus-preboxed's ~2% paired signal is explicitly small and unconfirmed, with higher execution allocations and short-task complete cost above ordinary. The report appropriately does not promote lower sampled/allocation bytes into a causal throughput or peak-memory claim, does not claim preceding-revision hook neutrality, and leaves full regression/large-scale qualification outstanding.

No material report correction or evidence-blocking issue found. Keep the older failed, stalled and CPU-unqualified attempts excluded. Do not interpret the cold +0.55% difference as an established regression: one first-use observation per arm supports the bounded conclusion that this screen demonstrates no additional compilation/preparation benefit.
