# Independent growth-input warm audit

Audited `small-screens.json`, `combination-screen.json`, `preboxed-screens.json` and their three CPU records. No Julia or source edits were performed for the audit. Cold results are pending and are not inferred from these warm samples.

## Qualification

All five distinct screens have four balanced forward/reverse cycles and the exact recorded sample order. Full stored scientific/type/history/topology/RNG snapshots, digests and work agree across every same-screen sample and warmup. XP runs four days, adds 12 objects, ends with 20 and retains 34 streams. PB runs 32 objects ×128 steps without growth. Fresh models, tree/state, RNGs and forcing copies are constructed for every sample; the Julia process is reused (PID 57399), so these are warm screens, not fresh-process compilation measurements.

All three CPU records are qualified=true with no observed busy Julia process: five observations for the initial screen, five for the combinations and thirty for the preboxed cohort. This is the monitor's sampled guarantee, not proof against every brief competing task.

The only nonzero measured JIT entry is initial ordinary XP preparation, cycle 1: 118.583 microseconds. All other measured compilation, all recompilation and all measured GC entries are zero. Initial source manifests differ from current files only in the two intentionally changed measurement/storage modules; exact old bytes resolve to immutable source-before-prebox snapshots. All preboxed manifest bytes match current files. Source cohorts must remain separate; do not pool their cycles. The two standalone initial screen exports duplicate `small-screens.json` exactly and are not additional independent replications.

Positive coverage is genuine metadata work: partition arms report 132 nonempty partition hits and 326 appended bindings; heap arms construct and retain 61 application plans on XP. New payload arms report 61 actual preboxed constructions/current plans; concrete and ordinary controls have zero preboxed plans. PB typed arms execute 128 actual selected batch entries. Metadata work is not credited as numerical kernel execution.

## Incremental evidence relative to the bounded anchor

Ratios below are recomputed medians of within-cycle candidate/anchor ratios. They are not quotients of the ordinary-control ratios.

| XP cohort / candidate vs bounded-only | Execution ratio | Complete ratio | Execution / complete wins |
|---|---:|---:|---:|
| Initial / heap | 1.112 | 1.064 | 0/4 ; 0/4 |
| Initial / heap + partition | 1.078 | 1.087 | 0/4 ; 0/4 |
| Combinations / bounded + heap | 1.020 | 1.038 | 1/4 ; 0/4 |
| Combinations / bounded + heap + partition | 0.987 | 1.040 | 3/4 ; 0/4 |
| Preboxed / preboxed | 1.181 | 1.182 | 0/4 ; 0/4 |
| Preboxed / preboxed + partition | 1.178 | 1.175 | 0/4 ; 0/4 |
| Preboxed / bounded + preboxed | 1.077 | 1.116 | 0/4 ; 0/4 |

The new mechanisms lower allocation volume but do not improve XP complete warm runtime over the existing bounded anchor. In the combinations cohort, bounded-all execution allocation is 5.921 MB versus 7.055 MB bounded-only and complete allocation is 11.227 MB versus 13.646 MB; complete time nevertheless loses all four pairs. In the preboxed cohort, bounded-preboxed execution allocation is 6.080 MB and complete allocation 11.271 MB, also slower than bounded-only in every complete pair. These allocation observations do not establish lower retained memory or peak RSS.

Partition-only has a small, inconsistent result across cohorts: initial ordinary-control execution/complete ratios 1.020/1.020, then 0.967/0.993 in the combinations screen. This is not a robust whole-run improvement. Removing measured boxing or repeated interpretation is real work reduction but is not by itself a runtime gain.

## Preboxed cohort and PB

Against its own ordinary XP control, preboxed-only execution/complete ratios are 1.061/1.079; bounded-preboxed is 0.939/1.005, versus bounded-only 0.871/0.892. The latter cohort has noticeable cycle variation; the direct bounded-anchor comparisons above are the appropriate interpretation. The zero-allocation property micro-check establishes that the specific getter boxing was removed, not that the growing simulation became faster.

PB typed-preboxed versus typed-only gives execution/complete ratios 0.979/0.974, winning all four pairs. This is a small promising signal in one short screen. Typed-preboxed retains the existing typed path's large execution gain over ordinary, but complete time is still 1.058× ordinary. Execution allocation increases from 114,800 to 122,992 bytes, while total allocation falls from 10.400 MB to 9.846 MB. Concrete typed-heap has no consistent incremental execution gain (1.012× typed-only, two wins), though its complete ratio is 0.985 with three wins. None of these small PB increments establishes broad scaling or a new large speedup.

Two fresh cold bounded/preboxed observations can test a distinct preparation hypothesis, but should remain separate from these paired warm results. No larger XP screen is justified by the current warm evidence.
