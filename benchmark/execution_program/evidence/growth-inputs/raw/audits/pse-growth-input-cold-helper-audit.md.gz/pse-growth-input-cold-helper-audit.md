# GrowthInputColdCase source-only first-use review

No false scientific warmup found. Loading the module defines functions/constants
and imports PSE/SHA only; it does not construct a fixture, run a model, sample an
environment or query scientific IR. Expected-source hashing reads bytes only.
The prototype method-file checks list definitions and do not infer/execute model
methods. Imports/definition-loader cost is outside the four measured case phases
and reported separately; external import time is optional and not fabricated.

The case uses the existing DirectPlanner `_timed`/`_phase` functions for fresh
construction, GrowthInputMeasurements preparation, first step and remaining step.
Those callbacks cross invokelatest within each timer, preventing the outer cold
wrapper from specializing on a constructed Simulation family before timing.
`_case` itself is entered through invokelatest after all includes, avoiding method
world-age issues from definitions loaded by the helper.

Fresh construction passes no shared weather; the original XP constructor reads
its forcing inside construction. All snapshots, copied scientific RNG draws,
digest comparisons, work/coverage and full package provenance occur only after
both execution phases. Source bytes are checked before loading definitions and
again after the case. PSE source/pkgdir, active project, helper method file and
prototype entrypoint method files must identify the expected image.

Measured-cohort clarification: root promoted the initial 9046-byte helper, SHA
`5d1136db70481eafefb17b6a6a07d926cf7a00645fbd6fd39b17b6404b9c515b`, before
the final draft added the helper's own method-file assertion and a friendly
active-project-none check. The measured version still verifies actual PSE
source/pkgdir, active project, prototype method files, and all 15 expected file
hashes including the promoted helper. Root includes that exact Native file.
Its XP-specific forcing label is accurate for both selected XP-only cases.
The later tmp draft is SHA
`3be80a02a3e3e34879d58c18a14f24f286cfee94170c01ee2f882362ccf51d6b`.
The timing/constructor/preparation/execution/digest logic is byte-equivalent
between those drafts. These extra guards do not invalidate the measured cohort
and do not warrant another scientific run. The Native source remains frozen.

Freshness needs the explicit caller attestation plus new worker PID, this
module's one-run counter and zero existing DirectPlanner/shared harness counters.
Those counters cannot detect an arbitrary manually executed scientific kernel;
the receipt says caller attestation rather than claiming automatic purity proof.
Do not test run_case in an already used warm worker. Definition parsing/loading
and source checks alone are safe there; actual first-use samples require fresh
workers and the same externally computed expected file hashes.

The expected image includes the promoted cold helper itself, so copy the final
draft to Native before fingerprinting it outside Julia. Root should pass the
working checkout root explicitly. A changed Project/Manifest during worker setup
will fail the hash guard cheaply rather than yield a qualified timing. Use a
two-step baseline digest for the two-step candidate; a four-day warm digest is a
different configuration. Compilation counters are reported by phase and must
not be added to wall time or treated as disjoint wall-clock partitions.

## Correction after the first actual cold trial

The source-only review above was incomplete: I checked `_case`'s latest-world
entry but missed the outer provenance expression resolving imported Main
bindings after the definition loader. Actual worker PID61856 failed after all
timed science and post-case diagnostics, at the outer tuple construction using
`Main.PlantBiophysics`. The receipt reports `UndefVarError`, running world39337
while current world44095. The stage log reaches `after_diagnostics` at
2026-10-31T16:16:03.454. This failed attempt remains excluded; no complete cold
record is reconstructed or promoted from its partial receipts.

Evidence is retained in
`results/growth-input/receipts/cold-bounded-20261031T161331-08-check_eval.json`,
the PID61856 stage log, and `source-before-cold-worldage-fix/` with the original
9046-byte helper/image. This observed failure supersedes any earlier implication
that the entire helper had no world-age issue; it does not imply a scientific
kernel or prototype correctness failure.

Root's actual correction wraps the entire provenance closure in
`Base.invokelatest() do ... end`, resolving both the newly imported Main package
bindings and the provenance function in the latest world. Merely wrapping a
call whose arguments were already resolved in the old world would not fix it.
The corrected helper is 9349 bytes, SHA
`3d68983c59ebaa8d259d6ddc1d19b263ec7ca33afd33b64a6a70e0385124943c`.
Both retry arms must use that same corrected image.

Post-loader read audit: `_load_definitions` runs in the latest world; `_case`
also enters the latest world before reading its H/G/F/CR bindings and executing
new methods. The remaining outer H/M counter reads actually completed in the
failed trial and were not its blocker. PSE and SHA/JSON bindings were available
before the helper was defined; source checks and file writing use those older
bindings. The newly imported downstream Main package names now occur only
inside the latest-world provenance closure. No further source-level blocker was
found, but actual fresh execution, not this audit, qualifies the retry.

This addendum records a meaningful review error and the observed fix without
removing the original source assessment. No Julia was run or Native/core source
changed by this reviewing agent.
