# Preboxed cold application-plan payloads

The concrete heap-plan screen reduced execution allocation but did not improve
the short XP runtime/complete ratios. The erased getter diagnostic identifies a
remaining mechanism: ordinary `.plan` access allocated 448 B/lookup and concrete
heap `.plan` access zero, while `.spec` still allocated 368 B/lookup in both.
These are warmed diagnostic loops, not whole-application speed evidence.

The follow-on `payload=:preboxed` mode retains the same ten readonly fields and
six original type parameters, but stores the six non-scalar metadata payloads
(`spec`, selector, matcher, timestep, clock, overrides) in Any fields once.
Scalar slot/id/process/name fields retain their original declared types. The
factory forwards the same original args; mutable scientific objects/references
are shared exactly as before, not copied, sampled or frozen by value. Phantom
parameters preserve the original argument type descriptors while ordinary
execution batches continue deriving concrete scientific model/status/carrier
types from the actual values.

Mode is private per model and fixed at first enablement. Default `:concrete`
behavior is preserved. The exact previous storage source is saved in
`results/growth-input/source-before-prebox/`. Preboxed results are a new source
cohort and cannot be pooled into the earlier concrete-heap timing screen.

Falsification: first check all const fields, exact supplied object/value/type
identity, callbacks, declarations, lifecycle/initializer/temporal/distributed
behavior and full state/history/RNG/reference parity. Require preboxed factory
and current-row counts, not merely the broad heap totals. Then verify erased
spec/property allocation falls without numerical batch type erasure. Finally
compare a short XP same-source warm screen (including bounded+preboxed if
promising), charging enablement/preparation and checking timed JIT. Reject a
whole-run claim if extra dynamic metadata dispatch offsets the eliminated boxes.
Nested immutable fields inside ModelSpec can still box; the prototype does not
claim to eliminate every NamedTuple allocation or retained-memory cost.
