# Shared heap application-plan prototype: source audit

`GrowthPlanStorage.HeapApplicationPlan` mirrors the ten field names/types and
six type parameters of `CompiledApplicationPlan`; every field binding is const.
A source-only comparison verified this exact correspondence. Constructor args
are the ordinary original args, with no model/status/default/source copies.
The per-model opt-in factory leaves ordinary controls on the original type.

No methods or metadata containers restricted to `CompiledApplicationPlan` were
found in `src`: usages are constructors/exports. `CompiledModelApplication{P}`
is already generic. Its property access forwards to plan fields generically.
Normal lifecycle and targeted application-shell construction reuse `.plan`,
including `_partial_model_application`, added/rewired applications and dirty
object environment refresh. They therefore share the same heap identity.
The graph-editor fallback can remain on the ordinary constructor.

The relevant tested contract is plan `===` identity across additions/removals,
scenario-plan sharing, fixed field names and readonly application.plan ownership.
An internal test currently asserts `!ismutabletype(typeof(application_plan))`;
for the opted-in type replace that representation assertion with all fields
const and failed field-reassignment checks. Nested model, selector, clock or
override objects retain their previous semantics: const field bindings do not
claim that an entire reachable object graph is immutable.

No plan-keyed Dict/Set/hash use or assignments to application-plan fields were
found. A full recompile constructs a new heap identity, which is appropriate for
guards that must reject an old compilation's metadata. This does not establish
arbitrary external code compatibility with the exported concrete type; the
prototype intentionally remains opt-in.

The rationale differs from input partition reuse. Ordinary application shells
embed an immutable plan payload; erased `.plan` extraction and repeated partial
shell construction can box/copy it. Heap storage keeps one metadata object and a
typed reference in each shell. Existing bounded containers separately replace
scenario-wide NamedTuples and per-application input-plan Tuples, so test heap-only,
bounded-only and both to identify overlapping/allocation benefits. Heap storage
will not by itself remove immutable ModelSpec/default NamedTuple boxing when
those fields are extracted dynamically.

Falsify with a tiny generic case before XP: full bindings/reference identity,
state/history/RNG parity and stable shared plan identity across growth;
all-const field checks; actual heap factory counts; allocations at the previously
observed plan-boxing sites. Then compare a short original XP growth run with the
same-source unenabled control, separately charging initial heap allocation and
checking warm numerical execution. Do not infer a complete win merely because
CompiledApplicationPlan boxes disappear or application shell sizeof falls.
