# GrowthInputMeasurements source review

No source-level blocker found before the first small timing screen. Reviewed
`growth_input_measurements.jl` and the shared DirectPlanner fixture/measurement
helpers; no Julia was run and no harness source was changed.

The default arms distinguish reference, partition, heap, heap+partition, old
bounded containers, bounded+heap and all three mechanisms. The old bounded arm
does not enable the new cold-planner boundary policy. Optional typed arms select
the existing direct driver independently. All flag enablement occurs inside the
measured preparation callback before initial logical compilation.

The measurement helper invokes construct/prepare/lower/execute through dynamic
callback boundaries and keeps scientific snapshots/reports after execution.
There is no generator combining concrete Simulation families. XP weather is read
at registration, copied by the original fixture into every independently built
model, and original deterministic model/tree/RNG construction repeats per sample.
PB likewise creates independent original models and forcing. Complete cost
includes construction and every enabled preparation step. This is a warm screen,
with one warmup per arm and forward/reverse order; timed JIT/GC must still be
checked before interpreting small ratios.

Coverage separates metadata operations from actual numerical driver entries and
checks each policy is absent from its controls. Heap requires actual factory
work/current heap plans; partition requires validated nonempty partition hits.
These counters are lifetime preparation+execution totals, so a positive value
alone does not establish growth-only work or a kernel speedup. In particular,
the observed PB partition report has no appended bindings and the observed XP
report has zero singleton dispatches. XP currently tests ordered-group partition
reuse, not the NoCompiledDistributedOutputs singleton shortcut. Do not credit
that unentered shortcut. Per-growth counter deltas/profile companions establish
where the metadata work occurs.

Correctness gates must retain outputs=:all separately; outputs=:none timed
screens compare the full retained state/topology/RNG and the streams retained by
that request, not histories that were deliberately disabled. The existing
feature/declaration/initializer/distributed gates are the history/aliasing oracle.

Suggested economical sequence: after checks, screen reference/partition/heap/
heap_partition over the existing four-day XP case with two balanced cycles and
inspect allocations, complete cost and timed JIT. Include bounded-only as an
anchor if its compiled scenario type is already warm. If heap is promising,
finish the requested seven-arm four-cycle screen to test bounded+heap and
bounded_all. Seven short arms are reasonable once warmed; increasing biological
duration is not necessary. For PB, small parity checks first, then an optional
three-arm 32×128 screen (reference, existing typed driver, typed+heap) tests that
the metadata representation does not regress the previously useful hot path.

All improvement claims remain same-source comparisons against the disabled hook
control. The common new hook/factory dispatch and any representation-dependent
JIT effects are shared experiment infrastructure, not evidence for a gain versus
an earlier production revision without a separate control.
