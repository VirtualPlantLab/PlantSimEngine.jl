# Growth input plan partition prototype

The prior qualified four-day XP profile measured input-binding refresh as the
largest logical-extension subphase (roughly 0.9–1.2 ms/day). It did not split
selector resolution from carrier/default/validation work. The following is a
source-based hypothesis, not an attributed or measured speedup.

`_compile_added_consumer_bindings!` processes each consumer by counting explicit
Many plans, scanning explicit plans, allocating a processed-input Set, and for
each inferred input scanning the entire plan collection again into a fresh
matching-plan vector. The immutable plan layout repeats across organs and
targeted preparation/barrier invocations. A singleton inferred group without
distributed outputs does not need a vector to select its sole live candidate.

`GrowthInputReuse` caches the explicit indices and ordered inferred-input index
groups. Its guard checks the current sequence of `(origin,input,is_many)` tags,
the only fields affecting that partition. All actual plans are read from the
current argument. Source selectors, memberships, producer ownership, policies,
reference carriers, sharing and subsequent defaults/required-input validation
remain ordinary. A singleton's writer is checked on every invocation, including
after a previous no-match. The cache contains no models/plans/defaults/carriers,
scientific references or negative membership results. Unsupported containers
decline the hook before appending anything.

API: `enable_growth_input_reuse!(model)` before initial compilation;
`growth_input_reuse_report(model_or_sim)`. It is independent of direct execution
plans, bounded metadata containers and cold-planner boundary flags.

Small falsification gates:

1. Compare ordinary/candidate full bindings and source IDs, canonical reference
   identity and reference transitions, Float32/heterogeneous Many behavior,
   defaults/conversion callbacks, temporal policies, initializers and full
   state/history/topology/RNG. Exercise absent→present source membership,
   removal/reparenting, distributed final ownership, ambiguous producer errors,
   and changed plan shape. Error ordering and messages should match ordinary.
2. Require `partition_hits>0` and `singleton_binding_dispatches>0` on a relevant
   nonempty workload. Report empty consumers separately. No candidate claim is
   allowed from skipped empty work or prepared rows alone.
3. Attribute the input phase before extrapolating. Compare one small existing
   XP growth fixture with flags off/on on identical source, charging recipe
   construction and validation overhead. Compare binding-phase and complete
   execution allocations/time separately; retain first-use/steady-state
   distinctions. Stop expansion if complete execution regresses or recipe
   lookup/shape checks cost more than the removed grouping/allocations.

This does not repeat the event-owned newborn binding promotion cache. The prior
cache's epoch/reference stamps and promotion overhead were not beneficial; no
such cache, stamps or already-resolved bindings are used here. Schema/default
value caching remains deferred pending the new phase attribution.
