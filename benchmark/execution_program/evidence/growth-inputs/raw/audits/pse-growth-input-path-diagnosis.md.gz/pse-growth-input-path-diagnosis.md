# XP growth input refresh: source diagnosis and initial profile

Source-only review in the prototype worktree; Julia execution belongs to root. The initial `results/growth-input/baseline-input-profile.json` and its exact profiler source are preserved. The enhanced source is a separate diagnostic revision, not an optimization.

## Actual path

`_extend_compiled_scene` first updates existing dynamic input memberships/carriers, then calls `_compile_added_consumer_bindings!` for new application/object targets. That helper handles explicit plans first, then inferred inputs in first-occurrence order, and filters current writer ownership before resolving each binding. `_push_model_input_binding!` performs current object selection, producer selection/final-owner filtering, policy selection, carrier construction and source validation. The resulting bindings are shared/indexed, their final canonical references are assembled, defaults and wiring are applied in a batched status recipe, then required inputs are validated. Targeted newborn calls run a similar preparation before the global barrier; they also prepare output defaults and environment/context metadata.

These are distinct costs. A selector lookup stack must not be assumed to be an input lookup merely because `_extend_compiled_scene` is an ancestor; call/output dependency work shares that parent. Likewise input/output default preparation shares status-recipe helpers. The profiler now uses explicit parent guards and separates other dependency/output metadata.

## Initial measured limit

The first root-run profile has 107 selected CPU samples and 4,626 allocation records. Default-schema projection accounts for only about 0.3% of sampled allocation bytes and one CPU sample. That is insufficient support for prioritizing a new Default projection, even though `_input_default_values` visibly builds a `Pair{Symbol,Any}` vector. Its theoretical allocation removal should not be confused with a meaningful whole-run gain.

The larger unknown category contains sampled NamedTuple allocation attributed only to the global-refresh parent. Binding assembly also includes NamedTuple, Tuple and CompiledModelInputPlan allocation. Those observations motivate allocation sites and PSE-only stack previews before deciding whether the cost is actual container construction, boxing of immutable metadata, or interpretation overhead. Broad typename/category alone cannot identify that cause.

## Bounded diagnostic

`GrowthInputProfile.profile_growth_input_allocations` performs a separate allocation-only run on fresh independent scenes after an unprofiled oracle. Top allocation sites retain nearest leafward PSE source function/file/line, broad typename, sampled count/bytes and up to eight PSE source frames. CPU summaries include previously unclassified PSE frames. No method instance/type-parameter printer, core method override, persistent scientific cache or numerical kernel change is installed. All scientific state/history/topology/RNG, work and canonical identity transitions must still match.

## Falsifiable candidates

1. **Input-plan partition reuse:** the independently implemented GrowthInputReuse cache stores only input/origin/Many tags and integer group indices. It can avoid the per-consumer processed-input Set, repeated scans of inferred plans and a singleton match vector. Live plans still resolve every source/writer/policy/carrier, and distributed ownership uses the original general path. Source audit found ordering and no-match-to-match behavior consistent with ordinary execution. Qualification must show nonempty group/binding work and reduced relevant allocation sites, then paired complete/execution gains against the same-source disabled-hook control. Empty-consumer hits alone are not useful evidence.
2. **Default projection / empty-default loop:** defer unless the finer profile changes the initial result. A typed projection must read the current Default values without retaining them, preserving mutable defaults and parameter-dependent schemas; uncertain declaration types require the ordinary path. Skipping per-target default lookup must preserve creation/validation of a missing or invalid Status even when defaults are empty, while retaining carrier wiring and required validation. A guard that silently removes that semantic work is not acceptable.

Any exact extra timers should bracket whole existing-membership update, new-binding assembly, index/reference assembly, batched defaults/wiring and required validation loops. Avoid timer branches per binding until sampling justifies them. Existing phase timers nest; profiler timing is not a candidate benchmark.
