module AMAPSimMakieExt

using AMAPSim
import Makie
import MultiScaleTreeGraph
import PlantGeom

import AMAPSim: AMAPSimTopology, GeneratedPlant, visualize
using MultiScaleTreeGraph: Node

_visualization_root(topology::AMAPSimTopology) = topology.scene
_visualization_root(node::Node) = MultiScaleTreeGraph.get_root(node)

"""
    visualize(plant; reconstruct_geometry=true, geometry_options=NamedTuple(), kwargs...)

Visualize an `AMAPSimTopology` or an ordinary MTG node through
`PlantGeom.plantviz`. By default, rebuild AMAPSim internode geometry first.
Pass `reconstruct_geometry=false` to render geometry already stored on the MTG,
or pass `build_geometry!` keywords in `geometry_options`.
"""
function visualize(
    plant::Union{AMAPSimTopology,Node};
    reconstruct_geometry::Bool=true,
    geometry_options::NamedTuple=NamedTuple(),
    kwargs...,
)
    if reconstruct_geometry
        AMAPSim.build_geometry!(plant; geometry_options...)
    end
    return PlantGeom.plantviz(_visualization_root(plant); kwargs...)
end

"""
    visualize(result::GeneratedPlant; reconstruct_geometry=true,
              geometry_options=NamedTuple(), kwargs...)

Visualize a generated plant while using its retained parameter set by default
when geometry is reconstructed. Explicit entries in `geometry_options` are
forwarded to `AMAPSim.build_geometry!`.
"""
function visualize(
    result::GeneratedPlant;
    reconstruct_geometry::Bool=true,
    geometry_options::NamedTuple=NamedTuple(),
    kwargs...,
)
    if reconstruct_geometry
        AMAPSim.build_geometry!(result; geometry_options...)
    end
    return PlantGeom.plantviz(_visualization_root(result.topology); kwargs...)
end

end
