module AMAPSimBonitoExt

using AMAPSim
using Bonito
import PlantSimEngine
import TOML

import AMAPSim: editor_scene, editor_toml, load_editor_toml!, scene_editor

const PANEL_STYLE = "background:#ffffff;border:1px solid #dbe5df;border-radius:14px;" *
                    "box-shadow:0 8px 24px rgba(22,67,45,.07);padding:1.1rem;"
const GRID_STYLE = "display:grid;grid-template-columns:repeat(auto-fit,minmax(19rem,1fr));" *
                   "gap:1rem;align-items:start;"
const FIELD_STYLE = "display:grid;gap:.3rem;margin:.55rem 0;color:#173d2a;font-size:.9rem;"
const INPUT_STYLE = Bonito.Styles(
    "box-sizing" => "border-box",
    "width" => "100%",
    "padding" => ".5rem .65rem",
    "border" => "1px solid #aebfb5",
    "border-radius" => "7px",
    "background" => "#fff",
    "color" => "#183b2b",
)

struct NativeSceneEditor{A,S,T,E,D,R,C,M,SV}
    app::A
    scene::S
    source::T
    draft::T
    error::E
    dirty::D
    registry::R
    controls::C
    messages::M
    saved_source::SV
    readonly::Bool
end

function _scene_toml(scene, registry)
    io = IOBuffer()
    AMAPSim.write_native_scene(io, scene; registry)
    return String(take!(io))
end

function _error_text(error)
    message = sprint(showerror, error)
    return isempty(message) ? string(typeof(error)) : message
end

function _validate_scene(scene, registry)
    AMAPSim.compile_scene(scene)
    return _scene_toml(scene, registry)
end

function _commit_candidate!(
    scene_observable,
    source_observable,
    draft_observable,
    saved_source,
    dirty,
    global_error,
    local_error,
    registry,
    candidate_builder,
)
    try
        candidate = candidate_builder()
        canonical = _validate_scene(candidate, registry)
        scene_observable[] = candidate
        source_observable[] = canonical
        draft_observable[] = canonical
        dirty[] = canonical != saved_source[]
        local_error[] = ""
        global_error[] = ""
        return true
    catch error
        message = _error_text(error)
        local_error[] = message
        global_error[] = message
        return false
    end
end

function _load_source!(
    scene_observable,
    source_observable,
    draft_observable,
    saved_source,
    dirty,
    global_error,
    local_error,
    registry,
    source,
)
    text = String(source)
    draft_observable[] = text
    dirty[] = text != saved_source[]
    try
        candidate = AMAPSim.read_native_scene(
            IOBuffer(text);
            registry,
            source="Bonito editor draft",
        )
        canonical = _validate_scene(candidate, registry)
        scene_observable[] = candidate
        source_observable[] = canonical
        draft_observable[] = canonical
        saved_source[] = canonical
        dirty[] = false
        local_error[] = ""
        global_error[] = ""
        return true
    catch error
        message = _error_text(error)
        local_error[] = message
        global_error[] = message
        return false
    end
end

editor_scene(editor::NativeSceneEditor) = editor.scene[]
editor_toml(editor::NativeSceneEditor; draft::Bool=false) =
    draft ? editor.draft[] : editor.source[]

function load_editor_toml!(editor::NativeSceneEditor, source::AbstractString)
    editor.readonly && throw(ArgumentError("a read-only scene editor cannot load TOML"))
    return _load_source!(
        editor.scene,
        editor.source,
        editor.draft,
        editor.saved_source,
        editor.dirty,
        editor.error,
        editor.messages.source,
        editor.registry,
        source,
    )
end

function _templates(scene)
    templates = Dict{Symbol,AMAPSim.PlantTemplate}()
    for plant in scene.plants
        templates[plant.template.id] = plant.template
    end
    return sort!(collect(values(templates)); by=template -> string(template.id))
end

function _template(scene, identifier)
    id = Symbol(identifier)
    match = findfirst(template -> template.id == id, _templates(scene))
    match === nothing && throw(ArgumentError("unknown plant template $(repr(id))"))
    return _templates(scene)[match]
end

function _plant(scene, identifier)
    id = Symbol(identifier)
    match = findfirst(plant -> plant.id == id, scene.plants)
    match === nothing && throw(ArgumentError("unknown plant instance $(repr(id))"))
    return match, scene.plants[match]
end

function _scene_with(scene; plants=scene.plants)
    return AMAPSim.SceneDefinition(;
        plants,
        objects=scene.objects,
        applications=scene.applications,
        environment=scene.environment,
    )
end

function _instance_with_template(plant, template)
    return AMAPSim.PlantInstance(
        plant.id,
        template;
        initialization=plant.initialization,
        seed=plant.seed,
        overrides=plant.overrides,
        object_overrides=plant.object_overrides,
    )
end

function _replace_template(scene, template)
    plants = map(scene.plants) do plant
        plant.template.id == template.id ? _instance_with_template(plant, template) : plant
    end
    return _scene_with(scene; plants)
end

function _template_with(
    template;
    axis_categories=template.axis_categories,
    initial_axis_category=template.initial_axis_category,
    applications=template.applications,
)
    return AMAPSim.PlantTemplate(
        template.id;
        axis_categories,
        initial_axis_category,
        initiation=template.initiation,
        applications,
        species=template.species,
        initialization=template.initialization,
        parameters=template.parameters,
    )
end

function _integer(value, label)
    value isa Real && isfinite(value) && isinteger(value) || throw(ArgumentError(
        "$label must be an integer",
    ))
    return Int(value)
end

function _seed(value)
    parsed = tryparse(UInt64, strip(String(value)))
    parsed === nothing && throw(ArgumentError(
        "plant seed must be an integer between zero and typemax(UInt64)",
    ))
    return parsed
end

function _parameter_values(source)
    text = strip(String(source))
    isempty(text) && return NamedTuple()
    table = TOML.parse(text)
    return AMAPSim._toml_table_named_tuple(table, "editor model parameters")
end

function _application_model(registry, reference, parameter_source)
    startswith(String(reference), "(") && throw(ArgumentError(
        "no registry-backed PlantSimEngine application model is available",
    ))
    return AMAPSim._construct_registered_model(
        registry,
        String(reference),
        _parameter_values(parameter_source),
        PlantSimEngine.AbstractModel,
        "Bonito editor application",
    )
end

function _selector(entity, category)
    category_text = strip(String(category))
    selected_category = isempty(category_text) ? nothing : Symbol(category_text)
    entity == "plant" && return AMAPSim.Plant()
    entity == "axis" && return AMAPSim.Axes(; category=selected_category)
    entity == "apical meristem" && return AMAPSim.ApicalMeristems(
        bearer=AMAPSim.Axes(; category=selected_category),
    )
    entity == "growth unit" && return AMAPSim.GrowthUnits(
        axis=AMAPSim.Axes(; category=selected_category),
    )
    entity == "leaf" && return AMAPSim.Leaves(
        axis=AMAPSim.Axes(; category=selected_category),
    )
    throw(ArgumentError("unsupported botanical selector $(repr(entity))"))
end

function _replace_or_append_application(template, application)
    position = findfirst(candidate -> candidate.name == application.name, template.applications)
    applications = if position === nothing
        (template.applications..., application)
    else
        ntuple(length(template.applications)) do index
            index == position ? application : template.applications[index]
        end
    end
    return _template_with(template; applications)
end

function _replace_plant(scene, position, plant)
    plants = ntuple(length(scene.plants)) do index
        index == position ? plant : scene.plants[index]
    end
    return _scene_with(scene; plants)
end

_application_references(registry) = [
    record.reference for record in AMAPSim.registered_models(registry)
    if record.model_type <: PlantSimEngine.AbstractModel
]

function _field(label, widget; hint=nothing)
    content = Any[Bonito.DOM.span(label; style="font-weight:650;") , widget]
    hint === nothing || push!(content, Bonito.DOM.small(hint; style="color:#60756a;"))
    return Bonito.DOM.label(content...; style=FIELD_STYLE)
end

function _feedback(observable)
    return Bonito.DOM.div(
        observable;
        style=map(
            message -> isempty(message) ?
                       "display:none;" :
                       "display:block;margin-top:.6rem;padding:.55rem .7rem;border-radius:7px;" *
                       "background:#fff0ec;color:#8a2d20;border:1px solid #f3b7aa;",
            observable,
        ),
        dataTestId="editor-validation",
    )
end

function _badge(text, color)
    return Bonito.DOM.span(
        text;
        style="display:inline-block;margin:.12rem .25rem .12rem 0;padding:.18rem .48rem;" *
              "border-radius:999px;background:$color;color:#173d2a;font-size:.75rem;font-weight:700;",
    )
end

function _model_label(model, registry)
    try
        return AMAPSim._registered_model_record(registry, model, "editor view").reference
    catch
        return "$(typeof(model)) (script-only)"
    end
end

function _template_card(template, registry)
    categories = Bonito.DOM.ul(
        (Bonito.DOM.li(
            "$(category.id) — initial physiological age " *
            "$(category.initial_physiological_age)",
        ) for category in template.axis_categories)...;
        style="margin:.45rem 0;padding-left:1.2rem;",
    )
    applications = isempty(template.applications) ?
                   Bonito.DOM.p("No template applications."; style="color:#60756a;") :
                   Bonito.DOM.div((Bonito.DOM.div(
                       _badge("template default", "#d9efe3"),
                       Bonito.DOM.code(String(application.name)),
                       " · ",
                       _model_label(application.model, registry),
                   ) for application in template.applications)...)
    return Bonito.DOM.div(
        Bonito.DOM.h3(String(template.id); style="margin:.1rem 0;color:#0f5232;"),
        Bonito.DOM.p(
            template.species === nothing ? "No species convention" : "Species: $(template.species)";
            style="margin:.25rem 0;color:#60756a;",
        ),
        Bonito.DOM.strong("Axis categories"),
        categories,
        applications;
        style=PANEL_STYLE,
        dataTestId="template-card",
    )
end

function _plant_card(plant, registry)
    overrides = isempty(plant.overrides) ?
                Bonito.DOM.p("No instance overrides."; style="color:#60756a;") :
                Bonito.DOM.div((Bonito.DOM.div(
                    _badge("instance override", "#ffe6b8"),
                    Bonito.DOM.code(String(name)),
                    " · ",
                    _model_label(model, registry),
                ) for (name, model) in pairs(plant.overrides))...)
    object_overrides = isempty(plant.object_overrides) ?
                       Bonito.DOM.p("No object overrides."; style="color:#60756a;") :
                       Bonito.DOM.div((Bonito.DOM.div(
                           _badge("object override · script-only", "#ffd5cf"),
                           Bonito.DOM.code(String(override.application)),
                           " on ",
                           string(override.object),
                       ) for override in plant.object_overrides)...)
    return Bonito.DOM.div(
        Bonito.DOM.h3(String(plant.id); style="margin:.1rem 0;color:#5f3d08;"),
        Bonito.DOM.p("Template: $(plant.template.id) · seed: $(plant.seed)"),
        overrides,
        object_overrides;
        style=PANEL_STYLE,
        dataTestId="plant-card",
    )
end

function _overview(scene, registry)
    templates = _templates(scene)
    return Bonito.DOM.div(
        Bonito.DOM.h2("Current valid scene"; style="color:#123f2b;"),
        Bonito.DOM.p(
            "$(length(scene.plants)) plant(s), $(length(templates)) reusable template(s). " *
            "The cards below make model ownership explicit.",
        ),
        Bonito.DOM.div(
            (_template_card(template, registry) for template in templates)...;
            style=GRID_STYLE,
        ),
        Bonito.DOM.h2("Plant instances"; style="color:#123f2b;margin-top:1.4rem;"),
        Bonito.DOM.div(
            (_plant_card(plant, registry) for plant in scene.plants)...;
            style=GRID_STYLE,
        ),
    )
end

function _parameter_description(name, specification)
    required = AMAPSim._parameter_is_required(specification) ? "required" :
               "default=$(repr(specification.default))"
    bounds = Any[]
    specification.minimum === nothing || push!(bounds, "min=$(specification.minimum)")
    specification.maximum === nothing || push!(bounds, "max=$(specification.maximum)")
    specification.allowed === nothing || push!(bounds, "allowed=$(specification.allowed)")
    suffix = isempty(bounds) ? "" : ", " * join(bounds, ", ")
    return "$(name)::$(specification.value_type) — $required$suffix"
end

function _registry_panel(registry)
    application_models = [
        record for record in AMAPSim.registered_models(registry)
        if record.model_type <: PlantSimEngine.AbstractModel
    ]
    cards = if isempty(application_models)
        (Bonito.DOM.p(
            "No registry-backed application model is available. Register a model in Julia " *
            "before opening the editor.";
            style="color:#8a2d20;",
        ),)
    else
        Tuple(Bonito.DOM.div(
            Bonito.DOM.code(record.reference; style="font-weight:700;"),
            Bonito.DOM.ul((Bonito.DOM.li(_parameter_description(name, specification))
                for (name, specification) in pairs(record.parameters))...);
            style="margin-bottom:.65rem;",
        ) for record in application_models)
    end
    return Bonito.DOM.div(
        Bonito.DOM.h2("Registered model palette"; style="color:#123f2b;"),
        cards...,
        Bonito.DOM.h3("Explicitly unavailable"; style="margin-bottom:.3rem;"),
        Bonito.DOM.ul(
            Bonito.DOM.li("Heliotropism — no built-in implementation is registered."),
            Bonito.DOM.li("Biomechanical reorientation — no built-in implementation is registered."),
            Bonito.DOM.li("Live application-graph hot swapping — use a predeclared SwitchingModel or rebuild explicitly."),
        );
        style=PANEL_STYLE,
        dataTestId="registry-panel",
    )
end

function _editor_controls(scene, registry)
    template_names = Observable(Any[String(template.id) for template in _templates(scene[])])
    plant_names = Observable(Any[String(plant.id) for plant in scene[].plants])
    on(scene) do current
        template_names[] = Any[String(template.id) for template in _templates(current)]
        plant_names[] = Any[String(plant.id) for plant in current.plants]
    end

    template_category = (
        template=Dropdown(template_names),
        category=TextField("lateral"; style=INPUT_STYLE),
        age=NumberInput(2.0; style=INPUT_STYLE, min=1, step=1),
        apply=Button("Add or update category"; dataTestId="apply-category"),
    )
    new_template = (
        template=TextField("shade_tree"; style=INPUT_STYLE),
        species=TextField(""; style=INPUT_STYLE),
        category=TextField("root"; style=INPUT_STYLE),
        age=NumberInput(1.0; style=INPUT_STYLE, min=1, step=1),
        plant=TextField("shade_1"; style=INPUT_STYLE),
        x=NumberInput(2.0; style=INPUT_STYLE),
        y=NumberInput(0.0; style=INPUT_STYLE),
        z=NumberInput(0.0; style=INPUT_STYLE),
        apply=Button("Add template and first plant"; dataTestId="add-template"),
    )
    model_references = _application_references(registry)
    isempty(model_references) && push!(model_references, "(no registered application models)")
    application = (
        template=Dropdown(template_names),
        name=TextField("carbon_allocation"; style=INPUT_STYLE),
        model=Dropdown(model_references),
        parameters=TextField(""; style=INPUT_STYLE),
        selector=Dropdown(["plant", "axis", "apical meristem", "growth unit", "leaf"]),
        category=TextField(""; style=INPUT_STYLE),
        apply=Button("Add or update application"; dataTestId="apply-application"),
    )
    new_plant = (
        id=TextField("plant_2"; style=INPUT_STYLE),
        template=Dropdown(template_names),
        seed=TextField("0"; style=INPUT_STYLE),
        x=NumberInput(1.0; style=INPUT_STYLE),
        y=NumberInput(0.0; style=INPUT_STYLE),
        z=NumberInput(0.0; style=INPUT_STYLE),
        apply=Button("Add plant instance"; dataTestId="add-plant"),
    )
    override = (
        plant=Dropdown(plant_names),
        application=TextField("carbon_allocation"; style=INPUT_STYLE),
        model=Dropdown(model_references),
        parameters=TextField(""; style=INPUT_STYLE),
        apply=Button("Set instance override"; dataTestId="apply-override"),
    )
    return (; template_category, new_template, application, new_plant, override)
end

function _forms(controls, messages)
    category = controls.template_category
    template = controls.new_template
    application = controls.application
    plant = controls.new_plant
    override = controls.override
    return Bonito.DOM.div(
        Bonito.DOM.div(
            Bonito.DOM.h3("Axis category"),
            _field("Template", category.template),
            _field("Category identifier", category.category),
            _field("Initial physiological age", category.age),
            category.apply,
            _feedback(messages.category);
            style=PANEL_STYLE,
        ),
        Bonito.DOM.div(
            Bonito.DOM.h3("New heterogeneous template"),
            _field("Template identifier", template.template),
            _field("Species convention (optional)", template.species),
            _field("Initial category", template.category),
            _field("Initial physiological age", template.age),
            _field("First plant identifier", template.plant),
            Bonito.DOM.div(
                _field("X", template.x), _field("Y", template.y), _field("Z", template.z);
                style="display:grid;grid-template-columns:repeat(3,1fr);gap:.4rem;",
            ),
            template.apply,
            _feedback(messages.template);
            style=PANEL_STYLE,
        ),
        Bonito.DOM.div(
            Bonito.DOM.h3("Template application"),
            _field("Template", application.template),
            _field("Stable application name", application.name),
            _field("Registered model", application.model),
            _field("Model parameters (TOML fields)", application.parameters;
                hint="Example: fraction = 0.25"),
            _field("Botanical selector", application.selector),
            _field("Axis category (optional)", application.category),
            application.apply,
            _feedback(messages.application);
            style=PANEL_STYLE,
        ),
        Bonito.DOM.div(
            Bonito.DOM.h3("Plant instance"),
            _field("Plant identifier", plant.id),
            _field("Template", plant.template),
            _field("Deterministic seed", plant.seed),
            Bonito.DOM.div(
                _field("X", plant.x), _field("Y", plant.y), _field("Z", plant.z);
                style="display:grid;grid-template-columns:repeat(3,1fr);gap:.4rem;",
            ),
            plant.apply,
            _feedback(messages.plant);
            style=PANEL_STYLE,
        ),
        Bonito.DOM.div(
            Bonito.DOM.h3("Plant-local model override"),
            _field("Plant", override.plant),
            _field("Application name", override.application),
            _field("Registered replacement", override.model),
            _field("Model parameters (TOML fields)", override.parameters),
            override.apply,
            _feedback(messages.override);
            style=PANEL_STYLE,
        );
        style=GRID_STYLE,
    )
end

function _wire_callbacks!(
    scene,
    source,
    draft,
    saved_source,
    dirty,
    error,
    registry,
    controls,
    messages,
)
    commit(builder, message) = _commit_candidate!(
        scene, source, draft, saved_source, dirty, error, message, registry, builder,
    )

    on(controls.template_category.apply) do _
        commit(messages.category) do
            current = scene[]
            selected = _template(current, controls.template_category.template.value[])
            identifier = Symbol(strip(controls.template_category.category.value[]))
            age = _integer(controls.template_category.age.value[], "initial physiological age")
            position = findfirst(category -> category.id == identifier, selected.axis_categories)
            categories = position === nothing ?
                         (selected.axis_categories..., AMAPSim.AxisCategory(
                             identifier; initial_physiological_age=age,
                         )) :
                         ntuple(length(selected.axis_categories)) do index
                             index == position ? AMAPSim.AxisCategory(
                                 identifier; initial_physiological_age=age,
                             ) : selected.axis_categories[index]
                         end
            _replace_template(current, _template_with(selected; axis_categories=categories))
        end
    end

    on(controls.new_template.apply) do _
        commit(messages.template) do
            current = scene[]
            template_id = Symbol(strip(controls.new_template.template.value[]))
            any(candidate -> candidate.id == template_id, _templates(current)) &&
                throw(ArgumentError("plant template $(repr(template_id)) already exists"))
            species_text = strip(controls.new_template.species.value[])
            category = AMAPSim.AxisCategory(
                strip(controls.new_template.category.value[]);
                initial_physiological_age=_integer(
                    controls.new_template.age.value[],
                    "initial physiological age",
                ),
            )
            template = AMAPSim.PlantTemplate(
                template_id;
                axis_categories=(category,),
                species=isempty(species_text) ? nothing : Symbol(species_text),
            )
            plant = AMAPSim.PlantInstance(
                strip(controls.new_template.plant.value[]),
                template;
                position=(
                    controls.new_template.x.value[],
                    controls.new_template.y.value[],
                    controls.new_template.z.value[],
                ),
            )
            _scene_with(current; plants=(current.plants..., plant))
        end
    end

    on(controls.application.apply) do _
        commit(messages.application) do
            current = scene[]
            selected = _template(current, controls.application.template.value[])
            application = AMAPSim.Apply(
                controls.application.name.value[],
                _application_model(
                    registry,
                    controls.application.model.value[],
                    controls.application.parameters.value[],
                );
                on=_selector(
                    controls.application.selector.value[],
                    controls.application.category.value[],
                ),
            )
            updated = _replace_or_append_application(selected, application)
            _replace_template(current, updated)
        end
    end

    on(controls.new_plant.apply) do _
        commit(messages.plant) do
            current = scene[]
            selected = _template(current, controls.new_plant.template.value[])
            plant = AMAPSim.PlantInstance(
                controls.new_plant.id.value[],
                selected;
                seed=_seed(controls.new_plant.seed.value[]),
                position=(
                    controls.new_plant.x.value[],
                    controls.new_plant.y.value[],
                    controls.new_plant.z.value[],
                ),
            )
            _scene_with(current; plants=(current.plants..., plant))
        end
    end

    on(controls.override.apply) do _
        commit(messages.override) do
            current = scene[]
            position, plant = _plant(current, controls.override.plant.value[])
            replacement = _application_model(
                registry,
                controls.override.model.value[],
                controls.override.parameters.value[],
            )
            updated = AMAPSim.replace_model(
                plant,
                controls.override.application.value[],
                replacement,
            )
            _replace_plant(current, position, updated)
        end
    end
    return controls
end

function _source_panel(
    draft,
    source,
    saved_source,
    dirty,
    error,
    registry,
    scene,
    messages,
)
    apply_button = Button("Validate and load TOML"; dataTestId="load-toml")
    save_button = Button("Mark current TOML saved"; dataTestId="save-toml")
    source_area = Bonito.DOM.textarea(;
        value=draft,
        rows=24,
        spellcheck="false",
        style="box-sizing:border-box;width:100%;font:13px/1.45 ui-monospace,monospace;" *
              "padding:.8rem;border:1px solid #aebfb5;border-radius:8px;",
        oninput=js"event => $(draft).notify(event.target.value)",
        dataTestId="toml-source",
    )
    status = map(dirty, error) do is_dirty, message
        if !isempty(message)
            return "Draft retained; current valid scene was not changed."
        end
        return is_dirty ? "Unsaved validated changes" : "Current TOML marked as saved"
    end
    on(apply_button) do _
        _load_source!(
            scene,
            source,
            draft,
            saved_source,
            dirty,
            error,
            messages.source,
            registry,
            draft[],
        )
    end
    on(save_button) do _
        saved_source[] = source[]
        draft[] = source[]
        dirty[] = false
        messages.source[] = ""
        error[] = ""
    end
    on(draft) do text
        dirty[] = text != saved_source[]
    end
    download = Bonito.DOM.button(
        "Download current TOML";
        style="padding:.45rem .75rem;border-radius:7px;border:1px solid #26764b;" *
              "background:#26764b;color:white;font-weight:700;cursor:pointer;",
        onclick=js"""() => {
            const blob = new Blob([$(source).value], {type: "text/plain;charset=utf-8"});
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = "amapsim-scene.toml";
            link.click();
            URL.revokeObjectURL(url);
        }""",
        dataTestId="download-toml",
    )
    return (
        panel=Bonito.DOM.div(
            Bonito.DOM.h2("Versioned native TOML"; style="color:#123f2b;"),
            Bonito.DOM.p(
                "The draft is parsed without evaluating Julia. Invalid text stays here while " *
                "the last valid scene remains available.",
            ),
            source_area,
            Bonito.DOM.div(apply_button, save_button, download),
            Bonito.DOM.p(status; style="font-weight:650;color:#4d6659;"),
            _feedback(messages.source);
            style=PANEL_STYLE,
        ),
        controls=(; source_area, apply=apply_button, save=save_button, download),
    )
end

"""
    AMAPSim.scene_editor(scene; registry=ModelRegistry(), readonly=false)

Build a Bonito v5 editor over the same immutable native definitions compiled by
AMAPSim. Guided edits are validated by reconstructing and compiling a candidate
scene before it replaces the current value. Model choices come only from the
supplied registry.

Set `readonly=true` for an exportable overview/help app. It contains no Julia
callbacks and remains useful in a static HTML export.
"""
function scene_editor(
    definition::AMAPSim.SceneDefinition;
    registry::AMAPSim.ModelRegistry=AMAPSim.ModelRegistry(),
    readonly::Bool=false,
)
    AMAPSim.compile_scene(definition)
    canonical = try
        _scene_toml(definition, registry)
    catch error
        readonly || rethrow()
        "# Native TOML export unavailable for this script-only scene.\n" *
        "# $(_error_text(error))\n"
    end
    # Guided edits routinely change concrete tuple and named-tuple parameters
    # (for example when a category or instance override is added). Keep the
    # observable typed to the abstract public definition so those valid
    # immutable reconstructions can replace one another.
    scene = Observable{AMAPSim.SceneDefinition}(definition)
    source = Observable(canonical)
    draft = Observable(canonical)
    saved_source = Observable(canonical)
    error = Observable("")
    dirty = Observable(false)
    messages = (
        category=Observable(""),
        template=Observable(""),
        application=Observable(""),
        plant=Observable(""),
        override=Observable(""),
        source=Observable(""),
    )
    controls = if readonly
        NamedTuple()
    else
        guided = _editor_controls(scene, registry)
        _wire_callbacks!(
            scene,
            source,
            draft,
            saved_source,
            dirty,
            error,
            registry,
            guided,
            messages,
        )
        guided
    end
    source_panel = readonly ? nothing : _source_panel(
        draft,
        source,
        saved_source,
        dirty,
        error,
        registry,
        scene,
        messages,
    )
    if !readonly
        controls = merge(controls, (; source=source_panel.controls))
    end
    overview = map(current -> _overview(current, registry), scene)
    app = App(; title="AMAPSim native plant editor", loading_page=nothing) do
        Bonito.DOM.div(
            Bonito.DOM.header(
                Bonito.DOM.p("AMAPSim.jl"; style="margin:0;color:#78d9a4;font-weight:800;"),
                Bonito.DOM.h1(
                    readonly ? "Native plant definition" : "Native plant editor";
                    style="margin:.25rem 0;font-size:clamp(2rem,5vw,3.7rem);",
                ),
                Bonito.DOM.p(
                    readonly ?
                    "A static, shareable view of templates, physiological ages, models, and overrides." :
                    "Compose reusable plant templates and heterogeneous scenes, then exchange them as safe TOML.";
                    style="max-width:52rem;font-size:1.08rem;color:#d9eee2;",
                );
                style="padding:clamp(1.5rem,4vw,3.4rem);border-radius:0 0 24px 24px;" *
                      "background:linear-gradient(125deg,#0e3b29,#17613d);color:white;",
            ),
            Bonito.DOM.main(
                readonly ? Bonito.DOM.p(
                    "Read-only static export — open the live Julia app to edit and validate.";
                    style="padding:.7rem 1rem;background:#e5f2ea;border-radius:8px;",
                ) : Bonito.DOM.div(
                    Bonito.DOM.h2("Guided definition edits"; style="color:#123f2b;"),
                    Bonito.DOM.p(
                        "Every button constructs a candidate definition. A failed category, selector, " *
                        "registry lookup, or override leaves the current scene untouched.",
                    ),
                    _forms(controls, messages),
                ),
                overview,
                _registry_panel(registry),
                readonly ? nothing : source_panel.panel;
                style="display:grid;gap:1.2rem;max-width:1180px;margin:0 auto;padding:1.2rem;",
            );
            style="min-height:100vh;background:#f4f8f5;color:#173d2a;" *
                  "font-family:Inter,ui-sans-serif,system-ui,-apple-system,sans-serif;",
            dataTestId="amapsim-scene-editor",
        )
    end
    return NativeSceneEditor(
        app,
        scene,
        source,
        draft,
        error,
        dirty,
        registry,
        controls,
        messages,
        saved_source,
        readonly,
    )
end

function Base.show(io::IO, mime::MIME"text/html", editor::NativeSceneEditor)
    return show(io, mime, editor.app)
end

end
