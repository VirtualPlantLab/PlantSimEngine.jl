"""
    event_table(model)

Return all normalized AMAPSim event-trace rows as a Tables.jl-compatible row
table. Rows are ordered by plant MTG node ID and then by processing order
within each plant. `plant_id`, `plant_index`, and `event_index` are prepended so
multi-plant outputs remain self-identifying. The deterministic union of event
fields is present on every row; fields that do not apply to an event kind are
`missing`.
"""
function event_table(model)
    plants = collect(PlantSimEngine.model_objects(
        model;
        scale=AMAPSIM_MTG_SYMBOLS.plant,
    ))
    sort!(plants; by=plant -> node_id(PlantSimEngine.source_node(model, plant)))
    rows = NamedTuple[]
    for plant in plants
        hasproperty(plant.status, :event_trace) || continue
        plant_node = PlantSimEngine.source_node(model, plant)
        plant_id = node_id(plant_node)
        plant_index = index(plant_node)
        for (event_index, event) in enumerate(plant.status.event_trace)
            push!(rows, merge((; plant_id, plant_index, event_index), event))
        end
    end
    isempty(rows) && return Tables.rowtable(rows)

    columns = Symbol[]
    seen = Set{Symbol}()
    for row in rows
        for name in propertynames(row)
            name in seen && continue
            push!(columns, name)
            push!(seen, name)
        end
    end
    column_names = Tuple(columns)
    normalized = NamedTuple[]
    for row in rows
        values = Tuple(
            hasproperty(row, name) ? getproperty(row, name) : missing
            for name in column_names
        )
        push!(normalized, NamedTuple{column_names}(values))
    end
    return Tables.rowtable(normalized)
end

const _SNAPSHOT_STRUCTURAL_COLUMNS = (
    :plant_id,
    :plant_index,
    :node_id,
    :parent_id,
    :link,
    :symbol,
    :index,
    :scale,
)

_snapshot_scope(topology::AMAPSimTopology) = topology.scene
_snapshot_scope(node::Node) = node

function _snapshot_plant(node)
    current = node
    while current !== nothing
        symbol(current) == AMAPSIM_MTG_SYMBOLS.plant && return current
        current = parent(current)
    end
    return nothing
end

function _snapshot_attribute_names(nodes, attributes, include_geometry::Bool)
    names = if attributes === :all
        collected = Set{Symbol}()
        for node in nodes
            union!(collected, keys(MultiScaleTreeGraph.node_attributes(node)))
        end
        sort!(collect(collected); by=String)
    elseif attributes isa Symbol || attributes isa AbstractString
        [Symbol(attributes)]
    else
        unique!(Symbol.(collect(attributes)))
    end
    include_geometry || filter!(name -> name !== :geometry, names)
    return names
end

function _snapshot_attribute_columns(attribute_names)
    columns = Symbol[Symbol("attr_", name) for name in attribute_names]
    length(unique(columns)) == length(columns) || throw(ArgumentError(
        "snapshot attribute names do not produce unique flattened columns",
    ))
    isempty(intersect(Set(columns), Set(_SNAPSHOT_STRUCTURAL_COLUMNS))) ||
        throw(ArgumentError("snapshot attribute columns collide with structural columns"))
    return columns
end

function _snapshot_row(
    node,
    ::Val{attribute_names},
    ::Val{row_names},
) where {attribute_names,row_names}
    plant = _snapshot_plant(node)
    node_parent = parent(node)
    node_attributes = MultiScaleTreeGraph.node_attributes(node)
    values = (
        isnothing(plant) ? nothing : node_id(plant),
        isnothing(plant) ? nothing : index(plant),
        node_id(node),
        isnothing(node_parent) ? nothing : node_id(node_parent),
        link(node),
        symbol(node),
        index(node),
        scale(node),
        ntuple(
            position -> get(node_attributes, attribute_names[position], nothing),
            Val(length(attribute_names)),
        )...,
    )
    return NamedTuple{row_names}(values)
end

"""
    snapshot_table(source; attributes=:all, include_geometry=false)

Return a deterministic Tables.jl-compatible row table for the MTG below
`source`. One row is emitted per node in stable node-ID order. Structural
columns contain plant identity, node identity, parent identity, link, symbol,
index, and scale. Selected MTG attributes are flattened with an `attr_` prefix.

By default, all attributes except the potentially large in-memory `geometry`
object are included. Pass an attribute name or collection to select columns,
or set `include_geometry=true` to retain `attr_geometry` when using
`attributes=:all`.
"""
function snapshot_table(
    source::Union{AMAPSimTopology,Node};
    attributes=:all,
    include_geometry::Bool=false,
)
    scope = _snapshot_scope(source)
    nodes = traverse(scope, identity; type=typeof(scope))
    sort!(nodes; by=node_id)
    attribute_names = Tuple(_snapshot_attribute_names(nodes, attributes, include_geometry))
    attribute_columns = _snapshot_attribute_columns(attribute_names)
    row_names = (_SNAPSHOT_STRUCTURAL_COLUMNS..., attribute_columns...)
    attribute_schema = Val(attribute_names)
    row_schema = Val(row_names)
    rows = map(node -> _snapshot_row(node, attribute_schema, row_schema), nodes)
    return Tables.rowtable(rows)
end

function _geometry_endpoint(point, name::AbstractString, organ_id::Int)
    length(point) == 3 || throw(ArgumentError(
        "$name for organ $organ_id must have three coordinates",
    ))
    return ntuple(3) do coordinate
        value = point[coordinate]
        value isa Real && isfinite(value) || throw(ArgumentError(
            "$name for organ $organ_id must contain finite real coordinates",
        ))
        Float64(value)
    end
end

function _geometry_measure(attributes, name::Symbol, organ_id::Int)
    value = get(attributes, name, nothing)
    value === nothing && return nothing
    value isa Real && isfinite(value) || throw(ArgumentError(
        "$name for organ $organ_id must be a finite real number",
    ))
    value >= 0 || throw(DomainError(
        value,
        "$name for organ $organ_id cannot be negative",
    ))
    return Float64(value)
end

function _geometry_coordinates(node, require_geometry::Bool)
    organ_id = node_id(node)
    attributes = MultiScaleTreeGraph.node_attributes(node)
    geometry = get(attributes, :geometry, nothing)
    if geometry === nothing
        require_geometry && throw(ArgumentError(
            "organ $organ_id has no reconstructed geometry",
        ))
        return (
            base=(missing, missing, missing),
            tip=(missing, missing, missing),
            direction=(missing, missing, missing),
            geometric_length=missing,
        )
    end
    hasproperty(geometry, :transformation) || throw(ArgumentError(
        "geometry for organ $organ_id has no transformation",
    ))
    local_base, local_tip = if hasproperty(geometry, :path)
        isempty(geometry.path) && throw(ArgumentError(
            "geometry path for organ $organ_id cannot be empty",
        ))
        (first(geometry.path), last(geometry.path))
    elseif hasproperty(geometry, :ref_mesh)
        ((0.0, 0.0, 0.0), (1.0, 0.0, 0.0))
    else
        throw(ArgumentError(
            "geometry for organ $organ_id has neither a path nor a reference mesh",
        ))
    end
    base = _geometry_endpoint(
        PlantGeom.apply_transformation_to_point(geometry.transformation, local_base),
        "geometry base",
        organ_id,
    )
    tip = _geometry_endpoint(
        PlantGeom.apply_transformation_to_point(geometry.transformation, local_tip),
        "geometry tip",
        organ_id,
    )
    delta = collect(tip) - collect(base)
    geometric_length = LinearAlgebra.norm(delta)
    direction = if iszero(geometric_length)
        (missing, missing, missing)
    else
        Tuple(delta / geometric_length)
    end
    return (; base, tip, direction, geometric_length)
end

function _geometry_organ_kind(node)
    node_symbol = symbol(node)
    node_symbol == AMAPSIM_MTG_SYMBOLS.leaf && return :leaf
    node_symbol == AMAPSIM_MTG_SYMBOLS.internode && return :wood
    throw(ArgumentError(
        "geometry organ $(node_id(node)) must be an Internode or Leaf",
    ))
end

function _geometry_axis_bearer_internode_index(axis)
    value = get(
        MultiScaleTreeGraph.node_attributes(axis),
        :BearerAxisInternodeIndex,
        nothing,
    )
    (value === nothing || ismissing(value)) && return nothing
    value isa Integer && !(value isa Bool) || throw(ArgumentError(
        "Axis $(node_id(axis)) BearerAxisInternodeIndex must be an integer",
    ))
    value > 0 || throw(DomainError(
        value,
        "BearerAxisInternodeIndex must be positive",
    ))
    return Int(value)
end

"""
    geometry_table(source; require_geometry=true, include_inactive=false)

Return one deterministic Tables.jl-compatible row per developed geometric
AMAPSim organ with plant, owning-axis, organ-owner, and bearer provenance;
stable `:wood` or `:leaf` organ kind; model length and diameters; and the
reconstructed base, tip, direction, and geometric length. Rows are ordered by
stable MTG node ID and never contain the in-memory geometry object itself.
Parameter-derived runtime scaffolds are internal initialization nodes and are
omitted. Native leaves own their geometry and dimensions directly.

By default, inactive organs and organs belonging to inactive axes are omitted,
and every selected organ must already have geometry, for example
after [`build_geometry!`](@ref). Set `include_inactive=true` and
`require_geometry=false` to retain abscised or otherwise inactive organs with
`missing` coordinate fields. A zero-length geometry has finite coincident
endpoints and a missing direction because no unit direction is defined.

Reference-mesh geometry follows PlantGeom's normalized prototype convention:
the reported base and tip are transformed local `(0, 0, 0)` and `(1, 0, 0)`
points, respectively.
"""
function geometry_table(
    source::Union{AMAPSimTopology,Node};
    require_geometry::Bool=true,
    include_inactive::Bool=false,
)
    scope = _snapshot_scope(source)
    scope_nodes = collect(traverse(scope, identity))
    nodes = filter(scope_nodes) do node
        node_symbol = symbol(node)
        node_symbol in (
            AMAPSIM_MTG_SYMBOLS.internode,
            AMAPSIM_MTG_SYMBOLS.leaf,
        ) || return false
        if node_symbol == AMAPSIM_MTG_SYMBOLS.internode &&
           _is_runtime_scaffold(node)
            return false
        end
        include_inactive && return true
        axis = _ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis)
        return organ_is_active(node) &&
               (axis === nothing || organ_is_active(axis))
    end
    sort!(nodes; by=node_id)
    rows = map(nodes) do node
        plant = _snapshot_plant(node)
        plant === nothing && throw(ArgumentError(
            "organ $(node_id(node)) does not belong to a plant",
        ))
        axis = _ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis)
        axis === nothing && throw(ArgumentError(
            "organ $(node_id(node)) does not belong to an axis",
        ))
        coordinates = _geometry_coordinates(node, require_geometry)
        attributes = MultiScaleTreeGraph.node_attributes(node)
        organ_id = node_id(node)
        organ_symbol = symbol(node)
        is_leaf = organ_symbol == AMAPSIM_MTG_SYMBOLS.leaf
        axis_internode_index = is_leaf ? nothing : _internode_axis_index_value(node)
        bearer_axis_internode_index = _geometry_axis_bearer_internode_index(axis)
        model_length = _geometry_measure(attributes, :Length, organ_id)
        top_width = _geometry_measure(attributes, :Width, organ_id)
        base_ratio = _geometry_measure(
            attributes,
            :BaseDiameterRatio,
            organ_id,
        )
        base_width = if top_width === nothing || base_ratio === nothing
            nothing
        else
            top_width * base_ratio
        end
        (
            plant_id=node_id(plant),
            plant_index=index(plant),
            axis_id=node_id(axis),
            axis_index=index(axis),
            organ_id,
            organ_symbol,
            organ_index=index(node),
            internode_id=is_leaf ? nothing : organ_id,
            axis_internode_index,
            bearer_axis_internode_index,
            organ_kind=_geometry_organ_kind(node),
            model_length,
            top_width,
            base_width,
            base_x=coordinates.base[1],
            base_y=coordinates.base[2],
            base_z=coordinates.base[3],
            tip_x=coordinates.tip[1],
            tip_y=coordinates.tip[2],
            tip_z=coordinates.tip[3],
            direction_x=coordinates.direction[1],
            direction_y=coordinates.direction[2],
            direction_z=coordinates.direction[3],
            geometric_length=coordinates.geometric_length,
        )
    end
    return Tables.rowtable(rows)
end

function _summary_plants(topology::AMAPSimTopology)
    return [topology.plant]
end

function _summary_plants(scope::Node)
    plants = filter(traverse(scope, identity)) do node
        symbol(node) == AMAPSIM_MTG_SYMBOLS.plant
    end
    if isempty(plants)
        containing_plant = _snapshot_plant(scope)
        isnothing(containing_plant) || push!(plants, containing_plant)
    end
    sort!(plants; by=node_id)
    return plants
end

function _summary_total_length(nodes)
    total = 0.0
    for node in nodes
        symbol(node) == AMAPSIM_MTG_SYMBOLS.internode || continue
        _is_runtime_scaffold(node) && continue
        length_value = get(
            MultiScaleTreeGraph.node_attributes(node),
            :Length,
            nothing,
        )
        isnothing(length_value) && continue
        length_value isa Real && isfinite(length_value) || throw(ArgumentError(
            "internode Length must be a finite real number for plant summaries",
        ))
        length_value >= 0 || throw(DomainError(
            length_value,
            "internode Length cannot be negative for plant summaries",
        ))
        total += Float64(length_value)
    end
    return total
end

function _zone_development_site_count(zone)
    symbol(zone) == AMAPSIM_MTG_SYMBOLS.zone || throw(ArgumentError(
        "developmental-site counts require a Zone node",
    ))
    value = get(
        MultiScaleTreeGraph.node_attributes(zone),
        :DevelopmentSiteCount,
        nothing,
    )
    value isa Integer || throw(ArgumentError(
        "canonical Zone $(node_id(zone)) requires an integer DevelopmentSiteCount",
    ))
    return _validate_development_count(
        value,
        "zone developmental-site count",
    )
end

function _legacy_mtg_scope(nodes, axes, growth_units; require_realized::Bool=true)
    developed_growth_unit_ids = Set(
        node_id(node) for node in growth_units if
        get(
            MultiScaleTreeGraph.node_attributes(node),
            :PhysiologicalAge,
            nothing,
        ) isa Real
    )
    is_developed_descendant(node) = begin
        growth_unit = _normalization_scope(
            node,
            AMAPSIM_MTG_SYMBOLS.growth_unit,
        )
        symbol(growth_unit) == AMAPSIM_MTG_SYMBOLS.growth_unit &&
            node_id(growth_unit) in developed_growth_unit_ids
    end
    realized_internodes = filter(nodes) do node
        symbol(node) == AMAPSIM_MTG_SYMBOLS.internode &&
            !_is_runtime_scaffold(node) && is_developed_descendant(node)
    end
    realized_internode_ids = Set(node_id.(realized_internodes))
    realized_axis_ids = Set(
        node_id(_ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis))
        for node in realized_internodes
    )
    realized_growth_unit_ids = Set(
        node_id(_ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.growth_unit))
        for node in realized_internodes
    )
    realized_cycle_ids = Set(
        node_id(_ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.growth_cycle))
        for node in realized_internodes
    )
    realized_zone_ids = Set(
        node_id(_ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.zone))
        for node in realized_internodes
    )
    # The historical geometry comparison keeps its pre-existing test-rank view.
    # Archived MTG counts instead require an own realized internode, not a test.
    developed_axis_ids = if require_realized
        realized_axis_ids
    else
        Set(
            node_id(_ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis))
            for node in nodes if
            symbol(node) == AMAPSIM_MTG_SYMBOLS.zone &&
            is_developed_descendant(node) && _zone_development_site_count(node) > 0
        )
    end
    legacy_mtg_axis_visible(axis) = begin
        node_id(axis) in developed_axis_ids || return false
        current = axis
        while !isnothing(current)
            if symbol(current) == AMAPSIM_MTG_SYMBOLS.axis &&
               get(
                   MultiScaleTreeGraph.node_attributes(current),
                   :Nature,
                   0,
               ) == 2
                return false
            end
            current = parent(current)
        end
        return true
    end
    legacy_mtg_axis_ids = Set(
        node_id(axis) for axis in axes if legacy_mtg_axis_visible(axis)
    )
    is_legacy_mtg_descendant(node) = begin
        axis = _ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis)
        !isnothing(axis) && node_id(axis) in legacy_mtg_axis_ids
    end
    return (;
        developed_growth_unit_ids,
        realized_internode_ids,
        realized_growth_unit_ids,
        realized_cycle_ids,
        realized_zone_ids,
        legacy_mtg_axis_ids,
        is_developed_descendant,
        is_legacy_mtg_descendant,
    )
end

function _legacy_mtg_export_levels(growth_units, scope)
    # Mapped to the unsimplified historical hierarchy: AnnualShoot is flattened,
    # then Axis -> GrowthUnit -> GrowthCycle -> Zone. The writer scans BEFORE
    # filtering empty containers or nature-2 subtrees. In particular, the empty
    # preformed Zone of a developed cycle is a real scanned container.
    units_per_axis = Dict{UInt64,Int}()
    maximum_cycles = 0
    maximum_zones = 0
    for unit in growth_units
        node_id(unit) in scope.developed_growth_unit_ids || continue
        axis_id = UInt64(node_id(_ancestor_with_symbol(unit, AMAPSIM_MTG_SYMBOLS.axis)))
        units_per_axis[axis_id] = get(units_per_axis, axis_id, 0) + 1
        cycles = filter(MultiScaleTreeGraph.children(unit)) do node
            symbol(node) == AMAPSIM_MTG_SYMBOLS.growth_cycle
        end
        maximum_cycles = max(maximum_cycles, length(cycles))
        for cycle in cycles
            zone_count = count(MultiScaleTreeGraph.children(cycle)) do node
                symbol(node) == AMAPSIM_MTG_SYMBOLS.zone
            end
            maximum_zones = max(maximum_zones, zone_count)
        end
    end
    maximum_units = maximum(values(units_per_axis); init=0)
    level(symbol, maximum_children) = (; symbol, maximum_children, exported=maximum_children > 1)
    return (;
        growth_unit=level("U", maximum_units),
        growth_cycle=level("C", maximum_cycles),
        zone=level("Z", maximum_zones),
    )
end

function _axis_branching_order(axis)
    symbol(axis) == AMAPSIM_MTG_SYMBOLS.axis || throw(ArgumentError(
        "branching order requires an axis node",
    ))
    order = 0
    current = parent(axis)
    while !isnothing(current)
        if symbol(current) == AMAPSIM_MTG_SYMBOLS.axis
            order = Base.Checked.checked_add(order, 1)
        end
        current = parent(current)
    end
    return order
end

function _legacy_mtg_branch_order_summary(plant; export_levels=nothing)
    nodes = collect(traverse(plant, identity))
    axes = filter(node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.axis, nodes)
    growth_units = filter(
        node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.growth_unit,
        nodes,
    )
    scope = _legacy_mtg_scope(nodes, axes, growth_units)
    visible_axes = filter(
        axis -> node_id(axis) in scope.legacy_mtg_axis_ids,
        axes,
    )
    axis_order = Dict(
        node_id(axis) => _axis_branching_order(axis) for axis in visible_axes
    )
    rows_by_order = Dict{Int,Dict{String,Any}}()
    row_for_order(order) = get!(rows_by_order, order) do
        row = Dict{String,Any}(
            "branching_order" => order,
            "axis_count" => 0,
            "active_axis_count" => 0,
            "ended_axis_count" => 0,
            "dead_axis_count" => 0,
            "pruned_axis_count" => 0,
            "other_axis_state_count" => 0,
            "growth_unit_count" => 0,
            "zone_count" => 0,
            "element_count" => 0,
        )
        isnothing(export_levels) || (row["growth_cycle_count"] = 0)
        row
    end
    for axis in visible_axes
        row = row_for_order(axis_order[node_id(axis)])
        row["axis_count"] += 1
        state = get(MultiScaleTreeGraph.node_attributes(axis), :State, nothing)
        state_field = if state == "active"
            "active_axis_count"
        elseif state == "ended"
            "ended_axis_count"
        elseif state == "dead"
            "dead_axis_count"
        elseif state == "pruned"
            "pruned_axis_count"
        else
            "other_axis_state_count"
        end
        row[state_field] += 1
    end
    for node in nodes
        node_symbol = symbol(node)
        node_symbol in (
            AMAPSIM_MTG_SYMBOLS.growth_unit,
            AMAPSIM_MTG_SYMBOLS.growth_cycle,
            AMAPSIM_MTG_SYMBOLS.zone,
            AMAPSIM_MTG_SYMBOLS.internode,
        ) || continue
        node_symbol == AMAPSIM_MTG_SYMBOLS.growth_cycle && isnothing(export_levels) && continue
        scope.is_developed_descendant(node) || continue
        scope.is_legacy_mtg_descendant(node) || continue
        axis = _ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis)
        order = axis_order[node_id(axis)]
        row = row_for_order(order)
        if node_symbol == AMAPSIM_MTG_SYMBOLS.growth_unit
            enabled = isnothing(export_levels) || export_levels.growth_unit.exported
            enabled && node_id(node) in scope.realized_growth_unit_ids && (row["growth_unit_count"] += 1)
        elseif node_symbol == AMAPSIM_MTG_SYMBOLS.growth_cycle
            export_levels.growth_cycle.exported && node_id(node) in scope.realized_cycle_ids &&
                (row["growth_cycle_count"] += 1)
        elseif node_symbol == AMAPSIM_MTG_SYMBOLS.zone
            enabled = isnothing(export_levels) || export_levels.zone.exported
            enabled && node_id(node) in scope.realized_zone_ids && (row["zone_count"] += 1)
        elseif node_id(node) in scope.realized_internode_ids
            row["element_count"] += 1
        end
    end
    return [rows_by_order[order] for order in sort!(collect(keys(rows_by_order)))]
end

function _legacy_mtg_export_projection(plant)
    nodes = collect(traverse(plant, identity))
    axes = filter(node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.axis, nodes)
    units = filter(node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.growth_unit, nodes)
    levels = _legacy_mtg_export_levels(units, _legacy_mtg_scope(nodes, axes, units))
    return (; levels, branch_orders=_legacy_mtg_branch_order_summary(plant; export_levels=levels))
end

function _legacy_bearer_test_rank(axis)
    phytomer = parent(axis)
    !isnothing(phytomer) && symbol(phytomer) == AMAPSIM_MTG_SYMBOLS.phytomer ||
        throw(ArgumentError(
            "legacy-visible lateral axis $(node_id(axis)) must be a direct child of its bearer Phytomer",
        ))
    value = get(
        MultiScaleTreeGraph.node_attributes(phytomer),
        :LegacyAxisTestIndex,
        nothing,
    )
    value isa Integer && !(value isa Bool) || throw(ArgumentError(
        "legacy-visible lateral axis $(node_id(axis)) requires an integer LegacyAxisTestIndex on its bearer Phytomer",
    ))
    value > 0 || throw(DomainError(
        value,
        "bearer Phytomer LegacyAxisTestIndex must be positive for legacy correspondence",
    ))
    return Int(value)
end

function _legacy_bearer_realized_rank(axis)
    phytomer = parent(axis)
    !isnothing(phytomer) && symbol(phytomer) == AMAPSIM_MTG_SYMBOLS.phytomer ||
        throw(ArgumentError(
            "legacy-visible lateral axis $(node_id(axis)) requires a bearer Phytomer",
        ))
    rank = get(MultiScaleTreeGraph.node_attributes(phytomer), :AxisInternodeIndex, nothing)
    rank isa Integer && !(rank isa Bool) && rank > 0 || throw(ArgumentError(
        "bearer Phytomer AxisInternodeIndex must be a positive integer",
    ))
    internodes = filter(MultiScaleTreeGraph.children(phytomer)) do child
        symbol(child) == AMAPSIM_MTG_SYMBOLS.internode && !_is_runtime_scaffold(child)
    end
    length(internodes) == 1 || throw(ArgumentError(
        "legacy bearer Phytomer must own exactly one realized Internode",
    ))
    internode = only(internodes)
    internode_rank = _internode_axis_index_value(internode)
    internode_rank isa Integer && !(internode_rank isa Bool) && internode_rank == rank ||
        throw(ArgumentError("bearer Phytomer and Internode realized ranks disagree"))
    attributes = MultiScaleTreeGraph.node_attributes(axis)
    bearer_rank = get(attributes, :BearerAxisInternodeIndex, nothing)
    bearer_rank isa Integer && !(bearer_rank isa Bool) && bearer_rank == rank ||
        throw(ArgumentError("lateral axis bearer realized rank disagrees with its Phytomer"))
    get(attributes, :BearerInternodeID, nothing) == node_id(internode) ||
        throw(ArgumentError("lateral axis bearer Internode ID disagrees with its Phytomer"))
    return Int(rank)
end

function _legacy_mtg_axis_strata_summary(plant)
    nodes = collect(traverse(plant, identity))
    axes = filter(node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.axis, nodes)
    growth_units = filter(
        node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.growth_unit,
        nodes,
    )
    scope = _legacy_mtg_scope(nodes, axes, growth_units)
    visible_axes = filter(
        axis -> node_id(axis) in scope.legacy_mtg_axis_ids,
        axes,
    )
    isempty(visible_axes) && return (;
        physiological_ages=Dict{String,Any}[],
        branch_types=Dict{String,Any}[],
        bearer_ranks=Dict{String,Any}[],
    )
    physiological_age_counts = Dict{Float64,Int}()
    branch_type_counts = Dict{String,Int}()
    bearer_rank_counts = Dict{Int,Int}()
    primary_axis_count = 0
    for axis in visible_axes
        attributes = MultiScaleTreeGraph.node_attributes(axis)
        physiological_age = _axis_initial_physiological_age(
            axis;
            allow_legacy=false,
        )
        physiological_age >= 1 || throw(DomainError(
            physiological_age,
            "axis InitialPhysiologicalAge must be at least one for run-manifest stratification",
        ))
        age = Float64(physiological_age)
        physiological_age_counts[age] =
            get(physiological_age_counts, age, 0) + 1

        branching_order = _axis_branching_order(axis)
        branch_type = if branching_order == 0
            primary_axis_count += 1
            "primary"
        else
            rank = _legacy_bearer_realized_rank(axis)
            bearer_rank_counts[rank] = get(bearer_rank_counts, rank, 0) + 1

            raw_branch_type = get(attributes, :BranchingType, nothing)
            if isnothing(raw_branch_type)
                "unclassified"
            else
                raw_branch_type isa AbstractString || throw(ArgumentError(
                    "axis BranchingType must be a string when present",
                ))
                normalized = strip(String(raw_branch_type))
                isempty(normalized) && throw(ArgumentError(
                    "axis BranchingType must not be empty",
                ))
                normalized
            end
        end
        branch_type_counts[branch_type] =
            get(branch_type_counts, branch_type, 0) + 1
    end
    primary_axis_count == 1 || throw(ArgumentError(
        "legacy-visible run-manifest scope requires exactly one primary axis; " *
        "found $primary_axis_count",
    ))
    sum(values(bearer_rank_counts); init=0) == length(visible_axes) - 1 ||
        throw(ArgumentError(
            "bearer-rank rows must account for every legacy-visible lateral axis",
        ))

    compact_age(age) = isinteger(age) && typemin(Int) <= age <= typemax(Int) ?
                       Int(age) : age
    return (;
        physiological_ages=[
            Dict{String,Any}(
                "physiological_age" => compact_age(age),
                "axis_count" => physiological_age_counts[age],
            ) for age in sort!(collect(keys(physiological_age_counts)))
        ],
        branch_types=[
            Dict{String,Any}(
                "branch_type" => branch_type,
                "axis_count" => branch_type_counts[branch_type],
            ) for branch_type in sort!(collect(keys(branch_type_counts)))
        ],
        bearer_ranks=[
            Dict{String,Any}(
                "bearer_axis_internode_index" => rank,
                "axis_count" => bearer_rank_counts[rank],
            ) for rank in sort!(collect(keys(bearer_rank_counts)))
        ],
    )
end

"""
    summary_table(source)

Return one deterministic Tables.jl-compatible summary row per plant in
`source`. Rows report the plant and stage identifiers, total node count,
botanical hierarchy counts, developed hierarchy counts that exclude the
initialized root scaffold, axis-state counts, and the sum of realized internode
`Length` attributes. Native leaf totals are reported separately from active
and inactive lifecycle counts. The summary is structural and deliberately does not assign
a public meaning to AMAPSim development time. The `legacy_mtg_*` counts match
the realized-internode observation scope: nature-2 axes and their descendants,
runtime scaffolds, and axes without an own developed Internode are excluded.
`legacy_mtg_element_count` counts realized Internodes. The legacy growth-unit
and zone counts are candidate containers with own realized internodes before
the writer's global level compression; they are not guaranteed raw `U`/`Z`
row counts. The separate `legacy_mtg_export_*_count` columns project raw `U`,
`C`, and `Z` rows for an unsimplified historical tree. Their global level mask
scans every developed container, including empty containers and nature-2 axes,
before applying visibility filters; a level is exported only if some parent
has more than one child at that level. The `legacy_mtg_exports_*` flags
distinguish a suppressed level from a retained level with zero visible rows.
Native developmental-site counters remain separate.
"""
function summary_table(source::Union{AMAPSimTopology,Node})
    rows = map(_summary_plants(source)) do plant
        nodes = collect(traverse(plant, identity))
        axes = filter(node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.axis, nodes)
        growth_units = filter(
            node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.growth_unit,
            nodes,
        )
        scope = _legacy_mtg_scope(nodes, axes, growth_units)
        export_levels = _legacy_mtg_export_levels(growth_units, scope)
        developed_growth_unit_ids = scope.developed_growth_unit_ids
        legacy_mtg_axis_ids = scope.legacy_mtg_axis_ids
        is_developed_descendant = scope.is_developed_descendant
        is_legacy_mtg_descendant = scope.is_legacy_mtg_descendant
        axis_states = map(axes) do axis
            get(MultiScaleTreeGraph.node_attributes(axis), :State, nothing)
        end
        legacy_mtg_axis_states = map(
            axis -> get(MultiScaleTreeGraph.node_attributes(axis), :State, nothing),
            filter(axis -> node_id(axis) in legacy_mtg_axis_ids, axes),
        )
        state_count(state) = count(==(state), axis_states)
        legacy_mtg_state_count(state) = count(==(state), legacy_mtg_axis_states)
        known_state_count = sum(state_count, ("active", "ended", "dead", "pruned"))
        legacy_mtg_known_state_count = sum(
            legacy_mtg_state_count,
            ("active", "ended", "dead", "pruned"),
        )
        plant_attributes = MultiScaleTreeGraph.node_attributes(plant)
        (
            plant_id=node_id(plant),
            plant_index=index(plant),
            stage=get(plant_attributes, :Stage, nothing),
            node_count=length(nodes),
            axis_count=length(axes),
            active_axis_count=state_count("active"),
            ended_axis_count=state_count("ended"),
            dead_axis_count=state_count("dead"),
            pruned_axis_count=state_count("pruned"),
            other_axis_state_count=length(axes) - known_state_count,
            legacy_mtg_axis_count=length(legacy_mtg_axis_ids),
            legacy_mtg_active_axis_count=legacy_mtg_state_count("active"),
            legacy_mtg_ended_axis_count=legacy_mtg_state_count("ended"),
            legacy_mtg_dead_axis_count=legacy_mtg_state_count("dead"),
            legacy_mtg_pruned_axis_count=legacy_mtg_state_count("pruned"),
            legacy_mtg_other_axis_state_count=
                length(legacy_mtg_axis_ids) - legacy_mtg_known_state_count,
            legacy_mtg_exports_growth_units=export_levels.growth_unit.exported,
            legacy_mtg_exports_growth_cycles=export_levels.growth_cycle.exported,
            legacy_mtg_exports_zones=export_levels.zone.exported,
            legacy_mtg_export_growth_unit_count=export_levels.growth_unit.exported ? count(
                node -> node_id(node) in scope.realized_growth_unit_ids &&
                        is_legacy_mtg_descendant(node),
                growth_units,
            ) : 0,
            legacy_mtg_export_growth_cycle_count=export_levels.growth_cycle.exported ? count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.growth_cycle &&
                        node_id(node) in scope.realized_cycle_ids &&
                        is_legacy_mtg_descendant(node),
                nodes,
            ) : 0,
            legacy_mtg_export_zone_count=export_levels.zone.exported ? count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.zone &&
                        node_id(node) in scope.realized_zone_ids &&
                        is_legacy_mtg_descendant(node),
                nodes,
            ) : 0,
            annual_shoot_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.annual_shoot,
                nodes,
            ),
            growth_unit_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.growth_unit,
                nodes,
            ),
            developed_growth_unit_count=length(developed_growth_unit_ids),
            legacy_mtg_developed_growth_unit_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.growth_unit &&
                        node_id(node) in scope.realized_growth_unit_ids &&
                        is_legacy_mtg_descendant(node),
                nodes,
            ),
            growth_cycle_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.growth_cycle,
                nodes,
            ),
            zone_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.zone,
                nodes,
            ),
            developed_zone_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.zone &&
                        is_developed_descendant(node),
                nodes,
            ),
            legacy_mtg_developed_zone_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.zone &&
                        node_id(node) in scope.realized_zone_ids &&
                        is_legacy_mtg_descendant(node),
                nodes,
            ),
            phytomer_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.phytomer,
                nodes,
            ),
            developed_phytomer_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.phytomer &&
                        is_developed_descendant(node),
                nodes,
            ),
            # Compatibility columns make removal of public TestSite nodes
            # explicit instead of silently changing the table schema.
            test_site_count=0,
            developed_test_site_count=0,
            internode_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.internode,
                nodes,
            ),
            developed_internode_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.internode &&
                        is_developed_descendant(node),
                nodes,
            ),
            leaf_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.leaf,
                nodes,
            ),
            active_leaf_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.leaf &&
                        organ_is_active(node),
                nodes,
            ),
            inactive_leaf_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.leaf &&
                        !organ_is_active(node),
                nodes,
            ),
            legacy_mtg_element_count=count(
                node -> node_id(node) in scope.realized_internode_ids &&
                        is_legacy_mtg_descendant(node),
                nodes,
            ),
            bud_count=count(
                node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.bud,
                nodes,
            ),
            total_internode_length=_summary_total_length(nodes),
        )
    end
    return Tables.rowtable(rows)
end
