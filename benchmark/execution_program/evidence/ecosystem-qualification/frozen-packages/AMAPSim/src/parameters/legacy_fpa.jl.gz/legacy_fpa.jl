mutable struct LegacyLineReader
    lines::Vector{String}
    next_line::Int
    source::String
end

function LegacyLineReader(text::AbstractString, source::AbstractString)
    lines = replace.(split(String(text), '\n'; keepempty=true), '\r' => "")
    return LegacyLineReader(lines, 1, String(source))
end

function _parameter_error(reader::LegacyLineReader, line, field, message)
    return LegacyParameterError(reader.source, Int(line), field, String(message))
end

function _next_line!(reader::LegacyLineReader, field::Symbol; skip_blank::Bool=false)
    while reader.next_line <= length(reader.lines)
        line_number = reader.next_line
        line = reader.lines[line_number]
        reader.next_line += 1
        skip_blank && isempty(strip(line)) && continue
        return line_number, line
    end
    throw(_parameter_error(reader, length(reader.lines), field, "unexpected end of file"))
end

function _parse_float(reader, token, line, field)
    value = tryparse(Float64, token)
    value === nothing &&
        throw(_parameter_error(reader, line, field, "expected a number, got '$token'"))
    isfinite(value) ||
        throw(_parameter_error(reader, line, field, "values must be finite, got '$token'"))
    return value
end

function _parse_int(reader, token, line, field)
    value = tryparse(Int, token)
    value === nothing &&
        throw(_parameter_error(reader, line, field, "expected an integer, got '$token'"))
    return value
end

function _parse_mode(reader, token, line, field)
    raw = _parse_int(reader, token, line, field)
    try
        return interpolation_mode(raw)
    catch error
        throw(_parameter_error(reader, line, field, sprint(showerror, error)))
    end
end

function _legacy_position(value::Float64)
    return Float64(trunc(Int, value - 1.0))
end

function _validate_domain(reader, line, spec::LegacyParameterSpec, values)
    domain = spec.domain
    if domain == :probability && !all(value -> 0.0 <= value <= 1.0, values)
        throw(_parameter_error(reader, line, spec.name, "probabilities must lie in [0, 1]"))
    elseif domain == :signed_probability && !all(value -> -1.0 <= value <= 1.0, values)
        throw(_parameter_error(
            reader,
            line,
            spec.name,
            "signed probabilities must lie in [-1, 1]",
        ))
    elseif domain == :nonnegative && !all(value -> value >= 0.0, values)
        throw(_parameter_error(reader, line, spec.name, "values must be non-negative"))
    elseif domain == :integer_nonnegative &&
           !all(value -> value >= 0.0 && isinteger(value), values)
        throw(_parameter_error(reader, line, spec.name, "value must be a non-negative integer"))
    end
    return nothing
end

function _provenance(reader, line, raw_line, spec, index=spec.index)
    return ParameterProvenance(
        source=reader.source,
        line=line,
        legacy_index=index,
        legacy_name=spec.legacy_name,
        unit=spec.unit,
        conversion=spec.conversion,
        raw_line=raw_line,
    )
end

function _normalized_scalar(spec::LegacyParameterSpec, raw_value::Float64)
    if spec.legacy_name == :glangins && abs(raw_value) < 1.0e-8
        return 1.0e-8 * spec.conversion
    end
    return raw_value * spec.conversion
end

function _parameter_tokens!(reader::LegacyLineReader, spec::LegacyParameterSpec)
    line, raw_line = _next_line!(reader, spec.name; skip_blank=true)
    tokens = String.(split(strip(raw_line)))
    token_lines = fill(line, length(tokens))
    return line, String[raw_line], tokens, token_lines
end

function _ensure_parameter_tokens!(
    reader::LegacyLineReader,
    spec::LegacyParameterSpec,
    raw_lines::Vector{String},
    tokens::Vector{String},
    token_lines::Vector{Int},
    required::Int,
)
    while length(tokens) < required
        line, raw_line = _next_line!(reader, spec.name; skip_blank=true)
        continuation = String.(split(strip(raw_line)))
        push!(raw_lines, raw_line)
        append!(tokens, continuation)
        append!(token_lines, fill(line, length(continuation)))
    end
    return nothing
end

function _read_scalar!(reader, spec::LegacyParameterSpec)
    line, raw_line = _next_line!(reader, spec.name; skip_blank=true)
    tokens = split(strip(raw_line))
    length(tokens) == 1 ||
        throw(_parameter_error(reader, line, spec.name, "expected one scalar value"))
    raw_value = _parse_float(reader, only(tokens), line, spec.name)
    _validate_domain(reader, line, spec, (raw_value,))
    value = _normalized_scalar(spec, raw_value)
    return ScalarParameter(value, raw_value, _provenance(reader, line, raw_line, spec))
end

function _read_curve!(reader, spec::LegacyParameterSpec, legacy_index::Int=spec.index)
    line, raw_lines, tokens, token_lines = _parameter_tokens!(reader, spec)
    length(tokens) >= 2 ||
    throw(_parameter_error(reader, line, spec.name, "curve header needs a mode and point count"))
    mode = _parse_mode(reader, tokens[1], token_lines[1], spec.name)
    count = _parse_int(reader, tokens[2], token_lines[2], spec.name)
    count >= 1 ||
    throw(_parameter_error(
        reader,
        token_lines[2],
        spec.name,
        "curve point count must be positive",
    ))
    expected = 2 + 2 * count
    _ensure_parameter_tokens!(reader, spec, raw_lines, tokens, token_lines, expected)
    length(tokens) == expected || throw(_parameter_error(
        reader,
        line,
        spec.name,
        "expected $expected fields for $count points, found $(length(tokens))",
    ))

    source_positions = Float64[]
    positions = Float64[]
    source_values = Float64[]
    for point in 1:count
        offset = 2 + 2 * (point - 1)
        source_position = _parse_float(
            reader,
            tokens[offset + 1],
            token_lines[offset + 1],
            spec.name,
        )
        source_value = _parse_float(
            reader,
            tokens[offset + 2],
            token_lines[offset + 2],
            spec.name,
        )
        push!(source_positions, source_position)
        push!(positions, _legacy_position(source_position))
        push!(source_values, source_value)
    end
    normalized_values = source_values .* spec.conversion
    _validate_domain(reader, token_lines[expected], spec, normalized_values)
    provenance = _provenance(reader, line, join(raw_lines, '\n'), spec, legacy_index)
    try
        return ParameterCurve(
            positions,
            normalized_values;
            interpolation=mode,
            source_positions=source_positions,
            source_values=source_values,
            provenance=provenance,
            _allow_duplicate_positions=true,
        )
    catch error
        throw(_parameter_error(reader, line, spec.name, sprint(showerror, error)))
    end
end

function _read_surface!(reader, spec::LegacyParameterSpec, legacy_index::Int=spec.index)
    line, raw_lines, tokens, token_lines = _parameter_tokens!(reader, spec)
    length(tokens) >= 2 || throw(_parameter_error(
        reader,
        line,
        spec.name,
        "surface header needs a mode and physiological-age count",
    ))
    outer_mode = _parse_mode(reader, tokens[1], token_lines[1], spec.name)
    age_count = _parse_int(reader, tokens[2], token_lines[2], spec.name)
    age_count >= 1 || throw(_parameter_error(
        reader,
        token_lines[2],
        spec.name,
        "physiological-age count must be positive",
    ))

    cursor = 3
    source_ages = Float64[]
    ages = Float64[]
    dummy_values = Float64[]
    curves = AbstractParameterCurve{Float64}[]
    provenance = _provenance(reader, line, join(raw_lines, '\n'), spec, legacy_index)

    for age_level in 1:age_count
        _ensure_parameter_tokens!(
            reader,
            spec,
            raw_lines,
            tokens,
            token_lines,
            cursor + 3,
        )
        source_age = _parse_float(reader, tokens[cursor], token_lines[cursor], spec.name)
        dummy = _parse_float(
            reader,
            tokens[cursor + 1],
            token_lines[cursor + 1],
            spec.name,
        )
        inner_mode = _parse_mode(
            reader,
            tokens[cursor + 2],
            token_lines[cursor + 2],
            spec.name,
        )
        point_count = _parse_int(
            reader,
            tokens[cursor + 3],
            token_lines[cursor + 3],
            spec.name,
        )
        point_count >= 1 || throw(_parameter_error(
            reader,
            token_lines[cursor + 3],
            spec.name,
            "point count at age level $age_level must be positive",
        ))
        cursor += 4
        _ensure_parameter_tokens!(
            reader,
            spec,
            raw_lines,
            tokens,
            token_lines,
            cursor + 2 * point_count - 1,
        )

        source_positions = Float64[]
        positions = Float64[]
        source_values = Float64[]
        for _ in 1:point_count
            source_position = _parse_float(
                reader,
                tokens[cursor],
                token_lines[cursor],
                spec.name,
            )
            source_value = _parse_float(
                reader,
                tokens[cursor + 1],
                token_lines[cursor + 1],
                spec.name,
            )
            cursor += 2
            push!(source_positions, source_position)
            push!(positions, _legacy_position(source_position))
            push!(source_values, source_value)
        end
        normalized_values = source_values .* spec.conversion
        value_line = token_lines[cursor - 1]
        _validate_domain(reader, value_line, spec, normalized_values)
        curve = try
            ParameterCurve(
                positions,
                normalized_values;
                interpolation=inner_mode,
                source_positions=source_positions,
                source_values=source_values,
                provenance=provenance,
                _allow_duplicate_positions=true,
            )
        catch error
            throw(_parameter_error(reader, line, spec.name, sprint(showerror, error)))
        end
        push!(source_ages, source_age)
        push!(ages, _legacy_position(source_age))
        push!(dummy_values, dummy)
        push!(curves, curve)
    end
    provenance = _provenance(reader, line, join(raw_lines, '\n'), spec, legacy_index)
    curves = AbstractParameterCurve{Float64}[
        ParameterCurve(
            curve.positions,
            curve.values;
            interpolation=curve.interpolation,
            source_positions=curve.source_positions,
            source_values=curve.source_values,
            provenance=provenance,
            _allow_duplicate_positions=true,
        ) for curve in curves
    ]
    cursor == length(tokens) + 1 || throw(_parameter_error(
        reader,
        line,
        spec.name,
        "found $(length(tokens) - cursor + 1) unexpected trailing field(s)",
    ))

    try
        return ParameterSurface(
            ages,
            curves;
            interpolation=outer_mode,
            source_physiological_ages=source_ages,
            source_dummy_values=dummy_values,
            provenance=provenance,
        )
    catch error
        throw(_parameter_error(reader, line, spec.name, sprint(showerror, error)))
    end
end

function _read_parameter!(reader, spec, legacy_index=spec.index)
    spec.kind == :curve && return _read_curve!(reader, spec, legacy_index)
    spec.kind == :surface && return _read_surface!(reader, spec, legacy_index)
    throw(ArgumentError("unsupported legacy parameter kind: $(spec.kind)"))
end

function _named_group(specs, parsed::Dict{Symbol,AbstractAMAPParameter})
    pairs = Pair{Symbol,Any}[spec.name => parsed[spec.name] for spec in specs]
    return ParameterGroup((; pairs...))
end

function _axis_groups(parsed::Dict{Symbol,AbstractAMAPParameter})
    by_group(group) = _named_group(filter(spec -> spec.group == group, LEGACY_AXIS_SPECS), parsed)
    return AxisParameters(
        by_group(:topology),
        by_group(:differentiation),
        by_group(:growth),
        by_group(:geometry),
    )
end

function _build_initialization(scalars::Dict{Symbol,ScalarParameter})
    return PlantInitialization(
        Int(scalars[:maximum_age].value),
        Int(scalars[:initial_physiological_age].value),
        Float64(scalars[:initial_insertion_angle].value),
        Float64(scalars[:initial_truncated_internode_length].value),
        Int(scalars[:lateral_production_count].value),
        Float64(scalars[:initial_truncated_internode_diameter].value),
    )
end

function _read_model_types!(reader, lateral_name)
    field = Symbol("branching_models_", lateral_name)
    line, raw_line = _next_line!(reader, field; skip_blank=true)
    tokens = split(strip(raw_line))
    length(tokens) == 4 || throw(_parameter_error(
        reader,
        line,
        field,
        "expected four branching-model flags",
    ))
    values = map(token -> _parse_int(reader, token, line, field), tokens)
    all(value -> value in (0, 1), values) || throw(_parameter_error(
        reader,
        line,
        field,
        "branching-model flags must be 0 (Markov) or 1 (semi-Markov)",
    ))
    return Tuple(BranchingModelKind(value) for value in values)
end

function _parse_parameters(text::String, source::String, digest::String)
    reader = LegacyLineReader(text, source)
    header_line, header = _next_line!(reader, :version)
    matched = match(r"^#AMAPSIM parameter file Version\s+(\S+)\s*$", header)
    matched === nothing && throw(_parameter_error(
        reader,
        header_line,
        :version,
        "expected '#AMAPSIM parameter file Version 2'",
    ))
    version = tryparse(Int, matched.captures[1])
    version == 2 || throw(_parameter_error(
        reader,
        header_line,
        :version,
        "only version 2 is supported, found '$(matched.captures[1])'",
    ))

    name_line, raw_name = _next_line!(reader, :plant_name)
    plant_name = String(strip(raw_name))
    isempty(plant_name) &&
        throw(_parameter_error(reader, name_line, :plant_name, "plant name must not be empty"))

    entries = Dict{Int,AbstractAMAPParameter}()
    scalars = Dict{Symbol,ScalarParameter}()
    for spec in LEGACY_SCALAR_SPECS
        parameter = _read_scalar!(reader, spec)
        scalars[spec.name] = parameter
        entries[spec.index] = parameter
    end
    initialization = _build_initialization(scalars)

    axis_parsed = Dict{Symbol,AbstractAMAPParameter}()
    for spec in LEGACY_AXIS_SPECS
        parameter = _read_parameter!(reader, spec)
        axis_parsed[spec.name] = parameter
        entries[spec.index] = parameter
    end
    axis = _axis_groups(axis_parsed)

    laterals = LateralProductionParameters[]
    for lateral_index in 1:initialization.lateral_production_count
        lateral_field = Symbol("lateral_production_", lateral_index)
        name_line, raw_lateral_name = _next_line!(reader, lateral_field)
        lateral_name = String(strip(raw_lateral_name))
        isempty(lateral_name) && throw(_parameter_error(
            reader,
            name_line,
            lateral_field,
            "lateral-production name must not be empty",
        ))
        base_index = LEGACY_BASE_PARAMETER_COUNT +
                     LEGACY_LATERAL_PARAMETER_COUNT * (lateral_index - 1)

        global_parsed = Dict{Symbol,AbstractAMAPParameter}()
        for spec in LEGACY_LATERAL_GLOBAL_SPECS
            legacy_index = base_index + spec.index
            parameter = _read_parameter!(reader, spec, legacy_index)
            global_parsed[spec.name] = parameter
            entries[legacy_index] = parameter
        end
        global_parameters = _named_group(LEGACY_LATERAL_GLOBAL_SPECS, global_parsed)
        model_types = _read_model_types!(reader, lateral_index)

        zones = LateralProductionZone[]
        for zone_index in 1:LEGACY_ZONE_COUNT
            zone_base = base_index + LEGACY_LATERAL_GLOBAL_COUNT +
                        LEGACY_ZONE_PARAMETER_COUNT * (zone_index - 1)
            zone_parsed = Dict{Symbol,AbstractAMAPParameter}()
            for spec in LEGACY_ZONE_SPECS
                legacy_index = zone_base + spec.index
                parameter = _read_parameter!(reader, spec, legacy_index)
                zone_parsed[spec.name] = parameter
                entries[legacy_index] = parameter
            end
            push!(
                zones,
                LateralProductionZone(zone_index, _named_group(LEGACY_ZONE_SPECS, zone_parsed)),
            )
        end
        push!(
            laterals,
            LateralProductionParameters(
                lateral_name,
                global_parameters,
                model_types,
                Tuple(zones),
            ),
        )
    end

    while reader.next_line <= length(reader.lines)
        line_number, line = _next_line!(reader, :trailing_data)
        isempty(strip(line)) && continue
        throw(_parameter_error(
            reader,
            line_number,
            :trailing_data,
            "unexpected data after the last parameter record",
        ))
    end

    source_metadata = ParameterSource(source, digest, :legacy_fpa, 2, plant_name)
    return AMAPSimParameters(
        source_metadata,
        initialization,
        axis,
        laterals,
        LegacyParameterIndex(entries),
    )
end

function _decode_legacy_text(bytes::Vector{UInt8})
    text = String(copy(bytes))
    isvalid(text) && return text
    return join(Char.(bytes))
end

"""
    read_parameters(path)
    read_parameters(io; source="<io>")

Read and fully validate an AMAPSim version-2 `.fpa` parameter file. Source
coordinates, raw values, legacy indices, units, and conversion factors are
retained alongside the normalized named representation.
"""
function read_parameters(path::AbstractString)
    absolute_path = abspath(path)
    isfile(absolute_path) || throw(ArgumentError("parameter file does not exist: $absolute_path"))
    bytes = read(absolute_path)
    return _parse_parameters(
        _decode_legacy_text(bytes),
        absolute_path,
        bytes2hex(SHA.sha256(bytes)),
    )
end

function read_parameters(io::IO; source::AbstractString="<io>")
    bytes = read(io)
    return _parse_parameters(
        _decode_legacy_text(bytes),
        String(source),
        bytes2hex(SHA.sha256(bytes)),
    )
end

function _write_number(io, value::Real)
    isinteger(value) ? print(io, Int(value)) : print(io, value)
end

function _write_curve(io, curve::ParameterCurve)
    print(io, Int(curve.interpolation), ' ', length(curve.positions))
    for (position, value) in zip(curve.source_positions, curve.source_values)
        print(io, ' ')
        _write_number(io, position)
        print(io, ' ')
        _write_number(io, value)
    end
    println(io)
end

function _write_surface(io, surface::ParameterSurface)
    print(io, Int(surface.interpolation), ' ', length(surface.physiological_ages))
    for (source_age, dummy, curve) in zip(
        surface.source_physiological_ages,
        surface.source_dummy_values,
        surface.curves,
    )
        print(io, ' ')
        _write_number(io, source_age)
        print(io, ' ')
        _write_number(io, dummy)
        print(io, ' ', Int(curve.interpolation), ' ', length(curve.positions))
        for (position, value) in zip(curve.source_positions, curve.source_values)
            print(io, ' ')
            _write_number(io, position)
            print(io, ' ')
            _write_number(io, value)
        end
    end
    println(io)
end

function _write_parameter(io, parameter::AbstractAMAPParameter)
    parameter isa ParameterCurve && return _write_curve(io, parameter)
    parameter isa ParameterSurface && return _write_surface(io, parameter)
    throw(ArgumentError("cannot write parameter record of type $(typeof(parameter))"))
end

"""Internal serializer used only to validate the lossless legacy reader."""
function _write_legacy_parameters(io::IO, parameters::AMAPSimParameters)
    println(io, "#AMAPSIM parameter file Version 2")
    println(io, parameters.source.plant_name)
    for spec in LEGACY_SCALAR_SPECS
        scalar = parameters.legacy[spec.index]
        _write_number(io, scalar.source_value)
        println(io)
    end
    for spec in LEGACY_AXIS_SPECS
        _write_parameter(io, parameters.legacy[spec.index])
    end
    for (lateral_index, lateral) in enumerate(parameters.lateral_productions)
        println(io, lateral.name)
        base_index = LEGACY_BASE_PARAMETER_COUNT +
                     LEGACY_LATERAL_PARAMETER_COUNT * (lateral_index - 1)
        for spec in LEGACY_LATERAL_GLOBAL_SPECS
            _write_parameter(io, parameters.legacy[base_index + spec.index])
        end
        println(io, join(Int.(lateral.branching_models), ' '))
        for zone_index in 1:LEGACY_ZONE_COUNT
            zone_base = base_index + LEGACY_LATERAL_GLOBAL_COUNT +
                        LEGACY_ZONE_PARAMETER_COUNT * (zone_index - 1)
            for spec in LEGACY_ZONE_SPECS
                _write_parameter(io, parameters.legacy[zone_base + spec.index])
            end
        end
    end
    return io
end

function _write_legacy_parameters(
    path::AbstractString,
    parameters::AMAPSimParameters,
)
    open(path, "w") do io
        _write_legacy_parameters(io, parameters)
    end
    return abspath(path)
end
