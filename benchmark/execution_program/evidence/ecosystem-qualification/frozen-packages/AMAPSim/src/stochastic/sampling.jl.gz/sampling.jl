"""Sampling policy used by AMAPSim stochastic kernels."""
abstract type AbstractSamplingPolicy end

"""
    StandardSampling()

Use the standard distributions supplied by Distributions.jl. Randomness always
comes from the explicit `AbstractRNG` passed to a sampling function.
"""
struct StandardSampling <: AbstractSamplingPolicy end

"""
    AttributeDistribution(attribute, distribution; transform=(value, target) -> value)

Declare one stochastic attribute realized by AMAPSim. `distribution` may be any
object accepted by `rand(rng, distribution)`, including the distributions from
Distributions.jl, or a function of the target that returns such an object. The
optional two-argument `transform` receives the sampled value and target before
the value is stored.

Distribution definitions remain model inputs; realized values are persisted on
the target MTG nodes by [`realize_attributes!`](@ref), so geometry and export
code do not draw random values independently.
"""
struct AttributeDistribution{D,F}
    attribute::Symbol
    distribution::D
    transform::F
end

function AttributeDistribution(
    attribute::Symbol,
    distribution;
    transform=(value, target) -> value,
)
    return AttributeDistribution(attribute, distribution, transform)
end

"""
    GroupedAttributeDistribution(attributes, distribution, groupby; transform)

Declare attributes that share one stochastic realization within each group of
targets. `attributes` is a symbol or tuple of symbols, `groupby(target)` returns
the group identity, and `distribution` may be any object accepted by
`rand(rng, distribution)` or a function `(group, members) -> distribution`.

The transform receives `(sample, target, members)` and must return either a
named tuple or dictionary containing every declared attribute. A scalar is also
accepted when exactly one attribute is declared. This supports correlated
structures such as an opposite branch pair: AMAPSim draws one angular residual
for the pair, then derives and stores one realized azimuth per member.
"""
struct GroupedAttributeDistribution{A,D,G,F}
    attributes::A
    distribution::D
    groupby::G
    transform::F
end

_grouped_attribute_names(attribute::Symbol) = (attribute,)

function _grouped_attribute_names(attributes)
    normalized = Tuple(attributes)
    isempty(normalized) && throw(ArgumentError(
        "a grouped attribute distribution must declare at least one attribute",
    ))
    all(attribute -> attribute isa Symbol, normalized) || throw(ArgumentError(
        "grouped attribute names must be symbols",
    ))
    allunique(normalized) || throw(ArgumentError(
        "grouped attribute names must be unique",
    ))
    return normalized
end

function GroupedAttributeDistribution(
    attributes,
    distribution,
    groupby;
    transform=nothing,
)
    normalized = _grouped_attribute_names(attributes)
    resolved_transform = if transform === nothing
        length(normalized) == 1 || throw(ArgumentError(
            "a transform is required when a grouped rule declares multiple attributes",
        ))
        (value, _target, _members) -> value
    else
        transform
    end
    return GroupedAttributeDistribution(
        normalized,
        distribution,
        groupby,
        resolved_transform,
    )
end

function _validate_sampling_seed(seed::Integer)
    0 <= seed <= typemax(UInt64) || throw(DomainError(
        seed,
        "sampling seed must be between zero and typemax(UInt64)",
    ))
    return UInt64(seed)
end

function _sampling_stream_seed(seed::Integer, stream::Union{Symbol,AbstractString})
    normalized_seed = _validate_sampling_seed(seed)
    label = String(stream)
    isempty(label) && throw(ArgumentError("sampling stream name cannot be empty"))
    digest = sha256(string(normalized_seed, '\0', label))
    derived = UInt64(0)
    for byte in @view digest[1:8]
        derived = (derived << 8) | UInt64(byte)
    end
    return derived
end

"""
    stochastic_stream(seed, stream)

Create a deterministic AMAPSim random substream identified by `stream`. Named
substreams keep additional trait families from consuming the botanical event
stream or one another. The plant seed and stream name are hashed before the
`Xoshiro` generator is initialized.
"""
function stochastic_stream(seed::Integer, stream::Union{Symbol,AbstractString})
    return Xoshiro(_sampling_stream_seed(seed, stream))
end

"""
    sample_distribution(rng, distribution; policy=StandardSampling())

Sample any Distributions.jl-compatible distribution using AMAPSim's explicit
random stream and sampling policy.
"""
function sample_distribution(
    rng::AbstractRNG,
    distribution;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    return sample_distribution(rng, policy, distribution)
end

sample_distribution(rng::AbstractRNG, ::StandardSampling, distribution) =
    rand(rng, distribution)

_attribute_store(target::Node) = MultiScaleTreeGraph.node_attributes(target)
_attribute_store(target::AbstractDict) = target

function _target_distribution(distribution, target)
    return distribution isa Function ? distribution(target) : distribution
end

"""
    realize_attributes!(rng, targets, rules; overwrite=false)
    realize_attributes!(targets, rules; seed, stream, overwrite=false)

Sample `AttributeDistribution` rules and persist their realized values on every
MTG node or attribute dictionary. The explicit-RNG method samples in
target-major, rule-minor order. The seed-and-stream method derives one stable
substream per attribute, so adding another rule does not perturb existing trait
realizations. Existing attributes are rejected before any draw unless
`overwrite=true`.

Callers control the target order. Sort MTG nodes by `node_id` when the order of
an upstream traversal is not already part of the model contract.
"""
function realize_attributes!(
    rng::AbstractRNG,
    targets,
    rules::AbstractVector{<:AttributeDistribution};
    overwrite::Bool=false,
)
    collected_targets = collect(targets)
    for target in collected_targets, rule in rules
        attributes = _attribute_store(target)
        !overwrite && haskey(attributes, rule.attribute) && throw(ArgumentError(
            "attribute $(rule.attribute) is already realized on a target",
        ))
    end
    for target in collected_targets, rule in rules
        distribution = _target_distribution(rule.distribution, target)
        sampled = sample_distribution(rng, distribution)
        value = rule.transform(sampled, target)
        _attribute_store(target)[rule.attribute] = value
    end
    return collected_targets
end

function _validate_attribute_realization(targets, rules, overwrite)
    attributes = getfield.(rules, :attribute)
    allunique(attributes) || throw(ArgumentError(
        "attribute distribution rules must use unique attribute names",
    ))
    for target in targets, rule in rules
        store = _attribute_store(target)
        !overwrite && haskey(store, rule.attribute) && throw(ArgumentError(
            "attribute $(rule.attribute) is already realized on a target",
        ))
    end
    return nothing
end

function realize_attributes!(
    targets,
    rules::AbstractVector{<:AttributeDistribution};
    seed,
    stream,
    overwrite::Bool=false,
)
    collected_targets = collect(targets)
    _validate_attribute_realization(collected_targets, rules, overwrite)
    stream_name = String(stream)
    for rule in rules
        rng = stochastic_stream(seed, string(stream_name, '/', rule.attribute))
        realize_attributes!(rng, collected_targets, [rule]; overwrite=true)
    end
    return collected_targets
end

function _group_targets(targets, groupby)
    keys = Any[]
    members = Dict{Any,Vector{Any}}()
    for target in targets
        key = groupby(target)
        if !haskey(members, key)
            push!(keys, key)
            members[key] = Any[]
        end
        push!(members[key], target)
    end
    return [(key, members[key]) for key in keys]
end

function _group_distribution(distribution, key, members)
    return distribution isa Function ? distribution(key, members) : distribution
end

function _grouped_assignment(attributes, transformed)
    if length(attributes) == 1 &&
       !(transformed isa NamedTuple) &&
       !(transformed isa AbstractDict)
        return (attributes[1] => transformed,)
    end
    return Tuple(attribute => if transformed isa NamedTuple
        hasproperty(transformed, attribute) || throw(ArgumentError(
            "grouped transform did not return attribute $attribute",
        ))
        getproperty(transformed, attribute)
    elseif transformed isa AbstractDict
        haskey(transformed, attribute) || throw(ArgumentError(
            "grouped transform did not return attribute $attribute",
        ))
        transformed[attribute]
    else
        throw(ArgumentError(
            "a multi-attribute grouped transform must return a named tuple or dictionary",
        ))
    end for attribute in attributes)
end

function _validate_grouped_attribute_realization(targets, rules, overwrite)
    declared = Symbol[]
    for rule in rules
        append!(declared, rule.attributes)
    end
    allunique(declared) || throw(ArgumentError(
        "grouped distribution rules must use unique attribute names",
    ))
    for target in targets, attribute in declared
        store = _attribute_store(target)
        !overwrite && haskey(store, attribute) && throw(ArgumentError(
            "attribute $attribute is already realized on a target",
        ))
    end
    return nothing
end

"""
    realize_grouped_attributes!(rng, targets, rules; overwrite=false)
    realize_grouped_attributes!(targets, rules; seed, stream, overwrite=false)

Group targets with each rule's `groupby` function, draw exactly once per group,
derive target-level values with the rule transform, and persist all declared
attributes. Groups and members follow first-occurrence order in `targets`.

The seed-and-stream method derives one named substream per rule, so adding an
unrelated grouped trait does not perturb existing realizations. Sort MTG nodes
by `node_id` before the call when traversal order is not part of the model
contract.
"""
function realize_grouped_attributes!(
    rng::AbstractRNG,
    targets,
    rules::AbstractVector{<:GroupedAttributeDistribution};
    overwrite::Bool=false,
)
    collected_targets = collect(targets)
    _validate_grouped_attribute_realization(collected_targets, rules, overwrite)
    assignments = Tuple{Any,Tuple}[]
    for rule in rules
        for (key, members) in _group_targets(collected_targets, rule.groupby)
            distribution = _group_distribution(rule.distribution, key, members)
            sampled = sample_distribution(rng, distribution)
            for target in members
                transformed = rule.transform(sampled, target, members)
                values = _grouped_assignment(rule.attributes, transformed)
                push!(assignments, (target, values))
            end
        end
    end
    for (target, values) in assignments
        store = _attribute_store(target)
        for (attribute, value) in values
            store[attribute] = value
        end
    end
    return collected_targets
end

function realize_grouped_attributes!(
    targets,
    rules::AbstractVector{<:GroupedAttributeDistribution};
    seed,
    stream,
    overwrite::Bool=false,
)
    collected_targets = collect(targets)
    _validate_grouped_attribute_realization(collected_targets, rules, overwrite)
    stream_name = String(stream)
    for rule in rules
        rule_name = join(string.(rule.attributes), "+")
        rng = stochastic_stream(seed, string(stream_name, '/', rule_name))
        realize_grouped_attributes!(
            rng,
            collected_targets,
            [rule];
            overwrite=true,
        )
    end
    return collected_targets
end

function _finite_lifecycle_value(value, attribute::Symbol)
    value isa Real && isfinite(value) || throw(ArgumentError(
        "$attribute must be a finite real number",
    ))
    return Float64(value)
end

"""
    update_organ_states!(targets, current_time; kwargs...)

Update explicit organ states from stored birth times and lifespans. Targets
born after `current_time` receive `not_emerged_state`; targets whose age is
strictly less than their lifespan receive `active_state`; and older targets
receive `expired_state` (by default `:abscised`).

The function does not sample. Realize the lifespan first with
[`realize_attributes!`](@ref), using any compatible `Distributions.jl`
distribution. All values are validated before any state is changed.
"""
function update_organ_states!(
    targets,
    current_time;
    birth_attribute::Symbol=:BirthTime,
    lifespan_attribute::Symbol=:Lifespan,
    state_attribute::Symbol=:OrganState,
    not_emerged_state::Symbol=:not_emerged,
    active_state::Symbol=:active,
    expired_state::Symbol=:abscised,
)
    time = _finite_lifecycle_value(current_time, :current_time)
    allunique((not_emerged_state, active_state, expired_state)) || throw(ArgumentError(
        "organ lifecycle states must be distinct",
    ))
    collected_targets = collect(targets)
    updates = Tuple{Any,Symbol}[]
    for target in collected_targets
        attributes = _attribute_store(target)
        haskey(attributes, birth_attribute) || throw(ArgumentError(
            "target has no $birth_attribute attribute",
        ))
        haskey(attributes, lifespan_attribute) || throw(ArgumentError(
            "target has no $lifespan_attribute attribute",
        ))
        birth = _finite_lifecycle_value(attributes[birth_attribute], birth_attribute)
        lifespan = _finite_lifecycle_value(
            attributes[lifespan_attribute],
            lifespan_attribute,
        )
        lifespan >= 0 || throw(DomainError(
            lifespan,
            "$lifespan_attribute cannot be negative",
        ))
        age = time - birth
        state = if age < 0
            not_emerged_state
        elseif age < lifespan
            active_state
        else
            expired_state
        end
        push!(updates, (target, state))
    end
    for (target, state) in updates
        _attribute_store(target)[state_attribute] = state
    end
    return collected_targets
end

"""
    organ_is_active(target; state_attribute=:OrganState, active_states=(:active,))

Return whether an organ should participate in current-state consumers such as
geometry reconstruction. A target without an explicit state remains active for
backward compatibility. Once a lifecycle state exists, only `active_states`
are considered active.
"""
function organ_is_active(
    target;
    state_attribute::Symbol=:OrganState,
    active_states=(:active,),
)
    attributes = _attribute_store(target)
    state = get(attributes, state_attribute, nothing)
    (state === nothing || ismissing(state)) && return true
    return state in active_states
end

function _validate_probability(probability::Real)
    isfinite(probability) || throw(ArgumentError("probability must be finite"))
    0 <= probability <= 1 ||
        throw(DomainError(probability, "probability must be between zero and one"))
    return probability
end

"""
    sample_bernoulli(rng, probability; policy=StandardSampling())

Sample a Bernoulli event. Probabilities zero and one are handled without
advancing `rng`.
"""
function sample_bernoulli(
    rng::AbstractRNG,
    probability::Real;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    return sample_bernoulli(rng, policy, probability)
end

function sample_bernoulli(
    rng::AbstractRNG,
    ::StandardSampling,
    probability::Real,
)
    probability = _validate_probability(probability)
    iszero(probability) && return false
    probability == one(probability) && return true
    return rand(rng, Bernoulli(probability)) == 1
end

"""
    sample_binomial(rng, trials, probability; policy=StandardSampling())

Sample the number of successes in `trials` independent Bernoulli events.
Degenerate cases are returned without advancing `rng`.
"""
function sample_binomial(
    rng::AbstractRNG,
    trials::Integer,
    probability::Real;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    return sample_binomial(rng, policy, trials, probability)
end

function sample_binomial(
    rng::AbstractRNG,
    ::StandardSampling,
    trials::Integer,
    probability::Real,
)
    trials >= 0 || throw(DomainError(trials, "the number of trials cannot be negative"))
    trials <= typemax(Int) || throw(ArgumentError("the number of trials is too large"))
    probability = _validate_probability(probability)
    (iszero(trials) || iszero(probability)) && return 0
    probability == one(probability) && return Int(trials)
    return rand(rng, Binomial(Int(trials), probability))
end

"""
    sample_negative_binomial(rng, successes, probability; policy=StandardSampling())

Sample the number of failures before `successes` successes. A probability of
one is deterministic; a probability of zero is rejected because the requested
number of successes would never be reached.
"""
function sample_negative_binomial(
    rng::AbstractRNG,
    successes::Real,
    probability::Real;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    return sample_negative_binomial(rng, policy, successes, probability)
end

function sample_negative_binomial(
    rng::AbstractRNG,
    ::StandardSampling,
    successes::Real,
    probability::Real,
)
    isfinite(successes) || throw(ArgumentError("the number of successes must be finite"))
    successes >= 0 ||
        throw(DomainError(successes, "the number of successes cannot be negative"))
    probability = _validate_probability(probability)
    iszero(probability) && throw(
        DomainError(probability, "success probability must be positive"),
    )
    (iszero(successes) || probability == one(probability)) && return 0
    return rand(rng, NegativeBinomial(successes, probability))
end

"""
    sample_categorical(rng, weights; policy=StandardSampling())

Return the one-based index sampled from non-negative categorical `weights`.
Weights need not be normalized. A single positive weight is handled without
advancing `rng`.
"""
function sample_categorical(
    rng::AbstractRNG,
    weights::AbstractVector{<:Real};
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    return sample_categorical(rng, policy, weights)
end

function sample_categorical(
    rng::AbstractRNG,
    ::StandardSampling,
    weights::AbstractVector{<:Real},
)
    isempty(weights) && throw(ArgumentError("categorical weights cannot be empty"))
    all(isfinite, weights) || throw(ArgumentError("categorical weights must be finite"))
    all(weight -> weight >= 0, weights) ||
        throw(DomainError(weights, "categorical weights cannot be negative"))

    positive = findall(>(0), weights)
    isempty(positive) && throw(DomainError(weights, "at least one weight must be positive"))
    length(positive) == 1 && return only(positive)

    probabilities = Float64.(weights)
    total = sum(probabilities)
    isfinite(total) || throw(ArgumentError("the sum of categorical weights must be finite"))
    probabilities ./= total
    return rand(rng, Categorical(probabilities))
end
