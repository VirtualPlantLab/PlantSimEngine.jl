module AMAPSim

import MultiScaleTreeGraph
import PlantGeom
import PlantSimEngine
import Tables
import TOML
import LinearAlgebra

"""
    visualize(plant; kwargs...)

Visualize an AMAPSim topology through PlantGeom. This optional function gains
methods only after Makie or a Makie backend is loaded; Makie is not a core
AMAPSim dependency.
"""
function visualize end

"""
    scene_editor(scene; registry=ModelRegistry(), readonly=false)

Create the optional Bonito native-scene editor. A method is installed when
Bonito v5 is loaded; Bonito remains outside AMAPSim's core dependencies.
"""
function scene_editor end

"""Return the last valid [`SceneDefinition`](@ref) held by a scene editor."""
function editor_scene end

"""
    editor_toml(editor; draft=false)

Return the canonical TOML for the last valid editor scene. With `draft=true`,
return the possibly invalid unsaved text retained by the editor.
"""
function editor_toml end

"""
    load_editor_toml!(editor, source) -> Bool

Try to load native TOML into an editor transactionally. Return `true` on
success. Invalid input remains visible as a draft and leaves the current valid
scene unchanged.
"""
function load_editor_toml! end

using DataStructures: PriorityQueue
using Distributions: Bernoulli, Binomial, Categorical, Geometric, NegativeBinomial
using Interpolations: Constant, Flat, Gridded, Linear, Previous, extrapolate, interpolate
using MultiScaleTreeGraph: Node,
    NodeMTG,
    index,
    link,
    node_id,
    scale,
    symbol,
    traverse
using PlantGeom: emit_internode!
using Random: AbstractRNG, Xoshiro, rand
using SHA

include("parameters/types.jl")
include("parameters/interpolation.jl")
include("parameters/legacy_schema.jl")
include("parameters/legacy_fpa.jl")
include("native/categories.jl")
include("native/physiological_age.jl")
include("native/initiation.jl")
include("native/applications.jl")
include("stochastic/sampling.jl")
include("development/event_queue.jl")
include("development/growth_intents.jl")
include("development/site_ledger.jl")
include("development/kernels.jl")
include("development/branching.jl")
include("development/geometry.jl")
include("topology/schema.jl")
include("topology/normalization.jl")
include("native/templates.jl")
include("native/replacement.jl")
include("native/switching.jl")
include("native/registry.jl")
include("native/toml_exchange.jl")
include("models/architecture_development.jl")
include("native/fpa_import.jl")
include("geometry/reconstruction.jl")
include("outputs/mtg.jl")
include("outputs/tables.jl")
include("outputs/manifest.jl")
include("generation.jl")
include("geometry/secondary_growth.jl")
include("modeling.jl")

export AMAPSimParameters,
    AMAPSimTopology,
    ArchitectureCoordinator,
    ArchitectureDevelopment,
    AbstractAxisCategoryInitiationModel,
    ApicalMeristems,
    Apply,
    AxisInitiationContext,
    AxisCategory,
    Axes,
    GeneratedPlant,
    GrowthUnits,
    GrowthIntent,
    CategoryInitiationModel,
    LegacyParameterError,
    Leaves,
    Modeling,
    ModelParameterSpec,
    ModelRegistry,
    Plant,
    PlantInstance,
    PlantTemplate,
    PhysiologicalAgeInitiation,
    SceneDefinition,
    SwitchingModel,
    advance_by!,
    advance_to!,
    add_initial_plant!,
    build_model,
    build_initial_topology,
    build_geometry!,
    compile_plant_template,
    compile_scene,
    event_table,
    editor_scene,
    editor_toml,
    geometry_table,
    generate_plant,
    growth_intent_key,
    import_fpa,
    load_editor_toml!,
    migrate_plant,
    read_parameters,
    read_native_scene,
    read_plant,
    register_model!,
    registered_models,
    replace_model,
    run_manifest,
    scene_editor,
    select_axis_category,
    select_model_variant,
    snapshot_table,
    summary_table,
    visualize,
    write_native_scene,
    write_plant,
    write_run_manifest

end
