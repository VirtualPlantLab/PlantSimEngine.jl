"""
    AMAPSim.Modeling

Explicit model-implementer interface for AMAPSim's parameter, stochastic,
event, developmental, topology, and geometry kernels.

Ordinary model composition and simulation use the concise names exported by
`AMAPSim`. Import this namespace only when implementing or testing botanical
kernels:

```julia
using AMAPSim
using AMAPSim.Modeling
```

The bindings are aliases of their qualified `AMAPSim.<name>` definitions; the
namespace does not duplicate types or generic functions.
"""
module Modeling

import ..AMAPSim

const API = (
    :AbstractSamplingPolicy,
    :AMAPSIM_MTG_SCALES,
    :AMAPSIM_MTG_SYMBOLS,
    :ApicalBudState,
    :AxisBendingInitialization,
    :AxisParameters,
    :AxillaryWhorlResult,
    :BranchingModelKind,
    :BudEvent,
    :BudEventQueue,
    :CycleInitialization,
    :CycleDelayedBranchInitialization,
    :CycleDelayedMarkovTransition,
    :CycleTailMortalityResult,
    :DelayedBranchInitialization,
    :DelayedBranchState,
    :DelayedMarkovTransition,
    :DelayedSemiMarkovState,
    :DelayedSemiMarkovTransition,
    :DelayedType1,
    :DelayedType2,
    :DelayedUnbranched,
    :EventID,
    :GrowthUnitTiming,
    :InitialDormancy,
    :ImmediateBranchInitialization,
    :ImmediateMarkovTransition,
    :ImmediateSemiMarkovState,
    :InternodeDimensions,
    :InterpolationMode,
    :LegacyLinearInterpolation,
    :LegacyParameterIndex,
    :LinearInterpolation,
    :LateralProductionParameters,
    :LateralProductionZone,
    :MarkovModel,
    :NeoformedTestResult,
    :ParameterCurve,
    :ParameterGroup,
    :ParameterProvenance,
    :ParameterSource,
    :ParameterSurface,
    :PlantInitialization,
    :PolycyclismResult,
    :ProgressivePruningResult,
    :PreviousStep,
    :PruningAction,
    :RemoveTerminalGrowthUnit,
    :SemiMarkovModel,
    :StandardSampling,
    :SympodialTransition,
    :TerminalStraighteningState,
    :TerminalStraighteningStep,
    :TotalAxisPruning,
    :TraumaticBranchInitialization,
    :TraumaticMarkovTransition,
    :TraumaticSemiMarkovState,
    :TraumaticSemiMarkovTransition,
    :VigorState,
    :advance_phyllotaxy,
    :advance_delayed_semimarkov_state,
    :advance_immediate_semimarkov_state,
    :advance_traumatic_semimarkov_state,
    :advance_vigor,
    :apply_terminal_straightening,
    :axis_bending_increment,
    :branch_azimuth,
    :branch_insertion_angle,
    :cancel_event!,
    :event_priority,
    :growth_unit_timing,
    :initial_vigor_state,
    :initialize_axis_bending,
    :initialize_cycle,
    :initialize_terminal_straightening,
    :internode_dimensions,
    :interpolation_mode,
    :is_immediate_production_position,
    :is_immediate_state_reset_position,
    :is_outside_apical_production_window,
    :legacy_parameter_schema,
    :light_directed_insertion_frame,
    :mortality_position,
    :normal_axis_insertion_frame,
    :parameter_by_legacy_index,
    :parameter_value,
    :peek_event,
    :plagiotropic_insertion_frame,
    :plagiotropic_phyllotaxy,
    :pop_event!,
    :projected_axis_test_count,
    :pseudo_plagiotropic_insertion_frame,
    :pseudo_plagiotropic_phyllotaxy,
    :random_absolute_insertion_angles,
    :randomized_insertion_angles,
    :reiteration_order,
    :reschedule_event!,
    :sample_axillary_whorl,
    :sample_bernoulli,
    :sample_binomial,
    :sample_bud_survival,
    :sample_categorical,
    :sample_cycle_delayed_branch_initialization,
    :sample_cycle_delayed_markov_state,
    :sample_cycle_tail_mortality,
    :sample_delayed_branch_initialization,
    :sample_delayed_markov_state,
    :sample_immediate_branch_initialization,
    :sample_immediate_markov_state,
    :sample_initial_dormancy,
    :sample_negative_binomial,
    :sample_neoformed_test,
    :sample_polycyclism,
    :sample_progressive_pruning_step,
    :sample_shifted_count,
    :sample_sympodial_direction_sign,
    :sample_sympodial_transition,
    :sample_traumatic_branch_initialization,
    :sample_traumatic_markov_state,
    :schedule_event!,
    :secondary_up_insertion_frame,
    :single_internode_bending_angle,
    :sympodial_angle,
    :synthesize_projection_metadata!,
    :topology_signature,
    :valueat,
)

for name in API
    isdefined(AMAPSim, name) || error("AMAPSim.Modeling API references undefined name $name")
    @eval const $(name) = getfield(AMAPSim, $(QuoteNode(name)))
    @eval export $(name)
end

end
