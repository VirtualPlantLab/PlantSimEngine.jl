"""
    GeneratedPlant

Result of [`generate_plant`](@ref). The result deliberately exposes the
ordinary AMAPSim topology, PlantSimEngine model, and PlantSimEngine simulation
instead of hiding them behind a separate runtime abstraction.

The `requested_stage` field is the nonnegative integer legacy developmental
horizon supplied to `generate_plant`; `seed` is its normalized `UInt64` random
seed.
"""
struct GeneratedPlant{P,T,M,S}
    parameters::P
    topology::T
    model::M
    simulation::S
    requested_stage::Int
    seed::UInt64
end

function Base.show(io::IO, result::GeneratedPlant)
    print(
        io,
        "GeneratedPlant(stage=",
        result.requested_stage,
        ", seed=",
        result.seed,
        ", steps=",
        PlantSimEngine.current_step(result.simulation),
        ")",
    )
end

function _development_objects(runtime)
    model = PlantSimEngine.runtime_model(runtime)
    plants = collect(PlantSimEngine.model_objects(model; scale = AMAPSIM_MTG_SYMBOLS.plant))
    isempty(plants) &&
        throw(ArgumentError("AMAPSim advancement requires at least one plant object"))
    sort!(plants; by = plant -> node_id(PlantSimEngine.source_node(model, plant)))
    return plants
end

function _validate_development_value(value, label::AbstractString)
    value isa Real || throw(ArgumentError("$label must be real"))
    isfinite(value) || throw(ArgumentError("$label must be finite"))
    value >= zero(value) || throw(DomainError(value, "$label cannot be negative"))
    return value
end

function _convert_development_value(::Type{T}, value, label::AbstractString) where {T<:Real}
    converted = try
        convert(T, value)
    catch error
        throw(
            ArgumentError(
                "$label cannot be represented by the model's development type $T: " *
                sprint(showerror, error),
            ),
        )
    end
    isfinite(converted) ||
        throw(ArgumentError("$label cannot be represented as a finite $T value"))
    converted >= zero(T) ||
        throw(DomainError(value, "$label cannot be represented as a nonnegative $T value"))
    return converted
end

function _prepare_development_increments(runtime, amount)
    _validate_development_value(amount, "development increment")
    return map(_development_objects(runtime)) do plant
        status = plant.status
        T = typeof(status.development_time)
        increment = _convert_development_value(T, amount, "development increment")
        (; status, increment)
    end
end

function _prepare_development_targets(runtime, target)
    _validate_development_value(target, "development target")
    return map(_development_objects(runtime)) do plant
        status = plant.status
        current = status.development_time
        T = typeof(current)
        converted_target = _convert_development_value(T, target, "development target")
        converted_target >= current || throw(
            DomainError(
                target,
                "development target cannot precede the current value $current " *
                "for plant index $(index(PlantSimEngine.source_node(runtime, status)))",
            ),
        )
        (; status, increment = converted_target - current)
    end
end

function _assign_development_increments!(updates)
    for update in updates
        update.status.development_increment = update.increment
    end
    return nothing
end

"""
    advance_by!(model, amount; kwargs...) -> PlantSimEngine.Simulation
    advance_by!(simulation, amount) -> PlantSimEngine.Simulation

Advance every AMAPSim plant in a PlantSimEngine model or live simulation by
one nonnegative, finite amount of AMAPSim's legacy virtual developmental
coordinate. One call performs one outer PlantSimEngine application execution,
so all events due at or before the resulting plant-local target are processed.

For a fresh model, `kwargs` are forwarded to `PlantSimEngine.run!` except that
`steps=1` is fixed. Advancing a simulation preserves its timeline and retained
output streams through `PlantSimEngine.continue!`.
"""
function advance_by!(model::PlantSimEngine.CompositeModel, amount; kwargs...)
    updates = _prepare_development_increments(model, amount)
    _assign_development_increments!(updates)
    return PlantSimEngine.run!(model; steps = 1, kwargs...)
end

function advance_by!(simulation::PlantSimEngine.Simulation, amount)
    updates = _prepare_development_increments(simulation, amount)
    _assign_development_increments!(updates)
    PlantSimEngine.continue!(simulation; steps = 1)
    return simulation
end

"""
    advance_to!(model, target; kwargs...) -> PlantSimEngine.Simulation
    advance_to!(simulation, target) -> PlantSimEngine.Simulation

Advance every AMAPSim plant to the same nonnegative, finite value of the
legacy virtual developmental coordinate. Fractional targets and event-boundary
targets are supported. A target below any plant's current value is rejected
before any plant status is changed.

For a fresh model, `kwargs` are forwarded to `PlantSimEngine.run!` except that
`steps=1` is fixed. The simulation method preserves the existing runtime
timeline and retained output streams.
"""
function advance_to!(model::PlantSimEngine.CompositeModel, target; kwargs...)
    updates = _prepare_development_targets(model, target)
    _assign_development_increments!(updates)
    return PlantSimEngine.run!(model; steps = 1, kwargs...)
end

function advance_to!(simulation::PlantSimEngine.Simulation, target)
    updates = _prepare_development_targets(simulation, target)
    _assign_development_increments!(updates)
    PlantSimEngine.continue!(simulation; steps = 1)
    return simulation
end

function _generation_stage(stage)
    stage isa Integer && !(stage isa Bool) ||
        throw(ArgumentError("generation stage must be an integer"))
    stage >= 0 || throw(DomainError(stage, "generation stage cannot be negative"))
    stage <= typemax(Int) || throw(ArgumentError("generation stage does not fit in Int"))
    return Int(stage)
end

"""
    generate_plant(parameters; stage, seed=1, rng_factory=nothing, position=(0, 0, 0), kwargs...)
    generate_plant(parameter_path; kwargs...)

Generate one AMAPSim plant at a requested legacy developmental horizon. The
initial topology is built at stage zero, an ordinary PlantSimEngine model is
constructed, and [`advance_to!`](@ref) performs the generation. `stage` must be
a nonnegative integer for legacy command-line parity; the lower-level
advancement functions accept real-valued horizons.

The returned [`GeneratedPlant`](@ref) exposes `topology`, `model`, and
`simulation` directly. `applications`, `environment`, `time_type`, `outputs`,
and `performance` retain their PlantSimEngine meanings. Pass `constants` to
override the PlantSimEngine run constants.
The optional `rng_factory(seed)` is forwarded to [`build_model`](@ref) before
botanical initialization; omitting it preserves the standard `Xoshiro` stream.
"""
function generate_plant(
    parameters::AMAPSimParameters;
    stage,
    seed = 1,
    rng_factory = nothing,
    position = (0.0, 0.0, 0.0),
    plant_index::Integer = 1,
    time_type::Type{T} = Float64,
    applications = (),
    environment = nothing,
    outputs = :none,
    performance::Bool = false,
    constants = nothing,
) where {T<:Real}
    requested_stage = _generation_stage(stage)
    normalized_seed = _validate_seed(seed, "random seed")
    topology = build_initial_topology(parameters; plant_index, stage = 0, position)
    model = build_model(
        topology;
        development_increment = zero(T),
        parameters,
        seed = normalized_seed,
        rng_factory,
        time_type = T,
        applications,
        environment,
    )
    simulation = if isnothing(constants)
        advance_to!(model, requested_stage; outputs, performance)
    else
        advance_to!(model, requested_stage; outputs, performance, constants)
    end
    topology.plant[:Stage] = requested_stage
    return GeneratedPlant(
        parameters,
        topology,
        model,
        simulation,
        requested_stage,
        normalized_seed,
    )
end

function generate_plant(path::AbstractString; kwargs...)
    return generate_plant(read_parameters(path); kwargs...)
end

"""
    build_geometry!(result::GeneratedPlant; parameters=result.parameters,
                    light_direction=nothing, kwargs...)

Reconstruct a generated plant's geometry and return `result`. Source insertion
mode 8 requires the explicit `light_direction` keyword, just like the topology
method; AMAPSim does not infer that directional signal from the simulation
environment.
"""
function build_geometry!(
    result::GeneratedPlant;
    parameters = result.parameters,
    light_direction = nothing,
    kwargs...,
)
    build_geometry!(
        result.topology;
        parameters,
        light_direction,
        kwargs...,
    )
    return result
end

write_plant(path::AbstractString, result::GeneratedPlant; kwargs...) =
    write_plant(path, result.topology; kwargs...)

event_table(result::GeneratedPlant) = event_table(result.model)
snapshot_table(result::GeneratedPlant; kwargs...) =
    snapshot_table(result.topology; kwargs...)
summary_table(result::GeneratedPlant) = summary_table(result.topology)
geometry_table(result::GeneratedPlant; kwargs...) =
    geometry_table(result.topology; kwargs...)
topology_signature(result::GeneratedPlant) = topology_signature(result.topology.scene)
run_manifest(result::GeneratedPlant; kwargs...) = run_manifest(result.model; kwargs...)

function write_run_manifest(path::AbstractString, result::GeneratedPlant; kwargs...)
    return write_run_manifest(path, result.model; kwargs...)
end
