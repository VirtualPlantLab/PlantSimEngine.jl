struct _NoModelParameterDefault end
const _NO_MODEL_PARAMETER_DEFAULT = _NoModelParameterDefault()

"""
    ModelParameterSpec(type; default, minimum=nothing, maximum=nothing,
                       allowed=nothing)

Declare one parameter accepted by a registered model constructor. Omitting
`default` makes the parameter required. Numeric bounds are inclusive, and
`allowed` may contain an explicit finite set of accepted values.
"""
struct ModelParameterSpec
    value_type::Type
    default
    minimum
    maximum
    allowed
end

function _coerce_registered_parameter(value, specification::ModelParameterSpec, context)
    target = specification.value_type
    converted = if target === Any || value isa target
        value
    elseif target === Symbol && value isa AbstractString
        Symbol(value)
    elseif target <: AbstractFloat && value isa Real && !(value isa Bool)
        convert(target, value)
    elseif target <: Integer && value isa Integer && !(value isa Bool)
        try
            convert(target, value)
        catch error
            throw(ArgumentError("$context cannot be represented as $target: $error"))
        end
    elseif target <: AbstractString && value isa AbstractString
        convert(target, value)
    else
        throw(ArgumentError(
            "$context must be a $target, got $(typeof(value))",
        ))
    end
    minimum = specification.minimum
    if minimum !== nothing
        converted isa Real || throw(ArgumentError(
            "$context has a numeric minimum but is not numeric",
        ))
        converted >= minimum || throw(DomainError(
            converted,
            "$context must be greater than or equal to $minimum",
        ))
    end
    maximum = specification.maximum
    if maximum !== nothing
        converted isa Real || throw(ArgumentError(
            "$context has a numeric maximum but is not numeric",
        ))
        converted <= maximum || throw(DomainError(
            converted,
            "$context must be less than or equal to $maximum",
        ))
    end
    allowed = specification.allowed
    if allowed !== nothing
        converted in allowed || throw(ArgumentError(
            "$context must be one of $(Tuple(allowed)), got $(repr(converted))",
        ))
    end
    return converted
end

function ModelParameterSpec(
    value_type::Type;
    default=_NO_MODEL_PARAMETER_DEFAULT,
    minimum=nothing,
    maximum=nothing,
    allowed=nothing,
)
    minimum === nothing || minimum isa Real || throw(ArgumentError(
        "registered model parameter minimum must be real or nothing",
    ))
    maximum === nothing || maximum isa Real || throw(ArgumentError(
        "registered model parameter maximum must be real or nothing",
    ))
    minimum !== nothing && maximum !== nothing && minimum > maximum &&
        throw(ArgumentError(
            "registered model parameter minimum cannot exceed its maximum",
        ))
    normalized_allowed = allowed === nothing ? nothing : Tuple(allowed)
    specification = ModelParameterSpec(
        value_type,
        default,
        minimum,
        maximum,
        normalized_allowed,
    )
    default === _NO_MODEL_PARAMETER_DEFAULT || _coerce_registered_parameter(
        default,
        specification,
        "registered model parameter default",
    )
    return specification
end

_parameter_is_required(specification::ModelParameterSpec) =
    specification.default === _NO_MODEL_PARAMETER_DEFAULT

struct _ModelRegistration{S,C,E}
    identifier::String
    version::Int
    model_type
    parameters::S
    construct::C
    extract::E
end

"""
    ModelRegistry(; include_defaults=true)

Create a registry of model constructors that may be referenced by native TOML
documents. The default registry contains AMAPSim's safe, parameter-free
`PhysiologicalAgeInitiation` model. Script closures are never registered
implicitly.
"""
mutable struct ModelRegistry
    entries::Dict{Tuple{String,Int},_ModelRegistration}
end

function ModelRegistry(; include_defaults::Bool=true)
    registry = ModelRegistry(Dict{Tuple{String,Int},_ModelRegistration}())
    include_defaults && _register_default_models!(registry)
    return registry
end

Base.length(registry::ModelRegistry) = length(registry.entries)
Base.keys(registry::ModelRegistry) = sort!(
    ["$identifier@$version" for (identifier, version) in keys(registry.entries)],
)
Base.haskey(registry::ModelRegistry, reference::AbstractString) = try
    haskey(registry.entries, _model_reference(reference))
catch error
    error isa ArgumentError || rethrow()
    false
end

"""
    registered_models(registry) -> Vector{NamedTuple}

Return the stable, editor-safe metadata for every model in `registry`, sorted
by versioned reference. Each record contains `reference`, `model_type`, and the
declared `parameters` named tuple of [`ModelParameterSpec`](@ref) values.

Constructor and extractor closures remain private to the registry. This lets
interactive tools present only models that can actually be serialized without
turning the registry into an executable-code exchange format.
"""
function registered_models(registry::ModelRegistry)
    records = [
        (
            reference="$(registration.identifier)@$(registration.version)",
            model_type=registration.model_type,
            parameters=registration.parameters,
        ) for registration in values(registry.entries)
    ]
    return sort!(records; by=record -> record.reference)
end

function _model_reference(reference)
    reference isa Union{Symbol,AbstractString} || throw(ArgumentError(
        "registered model reference must be a symbol or string",
    ))
    text = String(reference)
    matched = match(r"^([A-Za-z][A-Za-z0-9_.-]*)@([1-9][0-9]*)$", text)
    matched === nothing && throw(ArgumentError(
        "registered model reference $(repr(text)) must have the form " *
        "Namespace.Name@positive_version",
    ))
    version = tryparse(Int, matched.captures[2])
    version === nothing && throw(ArgumentError(
        "registered model version in $(repr(text)) is too large",
    ))
    return (String(matched.captures[1]), version)
end

function _validated_model_parameter_schema(parameters)
    parameters isa NamedTuple || throw(ArgumentError(
        "registered model parameters must be a named tuple of ModelParameterSpec values",
    ))
    for (name, specification) in pairs(parameters)
        Base.isidentifier(String(name)) || throw(ArgumentError(
            "registered model parameter name $(repr(name)) must follow Julia " *
            "identifier syntax",
        ))
        specification isa ModelParameterSpec || throw(ArgumentError(
            "registered model parameter $(repr(name)) must be a ModelParameterSpec",
        ))
    end
    return parameters
end

"""
    register_model!(registry, reference, model_type;
                    parameters=NamedTuple(), construct=nothing, extract=nothing)

Register one versioned model representation. `reference` uses the stable
`"Namespace.Name@version"` form. `construct` receives a validated named tuple;
`extract` receives a model and must return parameters with the same names.
When omitted, keyword construction and same-named properties are used.
"""
function register_model!(
    registry::ModelRegistry,
    reference,
    model_type;
    parameters=NamedTuple(),
    construct=nothing,
    extract=nothing,
)
    identifier, version = _model_reference(reference)
    key = (identifier, version)
    haskey(registry.entries, key) && throw(ArgumentError(
        "registered model reference $(repr("$identifier@$version")) already exists",
    ))
    (model_type isa DataType || model_type isa UnionAll) || throw(ArgumentError(
        "registered model type must be a Julia type, got $(typeof(model_type))",
    ))
    model_type <: Union{
        PlantSimEngine.AbstractModel,
        AbstractAxisCategoryInitiationModel,
    } || throw(ArgumentError(
        "registered model type $model_type must subtype PlantSimEngine.AbstractModel " *
        "or AbstractAxisCategoryInitiationModel",
    ))
    for registration in values(registry.entries)
        registration.model_type === model_type || continue
        registration.identifier == identifier || throw(ArgumentError(
            "model type $model_type is already registered as " *
            "$(registration.identifier); one type cannot serialize under two " *
            "stable identifiers",
        ))
    end
    schema = _validated_model_parameter_schema(parameters)
    builder = construct === nothing ?
              values -> model_type(; values...) : construct
    encoder = extract === nothing ? model -> NamedTuple{keys(schema)}(
        Tuple(getproperty(model, name) for name in keys(schema)),
    ) : extract
    registration = _ModelRegistration(
        identifier,
        version,
        model_type,
        schema,
        builder,
        encoder,
    )
    registry.entries[key] = registration
    return registry
end

function _registered_parameter_values(values, schema, context)
    pairs_by_name = if values isa NamedTuple
        Dict{Symbol,Any}(pairs(values))
    elseif values isa AbstractDict
        Dict{Symbol,Any}(Symbol(name) => value for (name, value) in pairs(values))
    else
        throw(ArgumentError("$context must be a named tuple or table"))
    end
    expected = Set(keys(schema))
    unknown = sort!(collect(setdiff(Set(keys(pairs_by_name)), expected)); by=string)
    isempty(unknown) || throw(ArgumentError(
        "$context contains unknown parameter(s) $(Tuple(unknown)); expected " *
        "$(keys(schema))",
    ))
    normalized = Any[]
    for name in keys(schema)
        specification = schema[name]
        value = if haskey(pairs_by_name, name)
            pairs_by_name[name]
        elseif _parameter_is_required(specification)
            throw(ArgumentError("$context is missing required parameter $(repr(name))"))
        else
            specification.default
        end
        push!(
            normalized,
            _coerce_registered_parameter(
                value,
                specification,
                "$context parameter $(repr(name))",
            ),
        )
    end
    return NamedTuple{keys(schema)}(Tuple(normalized))
end

function _registration_for_model(registry::ModelRegistry, model, context)
    candidates = filter(
        registration -> model isa registration.model_type,
        collect(values(registry.entries)),
    )
    isempty(candidates) && throw(ArgumentError(
        "$context uses unregistered script-only model $(typeof(model)); call " *
        "register_model! with a stable versioned identifier before TOML export",
    ))
    identifiers = unique(registration.identifier for registration in candidates)
    length(identifiers) == 1 || throw(ArgumentError(
        "$context matches several registered model identifiers $(Tuple(identifiers))",
    ))
    sort!(candidates; by=registration -> registration.version)
    return last(candidates)
end

function _registered_model_parameters(registration, model, context)
    extracted = try
        registration.extract(model)
    catch error
        throw(ArgumentError("$context parameter extraction failed: $error"))
    end
    return _registered_parameter_values(
        extracted,
        registration.parameters,
        context,
    )
end

function _registered_model_record(registry::ModelRegistry, model, context)
    registration = _registration_for_model(registry, model, context)
    parameters = _registered_model_parameters(registration, model, context)
    return (
        reference="$(registration.identifier)@$(registration.version)",
        parameters,
    )
end

function _construct_registered_model(
    registry::ModelRegistry,
    reference,
    parameters,
    expected_type,
    context,
)
    key = _model_reference(reference)
    registration = get(registry.entries, key, nothing)
    registration === nothing && throw(ArgumentError(
        "$context references unknown model $(repr(String(reference))); registered " *
        "models are $(Tuple(keys(registry)))",
    ))
    registration.model_type <: expected_type || throw(ArgumentError(
        "$context model $(repr(String(reference))) has type " *
        "$(registration.model_type), expected a subtype of $expected_type",
    ))
    values = _registered_parameter_values(
        parameters,
        registration.parameters,
        "$context model $(repr(String(reference)))",
    )
    model = try
        registration.construct(values)
    catch error
        throw(ArgumentError(
            "$context model $(repr(String(reference))) construction failed: $error",
        ))
    end
    model isa registration.model_type || throw(ArgumentError(
        "$context model constructor for $(repr(String(reference))) returned " *
        "$(typeof(model)), expected $(registration.model_type)",
    ))
    return model
end

function _register_default_models!(registry::ModelRegistry)
    register_model!(
        registry,
        "AMAPSim.PhysiologicalAgeInitiation@1",
        PhysiologicalAgeInitiation;
        construct=parameters -> PhysiologicalAgeInitiation(),
        extract=model -> NamedTuple(),
    )
    return registry
end
