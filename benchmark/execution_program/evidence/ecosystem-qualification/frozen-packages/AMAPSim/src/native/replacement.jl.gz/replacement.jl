function _replacement_model_contract(model, context)
    model isa PlantSimEngine.AbstractModel || throw(ArgumentError(
        "$context replacement must be a PlantSimEngine AbstractModel, got " *
        "$(typeof(model))",
    ))
    # Delegate semantic equality to PlantSimEngine, including output location,
    # declaration kind/type, contracts, and parameter-dependent defaults.
    return PlantSimEngine.Authoring.model_interface(model)
end

function _validate_replacement_contract(base, replacement, context)
    expected = _replacement_model_contract(base, context)
    actual = _replacement_model_contract(replacement, context)
    expected == actual || throw(ArgumentError(
        "$context has an incompatible model contract; expected $expected, got " *
        "$actual. Replacements may change parameters or implementation, but " *
        "not the declared PlantSimEngine interface",
    ))
    return replacement
end

function _template_application(template::PlantTemplate, application)
    name = _application_name(application)
    match = findfirst(candidate -> candidate.name == name, template.applications)
    match === nothing && throw(ArgumentError(
        "plant template $(repr(template.id)) has no application $(repr(name)); " *
        "available applications are " *
        "$(Tuple(candidate.name for candidate in template.applications))",
    ))
    return match, template.applications[match]
end

function _replace_application_model(application::Apply, model)
    return Apply(
        application.name,
        model;
        on=application.on,
        inputs=application.inputs,
        calls=application.calls,
        environment=application.environment,
        every=application.every,
        environment_bindings=application.environment_bindings,
        environment_window=application.environment_window,
        output_routing=application.output_routing,
        updates=application.updates,
    )
end

function _replace_named_override(overrides::NamedTuple, name::Symbol, model)
    entries = Pair{Symbol,Any}[]
    replaced = false
    for (candidate, current) in pairs(overrides)
        if candidate == name
            push!(entries, name => model)
            replaced = true
        else
            push!(entries, candidate => current)
        end
    end
    replaced || push!(entries, name => model)
    return (; entries...)
end

function _rebuild_plant_instance(
    instance::PlantInstance;
    overrides=instance.overrides,
    object_overrides=instance.object_overrides,
)
    return PlantInstance(
        instance.id,
        instance.template;
        initialization=instance.initialization,
        seed=instance.seed,
        overrides,
        object_overrides,
    )
end

"""
    replace_model(template, application, replacement) -> PlantTemplate

Return a new plant template whose named application uses `replacement` as its
default model. The original template is unchanged. The replacement must keep
the same PlantSimEngine process and declared input, output, and environment
variables.
"""
function replace_model(
    template::PlantTemplate,
    application,
    replacement::PlantSimEngine.AbstractModel,
)
    position, base = _template_application(template, application)
    context = "template $(repr(template.id)) application $(repr(base.name))"
    _validate_replacement_contract(base.model, replacement, context)
    applications = ntuple(length(template.applications)) do index
        index == position ? _replace_application_model(base, replacement) :
        template.applications[index]
    end
    return PlantTemplate(
        template.id;
        axis_categories=template.axis_categories,
        initial_axis_category=template.initial_axis_category,
        initiation=template.initiation,
        applications,
        species=template.species,
        initialization=template.initialization,
        parameters=template.parameters,
    )
end

"""
    replace_model(plant, application, replacement) -> PlantInstance

Return a new plant instance with an instance-local override for one named
template application. Other instances that reuse the template are unaffected.
The original definition and any already compiled simulation are unchanged.
"""
function replace_model(
    plant::PlantInstance,
    application,
    replacement::PlantSimEngine.AbstractModel,
)
    _, base = _template_application(plant.template, application)
    context = "plant $(repr(plant.id)) application $(repr(base.name))"
    _validate_replacement_contract(base.model, replacement, context)
    overrides = _replace_named_override(plant.overrides, base.name, replacement)
    return _rebuild_plant_instance(plant; overrides)
end

"""
    replace_model(plant, object, application, replacement) -> PlantInstance

Return a new plant instance with an exceptional-object override. `object` is a
PlantSimEngine `ObjectId` or a value accepted by its constructor. The model
contract is checked immediately; ownership and selector membership are checked
when the instance is compiled.
"""
function replace_model(
    plant::PlantInstance,
    object,
    application,
    replacement::PlantSimEngine.AbstractModel,
)
    _, base = _template_application(plant.template, application)
    context = "object override in plant $(repr(plant.id)) for application " *
              "$(repr(base.name))"
    _validate_replacement_contract(base.model, replacement, context)
    object_id = PlantSimEngine.ObjectId(object)
    overrides = PlantSimEngine.Override[
        override for override in plant.object_overrides
        if !(override.object == object_id && override.application == base.name)
    ]
    push!(
        overrides,
        PlantSimEngine.Override(
            object=object_id,
            application=base.name,
            model=replacement,
        ),
    )
    return _rebuild_plant_instance(plant; object_overrides=Tuple(overrides))
end

"""
    replace_model(model, plant, application, replacement) -> CompositeModel

Transactionally add or replace an instance override on a compiled definition.
PlantSimEngine validates the mounted application contract and returns a new
model; `model` is not mutated. This is configuration editing, not state
migration for a running `Simulation`.
"""
function replace_model(
    model::PlantSimEngine.CompositeModel,
    plant,
    application,
    replacement::PlantSimEngine.AbstractModel,
)
    return PlantSimEngine.apply_model_graph_edit(
        model,
        PlantSimEngine.SetModelInstanceOverride(plant, application, replacement),
    )
end

"""
    replace_model(model, plant, object, application, replacement) -> CompositeModel

Transactionally add or replace an exceptional-object override on a compiled
definition. PlantSimEngine verifies application identity, model contract, and
instance ownership before returning the new model. The input model remains
unchanged.
"""
function replace_model(
    model::PlantSimEngine.CompositeModel,
    plant,
    object,
    application,
    replacement::PlantSimEngine.AbstractModel,
)
    return PlantSimEngine.apply_model_graph_edit(
        model,
        PlantSimEngine.SetModelObjectOverride(
            plant,
            object,
            application,
            replacement,
        ),
    )
end
