const _NATIVE_SCENE_SCHEMA_VERSION = 1
const _NATIVE_SCENE_FORMAT = "AMAPSim.native_scene"
const _NATIVE_TOML_TYPE_KEY = "__amapsim_type"

function _toml_encode_value(value, context)
    value isa Bool && return value
    if value isa Integer
        value isa UInt64 && value > typemax(Int64) && return Dict(
            _NATIVE_TOML_TYPE_KEY => "uint64",
            "value" => string(value),
        )
        typemin(Int64) <= value <= typemax(Int64) || throw(ArgumentError(
            "$context integer is outside the TOML Int64 range",
        ))
        return Int64(value)
    end
    if value isa AbstractFloat
        isfinite(value) || throw(ArgumentError("$context must be finite for TOML export"))
        return Float64(value)
    end
    value isa AbstractString && return String(value)
    value isa Symbol && return Dict(
        _NATIVE_TOML_TYPE_KEY => "symbol",
        "value" => String(value),
    )
    value === nothing && return Dict(_NATIVE_TOML_TYPE_KEY => "nothing")
    value isa Tuple && return Dict(
        _NATIVE_TOML_TYPE_KEY => "tuple",
        "values" => [
            _toml_encode_value(item, "$context tuple item $position")
            for (position, item) in pairs(value)
        ],
    )
    value isa AbstractVector && return [
        _toml_encode_value(item, "$context array item $position")
        for (position, item) in pairs(value)
    ]
    if value isa NamedTuple || value isa AbstractDict
        encoded = Dict{String,Any}()
        for (name, item) in pairs(value)
            name isa Union{Symbol,AbstractString} || throw(ArgumentError(
                "$context table keys must be symbols or strings",
            ))
            key = String(name)
            key == _NATIVE_TOML_TYPE_KEY && throw(ArgumentError(
                "$context uses reserved key $(repr(_NATIVE_TOML_TYPE_KEY))",
            ))
            haskey(encoded, key) && throw(ArgumentError(
                "$context contains duplicate key $(repr(key))",
            ))
            encoded[key] = _toml_encode_value(item, "$context.$key")
        end
        return encoded
    end
    throw(ArgumentError(
        "$context value of type $(typeof(value)) is script-only and cannot be " *
        "represented safely in native TOML",
    ))
end

function _toml_table_named_tuple(table::AbstractDict, context)
    names = sort!(Symbol[Symbol(key) for key in keys(table)]; by=string)
    values = Tuple(
        _toml_decode_value(table[String(name)], "$context.$name") for name in names
    )
    return NamedTuple{Tuple(names)}(values)
end

function _toml_decode_value(value, context)
    value isa Union{Bool,Integer,AbstractFloat,AbstractString} && return value
    value isa AbstractVector && return [
        _toml_decode_value(item, "$context array item $position")
        for (position, item) in pairs(value)
    ]
    value isa AbstractDict || throw(ArgumentError(
        "$context contains unsupported TOML value $(typeof(value))",
    ))
    if haskey(value, _NATIVE_TOML_TYPE_KEY)
        tag = value[_NATIVE_TOML_TYPE_KEY]
        tag isa AbstractString || throw(ArgumentError(
            "$context typed value tag must be a string",
        ))
        if tag == "nothing"
            keys_set = Set(String.(keys(value)))
            keys_set == Set([_NATIVE_TOML_TYPE_KEY]) || throw(ArgumentError(
                "$context nothing value contains unexpected fields",
            ))
            return nothing
        elseif tag == "symbol"
            _validate_toml_keys(
                value,
                (_NATIVE_TOML_TYPE_KEY, "value"),
                context,
            )
            text = value["value"]
            text isa AbstractString || throw(ArgumentError(
                "$context symbol value must be a string",
            ))
            return Symbol(text)
        elseif tag == "tuple"
            _validate_toml_keys(
                value,
                (_NATIVE_TOML_TYPE_KEY, "values"),
                context,
            )
            items = value["values"]
            items isa AbstractVector || throw(ArgumentError(
                "$context tuple values must be an array",
            ))
            return Tuple(
                _toml_decode_value(item, "$context tuple item $position")
                for (position, item) in pairs(items)
            )
        elseif tag == "uint64"
            _validate_toml_keys(
                value,
                (_NATIVE_TOML_TYPE_KEY, "value"),
                context,
            )
            text = value["value"]
            text isa AbstractString || throw(ArgumentError(
                "$context UInt64 value must be a decimal string",
            ))
            parsed = tryparse(UInt64, text)
            parsed === nothing && throw(ArgumentError(
                "$context contains invalid UInt64 value $(repr(text))",
            ))
            return parsed
        end
        throw(ArgumentError("$context has unknown typed value tag $(repr(tag))"))
    end
    return _toml_table_named_tuple(value, context)
end

function _validate_toml_keys(table, allowed, context; required=allowed)
    table isa AbstractDict || throw(ArgumentError("$context must be a TOML table"))
    actual = Set(String.(keys(table)))
    allowed_set = Set(String.(allowed))
    unknown = sort!(collect(setdiff(actual, allowed_set)))
    isempty(unknown) || throw(ArgumentError(
        "$context contains unknown field(s) $(Tuple(unknown)); supported fields " *
        "are $(Tuple(sort!(collect(allowed_set))))",
    ))
    required_set = Set(String.(required))
    missing = sort!(collect(setdiff(required_set, actual)))
    isempty(missing) || throw(ArgumentError(
        "$context is missing required field(s) $(Tuple(missing))",
    ))
    return table
end

function _model_to_toml(registry, model, context)
    record = _registered_model_record(registry, model, context)
    return Dict(
        "model" => record.reference,
        "parameters" => _toml_encode_value(
            record.parameters,
            "$context parameters",
        ),
    )
end

function _model_from_toml(registry, table, expected_type, context)
    _validate_toml_keys(table, ("model", "parameters"), context)
    reference = table["model"]
    reference isa AbstractString || throw(ArgumentError(
        "$context model reference must be a string",
    ))
    parameters = _toml_decode_value(table["parameters"], "$context parameters")
    return _construct_registered_model(
        registry,
        reference,
        parameters,
        expected_type,
        context,
    )
end

_selector_axis_table(category) = category === nothing ?
                                Dict("entity" => "axis") :
                                Dict("entity" => "axis", "category" => String(category))

_selector_to_toml(::Plant, context) = Dict("entity" => "plant")
_selector_to_toml(selector::Axes, context) = _selector_axis_table(selector.category)
_selector_to_toml(selector::ApicalMeristems, context) = Dict(
    "entity" => "apical_meristem",
    "bearer" => _selector_axis_table(selector.bearer.category),
)
_selector_to_toml(selector::GrowthUnits, context) = Dict(
    "entity" => "growth_unit",
    "axis" => _selector_axis_table(selector.axis.category),
)
_selector_to_toml(selector::Leaves, context) = Dict(
    "entity" => "leaf",
    "axis" => _selector_axis_table(selector.axis.category),
)
function _selector_to_toml(selector, context)
    throw(ArgumentError(
        "$context selector $(typeof(selector)) is script-only; native TOML " *
        "supports Plant, Axes, ApicalMeristems, GrowthUnits, and Leaves",
    ))
end

function _axis_selector_from_toml(table, context)
    _validate_toml_keys(
        table,
        ("entity", "category"),
        context;
        required=("entity",),
    )
    table["entity"] == "axis" || throw(ArgumentError(
        "$context must have entity = \"axis\"",
    ))
    category = get(table, "category", nothing)
    category === nothing || category isa AbstractString || throw(ArgumentError(
        "$context category must be a string",
    ))
    return Axes(; category)
end

function _selector_from_toml(table, context)
    table isa AbstractDict || throw(ArgumentError("$context selector must be a table"))
    haskey(table, "entity") || throw(ArgumentError(
        "$context selector is missing required field \"entity\"",
    ))
    entity = table["entity"]
    entity isa AbstractString || throw(ArgumentError(
        "$context selector entity must be a string",
    ))
    if entity == "plant"
        _validate_toml_keys(table, ("entity",), context)
        return Plant()
    elseif entity == "axis"
        return _axis_selector_from_toml(table, context)
    elseif entity == "apical_meristem"
        _validate_toml_keys(table, ("entity", "bearer"), context)
        return ApicalMeristems(; bearer=_axis_selector_from_toml(
            table["bearer"],
            "$context bearer",
        ))
    elseif entity == "growth_unit"
        _validate_toml_keys(table, ("entity", "axis"), context)
        return GrowthUnits(; axis=_axis_selector_from_toml(
            table["axis"],
            "$context axis",
        ))
    elseif entity == "leaf"
        _validate_toml_keys(table, ("entity", "axis"), context)
        return Leaves(; axis=_axis_selector_from_toml(
            table["axis"],
            "$context axis",
        ))
    end
    throw(ArgumentError(
        "$context has unknown selector entity $(repr(entity)); supported entities " *
        "are plant, axis, apical_meristem, growth_unit, and leaf",
    ))
end

function _updates_to_toml(updates, context)
    normalized = updates isa PlantSimEngine.Updates ? (updates,) : updates
    normalized isa Tuple || throw(ArgumentError(
        "$context updates must be a tuple of PlantSimEngine.Updates values",
    ))
    return [
        begin
            update isa PlantSimEngine.Updates || throw(ArgumentError(
                "$context updates must contain PlantSimEngine.Updates values",
            ))
            Dict(
                "variables" => String.(collect(update.variables)),
                "after" => String.(collect(update.after)),
            )
        end for update in normalized
    ]
end

function _updates_from_toml(rows, context)
    rows isa AbstractVector || throw(ArgumentError("$context updates must be an array"))
    return Tuple(begin
        _validate_toml_keys(row, ("variables", "after"), "$context item $position")
        variables = row["variables"]
        after = row["after"]
        variables isa AbstractVector && all(item -> item isa AbstractString, variables) ||
            throw(ArgumentError("$context item $position variables must be strings"))
        after isa AbstractVector && all(item -> item isa AbstractString, after) ||
            throw(ArgumentError("$context item $position after must be strings"))
        PlantSimEngine.Updates(Symbol.(variables)...; after=Symbol.(after))
    end for (position, row) in pairs(rows))
end

function _application_to_toml(application::Apply, registry, context)
    table = Dict{String,Any}(
        "name" => String(application.name),
        "on" => _selector_to_toml(application.on, "$context target"),
    )
    merge!(table, _model_to_toml(registry, application.model, "$context model"))
    optional_values = (
        inputs=application.inputs,
        calls=application.calls,
        environment=application.environment,
        every=application.every,
        environment_bindings=application.environment_bindings,
        environment_window=application.environment_window,
        output_routing=application.output_routing,
    )
    for (name, value) in pairs(optional_values)
        omit = value === nothing || (value isa Union{Tuple,NamedTuple} && isempty(value))
        omit && continue
        table[String(name)] = _toml_encode_value(value, "$context $name")
    end
    updates = _updates_to_toml(application.updates, context)
    isempty(updates) || (table["updates"] = updates)
    return table
end

function _application_from_toml(table, registry, context)
    fields = (
        "name",
        "model",
        "parameters",
        "on",
        "inputs",
        "calls",
        "environment",
        "every",
        "environment_bindings",
        "environment_window",
        "output_routing",
        "updates",
    )
    _validate_toml_keys(
        table,
        fields,
        context;
        required=("name", "model", "parameters", "on"),
    )
    name = table["name"]
    name isa AbstractString || throw(ArgumentError("$context name must be a string"))
    model = _model_from_toml(
        registry,
        Dict("model" => table["model"], "parameters" => table["parameters"]),
        PlantSimEngine.AbstractModel,
        "$context model",
    )
    on = _selector_from_toml(table["on"], "$context target")
    value(name, default) = haskey(table, name) ?
                           _toml_decode_value(table[name], "$context $name") : default
    updates = haskey(table, "updates") ?
              _updates_from_toml(table["updates"], context) : ()
    return Apply(
        name,
        model;
        on,
        inputs=value("inputs", NamedTuple()),
        calls=value("calls", NamedTuple()),
        environment=value("environment", nothing),
        every=value("every", nothing),
        environment_bindings=value("environment_bindings", NamedTuple()),
        environment_window=value("environment_window", nothing),
        output_routing=value("output_routing", NamedTuple()),
        updates,
    )
end

function _template_to_toml(template::PlantTemplate, registry, context)
    table = Dict{String,Any}(
        "id" => String(template.id),
        "initial_axis_category" => String(template.initial_axis_category),
        "axis_categories" => [
            Dict(
                "id" => String(category.id),
                "initial_physiological_age" => category.initial_physiological_age,
            ) for category in template.axis_categories
        ],
        "initialization" => _toml_encode_value(
            template.initialization,
            "$context initialization",
        ),
        "parameters" => _toml_encode_value(template.parameters, "$context parameters"),
        "applications" => [
            _application_to_toml(
                application,
                registry,
                "$context application $(repr(application.name))",
            ) for application in template.applications
        ],
    )
    template.species === nothing || (table["species"] = String(template.species))
    if template.initiation !== nothing
        table["initiation"] = _model_to_toml(
            registry,
            template.initiation,
            "$context initiation",
        )
    end
    return table
end

function _template_from_toml(table, registry, context)
    fields = (
        "id",
        "species",
        "initial_axis_category",
        "axis_categories",
        "initiation",
        "initialization",
        "parameters",
        "applications",
    )
    required = (
        "id",
        "initial_axis_category",
        "axis_categories",
        "initialization",
        "parameters",
        "applications",
    )
    _validate_toml_keys(table, fields, context; required)
    identifier = table["id"]
    identifier isa AbstractString || throw(ArgumentError("$context id must be a string"))
    species = get(table, "species", nothing)
    species === nothing || species isa AbstractString || throw(ArgumentError(
        "$context species must be a string",
    ))
    category_rows = table["axis_categories"]
    category_rows isa AbstractVector || throw(ArgumentError(
        "$context axis_categories must be an array",
    ))
    categories = Tuple(begin
        category_context = "$context axis category $position"
        _validate_toml_keys(
            row,
            ("id", "initial_physiological_age"),
            category_context,
        )
        AxisCategory(
            row["id"];
            initial_physiological_age=row["initial_physiological_age"],
        )
    end for (position, row) in pairs(category_rows))
    initiation = haskey(table, "initiation") ? _model_from_toml(
        registry,
        table["initiation"],
        AbstractAxisCategoryInitiationModel,
        "$context initiation",
    ) : nothing
    application_rows = table["applications"]
    application_rows isa AbstractVector || throw(ArgumentError(
        "$context applications must be an array",
    ))
    applications = Tuple(
        _application_from_toml(
            row,
            registry,
            "$context application $position",
        ) for (position, row) in pairs(application_rows)
    )
    initialization = _toml_decode_value(
        table["initialization"],
        "$context initialization",
    )
    parameters = _toml_decode_value(table["parameters"], "$context parameters")
    return PlantTemplate(
        identifier;
        axis_categories=categories,
        initial_axis_category=table["initial_axis_category"],
        initiation,
        applications,
        species,
        initialization,
        parameters,
    )
end

function _plant_to_toml(plant::PlantInstance, registry, context)
    isempty(plant.object_overrides) || throw(ArgumentError(
        "$context uses PlantSimEngine object_overrides, which are script-only " *
        "until their object selectors are registered",
    ))
    overrides = [
        begin
            table = Dict{String,Any}("name" => String(name))
            merge!(
                table,
                _model_to_toml(
                    registry,
                    model,
                    "$context override $(repr(name))",
                ),
            )
            table
        end for (name, model) in pairs(plant.overrides)
    ]
    return Dict(
        "id" => String(plant.id),
        "template" => String(plant.template.id),
        "seed" => _toml_encode_value(plant.seed, "$context seed"),
        "initialization" => _toml_encode_value(
            plant.initialization,
            "$context initialization",
        ),
        "overrides" => overrides,
    )
end

function _plant_from_toml(table, templates, registry, context)
    _validate_toml_keys(
        table,
        ("id", "template", "seed", "initialization", "overrides"),
        context;
        required=("id", "template", "initialization", "overrides"),
    )
    identifier = table["id"]
    template_identifier = table["template"]
    identifier isa AbstractString || throw(ArgumentError("$context id must be a string"))
    template_identifier isa AbstractString || throw(ArgumentError(
        "$context template must be a string",
    ))
    template = get(templates, Symbol(template_identifier), nothing)
    template === nothing && throw(ArgumentError(
        "$context references unknown template $(repr(template_identifier)); " *
        "available templates are $(Tuple(sort!(collect(keys(templates)); by=string)))",
    ))
    override_rows = table["overrides"]
    override_rows isa AbstractVector || throw(ArgumentError(
        "$context overrides must be an array",
    ))
    names = Symbol[]
    models = Any[]
    for (position, row) in pairs(override_rows)
        override_context = "$context override $position"
        _validate_toml_keys(row, ("name", "model", "parameters"), override_context)
        name = _application_name(row["name"])
        name in names && throw(ArgumentError(
            "$context contains duplicate override name $(repr(name))",
        ))
        push!(names, name)
        push!(
            models,
            _model_from_toml(
                registry,
                Dict("model" => row["model"], "parameters" => row["parameters"]),
                PlantSimEngine.AbstractModel,
                override_context,
            ),
        )
    end
    overrides = NamedTuple{Tuple(names)}(Tuple(models))
    seed = _toml_decode_value(get(table, "seed", 0), "$context seed")
    seed isa Integer && !(seed isa Bool) || throw(ArgumentError(
        "$context seed must be an integer",
    ))
    initialization = _toml_decode_value(
        table["initialization"],
        "$context initialization",
    )
    return PlantInstance(identifier, template; initialization, seed, overrides)
end

function _native_scene_document(scene::SceneDefinition, registry::ModelRegistry)
    isempty(scene.objects) || throw(ArgumentError(
        "native TOML export does not yet support unregistered scene objects",
    ))
    templates = Dict{Symbol,PlantTemplate}()
    for plant in scene.plants
        existing = get(templates, plant.template.id, nothing)
        existing === nothing || existing === plant.template || throw(ArgumentError(
            "template identifier $(repr(plant.template.id)) refers to several definitions",
        ))
        templates[plant.template.id] = plant.template
    end
    ordered_templates = sort!(collect(values(templates)); by=template -> string(template.id))
    scene_table = Dict{String,Any}(
        "applications" => [
            _application_to_toml(
                application,
                registry,
                "scene application $(repr(application.name))",
            ) for application in scene.applications
        ],
    )
    scene.environment === nothing || (scene_table["environment"] = _toml_encode_value(
        scene.environment,
        "scene environment",
    ))
    return Dict(
        "schema_version" => _NATIVE_SCENE_SCHEMA_VERSION,
        "format" => _NATIVE_SCENE_FORMAT,
        "scene" => scene_table,
        "templates" => [
            _template_to_toml(
                template,
                registry,
                "template $(repr(template.id))",
            ) for template in ordered_templates
        ],
        "plants" => [
            _plant_to_toml(plant, registry, "plant $(repr(plant.id))")
            for plant in scene.plants
        ],
    )
end

function _native_scene_from_document(document, registry::ModelRegistry, source)
    _validate_toml_keys(
        document,
        ("schema_version", "format", "scene", "templates", "plants"),
        "native scene document $source",
    )
    version = document["schema_version"]
    version isa Integer && !(version isa Bool) || throw(ArgumentError(
        "native scene schema_version must be an integer",
    ))
    version == _NATIVE_SCENE_SCHEMA_VERSION || throw(ArgumentError(
        "unsupported native scene schema_version $version; this AMAPSim version " *
        "supports schema $(_NATIVE_SCENE_SCHEMA_VERSION)",
    ))
    document["format"] == _NATIVE_SCENE_FORMAT || throw(ArgumentError(
        "native scene format must be $(repr(_NATIVE_SCENE_FORMAT))",
    ))
    template_rows = document["templates"]
    template_rows isa AbstractVector && !isempty(template_rows) || throw(ArgumentError(
        "native scene templates must be a non-empty array",
    ))
    templates = Dict{Symbol,PlantTemplate}()
    for (position, row) in pairs(template_rows)
        template = _template_from_toml(row, registry, "template $position")
        haskey(templates, template.id) && throw(ArgumentError(
            "native scene contains duplicate template identifier $(repr(template.id))",
        ))
        templates[template.id] = template
    end
    plant_rows = document["plants"]
    plant_rows isa AbstractVector && !isempty(plant_rows) || throw(ArgumentError(
        "native scene plants must be a non-empty array",
    ))
    plants = Tuple(
        _plant_from_toml(row, templates, registry, "plant $position")
        for (position, row) in pairs(plant_rows)
    )
    scene_table = document["scene"]
    _validate_toml_keys(
        scene_table,
        ("environment", "applications"),
        "native scene",
        required=("applications",),
    )
    application_rows = scene_table["applications"]
    application_rows isa AbstractVector || throw(ArgumentError(
        "native scene applications must be an array",
    ))
    applications = Tuple(
        _application_from_toml(row, registry, "scene application $position")
        for (position, row) in pairs(application_rows)
    )
    environment = haskey(scene_table, "environment") ? _toml_decode_value(
        scene_table["environment"],
        "native scene environment",
    ) : nothing
    return SceneDefinition(; plants, applications, environment)
end

"""
    write_native_scene(io, scene; registry=ModelRegistry())
    write_native_scene(path, scene; registry=ModelRegistry(), overwrite=false)

Write a schema-version-1 native scene as deterministic TOML. Every application,
initiation model, and override must be registry-backed. The path method uses
atomic publication and preserves an existing destination unless explicitly
overwritten.
"""
function write_native_scene(
    io::IO,
    scene::SceneDefinition;
    registry::ModelRegistry=ModelRegistry(),
)
    TOML.print(io, _native_scene_document(scene, registry); sorted=true)
    return io
end

function write_native_scene(
    path::AbstractString,
    scene::SceneDefinition;
    registry::ModelRegistry=ModelRegistry(),
    overwrite::Bool=false,
)
    destination = abspath(path)
    parent_directory = dirname(destination)
    isdir(parent_directory) || throw(ArgumentError(
        "native scene directory does not exist: $parent_directory",
    ))
    ispath(destination) && !overwrite && throw(ArgumentError(
        "native scene already exists: $destination",
    ))
    temporary_path, temporary_io = mktemp(parent_directory)
    published = false
    try
        write_native_scene(temporary_io, scene; registry)
        close(temporary_io)
        mv(temporary_path, destination; force=overwrite)
        published = true
    finally
        isopen(temporary_io) && close(temporary_io)
        !published && ispath(temporary_path) && rm(temporary_path; force=true)
    end
    return destination
end

"""
    read_native_scene(io; registry=ModelRegistry(), source="<io>")
    read_native_scene(path; registry=ModelRegistry())

Read and validate a schema-version-1 native scene without evaluating Julia
source. Model construction is restricted to constructors explicitly present in
`registry`.
"""
function read_native_scene(
    io::IO;
    registry::ModelRegistry=ModelRegistry(),
    source::AbstractString="<io>",
)
    document = TOML.parse(read(io, String))
    return _native_scene_from_document(document, registry, source)
end

function read_native_scene(
    path::AbstractString;
    registry::ModelRegistry=ModelRegistry(),
)
    destination = abspath(path)
    isfile(destination) || throw(ArgumentError(
        "native scene file does not exist: $destination",
    ))
    open(destination, "r") do io
        return read_native_scene(io; registry, source=destination)
    end
end
