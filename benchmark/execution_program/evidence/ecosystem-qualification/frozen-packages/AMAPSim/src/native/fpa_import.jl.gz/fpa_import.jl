const _MAX_IMPORTED_FPA_PHYSIOLOGICAL_AGE = 1024

function _fpa_maximum_absolute_parameter_value(parameter::ParameterSurface)
    maximum_value = 0.0
    for curve in parameter.curves, value in curve.values
        maximum_value = max(maximum_value, abs(Float64(value)))
    end
    return maximum_value
end

function _fpa_child_age_bound(parameters::AMAPSimParameters)
    maximum_reference_age = maximum(
        Float64.(parameters.axis.topology.maximum_axis_physiological_age.values);
        init=0.0,
    ) + 1
    maximum_jump = 0.0
    maximum_variation = 0.0
    jump_names = (
        :delayed_type_1_minimum_jump,
        :delayed_type_2_minimum_jump,
        :immediate_minimum_jump,
        :cycle_delayed_minimum_jump,
        :traumatic_minimum_jump,
    )
    variation_names = (
        :delayed_type_1_jump_variation_count,
        :delayed_type_2_jump_variation_count,
        :immediate_jump_variation_count,
        :cycle_delayed_jump_variation_count,
        :traumatic_jump_variation_count,
    )
    for lateral in parameters.lateral_productions, zone in lateral.zones
        branching = zone.branching
        for name in jump_names
            maximum_jump = max(
                maximum_jump,
                _fpa_maximum_absolute_parameter_value(getproperty(branching, name)),
            )
        end
        for name in variation_names
            maximum_variation = max(
                maximum_variation,
                _fpa_maximum_absolute_parameter_value(getproperty(branching, name)),
            )
        end
    end
    return max(maximum_reference_age, maximum_jump) + maximum_variation
end

function _fpa_maximum_physiological_age(parameters::AMAPSimParameters)
    candidates = Float64[parameters.initialization.initial_physiological_age]
    maximum_reference_age =
        parameters.axis.topology.maximum_axis_physiological_age
    append!(candidates, maximum_reference_age.positions .+ 1)
    append!(candidates, maximum_reference_age.values .+ 1)
    # Curve coordinates and surface outer coordinates are zero-based bearer
    # physiological ages. Branch-jump variation counts are validated as
    # nonnegative, hence sampled binomially and bounded by their parameters.
    for parameter in values(parameters.legacy.entries)
        if parameter isa ParameterCurve
            append!(candidates, parameter.positions .+ 1)
        elseif parameter isa ParameterSurface
            append!(candidates, parameter.physiological_ages .+ 1)
        end
    end
    push!(candidates, _fpa_child_age_bound(parameters))
    all(value -> isfinite(value) && value > 0, candidates) || throw(ArgumentError(
        "FPA physiological-age coordinates must be finite and positive after import",
    ))
    maximum_age = ceil(Int, maximum(candidates))
    maximum_age <= _MAX_IMPORTED_FPA_PHYSIOLOGICAL_AGE || throw(ArgumentError(
        "FPA import would require $maximum_age neutral axis categories; the " *
        "supported safety limit is $(_MAX_IMPORTED_FPA_PHYSIOLOGICAL_AGE)",
    ))
    return maximum_age
end

_neutral_fpa_category(age::Int) = AxisCategory(
    Symbol("fpa_pa_", age);
    initial_physiological_age=age,
)

function _mapped_fpa_categories(parameters, category_mapping)
    maximum_age = _fpa_maximum_physiological_age(parameters)
    ages = 1:maximum_age
    if category_mapping === nothing
        return Tuple(_neutral_fpa_category(age) for age in ages)
    end
    category_mapping isa AbstractDict || throw(ArgumentError(
        "FPA category_mapping must be a dictionary from physiological age to " *
        "AxisCategory",
    ))
    normalized = Dict{Int,AxisCategory}()
    for (age, category) in pairs(category_mapping)
        age isa Integer && !(age isa Bool) && age > 0 || throw(ArgumentError(
            "FPA category_mapping keys must be positive integers",
        ))
        category isa AxisCategory || throw(ArgumentError(
            "FPA category_mapping value for age $age must be an AxisCategory",
        ))
        normalized_age = Int(age)
        category.initial_physiological_age == normalized_age || throw(ArgumentError(
            "FPA category_mapping age $normalized_age conflicts with category " *
            "$(repr(category.id)) initial physiological age " *
            "$(category.initial_physiological_age)",
        ))
        normalized[normalized_age] = category
    end
    missing = collect(setdiff(Set(ages), Set(keys(normalized))))
    sort!(missing)
    isempty(missing) || throw(ArgumentError(
        "FPA category_mapping is missing physiological age(s) $(Tuple(missing))",
    ))
    extra = collect(setdiff(Set(keys(normalized)), Set(ages)))
    sort!(extra)
    isempty(extra) || throw(ArgumentError(
        "FPA category_mapping contains unused physiological age(s) $(Tuple(extra)); " *
        "the imported file requires ages 1:$maximum_age",
    ))
    return _validated_axis_categories(Tuple(normalized[age] for age in ages))
end

function _fpa_template_initialization(parameters, initialization)
    initialization isa NamedTuple || throw(ArgumentError(
        "FPA template initialization must be a named tuple",
    ))
    defaults = (
        internode_length=
            parameters.initialization.initial_truncated_internode_length,
        internode_width=
            parameters.initialization.initial_truncated_internode_diameter,
        runtime_scaffold=true,
    )
    return merge(defaults, initialization)
end

"""
    import_fpa(parameters; id, category_mapping=nothing, applications=(),
               species=nothing, initialization=NamedTuple(),
               warn_on_neutral_categories=true)
    import_fpa(path; id, kwargs...)
    import_fpa(io; id, source="<io>", kwargs...)

Import legacy version-2 FPA parameters into a native [`PlantTemplate`](@ref).
The source `AMAPSimParameters`, including its path, SHA-256 digest, raw records,
units, and line provenance, remains available as `template.parameters`.

FPA identifies axes numerically by physiological age; it does not contain
stable user-defined botanical category names. Without `category_mapping`, the
adapter therefore creates private-convention neutral categories named
`fpa_pa_1`, `fpa_pa_2`, and so on. A mapping must associate every imported
integer age with an [`AxisCategory`](@ref) having the same initial age.
Legacy `Order`, `Nature`, bearer rank, and branching mechanism remain explicit
per-axis runtime attributes; the adapter does not reinterpret them as
botanical category names.

The returned template contains an `ArchitectureDevelopment{Float64}`
application and is directly usable in a [`SceneDefinition`](@ref). This is a
one-way import boundary: it does not promise FPA round-trip compatibility.
"""
function import_fpa(
    parameters::AMAPSimParameters;
    id,
    category_mapping=nothing,
    applications=(),
    species=nothing,
    initialization=NamedTuple(),
    warn_on_neutral_categories::Bool=true,
)
    categories = _mapped_fpa_categories(parameters, category_mapping)
    initial_age = parameters.initialization.initial_physiological_age
    initial_category = only(
        category for category in categories
        if category.initial_physiological_age == initial_age
    )
    if category_mapping === nothing && warn_on_neutral_categories
        @warn "FPA has numeric physiological ages but no stable named axis " *
              "categories; the importer created neutral adapter categories" source =
            parameters.source.path sha256 = parameters.source.sha256 categories =
            Tuple(category.id for category in categories)
    end
    architecture = Apply(
        :architecture_development,
        ArchitectureDevelopment{Float64}();
        on=Plant(),
    )
    additional_applications = _validated_applications(applications)
    imported_applications = _validated_applications((
        architecture,
        additional_applications...,
    ))
    return PlantTemplate(
        id;
        axis_categories=categories,
        initial_axis_category=initial_category,
        initiation=PhysiologicalAgeInitiation(),
        applications=imported_applications,
        species,
        initialization=_fpa_template_initialization(parameters, initialization),
        parameters,
    )
end

function import_fpa(path::AbstractString; id, kwargs...)
    return import_fpa(read_parameters(path); id, kwargs...)
end

function import_fpa(io::IO; id, source::AbstractString="<io>", kwargs...)
    return import_fpa(read_parameters(io; source); id, kwargs...)
end
