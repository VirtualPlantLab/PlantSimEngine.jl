const _DEFAULT_PLANT_INITIALIZATION = (
    stage=0,
    position=(0.0, 0.0, 0.0),
    internode_length=0.0,
    internode_width=0.0,
    runtime_scaffold=false,
)

function _definition_identifier(value, context::AbstractString)
    value isa Union{Symbol,AbstractString} || throw(ArgumentError(
        "$context must be a symbol or string",
    ))
    identifier = Symbol(value)
    text = String(identifier)
    isempty(text) && throw(ArgumentError("$context must not be empty"))
    Base.isidentifier(text) || throw(ArgumentError(
        "$context $(repr(identifier)) must follow Julia identifier syntax",
    ))
    return identifier
end

function _initialization_named_tuple(initialization, context::AbstractString)
    initialization isa NamedTuple || throw(ArgumentError(
        "$context must be a named tuple",
    ))
    unsupported = setdiff(keys(initialization), keys(_DEFAULT_PLANT_INITIALIZATION))
    isempty(unsupported) || throw(ArgumentError(
        "$context contains unsupported key(s) $(Tuple(unsupported)); supported " *
        "keys are $(keys(_DEFAULT_PLANT_INITIALIZATION))",
    ))
    return initialization
end

function _validated_plant_initialization(
    initialization;
    base=_DEFAULT_PLANT_INITIALIZATION,
    context="plant initialization",
)
    overrides = _initialization_named_tuple(initialization, context)
    values = merge(base, overrides)

    values.stage isa Integer && !(values.stage isa Bool) || throw(ArgumentError(
        "$context stage must be an integer",
    ))
    stage = _validate_topology_count(values.stage, "$context stage"; allow_zero=true)
    position = _validate_position(values.position)
    values.internode_length isa Real && !(values.internode_length isa Bool) ||
        throw(ArgumentError("$context internode_length must be real"))
    values.internode_width isa Real && !(values.internode_width isa Bool) ||
        throw(ArgumentError("$context internode_width must be real"))
    internode_length = _validate_topology_measure(
        values.internode_length,
        "$context internode length",
    )
    internode_width = _validate_topology_measure(
        values.internode_width,
        "$context internode width",
    )
    values.runtime_scaffold isa Bool || throw(ArgumentError(
        "$context runtime_scaffold must be a boolean",
    ))

    return (;
        stage,
        position,
        internode_length,
        internode_width,
        runtime_scaffold=values.runtime_scaffold,
    )
end

function _category_identifier_from_selector(selector)
    selector isa Axes && return selector.category
    selector isa ApicalMeristems && return selector.bearer.category
    selector isa GrowthUnits && return selector.axis.category
    selector isa Leaves && return selector.axis.category
    return nothing
end

function _validate_application_categories(applications, categories, context)
    identifiers = Set(category.id for category in categories)
    for application in applications
        identifier = _category_identifier_from_selector(application.on)
        identifier === nothing && continue
        identifier in identifiers || throw(ArgumentError(
            "application $(repr(application.name)) in $context selects unknown " *
            "axis category $(repr(identifier)); available categories are " *
            "$(Tuple(sort!(collect(identifiers); by=string)))",
        ))
    end
    return applications
end

"""
    PlantTemplate(id; axis_categories, initial_axis_category,
                  initiation=nothing,
                  applications=(), species=nothing,
                  initialization=NamedTuple(), parameters=NamedTuple())

Define one reusable native plant model. Axis-category identifiers and
application names are local to the template. `initial_axis_category` is
assigned once to the seed axis and determines its immutable initial
physiological age.

The template contains declarations, not plant state. [`compile_scene`](@ref)
creates fresh topology and status objects for every [`PlantInstance`](@ref),
while PlantSimEngine may safely share the template's model values.
"""
struct PlantTemplate{C,M,A,I,P}
    id::Symbol
    axis_categories::C
    initial_axis_category::Symbol
    initiation::M
    applications::A
    species::Union{Nothing,Symbol}
    initialization::I
    parameters::P
end

function PlantTemplate(
    id;
    axis_categories,
    initial_axis_category=nothing,
    initiation=nothing,
    applications=(),
    species=nothing,
    initialization=NamedTuple(),
    parameters=NamedTuple(),
)
    identifier = _definition_identifier(id, "plant template identifier")
    categories = _validated_axis_categories(axis_categories)
    category_ids = Set(category.id for category in categories)
    initial_identifier = if initial_axis_category === nothing
        first(categories).id
    else
        _selector_category_identifier(initial_axis_category)
    end
    initial_identifier in category_ids || throw(ArgumentError(
        "plant template $(repr(identifier)) initial axis category " *
        "$(repr(initial_identifier)) is not defined; available categories are " *
        "$(Tuple(sort!(collect(category_ids); by=string)))",
    ))
    initiation isa Union{Nothing,AbstractAxisCategoryInitiationModel} ||
        throw(ArgumentError(
            "plant template $(repr(identifier)) initiation must be an " *
            "AbstractAxisCategoryInitiationModel or nothing",
        ))
    declared_applications = _validated_applications(applications)
    _validate_application_categories(
        declared_applications,
        categories,
        "plant template $(repr(identifier))",
    )
    normalized_species = species === nothing ? nothing :
                         _definition_identifier(species, "plant species identifier")
    normalized_initialization = _validated_plant_initialization(
        initialization;
        context="plant template $(repr(identifier)) initialization",
    )
    return PlantTemplate(
        identifier,
        categories,
        initial_identifier,
        initiation,
        declared_applications,
        normalized_species,
        normalized_initialization,
        parameters,
    )
end

function _template_category(template::PlantTemplate, identifier::Symbol)
    category = findfirst(category -> category.id == identifier, template.axis_categories)
    category === nothing && throw(ArgumentError(
        "plant template $(repr(template.id)) has no axis category $(repr(identifier))",
    ))
    return template.axis_categories[category]
end

"""
    compile_plant_template(template) -> PlantSimEngine.CompositeModelTemplate

Lower a native template to PlantSimEngine. The returned template keeps the
botanical initialization metadata in `parameters.amapsim`, while its
applications are ordinary `ModelSpec` values.
"""
function compile_plant_template(template::PlantTemplate)
    metadata = (
        template_id=template.id,
        axis_categories=template.axis_categories,
        initial_axis_category=template.initial_axis_category,
        initiation=template.initiation,
        initialization=template.initialization,
        user_parameters=template.parameters,
    )
    return PlantSimEngine.CompositeModelTemplate(
        _lower_applications(template.applications);
        kind=template.id,
        species=template.species,
        parameters=(amapsim=metadata,),
    )
end

"""
    PlantInstance(id, template; initialization=NamedTuple(), position=nothing, seed=0,
                  overrides=NamedTuple(), object_overrides=())

Declare one plant occurrence. Initialization values are merged with the
template defaults. `overrides` maps a stable application name to a compatible
replacement PlantSimEngine model and affects only this instance.

`seed` identifies the plant-local deterministic stochastic stream. Reusing a
template never shares random state between instances.
"""
struct PlantInstance{T,I,O,OO}
    id::Symbol
    template::T
    initialization::I
    seed::UInt64
    overrides::O
    object_overrides::OO
end

function PlantInstance(
    id,
    template::PlantTemplate;
    initialization=NamedTuple(),
    position=nothing,
    seed=0,
    overrides=NamedTuple(),
    object_overrides=(),
)
    identifier = _definition_identifier(id, "plant instance identifier")
    instance_initialization = _initialization_named_tuple(
        initialization,
        "plant instance $(repr(identifier)) initialization",
    )
    if position !== nothing
        haskey(instance_initialization, :position) && throw(ArgumentError(
            "plant instance $(repr(identifier)) supplies position both directly " *
            "and in initialization",
        ))
        instance_initialization = merge(instance_initialization, (; position))
    end
    normalized_initialization = _validated_plant_initialization(
        instance_initialization;
        base=template.initialization,
        context="plant instance $(repr(identifier)) initialization",
    )
    seed isa Integer && !(seed isa Bool) || throw(ArgumentError(
        "plant instance $(repr(identifier)) seed must be an integer",
    ))
    0 <= seed <= typemax(UInt64) || throw(DomainError(
        seed,
        "plant instance $(repr(identifier)) seed must be between zero and " *
        "typemax(UInt64)",
    ))
    overrides isa NamedTuple || throw(ArgumentError(
        "plant instance $(repr(identifier)) overrides must be a named tuple " *
        "keyed by application name",
    ))
    for (name, model) in pairs(overrides)
        _definition_identifier(name, "plant instance override name")
        model isa PlantSimEngine.AbstractModel || throw(ArgumentError(
            "override $(repr(name)) for plant instance $(repr(identifier)) must " *
            "be a PlantSimEngine AbstractModel, got $(typeof(model))",
        ))
    end
    normalized_object_overrides = object_overrides isa Tuple ?
                                  object_overrides :
                                  object_overrides isa AbstractVector ?
                                  Tuple(object_overrides) : (object_overrides,)
    all(override -> override isa PlantSimEngine.Override, normalized_object_overrides) ||
        throw(ArgumentError(
            "plant instance $(repr(identifier)) object_overrides must contain " *
            "PlantSimEngine Override values",
        ))
    return PlantInstance(
        identifier,
        template,
        normalized_initialization,
        UInt64(seed),
        overrides,
        normalized_object_overrides,
    )
end

"""
    SceneDefinition(; plants, objects=(), applications=(), environment=nothing)

Declare a heterogeneous scene. Several instances may share one
[`PlantTemplate`](@ref), and instances of unrelated templates may coexist.
Optional ordinary PlantSimEngine objects and global native applications use
the same runtime model.
"""
struct SceneDefinition{P,O,A,E}
    plants::P
    objects::O
    applications::A
    environment::E
end

function SceneDefinition(;
    plants,
    objects=(),
    applications=(),
    environment=nothing,
)
    normalized_plants = plants isa PlantInstance ?
                        (plants,) :
                        plants isa Tuple ? plants : Tuple(plants)
    isempty(normalized_plants) && throw(ArgumentError(
        "a native scene must contain at least one PlantInstance",
    ))
    all(plant -> plant isa PlantInstance, normalized_plants) || throw(ArgumentError(
        "native scene plants must contain only PlantInstance values",
    ))
    seen = Dict{Symbol,Int}()
    for (position, plant) in pairs(normalized_plants)
        previous = get(seen, plant.id, nothing)
        previous === nothing || throw(ArgumentError(
            "duplicate plant instance identifier $(repr(plant.id)) at positions " *
            "$previous and $position",
        ))
        seen[plant.id] = position
    end
    normalized_objects = objects isa PlantSimEngine.Object ?
                         (objects,) :
                         objects isa Tuple ? objects : Tuple(objects)
    all(object -> object isa PlantSimEngine.Object, normalized_objects) ||
        throw(ArgumentError(
            "native scene objects must contain only PlantSimEngine Object values",
        ))
    normalized_applications = _validated_applications(applications)
    return SceneDefinition(
        normalized_plants,
        normalized_objects,
        normalized_applications,
        environment,
    )
end

function _owning_axis_category_identifier(node)
    current = node
    while current !== nothing
        if symbol(current) == AMAPSIM_MTG_SYMBOLS.axis
            return _axis_category_identifier(current)
        end
        current = parent(current)
    end
    return nothing
end

function _native_compilation_kind(node)
    symbol(node) == AMAPSIM_MTG_SYMBOLS.scene && return :scene
    symbol(node) == AMAPSIM_MTG_SYMBOLS.plant && return nothing
    return _owning_axis_category_identifier(node)
end

function _native_initial_status(node)
    _reject_mtg_runtime_status(node, "native scene status initialization")
    data = Dict{Symbol,Any}()
    for (name, value) in pairs(MultiScaleTreeGraph.node_attributes(node))
        data[Symbol(name)] = value
    end
    data[:node] = node
    return PlantSimEngine.Status((; data...))
end

function _native_amapsim_parameters(plant::PlantInstance)
    return plant.template.parameters isa AMAPSimParameters ?
           plant.template.parameters : nothing
end

function _native_scene_initial_status(node, plants)
    plant_node = if symbol(node) == AMAPSIM_MTG_SYMBOLS.plant
        node
    else
        current = parent(node)
        while current !== nothing &&
              symbol(current) != AMAPSIM_MTG_SYMBOLS.plant
            current = parent(current)
        end
        current
    end
    plant_node === nothing && return _native_initial_status(node)
    plant = plants[index(plant_node)]
    return _initial_model_status(
        node,
        Float64,
        0.0,
        _native_amapsim_parameters(plant),
        plant.seed,
        plant.template.axis_categories,
        plant.template.initiation,
    )
end

function _compiled_scene_templates(plants)
    definitions = Dict{Symbol,PlantTemplate}()
    compiled = Dict{Symbol,PlantSimEngine.CompositeModelTemplate}()
    for plant in plants
        identifier = plant.template.id
        existing = get(definitions, identifier, nothing)
        if existing !== nothing && existing !== plant.template
            throw(ArgumentError(
                "plant template identifier $(repr(identifier)) refers to more " *
                "than one definition in the scene; reuse the same PlantTemplate " *
                "value or choose distinct identifiers",
            ))
        end
        if existing === nothing
            definitions[identifier] = plant.template
            compiled[identifier] = compile_plant_template(plant.template)
        end
    end
    return compiled
end

"""
    compile_scene(scene) -> PlantSimEngine.CompositeModel

Compile a native heterogeneous scene into the PlantSimEngine runtime. Each
call builds fresh MTG topology and mutable status for every plant instance.
Template model values are shared according to PlantSimEngine's immutable
application-graph contract; instance overrides remain local.
"""
function compile_scene(scene::SceneDefinition)
    root = _new_amapsim_scene()
    compiled_templates = _compiled_scene_templates(scene.plants)
    runtime_instances = PlantSimEngine.ObjectInstance[]

    for (plant_index, plant) in pairs(scene.plants)
        category = _template_category(
            plant.template,
            plant.template.initial_axis_category,
        )
        topology = add_initial_plant!(
            root;
            plant_index,
            axis_category=category,
            plant.initialization...,
        )
        _validate_parameterized_plant_seed(
            topology.plant,
            _native_amapsim_parameters(plant);
            context="native compile_scene instance $(repr(plant.id))",
        )
        topology.plant[:NativePlantInstance] = plant.id
        topology.plant[:NativePlantTemplate] = plant.template.id
        _validate_physiological_age_state(
            topology.plant;
            categories=plant.template.axis_categories,
            allow_legacy=false,
        )
        push!(
            runtime_instances,
            PlantSimEngine.ObjectInstance(
                plant.id,
                compiled_templates[plant.template.id];
                root=node_id(topology.plant),
                overrides=plant.overrides,
                object_overrides=plant.object_overrides,
            ),
        )
    end

    model = PlantSimEngine.CompositeModel(
        root;
        instances=Tuple(runtime_instances),
        applications=_lower_applications(scene.applications),
        environment=scene.environment,
        kind=_native_compilation_kind,
        status=node -> _native_scene_initial_status(node, scene.plants),
    )
    for object in scene.objects
        PlantSimEngine.register_object!(model, object)
    end
    return model
end
