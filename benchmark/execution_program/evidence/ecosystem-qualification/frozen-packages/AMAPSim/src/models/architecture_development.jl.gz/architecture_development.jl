"""Abstract process family for AMAPSim architecture development models."""
abstract type AbstractArchitectureDevelopmentModel <: PlantSimEngine.AbstractModel end

PlantSimEngine.process_(::Type{<:AbstractArchitectureDevelopmentModel}) =
    :architecture_development

"""
    ArchitectureDevelopment{T}(; development_increment_contract=nothing, allocation_enabled=false)

PlantSimEngine model that advances each plant's private AMAPSim event queue by
the required `development_increment`. `T` is an internal real-valued scheduling
type for the legacy virtual developmental coordinate, not a physical-time unit.
`build_model` can additionally configure hard calls before apical creation.
An explicit increment contract is opt-in so existing uncontracted drivers keep
their interface.
"""
struct ArchitectureDevelopment{T<:Real,C<:Tuple,K,A} <: AbstractArchitectureDevelopmentModel
    before_growth_call_names::C
    development_increment_contract::K
end

function ArchitectureDevelopment{T}(
    before_growth_call_names::Tuple=();
    development_increment_contract=nothing,
    allocation_enabled::Bool=false,
) where {T<:Real}
    all(name -> name isa Symbol, before_growth_call_names) || throw(ArgumentError(
        "before-growth call names must be symbols",
    ))
    length(unique(before_growth_call_names)) == length(before_growth_call_names) ||
        throw(ArgumentError("before-growth call names must be unique"))
    development_increment_contract isa Union{Nothing,PlantSimEngine.VariableContract} ||
        throw(ArgumentError("development_increment_contract must be a VariableContract or nothing"))
    return ArchitectureDevelopment{T,typeof(before_growth_call_names),typeof(development_increment_contract),allocation_enabled}(
        before_growth_call_names,
        development_increment_contract,
    )
end

"""
    ArchitectureCoordinator{T}()
    ArchitectureCoordinator{T}(after_event_call_names)

Scene-level architecture model that merges due events from private per-plant
queues into one deterministic chronological order. Optional PlantSimEngine
hard calls run after each processed event and before the next event is
selected, so coupled models can inspect the updated scene without hiding a
callback in AMAPSim. Use this path when models can observe or modify more than
one plant during an outer step.
"""
struct ArchitectureCoordinator{T<:Real,C<:Tuple} <: AbstractArchitectureDevelopmentModel
    after_event_call_names::C
end

ArchitectureCoordinator{T}() where {T<:Real} = ArchitectureCoordinator{T}(())

function ArchitectureCoordinator{T}(after_event_call_names::Tuple) where {T<:Real}
    all(name -> name isa Symbol, after_event_call_names) || throw(ArgumentError(
        "after-event call names must be symbols",
    ))
    length(unique(after_event_call_names)) == length(after_event_call_names) ||
        throw(ArgumentError("after-event call names must be unique"))
    return ArchitectureCoordinator{T,typeof(after_event_call_names)}(
        after_event_call_names,
    )
end

@enum LegacyBranchingSiteState::UInt8 begin
    BranchingSiteUnbranched = 0
    BranchingSiteImmediate = 1
    BranchingSiteDelayedType1 = 2
    BranchingSiteDelayedType2 = 3
    BranchingSiteTraumatic = 4
    BranchingSiteCycleDelayed = 6
    BranchingSiteImmediateUnbranched = 8
    BranchingSiteCycleDelayedUnbranched = 9
    BranchingSiteTraumaticUnbranched = 10
    BranchingSiteUndefined = 255
end

"""
Mutable, per-bud state for the first unbranched apical-growth slice.

Node identifiers are stable MTG identifiers. A zero identifier means that the
next event must create that hierarchy level. The scheduling type `T` remains
generic so the legacy virtual developmental coordinate is not tied to
`Float64`.
"""
mutable struct ApicalBudState{T<:Real}
    bud_id::UInt64
    vigor::VigorState
    rhythm::Float64
    previous_polycyclic::Union{Nothing,Bool}
    growth_unit_index::Int
    maximum_growth_unit_count::Int
    maximum_reference_age::Float64
    ended::Bool
    initial_dormancy::Union{Nothing,InitialDormancy}
    dormancy_growth_unit_delay_remaining::Int
    dormancy_test_delay_remaining::Int
    dormancy_test_index_within_growth_unit::Int
    dormancy_incremental_test_delay::Bool
    dormancy_complete::Bool
    pruning_reference_age::Union{Nothing,Float64}
    growth_unit_test_count::Int
    time_per_test::T
    planned_cycle_count::Int
    cycle_index::Int
    test_index_within_growth_unit::Int
    test_index_within_cycle::Int
    test_count_on_axis::Int
    internode_count_within_growth_unit::Int
    internode_count_within_cycle::Int
    internode_count_on_axis::Int
    phytomer_count_within_zone::Int
    immediate_branching_order::Int
    legacy_branching_states::Vector{LegacyBranchingSiteState}
    immediate_markov_states::Vector{Union{Nothing,Bool}}
    immediate_markov_initial_probabilities::Vector{Union{Nothing,Float64}}
    immediate_markov_previous_positions::Vector{Union{Nothing,Float64}}
    immediate_markov_previous_zone_indices::Vector{Union{Nothing,Int}}
    immediate_semimarkov_states::Vector{ImmediateSemiMarkovState}
    delayed_markov_states::Vector{Union{Nothing,DelayedBranchState}}
    neoformed_zone_started::Bool
    neoformed_test_count::Int
    growth_unit_node_id::UInt64
    cycle_node_id::UInt64
    zone_node_id::UInt64
    cycle::Union{Nothing,CycleInitialization}
    organ_symbol::Symbol
end

# Stage private state without the generic deepcopy traversal. All nested state
# records are immutable values; only the seven vector fields need new storage.
# Preserve a legal alias between the two Float64 history vectors, and retain
# full deepcopy semantics for generic clocks that may contain mutable data.
function _copy_apical_bud_state(state::ApicalBudState{T}) where {T<:Real}
    isbitstype(T) || return deepcopy(state)
    initial_probabilities = copy(state.immediate_markov_initial_probabilities)
    previous_positions = state.immediate_markov_previous_positions ===
                         state.immediate_markov_initial_probabilities ?
                         initial_probabilities : copy(state.immediate_markov_previous_positions)
    return ApicalBudState{T}(
        state.bud_id,
        state.vigor,
        state.rhythm,
        state.previous_polycyclic,
        state.growth_unit_index,
        state.maximum_growth_unit_count,
        state.maximum_reference_age,
        state.ended,
        state.initial_dormancy,
        state.dormancy_growth_unit_delay_remaining,
        state.dormancy_test_delay_remaining,
        state.dormancy_test_index_within_growth_unit,
        state.dormancy_incremental_test_delay,
        state.dormancy_complete,
        state.pruning_reference_age,
        state.growth_unit_test_count,
        state.time_per_test,
        state.planned_cycle_count,
        state.cycle_index,
        state.test_index_within_growth_unit,
        state.test_index_within_cycle,
        state.test_count_on_axis,
        state.internode_count_within_growth_unit,
        state.internode_count_within_cycle,
        state.internode_count_on_axis,
        state.phytomer_count_within_zone,
        state.immediate_branching_order,
        copy(state.legacy_branching_states),
        copy(state.immediate_markov_states),
        initial_probabilities,
        previous_positions,
        copy(state.immediate_markov_previous_zone_indices),
        copy(state.immediate_semimarkov_states),
        copy(state.delayed_markov_states),
        state.neoformed_zone_started,
        state.neoformed_test_count,
        state.growth_unit_node_id,
        state.cycle_node_id,
        state.zone_node_id,
        state.cycle,
        state.organ_symbol,
    )
end

function _legacy_states_from_immediate_observer(states)
    return LegacyBranchingSiteState[
        isnothing(value) ?
        BranchingSiteUndefined :
        value ? BranchingSiteImmediate : BranchingSiteImmediateUnbranched for
        value in states
    ]
end

function _upgraded_legacy_apical_bud_state_args(args::Tuple)
    length(args) == 36 || throw(ArgumentError(
        "legacy ApicalBudState layout must contain exactly 36 fields",
    ))
    immediate_markov_states = args[27]
    immediate_markov_initial_probabilities = args[28]
    lateral_count = length(immediate_markov_states)
    return (
        args[1:26]...,
        0,
        _legacy_states_from_immediate_observer(immediate_markov_states),
        immediate_markov_states,
        immediate_markov_initial_probabilities,
        Union{Nothing,Float64}[nothing for _ in 1:lateral_count],
        Union{Nothing,Int}[nothing for _ in 1:lateral_count],
        args[29:36]...,
    )
end

function ApicalBudState{T}(args::Vararg{Any,36}) where {T<:Real}
    upgraded = _upgraded_legacy_apical_bud_state_args(args)
    return ApicalBudState{T}(upgraded...)
end

function ApicalBudState{T}(args::Vararg{Any,37}) where {T<:Real}
    upgraded = _upgraded_legacy_apical_bud_state_args(args[1:36])
    return ApicalBudState{T}(upgraded..., args[37])
end

function _upgraded_pre_legacy_state_apical_bud_args(args::Tuple)
    length(args) in (39, 40) || throw(ArgumentError(
        "pre-ledger ApicalBudState layout must contain 39 or 40 fields",
    ))
    lateral_count = length(args[28])
    return (
        args[1:27]...,
        _legacy_states_from_immediate_observer(args[28]),
        args[28:end]...,
    )
end

function ApicalBudState{T}(args::Vararg{Any,39}) where {T<:Real}
    upgraded = _upgraded_pre_legacy_state_apical_bud_args(args)
    return ApicalBudState{T}(upgraded..., :Internode)
end

function ApicalBudState{T}(args::Vararg{Any,40}) where {T<:Real}
    args[end] isa Symbol || return ApicalBudState{T}(args..., :Internode)
    upgraded = _upgraded_pre_legacy_state_apical_bud_args(args)
    return ApicalBudState{T}(upgraded...)
end

ApicalBudState(args::Vararg{Any,36}) =
    ApicalBudState{typeof(args[17])}(args...)

ApicalBudState(args::Vararg{Any,37}) =
    ApicalBudState{typeof(args[17])}(args...)

ApicalBudState(args::Vararg{Any,39}) =
    ApicalBudState{typeof(args[17])}(args...)

ApicalBudState(args::Vararg{Any,40}) =
    ApicalBudState{typeof(args[17])}(args...)

function ApicalBudState(
    bud_id::UInt64,
    vigor::VigorState,
    rhythm::Float64,
    previous_polycyclic::Union{Nothing,Bool},
    growth_unit_index::Int,
    maximum_growth_unit_count::Int,
    maximum_reference_age::Float64,
    ended::Bool,
    initial_dormancy::Union{Nothing,InitialDormancy},
    dormancy_growth_unit_delay_remaining::Int,
    dormancy_test_delay_remaining::Int,
    dormancy_test_index_within_growth_unit::Int,
    dormancy_incremental_test_delay::Bool,
    dormancy_complete::Bool,
    pruning_reference_age::Union{Nothing,Float64},
    growth_unit_test_count::Int,
    time_per_test::T,
    planned_cycle_count::Int,
    cycle_index::Int,
    test_index_within_growth_unit::Int,
    test_index_within_cycle::Int,
    test_count_on_axis::Int,
    internode_count_within_growth_unit::Int,
    internode_count_within_cycle::Int,
    internode_count_on_axis::Int,
    phytomer_count_within_zone::Int,
    immediate_branching_order::Int,
    immediate_markov_states::Vector{Union{Nothing,Bool}},
    immediate_markov_initial_probabilities::Vector{Union{Nothing,Float64}},
    immediate_markov_previous_positions::Vector{Union{Nothing,Float64}},
    immediate_markov_previous_zone_indices::Vector{Union{Nothing,Int}},
    immediate_semimarkov_states::Vector{ImmediateSemiMarkovState},
    delayed_markov_states::Vector{Union{Nothing,DelayedBranchState}},
    neoformed_zone_started::Bool,
    neoformed_test_count::Int,
    growth_unit_node_id::UInt64,
    cycle_node_id::UInt64,
    zone_node_id::UInt64,
    cycle::Union{Nothing,CycleInitialization},
) where {T<:Real}
    return ApicalBudState{T}(
        bud_id,
        vigor,
        rhythm,
        previous_polycyclic,
        growth_unit_index,
        maximum_growth_unit_count,
        maximum_reference_age,
        ended,
        initial_dormancy,
        dormancy_growth_unit_delay_remaining,
        dormancy_test_delay_remaining,
        dormancy_test_index_within_growth_unit,
        dormancy_incremental_test_delay,
        dormancy_complete,
        pruning_reference_age,
        growth_unit_test_count,
        time_per_test,
        planned_cycle_count,
        cycle_index,
        test_index_within_growth_unit,
        test_index_within_cycle,
        test_count_on_axis,
        internode_count_within_growth_unit,
        internode_count_within_cycle,
        internode_count_on_axis,
        phytomer_count_within_zone,
        immediate_branching_order,
        _legacy_states_from_immediate_observer(immediate_markov_states),
        immediate_markov_states,
        immediate_markov_initial_probabilities,
        immediate_markov_previous_positions,
        immediate_markov_previous_zone_indices,
        immediate_semimarkov_states,
        delayed_markov_states,
        neoformed_zone_started,
        neoformed_test_count,
        growth_unit_node_id,
        cycle_node_id,
        zone_node_id,
        cycle,
    )
end

PlantSimEngine.inputs_(::ArchitectureDevelopment{T}) where {T<:Real} = (
    development_increment=PlantSimEngine.Required(T),
    event_queue=PlantSimEngine.Required(BudEventQueue{T}),
)

function PlantSimEngine.outputs_(model::ArchitectureDevelopment{T}) where {T<:Real}
    legacy = (development_time=zero(T), processed_events=0, last_event_id=UInt64(0))
    isempty(model.before_growth_call_names) && !_growth_allocation_enabled(model) && return legacy
    intents = merge(legacy, (growth_intents=GrowthIntent{T}[],))
    _growth_allocation_enabled(model) || return intents
    return merge(intents, (
        realized_growth_intents=GrowthIntent{T}[],
        pending_growth_plans=Dict{EventID,Any}(),
        deferred_growth_count=0,
        growth_commit_in_progress=false,
    ))
end

function PlantSimEngine.variable_contracts_(model::ArchitectureDevelopment)
    contract = model.development_increment_contract
    increment = isnothing(contract) ? NamedTuple() : (development_increment=contract,)
    isempty(model.before_growth_call_names) && !_growth_allocation_enabled(model) && return increment
    intents = merge(increment, (growth_intents=GROWTH_INTENT_CONTRACT,))
    _growth_allocation_enabled(model) || return intents
    return merge(intents, (realized_growth_intents=GROWTH_INTENT_CONTRACT,))
end

_growth_allocation_enabled(::AbstractArchitectureDevelopmentModel) = false
_growth_allocation_enabled(::ArchitectureDevelopment{T,C,K,A}) where {T,C,K,A} = A

_growth_intent(event, state, batch, context) = GrowthIntent(
    PlantSimEngine.object_id(context), event.bud_id, event.id,
    batch.axis_internode_index, state.organ_symbol, 1, event.time,
)

# The current kernel creates one real product per event. The allocation target
# must return exactly its key; stale or ambiguous decisions cannot authorize it.
function _growth_allocation_accepted(targets, intent)
    length(targets) == 1 || throw(ArgumentError("growth allocation requires exactly one target"))
    target_status = only(targets).status
    hasproperty(target_status, :organ_allocation_decisions) || throw(ArgumentError(
        "growth allocation must expose organ_allocation_decisions",
    ))
    decisions = target_status.organ_allocation_decisions
    decisions isa AbstractVector && length(decisions) == 1 || throw(ArgumentError(
        "growth allocation must return exactly one decision for the intended organ",
    ))
    decision = only(decisions)
    all(name -> hasproperty(decision, name), (:intent_key, :realized, :allocated_gC)) ||
        throw(ArgumentError("an allocation decision needs intent_key, realized and allocated_gC"))
    decision.intent_key == growth_intent_key(intent) || throw(ArgumentError(
        "growth allocation decision has a stale or unknown organ identity",
    ))
    decision.realized isa Bool || throw(ArgumentError("realized must be boolean"))
    amount = decision.allocated_gC
    amount isa Real && !(amount isa Bool) && isfinite(amount) && amount >= 0 ||
        throw(ArgumentError("allocated_gC must be finite and nonnegative"))
    !decision.realized && !iszero(amount) && throw(ArgumentError(
        "a deferred organ cannot spend carbon",
    ))
    return decision.realized
end

_notify_growth_intent!(::AbstractArchitectureDevelopmentModel, status, event, state, batch, context) =
    true

function _notify_growth_intent!(model::ArchitectureDevelopment, status, event, state, batch, context)
    isempty(model.before_growth_call_names) && !_growth_allocation_enabled(model) && return true
    batch.main_outcome === RealizedDevelopmentSite || return true
    pending = status.growth_intents
    isempty(pending) || throw(ArgumentError("a growth intention is already being observed"))
    intent = _growth_intent(event, state, batch, context)
    push!(pending, intent)
    try
        for name in model.before_growth_call_names
            PlantSimEngine.run_call!(context, name; publish=false)
        end
        _growth_allocation_enabled(model) || return true
        targets = PlantSimEngine.run_call!(context, :growth_allocation; publish=false)
        return _growth_allocation_accepted(targets, intent)
    finally
        empty!(pending)
    end
end

function _settle_growth_allocation!(model, status, event, state, batch, context)
    _growth_allocation_enabled(model) || return nothing
    batch.main_outcome === RealizedDevelopmentSite || return nothing
    realized = status.realized_growth_intents
    isempty(realized) || throw(ArgumentError("a growth settlement is already in progress"))
    push!(realized, _growth_intent(event, state, batch, context))
    try
        PlantSimEngine.run_call!(context, :growth_allocation; publish=false)
    finally
        empty!(realized)
    end
    return nothing
end

PlantSimEngine.inputs_(::ArchitectureCoordinator{T}) where {T<:Real} = (
    development_increments=PlantSimEngine.Required(AbstractVector{T}),
)

PlantSimEngine.outputs_(::ArchitectureCoordinator) = (
    coordinated_events=0,
    coordination_trace=NamedTuple[],
    after_event_call_count=0,
)

function _validate_development_increment(increment::Real)
    isfinite(increment) || throw(ArgumentError("development increment must be finite"))
    increment >= 0 ||
        throw(DomainError(increment, "development increment cannot be negative"))
    return increment
end

function _process_architecture_event!(
    model::AbstractArchitectureDevelopmentModel,
    event::BudEvent,
    status,
    context,
    environment=nothing,
)
    event.process == :noop && return nothing
    event.process in (:initial_dormancy, :apical_growth) &&
        return _process_apical_growth_event!(
            model,
            event,
            status,
            context,
            environment,
        )
    event.process in (:progressive_pruning, :total_pruning) &&
        return _process_pruning_event!(model, event, status, context)
    throw(ArgumentError(
        "event process :$(event.process) is not implemented by ArchitectureDevelopment",
    ))
end

function _checked_node_id(id::UInt64)
    id <= typemax(Int) || throw(ArgumentError("MTG node ID does not fit in Int"))
    return Int(id)
end

function _registered_node(context, id::UInt64)
    model = PlantSimEngine.runtime_model(context)
    return try
        PlantSimEngine.source_node(model, _checked_node_id(id))
    catch error
        error isa ErrorException || rethrow()
        return nothing
    end
end

function _event_node(event::BudEvent, context)
    node = _registered_node(context, event.bud_id)
    isnothing(node) && throw(ArgumentError("event bud $(event.bud_id) is absent from the MTG"))
    symbol(node) == AMAPSIM_MTG_SYMBOLS.bud || throw(ArgumentError(
        "event target $(event.bud_id) is :$(symbol(node)), not :Bud",
    ))
    return node
end

function _ancestor_with_symbol(node, target::Symbol)
    current = node
    while !isnothing(current)
        symbol(current) == target && return current
        current = parent(current)
    end
    throw(ArgumentError("node $(node_id(node)) has no :$target ancestor"))
end

function _next_child_index(node, target::Symbol)
    indices = Int[
        index(child) for child in MultiScaleTreeGraph.children(node)
        if symbol(child) == target
    ]
    return isempty(indices) ? 1 : Base.Checked.checked_add(maximum(indices), 1)
end

function _convert_positive_interval(::Type{T}, interval::Real) where {T<:Real}
    isfinite(interval) || throw(ArgumentError("event interval must be finite"))
    interval > 0 || throw(DomainError(interval, "event interval must be positive"))
    converted = try
        convert(T, interval)
    catch error
        detail = sprint(showerror, error)
        throw(ArgumentError("event interval cannot be represented as $T: $detail"))
    end
    converted > zero(T) || throw(DomainError(
        converted,
        "event interval must remain positive after conversion to $T",
    ))
    return converted
end

function _dormancy_future_time(current::T, interval::Real, label) where {T<:Real}
    converted = _convert_positive_interval(T, interval)
    candidate = current + converted
    isfinite(candidate) || throw(ArgumentError("$label event time must be finite"))
    candidate > current || throw(ArgumentError("$label event time must increase"))
    return candidate
end

function _refresh_dormancy_timing!(state, parameters)
    timing = growth_unit_timing(
        parameters,
        state.vigor.reference_age;
        rhythm=state.rhythm,
    )
    state.growth_unit_test_count = timing.test_count
    state.time_per_test = _convert_positive_interval(
        typeof(state.time_per_test),
        timing.time_per_test,
    )
    return state
end

# The reference aggregates test dormancy only when aging is disabled and no
# growth-unit sleep returned early from `initProlepticSleep()`. Every other
# test delay is scheduled one test at a time so vigor can change at a growth-
# unit timing boundary and other buds retain their chronological event order.
function _advance_initial_dormancy!(state, rng, parameters, event_time)
    state.dormancy_complete && return (;
        action=:continue,
        phase=:complete,
        next_time=nothing,
        reference_age_before=state.vigor.reference_age,
        reference_age_after=state.vigor.reference_age,
    )

    reference_age_before = state.vigor.reference_age
    if isnothing(state.initial_dormancy)
        dormancy = sample_initial_dormancy(rng, parameters, reference_age_before)
        state.initial_dormancy = dormancy
        state.dormancy_growth_unit_delay_remaining = dormancy.growth_unit_delay
        state.dormancy_test_delay_remaining = dormancy.test_delay
        state.dormancy_incremental_test_delay =
            dormancy.ages_during_growth_unit_delay ||
            !iszero(dormancy.growth_unit_delay)
        if dormancy.dead
            state.ended = true
            state.dormancy_complete = true
            return (;
                action=:dead,
                phase=:death,
                next_time=nothing,
                reference_age_before,
                reference_age_after=state.vigor.reference_age,
            )
        end
    end

    dormancy = state.initial_dormancy::InitialDormancy
    if !iszero(state.dormancy_growth_unit_delay_remaining)
        delay = state.dormancy_growth_unit_delay_remaining
        state.dormancy_growth_unit_delay_remaining = 0
        if dormancy.ages_during_growth_unit_delay
            for _ in 1:delay
                state.vigor = advance_vigor(rng, parameters, state.vigor)
            end
        end
        return (;
            action=:wait,
            phase=:growth_unit_delay,
            next_time=_dormancy_future_time(
                event_time,
                delay,
                "growth-unit dormancy",
            ),
            reference_age_before,
            reference_age_after=state.vigor.reference_age,
        )
    end

    if !iszero(state.dormancy_test_delay_remaining)
        if state.dormancy_incremental_test_delay
            state.dormancy_test_delay_remaining = Base.Checked.checked_sub(
                state.dormancy_test_delay_remaining,
                1,
            )
            state.dormancy_test_index_within_growth_unit =
                Base.Checked.checked_add(
                    state.dormancy_test_index_within_growth_unit,
                    1,
                )
            if state.dormancy_test_index_within_growth_unit >=
               state.growth_unit_test_count
                state.vigor = advance_vigor(rng, parameters, state.vigor)
                state.dormancy_test_index_within_growth_unit = 0
                _refresh_dormancy_timing!(state, parameters)
            end
            state.dormancy_complete = iszero(state.dormancy_test_delay_remaining)
            return (;
                action=:wait,
                phase=:test_delay,
                next_time=_dormancy_future_time(
                    event_time,
                    state.time_per_test,
                    "test dormancy",
                ),
                reference_age_before,
                reference_age_after=state.vigor.reference_age,
            )
        end

        delay = state.dormancy_test_delay_remaining * state.time_per_test
        state.dormancy_test_delay_remaining = 0
        state.dormancy_complete = true
        return (;
            action=:wait,
            phase=:test_delay,
            next_time=_dormancy_future_time(event_time, delay, "test dormancy"),
            reference_age_before,
            reference_age_after=state.vigor.reference_age,
        )
    end

    state.dormancy_complete = true
    return (;
        action=:continue,
        phase=:complete,
        next_time=nothing,
        reference_age_before,
        reference_age_after=state.vigor.reference_age,
    )
end

function _legacy_initial_vigor(
    rng,
    parameters,
    physiological_age=parameters.initialization.initial_physiological_age,
)
    vigor = initial_vigor_state(rng, parameters, physiological_age)
    vigor = advance_vigor(rng, parameters, vigor)
    remaining = Base.Checked.checked_sub(vigor.remaining_growth_units, 1)
    return VigorState(
        vigor.reference_age,
        vigor.next_reference_age,
        remaining,
    )
end

function _build_apical_bud_state(
    parameters::AMAPSimParameters,
    bud_id::UInt64,
    ::Type{T},
    vigor::VigorState,
    rhythm::Real,
    organ_symbol=:Internode,
    immediate_branching_order::Integer=0,
) where {T<:Real}
    isfinite(rhythm) || throw(ArgumentError("bud rhythm must be finite"))
    rhythm > 0 || throw(DomainError(rhythm, "bud rhythm must be positive"))
    rhythm = Float64(rhythm)
    immediate_branching_order = _validate_development_count(
        immediate_branching_order,
        "immediate branching order",
    )
    maximum_growth_unit_count = _truncate_parameter_integer(
        valueat(
            parameters.axis.topology.maximum_growth_unit_count,
            vigor.reference_age,
        ),
        "maximum growth-unit count",
    )
    maximum_growth_unit_count >= 0 || throw(DomainError(
        maximum_growth_unit_count,
        "maximum growth-unit count cannot be negative",
    ))
    maximum_reference_age = Float64(valueat(
        parameters.axis.topology.maximum_axis_physiological_age,
        vigor.reference_age,
    ))
    maximum_reference_age >= 0 || throw(DomainError(
        maximum_reference_age,
        "maximum axis physiological age cannot be negative",
    ))
    timing = growth_unit_timing(
        parameters,
        vigor.reference_age;
        rhythm=rhythm,
    )
    return ApicalBudState{T}(
        bud_id,
        vigor,
        rhythm,
        nothing,
        0,
        maximum_growth_unit_count,
        maximum_reference_age,
        false,
        nothing,
        0,
        0,
        0,
        false,
        false,
        nothing,
        timing.test_count,
        _convert_positive_interval(T, timing.time_per_test),
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        immediate_branching_order,
        fill(
            BranchingSiteUndefined,
            length(parameters.lateral_productions),
        ),
        Union{Nothing,Bool}[nothing for _ in parameters.lateral_productions],
        Union{Nothing,Float64}[nothing for _ in parameters.lateral_productions],
        Union{Nothing,Float64}[nothing for _ in parameters.lateral_productions],
        Union{Nothing,Int}[nothing for _ in parameters.lateral_productions],
        ImmediateSemiMarkovState[
            ImmediateSemiMarkovState() for _ in parameters.lateral_productions
        ],
        Union{Nothing,DelayedBranchState}[
            nothing for _ in parameters.lateral_productions
        ],
        false,
        0,
        UInt64(0),
        UInt64(0),
        UInt64(0),
        nothing,
        _normalized_organ_symbol(organ_symbol),
    )
end

function _initialize_apical_bud_state(
    rng,
    parameters::AMAPSimParameters,
    bud,
    ::Type{T},
) where {T<:Real}
    physiological_age = _meristem_current_physiological_age(
        bud;
        allow_legacy=false,
    )
    vigor = _legacy_initial_vigor(rng, parameters, physiological_age)
    return _build_apical_bud_state(
        parameters,
        UInt64(node_id(bud)),
        T,
        vigor,
        1.0,
    )
end

function _initialize_lateral_bud_state(
    rng,
    parameters::AMAPSimParameters,
    ::Type{T},
    initialization::Union{
        CycleDelayedBranchInitialization,
        ImmediateBranchInitialization,
        DelayedBranchInitialization,
        TraumaticBranchInitialization,
    },
    organ_symbol=:Internode,
    immediate_branching_order::Integer=0,
) where {T<:Real}
    vigor = _legacy_initial_vigor(
        rng,
        parameters,
        initialization.physiological_age,
    )
    return _build_apical_bud_state(
        parameters,
        UInt64(0),
        T,
        vigor,
        initialization.rhythm,
        organ_symbol,
        immediate_branching_order,
    )
end

function _branch_initialization_with_age(
    initialization::ImmediateBranchInitialization,
    physiological_age,
)
    age = Float64(_validated_physiological_age(
        physiological_age,
        "selected child-axis initial physiological age",
    ))
    return ImmediateBranchInitialization(
        age - 1,
        age,
        initialization.rhythm,
        initialization.absolute_jump,
    )
end

function _branch_initialization_with_age(
    initialization::CycleDelayedBranchInitialization,
    physiological_age,
)
    age = Float64(_validated_physiological_age(
        physiological_age,
        "selected child-axis initial physiological age",
    ))
    return CycleDelayedBranchInitialization(
        age - 1,
        age,
        initialization.rhythm,
        initialization.absolute_jump,
    )
end

function _branch_initialization_with_age(
    initialization::TraumaticBranchInitialization,
    physiological_age,
)
    age = Float64(_validated_physiological_age(
        physiological_age,
        "selected child-axis initial physiological age",
    ))
    return TraumaticBranchInitialization(
        age - 1,
        age,
        initialization.rhythm,
        initialization.absolute_jump,
    )
end

function _branch_initialization_with_age(
    initialization::DelayedBranchInitialization,
    physiological_age,
)
    age = Float64(_validated_physiological_age(
        physiological_age,
        "selected child-axis initial physiological age",
    ))
    return DelayedBranchInitialization(
        initialization.branch_type,
        age - 1,
        age,
        initialization.rhythm,
        initialization.absolute_jump,
    )
end

function _axis_category_configuration(status)
    has_categories = hasproperty(status, :axis_categories)
    has_model = hasproperty(status, :axis_category_initiation)
    has_categories == has_model || throw(ArgumentError(
        "plant status must define axis_categories and axis_category_initiation together",
    ))
    has_categories || return nothing
    categories = _validated_axis_categories(status.axis_categories)
    model = status.axis_category_initiation
    model isa AbstractAxisCategoryInitiationModel || throw(ArgumentError(
        "plant status axis_category_initiation must be an " *
        "AbstractAxisCategoryInitiationModel",
    ))
    return (; categories, model)
end

function _resolve_child_axis_initialization(
    status,
    rng,
    bearer_axis,
    state,
    initialization;
    growth_unit_physiological_age,
    position,
    zone,
    branching_type,
    lateral_production,
    slot,
    time,
    environment,
)
    configuration = _axis_category_configuration(status)
    configuration === nothing && return (;
        category=nothing,
        initialization,
        context=nothing,
    )
    context = AxisInitiationContext(;
        bearer_axis_id=node_id(bearer_axis),
        bearer_category=_axis_category_identifier(bearer_axis),
        bearer_current_physiological_age=state.vigor.reference_age + 1,
        growth_unit_physiological_age,
        position,
        zone,
        branching_type,
        lateral_production,
        slot,
        time,
        environment,
        proposed_initial_physiological_age=initialization.physiological_age,
    )
    selection = select_axis_category(
        configuration.model,
        context,
        configuration.categories,
        rng,
    )
    category = _resolved_selected_axis_category(
        selection,
        configuration.categories,
    )
    resolved_initialization = _branch_initialization_with_age(
        initialization,
        category.initial_physiological_age,
    )
    return (; category, initialization=resolved_initialization, context)
end

function _prepare_cycle!(state, rng, parameters)
    starts_growth_unit = iszero(state.growth_unit_node_id)
    growth_unit_sympody = nothing
    if starts_growth_unit
        polycyclism = sample_polycyclism(
            rng,
            parameters,
            state.vigor.reference_age,
            state.previous_polycyclic,
        )
        state.previous_polycyclic = polycyclism.polycyclic
        state.planned_cycle_count = polycyclism.cycle_count
        state.growth_unit_index = Base.Checked.checked_add(state.growth_unit_index, 1)
        state.cycle_index = 1
        state.test_index_within_growth_unit = 0
        state.internode_count_within_growth_unit = 0
        growth_unit_sympody = sample_sympodial_transition(
            rng,
            valueat(
                parameters.axis.topology.sympodial_probability_between_growth_units,
                state.vigor.reference_age,
            ),
        )
    else
        state.cycle_index = Base.Checked.checked_add(state.cycle_index, 1)
    end
    state.test_index_within_cycle = 0
    state.internode_count_within_cycle = 0
    state.phytomer_count_within_zone = 0
    state.neoformed_zone_started = false
    state.neoformed_test_count = 0
    cycle = initialize_cycle(
        rng,
        parameters,
        state.vigor.reference_age,
        state.cycle_index,
        state.growth_unit_test_count;
        # CycleAMAP::init subtracts the zero-based last test index from the
        # GU budget. Adapt that legacy convention here; initialize_cycle's
        # public completed_test_count keyword retains its count semantics.
        completed_test_count=max(0, state.test_index_within_growth_unit - 1),
    )
    cycle_sympody = sample_sympodial_transition(
        rng,
        valueat(
            parameters.axis.topology.sympodial_probability_between_growth_cycles,
            state.vigor.reference_age,
        ),
    )
    cycle.preformed_internode_count >= 0 || throw(DomainError(
        cycle.preformed_internode_count,
        "negative preformed internode counts are not supported by the first apical slice",
    ))
    state.cycle = cycle
    return (; starts_growth_unit, growth_unit_sympody, cycle_sympody)
end

function _theoretical_cycle_test_count(cycle::CycleInitialization)
    raw_count = cycle.preformed_test_count +
                cycle.neoformed_test_lag +
                cycle.neoformed_maximum_test_count
    count = _truncate_parameter_integer(raw_count, "theoretical cycle test count")
    count >= 0 || throw(DomainError(
        count,
        "theoretical cycle test count cannot be negative",
    ))
    return count
end

function _current_basal_position(state, parameters, reference_age)
    return mortality_position(
        parameters,
        reference_age;
        test_count_within_growth_unit=state.test_index_within_growth_unit,
        test_count_within_cycle=state.test_index_within_cycle,
        test_count_on_axis=state.test_count_on_axis,
        internode_count_within_growth_unit=state.internode_count_within_growth_unit,
        internode_count_within_cycle=state.internode_count_within_cycle,
        internode_count_on_axis=state.internode_count_on_axis,
    )
end

function _axis_allows_lateral_branching(axis)
    nature = get(
        MultiScaleTreeGraph.node_attributes(axis),
        :Nature,
        nothing,
    )
    return nature != 2
end

function _maximum_nature_zero_branching_order(parameters, initial_reference_age)
    maximum_order = _truncate_parameter_integer(
        valueat(
            parameters.axis.topology.maximum_branching_order_nature_zero,
            initial_reference_age,
        ),
        "maximum branching order for nature-zero axes",
    )
    maximum_order >= 0 || throw(DomainError(
        maximum_order,
        "maximum branching order cannot be negative",
    ))
    return maximum_order
end

function _immediate_branching_limit(state, parameters, nature)
    nature = _truncate_parameter_integer(nature, "axis nature")
    # C++ clears `BranchBegining` immediately after this one-shot limit check,
    # before it samples or schedules proleptic dormancy. Julia's persistent
    # `initial_dormancy` is the corresponding marker on later sleep events.
    if iszero(state.immediate_branching_order) ||
       nature == 2 ||
       !iszero(state.growth_unit_index) ||
       !isnothing(state.initial_dormancy)
        return (; exceeded=false, maximum_order=nothing, nature)
    end
    maximum_order = _truncate_parameter_integer(
        valueat(
            parameters.axis.topology.maximum_immediate_branching_order,
            state.vigor.reference_age,
        ),
        "maximum immediate branching order",
    )
    maximum_order >= 0 || throw(DomainError(
        maximum_order,
        "maximum immediate branching order cannot be negative",
    ))
    threshold = maximum_order == typemax(Int) ? typemax(Int) : maximum_order + 1
    return (;
        exceeded=state.immediate_branching_order > threshold,
        maximum_order,
        nature,
    )
end

function _record_immediate_markov_site!(
    state,
    parameters,
    position,
    zone_index,
    lateral_index=nothing,
)
    isfinite(position) || throw(ArgumentError(
        "immediate Markov bearer position must be finite",
    ))
    zone_index = _validate_development_count(
        zone_index,
        "immediate Markov bearer zone index",
    )
    lateral_count = length(parameters.lateral_productions)
    length(state.immediate_markov_previous_positions) == lateral_count ||
        throw(ArgumentError(
            "immediate Markov previous-position state does not match lateral productions",
        ))
    length(state.immediate_markov_previous_zone_indices) == lateral_count ||
        throw(ArgumentError(
            "immediate Markov previous-zone state does not match lateral productions",
        ))
    lateral_indices = _selected_lateral_production_indices(
        parameters,
        lateral_index,
    )
    for index in lateral_indices
        lateral = parameters.lateral_productions[index]
        1 <= zone_index <= length(lateral.zones) ||
            throw(BoundsError(lateral.zones, zone_index))
        state.immediate_markov_previous_positions[index] = Float64(position)
        state.immediate_markov_previous_zone_indices[index] = zone_index
    end
    return state
end

function _selected_lateral_production_indices(parameters, lateral_index)
    isnothing(lateral_index) && return eachindex(parameters.lateral_productions)
    index = _validate_development_count(
        lateral_index,
        "selected lateral-production index",
    )
    1 <= index <= length(parameters.lateral_productions) || throw(
        BoundsError(parameters.lateral_productions, index),
    )
    return (index,)
end

# Event-local staging touches only sites consulted by the current branching
# scans. Values are flat vectors of enums, so a shallow vector copy isolates
# their mutations without copying every site accumulated by the plant.
struct _BranchingSiteLedgerPatch
    base::Dict{UInt64,Vector{LegacyBranchingSiteState}}
    updates::Dict{UInt64,Vector{LegacyBranchingSiteState}}
    deleted::Set{UInt64}
end

_BranchingSiteLedgerPatch(base::Dict{UInt64,Vector{LegacyBranchingSiteState}}) =
    _BranchingSiteLedgerPatch(base, empty(base), Set{UInt64}())

function Base.get!(default::F, patch::_BranchingSiteLedgerPatch, key::UInt64) where {F<:Function}
    return get!(patch.updates, key) do
        if !(key in patch.deleted) && haskey(patch.base, key)
            copy(patch.base[key])
        else
            default()
        end
    end
end

function Base.delete!(patch::_BranchingSiteLedgerPatch, key::UInt64)
    delete!(patch.updates, key)
    push!(patch.deleted, key)
    return patch
end

function _commit_branching_site_states!(patch::_BranchingSiteLedgerPatch)
    # Floating cleanup also removes live entries during graph removal. Keep
    # tombstones even for those keys so a staged value cannot resurrect them.
    for key in patch.deleted
        delete!(patch.base, key)
    end
    merge!(patch.base, patch.updates)
    return patch.base
end

function _branching_site_states!(ledger, phytomer, lateral_count::Integer)
    lateral_count = _validate_development_count(
        lateral_count,
        "lateral-production count for branching-site state",
    )
    phytomer_id = UInt64(node_id(phytomer))
    states = get!(ledger, phytomer_id) do
        fill(BranchingSiteUndefined, lateral_count)
    end
    states isa Vector{LegacyBranchingSiteState} || throw(ArgumentError(
        "branching-site ledger entry $phytomer_id has an invalid state vector",
    ))
    length(states) == lateral_count || throw(ArgumentError(
        "branching-site ledger entry $phytomer_id does not match lateral productions",
    ))
    return states
end

function _branching_site_state(ledger, phytomer, lateral_index, lateral_count)
    states = _branching_site_states!(ledger, phytomer, lateral_count)
    1 <= lateral_index <= length(states) || throw(BoundsError(states, lateral_index))
    return states[lateral_index]
end

function _set_branching_site_state!(
    ledger,
    phytomer,
    lateral_index,
    lateral_count,
    branching_state::LegacyBranchingSiteState,
)
    states = _branching_site_states!(ledger, phytomer, lateral_count)
    1 <= lateral_index <= length(states) || throw(BoundsError(states, lateral_index))
    states[lateral_index] = branching_state
    return branching_state
end

function _delayed_state_from_branching_site(state::LegacyBranchingSiteState)
    state in (
        BranchingSiteUnbranched,
        BranchingSiteImmediateUnbranched,
        BranchingSiteCycleDelayedUnbranched,
        BranchingSiteTraumaticUnbranched,
    ) && return DelayedUnbranched
    state in (
        BranchingSiteImmediate,
        BranchingSiteDelayedType1,
        BranchingSiteTraumatic,
        BranchingSiteCycleDelayed,
    ) && return DelayedType1
    state == BranchingSiteDelayedType2 && return DelayedType2
    return nothing
end

function _immediate_state_from_branching_site(state::LegacyBranchingSiteState)
    state in (
        BranchingSiteUnbranched,
        BranchingSiteImmediateUnbranched,
        BranchingSiteCycleDelayedUnbranched,
    ) && return false
    state in (
        BranchingSiteImmediate,
        BranchingSiteDelayedType1,
    ) && return true
    return nothing
end

function _immediate_semimarkov_input_state(
    state::ImmediateSemiMarkovState,
    shared_state::LegacyBranchingSiteState,
)
    shared_state == BranchingSiteUndefined && return ImmediateSemiMarkovState()
    isnothing(state.branched) && iszero(state.remaining_positions) &&
        return ImmediateSemiMarkovState(true, 0)
    return state
end

function _cycle_delayed_state_from_branching_site(
    state::LegacyBranchingSiteState,
)
    state in (
        BranchingSiteUnbranched,
        BranchingSiteImmediateUnbranched,
        BranchingSiteCycleDelayedUnbranched,
    ) && return false
    state in (
        BranchingSiteImmediate,
        BranchingSiteDelayedType1,
        BranchingSiteCycleDelayed,
    ) && return true
    return nothing
end

function _traumatic_state_from_branching_site(state::LegacyBranchingSiteState)
    state in (
        BranchingSiteUnbranched,
        BranchingSiteImmediateUnbranched,
        BranchingSiteCycleDelayedUnbranched,
        BranchingSiteTraumaticUnbranched,
    ) && return false
    state in (
        BranchingSiteImmediate,
        BranchingSiteDelayedType1,
        BranchingSiteTraumatic,
        BranchingSiteCycleDelayed,
    ) && return true
    return nothing
end

function _cycle_delayed_reset_state(state::LegacyBranchingSiteState)
    state in (
        BranchingSiteUnbranched,
        BranchingSiteImmediateUnbranched,
        BranchingSiteTraumaticUnbranched,
    ) && return false
    state in (
        BranchingSiteImmediate,
        BranchingSiteTraumatic,
        BranchingSiteCycleDelayed,
    ) && return true
    return nothing
end

function _traumatic_reset_state(state::LegacyBranchingSiteState)
    state in (
        BranchingSiteUnbranched,
        BranchingSiteImmediateUnbranched,
        BranchingSiteCycleDelayedUnbranched,
        BranchingSiteTraumaticUnbranched,
    ) && return false
    state in (
        BranchingSiteImmediate,
        BranchingSiteTraumatic,
        BranchingSiteCycleDelayed,
    ) && return true
    return nothing
end

function _delayed_markov_result_state(
    previous::LegacyBranchingSiteState,
    sampled::DelayedBranchState,
)
    previous_normalized = _delayed_state_from_branching_site(previous)
    sampled == previous_normalized && previous != BranchingSiteUndefined &&
        return previous
    sampled == DelayedUnbranched && return BranchingSiteUnbranched
    sampled == DelayedType1 && return BranchingSiteDelayedType1
    return BranchingSiteDelayedType2
end

function _legacy_branching_state_label(state::LegacyBranchingSiteState)
    state == BranchingSiteUnbranched && return "delayed_unbranched"
    state == BranchingSiteImmediate && return "immediate"
    state == BranchingSiteDelayedType1 && return "delayed_type_1"
    state == BranchingSiteDelayedType2 && return "delayed_type_2"
    state == BranchingSiteTraumatic && return "traumatic"
    state == BranchingSiteCycleDelayed && return "cycle_delayed"
    state == BranchingSiteImmediateUnbranched && return "immediate_unbranched"
    state == BranchingSiteCycleDelayedUnbranched &&
        return "cycle_delayed_unbranched"
    state == BranchingSiteTraumaticUnbranched && return "traumatic_unbranched"
    return "undifferentiated"
end

function _markov_cycle_delayed_site_available(state::LegacyBranchingSiteState)
    return state in (
        BranchingSiteUndefined,
        BranchingSiteUnbranched,
        BranchingSiteImmediateUnbranched,
        BranchingSiteTraumaticUnbranched,
    )
end

function _markov_delayed_site_available(state::LegacyBranchingSiteState)
    return state in (
        BranchingSiteUndefined,
        BranchingSiteUnbranched,
        BranchingSiteImmediateUnbranched,
        BranchingSiteCycleDelayedUnbranched,
        BranchingSiteTraumaticUnbranched,
    )
end

function _foreach_emitted_axillary_slot!(
    emit_slot,
    rng,
    lateral,
    reference_age,
)
    global_parameters = lateral.global_parameters
    requested_slot_count = _truncate_parameter_integer(
        valueat(global_parameters.axillary_count, reference_age),
        "axillary slot count",
    )
    requested_slot_count >= 0 || throw(DomainError(
        requested_slot_count,
        "axillary slot count cannot be negative",
    ))
    occurrence_probability = _validate_probability(valueat(
        global_parameters.axillary_probability,
        reference_age,
    ))
    for slot in 1:requested_slot_count
        sample_bernoulli(rng, occurrence_probability) || continue
        emit_slot(slot, requested_slot_count)
    end
    return nothing
end

# Project the selected field while the concrete lateral type is known. Reading
# `.zones` through the heterogeneous production vector otherwise boxes and
# copies the entire immutable tuple, including both large parameter zones.
Base.@noinline _lateral_production_zone(lateral::LateralProductionParameters, index) =
    lateral.zones[index]

Base.@noinline _lateral_production_zone_branching(lateral::LateralProductionParameters, index) =
    lateral.zones[index].branching

function _plan_immediate_branches!(
    state::ApicalBudState{T},
    rng,
    parameters,
    bearer_reference_age,
    position,
    zone_index,
    growth_unit_ended,
    parent_order,
    parent_reiteration_order,
    axis_initial_reference_age,
    status,
    bearer_axis,
    event_time,
    environment,
    branching_site_states,
    bearer_phytomer;
    lateral_index=nothing,
) where {T<:Real}
    plans = NamedTuple[]
    floating_cleanup_lateral_indices = Int[]
    lateral_count = length(parameters.lateral_productions)
    for lateral_index in _selected_lateral_production_indices(
        parameters,
        lateral_index,
    )
        lateral = parameters.lateral_productions[lateral_index]
        global_parameters = lateral.global_parameters
        outer_nature = _truncate_parameter_integer(
            valueat(global_parameters.nature, bearer_reference_age + 1),
            "outer lateral axis nature",
        )
        outer_nature >= 10 && continue
        if outer_nature == 0
            maximum_order = _maximum_nature_zero_branching_order(
                parameters,
                axis_initial_reference_age,
            )
            Base.Checked.checked_add(parent_order, 1) <= maximum_order ||
                continue
        end
        nature = _truncate_parameter_integer(
            valueat(global_parameters.nature, bearer_reference_age),
            "child lateral axis nature",
        )
        child_order = nature == 0 ?
                      Base.Checked.checked_add(parent_order, 1) :
                      parent_order
        is_immediate_production_position(
            lateral,
            bearer_reference_age,
            position,
        ) || continue
        direction = _truncate_parameter_integer(
            valueat(
                global_parameters.delayed_branch_counting_direction,
                bearer_reference_age,
            ),
            "branch production counting direction",
        )
        !iszero(direction) && push!(
            floating_cleanup_lateral_indices,
            lateral_index,
        )
        if is_immediate_state_reset_position(
            parameters,
            bearer_reference_age + 1;
            test_index_within_growth_unit=state.test_index_within_growth_unit,
            test_index_within_cycle=state.test_index_within_cycle,
            test_index_on_axis=state.test_count_on_axis,
        )
            state.legacy_branching_states[lateral_index] =
                BranchingSiteUndefined
            state.immediate_markov_states[lateral_index] = nothing
            state.immediate_markov_initial_probabilities[lateral_index] = nothing
            state.immediate_markov_previous_positions[lateral_index] = nothing
            state.immediate_markov_previous_zone_indices[lateral_index] = nothing
            state.immediate_semimarkov_states[lateral_index] =
                ImmediateSemiMarkovState()
        end
        zone = _lateral_production_zone(lateral, zone_index)
        is_markov = lateral.branching_models[2] == MarkovModel
        branched = if is_markov
            previous_position =
                state.immediate_markov_previous_positions[lateral_index]
            previous_zone_index =
                state.immediate_markov_previous_zone_indices[lateral_index]
            xor(isnothing(previous_position), isnothing(previous_zone_index)) &&
                throw(ArgumentError(
                    "immediate Markov previous position and zone must be stored together",
                ))
            previous_branching = if isnothing(previous_zone_index)
                nothing
            else
                1 <= previous_zone_index <= length(lateral.zones) ||
                    throw(BoundsError(lateral.zones, previous_zone_index))
                _lateral_production_zone_branching(lateral, previous_zone_index::Int)
            end
            previous_branched = _immediate_state_from_branching_site(
                state.legacy_branching_states[lateral_index],
            )
            if previous_branched === nothing &&
               state.legacy_branching_states[lateral_index] ==
               BranchingSiteUndefined &&
               position > 0 &&
               state.internode_count_on_axis > 1
                previous_branched = false
            end
            transition = sample_immediate_markov_state(
                rng,
                zone,
                bearer_reference_age,
                position,
                previous_branched;
                previous_branching,
                previous_position,
            )
            state.immediate_markov_states[lateral_index] = transition.branched
            state.immediate_markov_initial_probabilities[lateral_index] =
                transition.initial_probability
            state.legacy_branching_states[lateral_index] = transition.branched ?
                                                        BranchingSiteImmediate :
                                                        BranchingSiteImmediateUnbranched
            transition.branched
        else
            previous_semi_markov_state = _immediate_semimarkov_input_state(
                state.immediate_semimarkov_states[lateral_index],
                state.legacy_branching_states[lateral_index],
            )
            next_state = advance_immediate_semimarkov_state(
                rng,
                zone,
                bearer_reference_age,
                position,
                previous_semi_markov_state,
            )
            state.immediate_semimarkov_states[lateral_index] = next_state
            if previous_semi_markov_state.remaining_positions <= 0
                state.legacy_branching_states[lateral_index] = next_state.branched ?
                                                            BranchingSiteImmediate :
                                                            BranchingSiteImmediateUnbranched
            end
            next_state.branched::Bool
        end
        if is_markov
            branching_state = branched ?
                              BranchingSiteImmediate :
                              BranchingSiteImmediateUnbranched
            _set_branching_site_state!(
                branching_site_states,
                bearer_phytomer,
                lateral_index,
                lateral_count,
                branching_state,
            )
            bearer_phytomer[:BranchingState] = branched ?
                                                        "immediate" :
                                                        "immediate_unbranched"
        end
        branched || continue

        occurrence_probability = _validate_probability(valueat(
            global_parameters.axillary_probability,
            bearer_reference_age,
        ))
        iszero(occurrence_probability) && continue
        # verticille() backdates only ANTICIPE + SimpleImmediateOrgan (Nature 2)
        # by the bearer's current post-growth interval, not the child's interval.
        birth_time = nature == 2 ? event_time - state.time_per_test : event_time
        isfinite(birth_time) || throw(ArgumentError(
            "immediate child birth time must be finite",
        ))
        initialization = sample_immediate_branch_initialization(
            rng,
            zone,
            bearer_reference_age,
            position;
            current_reference_age=state.vigor.reference_age,
            growth_unit_ended,
        )
        child_reiteration_order = reiteration_order(
            parameters.axis.topology,
            axis_initial_reference_age,
            bearer_reference_age,
            initialization.physiological_age,
            parent_reiteration_order,
        )
        isnothing(child_reiteration_order) && continue
        _foreach_emitted_axillary_slot!(
            rng,
            lateral,
            bearer_reference_age,
        ) do slot, slot_count
            resolved = _resolve_child_axis_initialization(
                status,
                rng,
                bearer_axis,
                state,
                initialization;
                growth_unit_physiological_age=bearer_reference_age + 1,
                position,
                zone=zone_index,
                branching_type=:immediate,
                lateral_production=lateral_index,
                slot,
                time=event_time,
                environment,
            )
            resolved_reiteration_order = reiteration_order(
                parameters.axis.topology,
                axis_initial_reference_age,
                bearer_reference_age,
                resolved.initialization.physiological_age,
                parent_reiteration_order,
            )
            isnothing(resolved_reiteration_order) && return nothing
            child_state = _initialize_lateral_bud_state(
                rng,
                parameters,
                T,
                resolved.initialization,
                lateral.organ_symbol,
                Base.Checked.checked_add(state.immediate_branching_order, 1),
            )
            push!(plans, (;
                lateral_index,
                nature,
                child_order,
                reiteration_order=resolved_reiteration_order,
                slot,
                slot_count,
                category=resolved.category,
                initialization=resolved.initialization,
                initiation_context=resolved.context,
                birth_time,
                child_state,
            ))
            return nothing
        end
    end
    return (;
        branches=plans,
        floating_cleanup_lateral_indices,
    )
end

function _plan_apical_test!(
    state,
    rng,
    parameters,
    event_time,
    parent_order,
    parent_reiteration_order,
    axis_initial_reference_age,
    lateral_branching_enabled,
    status,
    parent_axis,
    environment,
    growth_unit_first_dispatch_time,
)
    reference_age = state.vigor.reference_age
    starts_cycle = isnothing(state.cycle)
    cycle_start = if starts_cycle
        _prepare_cycle!(state, rng, parameters)
    else
        (;
            starts_growth_unit=false,
            growth_unit_sympody=nothing,
            cycle_sympody=nothing,
        )
    end
    starts_growth_unit = cycle_start.starts_growth_unit
    cycle = state.cycle::CycleInitialization
    in_neoformed_zone = cycle.has_neoformed_zone && (
        state.neoformed_zone_started ||
        state.test_index_within_cycle >= cycle.preformed_internode_count
    )
    starts_neoformed_zone = false
    creates_test_site = true
    zone_kind = in_neoformed_zone ? :neoformed : :preformed
    zone_test_index = 0
    realized = false
    cycle_ended = false

    if in_neoformed_zone
        neoformed = sample_neoformed_test(
            rng,
            cycle;
            zone_started=state.neoformed_zone_started,
            completed_test_count=state.neoformed_test_count,
        )
        starts_neoformed_zone = neoformed.started_zone
        creates_test_site = neoformed.created_test_site
        realized = neoformed.realized_internode
        cycle_ended = neoformed.ended_cycle
        state.neoformed_zone_started |= neoformed.started_zone
        starts_neoformed_zone && (state.phytomer_count_within_zone = 0)
        if creates_test_site
            state.test_index_within_growth_unit = Base.Checked.checked_add(
                state.test_index_within_growth_unit,
                1,
            )
            state.test_index_within_cycle = Base.Checked.checked_add(
                state.test_index_within_cycle,
                1,
            )
            state.neoformed_test_count = neoformed.test_index
            zone_test_index = neoformed.test_index
        end
    else
        state.test_index_within_growth_unit = Base.Checked.checked_add(
            state.test_index_within_growth_unit,
            1,
        )
        state.test_index_within_cycle = Base.Checked.checked_add(
            state.test_index_within_cycle,
            1,
        )
        zone_test_index = state.test_index_within_cycle
        realized = state.test_index_within_cycle <= cycle.preformed_internode_count
        cycle_ended = !cycle.has_neoformed_zone && (
            iszero(cycle.preformed_internode_count) ||
            state.test_index_within_cycle >= cycle.preformed_internode_count
        )
    end

    if creates_test_site
        state.test_count_on_axis = Base.Checked.checked_add(
            state.test_count_on_axis,
            1,
        )
    end
    if realized
        state.internode_count_within_growth_unit = Base.Checked.checked_add(
            state.internode_count_within_growth_unit,
            1,
        )
        state.internode_count_within_cycle = Base.Checked.checked_add(
            state.internode_count_within_cycle,
            1,
        )
        state.internode_count_on_axis = Base.Checked.checked_add(
            state.internode_count_on_axis,
            1,
        )
        state.phytomer_count_within_zone = Base.Checked.checked_add(
            state.phytomer_count_within_zone,
            1,
        )
    end
    position = _current_basal_position(state, parameters, reference_age)
    survived = sample_bud_survival(rng, parameters, reference_age, position)
    mortality_death_position = survived ? nothing : position
    cycle_tail_test_count = 0
    cycle_tail_survival_test_count = 0
    counting_base = _truncate_parameter_integer(
        valueat(parameters.axis.topology.topology_counting_base, reference_age),
        "topology counting base",
    )
    if cycle_ended && survived && iszero(counting_base)
        theoretical_test_count = _theoretical_cycle_test_count(cycle)
        remaining_test_count = max(
            theoretical_test_count - state.test_index_within_cycle,
            0,
        )
        tail = sample_cycle_tail_mortality(
            rng,
            parameters,
            reference_age,
            position,
            remaining_test_count,
        )
        cycle_tail_test_count = tail.filled_test_count
        cycle_tail_survival_test_count = tail.sampled_survival_count
        state.test_index_within_growth_unit = Base.Checked.checked_add(
            state.test_index_within_growth_unit,
            tail.filled_test_count,
        )
        state.test_index_within_cycle = Base.Checked.checked_add(
            state.test_index_within_cycle,
            tail.filled_test_count,
        )
        state.test_count_on_axis = Base.Checked.checked_add(
            state.test_count_on_axis,
            tail.filled_test_count,
        )
        survived = tail.survived
        mortality_death_position = tail.death_position
    end
    bud_died = !survived

    theoretical_growth_unit_test_count = state.test_index_within_growth_unit
    # limitGuTime() fixes the GU clock at its first dispatch. Cycle-tail
    # tests consume counters without advancing time, including tails completed
    # in earlier cycles, so their count cannot reconstruct the scheduled end.
    theoretical_growth_unit_end_time =
        growth_unit_first_dispatch_time - state.time_per_test +
        state.growth_unit_test_count * state.time_per_test
    isfinite(theoretical_growth_unit_end_time) || throw(ArgumentError(
        "theoretical growth-unit end time must be finite",
    ))

    growth_unit_ended = bud_died || (
        creates_test_site &&
        state.test_index_within_growth_unit >= state.growth_unit_test_count
    ) ||
                        (cycle_ended && state.cycle_index >= state.planned_cycle_count)

    next_interval = state.time_per_test
    axis_ended = false
    if growth_unit_ended
        state.vigor = advance_vigor(rng, parameters, state.vigor)
        axis_ended = state.growth_unit_index >= state.maximum_growth_unit_count ||
                     state.vigor.reference_age >= state.maximum_reference_age
        state.ended = bud_died || axis_ended
        # endGu() refreshes getTimeGu() before the max-GU/death stop, while
        # the new reference age is below maxPhyAge. Immediate Nature 2
        # branches also use this interval when the bearer has just ended.
        if state.vigor.reference_age < state.maximum_reference_age
            timing = growth_unit_timing(
                parameters,
                state.vigor.reference_age;
                rhythm=state.rhythm,
            )
            state.growth_unit_test_count = timing.test_count
            state.time_per_test = _convert_positive_interval(
                typeof(state.time_per_test),
                timing.time_per_test,
            )
            next_interval = state.time_per_test
        end
    elseif cycle_ended
        state.cycle = nothing
    end
    theoretical_growth_unit_duration = state.ended ? growth_unit_timing(
        parameters,
        state.vigor.reference_age;
        rhythm=state.rhythm,
    ).duration : nothing

    # Bud::process_event temporarily repositions on the last realized internode
    # before ramification when mortality has filled the cycle's empty test tail.
    # Keep that site's position distinct from the completed test counters.
    branch_position = realized ? position :
                      _current_basal_position(state, parameters, reference_age)

    next_time = if state.ended
        nothing
    else
        next_anchor = growth_unit_ended ?
                      theoretical_growth_unit_end_time : event_time
        candidate = next_anchor + next_interval
        isfinite(candidate) ||
            throw(ArgumentError("next apical event time must be finite"))
        candidate > event_time ||
            throw(ArgumentError("next apical event time must increase"))
        candidate
    end
    return (;
        reference_age,
        starts_growth_unit,
        starts_cycle,
        growth_unit_sympody=cycle_start.growth_unit_sympody,
        cycle_sympody=cycle_start.cycle_sympody,
        starts_neoformed_zone,
        creates_test_site,
        zone_kind,
        zone_test_index,
        realized,
        cycle_ended,
        growth_unit_ended,
        axis_ended,
        mortality_position=position,
        mortality_death_position,
        survived,
        bud_died,
        cycle_tail_test_count,
        cycle_tail_survival_test_count,
        theoretical_growth_unit_test_count,
        theoretical_growth_unit_end_time,
        theoretical_growth_unit_duration,
        branch_position,
        branching_zone_index=zone_kind == :neoformed ? 2 : 1,
        bearer_axis_internode_index=state.internode_count_on_axis,
        immediate_branches=NamedTuple[],
        floating_cleanup_lateral_indices=Int[],
        next_time,
    )
end

function _add_hierarchy_node!(
    parent_node,
    context,
    node_symbol,
    node_scale;
    link=:/,
    index,
    attributes,
)
    status = PlantSimEngine.add_organ!(
        parent_node,
        context,
        link,
        node_symbol,
        node_scale;
        index=index,
        attributes=attributes,
        # The AMAPSim status adapter adds runtime state only for Plant nodes.
        # Every other hierarchy node is fully described by its creation
        # attributes, so asking PSE to call the adapter would construct and
        # immediately discard one equivalent Status. Keep the adapter for an
        # explicitly declared :Plant product to preserve that existing path.
        use_status_adapter=
            Symbol(node_symbol) === AMAPSIM_MTG_SYMBOLS.plant,
    )
    # add_organ! returns the canonical registry Status, not a kernel-local view.
    return PlantSimEngine.source_node(context, status)
end

function _development_site_batch(state, plan)
    tail_count = _validate_development_count(
        plan.cycle_tail_test_count,
        "cycle-tail developmental-site count",
    )
    base_growth_unit_test_index = _validate_development_count(
        Base.Checked.checked_sub(
            _validate_development_count(
                state.test_index_within_growth_unit,
                "growth-unit developmental-site count",
            ),
            tail_count,
        ),
        "growth-unit developmental-site base rank",
    )
    base_cycle_test_index = _validate_development_count(
        Base.Checked.checked_sub(
            _validate_development_count(
                state.test_index_within_cycle,
                "cycle developmental-site count",
            ),
            tail_count,
        ),
        "cycle developmental-site base rank",
    )
    base_axis_test_index = _validate_development_count(
        Base.Checked.checked_sub(
            _validate_development_count(
                state.test_count_on_axis,
                "axis developmental-site count",
            ),
            tail_count,
        ),
        "axis developmental-site base rank",
    )
    actual_zone_kind = state.neoformed_zone_started ? :neoformed : :preformed
    base_zone_test_index = if actual_zone_kind === :preformed
        base_cycle_test_index
    else
        _validate_development_count(
            state.neoformed_test_count,
            "neoformed-zone developmental-site count",
        )
    end
    main_outcome = if plan.creates_test_site
        plan.realized ? RealizedDevelopmentSite : FailedDevelopmentSite
    else
        plan.realized && throw(ArgumentError(
            "a developmental test cannot be realized when no test was created",
        ))
        nothing
    end
    if !isnothing(main_outcome)
        all(>(0), (
            base_zone_test_index,
            base_growth_unit_test_index,
            base_cycle_test_index,
            base_axis_test_index,
        )) || throw(DomainError(
            (
                base_zone_test_index,
                base_growth_unit_test_index,
                base_cycle_test_index,
                base_axis_test_index,
            ),
            "a created developmental site must have strictly positive ranks",
        ))
        plan.zone_kind === actual_zone_kind || throw(ArgumentError(
            "planned and active developmental-site zones disagree",
        ))
        _validate_development_count(
            plan.zone_test_index,
            "planned zone developmental-site rank",
        ) == base_zone_test_index || throw(ArgumentError(
            "planned and counted developmental-site zone ranks disagree",
        ))
    end
    growth_unit_internode_index = _validate_development_count(
        state.internode_count_within_growth_unit,
        "growth-unit internode count",
    )
    cycle_internode_index = _validate_development_count(
        state.internode_count_within_cycle,
        "cycle internode count",
    )
    axis_internode_index = _validate_development_count(
        state.internode_count_on_axis,
        "axis internode count",
    )

    # Validate the final ranks now, before any public MTG node is created.
    Base.Checked.checked_add(base_zone_test_index, tail_count)
    Base.Checked.checked_add(base_growth_unit_test_index, tail_count)
    Base.Checked.checked_add(base_cycle_test_index, tail_count)
    Base.Checked.checked_add(base_axis_test_index, tail_count)

    return _DevelopmentSiteBatch(
        main_outcome,
        actual_zone_kind,
        base_zone_test_index,
        base_growth_unit_test_index,
        base_cycle_test_index,
        base_axis_test_index,
        growth_unit_internode_index,
        cycle_internode_index,
        axis_internode_index,
        tail_count,
    )
end

@inline function _main_development_site(batch::_DevelopmentSiteBatch)
    isnothing(batch.main_outcome) && return nothing
    return _DevelopmentSiteSpecification(
        batch.zone_kind,
        batch.base_zone_test_index,
        batch.base_growth_unit_test_index,
        batch.base_cycle_test_index,
        batch.base_axis_test_index,
        batch.growth_unit_internode_index,
        batch.cycle_internode_index,
        batch.axis_internode_index,
        something(batch.main_outcome),
    )
end

@inline function _cycle_tail_development_site(
    batch::_DevelopmentSiteBatch,
    tail_index::Int,
)
    1 <= tail_index <= batch.tail_count || throw(BoundsError(
        Base.OneTo(batch.tail_count),
        tail_index,
    ))
    return _DevelopmentSiteSpecification(
        batch.zone_kind,
        batch.base_zone_test_index + tail_index,
        batch.base_growth_unit_test_index + tail_index,
        batch.base_cycle_test_index + tail_index,
        batch.base_axis_test_index + tail_index,
        batch.growth_unit_internode_index,
        batch.cycle_internode_index,
        batch.axis_internode_index,
        CycleTailDevelopmentSite,
    )
end

function _materialize_apical_test!(
    status,
    bud_node,
    state,
    plan,
    site_batch::_DevelopmentSiteBatch,
    event,
    context,
)
    symbols = AMAPSIM_MTG_SYMBOLS
    scales = AMAPSIM_MTG_SCALES
    growth_unit_node = if plan.starts_growth_unit
        annual_shoot = _ancestor_with_symbol(bud_node, symbols.annual_shoot)
        _add_hierarchy_node!(
            annual_shoot,
            context,
            symbols.growth_unit,
            scales.growth_unit;
            index=_next_child_index(annual_shoot, symbols.growth_unit),
            attributes=(
                GrowthUnitIndex=state.growth_unit_index,
                DevelopmentSiteCount=0,
                PhytomerCount=0,
                PhysiologicalAge=plan.reference_age + 1,
                BirthTime=event.time,
                SympodialTransition=plan.growth_unit_sympody.deviates,
                SympodialPlanar=plan.growth_unit_sympody.planar,
            ),
        )
    else
        node = _registered_node(context, state.growth_unit_node_id)
        isnothing(node) && throw(ArgumentError("active growth unit is absent from the MTG"))
        node
    end

    cycle_node, preformed_or_active_zone = if plan.starts_cycle
        new_cycle = _add_hierarchy_node!(
            growth_unit_node,
            context,
            symbols.growth_cycle,
            scales.growth_cycle;
            index=state.cycle_index,
            attributes=(
                CycleIndex=state.cycle_index,
                DevelopmentSiteCount=0,
                PhytomerCount=0,
                BirthTime=event.time,
                SympodialTransition=plan.cycle_sympody.deviates,
                SympodialPlanar=plan.cycle_sympody.planar,
            ),
        )
        new_zone = _add_hierarchy_node!(
            new_cycle,
            context,
            symbols.zone,
            scales.zone;
            index=1,
            attributes=(
                ZoneIndex=1,
                ZoneKind="preformed",
                DevelopmentSiteCount=0,
                PhytomerCount=0,
            ),
        )
        (new_cycle, new_zone)
    else
        cycle = _registered_node(context, state.cycle_node_id)
        zone = _registered_node(context, state.zone_node_id)
        (isnothing(cycle) || isnothing(zone)) && throw(ArgumentError(
            "active growth cycle or zone is absent from the MTG",
        ))
        (cycle, zone)
    end

    zone_node = if plan.starts_neoformed_zone
        _add_hierarchy_node!(
            cycle_node,
            context,
            symbols.zone,
            scales.zone;
            index=2,
            attributes=(
                ZoneIndex=2,
                ZoneKind="neoformed",
                DevelopmentSiteCount=0,
                PhytomerCount=0,
            ),
        )
    else
        preformed_or_active_zone
    end

    main_site = _main_development_site(site_batch)
    phytomer = if !isnothing(main_site) &&
                  main_site.outcome === RealizedDevelopmentSite
        _add_hierarchy_node!(
            zone_node,
            context,
            symbols.phytomer,
            scales.phytomer;
            index=state.phytomer_count_within_zone,
            attributes=(
                ZonePhytomerIndex=state.phytomer_count_within_zone,
                GrowthUnitPhytomerIndex=main_site.growth_unit_internode_index,
                CyclePhytomerIndex=main_site.cycle_internode_index,
                AxisPhytomerIndex=main_site.axis_internode_index,
                LegacyZoneTestIndex=main_site.zone_test_index,
                LegacyGrowthUnitTestIndex=main_site.growth_unit_test_index,
                LegacyCycleTestIndex=main_site.cycle_test_index,
                LegacyAxisTestIndex=main_site.axis_test_index,
                GrowthUnitInternodeIndex=main_site.growth_unit_internode_index,
                CycleInternodeIndex=main_site.cycle_internode_index,
                AxisInternodeIndex=main_site.axis_internode_index,
                BranchingState="undifferentiated",
                BirthTime=event.time,
            ),
        )
    else
        nothing
    end
    organ = if plan.realized && !isnothing(phytomer)
        reference_age = plan.reference_age
        length = valueat(status.amapsim_parameters.axis.geometry.initial_organ_length, reference_age)
        width = valueat(status.amapsim_parameters.axis.geometry.initial_organ_diameter, reference_age)
        parent_axis = _ancestor_with_symbol(bud_node, symbols.axis)
        first_axis_organ = state.internode_count_on_axis == 1
        phyllotaxy = first_axis_organ ? get(
            MultiScaleTreeGraph.node_attributes(parent_axis),
            :Phyllotaxy,
            nothing,
        ) : nothing
        y_insertion_angle = first_axis_organ ? get(
            MultiScaleTreeGraph.node_attributes(parent_axis),
            :YInsertionAngle,
            nothing,
        ) : nothing
        insertion_position_from_tip = first_axis_organ ? get(
            MultiScaleTreeGraph.node_attributes(parent_axis),
            :InsertionPositionFromTip,
            nothing,
        ) : nothing
        product_attributes = if isnothing(insertion_position_from_tip)
            (OrganIndex=1,)
        else
            (
                OrganIndex=1,
                InsertionPositionFromTip=insertion_position_from_tip,
            )
        end
        sympodial_boundary = if state.internode_count_within_growth_unit == 1 &&
                                state.growth_unit_index > 1
            (node=growth_unit_node, kind="growth_unit")
        elseif main_site.cycle_test_index == 1 && state.cycle_index > 1
            (node=cycle_node, kind="growth_cycle")
        else
            nothing
        end
        if !isnothing(sympodial_boundary)
            boundary_attributes = MultiScaleTreeGraph.node_attributes(
                sympodial_boundary.node,
            )
            product_attributes = merge(
                product_attributes,
                (
                    SympodialBoundary=sympodial_boundary.kind,
                    SympodialTransition=boundary_attributes[:SympodialTransition],
                    SympodialPlanar=boundary_attributes[:SympodialPlanar],
                    SympodialInitialAngle=valueat(
                        status.amapsim_parameters.axis.geometry.initial_sympodial_angle,
                        reference_age,
                    ),
                    SympodialAngle=0.0,
                ),
            )
        end
        # Keep product policy independent of botanical identity. The active
        # axis already owns the event's program and bearer provenance; copy
        # those values into the same creation transaction for every symbol.
        attributes = Dict{Symbol,Any}(
            :Length => length,
            :Width => width,
            :Thickness => width,
            :EmissionTime => event.time,
        )
        parent_axis_attributes = MultiScaleTreeGraph.node_attributes(parent_axis)
        attributes[:PhysiologicalAge] = _axis_initial_physiological_age(
            parent_axis;
            allow_legacy=false,
        )
        for name in (
            :BirthTime,
            :LateralProductionIndex,
            :WhorlSlot,
            :WhorlSize,
            :BearerPhytomerID,
            :BearerAxisID,
            :BearerAxisPhytomerIndex,
            :BearerAxisInternodeIndex,
            :BearerInternodeID,
        )
            value = get(parent_axis_attributes, name, nothing)
            (value === nothing || ismissing(value)) && continue
            attributes[name] = value
        end
        isnothing(phyllotaxy) || (attributes[:Phyllotaxy] = phyllotaxy)
        isnothing(y_insertion_angle) ||
            (attributes[:YInsertionAngle] = y_insertion_angle)
        merge!(attributes, pairs(product_attributes))
        _add_hierarchy_node!(
            phytomer,
            context,
            state.organ_symbol,
            scales.organ;
            index=1,
            link=:/,
            attributes,
        )
    else
        nothing
    end

    # Failed tests and theoretical cycle tails remain private ledger records.
    # They are numerical developmental events, not botanical phytomers.
    if !isnothing(phytomer)
        PlantSimEngine.reparent_object!(
            PlantSimEngine.runtime_model(context),
            _checked_node_id(event.bud_id),
            node_id(phytomer),
        )
        MultiScaleTreeGraph.reparent!(bud_node, phytomer)
    end
    _set_meristem_current_physiological_age!(
        bud_node,
        state.vigor.reference_age + 1,
    )
    axis_node = _ancestor_with_symbol(bud_node, symbols.axis)
    if plan.bud_died
        bud_node[:State] = "dead"
        axis_node[:State] = "dead"
    elseif plan.axis_ended
        bud_node[:State] = "ended"
        axis_node[:State] = "ended"
    end
    if state.ended
        axis_node[:TheoreticalGrowthUnitTestCount] =
            plan.theoretical_growth_unit_test_count
        axis_node[:TheoreticalGrowthUnitEndTime] =
            plan.theoretical_growth_unit_end_time
        axis_node[:TheoreticalGrowthUnitDuration] =
            plan.theoretical_growth_unit_duration
        axis_node[:ProjectedTheoreticalTestCount] = state.test_count_on_axis
    end
    axis_node[:DevelopmentSiteCount] = state.test_count_on_axis
    axis_node[:PhytomerCount] = state.internode_count_on_axis
    growth_unit_node[:DevelopmentSiteCount] = state.test_index_within_growth_unit
    growth_unit_node[:PhytomerCount] = state.internode_count_within_growth_unit
    cycle_node[:DevelopmentSiteCount] = state.test_index_within_cycle
    cycle_node[:PhytomerCount] = state.internode_count_within_cycle
    zone_node[:DevelopmentSiteCount] = Base.Checked.checked_add(
        site_batch.base_zone_test_index,
        site_batch.tail_count,
    )
    zone_node[:PhytomerCount] = state.phytomer_count_within_zone
    scene_version_node = isnothing(phytomer) ? zone_node : phytomer
    PlantGeom.bump_scene_version!(scene_version_node)
    return (;
        growth_unit_node,
        cycle_node,
        zone_node,
        phytomer,
        organ,
    )
end

function _development_site_record(
    event::BudEvent{T},
    trace_index::Int,
    axis_id::UInt64,
    growth_unit_id::UInt64,
    cycle_id::UInt64,
    zone_id::UInt64,
    site::_DevelopmentSiteSpecification;
    legacy_test_site_id::Union{Nothing,UInt64}=nothing,
    realized_object_id::Union{Nothing,UInt64}=nothing,
) where {T<:Real}
    realized = site.outcome === RealizedDevelopmentSite
    realized == !isnothing(realized_object_id) || throw(ArgumentError(
        "developmental-site outcome and realized-object identity disagree",
    ))
    return DevelopmentSiteRecord{T}(
        event.id,
        trace_index,
        event.process,
        event.bud_id,
        event.time,
        axis_id,
        growth_unit_id,
        cycle_id,
        zone_id,
        site.zone_kind,
        site.zone_test_index,
        site.growth_unit_test_index,
        site.cycle_test_index,
        site.axis_test_index,
        site.growth_unit_internode_index,
        site.cycle_internode_index,
        site.axis_internode_index,
        site.outcome,
        legacy_test_site_id,
        realized_object_id,
    )
end

function _append_development_site_records!(
    records::Vector{DevelopmentSiteRecord{T}},
    event::BudEvent{T},
    trace_index::Int,
    axis_node,
    nodes,
    site_batch::_DevelopmentSiteBatch,
) where {T<:Real}
    main_site = _main_development_site(site_batch)
    isnothing(main_site) && !isnothing(nodes.phytomer) && throw(ArgumentError(
        "a phytomer was materialized without a developmental test",
    ))
    isnothing(main_site) && !isnothing(nodes.organ) && throw(ArgumentError(
        "an organ was materialized without a developmental test",
    ))

    axis_id = UInt64(node_id(axis_node))
    growth_unit_id = UInt64(node_id(nodes.growth_unit_node))
    cycle_id = UInt64(node_id(nodes.cycle_node))
    zone_id = UInt64(node_id(nodes.zone_node))

    if !isnothing(main_site)
        realized_object_id = if main_site.outcome === RealizedDevelopmentSite
            isnothing(nodes.phytomer) && throw(ArgumentError(
                "a realized developmental test has no materialized phytomer",
            ))
            isnothing(nodes.organ) && throw(ArgumentError(
                "a realized developmental test has no materialized organ",
            ))
            UInt64(node_id(nodes.organ))
        else
            isnothing(nodes.phytomer) || throw(ArgumentError(
                "an unrealized developmental test materialized a phytomer",
            ))
            isnothing(nodes.organ) || throw(ArgumentError(
                "an unrealized developmental test materialized an organ",
            ))
            nothing
        end
        push!(
            records,
            _development_site_record(
                event,
                trace_index,
                axis_id,
                growth_unit_id,
                cycle_id,
                zone_id,
                main_site;
                legacy_test_site_id=nothing,
                realized_object_id,
            ),
        )
    end
    for tail_index in 1:site_batch.tail_count
        push!(
            records,
            _development_site_record(
                event,
                trace_index,
                axis_id,
                growth_unit_id,
                cycle_id,
                zone_id,
                _cycle_tail_development_site(site_batch, tail_index);
                legacy_test_site_id=nothing,
            ),
        )
    end
    return records
end

function _geometry_position_for_phytomer(
    phytomer,
    parent_axis,
    parameters,
    reference_age,
    scope_totals::Dict{Tuple{Int,Symbol,Bool},Int},
)
    counting_base = _truncate_parameter_integer(
        valueat(parameters.axis.topology.topology_counting_base, reference_age),
        "geometry counting base",
    )
    counting_unit = _truncate_parameter_integer(
        valueat(parameters.axis.topology.topology_counting_unit, reference_age),
        "geometry counting unit",
    )
    direction = _truncate_parameter_integer(
        valueat(
            parameters.axis.geometry.geometry_counting_direction,
            reference_age,
        ),
        "geometry counting direction",
    )
    scope_symbol, index_attribute = if iszero(counting_base)
        iszero(counting_unit) ?
        (AMAPSIM_MTG_SYMBOLS.growth_unit, :LegacyGrowthUnitTestIndex) :
        counting_unit == 1 ?
        (AMAPSIM_MTG_SYMBOLS.growth_cycle, :LegacyCycleTestIndex) :
        (AMAPSIM_MTG_SYMBOLS.axis, :LegacyAxisTestIndex)
    else
        iszero(counting_unit) ?
        (AMAPSIM_MTG_SYMBOLS.growth_unit, :GrowthUnitInternodeIndex) :
        counting_unit == 1 ?
        (AMAPSIM_MTG_SYMBOLS.growth_cycle, :CycleInternodeIndex) :
        (AMAPSIM_MTG_SYMBOLS.axis, :AxisInternodeIndex)
    end
    scope = _normalization_scope(phytomer, scope_symbol)
    effective_index_attribute = if symbol(scope) == AMAPSIM_MTG_SYMBOLS.axis &&
                                   scope_symbol != AMAPSIM_MTG_SYMBOLS.axis
        iszero(counting_base) ? :LegacyAxisTestIndex : :AxisInternodeIndex
    else
        index_attribute
    end
    current_index = _validate_development_count(
        phytomer[effective_index_attribute],
        "internode geometry position index",
    )
    current_index > 0 || throw(DomainError(
        current_index,
        "internode geometry position index must be one-based",
    ))
    counts_tests = iszero(counting_base)
    total = get!(
        scope_totals,
        (node_id(scope), effective_index_attribute, counts_tests),
    ) do
        count_attribute = counts_tests ? :DevelopmentSiteCount : :PhytomerCount
        count_value = get(
            MultiScaleTreeGraph.node_attributes(scope),
            count_attribute,
            nothing,
        )
        count_value isa Integer || throw(ArgumentError(
            "$(symbol(scope)) $(node_id(scope)) has no integer $count_attribute",
        ))
        _validate_development_count(count_value, "geometry scope count")
    end
    current_index <= total || throw(DomainError(
        current_index,
        "internode geometry position index cannot exceed its scope count",
    ))
    return iszero(direction) ? current_index - 1 : total - current_index
end

function _geometry_reference_age(node, fallback::Float64)
    growth_unit = _normalization_scope(
        node,
        AMAPSIM_MTG_SYMBOLS.growth_unit,
    )
    symbol(growth_unit) == AMAPSIM_MTG_SYMBOLS.growth_unit || return fallback
    value = get(
        MultiScaleTreeGraph.node_attributes(growth_unit),
        :PhysiologicalAge,
        nothing,
    )
    (value === nothing || ismissing(value)) && return fallback
    value isa Real && !(value isa Bool) && isfinite(value) || throw(ArgumentError(
        "growth-unit PhysiologicalAge must be a finite real number for geometry",
    ))
    value >= 1 || throw(DomainError(
        value,
        "growth-unit PhysiologicalAge must be at least one for geometry",
    ))
    return Float64(value) - 1.0
end

# Preserve preorder while visiting only the nodes owned by this axis. Nested
# axes own their whole subtrees, even when intermediate botanical levels are
# compressed. Keep this query local so topology changes need no separate cache.
function _axis_owned_nodes(axis, target::Union{Symbol,Tuple{Vararg{Symbol}}})
    target_symbols = target isa Symbol ? (target,) : target
    owned = typeof(axis)[]
    pending = typeof(axis)[axis]
    while !isempty(pending)
        node = pop!(pending)
        node !== axis && symbol(node) == AMAPSIM_MTG_SYMBOLS.axis && continue
        symbol(node) in target_symbols && push!(owned, node)
        children = MultiScaleTreeGraph.children(node)
        for i in lastindex(children):-1:firstindex(children)
            push!(pending, children[i])
        end
    end
    return owned
end

# Lateral axes are the first Axis encountered on each path through the owning
# axis's topology. Visit compressed and continuation containers, but leave each
# lateral axis's descendants to that axis. Bearer metadata is checked by callers.
function _axis_lateral_axes(axis)
    lateral_axes = typeof(axis)[]
    pending = typeof(axis)[axis]
    while !isempty(pending)
        node = pop!(pending)
        if node !== axis && symbol(node) == AMAPSIM_MTG_SYMBOLS.axis
            push!(lateral_axes, node)
            continue
        end
        children = MultiScaleTreeGraph.children(node)
        for i in lastindex(children):-1:firstindex(children)
            push!(pending, children[i])
        end
    end
    return lateral_axes
end

# Reduce in preorder, so repeated explicit indices retain the same first
# product as `argmin` on the former collected selection. Do not assume that
# tree order, node IDs or compressed-container indices encode organ rank.
function _first_axis_product(axis, product_symbol::Symbol)
    first_product = nothing
    first_index = nothing
    pending = typeof(axis)[axis]
    while !isempty(pending)
        node = pop!(pending)
        node_symbol = symbol(node)
        node !== axis && node_symbol == AMAPSIM_MTG_SYMBOLS.axis && continue
        if node_symbol == product_symbol
            product_index = get(
                MultiScaleTreeGraph.node_attributes(parent(node)),
                :AxisInternodeIndex,
                nothing,
            )
            if product_index isa Integer &&
               (first_product === nothing || isless(product_index, first_index))
                first_product = node
                first_index = product_index
            end
        end
        children = MultiScaleTreeGraph.children(node)
        for i in lastindex(children):-1:firstindex(children)
            push!(pending, children[i])
        end
    end
    return first_product
end

function _update_axis_dimensions!(
    parent_axis,
    actual_test_count::Integer,
    parameters;
    theoretical_test_count=actual_test_count,
    organ_symbol::Symbol=:Internode,
)
    actual_test_count = _validate_development_count(
        actual_test_count,
        "actual axis test count for geometry",
    )
    theoretical_test_count = _validate_development_count(
        theoretical_test_count,
        "theoretical axis test count for geometry",
    )
    theoretical_test_count >= actual_test_count || throw(DomainError(
        theoretical_test_count,
        "theoretical geometry test count cannot be smaller than the realized count",
    ))
    # These helpers already return Float64 ages and Int ranks. Keep that
    # contract visible across heterogeneous MTG attributes and dynamic calls.
    initial_reference_age = _axis_initial_reference_age(parent_axis)::Float64
    scope_totals = Dict{Tuple{Int,Symbol,Bool},Int}()
    phytomers = _axis_owned_nodes(parent_axis, AMAPSIM_MTG_SYMBOLS.phytomer)
    filter!(phytomers) do node
        axis_phytomer_index = get(
            MultiScaleTreeGraph.node_attributes(node),
            :AxisPhytomerIndex,
            nothing,
        )
        return axis_phytomer_index isa Integer
    end
    sort!(phytomers; by=node -> node[:AxisPhytomerIndex])
    for phytomer in phytomers
        if _has_abscised_leaf_product(phytomer)
            organ_symbol === AMAPSIM_MTG_SYMBOLS.leaf || throw(ArgumentError(
                "an abscised Leaf Phytomer cannot stand in for a $organ_symbol product",
            ))
            continue
        end
        organ = only(
            child for child in MultiScaleTreeGraph.children(phytomer)
            if symbol(child) == organ_symbol &&
               scale(child) == AMAPSIM_MTG_SCALES.organ
        )
        reference_age = _geometry_reference_age(
            phytomer,
            initial_reference_age,
        )::Float64
        topology_position = _geometry_position_for_phytomer(
            phytomer,
            parent_axis,
            parameters,
            reference_age,
            scope_totals,
        )::Int
        index_from_end = Base.Checked.checked_sub(
            theoretical_test_count,
            _validate_development_count(
                phytomer[:LegacyAxisTestIndex],
                "axis test index for organ geometry",
            ),
        )::Int
        dimensions = internode_dimensions(
            parameters,
            initial_reference_age,
            reference_age,
            topology_position,
            index_from_end,
        )
        PlantGeom.set_growth_attributes!(
            organ,
            (
                Length=dimensions.length,
                Width=dimensions.diameter,
                Thickness=dimensions.diameter,
                GeometryPosition=topology_position,
                IndexFromTheoreticalEnd=index_from_end,
            );
            bump_scene=false,
        )
        organ_attributes = MultiScaleTreeGraph.node_attributes(organ)
        stored_primary_diameter = get(
            organ_attributes,
            :PrimaryGrowthDiameter,
            nothing,
        )
        if stored_primary_diameter !== nothing &&
           !ismissing(stored_primary_diameter)
            organ_attributes[:PrimaryGrowthDiameter] = dimensions.diameter
        end
        sympodial_boundary = get(
            organ_attributes,
            :SympodialBoundary,
            nothing,
        )
        if sympodial_boundary isa AbstractString
            transition = get(
                organ_attributes,
                :SympodialTransition,
                false,
            ) === true
            angle = transition ?
                    sympodial_angle(parameters, reference_age, index_from_end) :
                    0.0
            PlantGeom.set_growth_attributes!(
                organ,
                (SympodialAngle=angle,);
                bump_scene=false,
            )
        end
    end
    updated_child_count = _update_lateral_insertion_angles!(parent_axis, parameters)
    (!isempty(phytomers) || updated_child_count > 0) &&
        PlantGeom.bump_scene_version!(parent_axis)
    return nothing
end

function _refresh_ended_axis_geometry!(status, output_time, context)
    hasproperty(status, :amapsim_parameters) || return false
    hasproperty(status, :bud_states) || return false
    parameters = status.amapsim_parameters
    parameters isa AMAPSimParameters || return false
    changed = false
    for (bud_id, state) in status.bud_states
        state.ended || continue
        bud_node = _registered_node(context, bud_id)
        bud_node === nothing && continue
        axis = _ancestor_with_symbol(bud_node, AMAPSIM_MTG_SYMBOLS.axis)
        attributes = MultiScaleTreeGraph.node_attributes(axis)
        growth_unit_test_count = get(
            attributes,
            :TheoreticalGrowthUnitTestCount,
            nothing,
        )
        growth_unit_end_time = get(
            attributes,
            :TheoreticalGrowthUnitEndTime,
            nothing,
        )
        growth_unit_duration = get(
            attributes,
            :TheoreticalGrowthUnitDuration,
            nothing,
        )
        growth_unit_test_count === nothing && continue
        growth_unit_end_time === nothing && continue
        growth_unit_duration === nothing && continue
        growth_unit_test_count isa Integer || throw(ArgumentError(
            "TheoreticalGrowthUnitTestCount must be an integer",
        ))
        growth_unit_end_time isa Real || throw(ArgumentError(
            "TheoreticalGrowthUnitEndTime must be real",
        ))
        growth_unit_duration isa Real || throw(ArgumentError(
            "TheoreticalGrowthUnitDuration must be real",
        ))
        projected_test_count = projected_axis_test_count(
            state.test_count_on_axis,
            growth_unit_test_count,
            growth_unit_end_time,
            output_time,
            growth_unit_duration,
        )
        previous_test_count = get(
            attributes,
            :ProjectedTheoreticalTestCount,
            state.test_count_on_axis,
        )
        previous_test_count isa Integer || throw(ArgumentError(
            "ProjectedTheoreticalTestCount must be an integer",
        ))
        projected_test_count == previous_test_count && continue
        _update_axis_dimensions!(
            axis,
            state.test_count_on_axis,
            parameters;
            theoretical_test_count=projected_test_count,
            organ_symbol=state.organ_symbol,
        )
        axis[:ProjectedTheoreticalTestCount] = projected_test_count
        changed = true
    end
    return changed
end

function _branch_phyllotaxy(
    parameters,
    bearer_axis,
    bearer_phytomer,
    lateral_index,
    slot,
    slot_count,
)
    lateral = parameters.lateral_productions[lateral_index]
    bearer_index = _validate_development_count(
        bearer_phytomer[:AxisInternodeIndex],
        "bearer axis internode index for phyllotaxy",
    )
    previous_sites = _axis_owned_nodes(bearer_axis, AMAPSIM_MTG_SYMBOLS.phytomer)
    filter!(previous_sites) do node
        axis_internode_index = get(
            MultiScaleTreeGraph.node_attributes(node),
            :AxisInternodeIndex,
            nothing,
        )
        axis_internode_index isa Integer || return false
        return axis_internode_index < bearer_index
    end
    sort!(previous_sites; by=node -> node[:AxisInternodeIndex])
    current_phyllotaxy = 0.0
    fallback_physiological_age = _axis_initial_physiological_age(
        bearer_axis;
        allow_legacy=false,
    )
    for phytomer in previous_sites
        growth_unit = _normalization_scope(
            phytomer,
            AMAPSIM_MTG_SYMBOLS.growth_unit,
        )
        physiological_age = if symbol(growth_unit) ==
                               AMAPSIM_MTG_SYMBOLS.growth_unit
            growth_unit[:PhysiologicalAge]
        else
            fallback_physiological_age
        end
        current_phyllotaxy = advance_phyllotaxy(
            current_phyllotaxy,
            lateral,
            physiological_age,
        )
    end
    bearer_reference_age = _geometry_reference_age(
        bearer_phytomer,
        Float64(fallback_physiological_age) - 1.0,
    )
    initial_angle = get(
        MultiScaleTreeGraph.node_attributes(bearer_axis),
        :InitialPhyllotaxyAngle,
        0.0,
    )
    return branch_azimuth(
        current_phyllotaxy,
        lateral,
        bearer_reference_age,
        slot,
        slot_count;
        initial_angle,
    )
end

function _update_lateral_insertion_angles!(bearer_axis, parameters)
    growth_units = _axis_owned_nodes(bearer_axis, AMAPSIM_MTG_SYMBOLS.growth_unit)
    filter!(growth_units) do node
        physiological_age = get(
            MultiScaleTreeGraph.node_attributes(node),
            :PhysiologicalAge,
            nothing,
        )
        return physiological_age isa Real
    end
    total_growth_units = length(growth_units)
    child_axes = _axis_lateral_axes(bearer_axis)
    bearer_axis_id = node_id(bearer_axis)
    filter!(child_axes) do node
        return get(
            MultiScaleTreeGraph.node_attributes(node),
            :BearerAxisID,
            nothing,
        ) == bearer_axis_id
    end
    sort!(child_axes; by=node_id)
    for child_axis in child_axes
        bearer_phytomer = parent(child_axis)
        bearer_growth_unit = _normalization_scope(
            bearer_phytomer,
            AMAPSIM_MTG_SYMBOLS.growth_unit,
        )
        scope_count, growth_unit_index = if symbol(bearer_growth_unit) ==
                                           AMAPSIM_MTG_SYMBOLS.growth_unit
            (
                total_growth_units,
                _validate_development_count(
                    bearer_growth_unit[:GrowthUnitIndex],
                    "bearer growth-unit index for insertion angle",
                ),
            )
        else
            (1, 1)
        end
        growth_unit_index > 0 || throw(DomainError(
            growth_unit_index,
            "bearer growth-unit index must be one-based",
        ))
        position_from_tip = (scope_count - (growth_unit_index - 1) - 2)::Int
        get(
            MultiScaleTreeGraph.node_attributes(child_axis),
            :BranchingType,
            nothing,
        ) == "immediate" && (position_from_tip += 1)
        angle = branch_insertion_angle(
            parameters,
            _axis_initial_reference_age(child_axis)::Float64,
            position_from_tip,
        )
        PlantGeom.set_growth_attributes!(
            child_axis,
            (YInsertionAngle=angle, InsertionPositionFromTip=position_from_tip);
            bump_scene=false,
        )
        child_axis_attributes = MultiScaleTreeGraph.node_attributes(child_axis)
        lateral_index_value = get(
            child_axis_attributes,
            :LateralProductionIndex,
            nothing,
        )
        product_symbol = if lateral_index_value === nothing ||
                            ismissing(lateral_index_value)
            AMAPSIM_MTG_SYMBOLS.internode
        else
            lateral_index = _validate_development_count(
                lateral_index_value,
                "lateral-production index for insertion angle",
            )
            1 <= lateral_index <= length(parameters.lateral_productions) ||
                throw(BoundsError(parameters.lateral_productions, lateral_index))
            parameters.lateral_productions[lateral_index].organ_symbol
        end
        first_product = _first_axis_product(child_axis, product_symbol)
        if first_product !== nothing
            PlantGeom.set_growth_attributes!(
                first_product,
                (
                    YInsertionAngle=angle,
                    InsertionPositionFromTip=position_from_tip,
                );
                bump_scene=false,
            )
        end
    end
    return length(child_axes)
end

function _topology_scope_internode_count(state, parameters, reference_age)
    counting_unit = _truncate_parameter_integer(
        valueat(parameters.axis.topology.topology_counting_unit, reference_age),
        "topology counting unit",
    )
    return iszero(counting_unit) ? state.internode_count_within_growth_unit :
           counting_unit == 1 ? state.internode_count_within_cycle :
           state.internode_count_on_axis
end

function _surviving_branching_state(bearer_phytomer; excluding=nothing)
    current_state = get(
        MultiScaleTreeGraph.node_attributes(bearer_phytomer),
        :BranchingState,
        nothing,
    )
    selected_type = nothing
    selected_key = (typemax(Int), typemax(Int), typemax(Int))
    for child in MultiScaleTreeGraph.children(bearer_phytomer)
        child === excluding && continue
        symbol(child) == AMAPSIM_MTG_SYMBOLS.axis || continue
        attributes = MultiScaleTreeGraph.node_attributes(child)
        branching_type = get(attributes, :BranchingType, nothing)
        branching_type isa AbstractString || throw(ArgumentError(
            "lateral Axis $(node_id(child)) requires a string BranchingType",
        ))
        current_state isa AbstractString && branching_type == current_state &&
            return String(current_state)
        lateral_index = get(attributes, :LateralProductionIndex, typemax(Int))
        whorl_slot = get(attributes, :WhorlSlot, typemax(Int))
        lateral_index = lateral_index isa Integer ? Int(lateral_index) : typemax(Int)
        whorl_slot = whorl_slot isa Integer ? Int(whorl_slot) : typemax(Int)
        key = (lateral_index, whorl_slot, node_id(child))
        if key < selected_key
            selected_key = key
            selected_type = String(branching_type)
        end
    end
    return isnothing(selected_type) ? "undifferentiated" : selected_type
end

function _remove_axis_subtree!(
    status,
    axis,
    context;
    current_event_id::Union{Nothing,EventID}=nothing,
)
    subtree = traverse(axis, identity)
    removed_axis_ids = sort!(Int[
        node_id(node) for node in subtree
        if symbol(node) == AMAPSIM_MTG_SYMBOLS.axis
    ])
    removed_phytomer_ids = sort!(UInt64[
        UInt64(node_id(node)) for node in subtree
        if symbol(node) == AMAPSIM_MTG_SYMBOLS.phytomer
    ])
    bud_ids = sort!(UInt64[
        UInt64(node_id(node)) for node in subtree
        if symbol(node) == AMAPSIM_MTG_SYMBOLS.bud
    ])
    bud_id_set = Set(bud_ids)
    event_ids = sort!(
        EventID[
            id for (id, event) in status.event_queue.events
            if event.bud_id in bud_id_set && id != current_event_id
        ];
        by=id -> id.value,
    )
    axis_id = node_id(axis)
    bearer = parent(axis)
    surviving_branching_state =
        symbol(bearer) == AMAPSIM_MTG_SYMBOLS.phytomer ?
        _surviving_branching_state(bearer; excluding=axis) : nothing
    PlantSimEngine.remove_object!(
        PlantSimEngine.runtime_model(context),
        axis_id,
    )
    for event_id in event_ids
        cancel_event!(status.event_queue, event_id)
    end
    for bud_id in bud_ids
        delete!(status.bud_states, bud_id)
    end
    for phytomer_id in removed_phytomer_ids
        delete!(status.branching_site_states, phytomer_id)
    end
    MultiScaleTreeGraph.prune!(axis)
    if symbol(bearer) == AMAPSIM_MTG_SYMBOLS.phytomer
        bearer[:BranchingState] = surviving_branching_state
    end
    return (;
        axis_id,
        removed_axis_ids,
        removed_phytomer_ids,
        bud_ids,
        cancelled_event_count=length(event_ids),
    )
end

function _prune_immediate_branch!(status, axis, context)
    return _remove_axis_subtree!(status, axis, context)
end

function _axis_growth_units(axis)
    growth_units = filter(traverse(axis, identity)) do node
        symbol(node) == AMAPSIM_MTG_SYMBOLS.growth_unit || return false
        _ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis) === axis || return false
        attributes = MultiScaleTreeGraph.node_attributes(node)
        get(attributes, :PhysiologicalAge, nothing) isa Real || return false
        return get(attributes, :GrowthUnitIndex, nothing) isa Integer
    end
    sort!(growth_units; by=node -> (node[:GrowthUnitIndex], node_id(node)))
    return growth_units
end

function _pruning_reference_age(axis)
    growth_units = _axis_growth_units(axis)
    isempty(growth_units) && return nothing
    physiological_age = Float64(first(growth_units)[:PhysiologicalAge])
    isfinite(physiological_age) || throw(ArgumentError(
        "first growth-unit physiological age must be finite for pruning",
    ))
    return max(physiological_age - 1, 0.0)
end

const LEGACY_AXIS_END_PRUNING_EPSILON = 2.0e-6

function _plan_initial_pruning(
    parameters,
    axis,
    event::BudEvent{T},
    plan,
) where {T<:Real}
    reference_age = _pruning_reference_age(axis)
    isnothing(reference_age) && return nothing

    (plan.bud_died || plan.axis_ended) || return nothing
    function legacy_lag(parameter)
        value = valueat(parameter, reference_age)
        isfinite(value) || throw(ArgumentError("pruning lag must be finite"))
        value >= 0 || throw(DomainError(value, "pruning lag cannot be negative"))
        lag = Float32(value)
        isfinite(lag) || throw(ArgumentError("pruning lag must fit in Float32"))
        return lag
    end
    # Bud.cpp:152-188 stores both delays and the clock in float. The inactive
    # delay remains9999; end lag and epsilon are rounded before the float sum.
    death_delay = plan.bud_died ? legacy_lag(
        parameters.axis.topology.pruning_lag_after_axis_death,
    ) : 9999.0f0
    end_delay = plan.axis_ended ? legacy_lag(
        parameters.axis.topology.pruning_lag_after_axis_end,
    ) + Float32(LEGACY_AXIS_END_PRUNING_EPSILON) : 9999.0f0

    coefficient = Float64(valueat(
        parameters.axis.topology.progressive_pruning_coefficient,
        reference_age,
    ))
    isfinite(coefficient) || throw(ArgumentError(
        "progressive pruning coefficient must be finite",
    ))
    coefficient >= 0 || throw(DomainError(
        coefficient,
        "progressive pruning coefficient cannot be negative",
    ))

    clock = Float32(event.time)
    isfinite(clock) || throw(ArgumentError("pruning clock must fit in Float32"))
    delay = end_delay < death_delay ? end_delay : death_delay
    total_time = convert(T, clock + delay)
    isfinite(total_time) || throw(ArgumentError("total pruning time must be finite"))
    # A zero lag can round below the double event clock. Keep the source's
    # value: the ordinary legacy queue permits this bounded retrograde event.
    progressive_time = event.time + one(T)
    isfinite(progressive_time) || throw(ArgumentError(
        "progressive pruning time must be finite",
    ))
    process = coefficient > 0 && progressive_time < total_time ?
              :progressive_pruning : :total_pruning
    time = process == :progressive_pruning ? progressive_time : total_time
    return (; process, time, reference_age, coefficient)
end

function _last_axis_phytomer_outside(axis, excluded_subtree)
    excluded_ids = Set(node_id(node) for node in traverse(excluded_subtree, identity))
    phytomers = filter(traverse(axis, identity)) do node
        node_id(node) in excluded_ids && return false
        symbol(node) == AMAPSIM_MTG_SYMBOLS.phytomer || return false
        return _ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis) === axis
    end
    if !isempty(phytomers)
        return argmax(phytomers) do phytomer
            rank = _validate_development_count(
                get(
                    MultiScaleTreeGraph.node_attributes(phytomer),
                    :AxisPhytomerIndex,
                    nothing,
                ),
                "surviving axis phytomer rank",
            )
            rank > 0 || throw(DomainError(
                rank,
                "surviving axis phytomer rank must be one-based",
            ))
            return (rank, node_id(phytomer))
        end
    end
    bearer_id = get(
        MultiScaleTreeGraph.node_attributes(axis),
        :InitializationBearerID,
        nothing,
    )
    bearer_id isa Integer || throw(ArgumentError(
        "axis $(node_id(axis)) has neither a surviving phytomer nor an initialization bearer",
    ))
    bearer = MultiScaleTreeGraph.get_node(
        MultiScaleTreeGraph.get_root(axis),
        Int(bearer_id),
    )
    isnothing(bearer) && throw(ArgumentError(
        "axis $(node_id(axis)) initialization bearer $bearer_id is absent",
    ))
    node_id(bearer) in excluded_ids && throw(ArgumentError(
        "axis $(node_id(axis)) initialization bearer belongs to the pruned subtree",
    ))
    return bearer
end

function _axis_development_counts(axis, excluded_subtree=nothing)
    excluded_ids = isnothing(excluded_subtree) ? Set{Int}() :
                   Set(node_id(node) for node in traverse(excluded_subtree, identity))
    development_site_count = 0
    phytomer_count = 0
    for node in traverse(axis, identity)
        node === axis && continue
        node_id(node) in excluded_ids && continue
        _ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis) === axis || continue
        node_symbol = symbol(node)
        if node_symbol == AMAPSIM_MTG_SYMBOLS.phytomer
            phytomer_count = Base.Checked.checked_add(phytomer_count, 1)
        elseif node_symbol == AMAPSIM_MTG_SYMBOLS.zone
            zone_count = get(
                MultiScaleTreeGraph.node_attributes(node),
                :DevelopmentSiteCount,
                nothing,
            )
            zone_count isa Integer || throw(ArgumentError(
                "Zone $(node_id(node)) requires an integer DevelopmentSiteCount before pruning",
            ))
            development_site_count = Base.Checked.checked_add(
                development_site_count,
                _validate_development_count(
                    zone_count,
                    "zone developmental-site count before pruning",
                ),
            )
        end
    end
    return (; development_site_count, phytomer_count)
end

function _refresh_axis_development_counts!(axis, counts)
    axis[:DevelopmentSiteCount] = counts.development_site_count
    axis[:PhytomerCount] = counts.phytomer_count
    return axis
end

function _remove_terminal_growth_unit!(status, axis, bud_node, context)
    growth_units = _axis_growth_units(axis)
    isempty(growth_units) && throw(ArgumentError(
        "progressive pruning requires a terminal growth unit",
    ))
    terminal = last(growth_units)
    subtree = traverse(terminal, identity)
    removed_axis_ids = sort!(Int[
        node_id(node) for node in subtree
        if symbol(node) == AMAPSIM_MTG_SYMBOLS.axis
    ])
    removed_bud_ids = sort!(UInt64[
        UInt64(node_id(node)) for node in subtree
        if symbol(node) == AMAPSIM_MTG_SYMBOLS.bud && node !== bud_node
    ])
    removed_phytomer_ids = sort!(UInt64[
        UInt64(node_id(node)) for node in subtree
        if symbol(node) == AMAPSIM_MTG_SYMBOLS.phytomer
    ])
    removed_bud_id_set = Set(removed_bud_ids)
    event_ids = sort!(EventID[
        id for (id, queued) in status.event_queue.events
        if queued.bud_id in removed_bud_id_set
    ]; by=id -> id.value)
    new_parent = _last_axis_phytomer_outside(axis, terminal)
    surviving_counts = _axis_development_counts(axis, terminal)

    PlantSimEngine.reparent_object!(
        PlantSimEngine.runtime_model(context),
        node_id(bud_node),
        node_id(new_parent),
    )
    MultiScaleTreeGraph.reparent!(bud_node, new_parent)
    PlantSimEngine.remove_object!(
        PlantSimEngine.runtime_model(context),
        node_id(terminal),
    )
    for event_id in event_ids
        cancel_event!(status.event_queue, event_id)
    end
    for bud_id in removed_bud_ids
        delete!(status.bud_states, bud_id)
    end
    for phytomer_id in removed_phytomer_ids
        delete!(status.branching_site_states, phytomer_id)
    end
    MultiScaleTreeGraph.prune!(terminal)
    _refresh_axis_development_counts!(axis, surviving_counts)
    PlantGeom.bump_scene_version!(axis)
    return (;
        growth_unit_id=node_id(terminal),
        removed_axis_ids,
        removed_phytomer_ids,
        removed_bud_ids,
        cancelled_event_count=length(event_ids),
    )
end

function _cleanup_floating_immediate_branches!(
    status,
    parent_axis,
    state,
    plan,
    context,
)
    isempty(plan.floating_cleanup_lateral_indices) && return (;
        axis_ids=Int[],
        bud_ids=UInt64[],
        phytomer_ids=UInt64[],
        cancelled_event_count=0,
    )
    parameters = status.amapsim_parameters
    scope_count = _topology_scope_internode_count(
        state,
        parameters,
        plan.reference_age,
    )
    parent_axis_id = node_id(parent_axis)
    candidates = Any[]
    for axis in _axis_lateral_axes(parent_axis)
        attributes = MultiScaleTreeGraph.node_attributes(axis)
        get(attributes, :BearerAxisID, nothing) == parent_axis_id || continue
        lateral_index = get(attributes, :LateralProductionIndex, nothing)
        lateral_index in plan.floating_cleanup_lateral_indices || continue
        bearer_index = get(attributes, :BearerAxisInternodeIndex, nothing)
        isnothing(bearer_index) && throw(ArgumentError(
            "lateral Axis $(node_id(axis)) has no bearer internode index",
        ))
        production_end = valueat(
            parameters.lateral_productions[lateral_index].global_parameters.production_end,
            plan.reference_age,
        )
        is_outside_apical_production_window(
            state.internode_count_on_axis,
            scope_count,
            bearer_index,
            production_end,
        ) && push!(candidates, axis)
    end
    sort!(candidates; by=node_id)
    removed_axis_ids = Int[]
    removed_bud_ids = UInt64[]
    removed_phytomer_ids = UInt64[]
    cancelled_event_count = 0
    for axis in candidates
        removed = _prune_immediate_branch!(status, axis, context)
        push!(removed_axis_ids, removed.axis_id)
        append!(removed_bud_ids, removed.bud_ids)
        append!(removed_phytomer_ids, removed.removed_phytomer_ids)
        cancelled_event_count += removed.cancelled_event_count
    end
    !isempty(candidates) && PlantGeom.bump_scene_version!(parent_axis)
    return (;
        axis_ids=removed_axis_ids,
        bud_ids=removed_bud_ids,
        phytomer_ids=removed_phytomer_ids,
        cancelled_event_count,
    )
end

function _branching_position_for_phytomer(
    phytomer,
    state,
    parameters,
    reference_age,
    direction,
    ;
    counting_unit_override=nothing,
)
    counting_base = _truncate_parameter_integer(
        valueat(parameters.axis.topology.topology_counting_base, reference_age),
        "topology counting base",
    )
    counting_unit = isnothing(counting_unit_override) ?
                    _truncate_parameter_integer(
        valueat(parameters.axis.topology.topology_counting_unit, reference_age),
        "topology counting unit",
    ) : _truncate_parameter_integer(
        counting_unit_override,
        "overridden topology counting unit",
    )
    attribute, total = if iszero(counting_base)
        iszero(counting_unit) ?
        (:LegacyGrowthUnitTestIndex, state.test_index_within_growth_unit) :
        counting_unit == 1 ?
        (:LegacyCycleTestIndex, state.test_index_within_cycle) :
        (:LegacyAxisTestIndex, state.test_count_on_axis)
    else
        iszero(counting_unit) ?
        (:GrowthUnitInternodeIndex, state.internode_count_within_growth_unit) :
        counting_unit == 1 ?
        (:CycleInternodeIndex, state.internode_count_within_cycle) :
        (:AxisInternodeIndex, state.internode_count_on_axis)
    end
    haskey(phytomer, attribute) || throw(ArgumentError(
        "phytomer $(node_id(phytomer)) has no $attribute branching index",
    ))
    current_index = _validate_development_count(
        phytomer[attribute],
        "phytomer branching index",
    )
    current_index > 0 || throw(DomainError(
        current_index,
        "phytomer branching index must be one-based",
    ))
    total = _validate_development_count(total, "branching topology-scope count")
    current_index <= total || throw(DomainError(
        current_index,
        "phytomer branching index cannot exceed its topology-scope count",
    ))
    return iszero(direction) ? current_index - 1 : total - current_index
end

function _branching_position_for_existing_phytomer(
    phytomer,
    parameters,
    reference_age,
    direction,
    ;
    counting_unit_override=nothing,
)
    counting_base = _truncate_parameter_integer(
        valueat(parameters.axis.topology.topology_counting_base, reference_age),
        "topology counting base",
    )
    counting_unit = isnothing(counting_unit_override) ?
                    _truncate_parameter_integer(
        valueat(parameters.axis.topology.topology_counting_unit, reference_age),
        "topology counting unit",
    ) : _truncate_parameter_integer(
        counting_unit_override,
        "overridden topology counting unit",
    )
    scope_symbol, attribute = if iszero(counting_base)
        iszero(counting_unit) ?
        (AMAPSIM_MTG_SYMBOLS.growth_unit, :LegacyGrowthUnitTestIndex) :
        counting_unit == 1 ?
        (AMAPSIM_MTG_SYMBOLS.growth_cycle, :LegacyCycleTestIndex) :
        (AMAPSIM_MTG_SYMBOLS.axis, :LegacyAxisTestIndex)
    else
        iszero(counting_unit) ?
        (AMAPSIM_MTG_SYMBOLS.growth_unit, :GrowthUnitInternodeIndex) :
        counting_unit == 1 ?
        (AMAPSIM_MTG_SYMBOLS.growth_cycle, :CycleInternodeIndex) :
        (AMAPSIM_MTG_SYMBOLS.axis, :AxisInternodeIndex)
    end
    scope = _normalization_scope(phytomer, scope_symbol)
    if symbol(scope) == AMAPSIM_MTG_SYMBOLS.axis &&
       scope_symbol != AMAPSIM_MTG_SYMBOLS.axis
        attribute = iszero(counting_base) ?
                    :LegacyAxisTestIndex :
                    :AxisInternodeIndex
    end
    current_index = _validate_development_count(
        phytomer[attribute],
        "physical-neighbor branching index",
    )
    count_attribute = iszero(counting_base) ?
                      :DevelopmentSiteCount :
                      :PhytomerCount
    total = _validate_development_count(
        scope[count_attribute],
        "physical-neighbor branching scope count",
    )
    current_index > 0 || throw(DomainError(
        current_index,
        "physical-neighbor branching index must be one-based",
    ))
    current_index <= total || throw(DomainError(
        current_index,
        "physical-neighbor branching index cannot exceed its scope count",
    ))
    return iszero(direction) ? current_index - 1 : total - current_index
end

function _adjacent_axis_phytomer(parent_axis, phytomer, direction)
    current_index = _validate_development_count(
        phytomer[:AxisInternodeIndex],
        "current physical branching-site index",
    )
    adjacent_index = iszero(direction) ? current_index - 1 : current_index + 1
    adjacent_index > 0 || return nothing
    pending = typeof(parent_axis)[parent_axis]
    while !isempty(pending)
        candidate = pop!(pending)
        candidate !== parent_axis &&
            symbol(candidate) == AMAPSIM_MTG_SYMBOLS.axis && continue
        if symbol(candidate) == AMAPSIM_MTG_SYMBOLS.phytomer &&
           get(
               MultiScaleTreeGraph.node_attributes(candidate),
               :AxisInternodeIndex,
               nothing,
           ) == adjacent_index
            return candidate
        end
        children = MultiScaleTreeGraph.children(candidate)
        for i in lastindex(children):-1:firstindex(children)
            push!(pending, children[i])
        end
    end
    return nothing
end

function _physical_branching_site(
    parent_axis,
    phytomer,
    parameters,
    global_parameters,
    reference_age,
    direction,
    lateral,
    ;
    counting_unit_override=nothing,
)
    previous_phytomer = _adjacent_axis_phytomer(parent_axis, phytomer, direction)
    previous_phytomer === nothing && return nothing
    previous_reference_age = _geometry_reference_age(
        previous_phytomer,
        Float64(reference_age),
    )
    previous_direction = _truncate_parameter_integer(
        valueat(
            global_parameters.delayed_branch_counting_direction,
            previous_reference_age,
        ),
        "previous physical-site branching direction",
    )
    previous_position = _branching_position_for_existing_phytomer(
        previous_phytomer,
        parameters,
        previous_reference_age,
        previous_direction,
        ;
        counting_unit_override,
    )
    previous_zone_index = _truncate_parameter_integer(
        _ancestor_with_symbol(
            previous_phytomer,
            AMAPSIM_MTG_SYMBOLS.zone,
        )[:ZoneIndex],
        "previous physical-site lateral-production zone index",
    )
    1 <= previous_zone_index <= length(lateral.zones) ||
        throw(BoundsError(lateral.zones, previous_zone_index))
    return (;
        phytomer=previous_phytomer,
        position=previous_position,
        zone_index=previous_zone_index,
        branching=_lateral_production_zone_branching(lateral, previous_zone_index),
    )
end

function _initial_markov_scan_state(
    state::ApicalBudState,
    parameters,
    parent_axis,
    first_phytomer,
    reference_age,
    direction,
    branching_site_states,
    lateral_index,
    lateral_count,
)
    counting_unit = _truncate_parameter_integer(
        valueat(
            parameters.axis.topology.topology_counting_unit,
            reference_age + 1,
        ),
        "topology counting unit",
    )
    iszero(direction) || return BranchingSiteUndefined
    test_index_attribute = iszero(counting_unit) ?
                           :LegacyGrowthUnitTestIndex :
                           counting_unit == 1 ?
                           :LegacyCycleTestIndex :
                           :LegacyAxisTestIndex
    first_test_index = _validate_development_count(
        first_phytomer[test_index_attribute],
        "first branching-scan topology test index",
    )
    first_test_index == 1 && return BranchingSiteUndefined
    state.legacy_branching_states[lateral_index] != BranchingSiteUndefined ||
        return BranchingSiteUndefined
    previous_phytomer = _adjacent_axis_phytomer(
        parent_axis,
        first_phytomer,
        direction,
    )
    previous_phytomer === nothing && return BranchingSiteUndefined
    return _branching_site_state(
        branching_site_states,
        previous_phytomer,
        lateral_index,
        lateral_count,
    )
end

function _delayed_semimarkov_state_from_branching_site(
    state::LegacyBranchingSiteState,
)
    state == BranchingSiteUnbranched && return DelayedUnbranched
    state == BranchingSiteDelayedType1 && return DelayedType1
    state == BranchingSiteDelayedType2 && return DelayedType2
    return nothing
end

function _traumatic_semimarkov_seed(state::LegacyBranchingSiteState)
    return state in (
        BranchingSiteImmediate,
        BranchingSiteTraumatic,
        BranchingSiteCycleDelayed,
    )
end

function _delayed_initial_probability(
    branching,
    reference_age,
    position,
    state::LegacyBranchingSiteState,
)
    if state in (
        BranchingSiteUnbranched,
        BranchingSiteImmediateUnbranched,
        BranchingSiteCycleDelayedUnbranched,
        BranchingSiteTraumaticUnbranched,
    )
        return _validate_probability(valueat(
            branching.delayed_initial_state_0_probability,
            reference_age,
            position,
        ))
    elseif state in (
        BranchingSiteImmediate,
        BranchingSiteDelayedType1,
        BranchingSiteTraumatic,
        BranchingSiteCycleDelayed,
    )
        return _validate_probability(valueat(
            branching.delayed_initial_state_1_probability,
            reference_age,
            position,
        ))
    elseif state == BranchingSiteDelayedType2
        p0 = _validate_probability(valueat(
            branching.delayed_initial_state_0_probability,
            reference_age,
            position,
        ))
        p1 = _validate_probability(valueat(
            branching.delayed_initial_state_1_probability,
            reference_age,
            position,
        ))
        return 1 - p0 - p1
    end
    return nothing
end

function _delayed_markov_scan_counting_unit(
    phytomer,
    state,
    parameters,
    lateral,
    zone,
    reference_age,
)
    configured_counting_unit = _truncate_parameter_integer(
        valueat(parameters.axis.topology.topology_counting_unit, reference_age),
        "topology counting unit",
    )
    initialization_direction = _truncate_parameter_integer(
        valueat(
            lateral.global_parameters.delayed_branch_strength_direction,
            reference_age,
        ),
        "delayed branch initialization direction",
    )
    initialization_position = _branching_position_for_phytomer(
        phytomer,
        state,
        parameters,
        reference_age,
        initialization_direction;
        counting_unit_override=configured_counting_unit,
    )
    minimum_jump = _truncate_parameter_integer(
        valueat(
            zone.branching.delayed_type_1_minimum_jump,
            reference_age,
            initialization_position,
        ),
        "delayed type-1 minimum jump",
    )
    return iszero(minimum_jump) ? 0 : configured_counting_unit
end

function _delayed_branching_state_label(state::DelayedBranchState)
    state == DelayedUnbranched && return "delayed_unbranched"
    state == DelayedType1 && return "delayed_type_1"
    return "delayed_type_2"
end

function _phytomer_has_lateral_axis(phytomer, lateral_index)
    return any(MultiScaleTreeGraph.children(phytomer)) do child
        symbol(child) == AMAPSIM_MTG_SYMBOLS.axis || return false
        existing_index = get(
            MultiScaleTreeGraph.node_attributes(child),
            :LateralProductionIndex,
            nothing,
        )
        return isnothing(existing_index) || existing_index == lateral_index
    end
end

function _axis_initial_reference_age(parent_axis)
    initial_physiological_age = Float64(
        _axis_initial_physiological_age(parent_axis; allow_legacy=false),
    )
    return max(initial_physiological_age - 1, 0.0)
end

function _axis_reiteration_context(parent_axis)
    attributes = MultiScaleTreeGraph.node_attributes(parent_axis)
    parent_order = _validate_development_count(
        get(attributes, :ReiterationOrder, 0),
        "parent reiteration order",
    )
    initial_reference_age = _axis_initial_reference_age(parent_axis)
    return (; parent_order, initial_reference_age)
end

function _child_reiteration_order(
    parameters,
    parent_axis,
    bearer_reference_age,
    child_physiological_age,
)
    context = _axis_reiteration_context(parent_axis)
    return reiteration_order(
        parameters.axis.topology,
        context.initial_reference_age,
        bearer_reference_age,
        child_physiological_age,
        context.parent_order,
    )
end

@inline function _require_internode_bearer_product(
    phytomer,
    branching_label::AbstractString,
)
    product = nothing
    for child in MultiScaleTreeGraph.children(phytomer)
        child_symbol = symbol(child)
        child_symbol in (
            AMAPSIM_MTG_SYMBOLS.bud,
            AMAPSIM_MTG_SYMBOLS.axis,
        ) && continue
        product === nothing || throw(ArgumentError(
            "$branching_label branching requires Phytomer " *
            "$(node_id(phytomer)) to contain exactly one direct botanical product",
        ))
        product = child
    end
    product === nothing && throw(ArgumentError(
        "$branching_label branching requires Phytomer $(node_id(phytomer)) " *
        "to contain exactly one direct botanical product",
    ))
    product_symbol = symbol(product)
    product_symbol == AMAPSIM_MTG_SYMBOLS.internode || throw(ArgumentError(
        "$branching_label branching requires the bearer product of Phytomer " *
        "$(node_id(phytomer)) to be an Internode; got $(repr(product_symbol))",
    ))
    return product
end

function _plan_delayed_branches!(
    state::ApicalBudState{T},
    rng,
    parameters,
    growth_unit_node,
    parent_axis,
    plan,
    parent_order,
    status,
    environment,
    branching_site_states;
    lateral_index=nothing,
) where {T<:Real}
    plan.growth_unit_ended || return NamedTuple[]
    phytomers = filter(traverse(growth_unit_node, identity)) do node
        symbol(node) == AMAPSIM_MTG_SYMBOLS.phytomer || return false
        _ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis) === parent_axis
    end
    sort!(phytomers; by=node -> node[:GrowthUnitPhytomerIndex])
    isempty(phytomers) && return NamedTuple[]

    branch_plans = NamedTuple[]
    axis_initial_reference_age = _axis_initial_reference_age(parent_axis)
    lateral_count = length(parameters.lateral_productions)
    for lateral_index in _selected_lateral_production_indices(
        parameters,
        lateral_index,
    )
        lateral = parameters.lateral_productions[lateral_index]
        global_parameters = lateral.global_parameters
        is_markov = lateral.branching_models[1] == MarkovModel
        occurrence_probability = _validate_probability(valueat(
            global_parameters.axillary_probability,
            plan.reference_age,
        ))
        outer_nature = _truncate_parameter_integer(
            valueat(global_parameters.nature, plan.reference_age + 1),
            "outer lateral axis nature",
        )
        outer_nature >= 10 && continue
        if outer_nature == 0
            maximum_order = _maximum_nature_zero_branching_order(
                parameters,
                axis_initial_reference_age,
            )
            Base.Checked.checked_add(parent_order, 1) <= maximum_order ||
                continue
        end
        nature = _truncate_parameter_integer(
            valueat(global_parameters.nature, plan.reference_age),
            "child lateral axis nature",
        )
        child_order = nature == 0 ?
                      Base.Checked.checked_add(parent_order, 1) :
                      parent_order
        direction = _truncate_parameter_integer(
            valueat(
                global_parameters.delayed_branch_counting_direction,
                plan.reference_age,
            ),
            "delayed branch counting direction",
        )
        ordered_phytomers = iszero(direction) ? phytomers : reverse(phytomers)
        previous_legacy_state = _initial_markov_scan_state(
            state,
            parameters,
            parent_axis,
            first(ordered_phytomers),
            plan.reference_age,
            direction,
            branching_site_states,
            lateral_index,
            lateral_count,
        )
        previous_state = _delayed_state_from_branching_site(
            previous_legacy_state,
        )
        semi_markov_state = DelayedSemiMarkovState(
            _delayed_semimarkov_state_from_branching_site(
                previous_legacy_state,
            ),
            0,
        )
        start_position = valueat(
            global_parameters.production_start,
            plan.reference_age,
        ) - 1
        end_position = valueat(
            global_parameters.production_end,
            plan.reference_age,
        ) - 1
        for phytomer in ordered_phytomers
            branching_site_state = _branching_site_state(
                branching_site_states,
                phytomer,
                lateral_index,
                lateral_count,
            )
            if is_markov &&
               (iszero(occurrence_probability) ||
                !_markov_delayed_site_available(branching_site_state))
                continue
            end
            zone_index = _truncate_parameter_integer(
                _ancestor_with_symbol(phytomer, AMAPSIM_MTG_SYMBOLS.zone)[:ZoneIndex],
                "lateral production zone index",
            )
            zone = _lateral_production_zone(lateral, zone_index)
            delayed_counting_unit = is_markov ?
                                    _delayed_markov_scan_counting_unit(
                phytomer,
                state,
                parameters,
                lateral,
                zone,
                plan.reference_age,
            ) : nothing
            basal_position = _branching_position_for_phytomer(
                phytomer,
                state,
                parameters,
                plan.reference_age,
                0;
                counting_unit_override=delayed_counting_unit,
            )
            if is_markov && basal_position < start_position
                previous_legacy_state = BranchingSiteUndefined
                previous_state = nothing
                semi_markov_state = DelayedSemiMarkovState()
                _set_branching_site_state!(
                    branching_site_states,
                    phytomer,
                    lateral_index,
                    lateral_count,
                    BranchingSiteUndefined,
                )
                continue
            elseif is_markov && basal_position > end_position
                previous_legacy_state = BranchingSiteUnbranched
                previous_state = DelayedUnbranched
                semi_markov_state = DelayedSemiMarkovState(previous_state, 0)
                phytomer[:BranchingState] =
                    _delayed_branching_state_label(previous_state)
                _set_branching_site_state!(
                    branching_site_states,
                    phytomer,
                    lateral_index,
                    lateral_count,
                    BranchingSiteUnbranched,
                )
                continue
            end
            position = _branching_position_for_phytomer(
                phytomer,
                state,
                parameters,
                plan.reference_age,
                direction;
                counting_unit_override=delayed_counting_unit,
            )
            emitted_branch = if is_markov
                effective_previous_legacy_state = previous_legacy_state
                previous_physical_site = _physical_branching_site(
                    parent_axis,
                    phytomer,
                    parameters,
                    global_parameters,
                    plan.reference_age,
                    direction,
                    lateral,
                    ;
                    counting_unit_override=delayed_counting_unit,
                )
                if iszero(position) || previous_physical_site === nothing
                    effective_previous_legacy_state = BranchingSiteUndefined
                elseif previous_legacy_state != BranchingSiteUndefined
                    current_initial_probability = _delayed_initial_probability(
                        zone.branching,
                        plan.reference_age,
                        position,
                        previous_legacy_state,
                    )
                    previous_initial_probability = _delayed_initial_probability(
                        previous_physical_site.branching,
                        plan.reference_age,
                        previous_physical_site.position,
                        previous_legacy_state,
                    )
                    if current_initial_probability != previous_initial_probability
                        effective_previous_legacy_state =
                            BranchingSiteUndefined
                    end
                end
                transition = sample_delayed_markov_state(
                    rng,
                    zone,
                    plan.reference_age,
                    position,
                    _delayed_state_from_branching_site(
                        effective_previous_legacy_state,
                    ),
                )
                previous_legacy_state = _delayed_markov_result_state(
                    effective_previous_legacy_state,
                    transition.state,
                )
                previous_state = _delayed_state_from_branching_site(
                    previous_legacy_state,
                )::DelayedBranchState
                _set_branching_site_state!(
                    branching_site_states,
                    phytomer,
                    lateral_index,
                    lateral_count,
                    previous_legacy_state,
                )
                previous_legacy_state in (
                    BranchingSiteDelayedType1,
                    BranchingSiteDelayedType2,
                )
            else
                transition = advance_delayed_semimarkov_state(
                    rng,
                    zone,
                    plan.reference_age,
                    position,
                    semi_markov_state,
                )
                semi_markov_state = transition.next_state
                previous_state = transition.current_state
                previous_legacy_state = previous_state == DelayedUnbranched ?
                                        BranchingSiteUnbranched :
                                        previous_state == DelayedType1 ?
                                        BranchingSiteDelayedType1 :
                                        BranchingSiteDelayedType2
                transition.emitted_branch &&
                start_position <= basal_position <= end_position
            end
            phytomer[:BranchingState] = is_markov ?
                                        _legacy_branching_state_label(
                previous_legacy_state,
            ) : _delayed_branching_state_label(previous_state)
            emitted_branch || continue
            iszero(occurrence_probability) && continue

            strength_direction = _truncate_parameter_integer(
                valueat(
                    global_parameters.delayed_branch_strength_direction,
                    plan.reference_age,
                ),
                "delayed branch strength direction",
            )
            strength_position = _branching_position_for_phytomer(
                phytomer,
                state,
                parameters,
                plan.reference_age,
                strength_direction,
            )
            initialization = sample_delayed_branch_initialization(
                rng,
                zone,
                parameters.axis.growth,
                plan.reference_age,
                strength_position,
                previous_state;
                current_reference_age=state.vigor.reference_age,
            )
            child_reiteration_order = _child_reiteration_order(
                parameters,
                parent_axis,
                plan.reference_age,
                initialization.physiological_age,
            )
            isnothing(child_reiteration_order) && continue
            bearer_internode = _require_internode_bearer_product(
                phytomer,
                "delayed",
            )
            _foreach_emitted_axillary_slot!(
                rng,
                lateral,
                plan.reference_age,
            ) do slot, slot_count
                # Legacy endGu() assigns the theoretical GU end to
                # previousInstant before the delayed-branch scan.
                resolved = _resolve_child_axis_initialization(
                    status,
                    rng,
                    parent_axis,
                    state,
                    initialization;
                    growth_unit_physiological_age=plan.reference_age + 1,
                    position=strength_position,
                    zone=zone_index,
                    branching_type=Symbol(_delayed_branching_state_label(previous_state)),
                    lateral_production=lateral_index,
                    slot,
                    time=plan.theoretical_growth_unit_end_time,
                    environment,
                )
                resolved_reiteration_order = _child_reiteration_order(
                    parameters,
                    parent_axis,
                    plan.reference_age,
                    resolved.initialization.physiological_age,
                )
                isnothing(resolved_reiteration_order) && return nothing
                push!(branch_plans, (;
                    phytomer=phytomer,
                    bearer_internode,
                    lateral_index,
                    nature,
                    child_order,
                    reiteration_order=resolved_reiteration_order,
                    slot,
                    slot_count,
                    branch_type=previous_state,
                    branching_label=_delayed_branching_state_label(previous_state),
                    birth_time=plan.theoretical_growth_unit_end_time,
                    category=resolved.category,
                    initialization=resolved.initialization,
                    initiation_context=resolved.context,
                    child_state=_initialize_lateral_bud_state(
                        rng,
                        parameters,
                        T,
                        resolved.initialization,
                        lateral.organ_symbol,
                    ),
                ))
                return nothing
            end
        end
        state.legacy_branching_states[lateral_index] = previous_legacy_state
        state.delayed_markov_states[lateral_index] =
            _delayed_state_from_branching_site(previous_legacy_state)
    end
    return branch_plans
end

function _plan_cycle_delayed_branches!(
    state::ApicalBudState{T},
    rng,
    parameters,
    cycle_node,
    parent_axis,
    plan,
    parent_order,
    status,
    environment,
    branching_site_states;
    lateral_index=nothing,
) where {T<:Real}
    plan.cycle_ended && !plan.growth_unit_ended || return NamedTuple[]
    phytomers = filter(traverse(cycle_node, identity)) do node
        symbol(node) == AMAPSIM_MTG_SYMBOLS.phytomer || return false
        _ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis) === parent_axis
    end
    sort!(phytomers; by=node -> node[:CyclePhytomerIndex])
    isempty(phytomers) && return NamedTuple[]

    branch_plans = NamedTuple[]
    axis_initial_reference_age = _axis_initial_reference_age(parent_axis)
    lateral_count = length(parameters.lateral_productions)
    for lateral_index in _selected_lateral_production_indices(
        parameters,
        lateral_index,
    )
        lateral = parameters.lateral_productions[lateral_index]
        lateral.branching_models[3] == MarkovModel || continue
        global_parameters = lateral.global_parameters
        occurrence_probability = _validate_probability(valueat(
            global_parameters.axillary_probability,
            plan.reference_age,
        ))
        outer_nature = _truncate_parameter_integer(
            valueat(global_parameters.nature, plan.reference_age + 1),
            "outer lateral axis nature",
        )
        outer_nature >= 10 && continue
        if outer_nature == 0
            maximum_order = _maximum_nature_zero_branching_order(
                parameters,
                axis_initial_reference_age,
            )
            Base.Checked.checked_add(parent_order, 1) <= maximum_order ||
                continue
        end
        nature = _truncate_parameter_integer(
            valueat(global_parameters.nature, plan.reference_age),
            "child lateral axis nature",
        )
        child_order = nature == 0 ?
                      Base.Checked.checked_add(parent_order, 1) :
                      parent_order
        direction = _truncate_parameter_integer(
            valueat(
                global_parameters.delayed_branch_counting_direction,
                plan.reference_age,
            ),
            "cycle-delayed branch counting direction",
        )
        ordered_phytomers = iszero(direction) ? phytomers : reverse(phytomers)
        previous_legacy_state = _initial_markov_scan_state(
            state,
            parameters,
            parent_axis,
            first(ordered_phytomers),
            plan.reference_age,
            direction,
            branching_site_states,
            lateral_index,
            lateral_count,
        )
        start_position = valueat(
            global_parameters.production_start,
            plan.reference_age,
        ) - 1
        end_position = valueat(
            global_parameters.production_end,
            plan.reference_age,
        ) - 1
        for phytomer in ordered_phytomers
            branching_site_state = _branching_site_state(
                branching_site_states,
                phytomer,
                lateral_index,
                lateral_count,
            )
            (!iszero(occurrence_probability) &&
             _markov_cycle_delayed_site_available(branching_site_state)) ||
                continue
            basal_position = _branching_position_for_phytomer(
                phytomer,
                state,
                parameters,
                plan.reference_age,
                0,
            )
            if basal_position < start_position
                previous_legacy_state = BranchingSiteUndefined
                _set_branching_site_state!(
                    branching_site_states,
                    phytomer,
                    lateral_index,
                    lateral_count,
                    BranchingSiteUndefined,
                )
                continue
            end
            position = _branching_position_for_phytomer(
                phytomer,
                state,
                parameters,
                plan.reference_age,
                direction,
            )
            zone_index = _truncate_parameter_integer(
                _ancestor_with_symbol(phytomer, AMAPSIM_MTG_SYMBOLS.zone)[:ZoneIndex],
                "lateral production zone index",
            )
            zone = _lateral_production_zone(lateral, zone_index)
            if basal_position > end_position
                previous_legacy_state = BranchingSiteUnbranched
                phytomer[:BranchingState] = "cycle_delayed_unbranched"
                _set_branching_site_state!(
                    branching_site_states,
                    phytomer,
                    lateral_index,
                    lateral_count,
                    BranchingSiteUnbranched,
                )
                continue
            end
            previous_branched = _cycle_delayed_state_from_branching_site(
                previous_legacy_state,
            )
            previous_physical_site = _physical_branching_site(
                parent_axis,
                phytomer,
                parameters,
                global_parameters,
                plan.reference_age,
                direction,
                lateral,
            )
            reset_state = _cycle_delayed_reset_state(previous_legacy_state)
            previous_initial_probability = if reset_state === nothing ||
                                              previous_physical_site === nothing
                nothing
            else
                _validate_probability(valueat(
                    previous_physical_site.branching.cycle_delayed_initial_probability,
                    plan.reference_age,
                    previous_physical_site.position,
                ))
            end
            transition = sample_cycle_delayed_markov_state(
                rng,
                zone,
                plan.reference_age,
                position,
                previous_branched;
                previous_initial_probability,
            )
            previous_legacy_state = transition.branched ?
                                    BranchingSiteCycleDelayed :
                                    BranchingSiteCycleDelayedUnbranched
            _set_branching_site_state!(
                branching_site_states,
                phytomer,
                lateral_index,
                lateral_count,
                previous_legacy_state,
            )
            phytomer[:BranchingState] = transition.branched ?
                                           "cycle_delayed" :
                                           "cycle_delayed_unbranched"
            transition.branched || continue

            strength_direction = _truncate_parameter_integer(
                valueat(
                    global_parameters.delayed_branch_strength_direction,
                    plan.reference_age,
                ),
                "cycle-delayed branch strength direction",
            )
            strength_position = _branching_position_for_phytomer(
                phytomer,
                state,
                parameters,
                plan.reference_age,
                strength_direction,
            )
            initialization = sample_cycle_delayed_branch_initialization(
                rng,
                zone,
                plan.reference_age,
                strength_position;
                current_reference_age=state.vigor.reference_age,
            )
            child_reiteration_order = _child_reiteration_order(
                parameters,
                parent_axis,
                plan.reference_age,
                initialization.physiological_age,
            )
            isnothing(child_reiteration_order) && continue
            bearer_internode = _require_internode_bearer_product(
                phytomer,
                "cycle-delayed",
            )
            _foreach_emitted_axillary_slot!(
                rng,
                lateral,
                plan.reference_age,
            ) do slot, slot_count
                resolved = _resolve_child_axis_initialization(
                    status,
                    rng,
                    parent_axis,
                    state,
                    initialization;
                    growth_unit_physiological_age=plan.reference_age + 1,
                    position=strength_position,
                    zone=zone_index,
                    branching_type=:cycle_delayed,
                    lateral_production=lateral_index,
                    slot,
                    time=plan.theoretical_growth_unit_end_time,
                    environment,
                )
                resolved_reiteration_order = _child_reiteration_order(
                    parameters,
                    parent_axis,
                    plan.reference_age,
                    resolved.initialization.physiological_age,
                )
                isnothing(resolved_reiteration_order) && return nothing
                push!(branch_plans, (;
                    phytomer=phytomer,
                    bearer_internode,
                    lateral_index,
                    nature,
                    child_order,
                    reiteration_order=resolved_reiteration_order,
                    slot,
                    slot_count,
                    branching_label="cycle_delayed",
                    category=resolved.category,
                    initialization=resolved.initialization,
                    initiation_context=resolved.context,
                    child_state=_initialize_lateral_bud_state(
                        rng,
                        parameters,
                        T,
                        resolved.initialization,
                        lateral.organ_symbol,
                        Base.Checked.checked_add(
                            state.immediate_branching_order,
                            1,
                        ),
                    ),
                ))
                return nothing
            end
        end
        state.legacy_branching_states[lateral_index] = previous_legacy_state
    end
    return branch_plans
end

function _plan_traumatic_branches!(
    state::ApicalBudState{T},
    rng,
    parameters,
    growth_unit_node,
    parent_axis,
    plan,
    parent_order,
    birth_time,
    status,
    environment,
    branching_site_states;
    lateral_index=nothing,
) where {T<:Real}
    plan.bud_died || return NamedTuple[]
    phytomers = filter(traverse(growth_unit_node, identity)) do node
        symbol(node) == AMAPSIM_MTG_SYMBOLS.phytomer || return false
        _ancestor_with_symbol(node, AMAPSIM_MTG_SYMBOLS.axis) === parent_axis
    end
    sort!(phytomers; by=node -> node[:GrowthUnitPhytomerIndex])
    isempty(phytomers) && return NamedTuple[]

    branch_plans = NamedTuple[]
    axis_initial_reference_age = _axis_initial_reference_age(parent_axis)
    lateral_count = length(parameters.lateral_productions)
    for lateral_index in _selected_lateral_production_indices(
        parameters,
        lateral_index,
    )
        lateral = parameters.lateral_productions[lateral_index]
        is_markov = lateral.branching_models[1] == MarkovModel
        global_parameters = lateral.global_parameters
        death_influence = _truncate_parameter_integer(
            valueat(
                global_parameters.bearing_axis_death_influence,
                plan.reference_age + 1,
            ),
            "bearing-axis death influence",
        )
        death_influence == 1 || continue
        occurrence_probability = _validate_probability(valueat(
            global_parameters.axillary_probability,
            plan.reference_age,
        ))
        outer_nature = _truncate_parameter_integer(
            valueat(global_parameters.nature, plan.reference_age + 1),
            "outer lateral axis nature",
        )
        outer_nature >= 10 && continue
        if outer_nature == 0
            maximum_order = _maximum_nature_zero_branching_order(
                parameters,
                axis_initial_reference_age,
            )
            Base.Checked.checked_add(parent_order, 1) <= maximum_order ||
                continue
        end
        nature = _truncate_parameter_integer(
            valueat(global_parameters.nature, plan.reference_age),
            "child lateral axis nature",
        )
        child_order = nature == 0 ?
                      Base.Checked.checked_add(parent_order, 1) :
                      parent_order
        direction = _truncate_parameter_integer(
            valueat(
                global_parameters.delayed_branch_counting_direction,
                plan.reference_age,
            ),
            "traumatic branch counting direction",
        )
        ordered_phytomers = iszero(direction) ? phytomers : reverse(phytomers)
        previous_legacy_state = _initial_markov_scan_state(
            state,
            parameters,
            parent_axis,
            first(ordered_phytomers),
            plan.reference_age,
            direction,
            branching_site_states,
            lateral_index,
            lateral_count,
        )
        semi_markov_state = TraumaticSemiMarkovState(
            _traumatic_semimarkov_seed(previous_legacy_state),
            0,
        )
        start_position = valueat(
            global_parameters.production_start,
            plan.reference_age,
        ) - 1
        end_position = valueat(
            global_parameters.production_end,
            plan.reference_age,
        ) - 1
        for phytomer in ordered_phytomers
            occupied = _phytomer_has_lateral_axis(phytomer, lateral_index)
            if is_markov
                branching_site_state = _branching_site_state(
                    branching_site_states,
                    phytomer,
                    lateral_index,
                    lateral_count,
                )
                (!iszero(occurrence_probability) &&
                 _markov_delayed_site_available(branching_site_state)) ||
                    continue
            end
            basal_position = _branching_position_for_phytomer(
                phytomer,
                state,
                parameters,
                plan.reference_age,
                0,
            )
            position = _branching_position_for_phytomer(
                phytomer,
                state,
                parameters,
                plan.reference_age,
                direction,
            )
            zone_index = _truncate_parameter_integer(
                _ancestor_with_symbol(phytomer, AMAPSIM_MTG_SYMBOLS.zone)[:ZoneIndex],
                "lateral production zone index",
            )
            zone = _lateral_production_zone(lateral, zone_index)
            emitted_branch = if is_markov
                if basal_position < start_position
                    previous_legacy_state = BranchingSiteUndefined
                    _set_branching_site_state!(
                        branching_site_states,
                        phytomer,
                        lateral_index,
                        lateral_count,
                        BranchingSiteUndefined,
                    )
                    continue
                elseif basal_position > end_position
                    previous_legacy_state = BranchingSiteUnbranched
                    phytomer[:BranchingState] = "traumatic_unbranched"
                    _set_branching_site_state!(
                        branching_site_states,
                        phytomer,
                        lateral_index,
                        lateral_count,
                        BranchingSiteUnbranched,
                    )
                    continue
                end
                previous_branched = _traumatic_state_from_branching_site(
                    previous_legacy_state,
                )
                previous_physical_site = _physical_branching_site(
                    parent_axis,
                    phytomer,
                    parameters,
                    global_parameters,
                    plan.reference_age,
                    direction,
                    lateral,
                )
                reset_state = _traumatic_reset_state(previous_legacy_state)
                previous_initial_probability = if reset_state === nothing ||
                                                  previous_physical_site === nothing
                    nothing
                else
                    _validate_probability(valueat(
                        previous_physical_site.branching.traumatic_initial_probability,
                        plan.reference_age,
                        previous_physical_site.position,
                    ))
                end
                transition = sample_traumatic_markov_state(
                    rng,
                    zone,
                    plan.reference_age,
                    position,
                    previous_branched;
                    previous_initial_probability,
                )
                previous_legacy_state = transition.branched ?
                                        BranchingSiteTraumatic :
                                        BranchingSiteTraumaticUnbranched
                _set_branching_site_state!(
                    branching_site_states,
                    phytomer,
                    lateral_index,
                    lateral_count,
                    previous_legacy_state,
                )
                phytomer[:BranchingState] = transition.branched ?
                                               "traumatic" :
                                               "traumatic_unbranched"
                transition.branched
            else
                transition = advance_traumatic_semimarkov_state(
                    rng,
                    zone,
                    plan.reference_age,
                    position,
                    semi_markov_state,
                )
                semi_markov_state = transition.next_state
                previous_legacy_state = transition.current_branched ?
                                        BranchingSiteTraumatic :
                                        BranchingSiteTraumaticUnbranched
                if !occupied
                    phytomer[:BranchingState] = transition.current_branched ?
                                                   "traumatic" :
                                                   "traumatic_unbranched"
                end
                transition.emitted_branch &&
                start_position <= basal_position <= end_position
            end
            emitted_branch || continue
            iszero(occurrence_probability) && continue

            strength_direction = _truncate_parameter_integer(
                valueat(
                    global_parameters.delayed_branch_strength_direction,
                    plan.reference_age,
                ),
                "traumatic branch strength direction",
            )
            strength_position = _branching_position_for_phytomer(
                phytomer,
                state,
                parameters,
                plan.reference_age,
                strength_direction,
            )
            initialization = sample_traumatic_branch_initialization(
                rng,
                zone,
                parameters.axis.growth,
                plan.reference_age,
                strength_position;
                current_reference_age=state.vigor.reference_age,
            )
            child_reiteration_order = _child_reiteration_order(
                parameters,
                parent_axis,
                plan.reference_age,
                initialization.physiological_age,
            )
            isnothing(child_reiteration_order) && continue
            bearer_internode = _require_internode_bearer_product(
                phytomer,
                "traumatic",
            )
            _foreach_emitted_axillary_slot!(
                rng,
                lateral,
                plan.reference_age,
            ) do slot, slot_count
                resolved = _resolve_child_axis_initialization(
                    status,
                    rng,
                    parent_axis,
                    state,
                    initialization;
                    growth_unit_physiological_age=plan.reference_age + 1,
                    position=strength_position,
                    zone=zone_index,
                    branching_type=:traumatic,
                    lateral_production=lateral_index,
                    slot,
                    time=birth_time,
                    environment,
                )
                resolved_reiteration_order = _child_reiteration_order(
                    parameters,
                    parent_axis,
                    plan.reference_age,
                    resolved.initialization.physiological_age,
                )
                isnothing(resolved_reiteration_order) && return nothing
                push!(branch_plans, (;
                    phytomer=phytomer,
                    bearer_internode,
                    lateral_index,
                    nature,
                    child_order,
                    reiteration_order=resolved_reiteration_order,
                    slot,
                    slot_count,
                    branching_label="traumatic",
                    birth_time,
                    category=resolved.category,
                    initialization=resolved.initialization,
                    initiation_context=resolved.context,
                    child_state=_initialize_lateral_bud_state(
                        rng,
                        parameters,
                        T,
                        resolved.initialization,
                        lateral.organ_symbol,
                    ),
                ))
                return nothing
            end
        end
        state.legacy_branching_states[lateral_index] = previous_legacy_state
    end
    return branch_plans
end

function _materialize_delayed_branches!(branch_plans, event, context, parameters)
    isempty(branch_plans) && return NamedTuple[]
    symbols = AMAPSIM_MTG_SYMBOLS
    scales = AMAPSIM_MTG_SCALES
    materialized = NamedTuple[]
    for branch in branch_plans
        age_attributes = _axis_meristem_initialization_attributes(
            branch.initialization.physiological_age,
            category=branch.category,
        )
        bearer_axis = _ancestor_with_symbol(branch.phytomer, symbols.axis)
        branch_type = branch.branching_label
        birth_time = get(branch, :birth_time, event.time)
        phyllotaxy = _branch_phyllotaxy(
            parameters,
            bearer_axis,
            branch.phytomer,
            branch.lateral_index,
            branch.slot,
            branch.slot_count,
        )
        _record_bearer_deviation!(
            branch.bearer_internode,
            parameters;
            child_initial_physiological_age=
                branch.initialization.physiological_age,
            lateral_production_index=branch.lateral_index,
            whorl_slot=branch.slot,
            whorl_size=branch.slot_count,
        )
        axis = _add_hierarchy_node!(
            branch.phytomer,
            context,
            symbols.axis,
            scales.axis;
            link=:+,
            index=_next_child_index(branch.phytomer, symbols.axis),
            attributes=merge((
                Order=branch.child_order,
                ReiterationOrder=branch.reiteration_order,
                DevelopmentSiteCount=0,
                PhytomerCount=0,
                InitialPhyllotaxyAngle=0.0,
                Phyllotaxy=phyllotaxy,
                Nature=branch.nature,
                State="active",
                BirthTime=birth_time,
                BranchingType=branch_type,
                LateralProductionIndex=branch.lateral_index,
                WhorlSlot=branch.slot,
                WhorlSize=branch.slot_count,
                BearerPhytomerID=node_id(branch.phytomer),
                BearerAxisID=node_id(bearer_axis),
                BearerAxisPhytomerIndex=branch.phytomer[:AxisPhytomerIndex],
                BearerAxisInternodeIndex=branch.phytomer[:AxisInternodeIndex],
                BearerInternodeID=node_id(branch.bearer_internode),
            ), age_attributes.axis),
        )
        annual_shoot = _add_hierarchy_node!(
            axis,
            context,
            symbols.annual_shoot,
            scales.annual_shoot;
            index=1,
            attributes=(AnnualShootIndex=1, BirthTime=birth_time),
        )
        axis[:InitializationBearerID] = node_id(annual_shoot)
        bud = _add_hierarchy_node!(
            annual_shoot,
            context,
            symbols.bud,
            scales.organ;
            index=1,
            attributes=merge((
                State="active",
                BirthTime=birth_time,
                BranchingType=branch_type,
            ), age_attributes.meristem),
        )
        branch.child_state.bud_id = UInt64(node_id(bud))
        next_time = birth_time + branch.child_state.time_per_test
        isfinite(next_time) || throw(ArgumentError(
            "first delayed child apical event time must be finite",
        ))
        next_time > birth_time || throw(ArgumentError(
            "first delayed child apical event time must increase",
        ))
        push!(materialized, (;
            axis,
            annual_shoot,
            bud,
            state=branch.child_state,
            next_time,
        ))
    end
    PlantGeom.bump_scene_version!(last(materialized).bud)
    return materialized
end

function _materialize_immediate_branches!(nodes, plan, event, context, parameters)
    isempty(plan.immediate_branches) && return NamedTuple[]
    isnothing(nodes.phytomer) && throw(ArgumentError(
        "immediate branches require a realized phytomer",
    ))
    isnothing(nodes.organ) && throw(ArgumentError(
        "immediate branches require a realized bearer internode",
    ))
    symbols = AMAPSIM_MTG_SYMBOLS
    scales = AMAPSIM_MTG_SCALES
    symbol(nodes.organ) == symbols.internode || throw(ArgumentError(
        "immediate branches require the realized developmental product to " *
        "be an Internode; got $(symbol(nodes.organ))",
    ))
    bearer_internode = nodes.organ
    bearer_axis = _ancestor_with_symbol(bearer_internode, symbols.axis)
    materialized = NamedTuple[]
    for branch in plan.immediate_branches
        birth_time = branch.birth_time
        age_attributes = _axis_meristem_initialization_attributes(
            branch.initialization.physiological_age,
            category=branch.category,
        )
        axis_index = _next_child_index(nodes.phytomer, symbols.axis)
        phyllotaxy = _branch_phyllotaxy(
            parameters,
            bearer_axis,
            nodes.phytomer,
            branch.lateral_index,
            branch.slot,
            branch.slot_count,
        )
        _record_bearer_deviation!(
            bearer_internode,
            parameters;
            child_initial_physiological_age=
                branch.initialization.physiological_age,
            lateral_production_index=branch.lateral_index,
            whorl_slot=branch.slot,
            whorl_size=branch.slot_count,
        )
        axis = _add_hierarchy_node!(
            nodes.phytomer,
            context,
            symbols.axis,
            scales.axis;
            link=:+,
            index=axis_index,
            attributes=merge((
                Order=branch.child_order,
                ReiterationOrder=branch.reiteration_order,
                DevelopmentSiteCount=0,
                PhytomerCount=0,
                InitialPhyllotaxyAngle=0.0,
                Phyllotaxy=phyllotaxy,
                Nature=branch.nature,
                State="active",
                BirthTime=birth_time,
                BranchingType="immediate",
                LateralProductionIndex=branch.lateral_index,
                WhorlSlot=branch.slot,
                WhorlSize=branch.slot_count,
                BearerPhytomerID=node_id(nodes.phytomer),
                BearerAxisID=node_id(bearer_axis),
                BearerAxisPhytomerIndex=nodes.phytomer[:AxisPhytomerIndex],
                BearerAxisInternodeIndex=plan.bearer_axis_internode_index,
                BearerInternodeID=node_id(bearer_internode),
            ), age_attributes.axis),
        )
        annual_shoot = _add_hierarchy_node!(
            axis,
            context,
            symbols.annual_shoot,
            scales.annual_shoot;
            index=1,
            attributes=(AnnualShootIndex=1, BirthTime=birth_time),
        )
        axis[:InitializationBearerID] = node_id(annual_shoot)
        bud = _add_hierarchy_node!(
            annual_shoot,
            context,
            symbols.bud,
            scales.organ;
            index=1,
            attributes=merge((
                State="active",
                BirthTime=birth_time,
                BranchingType="immediate",
            ), age_attributes.meristem),
        )
        child_state = branch.child_state
        child_state.bud_id = UInt64(node_id(bud))
        next_time = birth_time + child_state.time_per_test
        isfinite(next_time) || throw(ArgumentError(
            "first child apical event time must be finite",
        ))
        next_time > birth_time || throw(ArgumentError(
            "first child apical event must be later than its birth time",
        ))
        push!(materialized, (;
            axis,
            annual_shoot,
            bud,
            state=child_state,
            next_time,
            lateral_index=branch.lateral_index,
            slot=branch.slot,
        ))
    end
    nodes.phytomer[:BranchingState] = "immediate"
    PlantGeom.bump_scene_version!(last(materialized).bud)
    return materialized
end

function _materialize_lateral_branching_event!(
    state::ApicalBudState,
    rng,
    branching_site_states,
    status,
    nodes,
    plan,
    event,
    context,
    environment,
    parent_axis,
    parent_order,
    parent_reiteration_order,
    axis_initial_reference_age,
    lateral_branching_enabled,
)
    parameters = status.amapsim_parameters
    lateral_count = length(parameters.lateral_productions)
    if !isnothing(nodes.phytomer)
        _branching_site_states!(
            branching_site_states,
            nodes.phytomer,
            lateral_count,
        )
    end

    immediate_branches = NamedTuple[]
    cycle_delayed_branches = NamedTuple[]
    traumatic_branches = NamedTuple[]
    delayed_branches = NamedTuple[]
    emission_order = NamedTuple[]
    floating_axis_ids = Int[]
    floating_bud_ids = UInt64[]
    floating_phytomer_ids = UInt64[]
    floating_cancelled_event_count = 0

    for lateral_index in eachindex(parameters.lateral_productions)
        immediate_plan = (;
            branches=NamedTuple[],
            floating_cleanup_lateral_indices=Int[],
        )
        if plan.realized
            isnothing(nodes.phytomer) && throw(ArgumentError(
                "a realized branching site requires a Phytomer node",
            ))
            if lateral_branching_enabled
                immediate_plan = _plan_immediate_branches!(
                    state,
                    rng,
                    parameters,
                    plan.reference_age,
                    plan.branch_position,
                    plan.branching_zone_index,
                    plan.growth_unit_ended,
                    parent_order,
                    parent_reiteration_order,
                    axis_initial_reference_age,
                    status,
                    parent_axis,
                    event.time,
                    environment,
                    branching_site_states,
                    nodes.phytomer;
                    lateral_index,
                )
            end
            _record_immediate_markov_site!(
                state,
                parameters,
                plan.branch_position,
                plan.branching_zone_index,
                lateral_index,
            )
        end
        scoped_plan = merge(plan, (;
            immediate_branches=immediate_plan.branches,
            floating_cleanup_lateral_indices=
                immediate_plan.floating_cleanup_lateral_indices,
        ))
        floating = _cleanup_floating_immediate_branches!(
            status,
            parent_axis,
            state,
            scoped_plan,
            context,
        )
        append!(floating_axis_ids, floating.axis_ids)
        append!(floating_bud_ids, floating.bud_ids)
        append!(floating_phytomer_ids, floating.phytomer_ids)
        for phytomer_id in floating.phytomer_ids
            delete!(branching_site_states, phytomer_id)
        end
        floating_cancelled_event_count += floating.cancelled_event_count
        materialized_immediate = _materialize_immediate_branches!(
            nodes,
            scoped_plan,
            event,
            context,
            parameters,
        )
        append!(immediate_branches, materialized_immediate)
        append!(emission_order, materialized_immediate)

        lateral_branching_enabled || continue

        cycle_plans = _plan_cycle_delayed_branches!(
            state,
            rng,
            parameters,
            nodes.cycle_node,
            parent_axis,
            plan,
            parent_order,
            status,
            environment,
            branching_site_states;
            lateral_index,
        )
        materialized_cycle = _materialize_delayed_branches!(
            cycle_plans,
            event,
            context,
            parameters,
        )
        append!(cycle_delayed_branches, materialized_cycle)
        append!(emission_order, materialized_cycle)

        traumatic_plans = _plan_traumatic_branches!(
            state,
            rng,
            parameters,
            nodes.growth_unit_node,
            parent_axis,
            plan,
            parent_order,
            # Historical endGu() stores the theoretical GU end in
            # previousInstant before the traumatic scan runs. This may be
            # later than the lethal event when mortality ends a GU early.
            plan.theoretical_growth_unit_end_time,
            status,
            environment,
            branching_site_states;
            lateral_index,
        )
        materialized_traumatic = _materialize_delayed_branches!(
            traumatic_plans,
            event,
            context,
            parameters,
        )
        append!(traumatic_branches, materialized_traumatic)
        append!(emission_order, materialized_traumatic)

        delayed_plans = _plan_delayed_branches!(
            state,
            rng,
            parameters,
            nodes.growth_unit_node,
            parent_axis,
            plan,
            parent_order,
            status,
            environment,
            branching_site_states;
            lateral_index,
        )
        materialized_delayed = _materialize_delayed_branches!(
            delayed_plans,
            event,
            context,
            parameters,
        )
        append!(delayed_branches, materialized_delayed)
        append!(emission_order, materialized_delayed)
    end

    return (;
        floating_cleanup=(;
            axis_ids=floating_axis_ids,
            bud_ids=floating_bud_ids,
            phytomer_ids=floating_phytomer_ids,
            cancelled_event_count=floating_cancelled_event_count,
        ),
        immediate_branches,
        cycle_delayed_branches,
        traumatic_branches,
        delayed_branches,
        emission_order,
    )
end

function _process_pruning_event!(
    ::AbstractArchitectureDevelopmentModel,
    event::BudEvent,
    status,
    context,
)
    isnothing(context) && throw(ArgumentError(
        "pruning requires a PlantSimEngine runtime context",
    ))
    hasproperty(status, :amapsim_parameters) &&
        status.amapsim_parameters isa AMAPSimParameters || throw(ArgumentError(
        "plant status has no AMAPSim parameter set",
    ))
    hasproperty(status, :rng) && status.rng isa AbstractRNG || throw(ArgumentError(
        "plant status has no AMAPSim random stream",
    ))
    haskey(status.bud_states, event.bud_id) || throw(ArgumentError(
        "pruning bud $(event.bud_id) has no developmental state",
    ))

    bud_node = _event_node(event, context)
    axis = _ancestor_with_symbol(bud_node, AMAPSIM_MTG_SYMBOLS.axis)
    state = status.bud_states[event.bud_id]
    reference_age = state.pruning_reference_age
    isnothing(reference_age) && throw(ArgumentError(
        "pruning bud $(event.bud_id) has no retained reference age",
    ))
    coefficient = Float64(valueat(
        status.amapsim_parameters.axis.topology.progressive_pruning_coefficient,
        reference_age,
    ))
    isfinite(coefficient) || throw(ArgumentError(
        "progressive pruning coefficient must be finite",
    ))
    coefficient >= 0 || throw(DomainError(
        coefficient,
        "progressive pruning coefficient cannot be negative",
    ))
    candidate_rng = copy(status.rng)
    result = if event.process == :progressive_pruning
        sample_progressive_pruning_step(
            candidate_rng,
            coefficient;
            has_growth_units=!isempty(_axis_growth_units(axis)),
        )
    else
        probability = coefficient - floor(coefficient)
        ProgressivePruningResult(TotalAxisPruning, probability)
    end

    growth_unit_id = nothing
    pruned_axis_id = nothing
    removed_axis_ids = Int[]
    removed_bud_ids = UInt64[]
    cancelled_event_count = 0
    next_time = nothing
    if result.action == RemoveTerminalGrowthUnit
        candidate_time = event.time + one(event.time)
        isfinite(candidate_time) || throw(ArgumentError(
            "next progressive-pruning time must be finite",
        ))
        candidate_time > event.time || throw(ArgumentError(
            "next progressive-pruning time must increase",
        ))
        removed = _remove_terminal_growth_unit!(
            status,
            axis,
            bud_node,
            context,
        )
        growth_unit_id = removed.growth_unit_id
        removed_axis_ids = removed.removed_axis_ids
        removed_bud_ids = removed.removed_bud_ids
        cancelled_event_count = removed.cancelled_event_count
        schedule_event!(
            status.event_queue,
            event.bud_id,
            candidate_time,
            :progressive_pruning;
            legacy_priority=event.legacy_priority,
        )
        next_time = candidate_time
    else
        removed = _remove_axis_subtree!(
            status,
            axis,
            context;
            current_event_id=event.id,
        )
        pruned_axis_id = removed.axis_id
        removed_axis_ids = removed.removed_axis_ids
        removed_bud_ids = removed.bud_ids
        cancelled_event_count = removed.cancelled_event_count
        PlantGeom.bump_scene_version!(PlantSimEngine.source_node(context))
    end

    status.rng = candidate_rng
    push!(
        status.event_trace,
        (
            time=event.time,
            bud_id=event.bud_id,
            pruning_event=event.process,
            pruning_action=result.action == RemoveTerminalGrowthUnit ?
                           :remove_terminal_growth_unit : :total_axis_pruning,
            pruning_reference_age=reference_age,
            pruning_coefficient=coefficient,
            total_pruning_probability=result.total_pruning_probability,
            pruned_growth_unit_id=growth_unit_id,
            pruned_axis_id,
            removed_axis_ids,
            removed_bud_ids,
            pruning_cancelled_event_count=cancelled_event_count,
            next_pruning_time=next_time,
        ),
    )
    return nothing
end

function _process_apical_growth_event!(
    model::AbstractArchitectureDevelopmentModel,
    event::BudEvent{T},
    status,
    context,
    environment=nothing,
) where {T<:Real}
    isnothing(context) && throw(ArgumentError(
        "apical growth requires a PlantSimEngine runtime context",
    ))
    hasproperty(status, :amapsim_parameters) &&
        status.amapsim_parameters isa AMAPSimParameters || throw(ArgumentError(
        "plant status has no AMAPSim parameter set",
    ))
    hasproperty(status, :rng) && status.rng isa AbstractRNG || throw(ArgumentError(
        "plant status has no AMAPSim random stream",
    ))
    hasproperty(status, :bud_states) || throw(ArgumentError(
        "plant status has no AMAPSim bud-state registry",
    ))
    hasproperty(status, :branching_site_states) &&
        status.branching_site_states isa
        Dict{UInt64,Vector{LegacyBranchingSiteState}} || throw(ArgumentError(
        "plant status has no AMAPSim branching-site state ledger",
    ))
    hasproperty(status, :development_sites) &&
        status.development_sites isa Vector{DevelopmentSiteRecord{T}} ||
        throw(ArgumentError(
            "plant status has no typed AMAPSim developmental-site ledger",
        ))
    haskey(status.bud_states, event.bud_id) || throw(ArgumentError(
        "event bud $(event.bud_id) has no developmental state",
    ))

    bud_node = _event_node(event, context)
    parent_axis = _ancestor_with_symbol(bud_node, AMAPSIM_MTG_SYMBOLS.axis)
    parent_order = _truncate_parameter_integer(parent_axis[:Order], "axis order")
    lateral_branching_enabled = _axis_allows_lateral_branching(parent_axis)
    reiteration_context = _axis_reiteration_context(parent_axis)
    allocation_enabled = _growth_allocation_enabled(model)
    cached = allocation_enabled ? get(status.pending_growth_plans, event.id, nothing) : nothing
    if cached === nothing
        candidate_state = _copy_apical_bud_state(status.bud_states[event.bud_id])
        candidate_rng = copy(status.rng)
        immediate_branching_limit = _immediate_branching_limit(
            candidate_state,
            status.amapsim_parameters,
            get(
                MultiScaleTreeGraph.node_attributes(parent_axis),
                :Nature,
                0,
            ),
        )
        if immediate_branching_limit.exceeded
            candidate_state.ended = true
            bud_node[:State] = "ended"
            parent_axis[:State] = "ended"
            status.bud_states[event.bud_id] = candidate_state
            push!(
                status.event_trace,
                (;
                    time=event.time,
                    bud_id=event.bud_id,
                    immediate_branching_limit=true,
                    immediate_branching_order=candidate_state.immediate_branching_order,
                    maximum_immediate_branching_order=
                        immediate_branching_limit.maximum_order,
                    nature=immediate_branching_limit.nature,
                ),
            )
            PlantGeom.bump_scene_version!(bud_node)
            return nothing
        end
        dormancy = _advance_initial_dormancy!(
            candidate_state,
            candidate_rng,
            status.amapsim_parameters,
            event.time,
        )
        if dormancy.action != :continue
            initial_dormancy = candidate_state.initial_dormancy::InitialDormancy
            _set_meristem_current_physiological_age!(
                bud_node,
                candidate_state.vigor.reference_age + 1,
            )
            next_process = nothing
            if dormancy.action == :dead
                bud_node[:State] = "dead"
                parent_axis[:State] = "dead"
            else
                bud_node[:State] = "dormant"
                next_process = candidate_state.dormancy_complete ?
                               :apical_growth :
                               :initial_dormancy
                schedule_event!(
                    status.event_queue,
                    event.bud_id,
                    dormancy.next_time,
                    next_process;
                    legacy_priority=event.legacy_priority,
                )
            end
            status.bud_states[event.bud_id] = candidate_state
            status.rng = candidate_rng
            push!(
                status.event_trace,
                (
                    time=event.time,
                    bud_id=event.bud_id,
                    dormancy_event=:initial,
                    dormancy_phase=dormancy.phase,
                    dormancy_growth_unit_delay=initial_dormancy.growth_unit_delay,
                    dormancy_test_delay=initial_dormancy.test_delay,
                    dormancy_test_delay_remaining=
                        candidate_state.dormancy_test_delay_remaining,
                    dormancy_ages=initial_dormancy.ages_during_growth_unit_delay,
                    reference_age_before=dormancy.reference_age_before,
                    reference_age_after=dormancy.reference_age_after,
                    bud_died=dormancy.action == :dead,
                    next_dormancy_time=dormancy.next_time,
                    next_dormancy_process=next_process,
                ),
            )
            PlantGeom.bump_scene_version!(bud_node)
            return nothing
        end
        growth_unit_first_dispatch_time = if iszero(candidate_state.growth_unit_node_id)
            event.time
        else
            active_growth_unit = _registered_node(context, candidate_state.growth_unit_node_id)
            isnothing(active_growth_unit) && throw(ArgumentError(
                "active growth unit is absent from the MTG",
            ))
            first_dispatch = get(
                MultiScaleTreeGraph.node_attributes(active_growth_unit),
                :BirthTime,
                nothing,
            )
            first_dispatch isa Real && isfinite(first_dispatch) && first_dispatch <= event.time ||
                throw(ArgumentError("active growth unit requires a valid first-dispatch BirthTime"))
            first_dispatch
        end
        plan = _plan_apical_test!(
            candidate_state,
            candidate_rng,
            status.amapsim_parameters,
            event.time,
            parent_order,
            reiteration_context.parent_order,
            reiteration_context.initial_reference_age,
            lateral_branching_enabled,
            status,
            parent_axis,
            environment,
            growth_unit_first_dispatch_time,
        )
        site_batch = _development_site_batch(candidate_state, plan)
        if allocation_enabled && site_batch.main_outcome === RealizedDevelopmentSite
            status.pending_growth_plans[event.id] = (; event, candidate_state, candidate_rng, plan, site_batch,
                rng_committed=false)
        end
    else
        cached.event.bud_id == event.bud_id && cached.event.process === event.process &&
            cached.event.time == event.time || throw(ArgumentError(
                "a prepared organ's bud, process and developmental time cannot be rescheduled",
            ))
        candidate_state, plan, site_batch = cached.candidate_state, cached.plan, cached.site_batch
        # Other buds may have advanced the shared stream while this organ waited.
        # Reuse the apical plan, never restore its old stream over those draws.
        candidate_rng = cached.rng_committed ? copy(status.rng) : cached.candidate_rng
    end
    if !_notify_growth_intent!(model, status, event, candidate_state, site_batch, context)
        prepared = status.pending_growth_plans[event.id]
        if !prepared.rng_committed
            # Sample the potential organ once, including when it is not funded.
            # Later retries must neither repeat those draws nor rewind the stream.
            status.rng = candidate_rng
            status.pending_growth_plans[event.id] = merge(prepared, (rng_committed=true,))
        end
        status.deferred_growth_count += 1
        return :growth_deferred
    end
    allocation_enabled && delete!(status.pending_growth_plans, event.id)
    # Unknown partial lifecycle failures are aborts, never automatic retries.
    allocation_enabled && (status.growth_commit_in_progress = true)
    bud_node[:State] == "dormant" && (bud_node[:State] = "active")
    nodes = _materialize_apical_test!(
        status,
        bud_node,
        candidate_state,
        plan,
        site_batch,
        event,
        context,
    )
    pruning_plan = candidate_state.ended ? _plan_initial_pruning(
        status.amapsim_parameters,
        parent_axis,
        event,
        plan,
    ) : nothing
    candidate_state.pruning_reference_age = isnothing(pruning_plan) ?
                                            nothing :
                                            pruning_plan.reference_age
    candidate_branching_site_states = _BranchingSiteLedgerPatch(status.branching_site_states)
    lateral_branching = _materialize_lateral_branching_event!(
        candidate_state,
        candidate_rng,
        candidate_branching_site_states,
        status,
        nodes,
        plan,
        event,
        context,
        environment,
        parent_axis,
        parent_order,
        reiteration_context.parent_order,
        reiteration_context.initial_reference_age,
        lateral_branching_enabled,
    )
    floating_cleanup = lateral_branching.floating_cleanup
    immediate_branches = lateral_branching.immediate_branches
    cycle_delayed_branches = lateral_branching.cycle_delayed_branches
    traumatic_branches = lateral_branching.traumatic_branches
    delayed_branches = lateral_branching.delayed_branches

    active_growth_unit_id = UInt64(node_id(nodes.growth_unit_node))
    active_cycle_id = UInt64(node_id(nodes.cycle_node))
    active_zone_id = UInt64(node_id(nodes.zone_node))
    if plan.growth_unit_ended
        candidate_state.growth_unit_node_id = UInt64(0)
        candidate_state.cycle_node_id = UInt64(0)
        candidate_state.zone_node_id = UInt64(0)
        candidate_state.planned_cycle_count = 0
        candidate_state.cycle_index = 0
        candidate_state.test_index_within_growth_unit = 0
        candidate_state.test_index_within_cycle = 0
        candidate_state.cycle = nothing
    elseif plan.cycle_ended
        candidate_state.growth_unit_node_id = active_growth_unit_id
        candidate_state.cycle_node_id = UInt64(0)
        candidate_state.zone_node_id = UInt64(0)
        candidate_state.test_index_within_cycle = 0
        candidate_state.cycle = nothing
    else
        candidate_state.growth_unit_node_id = active_growth_unit_id
        candidate_state.cycle_node_id = active_cycle_id
        candidate_state.zone_node_id = active_zone_id
    end
    _update_axis_dimensions!(
        parent_axis,
        candidate_state.test_count_on_axis,
        status.amapsim_parameters;
        organ_symbol=candidate_state.organ_symbol,
    )

    if !candidate_state.ended
        schedule_event!(
            status.event_queue,
            event.bud_id,
            plan.next_time,
            :apical_growth;
            legacy_priority=event.legacy_priority,
        )
    elseif !isnothing(pruning_plan)
        schedule_event!(
            status.event_queue,
            event.bud_id,
            pruning_plan.time,
            pruning_plan.process;
            legacy_priority=event.legacy_priority,
        )
    end
    child_priority = Base.Checked.checked_add(event.legacy_priority, 11)
    for branch in lateral_branching.emission_order
        child_bud_id = UInt64(node_id(branch.bud))
        schedule_event!(
            status.event_queue,
            child_bud_id,
            branch.next_time,
            :initial_dormancy;
            legacy_priority=child_priority,
        )
        status.bud_states[child_bud_id] = branch.state
    end
    status.bud_states[event.bud_id] = candidate_state
    status.branching_site_states = _commit_branching_site_states!(candidate_branching_site_states)
    status.rng = candidate_rng
    main_site = _main_development_site(site_batch)
    push!(
        status.event_trace,
        (
            time=event.time,
            bud_id=event.bud_id,
            growth_unit_index=candidate_state.growth_unit_index,
            cycle_index=Int(nodes.cycle_node[:CycleIndex]),
            zone_kind=plan.zone_kind,
            phytomer_id=isnothing(nodes.phytomer) ? nothing : node_id(nodes.phytomer),
            # Retained as an explicit empty compatibility column for v0.1
            # event consumers; canonical v0.3 never emits TestSite nodes.
            test_site_id=nothing,
            growth_unit_test_index=isnothing(main_site) ?
                                   nothing : main_site.growth_unit_test_index,
            completed_growth_unit_test_count=plan.theoretical_growth_unit_test_count,
            axis_test_count=candidate_state.test_count_on_axis,
            realized=plan.realized,
            growth_unit_ended=plan.growth_unit_ended,
            axis_ended=plan.axis_ended,
            mortality_position=plan.mortality_position,
            mortality_death_position=plan.mortality_death_position,
            survived=plan.survived,
            bud_died=plan.bud_died,
            pruning_process=isnothing(pruning_plan) ? nothing : pruning_plan.process,
            pruning_time=isnothing(pruning_plan) ? nothing : pruning_plan.time,
            cycle_tail_test_count=plan.cycle_tail_test_count,
            cycle_tail_survival_test_count=plan.cycle_tail_survival_test_count,
            branch_position=plan.branch_position,
            floating_branch_axis_ids=floating_cleanup.axis_ids,
            floating_branch_bud_ids=floating_cleanup.bud_ids,
            floating_cancelled_event_count=
                floating_cleanup.cancelled_event_count,
            immediate_branch_count=length(immediate_branches),
            immediate_branch_axis_ids=Int[
                node_id(branch.axis) for branch in immediate_branches
            ],
            immediate_branch_bud_ids=Int[
                node_id(branch.bud) for branch in immediate_branches
            ],
            traumatic_branch_count=length(traumatic_branches),
            traumatic_branch_axis_ids=Int[
                node_id(branch.axis) for branch in traumatic_branches
            ],
            traumatic_branch_bud_ids=Int[
                node_id(branch.bud) for branch in traumatic_branches
            ],
            delayed_branch_count=length(delayed_branches),
            delayed_branch_axis_ids=Int[
                node_id(branch.axis) for branch in delayed_branches
            ],
            delayed_branch_bud_ids=Int[
                node_id(branch.bud) for branch in delayed_branches
            ],
            cycle_delayed_branch_count=length(cycle_delayed_branches),
            cycle_delayed_branch_axis_ids=Int[
                node_id(branch.axis) for branch in cycle_delayed_branches
            ],
            cycle_delayed_branch_bud_ids=Int[
                node_id(branch.bud) for branch in cycle_delayed_branches
            ],
            cycle_ended=plan.cycle_ended,
            organ_id=isnothing(nodes.organ) ? nothing : node_id(nodes.organ),
            organ_symbol=isnothing(nodes.organ) ? nothing : symbol(nodes.organ),
            # Compatibility alias for v0.1 consumers. It is intentionally
            # empty when the realized product is not botanically an Internode.
            internode_id=isnothing(nodes.organ) || symbol(nodes.organ) != :Internode ?
                          nothing : node_id(nodes.organ),
        ),
    )
    _append_development_site_records!(
        status.development_sites,
        event,
        length(status.event_trace),
        parent_axis,
        nodes,
        site_batch,
    )
    _settle_growth_allocation!(model, status, event, candidate_state, site_batch, context)
    allocation_enabled && (status.growth_commit_in_progress = false)
    return nothing
end

function _coordinated_event_key(event::BudEvent, plant_id::Int)
    time, priority, process_rank, sequence = _event_queue_priority(event)
    return (
        time,
        priority,
        plant_id,
        process_rank,
        sequence,
    )
end

function PlantSimEngine.run!(
    model::ArchitectureCoordinator{T},
    status,
    environment,
    constants=nothing,
    context=nothing,
) where {T<:Real}
    isnothing(context) && throw(ArgumentError(
        "ArchitectureCoordinator requires a PlantSimEngine runtime context",
    ))
    runtime = PlantSimEngine.runtime_model(context)
    plants = PlantSimEngine.model_objects(
        runtime;
        scale=AMAPSIM_MTG_SYMBOLS.plant,
    )
    plant_ids = map(plants) do plant
        node_id(PlantSimEngine.source_node(runtime, plant))
    end
    length(status.development_increments) == length(plants) || throw(ArgumentError(
        "coordinator increment binding does not match the number of plants",
    ))

    targets = Dict{Int,T}()
    for (plant, plant_id) in zip(plants, plant_ids)
        increment = _validate_development_increment(plant.status.development_increment)
        current_time = plant.status.development_time
        isfinite(current_time) || throw(ArgumentError("development time must be finite"))
        target_time = current_time + increment
        isfinite(target_time) ||
            throw(ArgumentError("target development time must be finite"))
        target_time >= current_time ||
            throw(ArgumentError("target development time must be monotonic"))
        plant.status.event_queue isa BudEventQueue{T} || throw(ArgumentError(
            "event queue time type must match ArchitectureCoordinator{$T}",
        ))
        targets[plant_id] = convert(T, target_time)
    end

    while true
        selected_plant = nothing
        selected_plant_id = nothing
        selected_event = nothing
        selected_key = nothing
        for (plant, plant_id) in zip(plants, plant_ids)
            event = peek_event(plant.status.event_queue)
            isnothing(event) && continue
            event.time <= targets[plant_id] || continue
            key = _coordinated_event_key(event, plant_id)
            if isnothing(selected_key) || key < selected_key
                selected_plant = plant
                selected_plant_id = plant_id
                selected_event = event
                selected_key = key
            end
        end
        isnothing(selected_event) && break
        if !isempty(status.coordination_trace)
            previous_time = last(status.coordination_trace).time
            selected_event.time >= previous_time || throw(ArgumentError(
                "coordinated event time $(selected_event.time) precedes the " *
                "previous processed time $previous_time",
            ))
        end

        _process_architecture_event!(
            model,
            selected_event,
            selected_plant.status,
            context,
            environment,
        )
        # Processing can enqueue an earlier-ranked action at this same time
        # (notably zero-lag pruning). Consume the action actually executed,
        # retaining the current event until processing succeeds.
        cancel_event!(selected_plant.status.event_queue, selected_event.id)
        popped = selected_event
        selected_plant.status.processed_events += 1
        selected_plant.status.last_event_id = popped.id.value
        status.coordinated_events += 1
        push!(
            status.coordination_trace,
            (
                time=popped.time,
                legacy_priority=popped.legacy_priority,
                plant_id=selected_plant_id,
                event_id=popped.id.value,
                process=popped.process,
            ),
        )
        for call_name in model.after_event_call_names
            PlantSimEngine.run_call!(context, call_name; publish=true)
            status.after_event_call_count += 1
        end
    end

    for (plant, plant_id) in zip(plants, plant_ids)
        target_time = targets[plant_id]
        plant.status.development_time = target_time
        _refresh_ended_axis_geometry!(plant.status, target_time, context)
    end
    return nothing
end

# Keep refused events in the canonical queue so pruning cancels them normally.
# Only allocation-enabled execution scans past events already tried this step.
function _next_unattempted_event(queue, attempted)
    event = peek_event(queue)
    event === nothing && return nothing
    event.id in attempted || return event
    selected = nothing
    for candidate in values(queue.events)
        candidate.id in attempted && continue
        if selected === nothing || event_priority(candidate) < event_priority(selected)
            selected = candidate
        end
    end
    return selected
end

function _discard_cancelled_growth_plans!(status)
    for id in collect(keys(status.pending_growth_plans))
        haskey(status.event_queue, id) || delete!(status.pending_growth_plans, id)
    end
    return nothing
end

function PlantSimEngine.run!(
    model::ArchitectureDevelopment{T},
    status,
    environment,
    constants=nothing,
    context=nothing,
) where {T<:Real}
    if _growth_allocation_enabled(model)
        status.growth_commit_in_progress && throw(ArgumentError(
            "a growth materialization or settlement failed; discard this simulation before retrying",
        ))
        _discard_cancelled_growth_plans!(status)
    end
    increment = _validate_development_increment(status.development_increment)
    current_time = status.development_time
    isfinite(current_time) || throw(ArgumentError("development time must be finite"))
    target_time = current_time + increment
    isfinite(target_time) || throw(ArgumentError("target development time must be finite"))
    target_time >= current_time ||
        throw(ArgumentError("target development time must be monotonic"))

    queue = status.event_queue
    queue isa BudEventQueue{T} || throw(ArgumentError(
        "event queue time type must match ArchitectureDevelopment{$T}",
    ))

    if _growth_allocation_enabled(model)
        # Credit this execution's cumulative supply even if no growth is due.
        # Empty slots denote a reserve update, with no quote or settlement.
        PlantSimEngine.run_call!(context, :growth_allocation; publish=false)
    end
    attempted = _growth_allocation_enabled(model) ? Set{EventID}() : nothing
    processed = 0
    last_event_id = status.last_event_id
    while true
        event = _growth_allocation_enabled(model) ? _next_unattempted_event(queue, attempted) : peek_event(queue)
        isnothing(event) && break
        event.time <= target_time || break
        outcome = _process_architecture_event!(model, event, status, context, environment)
        if outcome === :growth_deferred
            push!(attempted, event.id)
            continue
        end
        cancel_event!(queue, event.id)
        last_event_id = event.id.value
        processed += 1
    end

    status.processed_events += processed
    status.last_event_id = last_event_id
    status.development_time = convert(T, target_time)
    _refresh_ended_axis_geometry!(status, target_time, context)
    _growth_allocation_enabled(model) && _discard_cancelled_growth_plans!(status)
    return nothing
end

function _increment_for_plant(specification, node)
    if specification isa Real
        return specification
    elseif specification isa Function
        return specification(node)
    elseif specification isa AbstractDict
        plant_index = index(node)
        haskey(specification, plant_index) || throw(ArgumentError(
            "no development increment was supplied for plant index $plant_index",
        ))
        return specification[plant_index]
    end
    throw(ArgumentError(
        "development_increment must be a Real, function, or dictionary keyed by plant index",
    ))
end

function _parameters_for_plant(specification, node)
    parameters = if specification isa AMAPSimParameters
        specification
    elseif specification isa Function
        specification(node)
    elseif specification isa AbstractDict
        plant_index = index(node)
        haskey(specification, plant_index) || throw(ArgumentError(
            "no AMAPSim parameters were supplied for plant index $plant_index",
        ))
        specification[plant_index]
    else
        throw(ArgumentError(
            "parameters must be an AMAPSimParameters value, function, or dictionary keyed by plant index",
        ))
    end
    parameters isa AMAPSimParameters || throw(ArgumentError(
        "parameters for plant index $(index(node)) must be AMAPSimParameters",
    ))
    return parameters
end

function _validate_seed(seed, label)
    seed isa Integer || throw(ArgumentError("$label must be an integer"))
    0 <= seed <= typemax(UInt64) || throw(DomainError(
        seed,
        "$label must be between zero and typemax(UInt64)",
    ))
    return UInt64(seed)
end

function _seed_for_plant(specification, node)
    if specification isa Integer
        base = _validate_seed(specification, "random seed")
        offset = UInt64(index(node) - 1)
        return Base.Checked.checked_add(base, offset)
    elseif specification isa Function
        return _validate_seed(
            specification(node),
            "random seed for plant index $(index(node))",
        )
    elseif specification isa AbstractDict
        plant_index = index(node)
        haskey(specification, plant_index) || throw(ArgumentError(
            "no random seed was supplied for plant index $plant_index",
        ))
        return _validate_seed(
            specification[plant_index],
            "random seed for plant index $plant_index",
        )
    end
    throw(ArgumentError(
        "seed must be an integer, function, or dictionary keyed by plant index",
    ))
end

function _axis_categories_for_plant(specification, node)
    specification === nothing && return nothing
    categories = if specification isa Function
        specification(node)
    elseif specification isa AbstractDict
        plant_index = index(node)
        haskey(specification, plant_index) || throw(ArgumentError(
            "no axis categories were supplied for plant index $plant_index",
        ))
        specification[plant_index]
    else
        specification
    end
    return _validated_axis_categories(categories)
end

function _category_initiation_for_plant(specification, categories, node)
    if categories === nothing
        specification === nothing || throw(ArgumentError(
            "category_initiation requires axis_categories for plant index " *
            "$(index(node))",
        ))
        return nothing
    end
    model = if specification === nothing
        PhysiologicalAgeInitiation()
    elseif specification isa Function
        specification(node)
    elseif specification isa AbstractDict
        plant_index = index(node)
        haskey(specification, plant_index) || throw(ArgumentError(
            "no category-initiation model was supplied for plant index $plant_index",
        ))
        specification[plant_index]
    else
        specification
    end
    model isa AbstractAxisCategoryInitiationModel || throw(ArgumentError(
        "category initiation for plant index $(index(node)) must be an " *
        "AbstractAxisCategoryInitiationModel",
    ))
    return model
end

# Keep the retained PSE status adapter type independent of the concrete
# parameter/callback types. The same specification objects are resolved by
# _initial_model_status when each source node is initialized.
struct _StatusInitializer{T<:Real}
    increment_specification::Any
    parameter_specification::Any
    seed_specification::Any
    axis_category_specification::Any
    category_initiation_specification::Any
    rng_factory::Any
end

function (initializer::_StatusInitializer{T})(node) where {T<:Real}
    return _initial_model_status(
        node,
        T,
        initializer.increment_specification,
        initializer.parameter_specification,
        initializer.seed_specification,
        initializer.axis_category_specification,
        initializer.category_initiation_specification,
        initializer.rng_factory,
    )
end

function _initial_model_status(
    node,
    ::Type{T},
    increment_specification,
    parameter_specification,
    seed_specification,
    axis_category_specification=nothing,
    category_initiation_specification=nothing,
    rng_factory=nothing,
) where {T<:Real}
    _reject_mtg_runtime_status(node, "AMAPSim model status initialization")
    data = Dict{Symbol,Any}()
    for (key, value) in pairs(MultiScaleTreeGraph.node_attributes(node))
        data[Symbol(key)] = value
    end
    data[:node] = node

    if symbol(node) == AMAPSIM_MTG_SYMBOLS.plant
        increment = _increment_for_plant(increment_specification, node)
        increment isa Real || throw(ArgumentError(
            "development increment for plant index $(index(node)) must be real",
        ))
        _validate_development_increment(increment)
        data[:development_increment] = convert(T, increment)
        data[:event_queue] = BudEventQueue{T}(ordering=:legacy)
        data[:development_time] = zero(T)
        data[:processed_events] = 0
        data[:last_event_id] = UInt64(0)
        data[:amapsim_parameters] = nothing
        data[:random_seed] = nothing
        data[:rng] = nothing
        data[:bud_states] = Dict{UInt64,ApicalBudState{T}}()
        data[:branching_site_states] =
            Dict{UInt64,Vector{LegacyBranchingSiteState}}()
        data[:development_sites] = DevelopmentSiteRecord{T}[]
        data[:event_trace] = NamedTuple[]

        axis_categories = _axis_categories_for_plant(
            axis_category_specification,
            node,
        )
        category_initiation = _category_initiation_for_plant(
            category_initiation_specification,
            axis_categories,
            node,
        )
        if axis_categories !== nothing
            data[:axis_categories] = axis_categories
            data[:axis_category_initiation] = category_initiation
        end

        if !isnothing(parameter_specification)
            parameters = _parameters_for_plant(parameter_specification, node)
            random_seed = _seed_for_plant(seed_specification, node)
            rng = isnothing(rng_factory) ? Xoshiro(random_seed) : rng_factory(random_seed)
            rng isa AbstractRNG || throw(ArgumentError(
                "rng_factory must return an AbstractRNG for each plant seed",
            ))
            buds = filter(
                candidate -> symbol(candidate) == AMAPSIM_MTG_SYMBOLS.bud,
                traverse(node, identity),
            )
            length(buds) == 1 || throw(ArgumentError(
                "botanical initialization requires exactly one bud per initial plant",
            ))
            bud = only(buds)
            bud_id = UInt64(node_id(bud))
            bud_state = _initialize_apical_bud_state(
                rng,
                parameters,
                bud,
                T,
            )
            data[:amapsim_parameters] = parameters
            data[:random_seed] = random_seed
            data[:rng] = rng
            data[:bud_states] = Dict(bud_id => bud_state)
            schedule_event!(
                data[:event_queue],
                bud_id,
                bud_state.time_per_test,
                :initial_dormancy;
                legacy_priority=10,
            )
        end
    end

    if rng_factory !== nothing && symbol(node) == AMAPSIM_MTG_SYMBOLS.plant
        # Custom streams share one retained slot type. Keep their actual RNG
        # objects and copy/rand methods while avoiding a new PSE context type
        # for every diagnostic stream type.
        references = (;
            (key => (key === :rng ? Ref{Union{Nothing,AbstractRNG}}(value) : Ref(value))
             for (key, value) in pairs(data))...
        )
        return PlantSimEngine.Status(references)
    end
    return PlantSimEngine.Status((; data...))
end

function _validate_initial_axis_categories!(scene, specification)
    specification === nothing && return scene
    plants = filter(
        node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.plant,
        traverse(scene, identity),
    )
    for plant in plants
        categories = _axis_categories_for_plant(specification, plant)
        _validate_physiological_age_state(
            plant;
            categories,
            allow_legacy=false,
        )
    end
    return scene
end

function _validated_model_scene_preorder(scene::Node)
    parent(scene) === nothing || throw(ArgumentError("model scene must be an MTG root"))
    symbol(scene) == AMAPSIM_MTG_SYMBOLS.scene ||
        throw(ArgumentError("model scene root must have symbol :Scene"))
    nodes = traverse(scene, identity; type=typeof(scene))
    any(node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.plant, nodes) ||
        throw(ArgumentError("model scene must contain at least one :Plant node"))
    return nodes
end

function _validate_model_scene(scene::Node)
    _validated_model_scene_preorder(scene)
    return scene
end

function _parameterized_plant_seed_error(
    plant::Node,
    context::AbstractString,
)
    return ArgumentError(
        "$context cannot initialize Plant $(index(plant)) from a botanical " *
        "topology that already contains Phytomer nodes: AMAPSim's private " *
        "developmental state (bud histories, event queue, and random-number " *
        "state) cannot be reconstructed from the MTG. Reuse the live " *
        "simulation state, or omit parameters for scheduler-only composition " *
        "and geometry workflows.",
    )
end

function _outermost_seed_plant(node::Node)
    containing_plant = nothing
    current = node
    while !isnothing(current)
        symbol(current) == AMAPSIM_MTG_SYMBOLS.plant && (containing_plant = current)
        current = parent(current)
    end
    return containing_plant
end

function _validate_parameterized_plant_seed(
    plant::Node,
    parameters;
    context::AbstractString="parameterized build_model",
)
    isnothing(parameters) && return plant
    symbol(plant) == AMAPSIM_MTG_SYMBOLS.plant || throw(ArgumentError(
        "$context seed must be an AMAPSim Plant node",
    ))
    botanical_phytomer = findfirst(
        node -> symbol(node) == AMAPSIM_MTG_SYMBOLS.phytomer,
        traverse(plant, identity),
    )
    isnothing(botanical_phytomer) && return plant
    throw(_parameterized_plant_seed_error(plant, context))
end

function _validate_parameterized_model_seed(
    nodes::AbstractVector{<:Node},
    parameters,
)
    isnothing(parameters) && return nodes
    for node in nodes
        symbol(node) == AMAPSIM_MTG_SYMBOLS.phytomer || continue
        plant = _outermost_seed_plant(node)
        isnothing(plant) && continue
        throw(_parameterized_plant_seed_error(plant, "parameterized build_model"))
    end
    return nodes
end

function _validate_parameterized_model_seed(scene::Node, parameters)
    isnothing(parameters) && return scene
    nodes = traverse(scene, identity; type=typeof(scene))
    _validate_parameterized_model_seed(nodes, parameters)
    return scene
end

function _application_tuple(applications)
    applications === nothing && return ()
    applications isa Tuple && return applications
    applications isa AbstractVector && return Tuple(applications)
    return (applications,)
end

function _normalize_after_event_calls(after_event_calls)
    after_event_calls isa NamedTuple || throw(ArgumentError(
        "after_event_calls must be a named tuple of PlantSimEngine call selectors",
    ))
    return after_event_calls
end

function _coordinator_increment_selector(source)
    if isnothing(source)
        return PlantSimEngine.Many(
            scale=AMAPSIM_MTG_SYMBOLS.plant,
            within=PlantSimEngine.Subtree(),
            var=:development_increment,
            from_status=true,
        )
    end
    return PlantSimEngine.Many(
        scale=AMAPSIM_MTG_SYMBOLS.plant,
        within=PlantSimEngine.Subtree(),
        application=Symbol(source),
        var=:development_increment,
    )
end

"""
    build_model(source; development_increment, parameters=nothing, seed=0,
                rng_factory=nothing,
                axis_categories=nothing, category_initiation=nothing,
                time_type=Float64,
                applications=(), environment=nothing,
                coordinate_plants=false, development_increment_source=nothing,
                after_event_calls=NamedTuple(), before_growth_calls=NamedTuple(),
                growth_allocation_call=nothing, development_increment_contract=nothing)

Construct a PlantSimEngine `CompositeModel` over one AMAPSim topology, a shared
scene root, or several `AMAPSimTopology` handles belonging to the same scene.
The development increment is deliberately required: it is the amount added to
AMAPSim's legacy virtual developmental coordinate during one outer execution,
not an implicit calendar or thermal duration. Supply one real value, a
function of each plant node, or a dictionary keyed by plant index.

Supplying `parameters` initializes the main bud's botanical state and schedules
its first `:apical_growth` event. Parameterized initialization requires the
runtime-scaffold seed: an MTG that already contains botanical `Phytomer` nodes
does not retain the private bud history, event queue, or random-number state
needed to resume development and is rejected before statuses are attached.
Use one `AMAPSimParameters` value, a function, or a dictionary keyed by plant
index. A scalar `seed` derives independent per-plant streams by adding
`plant_index - 1`; functions and dictionaries supply explicit per-plant seeds.
An optional `rng_factory(seed)` supplies an `AbstractRNG` before the first
botanical initialization draw. The default is `Xoshiro(seed)`. The factory is
called once per parameterized plant and must return a separate mutable stream
for each plant. This supports controlled replay without replacing a stream
after initialization has already consumed it.
Omitting `parameters` retains the scheduler-only model used for composition,
custom event setup, and geometry workflows over an existing botanical MTG.

Supplying `axis_categories` enables one-time category assignment for emitted
child axes. `category_initiation` may be one reusable
`AbstractAxisCategoryInitiationModel`, a function of the plant node, or a
dictionary keyed by plant index. When omitted, `PhysiologicalAgeInitiation()`
maps the numeric child age to the unique matching category. Existing axes must
already carry a category from the supplied set.

Additional PlantSimEngine applications may be supplied through `applications`;
they use the same object registry and may produce `development_increment` in
the normal PlantSimEngine binding graph. Set `coordinate_plants=true` when
cross-plant effects require all due events to be merged chronologically. If an
additional application produces the increments in that mode, name it with
`development_increment_source` to make the scheduling dependency explicit.
Use `after_event_calls=(name=selector, ...)` to declare PlantSimEngine hard
calls owned by the coordinator. Each declared target runs after one globally
ordered event has updated the scene and before the next event is selected.

In per-plant mode, `before_growth_calls=(name=selector, ...)` declares hard
calls before a realized apical test creates its primary organ and its bearer
phytomer. Each intention identifies that organ, rather than a phytomer budget.
The architecture application exposes a transient `growth_intents` vector with
one immutable [`GrowthIntent`](@ref); targets must copy any retained records.
The slot is cleared after the calls, including on error. Calls use
`publish=false`; demand observation alone does not limit growth.
Lateral branching and final dimensions are not yet included in the intention.

Set `growth_allocation_call=One(...)` to opt into organ allocation. The target
must return one `organ_allocation_decisions` record with the exact `intent_key`,
boolean `realized` and finite nonnegative `allocated_gC`. A refused event remains
queued and is attempted at most once per outer execution; other buds continue.
Its potential apical state and draws are prepared once. After a complete event
succeeds, the same target settles the organ through `realized_growth_intents`.
It must debit only this settlement, never the provisional quote. Both slots
are transient and calls are non-publishing. An exceptional partial lifecycle or
settlement failure aborts the simulation and cannot be automatically retried.

The historical/abundant path keeps the original random stream. Under carbon
limitation, retries do not resample the apical intention, but reordering actual
creations can change later branching draws on the shared plant stream. This is
not a promise of identical limited and abundant stochastic trajectories.

`development_increment_contract` explicitly opts into a scientific contract
for an externally produced increment. The default retains the historical
uncontracted interface. These coupling options currently require per-plant mode.
"""
function build_model(
    scene::Node;
    development_increment,
    parameters=nothing,
    seed=0,
    rng_factory=nothing,
    axis_categories=nothing,
    category_initiation=nothing,
    time_type::Type{T}=Float64,
    applications=(),
    environment=nothing,
    coordinate_plants::Bool=false,
    development_increment_source=nothing,
    after_event_calls=NamedTuple(),
    before_growth_calls=NamedTuple(),
    growth_allocation_call=nothing,
    development_increment_contract=nothing,
) where {T<:Real}
    scene_nodes = _validated_model_scene_preorder(scene)
    _validate_parameterized_model_seed(scene_nodes, parameters)
    _validate_initial_axis_categories!(scene, axis_categories)
    isconcretetype(T) || throw(ArgumentError("time_type must be a concrete Real type"))
    application_tuple = _application_tuple(applications)
    normalized_after_event_calls = _normalize_after_event_calls(after_event_calls)
    before_growth_calls isa NamedTuple || throw(ArgumentError(
        "before_growth_calls must be a named tuple of PlantSimEngine call selectors",
    ))
    allocation_enabled = growth_allocation_call !== nothing
    allocation_enabled && haskey(before_growth_calls, :growth_allocation) && throw(ArgumentError(
        "growth_allocation is reserved for the allocation call",
    ))
    architecture_calls = allocation_enabled ?
        merge(before_growth_calls, (growth_allocation=growth_allocation_call,)) : before_growth_calls
    if coordinate_plants && (!isempty(before_growth_calls) || allocation_enabled || development_increment_contract !== nothing)
        throw(ArgumentError(
            "before_growth_calls, growth_allocation_call and development_increment_contract currently require per-plant mode",
        ))
    end
    architecture = if coordinate_plants
        PlantSimEngine.ModelSpec(
            ArchitectureCoordinator{T}(Tuple(keys(normalized_after_event_calls)));
            name=:architecture_development,
            on=PlantSimEngine.One(scale=AMAPSIM_MTG_SYMBOLS.scene),
            inputs=(
                :development_increments => _coordinator_increment_selector(
                    development_increment_source,
                ),
            ),
            calls=normalized_after_event_calls,
        )
    else
        isnothing(development_increment_source) || throw(ArgumentError(
            "development_increment_source is only needed with coordinate_plants=true",
        ))
        isempty(normalized_after_event_calls) || throw(ArgumentError(
            "after_event_calls requires coordinate_plants=true",
        ))
        PlantSimEngine.ModelSpec(
            ArchitectureDevelopment{T}(
                Tuple(keys(before_growth_calls)); development_increment_contract, allocation_enabled,
            );
            name=:architecture_development,
            on=PlantSimEngine.Many(scale=AMAPSIM_MTG_SYMBOLS.plant),
            calls=architecture_calls,
        )
    end
    status = _StatusInitializer{T}(
        development_increment,
        parameters,
        seed,
        axis_categories,
        category_initiation,
        rng_factory,
    )
    return PlantSimEngine.CompositeModel(
        scene;
        status=status,
        applications=(application_tuple..., architecture),
        environment=environment,
    )
end

function build_model(topology::AMAPSimTopology; kwargs...)
    return build_model(topology.scene; kwargs...)
end

function build_model(topologies::AbstractVector{<:AMAPSimTopology}; kwargs...)
    isempty(topologies) && throw(ArgumentError("at least one topology is required"))
    scene = first(topologies).scene
    all(topology -> topology.scene === scene, topologies) || throw(ArgumentError(
        "all topologies must belong to the same scene",
    ))
    return build_model(scene; kwargs...)
end
