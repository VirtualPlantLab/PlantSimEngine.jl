"""Length and top diameter computed for one realized AMAPSim internode."""
struct InternodeDimensions{T<:Real}
    length::T
    diameter::T
end

"""
    SympodialTransition(deviates, planar)

Result of one legacy sympody trial. `planar` records the mode encoded by a
negative source probability and remains meaningful even when the Bernoulli
trial does not produce a deviation.
"""
struct SympodialTransition
    deviates::Bool
    planar::Bool
end

"""Target vertical direction and per-internode conicity for one bent axis."""
struct AxisBendingInitialization{T<:Real}
    target_direction_z::T
    conicity_per_internode::T
end

"""Per-axis flexion increment used inside the terminal straightening zone."""
struct TerminalStraighteningState{T<:Real}
    increment::T
end

"""Result of one terminal-straightening state transition."""
struct TerminalStraighteningStep{T<:Real}
    bending_increment::T
    state::TerminalStraighteningState{T}
end

function _geometry_input(value::Real, label::AbstractString)
    isfinite(value) || throw(ArgumentError("$label must be finite"))
    value >= 0 || throw(DomainError(value, "$label cannot be negative"))
    return value
end

function _maturation_factor(index_from_end, lag, zone, mature_ratio)
    _geometry_input(lag, "geometry maturation lag")
    _geometry_input(zone, "geometry maturation zone")
    isfinite(mature_ratio) || throw(ArgumentError(
        "geometry mature ratio must be finite",
    ))

    index_from_end >= lag + zone && return mature_ratio
    index_from_end < lag && return one(mature_ratio)
    iszero(zone) && return mature_ratio
    progress = (index_from_end - lag) / zone
    return one(mature_ratio) + progress * (mature_ratio - one(mature_ratio))
end

"""
    internode_dimensions(
        geometry, axis_initial_reference_age, current_reference_age,
        topology_position, index_from_theoretical_end,
    )

Compute the legacy AMAPSim length and top diameter of one internode. Ages and
positions use the normalized zero-based parameter coordinates. The initial
length and diameter are indexed by the axis's initial reference age, positional
ratios use the current growth unit's reference age, and maturation uses the
number of theoretical tests remaining above the internode.

The sign of `diameter_variation_ratio` selects the reference parameter age as
in the inspected source: a non-negative current value uses the axis's initial
reference age for all diameter-maturation controls, while a negative value uses
the current reference age and its absolute magnitude.
"""
function internode_dimensions(
    geometry::ParameterGroup,
    axis_initial_reference_age::Real,
    current_reference_age::Real,
    topology_position::Real,
    index_from_theoretical_end::Real,
)
    _geometry_input(axis_initial_reference_age, "axis initial reference age")
    _geometry_input(current_reference_age, "current reference age")
    _geometry_input(topology_position, "geometry topology position")
    _geometry_input(index_from_theoretical_end, "index from theoretical end")

    initial_length = valueat(
        geometry.initial_organ_length,
        axis_initial_reference_age,
    )
    length_ratio = valueat(
        geometry.initial_length_ratio_along_growth_unit,
        current_reference_age,
        topology_position,
    )
    length_factor = _maturation_factor(
        index_from_theoretical_end,
        valueat(geometry.length_variation_lag, current_reference_age),
        valueat(geometry.length_variation_zone, current_reference_age),
        valueat(geometry.length_variation_ratio, current_reference_age),
    )
    length = initial_length * length_ratio * length_factor

    initial_diameter = valueat(
        geometry.initial_organ_diameter,
        axis_initial_reference_age,
    )
    diameter_ratio = valueat(
        geometry.initial_diameter_ratio_along_growth_unit,
        current_reference_age,
        topology_position,
    )
    current_diameter_variation = valueat(
        geometry.diameter_variation_ratio,
        current_reference_age,
    )
    diameter_parameter_age = current_diameter_variation >= 0 ?
                             axis_initial_reference_age :
                             current_reference_age
    diameter_factor = _maturation_factor(
        index_from_theoretical_end,
        valueat(geometry.diameter_variation_lag, diameter_parameter_age),
        valueat(geometry.diameter_variation_zone, diameter_parameter_age),
        abs(valueat(
            geometry.diameter_variation_ratio,
            diameter_parameter_age,
        )),
    )
    diameter = initial_diameter * diameter_ratio * diameter_factor

    _geometry_input(length, "computed internode length")
    _geometry_input(diameter, "computed internode diameter")
    return InternodeDimensions(length, diameter)
end

internode_dimensions(
    parameters::AMAPSimParameters,
    axis_initial_reference_age::Real,
    current_reference_age::Real,
    topology_position::Real,
    index_from_theoretical_end::Real,
) = internode_dimensions(
    parameters.axis.geometry,
    axis_initial_reference_age,
    current_reference_age,
    topology_position,
    index_from_theoretical_end,
)

"""
    sample_sympodial_transition(rng, signed_probability; policy=StandardSampling())

Sample the source sympody law. The absolute value is the Bernoulli probability;
a negative sign requests a deviation constrained to one persistent plane.
"""
function sample_sympodial_transition(
    rng::AbstractRNG,
    signed_probability::Real;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    isfinite(signed_probability) || throw(ArgumentError(
        "signed sympodial probability must be finite",
    ))
    -1 <= signed_probability <= 1 || throw(DomainError(
        signed_probability,
        "signed sympodial probability must lie between minus one and one",
    ))
    probability = abs(signed_probability)
    return SympodialTransition(
        sample_bernoulli(rng, probability; policy),
        signed_probability < 0,
    )
end

"""
    sample_sympodial_direction_sign(rng; policy=StandardSampling())

Sample the source's equiprobable direction sign for one realized sympodial
deviation. The geometry stream is intentionally supplied separately from the
bud-development stream. The result is either `-1` or `1` and consumes exactly
one Bernoulli trial.
"""
function sample_sympodial_direction_sign(
    rng::AbstractRNG;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    return sample_bernoulli(rng, 0.5; policy) ? -1 : 1
end

"""
    sympodial_angle(geometry, reference_age, index_from_theoretical_end)

Compute the signed sympodial deviation angle at a unit boundary. The angle
changes linearly from `initial_sympodial_angle` at the theoretical tip to
`final_sympodial_angle` across `sympodial_angle_variation_zone`, then remains
at the final value. All angles are in radians and parameter coordinates are
zero based.
"""
function sympodial_angle(
    geometry::ParameterGroup,
    reference_age::Real,
    index_from_theoretical_end::Real,
)
    _geometry_input(reference_age, "sympodial reference age")
    _geometry_input(
        index_from_theoretical_end,
        "sympodial index from theoretical end",
    )
    initial_angle = valueat(geometry.initial_sympodial_angle, reference_age)
    final_angle = valueat(geometry.final_sympodial_angle, reference_age)
    variation_zone = valueat(
        geometry.sympodial_angle_variation_zone,
        reference_age,
    )
    all(isfinite, (initial_angle, final_angle, variation_zone)) || throw(
        ArgumentError("sympodial angle parameters must be finite"),
    )
    variation_zone >= 0 || throw(DomainError(
        variation_zone,
        "sympodial angle variation zone cannot be negative",
    ))
    if index_from_theoretical_end < variation_zone
        progress = index_from_theoretical_end / variation_zone
        return initial_angle * (one(progress) - progress) + final_angle * progress
    end
    return variation_zone > 0 ? final_angle : initial_angle
end

sympodial_angle(
    parameters::AMAPSimParameters,
    reference_age::Real,
    index_from_theoretical_end::Real,
) = sympodial_angle(
    parameters.axis.geometry,
    reference_age,
    index_from_theoretical_end,
)

const _LEGACY_HALF_DEGREE = 0.5 * 0.0174533

function _legacy_bending_target_z(
    compliance::Float64,
    direction_z::Float64,
    internode_count::Int,
    conicity_per_internode::Float64,
)
    direction_z = clamp(direction_z, -1.0, 1.0)
    theta = acos(direction_z)
    precision = 1.0
    angle_min = 0.0
    angle_max = π - theta
    denominator = 1.0 - conicity_per_internode * internode_count
    iszero(denominator) && throw(DomainError(
        denominator,
        "axis bending is singular when total conicity equals one",
    ))
    effective_length = abs(internode_count / denominator)
    coefficient = compliance * effective_length * sqrt(abs(direction_z))
    weak_case_score = coefficient * 200.0 / π
    deflection = if 1.553 < theta < 1.588
        compliance^2 * effective_length^2 / 2.0
    else
        sin(theta) * (1.0 - cos(coefficient)) /
        cos(coefficient) / abs(direction_z)
    end

    if weak_case_score <= 40.0 && deflection <= 0.2
        return cos(deflection + theta)
    end

    while angle_max - angle_min > _LEGACY_HALF_DEGREE
        deflection = (angle_max + angle_min) / 2.0
        omega = 0.0
        integrated_length = 0.0
        increment = 1.0
        iteration = 0
        while omega < deflection && increment != 0.0 && iteration < 500
            increment = precision * sqrt(2.0) * compliance * sqrt(abs(
                cos(theta + omega) - cos(theta + deflection),
            ))
            omega += increment
            integrated_length += precision
            iteration += 1
        end
        if integrated_length <= effective_length - precision
            angle_min = deflection
        else
            angle_max = deflection
        end
    end
    return cos((angle_min + angle_max) / 2.0 + theta)
end

"""
    initialize_axis_bending(
        young_modulus, direction_z, internode_count, conicity_ratio;
        young_multiplier=1,
    )

Initialize the inspected legacy mechanical-bending law for a multi-internode
axis. `direction_z` is the initial unit direction's world-Z component,
`internode_count` is the realized axis length in internodes, and
`conicity_ratio` is the source `rgconicite` value. `young_multiplier` exposes
the source's optional per-axis random Young-modulus adjustment without drawing
randomness in this pure kernel.

The returned target is a world-Z direction component, not an angle. This
unusual representation reproduces the C++ `bending` helper and is consumed by
[`axis_bending_increment`](@ref).
"""
function initialize_axis_bending(
    young_modulus::Real,
    direction_z::Real,
    internode_count::Integer,
    conicity_ratio::Real;
    young_multiplier::Real=1,
)
    all(isfinite, (young_modulus, direction_z, conicity_ratio, young_multiplier)) ||
        throw(ArgumentError("axis bending inputs must be finite"))
    young_modulus > 0 || throw(DomainError(
        young_modulus,
        "axis Young modulus must be positive",
    ))
    young_multiplier > 0 || throw(DomainError(
        young_multiplier,
        "axis Young-modulus multiplier must be positive",
    ))
    -1 <= direction_z <= 1 || throw(DomainError(
        direction_z,
        "axis initial direction_z must lie between minus one and one",
    ))
    internode_count > 0 || throw(DomainError(
        internode_count,
        "axis internode count must be positive",
    ))
    count = Int(internode_count)
    conicity = Float64(conicity_ratio) / count
    compliance = inv(sqrt(Float64(young_modulus) * Float64(young_multiplier)))
    target = _legacy_bending_target_z(
        compliance,
        Float64(direction_z),
        count,
        conicity,
    )
    return AxisBendingInitialization(target, conicity)
end

"""
    axis_bending_increment(
        initialization, current_direction_z, young_modulus,
        internode_index, internodes_in_growth_unit, axis_internode_count,
        inflexion_ratio,
    )

Compute the source flexion angle for one non-initial internode of a
multi-internode axis. Indices are zero based. The magnitude follows the target
vertical direction and conicity initialized by [`initialize_axis_bending`](@ref),
is divided across the current growth unit, and changes sign at the truncated
`inflexion_ratio * axis_internode_count` position. Terminal straightening is a
separate stateful override and is not applied by this kernel.
"""
function axis_bending_increment(
    initialization::AxisBendingInitialization,
    current_direction_z::Real,
    young_modulus::Real,
    internode_index::Integer,
    internodes_in_growth_unit::Integer,
    axis_internode_count::Integer,
    inflexion_ratio::Real,
)
    all(isfinite, (current_direction_z, young_modulus, inflexion_ratio)) ||
        throw(ArgumentError("axis bending increment inputs must be finite"))
    -1 <= current_direction_z <= 1 || throw(DomainError(
        current_direction_z,
        "current direction_z must lie between minus one and one",
    ))
    young_modulus > 0 || throw(DomainError(
        young_modulus,
        "axis Young modulus must be positive",
    ))
    internode_index >= 0 || throw(DomainError(
        internode_index,
        "axis internode index cannot be negative",
    ))
    internodes_in_growth_unit > 0 || throw(DomainError(
        internodes_in_growth_unit,
        "growth-unit internode count must be positive",
    ))
    axis_internode_count > 0 || throw(DomainError(
        axis_internode_count,
        "axis internode count must be positive",
    ))
    iszero(internode_index) && return 0.0

    direction_gap = max(
        2.0 * (Float64(current_direction_z) - initialization.target_direction_z),
        0.0,
    )
    taper = 1.0 - initialization.conicity_per_internode * internode_index
    iszero(taper) && throw(DomainError(
        taper,
        "axis bending is singular at this conicity and internode index",
    ))
    increment = sqrt(direction_gap) /
                (sqrt(Float64(young_modulus)) * taper^2) /
                Int(internodes_in_growth_unit)
    reversal_position = trunc(Int, abs(Float64(inflexion_ratio)) * axis_internode_count)
    internode_index > reversal_position - 1 && (increment = -increment)
    return increment
end

"""
    single_internode_bending_angle(organ_bending_angle, direction_z)

Compute the source `rgflexion` shortcut used for an axis containing a single
internode. Both arguments and the result are in the source convention:
`organ_bending_angle` is a signed angle in radians, while `direction_z` is the
initial unit direction's world-Z component. Applying geometric randomness and
rotating the local frame remain reconstruction concerns.
"""
function single_internode_bending_angle(
    organ_bending_angle::Real,
    direction_z::Real,
)
    all(isfinite, (organ_bending_angle, direction_z)) || throw(ArgumentError(
        "single-internode bending inputs must be finite",
    ))
    -1 <= direction_z <= 1 || throw(DomainError(
        direction_z,
        "single-internode direction_z must lie between minus one and one",
    ))
    angle = Float64(organ_bending_angle)
    vertical = Float64(direction_z)
    return angle < 0 ? angle * (vertical - 1.0) : -angle * (vertical + 1.0)
end

"""
    initialize_terminal_straightening(
        direction_z, theoretical_tests_remaining,
        straightening_angle, straightening_zone,
    )

Initialize the stateful terminal-straightening law at the first internode of
an axis. `theoretical_tests_remaining` is the legacy `ntf` count after that
internode, `straightening_angle` is in radians, and `straightening_zone` is a
count. The source uses the smaller of the theoretical remainder and the zone,
with a denominator of one when that minimum is zero.
"""
function initialize_terminal_straightening(
    direction_z::Real,
    theoretical_tests_remaining::Integer,
    straightening_angle::Real,
    straightening_zone::Real,
)
    all(isfinite, (direction_z, straightening_angle, straightening_zone)) ||
        throw(ArgumentError("terminal straightening inputs must be finite"))
    -1 <= direction_z <= 1 || throw(DomainError(
        direction_z,
        "terminal-straightening direction_z must lie between minus one and one",
    ))
    theoretical_tests_remaining >= 0 || throw(DomainError(
        theoretical_tests_remaining,
        "theoretical tests remaining cannot be negative",
    ))
    straightening_zone >= 0 || throw(DomainError(
        straightening_zone,
        "terminal straightening zone cannot be negative",
    ))

    denominator = min(
        Float64(theoretical_tests_remaining),
        Float64(straightening_zone),
    )
    iszero(denominator) && (denominator = 1.0)
    increment = (
        asin(Float64(direction_z)) - Float64(straightening_angle)
    ) / denominator
    return TerminalStraighteningState(increment)
end

"""
    apply_terminal_straightening(
        state, bending_increment, current_direction_z, actual_tests_from_end,
        straightening_angle, straightening_zone,
    )

Apply one non-initial internode transition of the legacy terminal-straightening
law. Outside the terminal zone, the ordinary `bending_increment` is unchanged.
At the zone boundary, a new state is computed from the current direction but
the ordinary increment is still returned. Closer to the tip, the stored state
overrides the ordinary increment. `actual_tests_from_end` is zero at the final
test position.
"""
function apply_terminal_straightening(
    state::TerminalStraighteningState,
    bending_increment::Real,
    current_direction_z::Real,
    actual_tests_from_end::Integer,
    straightening_angle::Real,
    straightening_zone::Real,
)
    all(isfinite, (
        state.increment,
        bending_increment,
        current_direction_z,
        straightening_angle,
        straightening_zone,
    )) || throw(ArgumentError("terminal straightening inputs must be finite"))
    -1 <= current_direction_z <= 1 || throw(DomainError(
        current_direction_z,
        "terminal-straightening direction_z must lie between minus one and one",
    ))
    actual_tests_from_end >= 0 || throw(DomainError(
        actual_tests_from_end,
        "actual tests from end cannot be negative",
    ))
    straightening_zone >= 0 || throw(DomainError(
        straightening_zone,
        "terminal straightening zone cannot be negative",
    ))

    increment = Float64(bending_increment)
    next_state = TerminalStraighteningState(Float64(state.increment))
    zone = Float64(straightening_zone)
    distance = Float64(actual_tests_from_end)
    if zone > 0 && distance <= zone
        if distance == zone
            next_increment = (
                asin(Float64(current_direction_z)) -
                Float64(straightening_angle)
            ) / zone
            next_state = TerminalStraighteningState(next_increment)
        else
            increment = next_state.increment
        end
    end
    return TerminalStraighteningStep(increment, next_state)
end

"""
    advance_phyllotaxy(current_angle, lateral, bearer_growth_unit_physiological_age)

Advance one lateral production's cumulative phyllotaxy after a bearer
internode. The inspected source indexes this particular curve with the growth
unit's one-based physiological age.
"""
function advance_phyllotaxy(
    current_angle::Real,
    lateral::LateralProductionParameters,
    bearer_growth_unit_physiological_age::Real,
)
    isfinite(current_angle) || throw(ArgumentError(
        "current phyllotaxy angle must be finite",
    ))
    _geometry_input(
        bearer_growth_unit_physiological_age,
        "bearer growth-unit physiological age",
    )
    step = valueat(
        lateral.global_parameters.phyllotaxy_angle,
        bearer_growth_unit_physiological_age,
    )
    isfinite(step) || throw(ArgumentError("phyllotaxy step must be finite"))
    return current_angle + step
end

"""
    branch_azimuth(
        current_phyllotaxy, lateral, bearer_reference_age, slot, slot_count;
        initial_angle=0,
    )

Compute a child axis's normalized azimuth from the bearer's accumulated
phyllotaxy, the lateral production's phase angle, and its one-based position in
the axillary whorl. The result is in radians in `[0, 2π)`.
"""
function branch_azimuth(
    current_phyllotaxy::Real,
    lateral::LateralProductionParameters,
    bearer_reference_age::Real,
    slot::Integer,
    slot_count::Integer;
    initial_angle::Real=0.0,
)
    isfinite(current_phyllotaxy) || throw(ArgumentError(
        "current phyllotaxy angle must be finite",
    ))
    isfinite(initial_angle) || throw(ArgumentError(
        "initial phyllotaxy angle must be finite",
    ))
    _geometry_input(bearer_reference_age, "bearer reference age")
    slot_count > 0 || throw(DomainError(
        slot_count,
        "axillary whorl size must be positive",
    ))
    1 <= slot <= slot_count || throw(DomainError(
        slot,
        "axillary whorl slot must lie between one and the whorl size",
    ))
    phase = valueat(
        lateral.global_parameters.axillary_phase_angle,
        bearer_reference_age,
    )
    isfinite(phase) || throw(ArgumentError("axillary phase angle must be finite"))
    within_whorl = 2π * (slot - 1) / slot_count
    return mod(initial_angle + current_phyllotaxy + phase + within_whorl, 2π)
end

function _legacy_truncated_linear(
    first_position,
    first_value,
    last_position,
    last_value,
    position,
)
    first_position == last_position && return max(last_value, first_value)
    if last_position < first_position
        first_position, last_position = last_position, first_position
        first_value, last_value = last_value, first_value
    end
    position < first_position && return last_value
    position > last_position && return first_value
    weight = (position - first_position) / (last_position - first_position)
    return (one(weight) - weight) * last_value + weight * first_value
end

"""
    branch_insertion_angle(geometry, child_initial_reference_age, position_from_tip)

Compute the source insertion-angle maturation for a child axis. The unaged
angle is `initial_organ_insertion_angle`; after the configured lag it changes
linearly to that angle multiplied by `insertion_angle_variation_ratio`, then
stays at the mature value. `position_from_tip` is the caller's legacy
growth-unit position and may be negative for a newly delayed branch.
"""
function branch_insertion_angle(
    geometry::ParameterGroup,
    child_initial_reference_age::Real,
    position_from_tip::Real,
)
    _geometry_input(child_initial_reference_age, "child initial reference age")
    isfinite(position_from_tip) || throw(ArgumentError(
        "insertion-angle position from tip must be finite",
    ))
    initial_angle = valueat(
        geometry.initial_organ_insertion_angle,
        child_initial_reference_age,
    )
    variation_ratio = valueat(
        geometry.insertion_angle_variation_ratio,
        child_initial_reference_age,
    )
    lag = valueat(
        geometry.insertion_angle_variation_lag,
        child_initial_reference_age,
    )
    all(isfinite, (initial_angle, variation_ratio, lag)) || throw(ArgumentError(
        "insertion-angle parameters must be finite",
    ))
    mature_angle = initial_angle * variation_ratio
    position_from_tip > lag || return initial_angle
    interpolation_lag = _truncate_parameter_integer(
        lag,
        "insertion-angle variation lag",
    )
    interpolation_end = _truncate_parameter_integer(
        valueat(
            geometry.insertion_angle_variation_zone,
            child_initial_reference_age,
        ),
        "insertion-angle variation zone",
    )
    position = _truncate_parameter_integer(
        position_from_tip,
        "insertion-angle position from tip",
    )
    return _legacy_truncated_linear(
        interpolation_lag,
        mature_angle,
        interpolation_end,
        initial_angle,
        position,
    )
end

branch_insertion_angle(
    parameters::AMAPSimParameters,
    child_initial_reference_age::Real,
    position_from_tip::Real,
) = branch_insertion_angle(
    parameters.axis.geometry,
    child_initial_reference_age,
    position_from_tip,
)

"""
    randomized_insertion_angles(insertion_angle, phyllotaxy,
                                randomness_ratio, draw)

Apply the source insertion-mode-1 randomization using its shared per-axis draw.
The centered value `0.5 - draw` scales the insertion angle and adds a
`π * randomness_ratio` perturbation to phyllotaxy.
"""
function randomized_insertion_angles(
    insertion_angle::Real,
    phyllotaxy::Real,
    randomness_ratio::Real,
    draw::Real,
)
    for (name, value) in (
        ("insertion angle", insertion_angle),
        ("phyllotaxy", phyllotaxy),
        ("geometric randomness ratio", randomness_ratio),
        ("geometry random draw", draw),
    )
        isfinite(value) || throw(ArgumentError("$name must be finite"))
    end
    0 <= draw <= 1 || throw(DomainError(
        draw,
        "geometry random draw must lie between zero and one",
    ))
    centered_draw = 0.5 - draw
    return (
        insertion_angle=Float64(insertion_angle) *
                        (1.0 + Float64(randomness_ratio) * centered_draw),
        phyllotaxy=Float64(phyllotaxy) +
                    π * Float64(randomness_ratio) * centered_draw,
    )
end

"""
    random_absolute_insertion_angles(draw)

Return the source insertion-mode-7 angles from its shared fourth geometry draw.
The same centered value supplies an insertion angle in `[-π/2, π/2]` and a
phyllotaxy angle in `[-π, π]`, independently of the configured geometric
randomness ratio.
"""
function random_absolute_insertion_angles(draw::Real)
    isfinite(draw) || throw(ArgumentError("geometry random draw must be finite"))
    0 <= draw <= 1 || throw(DomainError(
        draw,
        "geometry random draw must lie between zero and one",
    ))
    centered_draw = 0.5 - Float64(draw)
    return (
        insertion_angle=π * centered_draw,
        phyllotaxy=2π * centered_draw,
    )
end

function _geometry_direction3(value, name::AbstractString)
    (value isa Tuple || value isa AbstractVector) || throw(ArgumentError(
        "$name must be a tuple or vector with three real components",
    ))
    length(value) == 3 || throw(ArgumentError(
        "$name must have exactly three components",
    ))
    components = Float64[]
    for component in value
        component isa Real && isfinite(component) || throw(ArgumentError(
            "$name components must be finite real numbers",
        ))
        push!(components, Float64(component))
    end
    LinearAlgebra.norm(components) > 0 || throw(DomainError(
        value,
        "$name cannot be the zero vector",
    ))
    return components
end

function _projected_secondary(direction, target)
    projected = target - LinearAlgebra.dot(target, direction) * direction
    if LinearAlgebra.dot(projected, projected) < 1.0e-4
        fallback = [1.0, 0.0, 0.0]
        projected = fallback -
                    LinearAlgebra.dot(fallback, direction) * direction
        if LinearAlgebra.dot(projected, projected) < eps(Float64)
            fallback = [0.0, 1.0, 0.0]
            projected = fallback -
                        LinearAlgebra.dot(fallback, direction) * direction
        end
    end
    return projected / LinearAlgebra.norm(projected)
end

function _rotate_around_axis(vector, axis, angle::Float64)
    cosine = cos(angle)
    sine = sin(angle)
    return vector * cosine +
           LinearAlgebra.cross(axis, vector) * sine +
           axis * LinearAlgebra.dot(axis, vector) * (1.0 - cosine)
end

"""
    light_directed_insertion_frame(direction, insertion_angle, light_direction;
                                   up_direction=(0.0, 0.0, 1.0))

Return the source insertion-mode-8 frame. The current axis direction is first
rotated by `insertion_angle` in the plane selected by `light_direction`; the
resulting secondary axis is then projected toward `up_direction`. Columns of
the returned matrix are the normalized direction, secondary, and normal axes.

The historical projection falls back to world `+X` when its squared norm is
below `1e-4`. This implementation retains that threshold and uses world `+Y`
only for the otherwise singular case where the direction is itself parallel to
world `+X`.
"""
function light_directed_insertion_frame(
    direction,
    insertion_angle::Real,
    light_direction;
    up_direction=(0.0, 0.0, 1.0),
)
    isfinite(insertion_angle) || throw(ArgumentError(
        "insertion angle must be finite",
    ))
    initial_direction = _geometry_direction3(direction, "axis direction")
    initial_direction /= LinearAlgebra.norm(initial_direction)
    light = _geometry_direction3(light_direction, "light direction")
    up = _geometry_direction3(up_direction, "up direction")

    light_secondary = _projected_secondary(initial_direction, light)
    rotation_axis = LinearAlgebra.cross(initial_direction, light_secondary)
    rotation_axis /= LinearAlgebra.norm(rotation_axis)
    realized_direction = _rotate_around_axis(
        initial_direction,
        rotation_axis,
        Float64(insertion_angle),
    )
    realized_direction /= LinearAlgebra.norm(realized_direction)
    realized_secondary = _projected_secondary(realized_direction, up)
    realized_normal = LinearAlgebra.cross(
        realized_direction,
        realized_secondary,
    )
    realized_normal /= LinearAlgebra.norm(realized_normal)
    return hcat(realized_direction, realized_secondary, realized_normal)
end

"""
    plagiotropic_phyllotaxy(phyllotaxy, branching_order,
                            bearer_internode_index, randomness_ratio, draw)

Return the source insertion-mode-2 phyllotaxy. Orders zero and one retain the
ordinary randomized phyllotaxy. Higher orders replace it with the zero-based
bearer internode index plus the shared centered random perturbation, scaled by
`π`.
"""
function plagiotropic_phyllotaxy(
    phyllotaxy::Real,
    branching_order::Integer,
    bearer_internode_index::Integer,
    randomness_ratio::Real,
    draw::Real,
)
    for (name, value) in (
        ("phyllotaxy", phyllotaxy),
        ("geometric randomness ratio", randomness_ratio),
        ("geometry random draw", draw),
    )
        isfinite(value) || throw(ArgumentError("$name must be finite"))
    end
    branching_order >= 0 || throw(DomainError(
        branching_order,
        "branching order cannot be negative",
    ))
    bearer_internode_index >= 0 || throw(DomainError(
        bearer_internode_index,
        "source bearer internode index cannot be negative",
    ))
    0 <= draw <= 1 || throw(DomainError(
        draw,
        "geometry random draw must lie between zero and one",
    ))
    centered_draw = 0.5 - Float64(draw)
    if branching_order < 2
        return Float64(phyllotaxy) +
               π * Float64(randomness_ratio) * centered_draw
    end
    return π * (
        Float64(bearer_internode_index) +
        Float64(randomness_ratio) * centered_draw
    )
end

"""
    pseudo_plagiotropic_phyllotaxy(phyllotaxy, bearer_vertical_direction)

Apply insertion-mode-5's nonlinear compression of phyllotaxy toward the
vertical planes at angles zero and `π`. `bearer_vertical_direction` is the
normalized bearer's dot product with world up and must lie in `[-1, 1]`.
"""
function pseudo_plagiotropic_phyllotaxy(
    phyllotaxy::Real,
    bearer_vertical_direction::Real,
)
    isfinite(phyllotaxy) || throw(ArgumentError("phyllotaxy must be finite"))
    isfinite(bearer_vertical_direction) || throw(ArgumentError(
        "bearer vertical direction must be finite",
    ))
    -1 <= bearer_vertical_direction <= 1 || throw(DomainError(
        bearer_vertical_direction,
        "bearer vertical direction must lie between -1 and 1",
    ))

    vertical = Float64(bearer_vertical_direction)
    compression = if abs(vertical) < 1e-4
        0.0
    else
        exponent = Int(ceil(abs(log10(abs(vertical)))))
        abs(vertical^exponent)
    end
    angle = mod(Float64(phyllotaxy), 2π)
    if angle < π / 2
        return angle * compression
    elseif angle < 3π / 2
        return π + (angle - π) * compression
    end
    return (angle - 2π) * compression
end

function _geometry_frame3(frame, name::AbstractString)
    frame isa AbstractMatrix || throw(ArgumentError(
        "$name must be a 3 × 3 matrix",
    ))
    size(frame) == (3, 3) || throw(ArgumentError(
        "$name must be a 3 × 3 matrix",
    ))
    all(value -> value isa Real && isfinite(value), frame) || throw(
        ArgumentError("$name must contain only finite real components"),
    )
    realized = Matrix{Float64}(frame)
    identity3 = Matrix{Float64}(LinearAlgebra.I, 3, 3)
    isapprox(realized' * realized, identity3; atol=1.0e-10, rtol=1.0e-10) ||
        throw(ArgumentError("$name must be orthonormal"))
    isapprox(LinearAlgebra.det(realized), 1.0; atol=1.0e-10, rtol=1.0e-10) ||
        throw(ArgumentError("$name must be a proper right-handed frame"))
    return realized
end

function _plagiotropic_reference_frame(direction, up_direction)
    main = _geometry_direction3(direction, "axis direction")
    main /= LinearAlgebra.norm(main)
    up = _geometry_direction3(up_direction, "up direction")
    up /= LinearAlgebra.norm(up)
    secondary = _projected_secondary(main, up)
    normal = LinearAlgebra.cross(main, secondary)
    normal /= LinearAlgebra.norm(normal)
    return hcat(main, secondary, normal)
end

function _rotate_geometry_frame(frame, axis, angle::Float64)
    return hcat((
        _rotate_around_axis(frame[:, column], axis, angle) for column in 1:3
    )...)
end

"""
    normal_axis_insertion_frame(bearer_frame, insertion_angle, phyllotaxy)

Return the source insertion-mode-1 frame. `bearer_frame` is a proper
orthonormal matrix whose columns are the bearer direction, secondary, and
normal axes. The source applies insertion around the bearer's normal axis and
then phyllotaxy around its direction axis.
"""
function normal_axis_insertion_frame(
    bearer_frame,
    insertion_angle::Real,
    phyllotaxy::Real,
)
    all(isfinite, (insertion_angle, phyllotaxy)) || throw(ArgumentError(
        "normal-axis insertion angles must be finite",
    ))
    bearer = _geometry_frame3(bearer_frame, "bearer frame")
    inserted = _rotate_geometry_frame(
        bearer,
        bearer[:, 3],
        -Float64(insertion_angle),
    )
    return _rotate_geometry_frame(
        inserted,
        bearer[:, 1],
        Float64(phyllotaxy),
    )
end

"""
    secondary_up_insertion_frame(
        bearer_frame, insertion_angle, phyllotaxy;
        up_direction=(0.0, 0.0, 1.0),
    )

Return the source insertion-mode-6 frame. The branch direction first follows
the mode-1 normal-axis insertion sequence, then the secondary axis is projected
toward world up without changing that direction.
"""
function secondary_up_insertion_frame(
    bearer_frame,
    insertion_angle::Real,
    phyllotaxy::Real;
    up_direction=(0.0, 0.0, 1.0),
)
    inserted = normal_axis_insertion_frame(
        bearer_frame,
        insertion_angle,
        phyllotaxy,
    )
    return _plagiotropic_reference_frame(inserted[:, 1], up_direction)
end

"""
    plagiotropic_insertion_frame(
        bearer_frame, insertion_angle, phyllotaxy;
        up_direction=(0.0, 0.0, 1.0),
    )

Return the source insertion-mode-2 frame. `bearer_frame` is a proper
orthonormal matrix whose columns are the bearer direction, secondary, and
normal axes. The source first levels the bearer frame toward world up, rotates
it around the bearer's original secondary and direction axes, and finally
levels the resulting branch frame again. This final leveling is what makes the
mode truly plagiotropic.
"""
function plagiotropic_insertion_frame(
    bearer_frame,
    insertion_angle::Real,
    phyllotaxy::Real;
    up_direction=(0.0, 0.0, 1.0),
)
    all(isfinite, (insertion_angle, phyllotaxy)) || throw(ArgumentError(
        "plagiotropic insertion angles must be finite",
    ))
    bearer = _geometry_frame3(bearer_frame, "bearer frame")
    leveled = _plagiotropic_reference_frame(bearer[:, 1], up_direction)
    inserted = _rotate_geometry_frame(
        leveled,
        bearer[:, 2],
        -Float64(insertion_angle),
    )
    inserted = _rotate_geometry_frame(
        inserted,
        bearer[:, 1],
        Float64(phyllotaxy),
    )
    return _plagiotropic_reference_frame(inserted[:, 1], up_direction)
end

"""
    pseudo_plagiotropic_insertion_frame(
        bearer_frame, insertion_angle, phyllotaxy;
        up_direction=(0.0, 0.0, 1.0),
    )

Return the source insertion-mode-5 frame after phyllotaxy has been compressed
with [`pseudo_plagiotropic_phyllotaxy`](@ref). The bearer is first leveled
toward world up, then rotated around that leveled secondary and the original
bearer direction. Unlike mode 2, the resulting roll is retained.
"""
function pseudo_plagiotropic_insertion_frame(
    bearer_frame,
    insertion_angle::Real,
    phyllotaxy::Real;
    up_direction=(0.0, 0.0, 1.0),
)
    all(isfinite, (insertion_angle, phyllotaxy)) || throw(ArgumentError(
        "pseudo-plagiotropic insertion angles must be finite",
    ))
    bearer = _geometry_frame3(bearer_frame, "bearer frame")
    leveled = _plagiotropic_reference_frame(bearer[:, 1], up_direction)
    inserted = _rotate_geometry_frame(
        leveled,
        leveled[:, 2],
        -Float64(insertion_angle),
    )
    return _rotate_geometry_frame(
        inserted,
        bearer[:, 1],
        Float64(phyllotaxy),
    )
end
