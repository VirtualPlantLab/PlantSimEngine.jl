"""Stable identifier allocated to a scheduled AMAPSim event."""
struct EventID
    value::UInt64
end

Base.show(io::IO, id::EventID) = print(io, "EventID(", id.value, ')')

"""
    BudEvent

A scheduled action for one bud. `sequence` records insertion order;
`process_id` persists across actions of the same bud in a legacy queue.
"""
struct BudEvent{T<:Real}
    id::EventID
    bud_id::UInt64
    time::T
    legacy_priority::Int
    sequence::UInt64
    process::Symbol
    process_id::UInt64
    legacy_order::Bool
end

BudEvent(id, bud_id, time::T, priority, sequence, process) where {T<:Real} =
    BudEvent{T}(id, bud_id, time, priority, sequence, process, UInt64(0), false)
BudEvent{T}(id, bud_id, time, priority, sequence, process) where {T<:Real} =
    BudEvent{T}(id, bud_id, time, priority, sequence, process, UInt64(0), false)

"""
    event_priority(event)

Return the queue ordering key. Insertion queues use
`(time, legacy_priority, sequence)`. Legacy queues use increasing time,
decreasing priority, decreasing persistent process ID, then decreasing sequence.
"""
function event_priority(event::BudEvent)
    event.legacy_order && return _event_queue_priority(event)
    return (event.time, event.legacy_priority, event.sequence)
end

function _event_queue_priority(event::BudEvent)
    event.legacy_order && return (
        event.time, ~event.legacy_priority, ~event.process_id, ~event.sequence,
    )
    return (event.time, event.legacy_priority, UInt64(0), event.sequence)
end

"""
    BudEventQueue{T}(; ordering=:insertion)

Create an empty event queue whose event times have concrete real type `T`.
The type is explicit because AMAPSim's final time representation is deferred.
`ordering=:legacy` reproduces the historical scheduler's persistent bud process
order. The default preserves the public insertion-order queue contract.
"""
mutable struct BudEventQueue{T<:Real}
    priorities::PriorityQueue{EventID,Tuple{T,Int,UInt64,UInt64}}
    events::Dict{EventID,BudEvent{T}}
    next_event_id::UInt64
    next_sequence::UInt64
    process_ids::Dict{UInt64,UInt64}
    next_process_id::UInt64
    legacy_order::Bool
end

function BudEventQueue{T}(; ordering::Symbol=:insertion) where {T<:Real}
    ordering in (:insertion, :legacy) || throw(ArgumentError(
        "event ordering must be :insertion or :legacy",
    ))
    return BudEventQueue{T}(
        PriorityQueue{EventID,Tuple{T,Int,UInt64,UInt64}}(),
        Dict{EventID,BudEvent{T}}(),
        UInt64(1),
        UInt64(1),
        Dict{UInt64,UInt64}(),
        UInt64(1),
        ordering === :legacy,
    )
end

Base.length(queue::BudEventQueue) = length(queue.events)
Base.isempty(queue::BudEventQueue) = isempty(queue.events)
Base.haskey(queue::BudEventQueue, id::EventID) = haskey(queue.events, id)
Base.getindex(queue::BudEventQueue, id::EventID) = queue.events[id]

function _take_counter!(queue::BudEventQueue, field::Symbol)
    value = getfield(queue, field)
    value == typemax(UInt64) && throw(OverflowError("AMAPSim event counter exhausted"))
    setfield!(queue, field, value + UInt64(1))
    return value
end

function _validate_event_time(time::Real)
    isfinite(time) || throw(ArgumentError("event time must be finite"))
    time >= zero(time) || throw(DomainError(time, "event time cannot be negative"))
    return time
end

function _validate_bud_id(bud_id::Integer)
    bud_id >= 0 || throw(DomainError(bud_id, "bud ID cannot be negative"))
    bud_id <= typemax(UInt64) || throw(ArgumentError("bud ID is too large"))
    return UInt64(bud_id)
end

function _validate_legacy_priority(priority::Integer)
    typemin(Int) <= priority <= typemax(Int) ||
        throw(ArgumentError("legacy priority does not fit in Int"))
    return Int(priority)
end

function _validate_process(process::Symbol)
    isempty(String(process)) && throw(ArgumentError("event process cannot be empty"))
    return process
end

"""
    schedule_event!(queue, bud_id, time, process; legacy_priority=0)

Schedule an event and return its stable `EventID`. Equal time and priority ties
use the queue's ordering policy. A legacy bud keeps its process identity even
after popping or cancelling an event and scheduling a different action.
"""
function schedule_event!(
    queue::BudEventQueue{T},
    bud_id::Integer,
    time::T,
    process::Symbol;
    legacy_priority::Integer=0,
) where {T<:Real}
    _validate_event_time(time)
    normalized_bud_id = _validate_bud_id(bud_id)
    normalized_priority = _validate_legacy_priority(legacy_priority)
    _validate_process(process)

    id = EventID(_take_counter!(queue, :next_event_id))
    sequence = _take_counter!(queue, :next_sequence)
    process_id = get!(queue.process_ids, normalized_bud_id) do
        _take_counter!(queue, :next_process_id)
    end
    event = BudEvent(
        id, normalized_bud_id, time, normalized_priority, sequence, process,
        process_id, queue.legacy_order,
    )
    queue.events[id] = event
    queue.priorities[id] = _event_queue_priority(event)
    return id
end

"""Return the next event without removing it, or `nothing` for an empty queue."""
function peek_event(queue::BudEventQueue)
    isempty(queue) && return nothing
    id = first(queue.priorities).first
    return queue.events[id]
end

"""Remove and return the next event, or `nothing` for an empty queue."""
function pop_event!(queue::BudEventQueue)
    isempty(queue) && return nothing
    id = popfirst!(queue.priorities).first
    return pop!(queue.events, id)
end

"""Cancel `id`, returning the removed event or `nothing` when it is absent."""
function cancel_event!(queue::BudEventQueue, id::EventID)
    haskey(queue, id) || return nothing
    delete!(queue.priorities, id)
    return pop!(queue.events, id)
end

"""
    reschedule_event!(queue, id, time; legacy_priority=nothing)

Move an existing event while preserving its ID and persistent process identity.
Rescheduling allocates a new sequence number; the queue's policy resolves ties.
"""
function reschedule_event!(
    queue::BudEventQueue{T},
    id::EventID,
    time::T;
    legacy_priority::Union{Nothing,Integer}=nothing,
) where {T<:Real}
    haskey(queue, id) || throw(KeyError(id))
    _validate_event_time(time)
    previous = queue.events[id]
    priority = isnothing(legacy_priority) ?
               previous.legacy_priority :
               _validate_legacy_priority(legacy_priority)
    sequence = _take_counter!(queue, :next_sequence)
    event = BudEvent(
        id,
        previous.bud_id,
        time,
        priority,
        sequence,
        previous.process,
        previous.process_id,
        previous.legacy_order,
    )
    queue.events[id] = event
    queue.priorities[id] = _event_queue_priority(event)
    return event
end
