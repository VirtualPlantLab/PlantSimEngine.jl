"""Timing of one growth unit and each developmental test within it."""
struct GrowthUnitTiming{T<:Real}
    duration::T
    time_per_test::T
    test_count::Int
end

"""
    growth_unit_timing(growth, reference_age; rhythm=1)

Compute the legacy growth-unit duration
`1 / rhythm / local_growth_rhythm(reference_age)` and divide it by the
truncated maximum test count. `reference_age` is the zero-based age used by the
legacy axis-reference curves.
"""
function growth_unit_timing(
    growth::ParameterGroup,
    reference_age::Real;
    rhythm::Real=1.0,
)
    isfinite(reference_age) || throw(ArgumentError("reference age must be finite"))
    isfinite(rhythm) || throw(ArgumentError("growth rhythm must be finite"))
    rhythm > 0 || throw(DomainError(rhythm, "growth rhythm must be positive"))

    local_rhythm = valueat(growth.local_growth_rhythm, reference_age)
    isfinite(local_rhythm) ||
        throw(ArgumentError("local growth rhythm must be finite"))
    local_rhythm > 0 || throw(DomainError(
        local_rhythm,
        "local growth rhythm must be positive",
    ))
    raw_test_count = valueat(growth.maximum_test_count, reference_age)
    isfinite(raw_test_count) ||
        throw(ArgumentError("growth-unit test count must be finite"))
    raw_test_count >= 0 || throw(DomainError(
        raw_test_count,
        "growth-unit test count cannot be negative",
    ))
    raw_test_count <= typemax(Int) ||
        throw(ArgumentError("growth-unit test count is too large"))
    test_count = trunc(Int, raw_test_count)
    test_count > 0 || throw(DomainError(
        raw_test_count,
        "growth-unit test count must truncate to a positive integer",
    ))

    duration = inv(rhythm) / local_rhythm
    isfinite(duration) || throw(ArgumentError("growth-unit duration must be finite"))
    return GrowthUnitTiming(duration, duration / test_count, test_count)
end

growth_unit_timing(
    parameters::AMAPSimParameters,
    reference_age::Real;
    kwargs...,
) = growth_unit_timing(parameters.axis.growth, reference_age; kwargs...)

"""
    projected_axis_test_count(actual_test_count, growth_unit_test_count,
                              growth_unit_end_time, output_time,
                              growth_unit_duration; epsilon=1.0e-6)

Reproduce the legacy geometry horizon for an ended axis. Starting from the
realized axis test count, add the realized current-growth-unit test count once
for every complete hypothetical growth-unit interval between its recorded end
and the internal output clock. This law uses simulation-internal scheduling
values and does not define AMAPSim's future public time or stage semantics.
"""
function projected_axis_test_count(
    actual_test_count::Integer,
    growth_unit_test_count::Integer,
    growth_unit_end_time::Real,
    output_time::Real,
    growth_unit_duration::Real;
    epsilon::Real=1.0e-6,
)
    actual_test_count >= 0 || throw(DomainError(
        actual_test_count,
        "actual axis test count cannot be negative",
    ))
    growth_unit_test_count >= 0 || throw(DomainError(
        growth_unit_test_count,
        "growth-unit test count cannot be negative",
    ))
    for (name, value) in (
        ("growth-unit end time", growth_unit_end_time),
        ("output time", output_time),
        ("growth-unit duration", growth_unit_duration),
        ("projection epsilon", epsilon),
    )
        isfinite(value) || throw(ArgumentError("$name must be finite"))
    end
    growth_unit_duration > 0 || throw(DomainError(
        growth_unit_duration,
        "growth-unit duration must be positive",
    ))
    epsilon >= 0 || throw(DomainError(
        epsilon,
        "projection epsilon cannot be negative",
    ))

    projected = Int(actual_test_count)
    tests_per_interval = Int(growth_unit_test_count)
    instant, target, duration = promote(
        growth_unit_end_time,
        output_time,
        growth_unit_duration,
    )
    while instant < target - epsilon
        projected = Base.Checked.checked_add(projected, tests_per_interval)
        instant += duration
        isfinite(instant) || throw(ArgumentError(
            "projected growth-unit end time must remain finite",
        ))
    end
    return projected
end

"""Result of the two-state polycyclism transition and cycle-count draw."""
struct PolycyclismResult
    polycyclic::Bool
    cycle_count::Int
end

function _polycyclism_threshold(growth, reference_age, previous_state)
    if isnothing(previous_state)
        return valueat(growth.initial_polycyclism_probability, reference_age)
    elseif previous_state
        return 1 - valueat(growth.remaining_polycyclic_probability, reference_age)
    end
    return valueat(growth.remaining_monocyclic_probability, reference_age)
end

"""
    sample_polycyclism(rng, growth, reference_age, previous_state=nothing;
                       policy=StandardSampling())

Advance the legacy two-state polycyclism automaton. `previous_state` is
`nothing` for the first growth unit, `false` for monocyclic, and `true` for
polycyclic. A polycyclic result then samples two, three, four, or five cycles.
"""
function sample_polycyclism(
    rng::AbstractRNG,
    growth::ParameterGroup,
    reference_age::Real,
    previous_state::Union{Nothing,Bool}=nothing;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    threshold = _validate_probability(
        _polycyclism_threshold(growth, reference_age, previous_state),
    )
    remains_state_zero = sample_bernoulli(rng, threshold; policy=policy)
    polycyclic = !remains_state_zero
    polycyclic || return PolycyclismResult(false, 1)

    probabilities = [
        valueat(growth.two_cycle_probability, reference_age),
        valueat(growth.three_cycle_probability, reference_age),
        valueat(growth.four_cycle_probability, reference_age),
    ]
    fifth_probability = 1 - sum(probabilities)
    fifth_probability >= -8eps(Float64) || throw(DomainError(
        probabilities,
        "two-, three-, and four-cycle probabilities cannot sum above one",
    ))
    push!(probabilities, max(0.0, fifth_probability))
    cycle_count = sample_categorical(rng, probabilities; policy=policy) + 1
    return PolycyclismResult(true, cycle_count)
end

sample_polycyclism(
    rng::AbstractRNG,
    parameters::AMAPSimParameters,
    reference_age::Real,
    previous_state::Union{Nothing,Bool}=nothing;
    kwargs...,
) = sample_polycyclism(
    rng,
    parameters.axis.growth,
    reference_age,
    previous_state;
    kwargs...,
)

"""Parameters sampled when a new legacy growth cycle is initialized."""
struct CycleInitialization
    has_neoformed_zone::Bool
    preformed_test_count::Int
    preformed_internode_count::Int
    neoformed_test_lag::Int
    neoformed_maximum_test_count::Float64
    neoformed_test_probability::Float64
    neoformed_elongation_probability::Float64
end

function _cycle_parameter(growth, cycle_index, suffix)
    prefix = if cycle_index == 1
        :first_cycle
    elseif cycle_index == 2
        :second_cycle
    else
        :later_cycle
    end
    return getproperty(growth, Symbol(prefix, suffix))
end

function _truncate_parameter_integer(value::Real, name::AbstractString)
    isfinite(value) || throw(ArgumentError("$name must be finite"))
    typemin(Int) <= value <= typemax(Int) ||
        throw(ArgumentError("$name does not fit in Int"))
    return trunc(Int, value)
end

function _legacy_limit_preformation(prefn, prefd, maximum_test_count)
    if prefn + prefd > maximum_test_count
        if prefn > maximum_test_count
            prefn = Float64(maximum_test_count)
        else
            if prefd > maximum_test_count - prefn
                # Preserve CycleAMAP.cpp exactly. This replaces the shift with
                # the full count instead of merely filling the remainder.
                prefd = maximum_test_count
            else
                prefd = 0
            end
            prefn = 0.0
        end
    end
    return prefn, prefd
end

"""
    initialize_cycle(rng, growth, reference_age, cycle_index,
                     maximum_test_count; completed_test_count=0,
                     policy=StandardSampling())

Sample the preformed and neoformed settings of one growth cycle. `cycle_index`
is one-based: one and two select their dedicated legacy parameter families,
while later indices share the third family. For cycles after the first,
`completed_test_count` is removed from the available growth-unit tests.

The preformation cap deliberately preserves the exact `CycleAMAP.cpp`
behavior, including its counterintuitive handling of a shift that makes the
nominal test count exceed the available count.
"""
function initialize_cycle(
    rng::AbstractRNG,
    growth::ParameterGroup,
    reference_age::Real,
    cycle_index::Integer,
    maximum_test_count::Integer;
    completed_test_count::Integer=0,
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    isfinite(reference_age) || throw(ArgumentError("reference age must be finite"))
    1 <= cycle_index <= typemax(Int) ||
        throw(DomainError(cycle_index, "cycle index must be positive and fit in Int"))
    1 <= maximum_test_count <= typemax(Int) || throw(DomainError(
        maximum_test_count,
        "maximum test count must be positive and fit in Int",
    ))
    0 <= completed_test_count <= typemax(Int) || throw(DomainError(
        completed_test_count,
        "completed test count must be non-negative and fit in Int",
    ))

    available_test_count = Int(maximum_test_count)
    if cycle_index > 1
        completed_test_count <= available_test_count || throw(DomainError(
            completed_test_count,
            "completed test count cannot exceed maximum test count",
        ))
        available_test_count -= Int(completed_test_count)
    end

    has_neoformed_zone = sample_bernoulli(
        rng,
        valueat(
            _cycle_parameter(growth, cycle_index, :_two_zone_probability),
            reference_age,
        );
        policy=policy,
    )

    neoformed_test_lag = 0
    neoformed_maximum_test_count = 0.0
    neoformed_test_probability = 0.0
    neoformed_elongation_probability = 0.0
    prefn = if has_neoformed_zone
        neoformed_test_lag = _truncate_parameter_integer(
            valueat(
                _cycle_parameter(growth, cycle_index, :_neoformed_test_lag),
                reference_age,
            ),
            "neoformed test lag",
        )
        neoformed_test_lag >= 0 || throw(DomainError(
            neoformed_test_lag,
            "neoformed test lag cannot be negative",
        ))
        neoformed_maximum_test_count = Float64(valueat(
            _cycle_parameter(growth, cycle_index, :_neoformed_maximum_test_count),
            reference_age,
        ))
        neoformed_maximum_test_count >= 0 || throw(DomainError(
            neoformed_maximum_test_count,
            "neoformed maximum test count cannot be negative",
        ))
        neoformed_test_probability = Float64(_validate_probability(valueat(
            _cycle_parameter(growth, cycle_index, :_neoformed_test_probability),
            reference_age,
        )))
        neoformed_elongation_probability = Float64(_validate_probability(valueat(
            _cycle_parameter(growth, cycle_index, :_neoformed_elongation_probability),
            reference_age,
        )))
        valueat(
            _cycle_parameter(growth, cycle_index, :_secondary_preformed_test_count),
            reference_age,
        )
    else
        valueat(
            _cycle_parameter(growth, cycle_index, :_preformed_test_count),
            reference_age,
        )
    end
    prefp = valueat(
        _cycle_parameter(
            growth,
            cycle_index,
            has_neoformed_zone ?
                :_secondary_preformed_elongation_probability :
                :_preformed_elongation_probability,
        ),
        reference_age,
    )
    prefd = _truncate_parameter_integer(
        valueat(
            _cycle_parameter(
                growth,
                cycle_index,
                has_neoformed_zone ?
                    :_neoformed_distribution_shift :
                    :_preformed_distribution_shift,
            ),
            reference_age,
        ),
        "preformed distribution shift",
    )
    isfinite(prefn) || throw(ArgumentError("preformed test count must be finite"))
    prefn >= 0 ||
        throw(DomainError(prefn, "preformed test count cannot be negative"))
    prefn, prefd = _legacy_limit_preformation(
        Float64(prefn),
        prefd,
        available_test_count,
    )
    raw_preformed_test_count = prefn + prefd
    preformed_test_count = _truncate_parameter_integer(
        raw_preformed_test_count,
        "preformed test count",
    )
    preformed_internode_count = sample_shifted_count(
        rng,
        prefn,
        prefp,
        prefd;
        policy=policy,
    )

    return CycleInitialization(
        has_neoformed_zone,
        preformed_test_count,
        preformed_internode_count,
        neoformed_test_lag,
        neoformed_maximum_test_count,
        neoformed_test_probability,
        neoformed_elongation_probability,
    )
end

initialize_cycle(
    rng::AbstractRNG,
    parameters::AMAPSimParameters,
    reference_age::Real,
    cycle_index::Integer,
    maximum_test_count::Integer;
    kwargs...,
) = initialize_cycle(
    rng,
    parameters.axis.growth,
    reference_age,
    cycle_index,
    maximum_test_count;
    kwargs...,
)

"""Result of one neoformed-zone event in the legacy growth-cycle kernel."""
struct NeoformedTestResult
    started_zone::Bool
    created_test_site::Bool
    realized_internode::Bool
    ended_cycle::Bool
    test_index::Int
end

function _sample_neoformed_stop(
    rng,
    cycle::CycleInitialization;
    policy,
)
    eligible_tests = sample_shifted_count(
        rng,
        cycle.neoformed_maximum_test_count,
        cycle.neoformed_test_probability,
        0;
        policy=policy,
    )
    return sample_shifted_count(
        rng,
        eligible_tests,
        cycle.neoformed_elongation_probability,
        cycle.neoformed_test_lag;
        policy=policy,
    )
end

"""
    sample_neoformed_test(rng, cycle; zone_started=false,
                          completed_test_count=0,
                          policy=StandardSampling())

Sample one event in a neoformed zone. At zone entry the legacy implementation
first samples a nested shifted stopping count. A zero result ends the cycle
without creating a developmental test. Otherwise it creates the zone and
samples the current test realization, then independently resamples the stopping
count.
Subsequent tests repeat the realization and stopping draws.

`completed_test_count` counts only tests already created in the neoformed zone.
The result reports whether this event starts the zone, creates a developmental
site record, realizes the active program's botanical product, and ends the
cycle. The fields `created_test_site` and `realized_internode` retain legacy
kernel spellings for compatibility; they do not imply a public canonical
`TestSite` node or force the realized product to have symbol `:Internode`.
"""
function sample_neoformed_test(
    rng::AbstractRNG,
    cycle::CycleInitialization;
    zone_started::Bool=false,
    completed_test_count::Integer=0,
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    cycle.has_neoformed_zone || throw(ArgumentError(
        "cycle has no neoformed zone",
    ))
    0 <= completed_test_count <= typemax(Int) || throw(DomainError(
        completed_test_count,
        "completed neoformed test count must be non-negative and fit in Int",
    ))
    !zone_started && !iszero(completed_test_count) && throw(ArgumentError(
        "an unstarted neoformed zone cannot already contain tests",
    ))

    started_zone = false
    if !zone_started
        entry_stop = _sample_neoformed_stop(rng, cycle; policy=policy)
        iszero(entry_stop) && return NeoformedTestResult(
            false,
            false,
            false,
            true,
            0,
        )
        started_zone = true
    end

    test_index = Base.Checked.checked_add(Int(completed_test_count), 1)
    realized = test_index <= cycle.neoformed_test_lag || sample_bernoulli(
        rng,
        cycle.neoformed_elongation_probability;
        policy=policy,
    )
    stop = _sample_neoformed_stop(rng, cycle; policy=policy)
    return NeoformedTestResult(
        started_zone,
        true,
        realized,
        test_index >= stop,
        test_index,
    )
end

"""Initial proleptic growth-unit and test delays sampled for one bud."""
struct InitialDormancy
    growth_unit_delay::Int
    test_delay::Int
    dead::Bool
    ages_during_growth_unit_delay::Bool
end

_sample_geometric_successes(rng, ::StandardSampling, probability) =
    rand(rng, Geometric(1 - probability))

function _sample_test_dormancy(
    rng,
    trial_count,
    probability,
    lag;
    policy,
)
    probability = _validate_probability(probability)
    integer_lag = _truncate_parameter_integer(lag, "test dormancy lag")
    integer_lag >= 0 ||
        throw(DomainError(integer_lag, "test dormancy lag cannot be negative"))

    if trial_count > 0
        trial_count <= typemax(Int) ||
            throw(ArgumentError("test dormancy trial count is too large"))
        trials = ceil(Int, trial_count)
        successes = sample_binomial(rng, trials, probability; policy=policy)
        return Base.Checked.checked_add(integer_lag, successes), false
    elseif iszero(trial_count) && !iszero(probability)
        probability == one(probability) && return 0, true
        consecutive_successes = _sample_geometric_successes(
            rng,
            policy,
            probability,
        )
        return Base.Checked.checked_add(integer_lag, consecutive_successes), false
    elseif trial_count < 0
        sampled = sample_shifted_count(
            rng,
            trial_count,
            probability,
            integer_lag;
            policy=policy,
        )
        dead = sampled == 0xffff
        return Base.Checked.checked_add(sampled, integer_lag), dead
    end
    return integer_lag, false
end

"""
    sample_initial_dormancy(rng, growth, topology, reference_age;
                            policy=StandardSampling())

Sample the initial proleptic delay used by the inspected C++ revision. The
growth-unit delay starts at the truncated configured duration and extends by
Bernoulli successes up to the axis maximum growth-unit count. Test delay uses:

- a binomial law with `ceil(trial_count)` trials when the count is positive;
- a geometric run of successes when the count is zero and probability is
  strictly between zero and one;
- immediate bud death when that zero-count probability is one;
- the legacy negative-binomial branch when the count is negative;
- the configured lag alone when both count and probability are zero.

The negative branch deliberately adds the configured lag twice, matching
`initProlepticSleep()` calling shifted `binodec` and then adding the lag again.
"""
function sample_initial_dormancy(
    rng::AbstractRNG,
    growth::ParameterGroup,
    topology::ParameterGroup,
    reference_age::Real;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    isfinite(reference_age) || throw(ArgumentError("reference age must be finite"))
    maximum_growth_units = _truncate_parameter_integer(
        valueat(topology.maximum_growth_unit_count, reference_age),
        "maximum growth-unit count",
    )
    maximum_growth_units >= 0 || throw(DomainError(
        maximum_growth_units,
        "maximum growth-unit count cannot be negative",
    ))
    growth_unit_delay = _truncate_parameter_integer(
        valueat(growth.growth_unit_dormancy_duration, reference_age),
        "growth-unit dormancy duration",
    )
    growth_unit_delay >= 0 || throw(DomainError(
        growth_unit_delay,
        "growth-unit dormancy duration cannot be negative",
    ))
    growth_probability = _validate_probability(valueat(
        growth.growth_unit_dormancy_probability,
        reference_age,
    ))
    while growth_unit_delay < maximum_growth_units && sample_bernoulli(
        rng,
        growth_probability;
        policy=policy,
    )
        growth_unit_delay = Base.Checked.checked_add(growth_unit_delay, 1)
    end

    trial_count = valueat(growth.test_dormancy_trial_count, reference_age)
    test_probability = valueat(growth.test_dormancy_probability, reference_age)
    lag = valueat(growth.test_dormancy_lag, reference_age)
    test_delay, dead = _sample_test_dormancy(
        rng,
        trial_count,
        test_probability,
        lag;
        policy=policy,
    )
    ages_during_delay = valueat(
        growth.dormancy_aging_mode,
        reference_age,
    ) == 1
    return InitialDormancy(
        growth_unit_delay,
        test_delay,
        dead,
        ages_during_delay,
    )
end

sample_initial_dormancy(
    rng::AbstractRNG,
    parameters::AMAPSimParameters,
    reference_age::Real=parameters.initialization.initial_physiological_age - 1;
    kwargs...,
) = sample_initial_dormancy(
    rng,
    parameters.axis.growth,
    parameters.axis.topology,
    reference_age;
    kwargs...,
)

function _validate_development_count(value::Integer, name::AbstractString)
    0 <= value <= typemax(Int) || throw(DomainError(
        value,
        "$name must be non-negative and fit in Int",
    ))
    return Int(value)
end

"""
    mortality_position(topology, reference_age; counts...)

Return the zero-based basal position used by the legacy survival surface.
`topology_counting_base == 0` selects numerical developmental tests and any
other value selects realized phytomers/internodes. `topology_counting_unit ==
0` selects the growth unit, one selects the growth cycle, and any other value
selects the whole axis.

All keyword values are completed counts after the current event. A selected
count of zero therefore returns `-1`, which the reference treats as an
unconditionally surviving position.
"""
function mortality_position(
    topology::ParameterGroup,
    reference_age::Real;
    test_count_within_growth_unit::Integer,
    test_count_within_cycle::Integer,
    test_count_on_axis::Integer,
    internode_count_within_growth_unit::Integer,
    internode_count_within_cycle::Integer,
    internode_count_on_axis::Integer,
)
    counts = (
        test_growth_unit=_validate_development_count(
            test_count_within_growth_unit,
            "growth-unit test count",
        ),
        test_cycle=_validate_development_count(
            test_count_within_cycle,
            "growth-cycle test count",
        ),
        test_axis=_validate_development_count(test_count_on_axis, "axis test count"),
        internode_growth_unit=_validate_development_count(
            internode_count_within_growth_unit,
            "growth-unit internode count",
        ),
        internode_cycle=_validate_development_count(
            internode_count_within_cycle,
            "growth-cycle internode count",
        ),
        internode_axis=_validate_development_count(
            internode_count_on_axis,
            "axis internode count",
        ),
    )
    counting_base = _truncate_parameter_integer(
        valueat(topology.topology_counting_base, reference_age),
        "topology counting base",
    )
    counting_unit = _truncate_parameter_integer(
        valueat(topology.topology_counting_unit, reference_age),
        "topology counting unit",
    )
    count = if iszero(counting_base)
        iszero(counting_unit) ? counts.test_growth_unit :
        counting_unit == 1 ? counts.test_cycle : counts.test_axis
    else
        iszero(counting_unit) ? counts.internode_growth_unit :
        counting_unit == 1 ? counts.internode_cycle : counts.internode_axis
    end
    return count - 1
end

mortality_position(
    parameters::AMAPSimParameters,
    reference_age::Real;
    kwargs...,
) = mortality_position(parameters.axis.topology, reference_age; kwargs...)

"""
    sample_bud_survival(rng, topology, reference_age, position;
                        policy=StandardSampling())

Sample survival at `position` from the legacy two-dimensional probability
surface. Position `-1` survives without advancing the random stream, matching
`testBudDeath`. Other negative positions are rejected.
"""
function sample_bud_survival(
    rng::AbstractRNG,
    topology::ParameterGroup,
    reference_age::Real,
    position::Integer;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    position == -1 && return true
    position >= 0 || throw(DomainError(
        position,
        "mortality position must be -1 or non-negative",
    ))
    probability = valueat(topology.survival_probability, reference_age, position)
    return sample_bernoulli(rng, probability; policy=policy)
end

sample_bud_survival(
    rng::AbstractRNG,
    parameters::AMAPSimParameters,
    reference_age::Real,
    position::Integer;
    kwargs...,
) = sample_bud_survival(
    rng,
    parameters.axis.topology,
    reference_age,
    position;
    kwargs...,
)

"""Outcome of the legacy cycle-end mortality tail."""
struct CycleTailMortalityResult
    filled_test_count::Int
    sampled_survival_count::Int
    final_position::Int
    survived::Bool
    death_position::Union{Nothing,Int}
end

"""
    sample_cycle_tail_mortality(rng, topology, reference_age, position,
                                remaining_test_count;
                                policy=StandardSampling())

Fill the remaining theoretical tests after a cycle ends and sample survival at
each successive basal position until the first death. The reference continues
filling the test stack after death but performs no further survival draws.
"""
function sample_cycle_tail_mortality(
    rng::AbstractRNG,
    topology::ParameterGroup,
    reference_age::Real,
    position::Integer,
    remaining_test_count::Integer;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    position == -1 || position >= 0 || throw(DomainError(
        position,
        "mortality position must be -1 or non-negative",
    ))
    position <= typemax(Int) || throw(ArgumentError(
        "mortality position does not fit in Int",
    ))
    filled_test_count = _validate_development_count(
        remaining_test_count,
        "remaining cycle test count",
    )
    final_position = try
        Base.Checked.checked_add(Int(position), filled_test_count)
    catch error
        error isa OverflowError || rethrow()
        throw(ArgumentError("final mortality position does not fit in Int"))
    end
    survived = true
    sampled_survival_count = 0
    death_position = nothing
    current_position = Int(position)
    for _ in 1:filled_test_count
        current_position = Base.Checked.checked_add(current_position, 1)
        if survived
            survived = sample_bud_survival(
                rng,
                topology,
                reference_age,
                current_position;
                policy=policy,
            )
            sampled_survival_count = Base.Checked.checked_add(
                sampled_survival_count,
                1,
            )
            survived || (death_position = current_position)
        end
    end
    return CycleTailMortalityResult(
        filled_test_count,
        sampled_survival_count,
        final_position,
        survived,
        death_position,
    )
end

sample_cycle_tail_mortality(
    rng::AbstractRNG,
    parameters::AMAPSimParameters,
    reference_age::Real,
    position::Integer,
    remaining_test_count::Integer;
    kwargs...,
) = sample_cycle_tail_mortality(
    rng,
    parameters.axis.topology,
    reference_age,
    position,
    remaining_test_count;
    kwargs...,
)

@enum PruningAction begin
    RemoveTerminalGrowthUnit
    TotalAxisPruning
end

"""Outcome of one legacy progressive-pruning event."""
struct ProgressivePruningResult
    action::PruningAction
    total_pruning_probability::Float64
end

"""
    sample_progressive_pruning_step(rng, coefficient;
                                    has_growth_units=true,
                                    policy=StandardSampling())

Choose the action for one already-scheduled legacy progressive-pruning event.
The fractional part of `coefficient` is the probability of switching directly
to total axis pruning. Otherwise one terminal growth unit is removed. An empty
axis switches to total pruning without consuming randomness.

The coefficient's positive integer part only participates in the separate
legacy scheduling gate; it does not change this per-event selection law.
"""
function sample_progressive_pruning_step(
    rng::AbstractRNG,
    coefficient::Real;
    has_growth_units::Bool=true,
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    isfinite(coefficient) || throw(ArgumentError(
        "progressive pruning coefficient must be finite",
    ))
    coefficient >= 0 || throw(DomainError(
        coefficient,
        "progressive pruning coefficient cannot be negative",
    ))
    probability = Float64(coefficient - floor(coefficient))
    has_growth_units || return ProgressivePruningResult(
        TotalAxisPruning,
        probability,
    )
    total_pruning = sample_bernoulli(rng, probability; policy=policy)
    action = total_pruning ? TotalAxisPruning : RemoveTerminalGrowthUnit
    return ProgressivePruningResult(action, probability)
end

function sample_progressive_pruning_step(
    rng::AbstractRNG,
    topology::ParameterGroup,
    reference_age::Real;
    kwargs...,
)
    coefficient = valueat(topology.progressive_pruning_coefficient, reference_age)
    return sample_progressive_pruning_step(rng, coefficient; kwargs...)
end

sample_progressive_pruning_step(
    rng::AbstractRNG,
    parameters::AMAPSimParameters,
    reference_age::Real;
    kwargs...,
) = sample_progressive_pruning_step(
    rng,
    parameters.axis.topology,
    reference_age;
    kwargs...,
)

"""
    sample_shifted_count(rng, trial_count, probability, shift;
                         policy=StandardSampling())

Standard-sampling counterpart of the legacy `binodec` helper. A non-negative
trial count is rounded half upward and sampled as a binomial count. A negative
count requests a negative-binomial number of failures before `-trial_count`
successes. The integer-truncated shift is added in both cases.
"""
function sample_shifted_count(
    rng::AbstractRNG,
    trial_count::Real,
    probability::Real,
    shift::Real;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    isfinite(trial_count) || throw(ArgumentError("trial count must be finite"))
    isfinite(shift) || throw(ArgumentError("count shift must be finite"))
    _validate_probability(probability)
    typemin(Int) <= shift <= typemax(Int) ||
        throw(ArgumentError("count shift does not fit in Int"))
    integer_shift = trunc(Int, shift)

    count = if trial_count >= 0
        trial_count <= typemax(Int) - 0.5 ||
            throw(ArgumentError("trial count is too large"))
        trials = floor(Int, trial_count + 0.5)
        sample_binomial(rng, trials, probability; policy=policy)
    else
        sample_negative_binomial(rng, -trial_count, probability; policy=policy)
    end
    return Base.Checked.checked_add(count, integer_shift)
end

"""
    VigorState

Zero-based physiological-age state used by the legacy differentiation kernel.
`remaining_growth_units` is the residence stock before the next transition.
"""
struct VigorState
    reference_age::Float64
    next_reference_age::Float64
    remaining_growth_units::Int
end

function _sample_legacy_shifted_count(rng, trial_count, probability, shift; policy)
    # Keep the public standard sampler's deterministic shortcuts. Historical
    # binodecf still consumes its CDF threshold at p=1; residence calls must
    # preserve that position in the botanical stream. Validate before drawing.
    count = sample_shifted_count(rng, trial_count, probability, shift; policy)
    if policy isa StandardSampling && trial_count < 0 && probability == 1
        rand(rng)
    end
    return count
end

function _vigor_residence(
    rng,
    differentiation,
    reference_age;
    policy,
)
    residence = _sample_legacy_shifted_count(
        rng,
        valueat(differentiation.nondifferentiation_trial_count, reference_age),
        valueat(differentiation.nondifferentiation_probability, reference_age),
        valueat(differentiation.nondifferentiation_shift, reference_age);
        policy=policy,
    )
    return residence == -1 ? 999_999 : residence
end

"""
    initial_vigor_state(rng, differentiation, physiological_age;
                        policy=StandardSampling())

Create the pre-differentiation vigor state for a one-based physiological age.
This mirrors the constructor's special handling of residence values `-1` and
zero, but does not yet perform the constructor's first differentiation call.
"""
function initial_vigor_state(
    rng::AbstractRNG,
    differentiation::ParameterGroup,
    physiological_age::Real;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    isfinite(physiological_age) ||
        throw(ArgumentError("physiological age must be finite"))
    physiological_age >= 1 ||
        throw(DomainError(physiological_age, "physiological age must be at least one"))
    reference_age = Float64(physiological_age - 1)
    residence = _vigor_residence(
        rng,
        differentiation,
        reference_age;
        policy=policy,
    )
    residence == 0 && (residence = 1)
    return VigorState(reference_age, reference_age, residence)
end

initial_vigor_state(
    rng::AbstractRNG,
    parameters::AMAPSimParameters,
    physiological_age::Real=parameters.initialization.initial_physiological_age;
    kwargs...,
) = initial_vigor_state(
    rng,
    parameters.axis.differentiation,
    physiological_age;
    kwargs...,
)

"""
    advance_vigor(rng, differentiation, state; policy=StandardSampling())

Advance the vigor residence stock by one growth unit. When it expires, sample
one of up to five signed legacy jumps, prevent physiological rejuvenation, and
sample the next residence stock.
"""
function advance_vigor(
    rng::AbstractRNG,
    differentiation::ParameterGroup,
    state::VigorState;
    policy::AbstractSamplingPolicy=StandardSampling(),
)
    reference_age = state.next_reference_age
    remaining = Base.Checked.checked_sub(state.remaining_growth_units, 1)
    remaining > 0 && return VigorState(reference_age, reference_age, remaining)

    raw_state_count = valueat(
        differentiation.differentiation_state_count,
        reference_age,
    )
    isfinite(raw_state_count) ||
        throw(ArgumentError("differentiation state count must be finite"))
    state_count = trunc(Int, raw_state_count)
    1 <= state_count <= 5 || throw(DomainError(
        raw_state_count,
        "differentiation state count must truncate to an integer from one to five",
    ))
    frequencies = [
        valueat(
            getproperty(differentiation, Symbol(:differentiation_state_, index, :_frequency)),
            reference_age,
        ) for index in 1:state_count
    ]
    selected = sample_categorical(rng, frequencies; policy=policy)
    jump = valueat(
        getproperty(
            differentiation,
            Symbol(:differentiation_state_, selected, :_physiological_age),
        ),
        reference_age,
    )
    next_reference_age = jump < 0 ? -jump - 1 : reference_age + jump
    next_reference_age = max(reference_age, next_reference_age)
    residence = _vigor_residence(
        rng,
        differentiation,
        next_reference_age;
        policy=policy,
    )
    return VigorState(reference_age, next_reference_age, residence)
end

advance_vigor(
    rng::AbstractRNG,
    parameters::AMAPSimParameters,
    state::VigorState;
    kwargs...,
) = advance_vigor(rng, parameters.axis.differentiation, state; kwargs...)
