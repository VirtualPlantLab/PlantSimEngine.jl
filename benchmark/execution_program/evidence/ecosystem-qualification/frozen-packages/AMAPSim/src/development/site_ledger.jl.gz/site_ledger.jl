"""Outcome of one numerical AMAPSim developmental test."""
@enum DevelopmentSiteOutcome::UInt8 begin
    RealizedDevelopmentSite = 1
    FailedDevelopmentSite = 2
    CycleTailDevelopmentSite = 3
end

"""
    DevelopmentSiteRecord{T}

Private, typed correspondence record for one numerical developmental test.

A record is not a botanical node. It retains the scheduling provenance and
legacy test ranks needed to explain a realized organ, a failed test, or a
cycle-tail test after public `TestSite` nodes are removed from the canonical
MTG. Node identifiers are the stable identifiers of the runtime MTG at the
time of materialization; `realized_object_id` is present only when the test
created its declared botanical product. The canonical Phytomer is that
product's parent, so this field keeps its v0.1 meaning while exposing the
botanical hierarchy without assuming that every product is an Internode.

Branching decisions are intentionally not copied into this immutable record:
delayed and traumatic scans may decide them during a later event. Their latest
live state belongs to the realized canonical Phytomer; emitted child axes are
the structural authority. Canonical v0.3 records leave `legacy_test_site_id`
empty. Legacy MTG normalization does not reconstruct runtime ledger rows.

The live developmental counters in `ApicalBudState` are the authority for
scheduling, ranks, and the next event. Records are appended only after the
corresponding topology mutation succeeds; they are an immutable audit
projection and are never read back to advance development. Scope-count MTG
attributes are likewise committed snapshots of those counters, not a second
source of developmental state.
"""
struct DevelopmentSiteRecord{T<:Real}
    event_id::EventID
    trace_index::Int
    event_process::Symbol
    bud_id::UInt64
    time::T
    axis_id::UInt64
    growth_unit_id::UInt64
    cycle_id::UInt64
    zone_id::UInt64
    zone_kind::Symbol
    zone_test_index::Int
    growth_unit_test_index::Int
    cycle_test_index::Int
    axis_test_index::Int
    growth_unit_internode_index::Int
    cycle_internode_index::Int
    axis_internode_index::Int
    outcome::DevelopmentSiteOutcome
    legacy_test_site_id::Union{Nothing,UInt64}
    realized_object_id::Union{Nothing,UInt64}
end

"""Private, node-independent description of one developmental test."""
struct _DevelopmentSiteSpecification
    zone_kind::Symbol
    zone_test_index::Int
    growth_unit_test_index::Int
    cycle_test_index::Int
    axis_test_index::Int
    growth_unit_internode_index::Int
    cycle_internode_index::Int
    axis_internode_index::Int
    outcome::DevelopmentSiteOutcome
end

"""
Private compact plan for the main developmental test and its cycle-tail tests.

All ranks are validated before public MTG mutation. Tail specifications are
derived on demand so the execution path does not allocate a second vector of
records or descriptors.
"""
struct _DevelopmentSiteBatch
    main_outcome::Union{Nothing,DevelopmentSiteOutcome}
    zone_kind::Symbol
    base_zone_test_index::Int
    base_growth_unit_test_index::Int
    base_cycle_test_index::Int
    base_axis_test_index::Int
    growth_unit_internode_index::Int
    cycle_internode_index::Int
    axis_internode_index::Int
    tail_count::Int
end
