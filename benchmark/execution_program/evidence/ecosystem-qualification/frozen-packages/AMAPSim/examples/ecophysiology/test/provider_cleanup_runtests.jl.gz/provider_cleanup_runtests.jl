# Included inside TwoPlantValidation; provider-only lifecycle tests need no
# simulation run and keep raw source-local IDs independent of runtime IDs.
@testset "Geometry provenance releases removed organs without ID reuse" begin
    geometry = D.DynamicLightGeometry
    setup = E.scenario()
    provider = setup.provider
    topologies = setup.topologies
    first_map, second_map = provider.source_ids
    old_highwaters = copy(provider.source_id_highwaters)

    leaves = [Node(topology.internode, NodeMTG(:+, :Leaf, 1, 5),
        Dict(:Length => 1.0, :Width => 0.5, :Thickness => 0.0))
        for topology in topologies]
    geometry._extend_source_ids!(topologies, provider.source_ids,
        provider.source_id_highwaters)
    assigned = [provider.source_ids[i][leaves[i]] for i in 1:2]
    @test assigned == old_highwaters .+ 1
    @test assigned[1] == assigned[2] # independent source namespaces still overlap
    @test leaves[1] !== leaves[2]
    @test all(leaves[i][:source_topology_id] == assigned[i] for i in 1:2)

    prune!(leaves[1])
    @test haskey(first_map, leaves[1]) # retained only until accepted cleanup
    before_cleanup = copy(provider.source_id_highwaters)
    @test geometry.cleanup_source_ids!(provider) == 1
    @test !haskey(first_map, leaves[1])
    @test haskey(second_map, leaves[2])
    @test provider.source_id_highwaters == before_cleanup
    @test geometry.cleanup_source_ids!(provider) == 0
    @test all(node in Base.IdSet{Any}(traverse(topologies[i].plant, identity))
        for i in 1:2 for node in keys(provider.source_ids[i]))

    replacement = Node(topologies[1].internode, NodeMTG(:+, :Leaf, 2, 5),
        Dict(:Length => 1.0, :Width => 0.5, :Thickness => 0.0))
    geometry._extend_source_ids!(topologies, provider.source_ids,
        provider.source_id_highwaters)
    @test first_map[replacement] == assigned[1] + 1
    @test first_map[replacement] > assigned[1]
    @test second_map[leaves[2]] == assigned[2]
    @test provider.source_id_highwaters == [assigned[1] + 1, assigned[2]]
    @test !haskey(first_map, leaves[1])

    # An invalid later namespace must not clean, extend, or stamp an earlier one.
    prune!(replacement)
    pending = Node(topologies[1].internode, NodeMTG(:+, :Leaf, 3, 5), Dict{Symbol,Any}())
    second_keys = collect(keys(second_map))
    second_map[second_keys[2]] = second_map[second_keys[1]]
    snapshots = copy.(provider.source_ids)
    highwaters = copy(provider.source_id_highwaters)
    @test_throws ArgumentError geometry.cleanup_source_ids!(provider)
    @test_throws ArgumentError geometry._extend_source_ids!(topologies, provider.source_ids,
        provider.source_id_highwaters)
    @test provider.source_id_highwaters == highwaters
    @test all(provider.source_ids[i] == snapshots[i] for i in 1:2)
    @test !haskey(node_attributes(pending), :source_topology_id)

    # Overflow is also detected for every plant before committing any plan.
    second_map[second_keys[2]] = maximum(values(second_map)) + 1
    provider.source_id_highwaters[2] = typemax(Int)
    Node(topologies[2].internode, NodeMTG(:+, :Leaf, 2, 5), Dict{Symbol,Any}())
    snapshots = copy.(provider.source_ids)
    highwaters = copy(provider.source_id_highwaters)
    @test_throws OverflowError geometry._extend_source_ids!(topologies, provider.source_ids,
        provider.source_id_highwaters)
    @test provider.source_id_highwaters == highwaters
    @test all(provider.source_ids[i] == snapshots[i] for i in 1:2)
    @test !haskey(node_attributes(pending), :source_topology_id)
end
