using AMAPSim, PlantSimEngine, PlantBiophysics, Test
include(joinpath(@__DIR__, "..", "dynamic_growth.jl"))
using Serialization

const E = DynamicGrowthExample
const D = E.DynamicPhysiologyModels
const G = D.GrowthDemandModels

@testset "Dynamic physiology conversion and native metadata" begin
    dimension = D.LeafDimension()
    dimension_status = Status(; Width=2.0, PlantSimEngine.outputs_(dimension)...)
    PlantSimEngine.run!(dimension, dimension_status, nothing)
    @test dimension_status.d ≈ 0.02
    for invalid in (0.0, -1.0, Inf, NaN)
        dimension_status.Width = invalid
        previous = dimension_status.d
        @test_throws Exception PlantSimEngine.run!(dimension, dimension_status, nothing)
        @test dimension_status.d == previous
    end

    wrapped = D.SurfaceEnergyBalance(maxiter=30)
    native = wrapped.model
    @test native isa PlantBiophysics.Monteith
    @test PlantSimEngine.process(wrapped) == PlantSimEngine.process(native)
    @test PlantSimEngine.inputs_(wrapped) == PlantSimEngine.inputs_(native)
    @test PlantSimEngine.outputs_(wrapped) == PlantSimEngine.outputs_(native)
    @test PlantSimEngine.environment_inputs_(wrapped) == PlantSimEngine.environment_inputs_(native)
    @test PlantSimEngine.output_policy(typeof(wrapped)) == PlantSimEngine.output_policy(typeof(native))
    @test PlantSimEngine.timestep_hint(typeof(wrapped)) == PlantSimEngine.timestep_hint(typeof(native))
    contracts = PlantSimEngine.variable_contracts(wrapped)
    @test contracts.d == PlantSimEngine.variable_contracts(dimension).d
    @test contracts.Ra_SW_f == PlantSimEngine.variable_contracts(native).Ra_SW_f
    @test keys(PlantSimEngine.dep(wrapped)) == keys(PlantSimEngine.dep(native)) == (:photosynthesis,)

    leaf_carbon = D.LeafNetCarbon()
    leaf = Status(; A=10.0, area_m2=0.02, PlantSimEngine.outputs_(leaf_carbon)...)
    hour = (duration_seconds=3600.0,)
    PlantSimEngine.run!(leaf_carbon, leaf, hour)
    @test leaf.carbon_step_gC ≈ 0.00864
    leaf.A = -1.0
    PlantSimEngine.run!(leaf_carbon, leaf, hour)
    @test leaf.carbon_step_gC ≈ -0.000864
    @test leaf.carbon_step_gC < 0
    previous = leaf.carbon_step_gC
    leaf.area_m2 = 0.0
    @test_throws DomainError PlantSimEngine.run!(leaf_carbon, leaf, hour)
    @test leaf.carbon_step_gC == previous
    leaf.area_m2 = 0.02
    leaf.A = NaN
    @test_throws ArgumentError PlantSimEngine.run!(leaf_carbon, leaf, hour)
    @test leaf.carbon_step_gC == previous
    leaf.A = 1.0
    @test_throws DomainError PlantSimEngine.run!(leaf_carbon, leaf, (duration_seconds=-1.0,))
    @test leaf.carbon_step_gC == previous
    PlantSimEngine.run!(leaf_carbon, leaf, (duration_seconds=0.0,))
    @test iszero(leaf.carbon_step_gC)

    supply_model = D.PlantCarbonSupply()
    supply = Status(; leaf_carbon_gC=[0.2, -0.03, 0.1],
        PlantSimEngine.outputs_(supply_model)...)
    environment = (duration_seconds=3600.0, development_rate_per_second=0.5 / 3600.0)
    PlantSimEngine.run!(supply_model, supply, environment)
    @test supply.cumulative_carbon_supply_gC ≈ 0.3
    @test supply.cumulative_carbon_loss_gC ≈ 0.03
    @test supply.development_increment ≈ 0.5
    supply.leaf_carbon_gC = [0.0, -0.02]
    PlantSimEngine.run!(supply_model, supply, environment)
    @test supply.cumulative_carbon_supply_gC ≈ 0.3
    @test supply.cumulative_carbon_loss_gC ≈ 0.05
    previous = (supply.cumulative_carbon_supply_gC, supply.cumulative_carbon_loss_gC,
        supply.development_increment)
    supply.leaf_carbon_gC = [1.0, NaN]
    @test_throws ArgumentError PlantSimEngine.run!(supply_model, supply, environment)
    @test (supply.cumulative_carbon_supply_gC, supply.cumulative_carbon_loss_gC,
        supply.development_increment) == previous
    supply.leaf_carbon_gC = [1.0]
    @test_throws DomainError PlantSimEngine.run!(supply_model, supply,
        (duration_seconds=3600.0, development_rate_per_second=-1.0))
    @test (supply.cumulative_carbon_supply_gC, supply.cumulative_carbon_loss_gC,
        supply.development_increment) == previous
end

@testset "Photosynthetic carbon reserve uses the organ settlement ledger" begin
    allocator = D.PhotosyntheticReserveAllocation(initial_reserve_gC=0.02)
    demand = G.MassConstructionDemand(organs=(
        Internode=(potential_dry_mass_g=0.02, construction_cost_gC_per_gDM=0.5),
        Leaf=(potential_dry_mass_g=0.01, construction_cost_gC_per_gDM=0.5),
    ))
    intent = AMAPSim.GrowthIntent(ObjectId(:coupled_carbon_plant), UInt64(7),
        AMAPSim.EventID(UInt64(9)), 1, :Internode, 1, 0.5)
    status = Status(; growth_intents=[intent], realized_growth_intents=typeof(intent)[],
        demand_history=NamedTuple[], current_demand_gC=0.0,
        cumulative_carbon_supply_gC=0.0, cumulative_carbon_loss_gC=0.0,
        PlantSimEngine.outputs_(allocator)...)
    PlantSimEngine.run!(demand, status, nothing, nothing, nothing)
    PlantSimEngine.run!(allocator, status, nothing)
    @test only(status.organ_allocation_decisions).realized
    @test only(status.organ_allocation_decisions).allocated_gC ≈ 0.01
    @test status.remaining_carbon_gC == 0.02
    @test iszero(status.spent_carbon_gC)
    @test isempty(status.allocation_history)

    status.growth_intents = typeof(intent)[]
    status.realized_growth_intents = [intent]
    PlantSimEngine.run!(allocator, status, nothing)
    @test status.remaining_carbon_gC ≈ 0.01
    @test status.spent_carbon_gC ≈ 0.01
    @test length(status.allocation_history) == 1
    PlantSimEngine.run!(allocator, status, nothing)
    @test status.remaining_carbon_gC ≈ 0.01
    @test status.spent_carbon_gC ≈ 0.01
    @test length(status.allocation_history) == 1

    status.realized_growth_intents = typeof(intent)[]
    status.cumulative_carbon_supply_gC = 0.004
    status.cumulative_carbon_loss_gC = 0.003
    PlantSimEngine.run!(allocator, status, nothing)
    @test status.credited_carbon_supply_gC == 0.004
    @test status.paid_carbon_loss_gC == 0.003
    @test status.remaining_carbon_gC ≈ 0.011
    @test 0.02 + status.credited_carbon_supply_gC ≈
        status.remaining_carbon_gC + status.spent_carbon_gC + status.paid_carbon_loss_gC
    fields = keys(PlantSimEngine.outputs_(allocator))
    state() = deepcopy(NamedTuple{fields}(Tuple(getproperty(status, field) for field in fields)))
    previous = state()
    PlantSimEngine.run!(allocator, status, nothing)
    @test state() == previous
    status.cumulative_carbon_loss_gC = 1.0
    @test_throws "exhausts the carbon reserve" PlantSimEngine.run!(allocator, status, nothing)
    @test state() == previous
    status.cumulative_carbon_loss_gC = 0.002
    @test_throws "cannot decrease" PlantSimEngine.run!(allocator, status, nothing)
    @test state() == previous
    status.cumulative_carbon_loss_gC = 0.003
    status.cumulative_carbon_supply_gC = 0.001
    @test_throws "cannot decrease" PlantSimEngine.run!(allocator, status, nothing)
    @test state() == previous

    limited = D.PhotosyntheticReserveAllocation(initial_reserve_gC=0.005)
    limited_status = Status(; growth_intents=[intent], realized_growth_intents=typeof(intent)[],
        demand_history=copy(status.demand_history),
        cumulative_carbon_supply_gC=0.0, cumulative_carbon_loss_gC=0.0,
        PlantSimEngine.outputs_(limited)...)
    PlantSimEngine.run!(limited, limited_status, nothing)
    @test !only(limited_status.organ_allocation_decisions).realized
    @test iszero(limited_status.spent_carbon_gC)
    @test isempty(limited_status.allocation_history)
    limited_status.cumulative_carbon_supply_gC = 0.005
    PlantSimEngine.run!(limited, limited_status, nothing)
    @test only(limited_status.organ_allocation_decisions).realized
    @test iszero(limited_status.spent_carbon_gC)
end

@testset "Six native growth intervals close light, energy, carbon and architecture" begin
    result = E.run_example()
    @test length(result.frames) == 6
    @test getfield.(result.frames, :execution) == collect(1:6)
    @test isempty(first(result.frames).leaves_at_start)
    @test any(!isempty(frame.leaves_at_end) for frame in result.frames)
    @test result.provider.rebuild_count > 1
    @test !result.provider.seed_stem_used

    cumulative_supply = 0.0
    cumulative_loss = 0.0
    previous_leaf_end = first(result.frames).leaves_at_start
    for frame in result.frames
        @test Set(frame.leaves_at_start) == Set(previous_leaf_end)
        @test Set(getfield.(frame.leaves, :object_id)) == Set(frame.leaves_at_start)
        @test length(frame.leaves) == length(unique(getfield.(frame.leaves, :object_id)))
        newborn = setdiff(Set(frame.leaves_at_end), Set(frame.leaves_at_start))
        @test isempty(intersect(newborn, Set(getfield.(frame.leaves, :object_id))))
        for leaf in frame.leaves
            @test leaf.area_m2 > 0
            @test leaf.d > 0
            @test isfinite(leaf.aPPFD) && leaf.aPPFD >= 0
            @test isfinite(leaf.Ra_SW_f) && leaf.Ra_SW_f >= 0
            @test isfinite(leaf.sky_fraction) && 0 <= leaf.sky_fraction <= 2
            @test all(isfinite, (leaf.A, leaf.Gₛ, leaf.Tₗ, leaf.Rn, leaf.H, leaf.λE))
            @test 0 <= leaf.iterations < 30
            @test isapprox(leaf.Rn, leaf.H + leaf.λE; atol=1e-6, rtol=1e-7)
            @test leaf.carbon_step_gC ≈ leaf.A * leaf.area_m2 * 3600.0 * 12e-6
            cumulative_supply += max(leaf.carbon_step_gC, 0.0)
            cumulative_loss += max(-leaf.carbon_step_gC, 0.0)
        end
        plant = only(frame.plants)
        @test plant.positive_net_gC ≈ cumulative_supply
        @test plant.negative_net_gC ≈ cumulative_loss
        @test result.initial_reserve_gC + plant.positive_net_gC ≈
            plant.reserve_gC + plant.construction_gC + plant.negative_net_gC
        @test plant.reserve_gC >= 0
        @test plant.construction_gC >= 0
        previous_leaf_end = frame.leaves_at_end
    end
    all_leaves = [leaf for frame in result.frames for leaf in frame.leaves]
    @test any(leaf.carbon_step_gC > 0 for leaf in all_leaves)
    @test any(leaf.carbon_step_gC < 0 for leaf in all_leaves)
    dark = result.frames[5]
    @test !isempty(dark.leaves)
    @test all(iszero(leaf.aPPFD) && iszero(leaf.Ra_SW_f) for leaf in dark.leaves)
    @test all(leaf.A < 0 && leaf.carbon_step_gC < 0 for leaf in dark.leaves)

    # The last scene belongs to the interval's start. New organs born at its
    # end intentionally acquire radiative coverage on the following interval.
    cache = getproperty(result.light_kernel, :runtime_cache)
    @test cache !== nothing
    @test Set(getproperty(cache, :target_ids)) == Set(last(result.frames).leaves_at_start)
    owner_map = getproperty(cache, :owner_map)
    source_ids = Dict(leaf.object_id => leaf.source_node_id for leaf in last(result.frames).leaves)
    for (id, source_id) in source_ids
        matching = [owner for owner in keys(owner_map) if owner_map[owner] == id]
        @test !isempty(matching)
        @test all(owner.source_node_id == source_id && owner.source_instance_id > 0
            for owner in matching)
    end
    @test PlantSimEngine.variable_contracts(result.light_kernel).area == D.ORGAN_AREA_CONTRACT
    @test PlantSimEngine.variable_contracts(result.light_kernel).aPPFD ==
        PlantSimEngine.variable_contracts(PlantBiophysics.Fvcb()).aPPFD
    @test PlantSimEngine.variable_contracts(result.light_kernel).Ra_SW_f ==
        PlantSimEngine.variable_contracts(D.SurfaceEnergyBalance()).Ra_SW_f

    # Geometry and physiology must not consume or reorder architecture draws
    # when the carbon reserve finances every historical growth event.
    legacy_topology = AMAPSim.build_initial_topology(E.synthetic_parameters())
    legacy = AMAPSim.build_model(legacy_topology; parameters=E.synthetic_parameters(),
        seed=7, development_increment=0.5)
    PlantSimEngine.run!(legacy; steps=6, outputs=:none)
    coupled_plant = only(model_objects(result.model; scale=:Plant)).status
    legacy_plant = only(model_objects(legacy; scale=:Plant)).status
    @test coupled_plant.event_trace == legacy_plant.event_trace
    @test coupled_plant.processed_events == legacy_plant.processed_events
    @test coupled_plant.development_time == legacy_plant.development_time
    @test length(coupled_plant.bud_states) == length(legacy_plant.bud_states)
    @test AMAPSim.topology_signature(result.topology.scene) ==
        AMAPSim.topology_signature(legacy_topology.scene)
    state_fields(value) = (; (field => deepcopy(getfield(value, field))
        for field in fieldnames(typeof(value)))...)
    @test isequal(Dict(id => state_fields(state) for (id, state) in coupled_plant.bud_states),
        Dict(id => state_fields(state) for (id, state) in legacy_plant.bud_states))
    @test isequal(coupled_plant.development_sites, legacy_plant.development_sites)
    queue_state(queue) = (
        events=sort!(collect(values(queue.events)); by=AMAPSim.event_priority),
        next_event_id=queue.next_event_id, next_sequence=queue.next_sequence,
        process_ids=copy(queue.process_ids), next_process_id=queue.next_process_id,
        legacy_order=queue.legacy_order,
    )
    @test isequal(queue_state(coupled_plant.event_queue), queue_state(legacy_plant.event_queue))
    @test coupled_plant.last_event_id == legacy_plant.last_event_id

    bindings = PlantSimEngine.Diagnostics.explain_bindings(result.simulation)
    for (application, input) in (
        (:growth_demand, :growth_intents),
        (:growth_allocation, :growth_intents),
        (:growth_allocation, :realized_growth_intents),
        (:growth_allocation, :demand_history),
    )
        rows = filter(row -> row.application_id == application && row.input == input, bindings)
        @test length(rows) == 1
        @test only(rows).carrier_hint == :shared_ref
        @test only(rows).copy_semantics == :live_references
    end
    carbon_A = filter(row -> row.application_id == :leaf_carbon && row.input == :A, bindings)
    @test !isempty(carbon_A)
    @test all(row.source_application_ids == [:energy_balance] && row.policy isa HoldLast
        for row in carbon_A)
    schedule = Dict(row.application_id => row for row in
        PlantSimEngine.Diagnostics.explain_schedule(result.simulation))
    @test schedule[:archimed_light].root_scheduled
    @test schedule[:coupled_interval].root_scheduled
    @test all(schedule[application].manual_call_only for application in (
        :energy_balance, :photosynthesis, :stomatal_conductance, :leaf_carbon,
        :carbon_supply, :architecture_development, :growth_demand, :growth_allocation,
    ))
    # Serialization compares the complete RNG state without advancing it.
    rng_bytes(rng) = let buffer=IOBuffer()
        Serialization.serialize(buffer, copy(rng))
        take!(buffer)
    end
    @test rng_bytes(coupled_plant.rng) == rng_bytes(legacy_plant.rng)
end


@testset "Photosynthesis funds later organs under a limited reserve" begin
    result = E.run_example(initial_reserve_gC=0.000175,
        weather=E.forcing(par=(450.0, 450.0, 450.0, 450.0)))
    @test length(result.frames) == 4
    @test any(!isempty(frame.leaves) for frame in result.frames)
    @test any(only(frame.plants).deferred_attempts > 0 for frame in result.frames)
    final = only(last(result.frames).plants)
    @test final.positive_net_gC > 0
    @test final.construction_gC > result.initial_reserve_gC
    for frame in result.frames
        plant = only(frame.plants)
        @test plant.reserve_gC >= 0
        @test result.initial_reserve_gC + plant.positive_net_gC ≈
            plant.reserve_gC + plant.construction_gC + plant.negative_net_gC
        @test Set(getfield.(frame.leaves, :object_id)) == Set(frame.leaves_at_start)
        @test isempty(intersect(setdiff(Set(frame.leaves_at_end), Set(frame.leaves_at_start)),
            Set(getfield.(frame.leaves, :object_id))))
    end
    status = only(model_objects(result.model; scale=:Plant)).status
    demand_keys = [row.intent_key for row in status.demand_history]
    committed_keys = [row.intent_key for row in status.allocation_history]
    @test length(demand_keys) == length(unique(demand_keys))
    @test length(committed_keys) == length(unique(committed_keys))
    @test all(key in demand_keys for key in committed_keys)
    @test sum(row.allocated_gC for row in status.allocation_history) ≈ status.spent_carbon_gC
end

@testset "An unfunded seed cannot assimilate through nonexistent leaves" begin
    result = E.run_example(initial_reserve_gC=0.0,
        weather=E.forcing(par=(450.0, 450.0)))
    @test length(result.frames) == 2
    @test all(isempty(frame.leaves_at_start) && isempty(frame.leaves) &&
        isempty(frame.leaves_at_end) for frame in result.frames)
    @test all(iszero(only(frame.plants).positive_net_gC) &&
        iszero(only(frame.plants).negative_net_gC) &&
        iszero(only(frame.plants).construction_gC) &&
        iszero(only(frame.plants).reserve_gC) for frame in result.frames)
    status = only(model_objects(result.model; scale=:Plant)).status
    @test isempty(status.allocation_history)
    @test !isempty(status.demand_history)
    @test status.deferred_growth_count > 0
    @test length(status.demand_history) == length(unique(row.intent_key for row in status.demand_history))
end
