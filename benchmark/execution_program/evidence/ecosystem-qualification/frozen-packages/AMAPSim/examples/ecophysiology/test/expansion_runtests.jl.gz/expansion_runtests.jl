# Included inside TwoPlantValidation, which supplies the shared example helpers.
const X = D.OrganExpansionModels
const EXPANSION = (maturation_seconds=7200.0, birth_fraction=0.25)

function native_potential_dimensions(model)
    result = Dict{PlantSimEngine.ObjectId,NamedTuple}()
    for scale in (:Internode, :Leaf), object in model_objects(model; scale)
        s = object.status
        result[object.id] = (Length=s.Length, Width=s.Width, Thickness=s.Thickness)
    end
    return result
end

function expansion_output_state(model, status)
    fields = keys(PlantSimEngine.outputs_(model))
    return deepcopy(NamedTuple{fields}(Tuple(getproperty(status, field) for field in fields)))
end

function check_expansion_frames(result)
    seen = Set{PlantSimEngine.ObjectId}()
    previous = Dict{PlantSimEngine.ObjectId,NamedTuple}()
    for frame in result.frames
        @test length(frame.expansion) == length(unique(organ.object_id for organ in frame.expansion))
        @test frame.geometry_invalidated == any(organ.changed for organ in frame.expansion)
        for leaf in frame.leaves
            @test haskey(previous, leaf.object_id)
            @test leaf.d ≈ previous[leaf.object_id].dimensions.Width * 0.01
        end
        for organ in frame.expansion
            @test organ.symbol in (:Internode, :Leaf)
            @test isfinite(organ.fraction) && 0.25 <= organ.fraction <= 1.0
            @test 0 <= organ.age_seconds <= 7200.0
            @test organ.fraction ≈ 0.25 + 0.75 * organ.age_seconds / 7200.0
            @test organ.deployed_construction_gC + organ.unexpanded_construction_gC ≈
                organ.prepaid_construction_gC
            @test organ.deployed_construction_gC ≈ organ.fraction * organ.prepaid_construction_gC
            @test organ.deployed_construction_gC >= 0
            @test organ.unexpanded_construction_gC >= 0
            if organ.object_id ∉ seen
                @test iszero(organ.age_seconds)
                @test organ.fraction == 0.25
                @test organ.changed
                push!(seen, organ.object_id)
            else
                old = previous[organ.object_id]
                @test organ.target == old.target
                @test organ.age_seconds == min(7200.0, old.age_seconds + 3600.0)
                @test organ.fraction >= old.fraction
            end
            s = model_status(result.model, organ.object_id)
            @test (Length=s.Length, Width=s.Width, Thickness=s.Thickness) == organ.target
            for name in (:Length, :Width, :Thickness)
                @test getproperty(organ.dimensions, name) ≈
                    getproperty(organ.target, name) * cbrt(organ.fraction)
            end
            previous[organ.object_id] = organ
        end
        for plant in frame.plants
            organs = filter(organ -> organ.plant_id == plant.object_id, frame.expansion)
            @test plant.deployed_construction_gC ≈
                sum(organ.deployed_construction_gC for organ in organs; init=0.0)
            @test plant.unexpanded_construction_gC ≈
                sum(organ.unexpanded_construction_gC for organ in organs; init=0.0)
            @test plant.deployed_construction_gC + plant.unexpanded_construction_gC ≈
                plant.construction_gC
        end
    end
    return nothing
end

@testset "Prepaid organ expansion follows explicit physical age" begin
    model = X.OrganExpansion(:Leaf; maturation_seconds=7200.0,
        birth_fraction=0.25, construction_cost_gC=0.04)
    status = Status(; Length=8.0, Width=2.0, Thickness=0.0,
        PlantSimEngine.outputs_(model)...)
    potential = (Length=status.Length, Width=status.Width, Thickness=status.Thickness)
    hour = (duration_seconds=3600.0,)
    PlantSimEngine.run!(model, status, hour)
    @test status.expansion_initialized
    @test status.expansion_age_seconds == 0.0
    @test status.expansion_fraction == 0.25
    @test status.expansion_changed
    @test status.expanded_length_cm ≈ 8.0 * cbrt(0.25)
    @test status.expanded_width_cm ≈ 2.0 * cbrt(0.25)
    @test iszero(status.expanded_thickness_cm)
    @test status.prepaid_construction_gC == 0.04
    @test status.deployed_construction_gC ≈ 0.01
    @test status.unexpanded_construction_gC ≈ 0.03

    for (age, fraction) in ((3600.0, 0.625), (7200.0, 1.0))
        PlantSimEngine.run!(model, status, hour)
        @test status.expansion_age_seconds == age
        @test status.expansion_fraction == fraction
        @test status.expanded_length_cm ≈ 8.0 * cbrt(fraction)
        @test status.expanded_width_cm ≈ 2.0 * cbrt(fraction)
        @test status.target_length_cm == potential.Length
        @test status.target_width_cm == potential.Width
        @test status.target_thickness_cm == potential.Thickness
        @test (Length=status.Length, Width=status.Width, Thickness=status.Thickness) == potential
        @test status.deployed_construction_gC + status.unexpanded_construction_gC ≈ 0.04
        @test status.prepaid_construction_gC == 0.04
    end
    @test status.expanded_length_cm == status.Length
    @test status.expanded_width_cm == status.Width
    @test iszero(status.unexpanded_construction_gC)
    PlantSimEngine.run!(model, status, (duration_seconds=floatmax(Float64),))
    @test status.expansion_age_seconds == 7200.0
    @test status.expansion_fraction == 1.0
    @test !status.expansion_changed

    zero_duration = Status(; Length=8.0, Width=2.0, Thickness=0.1,
        PlantSimEngine.outputs_(model)...)
    PlantSimEngine.run!(model, zero_duration, (duration_seconds=0.0,))
    @test zero_duration.expansion_fraction == 0.25
    PlantSimEngine.run!(model, zero_duration, (duration_seconds=0.0,))
    @test iszero(zero_duration.expansion_age_seconds)
    @test !zero_duration.expansion_changed
    @test zero_duration.prepaid_construction_gC == 0.04
    previous = expansion_output_state(model, zero_duration)
    for invalid in (-1.0, Inf, NaN)
        @test_throws Exception PlantSimEngine.run!(model, zero_duration, (duration_seconds=invalid,))
        @test isequal(expansion_output_state(model, zero_duration), previous)
    end
    for dimensions in ((Length=0.0, Width=2.0, Thickness=0.0),
                       (Length=8.0, Width=-1.0, Thickness=0.0),
                       (Length=8.0, Width=2.0, Thickness=-0.1),
                       (Length=NaN, Width=2.0, Thickness=0.0))
        invalid = Status(; dimensions..., PlantSimEngine.outputs_(model)...)
        before = expansion_output_state(model, invalid)
        @test_throws Exception PlantSimEngine.run!(model, invalid, hour)
        @test isequal(expansion_output_state(model, invalid), before)
    end
    for keywords in ((maturation_seconds=0.0, birth_fraction=0.25, construction_cost_gC=0.04),
                     (maturation_seconds=7200.0, birth_fraction=0.0, construction_cost_gC=0.04),
                     (maturation_seconds=7200.0, birth_fraction=1.1, construction_cost_gC=0.04),
                     (maturation_seconds=7200.0, birth_fraction=0.25, construction_cost_gC=-1.0),
                     (maturation_seconds=Inf, birth_fraction=0.25, construction_cost_gC=0.04))
        @test_throws Exception X.OrganExpansion(:Leaf; keywords...)
    end
    model32 = X.OrganExpansion(:Leaf; maturation_seconds=7200.0f0,
        birth_fraction=0.25f0, construction_cost_gC=0.04f0)
    status32 = Status(; Length=8.0f0, Width=2.0f0, Thickness=0.0f0,
        PlantSimEngine.outputs_(model32)...)
    PlantSimEngine.run!(model32, status32, (duration_seconds=3600.0f0,))
    @test status32.expansion_fraction === 0.25f0
    @test status32.prepaid_construction_gC === 0.04f0
    @test status32.expanded_width_cm isa Float32
    @test PlantSimEngine.variable_contracts(model).expanded_width_cm ==
        PlantSimEngine.variable_contracts(D.DynamicPhysiologyModels.LeafDimension()).Width
    current_dimension = X.ExpandedLeafDimension()
    dimension_status = Status(; Width=2.0, expanded_width_cm=1.0,
        PlantSimEngine.outputs_(current_dimension)...)
    PlantSimEngine.run!(current_dimension, dimension_status, nothing)
    @test dimension_status.d == 0.01
    @test dimension_status.Width == 2.0
    @test keys(PlantSimEngine.inputs_(current_dimension)) == (:expanded_width_cm,)
    @test PlantSimEngine.variable_contracts(current_dimension).expanded_width_cm ==
        PlantSimEngine.variable_contracts(model).expanded_width_cm
    dimension_status.expanded_width_cm = 0.0
    @test_throws DomainError PlantSimEngine.run!(current_dimension, dimension_status, nothing)
    @test dimension_status.d == 0.01
end

@testset "Two plants deploy prepaid organs without changing architecture or RNG" begin
    result = E.run_example(expansion=EXPANSION)
    instant = E.run_example(expansion=nothing)
    check_frame_carbon(result)
    check_expansion_frames(result)
    @test length(result.frames) == 6
    @test any(organ.fraction < 1 for frame in result.frames for organ in frame.expansion)
    @test any(organ.fraction == 1 for frame in result.frames for organ in frame.expansion)
    @test AMAPSim.topology_signature(first(result.topologies).scene) ==
        AMAPSim.topology_signature(first(instant.topologies).scene)
    @test native_potential_dimensions(result.model) == native_potential_dimensions(instant.model)
    fields(value) = (; (field => deepcopy(getfield(value, field))
        for field in fieldnames(typeof(value)))...)
    for (expanded, historical) in zip(plant_objects(result), plant_objects(instant))
        s, reference = expanded.status, historical.status
        @test expanded.id == historical.id
        @test rng_bytes(s.rng) == rng_bytes(reference.rng)
        @test isequal(s.event_trace, reference.event_trace)
        @test s.processed_events == reference.processed_events
        @test s.last_event_id == reference.last_event_id
        @test isequal(s.development_sites, reference.development_sites)
        @test isequal(Dict(id => fields(state) for (id, state) in s.bud_states),
            Dict(id => fields(state) for (id, state) in reference.bud_states))
        @test isequal(s.allocation_history, reference.allocation_history)
        @test s.spent_carbon_gC == reference.spent_carbon_gC
    end
    changed_area = false
    for (frame, historical) in zip(result.frames, instant.frames)
        reference_leaves = Dict(leaf.object_id => leaf for leaf in historical.leaves)
        @test Set(keys(reference_leaves)) == Set(leaf.object_id for leaf in frame.leaves)
        for leaf in frame.leaves
            native_area = reference_leaves[leaf.object_id].area_m2
            @test leaf.area_m2 <= native_area * (1 + 1e-5)
            changed_area |= leaf.area_m2 < native_area * 0.99
        end
    end
    @test changed_area
    truth = physical_owner_expectations(result)
    cache = getproperty(result.light_kernel, :runtime_cache)
    @test Set(getproperty(cache, :target_ids)) == Set(last(result.frames).leaves_at_start)
    @test Dict(getproperty(cache, :owner_map)) == truth.expected
end

@testset "Expansion refreshes geometry while organ creation is stopped" begin
    weather = D.forcing(par=fill(450.0, 8))
    weather = [index <= 4 ? row : merge(row, (development_rate_per_second=0.0,))
        for (index, row) in enumerate(weather)]
    setup = E.scenario(; weather, expansion=EXPANSION)
    simulation = PlantSimEngine.run!(setup.model; steps=4, outputs=:none)
    scene_status = only(model_objects(setup.model; scale=:Scene)).status
    frame4 = last(scene_status.interval_records)
    checkpoint_ids = Set(object.id for object in model_objects(setup.model))
    checkpoint_structure = PlantSimEngine.Advanced.model_revision(setup.model)
    checkpoint_dimensions = native_potential_dimensions(setup.model)
    checkpoint_rng = Dict(object.id => rng_bytes(object.status.rng) for object in plant_objects(setup))
    checkpoint_processed = Dict(object.id => object.status.processed_events for object in plant_objects(setup))
    checkpoint_construction = Dict(object.id => object.status.spent_carbon_gC for object in plant_objects(setup))
    youngest = [organ.object_id for organ in frame4.expansion
        if organ.symbol === :Leaf && iszero(organ.age_seconds)]
    @test !isempty(youngest)
    selected = first(youngest)
    rebuilds = Dict(4 => setup.provider.rebuild_count)
    environment_revisions = Dict(4 => PlantSimEngine.Advanced.environment_revision(setup.model))
    for execution in 5:8
        PlantSimEngine.continue!(simulation; steps=1)
        frame = last(scene_status.interval_records)
        @test frame.execution == execution
        @test Set(object.id for object in model_objects(setup.model)) == checkpoint_ids
        @test PlantSimEngine.Advanced.model_revision(setup.model) == checkpoint_structure
        @test native_potential_dimensions(setup.model) == checkpoint_dimensions
        for object in plant_objects(setup)
            @test rng_bytes(object.status.rng) == checkpoint_rng[object.id]
            @test object.status.processed_events == checkpoint_processed[object.id]
            @test object.status.spent_carbon_gC == checkpoint_construction[object.id]
        end
        rebuilds[execution] = setup.provider.rebuild_count
        environment_revisions[execution] = PlantSimEngine.Advanced.environment_revision(setup.model)
    end
    frames = scene_status.interval_records
    @test only(organ for organ in frames[4].expansion if organ.object_id == selected).fraction == 0.25
    @test only(organ for organ in frames[5].expansion if organ.object_id == selected).fraction == 0.625
    @test only(organ for organ in frames[6].expansion if organ.object_id == selected).fraction == 1.0
    leaf5 = only(leaf for leaf in frames[5].leaves if leaf.object_id == selected)
    leaf6 = only(leaf for leaf in frames[6].leaves if leaf.object_id == selected)
    leaf7 = only(leaf for leaf in frames[7].leaves if leaf.object_id == selected)
    @test leaf5.d < leaf6.d < leaf7.d
    @test leaf5.area_m2 < leaf6.area_m2 < leaf7.area_m2
    @test isapprox(leaf6.area_m2 / leaf5.area_m2, (0.625 / 0.25)^(2 / 3); rtol=1e-5)
    @test isapprox(leaf7.area_m2 / leaf5.area_m2, (1.0 / 0.25)^(2 / 3); rtol=1e-5)
    @test rebuilds[5] > rebuilds[4]
    @test rebuilds[6] > rebuilds[5]
    @test rebuilds[7] > rebuilds[6]
    @test rebuilds[8] == rebuilds[7]
    @test environment_revisions[5] > environment_revisions[4]
    @test environment_revisions[6] > environment_revisions[5]
    @test !frames[7].geometry_invalidated
    @test !frames[8].geometry_invalidated
    @test all(organ.fraction == 1.0 && !organ.changed for organ in frames[8].expansion)
    result = (; setup..., simulation, frames=copy(frames))
    check_frame_carbon(result)
    check_expansion_frames(result)
end

@testset "Unfunded organs and runtime collars acquire no expansion payment" begin
    result = E.run_example(initial_reserves_gC=(0.01, 0.0), expansion=EXPANSION)
    check = check_frame_carbon(result)
    check_expansion_frames(result)
    funded, unfunded = check.objects
    @test any(organ.plant_id == funded.id for frame in result.frames for organ in frame.expansion)
    @test all(organ.plant_id != unfunded.id for frame in result.frames for organ in frame.expansion)
    @test all(iszero(plant.deployed_construction_gC) && iszero(plant.unexpanded_construction_gC)
        for frame in result.frames for plant in frame.plants if plant.object_id == unfunded.id)
    @test iszero(check.positive[unfunded.id])
    @test result.provider.seed_stem_used == (false, true)
    @test length(MultiScaleTreeGraph.children(result.provider.last_scene.mtg)) == 2
    for object in model_objects(result.model; scale=:Internode)
        get(node_attributes(source_node(result.model, object)), :RuntimeScaffold, false) === true || continue
        @test !object.status.expansion_initialized
        @test iszero(object.status.prepaid_construction_gC)
        @test !object.status.expansion_changed
    end
end
