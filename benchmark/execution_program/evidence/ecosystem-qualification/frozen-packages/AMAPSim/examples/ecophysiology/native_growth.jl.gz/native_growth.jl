"""Small, uncalibrated light–carbon–growth examples using the native arenas."""
module NativePhysiologyExample

using AMAPSim
using ArchimedLight
using Dates
using PlantBiophysics
using PlantMeteo
using PlantSimEngine

include(joinpath(pkgdir(AMAPSim), "dev", "native", "native.jl"))
include(joinpath(pkgdir(AMAPSim), "dev", "native", "pse.jl"))
include(joinpath(pkgdir(AMAPSim), "dev", "native", "pse_physiology.jl"))
const Native = NativeAMAP
const Adapter = NativeAMAPPSE
const Physiology = NativeAMAPPhysiology

export scenario, run_example, forcing, profile_plant

"""Annotate a native product role without editing the historical FPA."""
function profile_plant(profile=:merisier; id=:tree, seed=1)
    name = Symbol(lowercase(string(profile)))
    filename, leaf_name = name === :merisier ? ("merisier.fpa", "feuilles") :
        name === :rauh ? ("mod_Rauh.fpa", "feuille") :
        throw(ArgumentError("profile must be :merisier or :rauh"))
    input = joinpath(pkgdir(AMAPSim), "test", "fixtures", "native_originals", filename)
    return Adapter.NativePlant(id, input; seed, product_symbols=Dict(leaf_name => :Leaf))
end

"""
Four authored one-hour intervals by default. The virtual-stage conversion is
an example input, not a calibrated phenology. `par` is interval-mean PAR W/m².
"""
function forcing(; steps=4, horizon=2.0, par=450.0, duration_seconds=3600.0)
    steps isa Integer && !(steps isa Bool) && steps > 0 ||
        throw(ArgumentError("steps must be a positive integer"))
    for (name, value) in (("horizon", horizon), ("duration_seconds", duration_seconds))
        value isa Real && !(value isa Bool) && isfinite(value) && value > 0 ||
            throw(ArgumentError("$name must be finite and positive"))
    end
    intensities = par isa Real ? fill(par, steps) : collect(par)
    length(intensities) == steps || throw(ArgumentError("PAR must have one value per step"))
    milliseconds = round(Int, duration_seconds * 1000)
    milliseconds > 0 && isapprox(milliseconds / 1000, duration_seconds; rtol=1e-12) ||
        throw(ArgumentError("example duration must be representable in milliseconds"))
    return map(enumerate(intensities)) do (index, intensity)
        intensity isa Real && !(intensity isa Bool) && isfinite(intensity) && intensity >= 0 ||
            throw(ArgumentError("PAR irradiance must be finite and nonnegative"))
        atmosphere = Atmosphere(
            date=DateTime(2023, 6, 21, 10) + Millisecond((index-1)*milliseconds),
            duration=Millisecond(milliseconds), T=25.0, Wind=1.0, P=101.3,
            Rh=0.65, Cₐ=400.0, Ri_PAR_f=Float64(intensity),
            Ri_NIR_f=0.55*Float64(intensity), sun_azimuth_deg=180.0,
            sun_elevation_deg=60.0, direct_fraction=0.7)
        return merge(NamedTuple(atmosphere), (
            duration_seconds=Float64(duration_seconds),
            development_rate_per_second=Float64(horizon)/(steps*duration_seconds)))
    end
end

"""
    scenario(profile=:merisier; initial_reserve_gC=1.0, kwargs...)

Native development, explicit diamond laminae, ArchimedLight and atmospheric
FvCB/Medlyn exchange. All default scientific coefficients are demonstration
values. The density law describes a solid native frustum, independently of
the thin display/radiative lamina; neither is a calibrated species allometry.
"""
function scenario(profile=:merisier; id=:tree, seed=1, steps=4, horizon=2.0,
    par=450.0, duration_seconds=3600.0, initial_reserve_gC=1.0,
    metres_per_native_unit=0.0001, leaf_width_per_native_diameter=2.0,
    density_gDM_per_cm3=0.5, construction_cost_gC_per_gDM=0.5,
    applications=())
    weather = forcing(; steps, horizon, par, duration_seconds)
    plant = profile_plant(profile; id, seed)
    surface = Physiology.NativeSurfaceGeometry(; metres_per_native_unit,
        leaf_width_per_native_diameter, domain=(-0.1, -0.1, 0.35, 0.2),
        plant_positions_m=Dict(plant.id => (0.0, 0.0, 0.0)))
    light_options = LightOptions(turtle_sectors=8, all_in_turtle=true,
        pixel_size=0.002, scattering=false, toricity=false, cache_radiation=true,
        radiation_timestep_minutes=duration_seconds/60,
        radiation_input_semantics=:interval_mean, nir_interception=true,
        include_sky_fraction=true)
    optical_models = models_for("native" => (
        "Leaf" => translucent(par=0.15, nir=0.85),
        "*" => translucent(par=0.20, nir=0.50)))
    demand_model = Adapter.FrustumGrowthDemand(; density_gDM_per_cm3,
        construction_cost_gC_per_gDM, cm_per_native_unit=100*metres_per_native_unit)
    setup = Physiology.scenario((plant,); weather, surface, light_options,
        optical_models, photosynthesis_model=Fvcb(VcMaxRef=80.0,
            JMaxRef=140.0, RdRef=1.0), conductance_model=Medlyn(0.03, 12.0),
        demand_model, initial_reserve_gC, par_energy_to_photon=4.57, applications)
    return (; setup..., weather, plant, profile=Symbol(lowercase(string(profile))),
        initial_reserve_gC, horizon=Float64(horizon))
end

"""Retain one compact plant carbon balance per exchange, without output history."""
function run_example(profile=:merisier; kwargs...)
    setup = scenario(profile; kwargs...)
    frames = NamedTuple[]
    simulation = PlantSimEngine.run!(setup.model; steps=0, outputs=:none)
    for index in eachindex(setup.weather)
        step!(simulation)
        status = model_status(setup.model, setup.plant.id)
        state = Adapter.native_state(setup.model, setup.plant.id)
        push!(frames, (step=index, physical_time_seconds=state.development.physical_time,
            development_time=state.native.plant.time,
            living_organs=count(organ -> organ.active, state.native.plant.organs),
            construction_gC=status.spent_carbon_gC,
            reserve_gC=status.remaining_carbon_gC,
            positive_net_gC=status.credited_carbon_supply_gC,
            negative_net_gC=status.paid_carbon_loss_gC,
            living_dry_mass_gDM=status.living_dry_mass_gDM,
            removed_dry_mass_gDM=status.removed_dry_mass_gDM))
    end
    return (; setup..., simulation, frames)
end

end # module NativePhysiologyExample
