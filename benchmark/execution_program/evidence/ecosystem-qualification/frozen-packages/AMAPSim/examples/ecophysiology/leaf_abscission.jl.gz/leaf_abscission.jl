"""An explicit physical lifespan for terminal leaves, without remobilization."""
module LeafAbscissionModels

import PlantSimEngine

export LeafAbscission

PlantSimEngine.@process "leaf_abscission" verbose=false

"""
    LeafAbscission(; lifespan_seconds, construction_cost_gC)

Start age at zero on the first accepted call at a leaf's actual realization
endpoint. Later calls add physical elapsed seconds, bounded by its lifespan.
The kernel only proposes removal; the interval controller owns the terminal
Leaf lifecycle change and its geometry invalidation. No random draw occurs.

The construction payment is historical and is never refunded. Its output is
an accounting equivalent, not measured tissue carbon or a litter-carbon flux.
"""
struct LeafAbscission{T<:Real} <: AbstractLeaf_AbscissionModel
    lifespan_seconds::T
    construction_cost_gC::T
end

function LeafAbscission(; lifespan_seconds, construction_cost_gC)
    for (name, value) in ((:lifespan_seconds, lifespan_seconds),
                           (:construction_cost_gC, construction_cost_gC))
        value isa Real && !(value isa Bool) && isfinite(value) ||
            throw(ArgumentError("$name must be finite and real"))
    end
    lifespan_seconds > 0 || throw(DomainError(lifespan_seconds, "lifespan must be positive"))
    construction_cost_gC >= 0 || throw(DomainError(construction_cost_gC, "cost cannot be negative"))
    lifespan, cost = promote(float(lifespan_seconds), float(construction_cost_gC))
    return LeafAbscission(lifespan, cost)
end

PlantSimEngine.environment_inputs_(model::LeafAbscission) = (
    duration_seconds=zero(model.lifespan_seconds),
)
PlantSimEngine.outputs_(model::LeafAbscission) = (
    abscission_initialized=false,
    abscission_age_seconds=zero(model.lifespan_seconds),
    abscission_due=false,
    abscission_prepaid_gC=zero(model.construction_cost_gC),
)
PlantSimEngine.variable_contracts_(::LeafAbscission) = (
    duration_seconds=PlantSimEngine.VariableContract(
        unit=:second, temporal=:step, aggregation=:total, extent=:intensive),
    abscission_age_seconds=PlantSimEngine.VariableContract(
        unit=:second, basis=:organ, temporal=:instantaneous,
        aggregation=:state, extent=:intensive),
    abscission_prepaid_gC=PlantSimEngine.VariableContract(
        unit=:g_carbon, basis=:organ, temporal=:instantaneous,
        aggregation=:state, extent=:extensive),
)

function PlantSimEngine.run!(model::LeafAbscission{T}, status, environment,
                             constants=nothing, context=nothing) where {T}
    elapsed = environment.duration_seconds
    elapsed isa Real && !(elapsed isa Bool) && isfinite(elapsed) && elapsed >= 0 ||
        throw(ArgumentError("duration_seconds must be finite and nonnegative"))
    initialized = status.abscission_initialized
    initialized isa Bool || throw(ArgumentError("abscission_initialized must be boolean"))
    previous = initialized ? status.abscission_age_seconds : zero(T)
    previous isa Real && !(previous isa Bool) && isfinite(previous) &&
        0 <= previous <= model.lifespan_seconds ||
        throw(ArgumentError("leaf age must remain within its lifespan"))
    # Clamp before conversion/addition, including very large finite durations.
    age = convert(T, previous + min(elapsed, model.lifespan_seconds - previous))
    initialized || (age = zero(T))
    status.abscission_initialized = true
    status.abscission_age_seconds = age
    status.abscission_due = age >= model.lifespan_seconds
    status.abscission_prepaid_gC = model.construction_cost_gC
    return nothing
end

end
