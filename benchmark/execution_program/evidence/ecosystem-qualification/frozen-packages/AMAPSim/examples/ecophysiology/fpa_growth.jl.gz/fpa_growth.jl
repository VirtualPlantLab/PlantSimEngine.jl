"""Short, uncalibrated light–energy–carbon–growth runs on authentic FPA programs."""
module FPAGrowthExample

using AMAPSim
using AMAPSim.Modeling: LateralProductionParameters
using PlantSimEngine

include("dynamic_growth.jl")
const E = DynamicGrowthExample

export profile_parameters, scenario, run_example

const PROFILES = (
    rauh=(
        fixture=("rauh_stage2_extended_profile_replay", "rauh_stage2"),
        sha256="d6579b1543f80fe5be360996e776699c2397776dca85a3a574a3e0d7e903ff56",
        leaf_index=3, leaf_name="feuille",
    ),
    merisier=(
        fixture=("categorical_profile_replay", "merisier_stage2"),
        sha256="cf316a3ecd559c69a8b8091b867386ad125c17818c4b3648d8314612d936742a",
        leaf_index=2, leaf_name="feuilles",
    ),
)

"""
    profile_parameters(profile=:rauh)

Read a protected Rauh or Merisier FPA without changing its numeric parameters.
Only the explicitly named foliar program is annotated `organ_symbol=:Leaf`:
Rauh production 3 (`feuille`) or Merisier production 2 (`feuilles`). This is an
authored example-level role, not a global interpretation of numeric Nature 2.
Every realized program test still creates its own ordinary native product;
no leaf is fabricated for a pending test or projected from an axis afterward.

The raw parameters, source digest and exact annotation are returned for audit.
The historical architecture control must use this same annotated parameter set.
"""
function profile_parameters(profile=:rauh)
    name = Symbol(lowercase(string(profile)))
    hasproperty(PROFILES, name) || throw(ArgumentError("profile must be :rauh or :merisier"))
    spec = getproperty(PROFILES, name)
    path = joinpath(pkgdir(AMAPSim), "test", "fixtures", spec.fixture..., "input.fpa")
    raw = read_parameters(path)
    raw.source.plant_name == string(name) && raw.source.sha256 == spec.sha256 ||
        throw(ArgumentError("the protected $name FPA differs from the reviewed source"))
    production = raw.lateral_productions[spec.leaf_index]
    production.name == spec.leaf_name || throw(ArgumentError(
        "the selected foliar production must be named $(repr(spec.leaf_name))",
    ))
    production.organ_symbol === :Internode || throw(ArgumentError(
        "the raw historical foliar production must retain its parser default",
    ))
    productions = copy(raw.lateral_productions)
    productions[spec.leaf_index] = LateralProductionParameters(
        production.name, production.global_parameters,
        production.branching_models, production.zones; organ_symbol=:Leaf,
    )
    parameters = AMAPSimParameters(raw.source, raw.initialization, raw.axis,
        productions, raw.legacy)
    mapping = (profile=name, production_index=spec.leaf_index,
        production_name=spec.leaf_name, raw_symbol=:Internode, effective_symbol=:Leaf,
        source_sha256=spec.sha256)
    return (; parameters, raw_parameters=raw, mapping)
end

"""
    scenario(profile=:rauh; steps=4, horizon=2.0, seed=1,
             initial_reserve_gC=1.0, par=450.0, kwargs...)

Reuse the full dynamic application graph on a fresh authentic FPA seed. Each
weather interval lasts one hour; `horizon / steps` is an explicitly authored
virtual developmental increment, not a species phenology or calendar model.
The initial reserve, organ construction masses/costs and physiological models
are illustrative inputs. Lower `initial_reserve_gC` to exercise organ-wise
deferral; retained growth intentions are not drawn again. Geometry uses its
own stream and the existing centimetre-to-metre radiative boundary.
"""
function scenario(profile=:rauh; steps=4, horizon=2.0, seed=1,
                  initial_reserve_gC=1.0, par=450.0, kwargs...)
    steps isa Integer && !(steps isa Bool) && steps > 0 ||
        throw(ArgumentError("steps must be a positive integer"))
    horizon isa Real && !(horizon isa Bool) && isfinite(horizon) && horizon > 0 ||
        throw(ArgumentError("horizon must be finite and positive"))
    par isa Real && !(par isa Bool) && isfinite(par) && par >= 0 ||
        throw(ArgumentError("par must be finite and nonnegative"))
    profile_setup = profile_parameters(profile)
    development_increment = Float64(horizon) / steps
    weather = E.forcing(; par=fill(Float64(par), steps), development_increment)
    setup = E.scenario(; parameters=profile_setup.parameters, weather, seed,
        initial_reserve_gC, kwargs...)
    return (; setup..., profile_setup..., seed, development_increment,
        developmental_horizon=Float64(horizon), physical_step_seconds=3600.0)
end

function run_example(profile=:rauh; outputs=:none, kwargs...)
    setup = scenario(profile; kwargs...)
    simulation = PlantSimEngine.run!(setup.model; steps=length(setup.weather), outputs)
    scene = only(model_objects(setup.model; scale=:Scene)).status
    return (; setup..., simulation, frames=copy(scene.interval_records))
end

end # module FPAGrowthExample
