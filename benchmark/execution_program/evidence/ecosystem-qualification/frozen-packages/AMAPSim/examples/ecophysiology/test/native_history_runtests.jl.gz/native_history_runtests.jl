module NativeHistoryValidation

using AMAPSim
using MultiScaleTreeGraph
using PlantSimEngine
using Serialization
using Test

include(joinpath(@__DIR__, "..", "two_plant_growth.jl"))
const E = TwoPlantGrowthExample

function rng_bytes(rng)
    buffer = IOBuffer()
    Serialization.serialize(buffer, copy(rng))
    return take!(buffer)
end

plant_objects(result) = sort!(model_objects(result.model; scale=:Plant);
    by=object -> MultiScaleTreeGraph.index(source_node(result.model, object)))

# Runtime revisions describe invalidation work, not plant state. Compare the
# complete numerical interval journal independently of those revision counters.
scientific_frame(frame) = (
    execution=frame.execution,
    leaves_at_start=frame.leaves_at_start,
    leaves=frame.leaves,
    leaves_at_end=frame.leaves_at_end,
    plants=frame.plants,
    expansion=frame.expansion,
    abscission=frame.abscission,
)

state_fields(value) = (; (field => deepcopy(getfield(value, field))
    for field in fieldnames(typeof(value)))...)

function queue_state(queue)
    return (
        events=Dict(id.value => state_fields(event) for (id, event) in queue.events),
        priorities=Dict(id.value => priority for (id, priority) in pairs(queue.priorities)),
        next_event_id=queue.next_event_id,
        next_sequence=queue.next_sequence,
        process_ids=copy(queue.process_ids),
        next_process_id=queue.next_process_id,
        legacy_order=queue.legacy_order,
    )
end

function check_architecture_and_rng(result, reference)
    @test isequal(scientific_frame.(result.frames), scientific_frame.(reference.frames))
    @test AMAPSim.topology_signature(first(result.topologies).scene) ==
        AMAPSim.topology_signature(first(reference.topologies).scene)
    actual = plant_objects(result)
    expected = plant_objects(reference)
    @test getproperty.(actual, :id) == getproperty.(expected, :id)
    for (plant, baseline) in zip(actual, expected)
        s, previous = plant.status, baseline.status
        @test rng_bytes(s.rng) == rng_bytes(previous.rng)
        @test isequal(s.event_trace, previous.event_trace)
        @test s.processed_events == previous.processed_events
        @test s.last_event_id == previous.last_event_id
        @test isequal(s.development_sites, previous.development_sites)
        @test isequal(s.allocation_history, previous.allocation_history)
        @test s.spent_carbon_gC == previous.spent_carbon_gC
        @test isequal(Dict(id => state_fields(state) for (id, state) in s.bud_states),
            Dict(id => state_fields(state) for (id, state) in previous.bud_states))
        @test isequal(queue_state(s.event_queue), queue_state(previous.event_queue))
    end
end

function check_native_history(result; named=false)
    frames = result.frames
    @test length(frames) == 6
    @test isempty(first(frames).leaves_at_start)
    births = Dict{PlantSimEngine.ObjectId,Int}()
    for frame in frames, id in frame.leaves_at_end
        get!(births, id, frame.execution)
    end
    removals = Dict(organ.object_id => organ.execution
        for frame in frames for organ in frame.abscission)
    @test !isempty(births)
    @test !isempty(removals)
    @test all(id in keys(births) for id in keys(removals))
    @test any(organ.fraction < 1 for frame in frames for organ in frame.expansion)
    live = Set(object_ids(result.model; scale=:Leaf))
    @test isempty(intersect(live, Set(keys(removals))))
    @test any(id in live for id in keys(births))

    histories = Dict{PlantSimEngine.ObjectId,Vector{Tuple{Float64,Float64}}}()
    named_rows = named ? collect_outputs(result.simulation, :carbon_history; sink=nothing) : nothing
    if named
        # Named requests retain historical membership after source removal.
        @test Set(keys(collect_outputs(result.simulation; sink=nothing))) == Set([:carbon_history])
        @test length(unique((row.object_id, row.timestep) for row in named_rows)) ==
            length(named_rows)
        @test all(row.application_id == :leaf_carbon && row.scale == :Leaf &&
            row.variable == :carbon_step_gC for row in named_rows)
    end
    for (id, birth) in births
        expected = [(Float64(frame.execution), leaf.carbon_step_gC)
            for frame in frames for leaf in frame.leaves if leaf.object_id == id]
        key = (:leaf_carbon, id, :carbon_step_gC)
        @test haskey(outputs(result.simulation), key)
        stream = outputs(result.simulation)[key]
        @test stream == expected
        @test length(unique(first.(stream))) == length(stream)
        # Growth takes place after physiology: creation never publishes a
        # fictitious carbon observation in the birth interval or before it.
        @test all(time > birth for (time, _) in stream)
        @test all(time <= get(removals, id, length(frames)) for (time, _) in stream)
        rows = collect_outputs(result.simulation, id, :carbon_step_gC; sink=nothing)
        @test getproperty.(rows, :timestep) == Int.(first.(expected))
        @test getproperty.(rows, :value) == last.(expected)
        @test getproperty.(rows, :datetime) ==
            [result.weather[Int(time)].date for (time, _) in expected]
        @test all(row.object_id == id.value && row.application_id == :leaf_carbon
            for row in rows)
        if haskey(removals, id)
            @test !isempty(stream)
            @test last(stream)[1] == removals[id]
            @test_throws Exception source_node(result.model, id)
        end
        if named
            selected = filter(row -> row.object_id == id.value, named_rows)
            @test getproperty.(selected, :timestep) == Int.(first.(expected))
            @test getproperty.(selected, :value) == last.(expected)
            @test getproperty.(selected, :datetime) == getproperty.(rows, :datetime)
        end
        histories[id] = stream
    end
    if named
        @test length(named_rows) == sum(length, values(histories))
    end
    return histories
end

function check_separate_carbon_balances(result, histories)
    plants = plant_objects(result)
    @test length(plants) == 2
    ids = Set(plant.id for plant in plants)
    initial = Dict(plant.id => result.initial_reserves_gC[index]
        for (index, plant) in enumerate(plants))
    positive = Dict(id => 0.0 for id in ids)
    negative = Dict(id => 0.0 for id in ids)
    removed = Dict(id => 0.0 for id in ids)
    owners = Dict{PlantSimEngine.ObjectId,PlantSimEngine.ObjectId}()
    sources = Dict(id => Set{Int}() for id in ids)
    for frame in result.frames
        @test Set(plant.object_id for plant in frame.plants) == ids
        for leaf in frame.leaves
            @test leaf.plant_id in ids
            @test get!(owners, leaf.object_id, leaf.plant_id) == leaf.plant_id
            push!(sources[leaf.plant_id], leaf.source_node_id)
            # Derive each ledger from the retained observations, independently
            # of the allocator's cumulative values in the interval journal.
            gain = only(value for (time, value) in histories[leaf.object_id]
                if time == frame.execution)
            @test gain ≈ leaf.A * leaf.area_m2 * result.weather[frame.execution].duration_seconds * 12e-6
            positive[leaf.plant_id] += max(gain, 0.0)
            negative[leaf.plant_id] += max(-gain, 0.0)
        end
        for organ in frame.abscission
            @test owners[organ.object_id] == organ.plant_id
            removed[organ.plant_id] += organ.prepaid_construction_gC
        end
        for plant in frame.plants
            @test plant.positive_net_gC ≈ positive[plant.object_id]
            @test plant.negative_net_gC ≈ negative[plant.object_id]
            @test plant.abscised_construction_gC ≈ removed[plant.object_id]
            @test plant.reserve_gC >= 0
            @test initial[plant.object_id] + positive[plant.object_id] ≈
                plant.reserve_gC + plant.construction_gC + negative[plant.object_id]
            @test plant.active_construction_gC + plant.abscised_construction_gC ≈
                plant.construction_gC
            @test plant.deployed_construction_gC + plant.unexpanded_construction_gC ≈
                plant.active_construction_gC
        end
    end
    @test all(positive[id] > 0 && negative[id] > 0 && removed[id] > 0 for id in ids)
    # Equal source-local IDs deliberately occur in both plants. Histories are
    # keyed by the distinct runtime ObjectIds and never pooled by the raw ID.
    @test !isempty(intersect(values(sources)...))
    @test Set(values(owners)) == ids
end

@testset "Native output histories survive two-plant growth and abscission" begin
    options = (
        expansion=(maturation_seconds=7200.0, birth_fraction=0.25),
        abscission=(lifespan_seconds=7200.0,),
    )
    reference = E.run_example(; options..., outputs=:none)
    @test isempty(outputs(reference.simulation))
    for mode in (:all, :request)
        @testset "$mode" begin
            retained = mode == :all ? :all : OutputRequest(Many(scale=:Leaf),
                :carbon_step_gC; name=:carbon_history, application=:leaf_carbon)
            result = E.run_example(; options..., outputs=retained)
            check_architecture_and_rng(result, reference)
            histories = check_native_history(result; named=mode == :request)
            check_separate_carbon_balances(result, histories)
        end
    end
end

end # module NativeHistoryValidation
