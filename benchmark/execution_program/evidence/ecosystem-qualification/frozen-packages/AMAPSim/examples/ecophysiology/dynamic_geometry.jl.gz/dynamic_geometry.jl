"""Geometry preparation for the bounded, growing ecophysiology example."""
module DynamicLightGeometry

import AMAPSim
import MultiScaleTreeGraph
import PlantGeom
import PlantSimEngine

export DynamicSceneProvider, MultiPlantSceneProvider, prepare_scene, source_roots, leaf_prototype
export cleanup_source_ids!

const CENTIMETRES_TO_METRES = 0.01

"""A small shared lamina; native Leaf dimensions scale each instance in cm."""
function leaf_prototype()
    reference = PlantGeom.lamina_refmesh(
        "dynamic_native_leaf";
        length=1.0,
        max_width=1.0,
        n_long=8,
        n_half=2,
    )
    return PlantGeom.RefMeshPrototype(
        reference; normalize=true, warn=false, length_axis=:x,
    )
end

function _positive_measure(value, label)
    value isa Real && !(value isa Bool) && isfinite(value) && value > 0 ||
        throw(ArgumentError("$label must be a finite positive length in cm"))
    converted = Float64(value)
    isfinite(converted) && converted > 0 || throw(ArgumentError(
        "$label cannot be represented as a finite positive Float64",
    ))
    return converted
end

function _domain(value)
    length(value) == 4 || throw(ArgumentError("domain needs four bounds in metres"))
    all(bound -> bound isa Real && !(bound isa Bool) && isfinite(bound), value) ||
        throw(ArgumentError("domain bounds must be finite real values in metres"))
    bounds = Tuple(Float64.(value))
    all(isfinite, bounds) && bounds[1] < bounds[3] && bounds[2] < bounds[4] ||
        throw(ArgumentError("domain needs increasing finite x/y bounds"))
    return bounds
end

function _materialize_metres!(plant)
    for node in MultiScaleTreeGraph.traverse(plant, identity)
        PlantGeom.has_geometry(node) || continue
        # Materialize the complete cm-space placement exactly once, then apply
        # the sole cm -> m conversion at the radiative scene boundary.
        mesh_cm = PlantGeom.refmesh_to_mesh(node)
        node[:type] = MultiScaleTreeGraph.symbol(node) === :Leaf ? "Leaf" : "Internode"
        node[:geometry] = PlantGeom.Geometry(
            ref_mesh=PlantGeom.RefMesh(
                "dynamic_component_$(MultiScaleTreeGraph.node_id(node))", mesh_cm,
            ),
            transformation=PlantGeom.scale3(CENTIMETRES_TO_METRES),
        )
    end
    return plant
end

function _prepare_plant(
    topology,
    parameters,
    organ_prototypes,
    geometry_seed,
    internode_sides,
    seed_stem_length_cm,
    seed_stem_diameter_cm;
    geometry_stream=:dynamic_geometry,
    dimensions=nothing,
)
    # The historical path persists ordinary geometry provenance on the live
    # plant. Expansion instead reconstructs a disposable copy: its current
    # dimensions and geometry must never replace AMAPSim's potential values.
    target = topology.plant
    if dimensions !== nothing
        dimensions isa AbstractDict || throw(ArgumentError(
            "expanded dimensions must be a dictionary keyed by current runtime node ID",
        ))
        target = deepcopy(topology.plant)
        MultiScaleTreeGraph.reparent!(target, nothing)
        nodes = Dict(MultiScaleTreeGraph.node_id(node) => node
            for node in MultiScaleTreeGraph.traverse(target, identity))
        for (id, current) in pairs(dimensions)
            id isa Integer && !(id isa Bool) && haskey(nodes, id) || throw(ArgumentError(
                "expanded dimensions refer to an unknown current plant node ID",
            ))
            node = nodes[id]
            MultiScaleTreeGraph.symbol(node) in (:Internode, :Leaf) || throw(ArgumentError(
                "expanded dimensions may only describe native Internode or Leaf products",
            ))
            current isa NamedTuple && length(current) == 3 &&
                all(name -> haskey(current, name), (:Length, :Width, :Thickness)) ||
                throw(ArgumentError("expanded dimensions require Length, Width and Thickness in cm"))
            for name in (:Length, :Width, :Thickness)
                value = current[name]
                value isa Real && !(value isa Bool) && isfinite(value) && value >= 0 ||
                    throw(ArgumentError("expanded $name must be a finite nonnegative length in cm"))
                node[name] = value
            end
        end
    end
    AMAPSim.build_geometry!(
        target;
        parameters,
        rng=AMAPSim.stochastic_stream(geometry_seed, geometry_stream),
        internode_sides,
        cap_ends=true,
        organ_prototypes,
    )
    plant = if dimensions === nothing
        copied = deepcopy(topology.plant)
        MultiScaleTreeGraph.reparent!(copied, nothing)
        copied
    else
        target
    end
    seed_stem_used = !any(PlantGeom.has_geometry, MultiScaleTreeGraph.traverse(plant, identity))
    if seed_stem_used
        # The AMAPSim seed has an existing registered scaffold Internode but
        # no developed geometry. This explicitly authored nonphotosynthetic
        # collar is an initial radiative condition, not a growth event or Leaf.
        # Its geometry exists only in the disposable radiative copy. It is
        # omitted once the plant has real organ geometry.
        seed_id = MultiScaleTreeGraph.node_id(topology.internode)
        seed_nodes = filter(MultiScaleTreeGraph.traverse(plant, identity)) do node
            MultiScaleTreeGraph.node_id(node) == seed_id
        end
        length(seed_nodes) == 1 || throw(ArgumentError(
            "the radiative seed collar requires the existing unique scaffold Internode",
        ))
        seed = only(seed_nodes)
        MultiScaleTreeGraph.symbol(seed) === :Internode || throw(ArgumentError(
            "the radiative seed collar owner must be an Internode",
        ))
        position = ntuple(3) do coordinate
            value = get(MultiScaleTreeGraph.node_attributes(plant), (:X, :Y, :Z)[coordinate], 0.0)
            value isa Real && isfinite(value) || throw(ArgumentError(
                "the seed collar needs finite plant coordinates in centimetres",
            ))
            Float64(value)
        end
        seed[:geometry] = PlantGeom.ExtrudedTubeGeometry(
            [position, (position[1], position[2], position[3] + seed_stem_length_cm)];
            n_sides=internode_sides,
            radius=seed_stem_diameter_cm / 2,
            cap_ends=true,
        )
    end
    _materialize_metres!(plant)
    return (; plant, seed_stem_used)
end

function _assemble_scene(prepared_plants, domain)
    scene = PlantGeom.make_scene(
        domain=domain,
        source_path="AMAPSim bounded dynamic ecophysiology",
    ) do builder
        for (ordinal, prepared) in enumerate(prepared_plants)
            PlantGeom.add_plant!(
                builder, prepared.plant;
                group="dynamic",
                id=ordinal,
                source_length_unit="cm",
                scene_length_unit="m",
                source_to_scene_scale=CENTIMETRES_TO_METRES,
                seed_stem_initial_condition=prepared.seed_stem_used,
            )
        end
    end
    return scene
end

function _prepare_scene(
    topology, parameters, organ_prototypes, geometry_seed, internode_sides,
    seed_stem_length_cm, seed_stem_diameter_cm, domain;
    dimensions=nothing,
)
    prepared = _prepare_plant(
        topology, parameters, organ_prototypes, geometry_seed, internode_sides,
        seed_stem_length_cm, seed_stem_diameter_cm; dimensions,
    )
    return (scene=_assemble_scene((prepared,), domain), seed_stem_used=prepared.seed_stem_used)
end

"""
    DynamicSceneProvider(topology, parameters; dimension_provider=nothing, geometry_seed=7,
        internode_sides=6, seed_stem_length_cm=1.0,
        seed_stem_diameter_cm=0.1, domain=(-0.1, -0.1, 0.1, 0.1))

Prepare the initial real radiative scene and retain a callable scene provider
for `ArchimedLightModel`. `provider(context)` rebuilds the geometry and returns
the refreshed scene. The provider caches geometry only; biological state and
physiology remain in AMAPSim and PlantSimEngine statuses. Its dedicated named
geometry stream never consumes the architecture stream.

An optional `dimension_provider(context, exact_live_plant)` returns a dictionary
from current runtime node IDs to `(Length=..., Width=..., Thickness=...)` in cm.
Runtime reconstruction then changes only a disposable plant copy; potential
dimensions and geometry on the live plant remain untouched. The initial seed
is prepared without invoking this hook. The caller must notify PlantSimEngine
when expanded geometry changes so ArchimedLight requests a refreshed scene.

The empty architectural seed is represented by a nonphotosynthetic stem
collar, explicitly assumed to be 1 cm long and 0.1 cm in diameter by default.
It uses the existing seed Internode's complete owner identity, creates no
botanical organ or assimilation, and disappears when developed geometry is
available. These dimensions are illustrative initial conditions, not inferred
from FPA or calibrated data. Source dimensions and physiology fields are not
changed by the collar.

Use `provider.last_scene` to construct the initial `LightSimulation`, and
`source_roots=context -> DynamicLightGeometry.source_roots(provider, context)`
for the matching exact botanical roots. Rebuild counters are diagnostics,
not biological variables. No light solver or physiology kernel is called here.
"""
mutable struct DynamicSceneProvider{T,P,O,D,S}
    topology::T
    parameters::P
    organ_prototypes::O
    dimension_provider::D
    geometry_seed::Int
    internode_sides::Int
    seed_stem_length_cm::Float64
    seed_stem_diameter_cm::Float64
    domain::NTuple{4,Float64}
    last_scene::S
    rebuild_count::Int
    seed_stem_used::Bool
end

function DynamicSceneProvider(
    topology,
    parameters;
    dimension_provider=nothing,
    geometry_seed::Integer=7,
    internode_sides::Integer=6,
    seed_stem_length_cm=1.0,
    seed_stem_diameter_cm=0.1,
    domain=(-0.1, -0.1, 0.1, 0.1),
)
    3 <= internode_sides <= typemax(Int) || throw(ArgumentError(
        "internode_sides must be an integer between 3 and typemax(Int)",
    ))
    stem_length = _positive_measure(seed_stem_length_cm, "seed_stem_length_cm")
    stem_diameter = _positive_measure(seed_stem_diameter_cm, "seed_stem_diameter_cm")
    bounds = _domain(domain)
    prototypes = Dict(:Leaf => leaf_prototype())
    seed = Int(geometry_seed)
    sides = Int(internode_sides)
    prepared = _prepare_scene(
        topology, parameters, prototypes, seed, sides, stem_length, stem_diameter, bounds,
    )
    return DynamicSceneProvider(
        topology, parameters, prototypes, dimension_provider, seed, sides, stem_length, stem_diameter,
        bounds, prepared.scene, 1, prepared.seed_stem_used,
    )
end

function _provided_dimensions(provider, context, plant)
    (provider === nothing || context === nothing) && return nothing
    applicable(provider, context, plant) || throw(ArgumentError(
        "dimension_provider must accept the context and exact live Plant",
    ))
    current = provider(context, plant)
    current isa AbstractDict || throw(ArgumentError(
        "dimension_provider must return a dictionary of current runtime node IDs and dimensions",
    ))
    return current
end

function (provider::DynamicSceneProvider)(context)
    # Require the exact live botanical root, rather than accepting a foreign
    # MTG whose raw identifiers happen to be the same.
    PlantSimEngine.object_id(context, provider.topology.plant)
    dimensions = _provided_dimensions(provider.dimension_provider, context, provider.topology.plant)
    prepared = _prepare_scene(
        provider.topology, provider.parameters, provider.organ_prototypes,
        provider.geometry_seed, provider.internode_sides,
        provider.seed_stem_length_cm, provider.seed_stem_diameter_cm, provider.domain;
        dimensions,
    )
    provider.last_scene = prepared.scene
    provider.seed_stem_used = prepared.seed_stem_used
    provider.rebuild_count += 1
    return provider.last_scene
end

"""Build one scene with the same explicit conditions as `DynamicSceneProvider`."""
function prepare_scene(topology, parameters; kwargs...)
    return DynamicSceneProvider(topology, parameters; kwargs...).last_scene
end

"""Map the actual scene namespace to the exact registered botanical root."""
function source_roots(provider::DynamicSceneProvider, context=nothing)
    context === nothing || PlantSimEngine.object_id(context, provider.topology.plant)
    instances = Set(
        owner.source_instance_id for owner in values(PlantGeom.source_owners(provider.last_scene))
        if owner !== nothing
    )
    length(instances) == 1 || throw(ArgumentError(
        "the dynamic scene must contain exactly one source-instance namespace",
    ))
    return Dict(only(instances) => provider.topology.plant)
end

function _source_id(value)
    value isa Integer && !(value isa Bool) && 0 < value <= typemax(Int) ||
        throw(ArgumentError("source-local node IDs must be positive integers fitting in Int"))
    return Int(value)
end

function _source_id_highwaters(source_ids)
    return [isempty(ids) ? 0 : maximum(_source_id(value) for value in values(ids))
        for ids in source_ids]
end

function _source_id_plans(topologies, source_ids, highwaters; assign_new)
    length(topologies) == length(source_ids) == length(highwaters) || throw(ArgumentError(
        "supply one independent source-ID namespace and high-water mark per plant",
    ))
    length(Base.IdSet{Any}(source_ids)) == length(source_ids) || throw(ArgumentError(
        "each plant requires its own independent source_ids map",
    ))
    # Stage every namespace before changing maps, live provenance, or counters.
    # Removed nodes can then be released without retaining provenance tombstones;
    # the scalar high-water mark keeps their IDs reserved permanently.
    return map(eachindex(topologies)) do ordinal
        topology, ids = topologies[ordinal], source_ids[ordinal]
        ids isa IdDict || throw(ArgumentError(
            "source_ids[$ordinal] must be an IdDict keyed by exact live MTG nodes",
        ))
        maximum_id = highwaters[ordinal]
        maximum_id isa Integer && !(maximum_id isa Bool) &&
            0 <= maximum_id <= typemax(Int) || throw(ArgumentError(
                "source-ID high-water marks must be nonnegative integers fitting in Int",
            ))
        maximum_id = Int(maximum_id)
        used = Set{Int}()
        for value in values(ids)
            id = _source_id(value)
            id in used && throw(ArgumentError(
                "source_ids[$ordinal] contains duplicate source-local ID $id",
            ))
            push!(used, id)
            maximum_id = max(maximum_id, id)
        end
        nodes = sort!(MultiScaleTreeGraph.traverse(topology.plant, identity);
            by=MultiScaleTreeGraph.node_id)
        live = Base.IdSet{Any}(nodes)
        staged = copy(ids)
        removed = 0
        for node in keys(ids)
            if node ∉ live
                delete!(staged, node)
                removed += 1
            end
        end
        if assign_new
            for node in nodes
                if !haskey(staged, node)
                    maximum_id = Base.Checked.checked_add(maximum_id, 1)
                    staged[node] = maximum_id
                end
            end
        end
        return (; staged, nodes, maximum_id, removed)
    end
end

function _apply_source_id_plans!(source_ids, highwaters, plans; stamp)
    for (ordinal, plan) in enumerate(plans)
        empty!(source_ids[ordinal])
        merge!(source_ids[ordinal], plan.staged)
        highwaters[ordinal] = plan.maximum_id
        if stamp
            for node in plan.nodes
                node[:source_topology_id] = _source_id(plan.staged[node])
            end
        end
    end
    return sum(plan.removed for plan in plans; init=0)
end

function _extend_source_ids!(topologies, source_ids, highwaters)
    plans = _source_id_plans(topologies, source_ids, highwaters; assign_new=true)
    _apply_source_id_plans!(source_ids, highwaters, plans; stamp=true)
    return source_ids
end

function _prepare_multiple(
    topologies, parameters, source_ids, source_id_highwaters, organ_prototypes, geometry_seed,
    internode_sides, stem_length, stem_diameter, domain;
    dimension_provider=nothing,
    context=nothing,
)
    _extend_source_ids!(topologies, source_ids, source_id_highwaters)
    prepared = map(eachindex(topologies)) do ordinal
        dimensions = _provided_dimensions(dimension_provider, context, topologies[ordinal].plant)
        _prepare_plant(
            topologies[ordinal], parameters[ordinal], organ_prototypes,
            geometry_seed, internode_sides, stem_length, stem_diameter;
            geometry_stream="dynamic_geometry/plant/$ordinal",
            dimensions,
        )
    end
    return (
        scene=_assemble_scene(prepared, domain),
        seed_stem_used=Tuple(item.seed_stem_used for item in prepared),
    )
end

"""
    MultiPlantSceneProvider(topologies, parameters; source_ids,
        dimension_provider=nothing, geometry_seed=17,
        internode_sides=6, seed_stem_length_cm=1.0,
        seed_stem_diameter_cm=0.1, domain=(-0.1, -0.1, 0.1, 0.1))

Prepare one radiative scene for several plants in one live, shared runtime MTG.
Current runtime `node_id`s remain globally unique. `source_ids` is one `IdDict`
per plant, keyed by exact live nodes and carrying the original source-local
node IDs. Those provenance IDs may overlap between plants, never within one
plant. The original input trees are not altered. New nodes receive monotonically
increasing source-local IDs in current-node order. Removed-node entries are
released while an independent integer high-water mark prevents ID reuse. Only
`source_topology_id` provenance is stamped on live nodes. These source IDs are not substitutes for runtime `ObjectId`s.

`parameters` is one shared AMAPSim parameter set or one set per topology.
Geometry has a dedicated named stream for each plant. Its cache and counters
carry no biological model state. Collar assumptions and cm-to-m conversion
match `DynamicSceneProvider`. Plant positions are the authored `X/Y/Z` in cm.

When supplied, `dimension_provider(context, exact_live_plant)` returns a
dictionary from current runtime node IDs to `(Length=..., Width=...,
Thickness=...)` in cm. During runtime refreshes these dimensions are applied
only to a disposable botanical copy before its complete reconstruction, so
attachments follow expanded bearer organs without changing live potential
dimensions or live geometry. The initial fresh-seed scene is prepared before
the runtime context exists and does not call this hook. The caller owns
PlantSimEngine geometry/environment invalidation when expansion changes.

Pass `provider.last_scene` to the initial `LightSimulation`, `provider` as its
scene callback, and `context -> source_roots(provider, context)` for roots.
Namespaces are read from actual placed-component ownership and associated with
the exact live plant through the scene root's public plant `id` metadata.
Neither insertion order nor raw ID collisions determine runtime ownership.
"""
mutable struct MultiPlantSceneProvider{T,P,I,O,D,S}
    topologies::T
    parameters::P
    source_ids::I
    source_id_highwaters::Vector{Int}
    organ_prototypes::O
    dimension_provider::D
    geometry_seed::Int
    internode_sides::Int
    seed_stem_length_cm::Float64
    seed_stem_diameter_cm::Float64
    domain::NTuple{4,Float64}
    last_scene::S
    rebuild_count::Int
    seed_stem_used::Tuple
end

function MultiPlantSceneProvider(
    topologies, parameters;
    source_ids,
    dimension_provider=nothing,
    geometry_seed::Integer=17,
    internode_sides::Integer=6,
    seed_stem_length_cm=1.0,
    seed_stem_diameter_cm=0.1,
    domain=(-0.1, -0.1, 0.1, 0.1),
)
    plants = collect(topologies)
    isempty(plants) && throw(ArgumentError("supply at least one plant topology"))
    all(topology -> topology.scene === first(plants).scene, plants) || throw(ArgumentError(
        "all runtime plant topologies must share the exact same Scene",
    ))
    roots = [topology.plant for topology in plants]
    length(Base.IdSet{Any}(roots)) == length(roots) || throw(ArgumentError(
        "each runtime plant topology must identify a different exact Plant",
    ))
    ids = collect(source_ids)
    length(ids) == length(plants) || throw(ArgumentError("supply one source_ids map per plant"))
    all(map -> map isa IdDict, ids) || throw(ArgumentError(
        "each source_ids entry must be an IdDict keyed by exact live nodes",
    ))
    length(Base.IdSet{Any}(ids)) == length(ids) || throw(ArgumentError(
        "each plant requires its own independent source_ids map",
    ))
    for (ordinal, (topology, map)) in enumerate(zip(plants, ids))
        live_nodes = Base.IdSet{Any}(MultiScaleTreeGraph.traverse(topology.plant, identity))
        all(node -> node in live_nodes, keys(map)) || throw(ArgumentError(
            "source_ids[$ordinal] contains a node outside its exact live plant subtree",
        ))
    end
    params = parameters isa AMAPSim.AMAPSimParameters ? fill(parameters, length(plants)) :
        collect(parameters)
    length(params) == length(plants) && all(value -> value isa AMAPSim.AMAPSimParameters, params) ||
        throw(ArgumentError("supply one shared parameter set or one AMAPSim parameter set per plant"))
    3 <= internode_sides <= typemax(Int) || throw(ArgumentError(
        "internode_sides must be an integer between 3 and typemax(Int)",
    ))
    stem_length = _positive_measure(seed_stem_length_cm, "seed_stem_length_cm")
    stem_diameter = _positive_measure(seed_stem_diameter_cm, "seed_stem_diameter_cm")
    bounds = _domain(domain)
    prototypes = Dict(:Leaf => leaf_prototype())
    seed = Int(geometry_seed)
    sides = Int(internode_sides)
    highwaters = _source_id_highwaters(ids)
    prepared = _prepare_multiple(
        plants, params, ids, highwaters, prototypes, seed, sides, stem_length, stem_diameter, bounds,
    )
    return MultiPlantSceneProvider(
        plants, params, ids, highwaters, prototypes, dimension_provider, seed, sides, stem_length, stem_diameter,
        bounds, prepared.scene, 1, prepared.seed_stem_used,
    )
end

function (provider::MultiPlantSceneProvider)(context)
    for topology in provider.topologies
        PlantSimEngine.object_id(context, topology.plant)
    end
    prepared = _prepare_multiple(
        provider.topologies, provider.parameters, provider.source_ids, provider.source_id_highwaters,
        provider.organ_prototypes,
        provider.geometry_seed, provider.internode_sides, provider.seed_stem_length_cm,
        provider.seed_stem_diameter_cm, provider.domain;
        dimension_provider=provider.dimension_provider, context,
    )
    provider.last_scene = prepared.scene
    provider.seed_stem_used = prepared.seed_stem_used
    provider.rebuild_count += 1
    return provider.last_scene
end

"""
    cleanup_source_ids!(provider)

Release provenance-map references to nodes detached from their exact live plant
subtrees, returning the number of removed entries. Validate all namespaces before
changing any of them. Monotone per-plant high-water marks reserve former source
IDs permanently without retaining the detached organs themselves. Call after an
accepted botanical removal; the caller still owns scene/environment invalidation
and the next light-boundary rebuild. New provenance is assigned on that rebuild.
The single-plant provider has no retained node map and returns zero.
"""
cleanup_source_ids!(provider::DynamicSceneProvider) = 0

function cleanup_source_ids!(provider::MultiPlantSceneProvider)
    plans = _source_id_plans(
        provider.topologies, provider.source_ids, provider.source_id_highwaters;
        assign_new=false,
    )
    return _apply_source_id_plans!(
        provider.source_ids, provider.source_id_highwaters, plans; stamp=false,
    )
end

function source_roots(provider::MultiPlantSceneProvider, context=nothing)
    owners = PlantGeom.source_owners(provider.last_scene)
    result = Dict{Int,typeof(first(provider.topologies).plant)}()
    ordinals = Set{Int}()
    for placed_root in MultiScaleTreeGraph.children(provider.last_scene.mtg)
        ordinal = get(MultiScaleTreeGraph.node_attributes(placed_root), :id, nothing)
        ordinal isa Integer && 1 <= ordinal <= length(provider.topologies) ||
            throw(ArgumentError("a placed dynamic plant is missing its valid public plant id"))
        ordinal in ordinals && throw(ArgumentError("the scene repeats dynamic plant id $ordinal"))
        push!(ordinals, Int(ordinal))
        instances = Set{Int}()
        for node in MultiScaleTreeGraph.traverse(placed_root, identity)
            owner = get(owners, MultiScaleTreeGraph.node_id(node), nothing)
            owner === nothing || push!(instances, owner.source_instance_id)
        end
        length(instances) == 1 || throw(ArgumentError(
            "each placed dynamic plant must have exactly one actual source namespace",
        ))
        instance = only(instances)
        haskey(result, instance) && throw(ArgumentError("dynamic plants share a source namespace"))
        root = provider.topologies[Int(ordinal)].plant
        context === nothing || PlantSimEngine.object_id(context, root)
        result[instance] = root
    end
    length(ordinals) == length(provider.topologies) || throw(ArgumentError(
        "the radiative scene does not cover all dynamic plants",
    ))
    return result
end

end
