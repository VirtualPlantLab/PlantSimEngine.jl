"""Optional real-backend checks: run in the ecophysiology environment via Kaimon."""
module NativePhysiologyChecks

using Test
using AMAPSim
using ArchimedLight
using Dates
using PlantBiophysics
using PlantMeteo
using PlantSimEngine
import PlantGeom

const ROOT = pkgdir(AMAPSim)
include(joinpath(ROOT, "dev", "native", "native.jl"))
include(joinpath(ROOT, "dev", "native", "pse.jl"))
include(joinpath(ROOT, "dev", "native", "pse_physiology.jl"))
const Native = NativeAMAP
const Adapter = NativeAMAPPSE
const Physiology = NativeAMAPPhysiology

const PROFILES = (
    merisier=(file="merisier.fpa", leaf="feuilles",),
    rauh=(file="mod_Rauh.fpa", leaf="feuille",),
)

input(profile) = joinpath(ROOT, "test", "fixtures", "native_originals",
    getproperty(PROFILES, profile).file)

function forcing(; par=(450.0, 450.0, 0.0, 450.0), increment=0.5)
    return map(enumerate(par)) do (i, radiation)
        atmosphere = Atmosphere(date=DateTime(2023,6,21,10) + Hour(i-1),
            duration=Hour(1), T=25.0, Wind=1.0, P=101.3, Rh=0.65, Cₐ=400.0,
            Ri_PAR_f=Float64(radiation), Ri_NIR_f=0.55*Float64(radiation),
            sun_azimuth_deg=180.0, sun_elevation_deg=60.0, direct_fraction=0.7)
        return merge(NamedTuple(atmosphere), (duration_seconds=3600.0,
            development_rate_per_second=increment/3600.0))
    end
end

function setup(profile; ids=(:tree,), reserve=32.0,
    par=(450.0,450.0,0.0,450.0), increment=0.5)
    leaf_name = getproperty(PROFILES, profile).leaf
    plants = Tuple(Adapter.NativePlant(id, input(profile); seed=1,
        product_symbols=Dict(leaf_name=>:Leaf)) for id in ids)
    positions = Dict(ObjectId(id)=>(0.15*(i-1),0.0,0.0) for (i,id) in pairs(ids))
    surface = Physiology.NativeSurfaceGeometry(metres_per_native_unit=0.0001,
        leaf_width_per_native_diameter=2.0,
        domain=(-0.1,-0.1,0.35,0.2), plant_positions_m=positions)
    options = LightOptions(turtle_sectors=8, all_in_turtle=true,
        pixel_size=0.002, scattering=false, toricity=false,
        radiation_timestep_minutes=60.0, radiation_input_semantics=:interval_mean)
    optics = models_for("native"=>(
        "Leaf"=>translucent(par=0.15,nir=0.85),
        "*"=>translucent(par=0.20,nir=0.50)))
    demand = Adapter.FrustumGrowthDemand(density_gDM_per_cm3=0.5,
        construction_cost_gC_per_gDM=0.5, cm_per_native_unit=0.01)
    return Physiology.scenario(plants; weather=forcing(;par,increment), surface,
        light_options=options, optical_models=optics,
        photosynthesis_model=Fvcb(VcMaxRef=80.0,JMaxRef=140.0,RdRef=1.0),
        conductance_model=Medlyn(0.03,12.0), demand_model=demand,
        initial_reserve_gC=reserve, par_energy_to_photon=4.57,
        expansion_model=Adapter.IsometricExpansion())
end

# Geometry legitimately differs between potential and realized states. Compare
# every other changing arena field, including the architecture RNG and queue.
snapshot(x::Union{Number,Symbol,AbstractString,Nothing,Missing}) = x
snapshot(x::AbstractArray) = (size(x), map(snapshot,collect(x)))
snapshot(x::Tuple) = map(snapshot,x)
snapshot(x) = NamedTuple{fieldnames(typeof(x))}(
    map(name->snapshot(getfield(x,name)),fieldnames(typeof(x))))
function botanical_snapshot(model)
    p = model.plant
    names = filter(!=(:parameters),fieldnames(typeof(p)))
    fields = NamedTuple{names}(map(name->snapshot(getfield(p,name)),names))
    return merge(fields,(organs=[(site=o.site,axis=o.axis,rank=o.rank,active=o.active)
        for o in p.organs],))
end

function growth_balance(model,id,reserve)
    s = model_status(model,id)
    state = Adapter.native_state(model,id)
    g = state.organ_growth
    @test reserve + s.credited_carbon_supply_gC ≈
        s.remaining_carbon_gC + s.spent_carbon_gC + s.paid_carbon_loss_gC
    @test s.remaining_carbon_gC >= 0
    @test s.spent_carbon_gC >= 0 && s.paid_carbon_loss_gC >= 0
    @test s.living_dry_mass_gDM ≈ sum(g.structural_mass_gDM)
    @test s.removed_dry_mass_gDM == g.removed_dry_mass_gDM
    @test !state.coupled_pending && !g.failed
    @test g.committed_revision == g.revision
end

function opening_records(model)
    scene = only(model_objects(model;scale=:Scene)).status
    return copy(scene.radiation_records)
end

function check_profile(profile; reserve=32.0)
    @testset "Real native light/photosynthesis/growth: $profile reserve=$reserve" begin
        result = setup(profile;reserve)
        model = result.model
        reference = Native.NativeModel(input(profile);seed=1)
        simulation = nothing
        previous_active = Set{ObjectId}()
        positive = negative = 0.0
        saw_light = false
        saw_dark = false
        for step in 1:4
            before = Dict(object.id=>begin
                state=Adapter.native_state(model,:tree)
                organ=state.native.plant.organs[Int(object.id.value[3])]
                (;length=organ.length,top=organ.diameter_top,bottom=organ.diameter_bottom,
                    base=organ.base,tip=organ.tip,accepted_status=object.status)
            end for object in model_objects(model;scale=:Leaf))
            simulation = step==1 ? PlantSimEngine.run!(model;steps=1,outputs=:none) :
                (step!(simulation);simulation)
            Native.advance_to!(reference,0.5*step)
            state = Adapter.native_state(model,:tree)
            @test isequal(botanical_snapshot(state.native),botanical_snapshot(reference))
            @test state.development.physical_time == 3600.0*step
            @test isempty(model_objects(model;scale=:Internode))
            @test isempty(model_objects(model;scale=:Axis))
            records = opening_records(model)
            eligible=Set(id for (id,dimensions) in pairs(before)
                if dimensions.length>0 && dimensions.bottom>0)
            @test Set(record.object_id for record in records)==eligible
            @test all(record->record.object_id in previous_active,records)
            @test length(records)==length(unique(record.object_id for record in records))
            scene=only(model_objects(model;scale=:Scene)).status
            @test scene.light_epoch==step
            @test isfinite(scene.geometry_seconds) && scene.geometry_seconds>=0
            @test isfinite(scene.light_seconds) && scene.light_seconds>=0
            @test only(scene.opening_plant_times).physical_time==3600.0*(step-1)
            @test only(scene.opening_plant_times).development_time==0.5*(step-1)
            for record in records
                @test record.plant_id == ObjectId(:tree)
                @test record.object_id == Adapter.native_object_id(:tree,:Leaf,record.organ_id)
                @test record.area_m2 > 0 && isfinite(record.area_m2)
                @test record.aPPFD >= 0 && isfinite(record.aPPFD)
                @test haskey(before,record.object_id)
                prior=before[record.object_id]
                @test record.length == prior.length
                @test record.diameter_top == prior.top
                @test record.diameter_bottom == prior.bottom
                @test record.base == prior.base && record.tip == prior.tip
                # Independent analytic diamond area, with the single explicit
                # native-to-metre conversion applied to both diagonals.
                @test record.area_m2 ≈ Float64(prior.length)*Float64(prior.bottom)*
                    2.0*(0.0001)^2/2 rtol=1e-6
                # An opening leaf may naturally disappear during closing
                # development. Its retained owning Status still contains the
                # exchange accepted before that lifecycle removal.
                leaf = prior.accepted_status
                @test isfinite(leaf.A) && isfinite(leaf.carbon_step_gC)
                carbon=leaf.A*record.area_m2*3600.0*12e-6
                @test leaf.carbon_step_gC ≈ carbon
                positive += max(carbon,0.0)
                negative += max(-carbon,0.0)
                if step==3
                    @test iszero(record.aPPFD)
                    @test leaf.A < 0
                    saw_dark=true
                elseif record.aPPFD>0
                    saw_light=true
                end
            end
            s=model_status(model,:tree)
            @test s.credited_carbon_supply_gC ≈ positive
            @test s.paid_carbon_loss_gC ≈ negative
            growth_balance(model,:tree,reserve)
            previous_active=Set(object.id for object in model_objects(model;scale=:Leaf))
        end
        if reserve==32.0
            @test saw_light
            @test saw_dark
            @test positive>0 && negative>0
            @test model_status(model,:tree).living_dry_mass_gDM>0
        else
            @test model_status(model,:tree).spent_carbon_gC <= reserve + positive
            @test model_status(model,:tree).spent_carbon_gC>0
        end
        return result
    end
end

function check_two_plant_ownership_and_cut()
    @testset "Two typed plant identities own light and carbon; cuts remove only their surfaces" begin
        ids=(1,Symbol("1"))
        reserve=32.0
        result=setup(:merisier;ids,reserve,par=(450.0,450.0,0.0,450.0,450.0))
        model=result.model
        positive=Dict(ObjectId(id)=>0.0 for id in ids)
        negative=Dict(ObjectId(id)=>0.0 for id in ids)
        simulation=nothing
        found_shared_raw_ids=false
        for step in 1:3
            opening_status=Dict(object.id=>object.status
                for object in model_objects(model;scale=:Leaf))
            simulation=step==1 ? PlantSimEngine.run!(model;steps=1,outputs=:none) :
                (step!(simulation);simulation)
            records=opening_records(model)
            @test length(records)==length(unique(r.object_id for r in records))
            byplant=Dict(ObjectId(id)=>Set{Int}() for id in ids)
            for record in records
                @test record.plant_id in keys(positive)
                @test record.plant_id == ObjectId(ids[record.source_instance_id])
                @test record.object_id == Adapter.native_object_id(record.plant_id,:Leaf,
                    record.organ_id)
                @test record.object_id.value[1] === record.plant_id.value
                push!(byplant[record.plant_id],record.organ_id)
                @test haskey(opening_status,record.object_id)
                leaf=opening_status[record.object_id]
                carbon=leaf.A*record.area_m2*3600.0*12e-6
                @test leaf.carbon_step_gC ≈ carbon
                positive[record.plant_id]+=max(carbon,0.0)
                negative[record.plant_id]+=max(-carbon,0.0)
            end
            if !isempty(records)
                found_shared_raw_ids |= !isempty(intersect(byplant[ObjectId(ids[1])],
                    byplant[ObjectId(ids[2])]))
                # Independent scene provenance: each source owner names a
                # native slot within its own source instance, not a scene ID.
                owners=Set((key.source_instance_id,key.source_node_id)
                    for key in values(PlantGeom.source_owners(result.radiation.last_scene)))
                @test all(r->(r.source_instance_id,r.organ_id) in owners,records)
            end
            for id in ids
                s=model_status(model,id)
                @test s.credited_carbon_supply_gC ≈ positive[ObjectId(id)]
                @test s.paid_carbon_loss_gC ≈ negative[ObjectId(id)]
                growth_balance(model,id,reserve)
            end
        end
        @test found_shared_raw_ids
        first=Adapter.native_state(model,ids[1])
        second=Adapter.native_state(model,ids[2])
        @test first.organ_growth !== second.organ_growth
        first_mass=sum(first.organ_growth.structural_mass_gDM)
        removed=first.organ_growth.removed_dry_mass_gDM
        spent=first.organ_growth.spent_carbon_gC
        other_before=botanical_snapshot(second.native)
        @test Adapter.cut_axis!(model,ids[1],1).removed
        @test all(!o.active for o in first.native.plant.organs)
        @test all(iszero,first.organ_growth.structural_mass_gDM)
        @test first.organ_growth.removed_dry_mass_gDM ≈ removed+first_mass
        @test first.organ_growth.spent_carbon_gC==spent
        @test isequal(botanical_snapshot(second.native),other_before)
        @test all(o->o.parent!=ObjectId(ids[1]),model_objects(model;scale=:Leaf))
        @test any(o->o.parent==ObjectId(ids[2]),model_objects(model;scale=:Leaf))
        step!(simulation)
        records=opening_records(model)
        @test !isempty(records)
        @test all(r->r.plant_id==ObjectId(ids[2]),records)
        @test first.organ_growth.spent_carbon_gC==spent
        @test first.organ_growth.removed_dry_mass_gDM ≈ removed+first_mass
        @test all(!o.active for o in first.native.plant.organs)
        @test !Adapter.cut_axis!(model,ids[1],1).removed
        growth_balance(model,ids[1],reserve)
        growth_balance(model,ids[2],reserve)

        # When the entire scene is removed, a later interval has no hidden
        # photosynthetic surface and releases the previous light solver cache.
        other_spent=second.organ_growth.spent_carbon_gC
        @test Adapter.cut_axis!(model,ids[2],1).removed
        step!(simulation)
        @test isempty(opening_records(model))
        @test isempty(model_objects(model;scale=:Leaf))
        @test result.radiation.last_scene===nothing
        @test result.radiation.simulation===nothing
        @test first.organ_growth.spent_carbon_gC==spent
        @test second.organ_growth.spent_carbon_gC==other_spent
        growth_balance(model,ids[1],reserve)
        growth_balance(model,ids[2],reserve)
    end
end

function check_surface_units_and_signed_integration()
    @testset "Surface conversion and signed interval integration are explicit" begin
        @test_throws ArgumentError Physiology.NativeSurfaceGeometry(
            metres_per_native_unit=0.0,leaf_width_per_native_diameter=2.0,
            domain=(-1,-1,1,1),plant_positions_m=Dict(:tree=>(0,0,0)))
        @test_throws ArgumentError Physiology.NativeSurfaceGeometry(
            metres_per_native_unit=0.01,leaf_width_per_native_diameter=-1.0,
            domain=(-1,-1,1,1),plant_positions_m=Dict(:tree=>(0,0,0)))
        @test_throws ArgumentError Physiology.NativeSurfaceGeometry(
            metres_per_native_unit=0.01,leaf_width_per_native_diameter=2.0,
            domain=(1,-1,-1,1),plant_positions_m=Dict(:tree=>(0,0,0)))
        for assimilation in (-2.0,0.0,10.0),area in (0.0,0.02)
            status=CarbonStatus(assimilation,area,NaN)
            PlantSimEngine.run!(Physiology.SurfaceNetCarbon(),status,
                (duration_seconds=1800.0,),nothing,nothing)
            @test status.carbon_step_gC==assimilation*area*1800.0*12e-6
        end
        state=CarbonStatus(10.0,-0.01,123.0)
        @test_throws ArgumentError PlantSimEngine.run!(Physiology.SurfaceNetCarbon(),state,
            (duration_seconds=1800.0,),nothing,nothing)
        @test state.carbon_step_gC==123.0

        # A radiation interval may be consumed more than once by an explicit
        # coupling caller; only its first accepted supply evaluation credits it.
        supply=SupplyStatus([2.0,-1.0,0.0],1,0.0,0.0,0.0,0)
        step_supply(rate)=PlantSimEngine.run!(Physiology.PhotosyntheticSupply(),supply,
            (development_rate_per_second=rate,),nothing,nothing)
        step_supply(0.5)
        @test supply.cumulative_carbon_supply_gC==2.0
        @test supply.cumulative_carbon_loss_gC==1.0
        @test supply.credited_light_epoch==1
        step_supply(0.75)
        @test supply.cumulative_carbon_supply_gC==2.0
        @test supply.cumulative_carbon_loss_gC==1.0
        @test supply.development_rate==0.75
        supply.light_epoch=2
        supply.leaf_carbon_gC=[0.5,-0.25]
        step_supply(1.0)
        @test supply.cumulative_carbon_supply_gC==2.5
        @test supply.cumulative_carbon_loss_gC==1.25
        @test supply.credited_light_epoch==2
        supply.light_epoch=1
        @test_throws ArgumentError step_supply(1.0)
        supply.light_epoch=3
        supply.leaf_carbon_gC=[2.0,NaN]
        @test_throws ArgumentError step_supply(1.0)
        @test supply.cumulative_carbon_supply_gC==2.5
        @test supply.cumulative_carbon_loss_gC==1.25
        @test supply.credited_light_epoch==2
    end
end

function check_failed_exchange_guard()
    @testset "An unfinished physiological interval cannot credit a second interval" begin
        ids=(ObjectId(1),ObjectId(Symbol("1")))
        native(id,time;pending=false)=(plant_id=id,coupled_pending=pending,
            development=(physical_time=time,))
        states=[native(id,3600.0) for id in ids]
        opening=[(plant_id=id,physical_time=0.0) for id in ids]
        checkpoint=(native_states=states,light_epoch=1,opening_plant_times=opening,
            preceding_interval_seconds=3600.0)
        @test Physiology._validate_preceding_exchange(checkpoint)===nothing
        @test_throws ArgumentError Physiology._validate_preceding_exchange(
            merge(checkpoint,(native_states=[native(ids[1],0.0),native(ids[2],3600.0)],)))
        @test_throws ArgumentError Physiology._validate_preceding_exchange(
            merge(checkpoint,(native_states=[native(ids[1],3600.0;pending=true),
                native(ids[2],3600.0)],)))
        @test_throws ArgumentError Physiology._validate_preceding_exchange(
            merge(checkpoint,(native_states=[states[1],states[1]],)))
        @test_throws ArgumentError Physiology._validate_preceding_exchange(
            merge(checkpoint,(native_states=[states[1]],)))

        # A public composition failure before architectural mutation used to
        # leave physiology credited but allow radiation to start again. The
        # next attempt must reject before a new light epoch or bank credit.
        result=setup(:merisier)
        model=result.model
        simulation=PlantSimEngine.run!(model;steps=1,outputs=:none)
        state=Adapter.native_state(model,:tree)
        status=model_status(model,:tree)
        scene=only(model_objects(model;scale=:Scene)).status
        status.axis_development_rates=Dict(typemax(Int)=>0.0)
        @test_throws Exception step!(simulation)
        @test !state.coupled_pending # failure is in architectural preflight
        @test state.development.physical_time==3600.0
        @test scene.light_epoch==2
        credited=(status.cumulative_carbon_supply_gC,status.cumulative_carbon_loss_gC)
        status.axis_development_rates=Dict{Int,Float64}()
        @test_throws Exception step!(simulation)
        @test scene.light_epoch==2
        @test (status.cumulative_carbon_supply_gC,status.cumulative_carbon_loss_gC)==credited
        @test state.development.physical_time==3600.0
    end
end

mutable struct CarbonStatus
    A::Float64
    area_m2::Float64
    carbon_step_gC::Float64
end

mutable struct SupplyStatus
    leaf_carbon_gC::Vector{Float64}
    light_epoch::Int
    cumulative_carbon_supply_gC::Float64
    cumulative_carbon_loss_gC::Float64
    development_rate::Float64
    credited_light_epoch::Int
end

function run_checks()
    check_surface_units_and_signed_integration()
    check_profile(:merisier)
    check_profile(:rauh)
    check_profile(:merisier;reserve=1.0e-8)
    check_profile(:rauh;reserve=1.0e-8)
    check_two_plant_ownership_and_cut()
    check_failed_exchange_guard()
end

end
