using AMAPSim
using ArchimedLight
using MultiScaleTreeGraph
using PlantBiophysics
using PlantGeom
using PlantMeteo
using PlantSimEngine
using Test

include(joinpath(@__DIR__, "..", "run.jl"))
include("native_history_runtests.jl")

@testset "Native Leaf distributed light and physiology" begin
    applications = physiology_applications()
    @test length(applications) == 4

    leaf_carbon_contracts = PlantSimEngine.variable_contracts(LeafCarbonGain())
    allocation_contracts = PlantSimEngine.variable_contracts(
        FixedFractionAllocation(0.30, 0.50, 0.20),
    )
    area_contract = leaf_carbon_contracts.area
    @test (
        area_contract.unit,
        area_contract.basis,
        area_contract.temporal,
        area_contract.aggregation,
        area_contract.extent,
    ) == (:square_metre, :organ, nothing, :total, :extensive)
    carbon_contract = leaf_carbon_contracts.carbon_gain_g
    @test (
        carbon_contract.unit,
        carbon_contract.basis,
        carbon_contract.temporal,
        carbon_contract.aggregation,
        carbon_contract.extent,
    ) == (:gram_carbon, :organ, :step, :total, :extensive)
    @test allocation_contracts.leaf_carbon_g ==
          carbon_contract

    for retired in (
        :run_light_stage_manual,
        :_leaf_light_update_plan,
        :apply_leaf_light!,
        :run_physiology_stage_manual!,
        :_run_example_manual,
    )
        @test !isdefined(Main, retired)
    end

    preflight = grow_coffee(1; seed=CANONICAL_SEED)
    atmosphere = tutorial_atmosphere()
    initialize_leaf_physiology!(preflight, atmosphere)
    preflight_leaves = filter(
        is_coffee_leaf,
        MultiScaleTreeGraph.traverse(preflight.result.topology.scene, identity),
    )

    # The Nature-2 birth-date parity correction realizes all 20 H1 leaves.
    # This canonical guard matches test-coffee-example.jl (updated in 8ae56d0);
    # coupling coverage below is checked against the independent native MTG.
    expected_leaf_ids = Set(node_id(leaf) for leaf in preflight_leaves)
    @test length(expected_leaf_ids) == 20
    @test length(preflight_leaves) == length(expected_leaf_ids)
    for leaf in preflight_leaves
        attributes = MultiScaleTreeGraph.node_attributes(leaf)
        @test get(attributes, :aPPFD, nothing) === nothing
        @test get(attributes, :aPPFD_leaf_mean, nothing) === nothing
        @test get(attributes, :area, nothing) === nothing
        @test leaf[:botanical_leaf_area] ≈
              Float64(leaf[:EstimatedLeafAreaCm2]) *
              SQUARE_CENTIMETRES_TO_SQUARE_METRES
        @test leaf[:Tₗ] == atmosphere.T
        @test leaf[:Cₛ] == atmosphere.Cₐ
        @test leaf[:Dₗ] == atmosphere.VPD
    end

    invalid_snapshot = grow_coffee(1; seed=CANONICAL_SEED)
    invalid_leaves = filter(
        is_coffee_leaf,
        MultiScaleTreeGraph.traverse(
            invalid_snapshot.result.topology.scene,
            identity,
        ),
    )
    last(invalid_leaves)[:EstimatedLeafAreaCm2] = 0.0
    physiology_state(leaf) = begin
        attributes = MultiScaleTreeGraph.node_attributes(leaf)
        return (
            Tₗ=get(attributes, :Tₗ, nothing),
            Cₛ=get(attributes, :Cₛ, nothing),
            Dₗ=get(attributes, :Dₗ, nothing),
            botanical_leaf_area=get(attributes, :botanical_leaf_area, nothing),
        )
    end
    state_before_invalid_initialization = Dict(
        MultiScaleTreeGraph.node_id(leaf) => physiology_state(leaf)
        for leaf in invalid_leaves
    )
    @test_throws "invalid botanical area" initialize_leaf_physiology!(
        invalid_snapshot,
        atmosphere,
    )
    @test all(
        physiology_state(leaf) ==
        state_before_invalid_initialization[MultiScaleTreeGraph.node_id(leaf)]
        for leaf in invalid_leaves
    )

    # Assimilation and radiation share the mesh surface reference. A separate
    # botanical estimate must not silently rescale the integrated carbon gain.
    direct_status = Status(;
        A=10.0,
        area=0.02,
        botanical_leaf_area=0.5,
        carbon_gain_g=0.0,
    )
    PlantSimEngine.run!(LeafCarbonGain(), direct_status, atmosphere)
    @test direct_status.carbon_gain_g ≈
          10.0 * 0.02 * 3600.0 * CARBON_MOLAR_MASS_G_PER_MICROMOL

    result = run_example(; horizon=1, seed=CANONICAL_SEED, applications)
    light_contracts = PlantSimEngine.variable_contracts(result.physiology.light_kernel)
    @test light_contracts.aPPFD ==
          PlantSimEngine.variable_contracts(Fvcb()).aPPFD
    @test light_contracts.aPPFD.basis == :surface_area
    @test light_contracts.area == area_contract

    topology = result.snapshot.result.topology.scene
    native_leaves = filter(is_coffee_leaf, MultiScaleTreeGraph.traverse(topology, identity))
    topology_leaf_ids = Set(node_id(leaf) for leaf in native_leaves)
    @test topology_leaf_ids == expected_leaf_ids
    @test Set(row.organ_id for row in result.leaves) == topology_leaf_ids
    @test length(result.leaves) == length(topology_leaf_ids)
    @test all(PlantGeom.has_geometry, native_leaves)
    for row in result.leaves
        node = MultiScaleTreeGraph.get_node(topology, Int(row.organ_id))
        @test node !== nothing
        @test MultiScaleTreeGraph.symbol(node) == :Leaf
    end

    model = result.physiology.model
    simulation = result.physiology.simulation
    leaf_objects = collect(PlantSimEngine.model_objects(model; scale=:Leaf))
    leaf_object_ids = Set(object.id for object in leaf_objects)
    leaf_node_ids = Set(object.id.value for object in leaf_objects)
    @test length(leaf_objects) == length(topology_leaf_ids)
    @test topology_leaf_ids == leaf_node_ids
    @test Set(source_node(model, object) for object in leaf_objects) == Set(native_leaves)

    runtime_cache = getproperty(result.physiology.light_kernel, :runtime_cache)
    @test runtime_cache !== nothing
    owner_map = getproperty(runtime_cache, :owner_map)
    @test PlantGeom.source_owner_map_iscurrent(
        owner_map,
        result.light.simulation.scene,
        model,
    )
    @test Set(getproperty(runtime_cache, :target_ids)) == leaf_object_ids
    @test length(owner_map) >= length(topology_leaf_ids)
    @test all(key.source_instance_id > 0 for key in keys(owner_map))
    @test any(
        scene_id != owner.source_node_id for (scene_id, owner) in
        PlantGeom.source_owners(result.light.simulation.scene) if owner !== nothing
    )

    schedule = Dict(
        row.application_id => row
        for row in PlantSimEngine.Diagnostics.explain_schedule(simulation)
    )
    @test schedule[:archimed_light].execution_index <
          schedule[:photosynthesis].execution_index <
          schedule[:leaf_carbon_gain].execution_index <
          schedule[:carbon_allocation].execution_index
    @test schedule[:archimed_light].execution_index <
          schedule[:leaf_carbon_gain].execution_index
    @test schedule[:stomatal_conductance].manual_call_only

    bindings = PlantSimEngine.Diagnostics.explain_bindings(simulation)
    function producer_rows(application_id, input)
        filter(
            row -> row.application_id == application_id && row.input == input,
            bindings,
        )
    end

    photosynthesis_light = producer_rows(:photosynthesis, :aPPFD)
    radiative_area = producer_rows(:leaf_carbon_gain, :area)
    carbon_assimilation = producer_rows(:leaf_carbon_gain, :A)
    carbon_gather = producer_rows(:carbon_allocation, :leaf_carbon_g)
    for leaf_bindings in (photosynthesis_light, radiative_area, carbon_assimilation)
        @test length(leaf_bindings) == length(topology_leaf_ids)
        @test Set(row.consumer_id for row in leaf_bindings) == leaf_node_ids
        @test all(row.source_ids == [row.consumer_id] for row in leaf_bindings)
    end
    @test length(carbon_gather) == 1
    @test all(row.source_application_ids == [:archimed_light]
              for row in photosynthesis_light)
    @test all(row.source_application_ids == [:archimed_light]
              for row in radiative_area)
    @test all(row.source_application_ids == [:photosynthesis]
              for row in carbon_assimilation)
    @test only(carbon_gather).source_application_ids == [:leaf_carbon_gain]
    @test Set(only(carbon_gather).source_ids) == leaf_node_ids
    @test all(row.policy isa HoldLast for row in photosynthesis_light)
    @test all(row.policy isa HoldLast for row in radiative_area)
    @test all(row.policy isa HoldLast for row in carbon_assimilation)
    @test only(carbon_gather).policy isa HoldLast

    light_variables = Set(propertynames(archimed_light_outputs(:coupling)))
    light_writers = filter(
        row -> :archimed_light in row.application_ids,
        PlantSimEngine.Diagnostics.explain_writers(simulation),
    )
    @test length(light_writers) == length(topology_leaf_ids) * length(light_variables)
    @test Set((row.object_id, row.variable) for row in light_writers) ==
          Set((id, variable) for id in leaf_node_ids for variable in light_variables)
    @test all(row.object_id in leaf_node_ids for row in light_writers)
    @test Set(row.variable for row in light_writers) == light_variables

    duration_seconds = _duration_seconds(tutorial_atmosphere())
    for object in leaf_objects
        status = object.status
        raw_aPPFD = last(PlantSimEngine.outputs(simulation)[
            (:archimed_light, object.id, :aPPFD)
        ])[2]
        raw_radiative_area = last(PlantSimEngine.outputs(simulation)[
            (:archimed_light, object.id, :area)
        ])[2]
        @test status.area > 0
        @test isfinite(status.aPPFD) && status.aPPFD >= 0
        source_leaf = PlantSimEngine.source_node(model, object)
        expected_botanical_area =
            Float64(source_leaf[:EstimatedLeafAreaCm2]) *
            SQUARE_CENTIMETRES_TO_SQUARE_METRES
        @test status.botanical_leaf_area ≈ expected_botanical_area
        @test status.aPPFD ≈ raw_aPPFD
        @test status.area ≈ raw_radiative_area
        result_row = only(row for row in result.leaves if row.organ_id == object.id.value)
        @test result_row.aPPFD_radiative ≈ raw_aPPFD
        @test result_row.radiative_mesh_area ≈ raw_radiative_area
        @test result_row.aPPFD_surface ≈ raw_aPPFD
        @test isfinite(status.A)
        @test isfinite(status.carbon_gain_g) && status.carbon_gain_g > 0
        expected_carbon = status.A * raw_radiative_area *
                          duration_seconds * CARBON_MOLAR_MASS_G_PER_MICROMOL
        @test status.carbon_gain_g ≈ expected_carbon atol=1.0e-12 rtol=1.0e-12
    end

    for object in PlantSimEngine.model_objects(model)
        object.scale === :Leaf && continue
        @test !hasproperty(object.status, :area)
        @test !hasproperty(object.status, :aPPFD)
        @test !hasproperty(object.status, :aPPFD_leaf_mean)
        @test !hasproperty(object.status, :botanical_leaf_area)
    end

    @test all(
        row -> row.aPPFD_radiative ≈ row.aPPFD_surface,
        result.leaves,
    )

    plant = result.plant
    leaf_carbon = sum(row.carbon_gain_g for row in result.leaves)
    pool_carbon = plant.leaf_pool_g + plant.wood_pool_g + plant.reserve_pool_g
    @test plant.assimilated_carbon_g ≈ leaf_carbon atol=1.0e-10 rtol=1.0e-10
    @test plant.assimilated_carbon_g ≈ pool_carbon atol=1.0e-10 rtol=1.0e-10
    @test plant.leaf_pool_g ≈ 0.30 * plant.assimilated_carbon_g atol=1.0e-12 rtol=1.0e-12
    @test plant.wood_pool_g ≈ 0.50 * plant.assimilated_carbon_g atol=1.0e-12 rtol=1.0e-12
    @test plant.reserve_pool_g ≈ 0.20 * plant.assimilated_carbon_g atol=1.0e-12 rtol=1.0e-12
end

include("dynamic_runtests.jl")
include("two_plant_runtests.jl")
include("fpa_runtests.jl")
FpaCouplingValidation.run_tests()
