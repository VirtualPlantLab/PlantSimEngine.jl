"""Illustrative progressive deployment of an organ whose construction is prepaid."""
module OrganExpansionModels

import MultiScaleTreeGraph
import PlantSimEngine
using ..DynamicPhysiologyModels: AbstractLeaf_DimensionModel, LEAF_DIMENSION_CONTRACT

export OrganExpansion, ExpandedLeafDimension

PlantSimEngine.@process "organ_expansion" verbose=false

const _LENGTH_CM_CONTRACT = PlantSimEngine.VariableContract(
    unit=:centimetre, basis=:organ, temporal=:instantaneous,
    aggregation=:state, extent=:intensive,
)
const _FRACTION_CONTRACT = PlantSimEngine.VariableContract(
    unit=:fraction, basis=:organ, temporal=:instantaneous,
    aggregation=:state, extent=:intensive,
)
const _AGE_SECONDS_CONTRACT = PlantSimEngine.VariableContract(
    unit=:second, basis=:organ, temporal=:instantaneous,
    aggregation=:state, extent=:intensive,
)
const _STEP_SECONDS_CONTRACT = PlantSimEngine.VariableContract(
    unit=:second, temporal=:step, aggregation=:total, extent=:intensive,
)
const _CONSTRUCTION_COST_CONTRACT = PlantSimEngine.VariableContract(
    unit=:g_carbon, basis=:organ, temporal=:instantaneous,
    aggregation=:state, extent=:extensive,
)

# A distinct input name prevents PSE's shared reference wiring from aliasing
# the native potential Width to the current expanded width.
struct ExpandedLeafDimension <: AbstractLeaf_DimensionModel end
PlantSimEngine.inputs_(::ExpandedLeafDimension) = (
    expanded_width_cm=PlantSimEngine.Required(Real),
)
PlantSimEngine.outputs_(::ExpandedLeafDimension) = (d=0.0,)
PlantSimEngine.variable_contracts_(::ExpandedLeafDimension) = (
    expanded_width_cm=_LENGTH_CM_CONTRACT, d=LEAF_DIMENSION_CONTRACT,
)
function PlantSimEngine.run!(::ExpandedLeafDimension, status, environment,
                             constants=nothing, context=nothing)
    width = _finite_real(status.expanded_width_cm, "expanded_width_cm")
    width > zero(width) || throw(DomainError(width, "expanded_width_cm must be positive"))
    d = width * 0.01
    isfinite(d) && d > zero(d) || throw(ArgumentError("expanded width cannot be represented in metres"))
    status.d = d
    return nothing
end

function _finite_real(value, label)
    value isa Real && !(value isa Bool) || throw(ArgumentError("$label must be real"))
    isfinite(value) || throw(ArgumentError("$label must be finite"))
    return value
end

function _typed_amount(::Type{T}, value, label; positive=false) where {T}
    _finite_real(value, label)
    value >= zero(value) || throw(DomainError(value, "$label cannot be negative"))
    positive && value <= zero(value) && throw(DomainError(value, "$label must be positive"))
    converted = try
        convert(T, value)
    catch error
        throw(ArgumentError("$label cannot be represented as $T: " * sprint(showerror, error)))
    end
    isfinite(converted) || throw(ArgumentError("$label must remain finite in $T"))
    value > zero(value) && iszero(converted) && throw(ArgumentError(
        "$label underflows to zero in $T",
    ))
    return converted
end

"""
    OrganExpansion(symbol; maturation_seconds=7200.0, birth_fraction=0.25,
                   construction_cost_gC)

Deploy the potential dimensions of one selected, already funded native organ.
The first accepted call occurs at its actual realization endpoint, captures
`Length`, `Width` and `Thickness` in centimetres, and starts physical age at zero.
It never assigns age from a scheduled developmental event or charges the
preceding interval to a newborn. Later calls advance age by explicit elapsed
seconds, up to `maturation_seconds`. The deployment fraction rises linearly from
`birth_fraction` to one; each dimension is scaled by its cube root. For the planar leaf lamina, surface
area scales as `fraction^(2/3)`, not as the fraction itself. A tapered stem
connected to a predecessor at a different stage need not have that area ratio.

This isotropic rule is an illustrative kinematic assumption, not calibrated
allometry or a mass estimate derived from a thin lamina's mesh volume. The
`construction_cost_gC` is the full COUP-2 payment already made at birth. Outputs
`deployed_construction_gC` and `unexpanded_construction_gC` partition that prepaid
cost; they are construction-cost equivalents, not tissue carbon stocks. Their
sum equals `prepaid_construction_gC`. No additional allocation or random draw
occurs during expansion.

Runtime organs marked exactly `RuntimeScaffold === true` are excluded. Direct
kernel calls without a runtime context represent explicitly selected non-scaffold
organs. Native potential dimensions are never changed. A geometry provider must
apply the expanded dimensions to a disposable whole-plant view before rebuilding
its attachment frames. The calling controller owns accepted geometry invalidation
after the batch; this kernel only reports `expansion_changed`.
"""
struct OrganExpansion{T<:Real} <: AbstractOrgan_ExpansionModel
    symbol::Symbol
    maturation_seconds::T
    birth_fraction::T
    construction_cost_gC::T
end

function OrganExpansion(symbol; maturation_seconds=7200.0, birth_fraction=0.25,
                        construction_cost_gC)
    symbol isa Symbol || throw(ArgumentError("organ symbol must be a Symbol"))
    duration = _finite_real(maturation_seconds, "maturation_seconds")
    fraction = _finite_real(birth_fraction, "birth_fraction")
    cost = _finite_real(construction_cost_gC, "construction_cost_gC")
    duration > zero(duration) || throw(DomainError(duration, "maturation_seconds must be positive"))
    zero(fraction) < fraction <= one(fraction) || throw(DomainError(
        fraction, "birth_fraction must be in (0, 1]",
    ))
    cost >= zero(cost) || throw(DomainError(cost, "construction_cost_gC cannot be negative"))
    duration, fraction, cost = promote(float(duration), float(fraction), float(cost))
    T = typeof(duration)
    return OrganExpansion{T}(symbol,
        _typed_amount(T, duration, "maturation_seconds"; positive=true),
        _typed_amount(T, fraction, "birth_fraction"; positive=true),
        _typed_amount(T, cost, "construction_cost_gC"))
end

PlantSimEngine.inputs_(::OrganExpansion) = (
    Length=PlantSimEngine.Required(Real),
    Width=PlantSimEngine.Required(Real),
    Thickness=PlantSimEngine.Required(Real),
)
PlantSimEngine.environment_inputs_(model::OrganExpansion) = (
    duration_seconds=zero(model.maturation_seconds),
)
PlantSimEngine.outputs_(model::OrganExpansion) = (
    expansion_initialized=false,
    expansion_age_seconds=zero(model.maturation_seconds),
    expansion_fraction=zero(model.birth_fraction),
    target_length_cm=zero(model.maturation_seconds),
    target_width_cm=zero(model.maturation_seconds),
    target_thickness_cm=zero(model.maturation_seconds),
    expanded_length_cm=zero(model.maturation_seconds),
    expanded_width_cm=zero(model.maturation_seconds),
    expanded_thickness_cm=zero(model.maturation_seconds),
    prepaid_construction_gC=zero(model.construction_cost_gC),
    deployed_construction_gC=zero(model.construction_cost_gC),
    unexpanded_construction_gC=zero(model.construction_cost_gC),
    expansion_changed=false,
)
PlantSimEngine.variable_contracts_(::OrganExpansion) = (
    Length=_LENGTH_CM_CONTRACT,
    Width=_LENGTH_CM_CONTRACT,
    Thickness=_LENGTH_CM_CONTRACT,
    target_length_cm=_LENGTH_CM_CONTRACT,
    target_width_cm=_LENGTH_CM_CONTRACT,
    target_thickness_cm=_LENGTH_CM_CONTRACT,
    expanded_length_cm=_LENGTH_CM_CONTRACT,
    expanded_width_cm=_LENGTH_CM_CONTRACT,
    expanded_thickness_cm=_LENGTH_CM_CONTRACT,
    duration_seconds=_STEP_SECONDS_CONTRACT,
    expansion_age_seconds=_AGE_SECONDS_CONTRACT,
    expansion_fraction=_FRACTION_CONTRACT,
    prepaid_construction_gC=_CONSTRUCTION_COST_CONTRACT,
    deployed_construction_gC=_CONSTRUCTION_COST_CONTRACT,
    unexpanded_construction_gC=_CONSTRUCTION_COST_CONTRACT,
)

function PlantSimEngine.run!(model::OrganExpansion{T}, status, environment,
                             constants=nothing, context=nothing) where {T}
    if context !== nothing
        node = PlantSimEngine.source_node(context)
        if get(MultiScaleTreeGraph.node_attributes(node), :RuntimeScaffold, false) === true
            status.expansion_changed = false
            return nothing
        end
        MultiScaleTreeGraph.symbol(node) === model.symbol || throw(ArgumentError(
            "OrganExpansion($(repr(model.symbol))) received a different native organ symbol",
        ))
    end
    initialized = status.expansion_initialized
    initialized isa Bool || throw(ArgumentError("expansion_initialized must be boolean"))
    elapsed = _typed_amount(T, environment.duration_seconds, "duration_seconds")
    if initialized
        length_cm = _typed_amount(T, status.target_length_cm, "target_length_cm"; positive=true)
        width_cm = _typed_amount(T, status.target_width_cm, "target_width_cm"; positive=true)
        thickness_cm = _typed_amount(T, status.target_thickness_cm, "target_thickness_cm")
        previous_age = _typed_amount(T, status.expansion_age_seconds, "expansion_age_seconds")
        previous_age <= model.maturation_seconds || throw(DomainError(
            previous_age, "expansion age cannot exceed maturation_seconds",
        ))
        previous_fraction = _typed_amount(T, status.expansion_fraction, "expansion_fraction";
                                          positive=true)
        model.birth_fraction <= previous_fraction <= one(T) || throw(DomainError(
            previous_fraction, "expansion fraction must remain between birth_fraction and one",
        ))
        # Bound the increment before adding to avoid an overflowing intermediate.
        age = previous_age + min(elapsed, model.maturation_seconds - previous_age)
    else
        length_cm = _typed_amount(T, status.Length, "native Length in cm"; positive=true)
        width_cm = _typed_amount(T, status.Width, "native Width in cm"; positive=true)
        thickness_cm = _typed_amount(T, status.Thickness, "native Thickness in cm")
        age = zero(T)
    end
    fraction = model.birth_fraction + (one(T) - model.birth_fraction) *
        (age / model.maturation_seconds)
    scale = cbrt(fraction)
    expanded_length = _typed_amount(T, length_cm * scale, "expanded_length_cm"; positive=true)
    expanded_width = _typed_amount(T, width_cm * scale, "expanded_width_cm"; positive=true)
    expanded_thickness = _typed_amount(T, thickness_cm * scale, "expanded_thickness_cm")
    deployed = _typed_amount(T, fraction * model.construction_cost_gC,
                              "deployed_construction_gC")
    unexpanded = _typed_amount(T, model.construction_cost_gC - deployed,
                                "unexpanded_construction_gC")
    changed = !initialized || fraction != status.expansion_fraction ||
        expanded_length != status.expanded_length_cm || expanded_width != status.expanded_width_cm ||
        expanded_thickness != status.expanded_thickness_cm
    # Validate the entire update before changing any status output.
    status.expansion_initialized = true
    status.expansion_age_seconds = age
    status.expansion_fraction = fraction
    status.target_length_cm = length_cm
    status.target_width_cm = width_cm
    status.target_thickness_cm = thickness_cm
    status.expanded_length_cm = expanded_length
    status.expanded_width_cm = expanded_width
    status.expanded_thickness_cm = expanded_thickness
    status.prepaid_construction_gC = model.construction_cost_gC
    status.deployed_construction_gC = deployed
    status.unexpanded_construction_gC = unexpanded
    status.expansion_changed = changed
    return nothing
end

end
