"""
Small, inspectable adapters for the dynamic light–physiology–growth example.

These models retain native organ identities, use the represented mesh surface
area consistently, and account for signed net leaf exchange. Parameters remain
illustrative inputs; this module supplies neither calibration nor a maintenance
respiration model for non-leaf organs. Loading it does not start a simulation.
"""
module DynamicPhysiologyModels

import AMAPSim
import PlantBiophysics
import PlantSimEngine

include(joinpath(@__DIR__, "..", "growth_demand", "models.jl"))
using .GrowthDemandModels

export LeafDimension, SurfaceEnergyBalance, LeafNetCarbon
export PlantCarbonSupply, PhotosyntheticReserveAllocation
export GrowthDemandModels, ORGAN_STEP_CARBON_CONTRACT, ORGAN_AREA_CONTRACT

const ORGAN_AREA_CONTRACT = PlantSimEngine.VariableContract(
    unit=:square_metre, basis=:organ, temporal=nothing,
    aggregation=:total, extent=:extensive,
)
const ORGAN_STEP_CARBON_CONTRACT = PlantSimEngine.VariableContract(
    unit=:g_carbon, basis=:organ, temporal=:step,
    aggregation=:total, extent=:extensive,
)
const SECOND_CONTRACT = PlantSimEngine.VariableContract(
    unit=:second, temporal=:step, aggregation=:total, extent=:intensive,
)
const LEAF_DIMENSION_CONTRACT = PlantSimEngine.VariableContract(
    unit=:metre, basis=:organ, temporal=:instantaneous,
    aggregation=:state, extent=:intensive,
)
const _CARBON_G_PER_MICROMOL_CO2 = 12.0e-6

PlantSimEngine.@process "leaf_dimension" verbose=false
PlantSimEngine.@process "leaf_net_carbon" verbose=false
PlantSimEngine.@process "plant_carbon_supply" verbose=false

_finite_nonnegative(value, label) = GrowthDemandModels._finite_nonnegative(value, label)
_finite_result(value, label) = GrowthDemandModels._finite_result(value, label)

function _finite_real(value, label)
    value isa Real && !(value isa Bool) || throw(ArgumentError("$label must be real"))
    return _finite_result(value, label)
end

"""Convert a native leaf's positive `Width` in centimetres to `d` in metres."""
struct LeafDimension <: AbstractLeaf_DimensionModel end

PlantSimEngine.inputs_(::LeafDimension) = (Width=PlantSimEngine.Required(Real),)
PlantSimEngine.outputs_(::LeafDimension) = (d=0.0,)
PlantSimEngine.variable_contracts_(::LeafDimension) = (
    Width=PlantSimEngine.VariableContract(unit=:centimetre, basis=:organ,
        temporal=:instantaneous, aggregation=:state, extent=:intensive),
    d=LEAF_DIMENSION_CONTRACT,
)

function PlantSimEngine.run!(::LeafDimension, status, environment,
                             constants=nothing, context=nothing)
    width = _finite_real(status.Width, "leaf Width in centimetres")
    width > zero(width) || throw(DomainError(width, "leaf Width must be positive"))
    d = _finite_result(width * 0.01, "leaf dimension in metres")
    d > zero(d) || throw(ArgumentError("leaf dimension underflows to zero"))
    status.d = d
    return nothing
end

"""
    SurfaceEnergyBalance(model=PlantBiophysics.Monteith())
    SurfaceEnergyBalance(; kwargs...)

Delegate the energy-balance process to `Monteith`, adding only its documented
characteristic-dimension contract: `d` is an organ dimension in metres. This
known boundary is missing from PlantBiophysics's current metadata. The native
ports, environment requirements, hard-call dependencies, output policies,
timestep hints and numerical implementation remain those of the wrapped model.
"""
struct SurfaceEnergyBalance{M<:PlantBiophysics.Monteith} <:
       PlantBiophysics.AbstractEnergy_BalanceModel
    model::M
end

SurfaceEnergyBalance(; kwargs...) =
    SurfaceEnergyBalance(PlantBiophysics.Monteith(; kwargs...))

PlantSimEngine.inputs_(model::SurfaceEnergyBalance) = PlantSimEngine.inputs_(model.model)
PlantSimEngine.outputs_(model::SurfaceEnergyBalance) = PlantSimEngine.outputs_(model.model)
PlantSimEngine.environment_inputs_(model::SurfaceEnergyBalance) =
    PlantSimEngine.environment_inputs_(model.model)
PlantSimEngine.dep(model::SurfaceEnergyBalance) = PlantSimEngine.dep(model.model)
PlantSimEngine.variable_contracts_(model::SurfaceEnergyBalance) = merge(
    PlantSimEngine.variable_contracts_(model.model), (d=LEAF_DIMENSION_CONTRACT,),
)
PlantSimEngine.output_policy(::Type{<:SurfaceEnergyBalance{M}}) where {M} =
    PlantSimEngine.output_policy(M)
PlantSimEngine.timestep_hint(::Type{<:SurfaceEnergyBalance{M}}) where {M} =
    PlantSimEngine.timestep_hint(M)
Base.eltype(model::SurfaceEnergyBalance) = eltype(model.model)

function PlantSimEngine.run!(model::SurfaceEnergyBalance, status, environment,
                             constants, context)
    return PlantSimEngine.run!(model.model, status, environment, constants, context)
end

"""
Integrate accepted net `A` (µmol CO₂ m⁻² s⁻¹) over `area_m2` and explicit seconds.

The `A` binding must use `HoldLast()` from Monteith's accepted output. Both
photosynthesis and energy balance use the same represented surface as
ArchimedLight's `area`; no botanical-area conversion is applied here. Negative
net exchange is retained as a leaf carbon loss, rather than clamped to zero.
PlantBiophysics does not currently declare a variable contract for `A`; the
explicit rate conversion is checked numerically rather than assigned invented
upstream metadata.
"""
struct LeafNetCarbon <: AbstractLeaf_Net_CarbonModel end

PlantSimEngine.inputs_(::LeafNetCarbon) = (
    A=PlantSimEngine.Required(Real),
    area_m2=PlantSimEngine.Required(Real),
)
PlantSimEngine.environment_inputs_(::LeafNetCarbon) = (duration_seconds=0.0,)
PlantSimEngine.outputs_(::LeafNetCarbon) = (carbon_step_gC=0.0,)
PlantSimEngine.variable_contracts_(::LeafNetCarbon) = (
    area_m2=ORGAN_AREA_CONTRACT,
    duration_seconds=SECOND_CONTRACT,
    carbon_step_gC=ORGAN_STEP_CARBON_CONTRACT,
)

function PlantSimEngine.run!(::LeafNetCarbon, status, environment,
                             constants=nothing, context=nothing)
    assimilation = _finite_real(status.A, "accepted net leaf assimilation")
    area = _finite_real(status.area_m2, "represented leaf area in square metres")
    area > zero(area) || throw(DomainError(area, "represented leaf area must be positive"))
    duration = _finite_nonnegative(environment.duration_seconds, "duration_seconds")
    carbon = _finite_result(assimilation * area * duration * _CARBON_G_PER_MICROMOL_CO2,
                            "net leaf carbon exchange")
    status.carbon_step_gC = carbon
    return nothing
end

"""
Gather signed leaf exchange and advance an explicitly prescribed developmental rate.

Bind `leaf_carbon_gC` with `Many(scale=:Leaf, within=Subtree())` so each plant
receives only its own living leaves. Positive and negative *net* leaf exchange
are accumulated separately. These are not gross photosynthesis and total
respiration: FvCB already includes its day respiration in net `A`. The output
development increment supplies a declared dependency from physiology to AMAPSim.
"""
struct PlantCarbonSupply <: AbstractPlant_Carbon_SupplyModel end

PlantSimEngine.inputs_(::PlantCarbonSupply) = (
    leaf_carbon_gC=PlantSimEngine.Required(AbstractVector),
)
PlantSimEngine.environment_inputs_(::PlantCarbonSupply) = (
    duration_seconds=0.0,
    development_rate_per_second=0.0,
)
PlantSimEngine.outputs_(::PlantCarbonSupply) = (
    cumulative_carbon_supply_gC=0.0,
    cumulative_carbon_loss_gC=0.0,
    development_increment=0.0,
)
PlantSimEngine.variable_contracts_(::PlantCarbonSupply) = (
    leaf_carbon_gC=ORGAN_STEP_CARBON_CONTRACT,
    duration_seconds=SECOND_CONTRACT,
    development_rate_per_second=PlantSimEngine.VariableContract(
        unit=:development_stage, basis=:plant, temporal=:second,
        aggregation=:rate, extent=:intensive),
    cumulative_carbon_supply_gC=CUMULATIVE_CARBON_CONTRACT,
    cumulative_carbon_loss_gC=CUMULATIVE_CARBON_CONTRACT,
    development_increment=AMAPSim.DEVELOPMENT_INCREMENT_CONTRACT,
)

function PlantSimEngine.run!(::PlantCarbonSupply, status, environment,
                             constants=nothing, context=nothing)
    supply = _finite_nonnegative(status.cumulative_carbon_supply_gC,
                                  "cumulative positive net leaf exchange")
    loss = _finite_nonnegative(status.cumulative_carbon_loss_gC,
                                "cumulative negative net leaf exchange")
    for value in status.leaf_carbon_gC
        carbon = _finite_real(value, "net leaf carbon exchange")
        if carbon >= zero(carbon)
            supply = _finite_result(supply + carbon, "cumulative positive net leaf exchange")
        else
            loss = _finite_result(loss - carbon, "cumulative negative net leaf exchange")
        end
    end
    increment = physical_development_increment(environment.development_rate_per_second,
                                                environment.duration_seconds)
    # Assign only after validating every leaf and the development increment.
    status.cumulative_carbon_supply_gC = supply
    status.cumulative_carbon_loss_gC = loss
    status.development_increment = increment
    return nothing
end

"""
    PhotosyntheticReserveAllocation(; initial_reserve_gC)

Fund or defer each whole organ using the COUP-2 quote/settlement ledger. Inputs
are cumulative positive and negative net leaf exchanges, not a signed supply.
Repeated architecture hard calls credit and pay each cumulative amount once.
Successful calls preserve

`initial reserve + positive net exchange = reserve + construction + negative net exchange`.

Negative exchange is paid before new organ quotes. If it would exceed the
reserve remaining after already committed construction, raise an explicit error
without changing allocation status. This bounded example has no implicit carbon
debt, tissue remobilization, or arbitrary clamp. Every model field is immutable;
all evolving quantities live in the plant status.
"""
struct PhotosyntheticReserveAllocation{T<:Real} <:
       PlantSimEngine.Examples.AbstractCarbon_AllocationModel
    initial_reserve_gC::T
end

function PhotosyntheticReserveAllocation(; initial_reserve_gC)
    reserve = _finite_nonnegative(initial_reserve_gC, "initial_reserve_gC")
    return PhotosyntheticReserveAllocation(float(reserve))
end

PlantSimEngine.inputs_(::PhotosyntheticReserveAllocation) = (
    growth_intents=PlantSimEngine.Required(AbstractVector),
    realized_growth_intents=PlantSimEngine.Required(AbstractVector),
    demand_history=PlantSimEngine.Required(AbstractVector),
    cumulative_carbon_supply_gC=PlantSimEngine.Required(Real),
    cumulative_carbon_loss_gC=PlantSimEngine.Required(Real),
)
PlantSimEngine.outputs_(model::PhotosyntheticReserveAllocation) = (
    organ_allocation_decisions=NamedTuple[],
    remaining_carbon_gC=copy(model.initial_reserve_gC),
    spent_carbon_gC=zero(model.initial_reserve_gC),
    credited_carbon_supply_gC=zero(model.initial_reserve_gC),
    paid_carbon_loss_gC=zero(model.initial_reserve_gC),
    allocation_history=NamedTuple[],
)
PlantSimEngine.variable_contracts_(::PhotosyntheticReserveAllocation) = (
    growth_intents=AMAPSim.GROWTH_INTENT_CONTRACT,
    realized_growth_intents=AMAPSim.GROWTH_INTENT_CONTRACT,
    demand_history=DEMAND_HISTORY_CONTRACT,
    organ_allocation_decisions=ORGAN_ALLOCATION_DECISION_CONTRACT,
    remaining_carbon_gC=CARBON_RESERVE_CONTRACT,
    spent_carbon_gC=CUMULATIVE_CARBON_CONTRACT,
    credited_carbon_supply_gC=CUMULATIVE_CARBON_CONTRACT,
    paid_carbon_loss_gC=CUMULATIVE_CARBON_CONTRACT,
    cumulative_carbon_supply_gC=CUMULATIVE_CARBON_CONTRACT,
    cumulative_carbon_loss_gC=CUMULATIVE_CARBON_CONTRACT,
    allocation_history=ALLOCATION_HISTORY_CONTRACT,
)

function PlantSimEngine.run!(model::PhotosyntheticReserveAllocation{T}, status,
                             environment, constants=nothing, context=nothing) where {T}
    amount(value, label) = GrowthDemandModels._carbon_amount(T, value, label)
    supply = amount(status.cumulative_carbon_supply_gC, "cumulative_carbon_supply_gC")
    loss = amount(status.cumulative_carbon_loss_gC, "cumulative_carbon_loss_gC")
    credited = amount(status.credited_carbon_supply_gC, "credited_carbon_supply_gC")
    paid = amount(status.paid_carbon_loss_gC, "paid_carbon_loss_gC")
    supply >= credited || throw(ArgumentError("cumulative_carbon_supply_gC cannot decrease"))
    loss >= paid || throw(ArgumentError("cumulative_carbon_loss_gC cannot decrease"))
    budget = _finite_result(
        _finite_result(model.initial_reserve_gC + supply, "total supplied carbon") - loss,
        "carbon available after negative net leaf exchange",
    )
    old_budget = _finite_result(
        _finite_result(model.initial_reserve_gC + credited, "previous supplied carbon") - paid,
        "previous carbon available after negative net leaf exchange",
    )
    committed = amount(status.spent_carbon_gC, "spent_carbon_gC")
    budget >= committed || throw(ArgumentError(
        "negative net leaf exchange exhausts the carbon reserve after committed construction; " *
        "the example does not create implicit carbon debt",
    ))
    batch = GrowthDemandModels._organ_allocation_batch(status, T, budget, old_budget)
    status.organ_allocation_decisions = batch.decisions
    status.credited_carbon_supply_gC = supply
    status.paid_carbon_loss_gC = loss
    status.remaining_carbon_gC = budget - batch.spent
    status.spent_carbon_gC = batch.spent
    status.allocation_history = batch.next_history
    return nothing
end

end
