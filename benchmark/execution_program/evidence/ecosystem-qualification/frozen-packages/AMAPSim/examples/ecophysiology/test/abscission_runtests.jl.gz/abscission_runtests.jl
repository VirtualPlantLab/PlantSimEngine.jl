# Included inside TwoPlantValidation after the expansion helpers.
const B = D.LeafAbscissionModels
const ABSCISSION = (lifespan_seconds=7200.0,)

function abscission_output_state(model, status)
    fields = keys(PlantSimEngine.outputs_(model))
    return deepcopy(NamedTuple{fields}(Tuple(getproperty(status, field) for field in fields)))
end

function check_abscission_carbon(result)
    objects = plant_objects(result)
    ids = Set(object.id for object in objects)
    initial = Dict(object.id => result.initial_reserves_gC[index]
        for (index, object) in enumerate(objects))
    positive = Dict(id => 0.0 for id in ids)
    negative = Dict(id => 0.0 for id in ids)
    abscised = Dict(id => 0.0 for id in ids)
    removed = Set{PlantSimEngine.ObjectId}()
    source_identity = Dict{Tuple{PlantSimEngine.ObjectId,Int},Int}()
    journal = NamedTuple[]
    previous_end = first(result.frames).leaves_at_start
    for frame in result.frames
        @test Set(frame.leaves_at_start) == Set(previous_end)
        @test Set(leaf.object_id for leaf in frame.leaves) == Set(frame.leaves_at_start)
        @test isempty(intersect(Set(frame.leaves_at_start), removed))
        @test Set(plant.object_id for plant in frame.plants) == ids
        for leaf in frame.leaves
            @test leaf.plant_id in ids
            @test leaf.area_m2 > 0
            @test leaf.carbon_step_gC ≈ leaf.A * leaf.area_m2 * 3600.0 * 12e-6
            key = (leaf.plant_id, leaf.source_node_id)
            @test get(source_identity, key, leaf.runtime_node_id) == leaf.runtime_node_id
            source_identity[key] = leaf.runtime_node_id
            positive[leaf.plant_id] += max(leaf.carbon_step_gC, 0.0)
            negative[leaf.plant_id] += max(-leaf.carbon_step_gC, 0.0)
        end
        for organ in frame.abscission
            @test organ.object_id ∉ removed
            @test organ.object_id in frame.leaves_at_start
            @test organ.object_id ∉ frame.leaves_at_end
            @test organ.plant_id in ids
            @test organ.execution == frame.execution
            @test organ.age_seconds == ABSCISSION.lifespan_seconds
            @test organ.prepaid_construction_gC > 0
            @test organ.deployed_construction_gC + organ.unexpanded_construction_gC ≈
                organ.prepaid_construction_gC
            key = (organ.plant_id, organ.source_node_id)
            @test source_identity[key] == organ.runtime_node_id
            abscised[organ.plant_id] += organ.prepaid_construction_gC
            push!(removed, organ.object_id)
            push!(journal, organ)
        end
        @test isempty(intersect(Set(frame.leaves_at_end), removed))
        @test isempty(frame.abscission) || frame.geometry_invalidated
        for plant in frame.plants
            @test plant.positive_net_gC ≈ positive[plant.object_id]
            @test plant.negative_net_gC ≈ negative[plant.object_id]
            @test plant.abscised_construction_gC ≈ abscised[plant.object_id]
            @test plant.reserve_gC >= 0
            @test initial[plant.object_id] + positive[plant.object_id] ≈
                plant.reserve_gC + plant.construction_gC + negative[plant.object_id]
            @test plant.active_construction_gC + plant.abscised_construction_gC ≈
                plant.construction_gC
            if hasproperty(frame, :expansion)
                own = filter(organ -> organ.plant_id == plant.object_id, frame.expansion)
                @test isempty(intersect(Set(organ.object_id for organ in own), removed))
                @test plant.deployed_construction_gC ≈
                    sum(organ.deployed_construction_gC for organ in own; init=0.0)
                @test plant.unexpanded_construction_gC ≈
                    sum(organ.unexpanded_construction_gC for organ in own; init=0.0)
                @test plant.deployed_construction_gC + plant.unexpanded_construction_gC ≈
                    plant.active_construction_gC
            end
        end
        @test sum(values(initial)) + sum(values(positive)) ≈
            sum(plant.reserve_gC + plant.construction_gC + plant.negative_net_gC
                for plant in frame.plants)
        previous_end = frame.leaves_at_end
    end
    scene = only(model_objects(result.model; scale=:Scene)).status
    @test isequal(scene.abscission_history, journal)
    @test length(removed) == length(journal)
    return (; removed, journal, positive, negative, source_identity)
end

function structure_without_leaves(plant)
    nodes = filter(node -> MultiScaleTreeGraph.symbol(node) !== :Leaf,
        MultiScaleTreeGraph.traverse(plant, identity))
    positions = IdDict(node => position for (position, node) in enumerate(nodes))
    return [(parent=get(positions, MultiScaleTreeGraph.parent(node), 0),
        link=MultiScaleTreeGraph.link(node), symbol=MultiScaleTreeGraph.symbol(node),
        index=node === plant ? 0 : MultiScaleTreeGraph.index(node),
        scale=MultiScaleTreeGraph.scale(node)) for node in nodes]
end

abscission_state_fields(value) = (; (field => deepcopy(getfield(value, field))
    for field in fieldnames(typeof(value)))...)

function abscission_queue_state(queue)
    return (
        events=Dict(id.value => abscission_state_fields(event) for (id, event) in queue.events),
        priorities=Dict(id.value => priority for (id, priority) in pairs(queue.priorities)),
        next_event_id=queue.next_event_id,
        next_sequence=queue.next_sequence,
        process_ids=copy(queue.process_ids),
        next_process_id=queue.next_process_id,
        legacy_order=queue.legacy_order,
    )
end

@testset "Leaf abscission uses physical age without consuming randomness" begin
    model = B.LeafAbscission(; lifespan_seconds=7200.0, construction_cost_gC=0.04)
    status = Status(; PlantSimEngine.outputs_(model)...)
    hour = (duration_seconds=3600.0,)
    PlantSimEngine.run!(model, status, hour)
    @test status.abscission_initialized
    @test iszero(status.abscission_age_seconds)
    @test !status.abscission_due
    @test status.abscission_prepaid_gC == 0.04
    PlantSimEngine.run!(model, status, (duration_seconds=0.0,))
    @test iszero(status.abscission_age_seconds)
    PlantSimEngine.run!(model, status, hour)
    @test status.abscission_age_seconds == 3600.0
    @test !status.abscission_due
    PlantSimEngine.run!(model, status, hour)
    @test status.abscission_age_seconds == 7200.0
    @test status.abscission_due
    PlantSimEngine.run!(model, status, (duration_seconds=floatmax(Float64),))
    @test status.abscission_age_seconds == 7200.0
    @test status.abscission_due
    @test status.abscission_prepaid_gC == 0.04
    previous = abscission_output_state(model, status)
    for duration in (-1.0, Inf, NaN)
        @test_throws Exception PlantSimEngine.run!(model, status, (duration_seconds=duration,))
        @test isequal(abscission_output_state(model, status), previous)
    end
    for config in ((lifespan_seconds=0.0, construction_cost_gC=0.04),
                   (lifespan_seconds=Inf, construction_cost_gC=0.04),
                   (lifespan_seconds=7200.0, construction_cost_gC=-0.1))
        @test_throws Exception B.LeafAbscission(; config...)
    end
    model32 = B.LeafAbscission(; lifespan_seconds=7200.0f0, construction_cost_gC=0.04f0)
    status32 = Status(; PlantSimEngine.outputs_(model32)...)
    PlantSimEngine.run!(model32, status32, (duration_seconds=3600.0f0,))
    @test status32.abscission_age_seconds === 0.0f0
    @test status32.abscission_prepaid_gC === 0.04f0
end

@testset "Two plants lose prepaid leaves and keep growing with unchanged RNG" begin
    weather = D.forcing(par=(450.0, 450.0, 0.0, 450.0, 450.0, 450.0, 450.0, 450.0))
    result = E.run_example(; weather, expansion=EXPANSION, abscission=ABSCISSION)
    reference = E.run_example(; weather, expansion=EXPANSION)
    check = check_abscission_carbon(result)
    @test !isempty(check.journal)
    @test all(check.positive[object.id] > 0 && check.negative[object.id] > 0
        for object in plant_objects(result))
    @test any(!isempty(frame.abscission) for frame in result.frames[3:4])
    @test any(!isempty(setdiff(Set(frame.leaves_at_end), Set(frame.leaves_at_start)))
        for frame in result.frames[5:end])
    live = Set(object.id for object in model_objects(result.model))
    live_node_ids = Set(MultiScaleTreeGraph.node_id(node)
        for node in MultiScaleTreeGraph.traverse(first(result.topologies).scene, identity))
    @test isempty(intersect(live, check.removed))
    @test all(organ.runtime_node_id ∉ live_node_ids for organ in check.journal)
    for organ in check.journal
        @test_throws Exception model_status(result.model, organ.object_id)
        @test_throws Exception source_node(result.model, organ.object_id)
    end
    for (plant, baseline) in zip(plant_objects(result), plant_objects(reference))
        s, expected = plant.status, baseline.status
        @test rng_bytes(s.rng) == rng_bytes(expected.rng)
        same_events = isequal(s.event_trace, expected.event_trace)
        @test same_events
        @test s.processed_events == expected.processed_events
        @test s.last_event_id == expected.last_event_id
        same_queue = isequal(abscission_queue_state(s.event_queue),
            abscission_queue_state(expected.event_queue))
        same_buds = isequal(Dict(id => abscission_state_fields(state) for (id, state) in s.bud_states),
            Dict(id => abscission_state_fields(state) for (id, state) in expected.bud_states))
        @test same_queue
        @test same_buds
        same_sites = isequal(s.development_sites, expected.development_sites)
        same_allocations = isequal(s.allocation_history, expected.allocation_history)
        @test same_sites
        @test same_allocations
        @test s.spent_carbon_gC == expected.spent_carbon_gC
        @test structure_without_leaves(source_node(result.model, plant)) ==
            structure_without_leaves(source_node(reference.model, baseline))
    end
    # Removing a source-local ID in one plant cannot retire its namespaced peer.
    per_plant = [Set(organ.source_node_id for organ in check.journal if organ.plant_id == plant.id)
        for plant in plant_objects(result)]
    @test !isempty(intersect(per_plant...))
    @test length(Set((organ.plant_id, organ.source_node_id) for organ in check.journal)) ==
        length(check.journal)
    final_frame = last(result.frames)
    cache = getproperty(result.light_kernel, :runtime_cache)
    @test Set(getproperty(cache, :target_ids)) == Set(final_frame.leaves_at_start)
    prior_removed = Set(organ.object_id for frame in result.frames[1:end-1]
        for organ in frame.abscission)
    @test isempty(intersect(Set(values(getproperty(cache, :owner_map))), prior_removed))
end

function abscission_leaf_history(frames, id)
    return [(execution=frame.execution, leaf=leaf)
        for frame in frames for leaf in frame.leaves if leaf.object_id == id]
end

@testset "Abscission clears the living canopy and preserves numerical interval history" begin
    weather = D.forcing(par=(450.0, 450.0, 0.0, 450.0, 450.0, 450.0, 450.0, 450.0))
    weather = [execution <= 4 ? row : merge(row, (development_rate_per_second=0.0,))
        for (execution, row) in enumerate(weather)]
    setup = E.scenario(; weather, expansion=EXPANSION, abscission=ABSCISSION)
    # These numerical snapshots belong to the example's interval journal.
    # Native PlantSimEngine output-stream retention is a separate contract.
    simulation = PlantSimEngine.run!(setup.model; steps=3, outputs=:none)
    scene = only(model_objects(setup.model; scale=:Scene)).status
    selected = first(last(scene.interval_records).leaves).object_id
    early_frames = deepcopy(scene.interval_records)
    early_history = abscission_leaf_history(early_frames, selected)
    @test getproperty.(early_history, :execution) == [3]
    history_at_removal = nothing
    checkpoint_rng = nothing
    checkpoint_events = nothing
    for execution in 4:8
        PlantSimEngine.continue!(simulation; steps=1)
        frame = last(scene.interval_records)
        @test frame.execution == execution
        unchanged_prefix = isequal(scene.interval_records[1:length(early_frames)], early_frames)
        @test unchanged_prefix
        history = abscission_leaf_history(scene.interval_records, selected)
        if execution == 4
            @test selected in Set(organ.object_id for organ in frame.abscission)
            @test selected in Set(leaf.object_id for leaf in frame.leaves)
            @test selected ∉ Set(frame.leaves_at_end)
            history_at_removal = deepcopy(history)
            @test getproperty.(history_at_removal, :execution) == [3, 4]
            @test all(row.leaf.object_id == selected for row in history_at_removal)
        else
            unchanged_history = isequal(history, history_at_removal)
            @test unchanged_history
            @test selected ∉ Set(leaf.object_id for leaf in frame.leaves)
        end
        if execution == 4
            checkpoint_rng = Dict(object.id => rng_bytes(object.status.rng)
                for object in plant_objects(setup))
            checkpoint_events = Dict(object.id => object.status.processed_events
                for object in plant_objects(setup))
        elseif execution > 4
            for object in plant_objects(setup)
                @test rng_bytes(object.status.rng) == checkpoint_rng[object.id]
                @test object.status.processed_events == checkpoint_events[object.id]
            end
        end
    end
    result = (; setup..., simulation, frames=copy(scene.interval_records))
    check = check_abscission_carbon(result)
    @test isempty(model_objects(setup.model; scale=:Leaf))
    @test isempty(last(result.frames).leaves_at_start)
    @test isempty(last(result.frames).leaves)
    @test isempty(filter(organ -> organ.symbol === :Leaf, last(result.frames).expansion))
    @test setup.provider.seed_stem_used == (false, false)
    cache = getproperty(setup.light_kernel, :runtime_cache)
    @test isempty(getproperty(cache, :target_ids))
    @test isempty(intersect(Set(values(getproperty(cache, :owner_map))), check.removed))
    physical = physical_owner_expectations(result)
    @test Dict(getproperty(cache, :owner_map)) == physical.expected
    bindings = PlantSimEngine.Diagnostics.explain_bindings(setup.model)
    gathers = filter(row -> row.input == :leaf_carbon_gC, bindings)
    @test length(gathers) == 2
    @test all(isempty(row.source_ids) for row in gathers)
    removed_sources = Set((organ.plant_id, organ.source_node_id) for organ in check.journal)
    for (ordinal, map) in enumerate(setup.provider.source_ids), (node, raw) in map
        plant = plant_objects(setup)[ordinal]
        @test (plant.id, Int(raw)) ∉ removed_sources
        @test object_id(setup.model, node) in Set(object.id for object in model_objects(setup.model))
    end
    @test all(plant.abscised_construction_gC > 0 for plant in last(result.frames).plants)
end

@testset "Abscission works independently of progressive expansion" begin
    weather = D.forcing(par=(450.0, 450.0, 0.0, 450.0, 450.0))
    result = E.run_example(; weather, expansion=nothing, abscission=ABSCISSION)
    check = check_abscission_carbon(result)
    @test !isempty(check.journal)
    @test all(!hasproperty(frame, :expansion) for frame in result.frames)
    @test all(organ.deployed_construction_gC == organ.prepaid_construction_gC
        && iszero(organ.unexpanded_construction_gC) for organ in check.journal)
    first_removed = Set(organ.object_id for frame in result.frames[1:end-1]
        for organ in frame.abscission)
    @test !isempty(first_removed)
    cache = getproperty(result.light_kernel, :runtime_cache)
    @test Set(getproperty(cache, :target_ids)) == Set(last(result.frames).leaves_at_start)
    @test isempty(intersect(Set(values(getproperty(cache, :owner_map))), first_removed))
    @test all(plant.abscised_construction_gC > 0 for plant in last(result.frames).plants)
end
