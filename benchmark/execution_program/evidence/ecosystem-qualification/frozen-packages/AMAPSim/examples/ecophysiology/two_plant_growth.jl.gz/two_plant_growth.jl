"""Two source namespaces in one dynamic light–physiology–growth composition."""
module TwoPlantGrowthExample

using AMAPSim
using MultiScaleTreeGraph
using PlantSimEngine

include("dynamic_growth.jl")
const E = DynamicGrowthExample
const D = E.DynamicPhysiologyModels
const G = E.DynamicLightGeometry

export scenario, run_example

"""
Copy an authored, undeveloped seed into the shared runtime MTG.

Input node IDs stay intact. Runtime node IDs are unique across the scene;
`source_topology_id` retains each original ID. This deliberately small seed
projection is not an importer for a developed plant's private simulation state.
"""
function _copy_seed!(scene, source; plant_index, position_cm)
    copies = IdDict{Any,Any}(source.scene => scene)
    source_ids = IdDict{Any,Int}()
    current_ids = Dict{Int,Int}()
    for node in traverse(source.plant, identity)
        encoding = NodeMTG(link(node), symbol(node),
            node === source.plant ? plant_index : index(node), scale(node))
        attributes = deepcopy(Dict(pairs(node_attributes(node))))
        attributes[:source_topology_id] = node_id(node)
        copy_node = Node(copies[parent(node)], encoding, attributes)
        copies[node] = copy_node
        source_ids[copy_node] = node_id(node)
        current_ids[node_id(node)] = node_id(copy_node)
    end
    # The minimal native seed has one explicit bearer-ID reference. Rewrite
    # that runtime attachment, while preserving its original source identity.
    axis = copies[source.axis]
    axis[:InitializationBearerID] = current_ids[Int(source.axis[:InitializationBearerID])]
    plant = copies[source.plant]
    plant[:X], plant[:Y], plant[:Z] = Float64.(position_cm)
    topology = AMAPSimTopology((getfield(source, field) === nothing ? nothing :
        copies[getfield(source, field)] for field in fieldnames(typeof(source)))...)
    return topology, source_ids
end

"""Select an immutable construction-reserve model by the current Plant index."""
struct PerPlantReserveAllocation{T} <: PlantSimEngine.Examples.AbstractCarbon_AllocationModel
    reserves_gC::T
end

_base() = D.PhotosyntheticReserveAllocation(initial_reserve_gC=0.0)
PlantSimEngine.inputs_(::PerPlantReserveAllocation) = PlantSimEngine.inputs_(_base())
PlantSimEngine.outputs_(::PerPlantReserveAllocation) = PlantSimEngine.outputs_(_base())
PlantSimEngine.variable_contracts_(::PerPlantReserveAllocation) =
    PlantSimEngine.variable_contracts_(_base())
function PlantSimEngine.run!(model::PerPlantReserveAllocation, status, environment,
                             constants, context)
    plant = source_node(context)
    symbol(plant) === :Plant || throw(ArgumentError("reserve allocation requires a Plant"))
    allocation = D.PhotosyntheticReserveAllocation(
        initial_reserve_gC=model.reserves_gC[index(plant)])
    return PlantSimEngine.run!(allocation, status, environment, constants, context)
end

"""
    scenario(; initial_reserves_gC=(0.01, 0.02), seed=7, geometry_seed=17, ...)

Project two independent seeds with equal raw MTG IDs into one runtime Scene.
Only execution copies receive globally unique current IDs. Original source
IDs and the independent source-ID sequences of newborn organs remain local to
each Plant; the complete light owner key includes its scene-instance namespace.
Both plants use the explicitly selected architecture seed, with separate RNGs
and carbon ledgers. Positions are authored in cm before the geometry boundary.
"""
function scenario(; parameters=E.synthetic_parameters(), weather=E.forcing(), seed=7,
                    geometry_seed=17, initial_reserves_gC=(0.01, 0.02),
                    positions_cm=((-5.0, 0.0, 0.0), (5.0, 0.0, 0.0)), expansion=nothing,
                    abscission=nothing, kwargs...)
    length(initial_reserves_gC) == 2 || throw(ArgumentError("supply two initial reserves"))
    length(positions_cm) == 2 || throw(ArgumentError("supply two plant positions in cm"))
    reserves = Tuple(Float64(D.PhotosyntheticReserveAllocation(
        initial_reserve_gC=value).initial_reserve_gC) for value in initial_reserves_gC)
    all(isfinite, reserves) || throw(ArgumentError("initial reserves must fit Float64"))
    for position_cm in positions_cm
        length(position_cm) == 3 && all(value -> value isa Real &&
            !(value isa Bool) && isfinite(value), position_cm) ||
            throw(ArgumentError("positions must have three finite coordinates in cm"))
    end
    source_topologies = [build_initial_topology(parameters) for _ in 1:2]
    # Keep the input graphs separate: ColumnarAttrs and the live AMAPSim
    # scheduler require unique current node IDs in their shared runtime MTG.
    scene = Node(deepcopy(node_mtg(first(source_topologies).scene)),
        deepcopy(Dict(pairs(node_attributes(first(source_topologies).scene)))))
    projected = [_copy_seed!(scene, source; plant_index=i, position_cm=positions_cm[i])
        for (i, source) in enumerate(source_topologies)]
    topologies = first.(projected)
    source_ids = last.(projected)
    for (i, topology) in enumerate(topologies)
        # These are explicit initial status values. The allocator's output
        # defaults do not replace the selected plant's initial reserve.
        topology.plant[:remaining_carbon_gC] = reserves[i]
    end
    provider = G.MultiPlantSceneProvider(topologies, parameters; geometry_seed, source_ids,
        dimension_provider=expansion === nothing ? nothing : E._expanded_dimensions)
    allocation = PerPlantReserveAllocation(reserves)
    setup = E._scenario(topologies, parameters, provider; weather,
        seed=Dict(1 => seed, 2 => seed), initial_reserve_gC=reserves,
        allocation, expansion, abscission, kwargs...)
    return (; setup..., topologies, source_topologies, initial_reserves_gC=reserves)
end

function run_example(; outputs=:none, kwargs...)
    setup = scenario(; kwargs...)
    simulation = PlantSimEngine.run!(setup.model; steps=length(setup.weather), outputs)
    scene = only(model_objects(setup.model; scale=:Scene)).status
    return (; setup..., simulation, frames=copy(scene.interval_records))
end

end

if abspath(PROGRAM_FILE) == @__FILE__
    result = TwoPlantGrowthExample.run_example()
    println([(execution=frame.execution, plants=frame.plants) for frame in result.frames])
end
