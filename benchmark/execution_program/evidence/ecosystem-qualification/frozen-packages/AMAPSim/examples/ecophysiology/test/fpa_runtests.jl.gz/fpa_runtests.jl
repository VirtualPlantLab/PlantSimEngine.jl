module FpaCouplingValidation

using AMAPSim
using MultiScaleTreeGraph
using PlantBiophysics
using PlantGeom
using PlantSimEngine
using Serialization
using SHA
using Test

include(joinpath(@__DIR__, "..", "fpa_growth.jl"))
const F = FPAGrowthExample

plant(result) = only(model_objects(result.model; scale=:Plant)).status
fields(value) = (; (name => deepcopy(getfield(value, name))
    for name in fieldnames(typeof(value)))...)

function rng_bytes(rng)
    buffer = IOBuffer()
    serialize(buffer, copy(rng))
    return take!(buffer)
end

function queue_state(queue)
    return (
        events=Dict(id.value => fields(event) for (id, event) in queue.events),
        priorities=Dict(id.value => priority for (id, priority) in pairs(queue.priorities)),
        next_event_id=queue.next_event_id,
        next_sequence=queue.next_sequence,
        process_ids=copy(queue.process_ids),
        next_process_id=queue.next_process_id,
        legacy_order=queue.legacy_order,
    )
end

# Compare potential botanical dimensions and developmental provenance separately
# from geometry's additional realized-frame/prototype attributes.
const BOTANICAL_ATTRIBUTES = Set((
    :Length, :Width, :Thickness, :EmissionTime, :BirthTime, :DeathTime,
    :PhysiologicalAge, :Nature, :OrganIndex, :LateralProductionIndex,
    :WhorlSlot, :WhorlSize, :BearerPhytomerID, :BearerAxisID,
    :BearerAxisPhytomerIndex, :BearerAxisInternodeIndex, :BearerInternodeID,
    :InsertionPositionFromTip, :Phyllotaxy, :YInsertionAngle,
    :GrowthUnitIndex, :GrowthCycleIndex, :ZoneIndex, :TestIndex,
    :SympodialBoundary, :SympodialTransition, :SympodialPlanar,
    :SympodialInitialAngle, :SympodialAngle,
))

function botanical_attributes(topology)
    return Dict(node_id(node) => Dict(key => deepcopy(value)
        for (key, value) in pairs(node_attributes(node)) if key in BOTANICAL_ATTRIBUTES)
        for node in traverse(topology.scene, identity))
end

function plain_architecture(parameters, increment, steps, seed)
    topology = build_initial_topology(parameters)
    model = build_model(topology; parameters, seed, development_increment=increment)
    simulation = PlantSimEngine.run!(model; steps, outputs=:none)
    return (; topology, model, simulation)
end

function check_source_and_role(result)
    raw, parameters, mapping = result.raw_parameters, result.parameters, result.mapping
    @test bytes2hex(sha256(read(raw.source.path))) == mapping.source_sha256
    @test parameters.source === raw.source
    @test parameters.initialization === raw.initialization
    @test parameters.axis === raw.axis
    @test parameters.legacy === raw.legacy
    @test mapping.raw_symbol === :Internode
    @test mapping.effective_symbol === :Leaf
    @test (mapping.production_index, mapping.production_name) ==
        (mapping.profile === :rauh ? (3, "feuille") : (2, "feuilles"))
    for (index, (original, annotated)) in enumerate(zip(
            raw.lateral_productions, parameters.lateral_productions))
        @test annotated.name == original.name
        @test annotated.global_parameters === original.global_parameters
        @test annotated.branching_models === original.branching_models
        @test annotated.zones === original.zones
        @test annotated.organ_symbol ===
            (index == mapping.production_index ? :Leaf : original.organ_symbol)
    end
end

function check_abundant_architecture(result)
    steps = length(result.weather)
    reference = plain_architecture(result.parameters, result.development_increment,
        steps, result.seed)
    raw = plain_architecture(result.raw_parameters, result.development_increment,
        steps, result.seed)
    actual, expected = plant(result), plant(reference)
    @test rng_bytes(plant(raw).rng) == rng_bytes(expected.rng)
    normalized = [merge(row, (symbol=row.symbol === :Leaf ? :Internode : row.symbol,))
        for row in AMAPSim.topology_signature(reference.topology.scene)]
    @test normalized == AMAPSim.topology_signature(raw.topology.scene)
    @test AMAPSim.topology_signature(result.topology.scene) ==
        AMAPSim.topology_signature(reference.topology.scene)
    @test isequal(botanical_attributes(result.topology), botanical_attributes(reference.topology))
    @test rng_bytes(actual.rng) == rng_bytes(expected.rng)
    @test actual.development_time == expected.development_time
    @test actual.processed_events == expected.processed_events
    @test actual.last_event_id == expected.last_event_id
    @test isequal(actual.event_trace, expected.event_trace)
    @test isequal(actual.development_sites, expected.development_sites)
    @test isequal(actual.branching_site_states, expected.branching_site_states)
    @test isequal(Dict(id => fields(state) for (id, state) in actual.bud_states),
        Dict(id => fields(state) for (id, state) in expected.bud_states))
    @test isequal(queue_state(actual.event_queue), queue_state(expected.event_queue))
    @test iszero(actual.deferred_growth_count)
end

function check_physiology_and_balance(result; require_positive=true)
    @test !isempty(result.frames)
    @test isempty(first(result.frames).leaves_at_start)
    @test any(!isempty(frame.leaves) for frame in result.frames)
    @test result.provider.rebuild_count > 1
    @test !result.provider.seed_stem_used
    cumulative_positive, cumulative_negative = 0.0, 0.0
    previous_end = first(result.frames).leaves_at_start
    for frame in result.frames
        @test Set(frame.leaves_at_start) == Set(previous_end)
        @test Set(leaf.object_id for leaf in frame.leaves) == Set(frame.leaves_at_start)
        @test length(frame.leaves) == length(unique(leaf.object_id for leaf in frame.leaves))
        newborn = setdiff(Set(frame.leaves_at_end), Set(frame.leaves_at_start))
        @test isempty(intersect(newborn, Set(leaf.object_id for leaf in frame.leaves)))
        for leaf in frame.leaves
            @test leaf.area_m2 > 0 && leaf.d > 0
            @test isfinite(leaf.aPPFD) && leaf.aPPFD >= 0
            @test isfinite(leaf.Ra_SW_f) && leaf.Ra_SW_f >= 0
            @test all(isfinite, (leaf.A, leaf.Gₛ, leaf.Tₗ, leaf.Rn, leaf.H, leaf.λE))
            @test 0 <= leaf.iterations < 30
            @test isapprox(leaf.Rn, leaf.H + leaf.λE; atol=1e-6, rtol=1e-7)
            expected_carbon = leaf.A * leaf.area_m2 *
                result.weather[frame.execution].duration_seconds * 12e-6
            @test leaf.carbon_step_gC ≈ expected_carbon
            cumulative_positive += max(expected_carbon, 0.0)
            cumulative_negative += max(-expected_carbon, 0.0)
        end
        ledger = only(frame.plants)
        @test ledger.positive_net_gC ≈ cumulative_positive
        @test ledger.negative_net_gC ≈ cumulative_negative
        @test result.initial_reserve_gC + cumulative_positive ≈
            ledger.reserve_gC + ledger.construction_gC + cumulative_negative
        @test ledger.reserve_gC >= 0 && ledger.construction_gC >= 0
        previous_end = frame.leaves_at_end
    end
    @test cumulative_positive + cumulative_negative > 0
    if require_positive
        @test cumulative_positive > 0
    end

    status = plant(result)
    demands = [row.intent_key for row in status.demand_history]
    payments = [row.intent_key for row in status.allocation_history]
    @test !isempty(payments)
    @test length(demands) == length(unique(demands))
    @test length(payments) == length(unique(payments))
    @test all(key in demands for key in payments)
    @test sum(row.allocated_gC for row in status.allocation_history) ≈ status.spent_carbon_gC
    @test any(row.organ_symbol === :Leaf for row in status.allocation_history)
    @test any(row.organ_symbol === :Internode for row in status.allocation_history)

    # This scene represents the start of the last interval, before its growth.
    cache = result.light_kernel.runtime_cache
    @test cache !== nothing
    @test Set(cache.target_ids) == Set(last(result.frames).leaves_at_start)
    owners = cache.owner_map
    for leaf in last(result.frames).leaves
        keys_for_leaf = [key for key in keys(owners) if owners[key] == leaf.object_id]
        @test !isempty(keys_for_leaf)
        @test all(key.source_node_id == leaf.runtime_node_id && key.source_instance_id > 0
            for key in keys_for_leaf)
    end

    schedule = Dict(row.application_id => row for row in
        PlantSimEngine.Diagnostics.explain_schedule(result.simulation))
    @test schedule[:archimed_light].root_scheduled
    @test schedule[:coupled_interval].root_scheduled
    @test all(schedule[application].manual_call_only for application in (
        :energy_balance, :photosynthesis, :stomatal_conductance, :leaf_carbon,
        :carbon_supply, :architecture_development, :growth_demand, :growth_allocation,
    ))
    carbon_bindings = filter(row -> row.application_id == :leaf_carbon && row.input == :A,
        PlantSimEngine.Diagnostics.explain_bindings(result.simulation))
    @test length(carbon_bindings) == length(model_objects(result.model; scale=:Leaf))
    @test all(row.source_application_ids == [:energy_balance] && row.policy isa HoldLast
        for row in carbon_bindings)
    return nothing
end

function check_native_history(result)
    rows = collect_outputs(result.simulation, :fpa_carbon_history; sink=nothing)
    ids = Set(id for frame in result.frames for id in frame.leaves_at_end)
    @test !isempty(ids)
    @test length(unique((row.object_id, row.timestep) for row in rows)) == length(rows)
    for id in ids
        expected = [(Float64(frame.execution), leaf.carbon_step_gC)
            for frame in result.frames for leaf in frame.leaves if leaf.object_id == id]
        @test outputs(result.simulation)[(:leaf_carbon, id, :carbon_step_gC)] == expected
        selected = filter(row -> row.object_id == id.value, rows)
        @test getproperty.(selected, :timestep) == Int.(first.(expected))
        @test getproperty.(selected, :value) == last.(expected)
        @test getproperty.(selected, :datetime) ==
            [result.weather[Int(time)].date for (time, _) in expected]
    end
    @test length(rows) == sum(length(frame.leaves) for frame in result.frames)
    return nothing
end

function run_profile_tests(profile;
                           steps=profile === :rauh ? 3 : 4,
                           horizon=profile === :rauh ? 1.5 : 2.0,
                           seed=1,
                           abundant_reserve_gC=profile === :rauh ? 10.0 : 1.0,
                           limited_reserve_gC=profile === :rauh ? 0.3375 : 0.0002875,
                           organs=profile === :rauh ? (
                               Internode=(potential_dry_mass_g=0.1, construction_cost_gC_per_gDM=0.5),
                               Leaf=(potential_dry_mass_g=0.05, construction_cost_gC_per_gDM=0.5),
                           ) : nothing)
    return @testset "$profile FPA light–carbon–growth coupling" begin
        request() = OutputRequest(Many(scale=:Leaf), :carbon_step_gC;
            name=:fpa_carbon_history, application=:leaf_carbon)
        organ_options = isnothing(organs) ? NamedTuple() : (; organs)
        abundant = F.run_example(profile; steps, horizon, seed,
            organ_options..., initial_reserve_gC=abundant_reserve_gC, outputs=request())
        check_source_and_role(abundant)
        check_abundant_architecture(abundant)
        check_physiology_and_balance(abundant)
        check_native_history(abundant)
        reserve = limited_reserve_gC
        @test 0 < reserve < abundant_reserve_gC
        limited = F.run_example(profile; steps, horizon, seed,
            organ_options..., initial_reserve_gC=reserve, outputs=request())
        check_source_and_role(limited)
        # This short Rauh canopy is a net carbon sink while resource-limited;
        # signed leaf exchange still runs and is paid without implicit debt.
        check_physiology_and_balance(limited; require_positive=profile !== :rauh)
        check_native_history(limited)
        @test plant(limited).deferred_growth_count > 0
        @test any(only(frame.plants).deferred_attempts > 0 for frame in limited.frames)
        @test plant(limited).spent_carbon_gC > 0
        if profile === :merisier
            @test plant(limited).spent_carbon_gC > limited.initial_reserve_gC
        end
        @test bytes2hex(sha256(read(abundant.raw_parameters.source.path))) ==
            abundant.mapping.source_sha256
    end
end

function run_tests()
    @testset "Authentic FPA ecophysiology" begin
        for profile in (:rauh, :merisier)
            run_profile_tests(profile)
        end
    end
end

end # module FpaCouplingValidation
