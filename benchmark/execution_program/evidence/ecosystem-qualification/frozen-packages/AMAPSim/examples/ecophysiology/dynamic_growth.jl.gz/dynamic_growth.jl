"""A bounded, non-calibrated light–energy–carbon–growth composition."""
module DynamicGrowthExample

using AMAPSim
using AMAPSim.Modeling: ParameterCurve, ParameterGroup, AxisParameters, LateralProductionParameters
using ArchimedLight
using Dates
using MultiScaleTreeGraph
using PlantBiophysics
using PlantGeom
using PlantMeteo
using PlantSimEngine

include("dynamic_models.jl")
include("dynamic_geometry.jl")
include("organ_expansion.jl")
include("leaf_abscission.jl")
using .DynamicPhysiologyModels
using .DynamicPhysiologyModels.GrowthDemandModels: MassConstructionDemand
using .DynamicLightGeometry
using .OrganExpansionModels
using .LeafAbscissionModels

export scenario, run_example, synthetic_parameters, forcing

_curve(value) = ParameterCurve([0.0], [Float64(value)])
_group(group; kwargs...) = ParameterGroup(merge(group.values, (; kwargs...)))

"""Explicit small branching program derived from the retained deterministic fixture."""
function synthetic_parameters()
    parsed = read_parameters(joinpath(pkgdir(AMAPSim), "test", "fixtures", "reference",
        "synthetic_immediate_stage1", "input", "synthetic.fpa"))
    axis = parsed.axis
    topology = _group(axis.topology;
        maximum_growth_unit_count=_curve(3),
        maximum_branching_order_nature_zero=_curve(1),
    )
    growth = _group(axis.growth;
        maximum_test_count=_curve(2),
        first_cycle_preformed_test_count=_curve(2),
        first_cycle_preformed_elongation_probability=_curve(1),
    )
    geometry = _group(axis.geometry;
        initial_organ_length=_curve(5), initial_organ_diameter=_curve(0.2),
    )
    laterals = [LateralProductionParameters(lateral.name, lateral.global_parameters,
        lateral.branching_models, lateral.zones; organ_symbol=:Leaf)
        for lateral in parsed.lateral_productions]
    return AMAPSimParameters(parsed.source, parsed.initialization,
        AxisParameters(topology, axis.differentiation, growth, geometry), laterals, parsed.legacy)
end

"""One-hour authored weather rows; the rate maps seconds to virtual stages explicitly."""
function forcing(; par=(450.0, 450.0, 450.0, 450.0, 0.0, 450.0),
                   development_increment=0.5)
    isempty(par) && throw(ArgumentError("supply at least one radiation interval"))
    isfinite(development_increment) && development_increment >= 0 ||
        throw(ArgumentError("development_increment must be finite and nonnegative"))
    return map(enumerate(par)) do (index, irradiance)
        isfinite(irradiance) && irradiance >= 0 ||
            throw(ArgumentError("PAR irradiance must be finite and nonnegative"))
        atmosphere = Atmosphere(date=DateTime(2023, 6, 21, 10) + Hour(index - 1),
            duration=Hour(1), T=25.0, Wind=1.0, P=101.3, Rh=0.65, Cₐ=400.0,
            Ri_PAR_f=Float64(irradiance), Ri_NIR_f=0.55 * Float64(irradiance),
            sun_azimuth_deg=180.0, sun_elevation_deg=60.0, direct_fraction=0.7)
        return merge(NamedTuple(atmosphere), (duration_seconds=3600.0,
            development_rate_per_second=development_increment / 3600.0))
    end
end

# The native distributed writer stays root-scheduled. A local completion token
# gives the interval controller a dependency even while its Leaf set is empty.
struct IntervalLight{K} <: PlantSimEngine.AbstractModel
    kernel::K
end
PlantSimEngine.process(model::IntervalLight) = PlantSimEngine.process(model.kernel)
PlantSimEngine.inputs_(model::IntervalLight) = PlantSimEngine.inputs_(model.kernel)
PlantSimEngine.outputs_(model::IntervalLight) = merge(
    PlantSimEngine.outputs_(model.kernel), (light_epoch=0,))
PlantSimEngine.environment_inputs_(model::IntervalLight) =
    PlantSimEngine.environment_inputs_(model.kernel)
PlantSimEngine.variable_contracts_(model::IntervalLight) =
    PlantSimEngine.variable_contracts_(model.kernel)
PlantSimEngine.output_policy(::Type{IntervalLight{K}}) where {K} = PlantSimEngine.output_policy(K)
function PlantSimEngine.run!(model::IntervalLight, status, environment, constants, context)
    PlantSimEngine.run!(model.kernel, status, environment, constants, context)
    status.light_epoch += 1
    return nothing
end

PlantSimEngine.@process "coupled_growth_interval" verbose=false

"""Own the causal interval: existing leaves exchange carbon, then organs can be born."""
struct CoupledInterval{Expansion,Abscission,P} <: AbstractCoupled_Growth_IntervalModel
    provider::P
end
CoupledInterval(; expansion=false, abscission=false, provider=nothing) =
    CoupledInterval{expansion,abscission,typeof(provider)}(provider)
PlantSimEngine.inputs_(::CoupledInterval) = (light_epoch=Required(Int),)
PlantSimEngine.outputs_(::CoupledInterval{E,A}) where {E,A} = merge(
    (completed_intervals=0, interval_records=NamedTuple[]),
    A ? (abscission_history=NamedTuple[],) : NamedTuple())

function _leaf_records(runtime)
    return [let status=object.status, node=source_node(runtime, object)
        plant = node
        while symbol(plant) !== :Plant
            plant = parent(plant)
            plant === nothing && throw(ArgumentError("a coupled Leaf must belong to a Plant"))
        end
        raw_id = get(node_attributes(node), :source_topology_id, nothing)
        (object_id=object.id, plant_id=object_id(runtime, plant),
         source_node_id=raw_id === nothing ? node_id(node) : Int(raw_id),
         runtime_node_id=node_id(node),
         area_m2=status.area_m2, aPPFD=status.aPPFD, Ra_SW_f=status.Ra_SW_f,
         sky_fraction=status.sky_fraction, d=status.d, Tₗ=status.Tₗ,
         A=status.A, Gₛ=status.Gₛ, Rn=status.Rn, H=status.H, λE=status.λE,
         iterations=status.iter, carbon_step_gC=status.carbon_step_gC)
    end for object in model_objects(runtime; scale=:Leaf)]
end

function _expansion_records(runtime)
    records = NamedTuple[]
    for scale in (:Internode, :Leaf), object in model_objects(runtime; scale)
        s = object.status
        s.expansion_initialized || continue
        plant = source_node(runtime, object)
        while symbol(plant) !== :Plant
            plant = parent(plant)
        end
        push!(records, (object_id=object.id, plant_id=object_id(runtime, plant), symbol=scale,
            age_seconds=s.expansion_age_seconds, fraction=s.expansion_fraction,
            target=(Length=s.target_length_cm, Width=s.target_width_cm, Thickness=s.target_thickness_cm),
            dimensions=(Length=s.expanded_length_cm, Width=s.expanded_width_cm, Thickness=s.expanded_thickness_cm),
            prepaid_construction_gC=s.prepaid_construction_gC,
            deployed_construction_gC=s.deployed_construction_gC,
            unexpanded_construction_gC=s.unexpanded_construction_gC,
            changed=s.expansion_changed))
    end
    return records
end

function _expanded_dimensions(context, plant)
    runtime = runtime_model(context)
    dimensions = Dict{Int,NamedTuple{(:Length, :Width, :Thickness),NTuple{3,Float64}}}()
    for node in traverse(plant, identity)
        symbol(node) in (:Internode, :Leaf) || continue
        s = model_status(runtime, node)
        s.expansion_initialized || continue
        dimensions[node_id(node)] = (Length=s.expanded_length_cm, Width=s.expanded_width_cm,
            Thickness=s.expanded_thickness_cm)
    end
    return dimensions
end

function _abscise_leaves!(runtime, execution; expansion)
    # Validate the complete removal batch before changing topology. Only a
    # terminal leaf product may disappear; its developmental bearer stays.
    selected = [(object=object, node=source_node(runtime, object))
        for object in model_objects(runtime; scale=:Leaf) if object.status.abscission_due]
    records = NamedTuple[]
    scars = Any[]
    for (object, node) in selected
        isempty(children(node)) || throw(ArgumentError("abscission requires a terminal Leaf"))
        bearer = parent(node)
        symbol(bearer) === :Phytomer || throw(ArgumentError("a Leaf must have a Phytomer bearer"))
        get(node_attributes(bearer), :AbscisedOrganSymbol, nothing) === nothing ||
            throw(ArgumentError("the Phytomer already records an abscised organ"))
        any(child -> child !== node && symbol(child) in (:Leaf, :Internode), children(bearer)) &&
            throw(ArgumentError("abscission requires one botanical product per Phytomer"))
        plant = bearer
        while symbol(plant) !== :Plant
            plant = parent(plant)
            plant === nothing && throw(ArgumentError("the Leaf must belong to a Plant"))
        end
        s = object.status
        dimensions = expansion ? (Length=s.expanded_length_cm, Width=s.expanded_width_cm,
            Thickness=s.expanded_thickness_cm) : (Length=s.Length, Width=s.Width, Thickness=s.Thickness)
        push!(scars, AMAPSim._leaf_abscission_geometry(node; dimensions))
        prepaid = s.abscission_prepaid_gC
        deployed = expansion ? s.deployed_construction_gC : prepaid
        unexpanded = expansion ? s.unexpanded_construction_gC : zero(prepaid)
        isapprox(deployed + unexpanded, prepaid; rtol=1e-12, atol=1e-15) ||
            throw(ArgumentError("abscised construction disagrees with its settled payment"))
        raw = get(node_attributes(node), :source_topology_id, node_id(node))
        push!(records, (execution=execution, object_id=object.id,
            plant_id=object_id(runtime, plant), source_node_id=Int(raw),
            runtime_node_id=node_id(node), age_seconds=s.abscission_age_seconds,
            prepaid_construction_gC=prepaid, deployed_construction_gC=deployed,
            unexpanded_construction_gC=unexpanded))
    end
    for ((object, node), scar) in zip(selected, scars)
        bearer = parent(node)
        remove_object!(runtime, object.id; recursive=false)
        MultiScaleTreeGraph.prune!(node)
        bearer[:AbscisedOrganSymbol] = :Leaf
        bearer[:AbscisedLeafGeometry] = scar
    end
    return records
end

function PlantSimEngine.run!(model::CoupledInterval{Expansion,Abscission}, status,
                             environment, constants, context) where {Expansion,Abscission}
    runtime = runtime_model(context)
    before = [object.id for object in model_objects(runtime; scale=:Leaf)]
    # All steps are declared PlantSimEngine calls. The controller owns this
    # physical-time boundary; Monteith owns its own FvCB/Medlyn iteration.
    for name in (:dimensions, :energy, :leaf_carbon, :supply)
        run_call!(context, name; publish=true)
    end
    leaves = _leaf_records(runtime)
    run_call!(context, :growth; publish=true)
    expanded = NamedTuple[]
    geometry_invalidated = false
    if Expansion
        # Explicit current-topology targets refresh lifecycle bindings inside
        # this call, so end-of-interval newborns are initialized exactly once.
        run_call!(context, :internode_expansion; publish=true,
            objects=object_ids(runtime; scale=:Internode))
        run_call!(context, :leaf_expansion; publish=true,
            objects=object_ids(runtime; scale=:Leaf))
    end
    abscised = NamedTuple[]
    if Abscission
        run_call!(context, :leaf_abscission; publish=true,
            objects=object_ids(runtime; scale=:Leaf))
        abscised = _abscise_leaves!(runtime, status.completed_intervals + 1;
            expansion=Expansion)
        append!(status.abscission_history, abscised)
        isempty(abscised) || cleanup_source_ids!(model.provider)
        geometry_invalidated = !isempty(abscised)
    end
    if Expansion
        expanded = _expansion_records(runtime)
        geometry_invalidated |= any(organ.changed for organ in expanded)
    end
    # The deferred geometry backend owns disposable whole-plant views.
    geometry_invalidated && mark_environment_binding_dirty!(runtime)
    plants = [let s=object.status
        row = (object_id=object.id, plant_index=index(source_node(runtime, object)),
         positive_net_gC=s.credited_carbon_supply_gC,
         negative_net_gC=s.paid_carbon_loss_gC, construction_gC=s.spent_carbon_gC,
         reserve_gC=s.remaining_carbon_gC, development_time=s.development_time,
         allocations=length(s.allocation_history), deferred_attempts=s.deferred_growth_count)
        removed = Abscission ? sum(organ.prepaid_construction_gC
            for organ in status.abscission_history if organ.plant_id == object.id; init=0.0) : 0.0
        if Abscission
            active = s.spent_carbon_gC - removed
            active >= -1e-15 || throw(ArgumentError("abscised cost exceeds paid construction"))
            row = merge(row, (active_construction_gC=max(active, 0.0),
                abscised_construction_gC=removed))
        end
        if Expansion
            own_organs = filter(organ -> organ.plant_id == object.id, expanded)
            deployed = sum(organ.deployed_construction_gC for organ in own_organs; init=0.0)
            unexpanded = sum(organ.unexpanded_construction_gC for organ in own_organs; init=0.0)
            isapprox(deployed + unexpanded + removed, s.spent_carbon_gC; rtol=1e-12, atol=1e-15) ||
                throw(ArgumentError("expanded and prepaid construction disagree with the settled organ ledger"))
            row = merge(row, (deployed_construction_gC=deployed, unexpanded_construction_gC=unexpanded))
        end
        row
    end for object in model_objects(runtime; scale=:Plant)]
    status.completed_intervals += 1
    frame = (execution=status.completed_intervals,
        leaves_at_start=before, leaves=leaves,
        leaves_at_end=[object.id for object in model_objects(runtime; scale=:Leaf)],
        plants=plants)
    Expansion && (frame = merge(frame, (expansion=expanded,)))
    Abscission && (frame = merge(frame, (abscission=abscised,)))
    if Expansion || Abscission
        frame = merge(frame, (geometry_invalidated=geometry_invalidated,
            structure_revision=PlantSimEngine.Advanced.model_revision(runtime),
            environment_revision=PlantSimEngine.Advanced.environment_revision(runtime)))
    end
    push!(status.interval_records, frame)
    return nothing
end

function scenario(; parameters=synthetic_parameters(), geometry_seed=17, expansion=nothing,
                    abscission=nothing, kwargs...)
    topology = build_initial_topology(parameters)
    provider = DynamicSceneProvider(topology, parameters; geometry_seed,
        dimension_provider=expansion === nothing ? nothing : _expanded_dimensions)
    return _scenario(topology, parameters, provider; expansion, abscission, kwargs...)
end

# Shared application graph: only the source projection, geometry provider and
# explicit reserve model differ in the two-plant example.
function _scenario(topology, parameters, provider; weather=forcing(), seed=7,
                    expansion=nothing, abscission=nothing,
                    initial_reserve_gC=0.01,
                    allocation=PhotosyntheticReserveAllocation(; initial_reserve_gC),
                    organs=(
                        Internode=(potential_dry_mass_g=0.0001, construction_cost_gC_per_gDM=0.5),
                        Leaf=(potential_dry_mass_g=0.00005, construction_cost_gC_per_gDM=0.5),
                    ),
                    energy_model=SurfaceEnergyBalance(maxiter=30),
                    photosynthesis_model=Fvcb(VcMaxRef=80.0, JMaxRef=140.0, RdRef=1.0),
                    conductance_model=Medlyn(0.03, 12.0))
    isempty(weather) && throw(ArgumentError("supply at least one weather row"))
    options = LightOptions(turtle_sectors=8, all_in_turtle=true, pixel_size=0.002,
        scattering=false, toricity=false, cache_radiation=true,
        radiation_timestep_minutes=60.0, radiation_input_semantics=:interval_mean,
        nir_interception=true, include_sky_fraction=true)
    optical_models = models_for("dynamic" => (
        "Leaf" => translucent(par=0.15, nir=0.85),
        "*" => translucent(par=0.20, nir=0.50)))
    light_simulation = LightSimulation(provider.last_scene, optical_models; options)
    light_kernel = ArchimedLightModel(light_simulation; output_schema=:coupling,
        scene_provider=provider,
        source_roots=context -> DynamicLightGeometry.source_roots(provider, context),
        par_energy_to_photon=4.57)
    demand = MassConstructionDemand(; organs)
    expansion_apps = if expansion === nothing
        ()
    else
        expansion isa NamedTuple || throw(ArgumentError("expansion must be an explicit named tuple"))
        Tuple(ModelSpec(OrganExpansion(symbol; expansion...,
                construction_cost_gC=GrowthDemandModels.construction_carbon_demand(
                    getproperty(demand.organs, symbol).potential_dry_mass_g,
                    getproperty(demand.organs, symbol).construction_cost_gC_per_gDM));
            name=Symbol(lowercase(string(symbol)), "_expansion"), on=Many(scale=symbol))
            for symbol in (:Internode, :Leaf))
    end
    abscission_apps = if abscission === nothing
        ()
    else
        abscission isa NamedTuple || throw(ArgumentError("abscission must be an explicit named tuple"))
        (ModelSpec(LeafAbscission(; abscission...,
            construction_cost_gC=GrowthDemandModels.construction_carbon_demand(
                demand.organs.Leaf.potential_dry_mass_g,
                demand.organs.Leaf.construction_cost_gC_per_gDM));
            name=:leaf_abscission, on=Many(scale=:Leaf)),)
    end
    own(application, variable) = One(within=Self(), application=application, var=variable,
                                    policy=HoldLast())
    applications = (
        ModelSpec(expansion === nothing ? LeafDimension() : ExpandedLeafDimension();
            name=:leaf_dimensions, on=Many(scale=:Leaf),
            # Deliberate accepted state carried from the preceding interval end.
            inputs=expansion === nothing ? NamedTuple() :
                (expanded_width_cm=own(:leaf_expansion, :expanded_width_cm),)),
        ModelSpec(IntervalLight(light_kernel); name=:archimed_light, on=One(scale=:Scene),
            outputs_to=(OutputTo(Many(scale=:Leaf, within=SceneScope()); coverage=:exact),)),
        ModelSpec(energy_model; name=:energy_balance, on=Many(scale=:Leaf),
            inputs=(d=own(:leaf_dimensions, :d), Ra_SW_f=own(:archimed_light, :Ra_SW_f),
                    sky_fraction=own(:archimed_light, :sky_fraction)),
            calls=(photosynthesis=One(within=Self(), application=:photosynthesis),)),
        ModelSpec(photosynthesis_model; name=:photosynthesis, on=Many(scale=:Leaf),
            inputs=(aPPFD=own(:archimed_light, :aPPFD),),
            calls=(stomatal_conductance=One(within=Self(), application=:stomatal_conductance),)),
        ModelSpec(conductance_model; name=:stomatal_conductance, on=Many(scale=:Leaf)),
        ModelSpec(LeafNetCarbon(); name=:leaf_carbon, on=Many(scale=:Leaf),
            inputs=(A=own(:energy_balance, :A), area_m2=own(:archimed_light, :area))),
        ModelSpec(PlantCarbonSupply(); name=:carbon_supply, on=Many(scale=:Plant),
            inputs=(leaf_carbon_gC=Many(scale=:Leaf, within=Subtree(),
                application=:leaf_carbon, var=:carbon_step_gC, policy=HoldLast()),)),
        ModelSpec(demand; name=:growth_demand, on=Many(scale=:Plant),
            inputs=(growth_intents=own(:architecture_development, :growth_intents),)),
        ModelSpec(allocation; name=:growth_allocation, on=Many(scale=:Plant),
            inputs=(growth_intents=own(:architecture_development, :growth_intents),
                realized_growth_intents=own(:architecture_development, :realized_growth_intents),
                demand_history=own(:growth_demand, :demand_history),
                cumulative_carbon_supply_gC=own(:carbon_supply, :cumulative_carbon_supply_gC),
                cumulative_carbon_loss_gC=own(:carbon_supply, :cumulative_carbon_loss_gC))),
        expansion_apps...,
        abscission_apps...,
        ModelSpec(CoupledInterval(expansion=expansion !== nothing, abscission=abscission !== nothing,
            provider=abscission === nothing ? nothing : provider);
            name=:coupled_interval, on=One(scale=:Scene),
            inputs=(light_epoch=One(scale=:Scene, application=:archimed_light, var=:light_epoch),),
            calls=merge((
                dimensions=Many(scale=:Leaf, application=:leaf_dimensions),
                energy=Many(scale=:Leaf, application=:energy_balance),
                leaf_carbon=Many(scale=:Leaf, application=:leaf_carbon),
                supply=Many(scale=:Plant, application=:carbon_supply),
                growth=Many(scale=:Plant, application=:architecture_development),
            ), expansion === nothing ? NamedTuple() : (
                internode_expansion=Many(scale=:Internode, application=:internode_expansion),
                leaf_expansion=Many(scale=:Leaf, application=:leaf_expansion),
            ), abscission === nothing ? NamedTuple() : (
                leaf_abscission=Many(scale=:Leaf, application=:leaf_abscission),
            ))),
    )
    model = build_model(topology; parameters, seed, development_increment=0.0,
        development_increment_contract=AMAPSim.DEVELOPMENT_INCREMENT_CONTRACT,
        applications, environment=weather,
        before_growth_calls=(growth_demand=One(within=Self(), application=:growth_demand),),
        growth_allocation_call=One(within=Self(), application=:growth_allocation))
    return (; model, topology, provider, light_simulation, light_kernel, demand, allocation,
            weather, initial_reserve_gC)
end

function run_example(; outputs=:none, kwargs...)
    setup = scenario(; kwargs...)
    simulation = PlantSimEngine.run!(setup.model; steps=length(setup.weather), outputs)
    scene = only(model_objects(setup.model; scale=:Scene)).status
    return (; setup..., simulation, frames=copy(scene.interval_records))
end

end

if abspath(PROGRAM_FILE) == @__FILE__
    result = DynamicGrowthExample.run_example()
    println([(execution=f.execution, leaves=length(f.leaves_at_end), plant=only(f.plants))
             for f in result.frames])
end
