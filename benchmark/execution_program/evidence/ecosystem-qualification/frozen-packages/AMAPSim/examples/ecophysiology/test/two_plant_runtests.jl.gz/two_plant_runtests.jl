module TwoPlantValidation

using AMAPSim
using ArchimedLight
using MultiScaleTreeGraph
using PlantGeom
using PlantSimEngine
using Serialization
using Test

include(joinpath(@__DIR__, "..", "two_plant_growth.jl"))
const E = TwoPlantGrowthExample
const D = E.DynamicGrowthExample

function rng_bytes(rng)
    buffer = IOBuffer()
    Serialization.serialize(buffer, copy(rng))
    return take!(buffer)
end

# Current runtime IDs are deliberately unique after assembly. Compare botanical
# structure independently of those IDs and of the scene's plant index labels.
function local_structure(plant)
    nodes = MultiScaleTreeGraph.traverse(plant, identity)
    positions = IdDict(node => index for (index, node) in enumerate(nodes))
    return [(
        parent=get(positions, MultiScaleTreeGraph.parent(node), 0),
        link=MultiScaleTreeGraph.link(node),
        symbol=MultiScaleTreeGraph.symbol(node),
        index=node === plant ? 0 : MultiScaleTreeGraph.index(node),
        scale=MultiScaleTreeGraph.scale(node),
    ) for node in nodes]
end

function event_mechanisms(trace)
    return [(; (name => value for (name, value) in pairs(row)
        if !(endswith(string(name), "_id") || endswith(string(name), "_ids")))...)
        for row in trace]
end

function plant_objects(result)
    objects = model_objects(result.model; scale=:Plant)
    return sort!(objects; by=object -> MultiScaleTreeGraph.index(source_node(result.model, object)))
end

function plant_descendants(result, plant)
    return Set(object_id(result.model, node) for node in
        MultiScaleTreeGraph.traverse(source_node(result.model, plant), identity))
end

# Derive the intended physical destination independently of the light kernel's
# source_roots callback and cached owner_map. Public placed-plant :id metadata
# identifies the authored live plant; source-local provenance identifies the
# exact descendant. Equal raw IDs in the other plant cannot substitute for it.
function physical_owner_expectations(result)
    scene = result.provider.last_scene
    scene_owners = PlantGeom.source_owners(scene)
    expected = Dict{PlantGeom.SourceOwnerKey,PlantSimEngine.ObjectId}()
    expected_roots = Dict{Int,Any}()
    ordinals = Set{Int}()
    placed_roots = MultiScaleTreeGraph.children(scene.mtg)
    @test length(placed_roots) == 2
    for placed_root in placed_roots
        ordinal = MultiScaleTreeGraph.node_attributes(placed_root)[:id]
        @test ordinal in eachindex(result.topologies)
        @test ordinal ∉ ordinals
        push!(ordinals, Int(ordinal))
        live_root = result.topologies[Int(ordinal)].plant
        local_nodes = Dict{Int,Any}()
        for node in MultiScaleTreeGraph.traverse(live_root, identity)
            raw = get(MultiScaleTreeGraph.node_attributes(node), :source_topology_id, nothing)
            # End-of-interval newborns are absent from this interval's scene.
            # Their provenance is assigned at the next geometry boundary.
            raw === nothing && continue
            @test !haskey(local_nodes, Int(raw))
            local_nodes[Int(raw)] = node
        end
        for scene_node in MultiScaleTreeGraph.traverse(placed_root, identity)
            key = get(scene_owners, MultiScaleTreeGraph.node_id(scene_node), nothing)
            key === nothing && continue
            @test haskey(local_nodes, key.source_node_id)
            destination = object_id(result.model, local_nodes[key.source_node_id])
            @test get(expected_roots, key.source_instance_id, live_root) === live_root
            expected_roots[key.source_instance_id] = live_root
            @test !haskey(expected, key) || expected[key] == destination
            expected[key] = destination
        end
    end
    @test ordinals == Set(eachindex(result.topologies))
    @test length(expected_roots) == 2
    return (; expected, expected_roots)
end

function check_frame_carbon(result)
    objects = plant_objects(result)
    plant_ids = Set(object.id for object in objects)
    initial = Dict(object.id => result.initial_reserves_gC[index]
        for (index, object) in enumerate(objects))
    positive = Dict(id => 0.0 for id in plant_ids)
    negative = Dict(id => 0.0 for id in plant_ids)
    membership = Dict(object.id => plant_descendants(result, object) for object in objects)
    previous_end = first(result.frames).leaves_at_start
    for frame in result.frames
        @test Set(frame.leaves_at_start) == Set(previous_end)
        @test Set(leaf.object_id for leaf in frame.leaves) == Set(frame.leaves_at_start)
        @test length(frame.leaves) == length(unique(leaf.object_id for leaf in frame.leaves))
        newborn = setdiff(Set(frame.leaves_at_end), Set(frame.leaves_at_start))
        @test isempty(intersect(newborn, Set(leaf.object_id for leaf in frame.leaves)))
        @test Set(plant.object_id for plant in frame.plants) == plant_ids
        for leaf in frame.leaves
            @test leaf.plant_id in plant_ids
            @test leaf.object_id in membership[leaf.plant_id]
            @test all(leaf.object_id ∉ members for (id, members) in membership if id != leaf.plant_id)
            @test leaf.area_m2 > 0
            @test isfinite(leaf.carbon_step_gC)
            @test leaf.carbon_step_gC ≈ leaf.A * leaf.area_m2 * 3600.0 * 12e-6
            positive[leaf.plant_id] += max(leaf.carbon_step_gC, 0.0)
            negative[leaf.plant_id] += max(-leaf.carbon_step_gC, 0.0)
        end
        for plant in frame.plants
            @test plant.positive_net_gC ≈ positive[plant.object_id]
            @test plant.negative_net_gC ≈ negative[plant.object_id]
            @test plant.reserve_gC >= 0
            @test initial[plant.object_id] + plant.positive_net_gC ≈
                plant.reserve_gC + plant.construction_gC + plant.negative_net_gC
        end
        @test sum(values(initial)) + sum(plant.positive_net_gC for plant in frame.plants) ≈
            sum(plant.reserve_gC + plant.construction_gC + plant.negative_net_gC
                for plant in frame.plants)
        previous_end = frame.leaves_at_end
    end
    return (; objects, membership, positive, negative)
end

@testset "Two growing plants retain source identity and separate carbon ledgers" begin
    result = E.run_example(initial_reserves_gC=(0.01, 0.02), seed=7)
    @test length(result.frames) == 6
    @test length(result.topologies) == length(result.source_topologies) == 2
    @test result.topologies[1].scene === result.topologies[2].scene
    check = check_frame_carbon(result)
    @test length(check.objects) == 2
    @test check.objects[1].id != check.objects[2].id
    @test isempty(intersect(check.membership[check.objects[1].id],
        check.membership[check.objects[2].id]))
    @test all(check.positive[object.id] > 0 for object in check.objects)
    @test all(check.negative[object.id] > 0 for object in check.objects)

    # The untouched input graphs really use colliding raw IDs. Their registered
    # live copies have globally unique current IDs and preserve source-local IDs
    # in a separate per-plant provenance namespace.
    raw_inputs = [Set(MultiScaleTreeGraph.node_id(node) for node in
        MultiScaleTreeGraph.traverse(topology.plant, identity))
        for topology in result.source_topologies]
    @test raw_inputs[1] == raw_inputs[2]
    @test !isempty(raw_inputs[1])
    live_node_ids = [MultiScaleTreeGraph.node_id(node) for node in
        MultiScaleTreeGraph.traverse(result.topologies[1].scene, identity)]
    @test length(live_node_ids) == length(unique(live_node_ids))
    for source in result.source_topologies
        reference = AMAPSim.build_initial_topology(D.synthetic_parameters();
            plant_index=MultiScaleTreeGraph.index(source.plant))
        @test AMAPSim.topology_signature(source.scene) == AMAPSim.topology_signature(reference.scene)
        @test !any(node -> MultiScaleTreeGraph.symbol(node) in (:Leaf, :Phytomer),
            MultiScaleTreeGraph.traverse(source.plant, identity))
        @test_throws ArgumentError object_id(result.model, source.plant)
    end
    @test_throws ArgumentError object_id(result.model, deepcopy(first(result.topologies).plant))

    last_frame = last(result.frames)
    local_leaf_ids = [Set(leaf.source_node_id for leaf in last_frame.leaves
        if leaf.plant_id == object.id) for object in check.objects]
    @test !isempty(intersect(local_leaf_ids...))
    for leaf in last_frame.leaves
        index = only(index for (index, object) in enumerate(check.objects)
            if object.id == leaf.plant_id)
        live_node = source_node(result.model, leaf.object_id)
        @test MultiScaleTreeGraph.node_id(live_node) == leaf.runtime_node_id
        @test result.provider.source_ids[index][live_node] == leaf.source_node_id
    end

    cache = getproperty(result.light_kernel, :runtime_cache)
    @test cache !== nothing
    @test Set(getproperty(cache, :target_ids)) == Set(last_frame.leaves_at_start)
    owner_map = getproperty(cache, :owner_map)
    namespaces = Dict(object.id => Set{Int}() for object in check.objects)
    for leaf in last_frame.leaves
        owners = [owner for owner in keys(owner_map) if owner_map[owner] == leaf.object_id]
        @test length(owners) == 1
        owner = only(owners)
        @test owner.source_node_id == leaf.source_node_id
        @test owner.source_instance_id > 0
        push!(namespaces[leaf.plant_id], owner.source_instance_id)
    end
    @test all(length(instances) == 1 for instances in values(namespaces))
    @test isempty(intersect(namespaces[check.objects[1].id], namespaces[check.objects[2].id]))
    shared_raw_id = first(intersect(local_leaf_ids...))
    colliding = [owner for owner in keys(owner_map) if owner.source_node_id == shared_raw_id]
    @test length(colliding) == 2
    @test colliding[1] != colliding[2]
    @test owner_map[colliding[1]] != owner_map[colliding[2]]
    @test length(unique(owner.source_instance_id for owner in colliding)) == 2

    physical = physical_owner_expectations(result)
    @test Set(keys(owner_map)) == Set(keys(physical.expected))
    @test all(owner_map[key] == destination for (key, destination) in physical.expected)

    # Flush the completed topology barrier before inspecting current binding
    # coverage. This does not run light, physiology, allocation or architecture.
    bindings = PlantSimEngine.Diagnostics.explain_bindings(result.model)
    # Source-root pair order carries no physical identity. Compiling the same
    # independently derived mapping in reverse order must preserve destinations.
    roots = collect(pairs(physical.expected_roots))
    reversed_map = PlantGeom.compile_source_owner_map(result.provider.last_scene,
        result.model; source_roots=reverse(roots))
    @test Dict(reversed_map) == physical.expected
    # This non-mutating control swaps the two exact roots. Their colliding raw
    # IDs still resolve, but the independent physical-destination oracle detects
    # the interchange. No provider, cached map, scene or botanical node is edited.
    namespaces = sort!(collect(keys(physical.expected_roots)))
    swapped_roots = Dict(namespaces[1] => physical.expected_roots[namespaces[2]],
        namespaces[2] => physical.expected_roots[namespaces[1]])
    swapped_map = PlantGeom.compile_source_owner_map(result.provider.last_scene,
        result.model; source_roots=swapped_roots)
    @test any(swapped_map[key] != destination for (key, destination) in physical.expected)
    gathers = filter(row -> row.input == :leaf_carbon_gC, bindings)
    @test length(gathers) == 2
    for object in check.objects
        selected = Set(resolve_object_ids(result.model,
            Many(scale=:Leaf, within=Subtree()); context=object.id))
        row = only(row for row in gathers if row.consumer_id == object.id.value)
        @test Set(row.source_ids) == Set(id.value for id in selected)
        @test all(id in check.membership[object.id] for id in selected)
        @test row.copy_semantics == :live_references
    end

    for (index, object) in enumerate(check.objects)
        status = object.status
        @test all(row.intent_key.plant_id == object.id for row in status.demand_history)
        @test all(row.intent_key.plant_id == object.id for row in status.allocation_history)
        @test length(status.allocation_history) ==
            length(unique(row.intent_key for row in status.allocation_history))
        @test sum(row.allocated_gC for row in status.allocation_history) ≈ status.spent_carbon_gC
        baseline = D.run_example(seed=status.random_seed)
        baseline_plant = only(model_objects(baseline.model; scale=:Plant)).status
        @test rng_bytes(status.rng) == rng_bytes(baseline_plant.rng)
        @test status.development_time == baseline_plant.development_time
        @test status.processed_events == baseline_plant.processed_events
        @test isequal(event_mechanisms(status.event_trace), event_mechanisms(baseline_plant.event_trace))
        @test local_structure(result.topologies[index].plant) == local_structure(baseline.topology.plant)
    end

    replay = E.run_example(initial_reserves_gC=(0.01, 0.02), seed=7)
    @test isequal(result.frames, replay.frames)
    replay_objects = plant_objects(replay)
    @test all(rng_bytes(object.status.rng) == rng_bytes(replay_object.status.rng)
        for (object, replay_object) in zip(check.objects, replay_objects))
end

@testset "A funded neighbor cannot subsidize an unfunded seed" begin
    result = E.run_example(initial_reserves_gC=(0.01, 0.0), seed=7)
    check = check_frame_carbon(result)
    @test result.provider.seed_stem_used == (false, true)
    @test length(MultiScaleTreeGraph.children(result.provider.last_scene.mtg)) == 2
    funded, unfunded = check.objects
    @test any(leaf.plant_id == funded.id for frame in result.frames for leaf in frame.leaves)
    @test all(leaf.plant_id != unfunded.id for frame in result.frames for leaf in frame.leaves)
    @test check.positive[funded.id] > 0
    @test iszero(check.positive[unfunded.id])
    @test iszero(check.negative[unfunded.id])
    for frame in result.frames
        plant = only(plant for plant in frame.plants if plant.object_id == unfunded.id)
        @test iszero(plant.positive_net_gC)
        @test iszero(plant.negative_net_gC)
        @test iszero(plant.construction_gC)
        @test iszero(plant.reserve_gC)
    end
    status = unfunded.status
    @test status.deferred_growth_count > 0
    @test !isempty(status.demand_history)
    @test isempty(status.allocation_history)
    @test all(row.intent_key.plant_id == unfunded.id for row in status.demand_history)
    @test length(status.demand_history) == length(unique(row.intent_key for row in status.demand_history))
    bindings = PlantSimEngine.Diagnostics.explain_bindings(result.model)
    unfunded_gather = only(row for row in bindings
        if row.input == :leaf_carbon_gC && row.consumer_id == unfunded.id.value)
    @test isempty(unfunded_gather.source_ids)
end

include("expansion_runtests.jl")
include("provider_cleanup_runtests.jl")
include("abscission_runtests.jl")

end
