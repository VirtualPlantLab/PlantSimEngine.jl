using AMAPSim
using ArchimedLight
using Dates
using MultiScaleTreeGraph
using PlantBiophysics
using PlantGeom
using PlantMeteo
using PlantSimEngine

# Reuse the reviewed coffee architecture, traits, and geometry instead of
# maintaining a second coffee parameterization in this coupling example.
include(joinpath(@__DIR__, "..", "coffee", "run.jl"))

const PAR_WATT_TO_MICROMOL = 4.57
const CARBON_MOLAR_MASS_G_PER_MICROMOL = 12.0e-6
const CENTIMETRES_TO_METRES = 0.01
const SQUARE_CENTIMETRES_TO_SQUARE_METRES = 1.0e-4
const COFFEE_LIGHT_PLANT_ID = 1
const ECOPHYSIOLOGY_SURFACE_AREA_CONTRACT = PlantSimEngine.VariableContract(
    unit=:square_metre,
    basis=:organ,
    temporal=nothing,
    aggregation=:total,
    extent=:extensive,
)
const _ORGAN_STEP_CARBON_GAIN_CONTRACT = PlantSimEngine.VariableContract(
    unit=:gram_carbon,
    basis=:organ,
    temporal=:step,
    aggregation=:total,
    extent=:extensive,
)

PlantSimEngine.@process "leaf_carbon_gain" verbose = false
PlantSimEngine.@process "fixed_fraction_allocation" verbose = false

is_coffee_leaf(node) = MultiScaleTreeGraph.symbol(node) == :Leaf

"""
Integrate net assimilation over the represented radiative mesh surface and timestep.

The same mesh surface normalizes ArchimedLight's PPFD and PlantBiophysics' `A`.
`botanical_leaf_area` is reported separately and is not used to rescale this rate.
"""
struct LeafCarbonGain <: AbstractLeaf_Carbon_GainModel end

PlantSimEngine.inputs_(::LeafCarbonGain) = (
    A=PlantSimEngine.Required(Real),
    area=PlantSimEngine.Required(Real),
)
PlantSimEngine.outputs_(::LeafCarbonGain) = (carbon_gain_g=0.0,)
PlantSimEngine.variable_contracts_(::LeafCarbonGain) = (
    area=ECOPHYSIOLOGY_SURFACE_AREA_CONTRACT,
    carbon_gain_g=_ORGAN_STEP_CARBON_GAIN_CONTRACT,
)

function _duration_seconds(environment)
    Dates.value(Dates.Millisecond(environment.duration)) / 1000.0
end

function PlantSimEngine.run!(
    ::LeafCarbonGain,
    status,
    environment,
    constants=nothing,
    context=nothing,
)
    status.carbon_gain_g =
        status.A * status.area * _duration_seconds(environment) *
        CARBON_MOLAR_MASS_G_PER_MICROMOL
    return nothing
end

"""Allocate plant carbon gain between three illustrative destination pools."""
struct FixedFractionAllocation{T<:Real} <: AbstractFixed_Fraction_AllocationModel
    leaf_fraction::T
    wood_fraction::T
    reserve_fraction::T

    function FixedFractionAllocation(
        leaf_fraction::T,
        wood_fraction::T,
        reserve_fraction::T,
    ) where {T<:Real}
        fractions = (leaf_fraction, wood_fraction, reserve_fraction)
        all(fraction -> 0 <= fraction <= 1, fractions) || throw(ArgumentError(
            "allocation fractions must be between zero and one",
        ))
        isapprox(sum(fractions), one(T); atol=eps(float(T)) * 16, rtol=0) ||
            throw(ArgumentError("allocation fractions must sum to one"))
        new{T}(fractions...)
    end
end

PlantSimEngine.inputs_(::FixedFractionAllocation) = (
    leaf_carbon_g=PlantSimEngine.Required(Vector{Float64}),
)
PlantSimEngine.outputs_(::FixedFractionAllocation) = (
    assimilated_carbon_g=0.0,
    leaf_pool_g=0.0,
    wood_pool_g=0.0,
    reserve_pool_g=0.0,
)
PlantSimEngine.variable_contracts_(::FixedFractionAllocation) = (
    leaf_carbon_g=_ORGAN_STEP_CARBON_GAIN_CONTRACT,
)

function PlantSimEngine.run!(
    model::FixedFractionAllocation,
    status,
    environment,
    constants=nothing,
    context=nothing,
)
    carbon = foldl(
        (total, value) -> total + Float64(value),
        status.leaf_carbon_g;
        init=0.0,
    )
    status.assimilated_carbon_g = carbon
    status.leaf_pool_g += model.leaf_fraction * carbon
    status.wood_pool_g += model.wood_fraction * carbon
    status.reserve_pool_g += model.reserve_fraction * carbon
    return nothing
end

function tutorial_atmosphere()
    Atmosphere(
        date=DateTime(2023, 6, 21, 12),
        duration=Hour(1),
        T=25.0,
        Wind=1.0,
        P=101.3,
        Rh=0.65,
        Cₐ=400.0,
        Ri_PAR_f=450.0,
        Ri_NIR_f=0.0,
        # These explicit values are the resolved sky for the fixed date,
        # latitude, and one-hour interval in `tutorial_light_weather()`.
        sun_azimuth_deg=336.89450500744636,
        sun_elevation_deg=73.11086765482884,
        direct_fraction=0.7413369872488782,
    )
end

function tutorial_light_weather()
    return (
        date=DateTime(2023, 6, 21, 12),
        step_duration=3600.0,
        latitude=8.0,
        Ri_PAR_f=450.0,
    )
end

function tutorial_light_options()
    LightOptions(
        turtle_sectors=8,
        all_in_turtle=true,
        pixel_size=0.01,
        scattering=false,
        cache_radiation=true,
        toricity=false,
        radiation_timestep_minutes=60.0,
        radiation_input_semantics=:interval_mean,
        nir_interception=false,
    )
end

function tutorial_light_models()
    models_for(
        "coffee" => (
            "Leaf" => translucent(par=0.15, nir=0.90),
            "*" => translucent(par=0.20, nir=0.50),
        ),
    )
end

function materialize_metres!(root)
    centimetres_to_metres = PlantGeom.scale3(CENTIMETRES_TO_METRES)
    pending = Any[root]
    while !isempty(pending)
        node = pop!(pending)
        if PlantGeom.has_geometry(node)
            mesh_cm = PlantGeom.refmesh_to_mesh(node)
            node[:type] = is_coffee_leaf(node) ? "Leaf" : "Internode"
            node[:geometry] = PlantGeom.Geometry(
                ref_mesh=PlantGeom.RefMesh(
                    "coffee_component_$(MultiScaleTreeGraph.node_id(node))",
                    mesh_cm,
                ),
                transformation=centimetres_to_metres,
            )
        end
        append!(pending, MultiScaleTreeGraph.children(node))
    end
    return root
end

function coffee_light_scene(snapshot)
    plant = deepcopy(snapshot.result.topology.plant)
    MultiScaleTreeGraph.reparent!(plant, nothing)
    materialize_metres!(plant)
    return make_scene(
        domain=(-1.0, -1.0, 1.0, 1.0),
        source_path="AMAPSim coffee horizon $(snapshot.horizon)",
    ) do builder
        add_plant!(
            builder,
            plant;
            group="coffee",
            id=COFFEE_LIGHT_PLANT_ID,
            source_length_unit="cm",
            scene_length_unit="m",
            source_to_scene_scale=CENTIMETRES_TO_METRES,
        )
    end
end

function _coffee_light_source_roots(snapshot, scene)
    source_instance_ids = Set(
        owner.source_instance_id for owner in values(PlantGeom.source_owners(scene))
        if owner !== nothing
    )
    length(source_instance_ids) == 1 || error(
        "The coffee light scene must contain exactly one source-instance " *
        "namespace; got $(sort!(collect(source_instance_ids))).",
    )
    return Dict(only(source_instance_ids) => snapshot.result.topology.plant)
end

function prepare_light_stage(snapshot)
    scene = coffee_light_scene(snapshot)
    models = tutorial_light_models()
    options = tutorial_light_options()
    weather = tutorial_light_weather()
    report = check_simulation(scene, [weather]; models, options)
    isempty(report.errors) || error(join(report.errors, "\n"))
    simulation = LightSimulation(scene, models; options)
    source_roots = _coffee_light_source_roots(snapshot, scene)
    return (; simulation, source_roots)
end

function initialize_leaf_physiology!(snapshot, atmosphere)
    all_leaf_nodes = filter(
        is_coffee_leaf,
        MultiScaleTreeGraph.traverse(snapshot.result.topology.scene, identity),
    )
    initialized_leaves = map(all_leaf_nodes) do leaf
        botanical_leaf_area =
            Float64(leaf[:EstimatedLeafAreaCm2]) *
            SQUARE_CENTIMETRES_TO_SQUARE_METRES
        isfinite(botanical_leaf_area) && botanical_leaf_area > 0 || error(
            "Leaf $(MultiScaleTreeGraph.node_id(leaf)) has invalid botanical area " *
            "$(repr(botanical_leaf_area)) m²",
        )
        return (; leaf, botanical_leaf_area)
    end
    for initialized in initialized_leaves
        leaf = initialized.leaf
        leaf[:Tₗ] = atmosphere.T
        leaf[:Cₛ] = atmosphere.Cₐ
        leaf[:Dₗ] = atmosphere.VPD
        leaf[:botanical_leaf_area] = initialized.botanical_leaf_area
    end
    return nothing
end

function physiology_applications(;
    photosynthesis_model=Fvcb(VcMaxRef=80.0, JMaxRef=140.0, RdRef=1.0),
    conductance_model=Medlyn(0.03, 12.0),
    allocation_model=FixedFractionAllocation(0.30, 0.50, 0.20),
)
    radiative_source(variable) = One(
        within=Self(),
        application=:archimed_light,
        var=variable,
        policy=HoldLast(),
    )
    return (
        ModelSpec(
            photosynthesis_model;
            name=:photosynthesis,
            on=Many(scale=:Leaf),
            inputs=(
                :aPPFD => radiative_source(:aPPFD),
            ),
            calls=(
                :stomatal_conductance => One(
                    within=Self(),
                    application=:stomatal_conductance,
                ),
            ),
        ),
        ModelSpec(
            conductance_model;
            name=:stomatal_conductance,
            on=Many(scale=:Leaf),
        ),
        ModelSpec(
            LeafCarbonGain();
            name=:leaf_carbon_gain,
            on=Many(scale=:Leaf),
            inputs=(
                :A => One(
                    within=Self(),
                    application=:photosynthesis,
                    var=:A,
                    policy=HoldLast(),
                ),
                :area => radiative_source(:area),
            ),
        ),
        ModelSpec(
            allocation_model;
            name=:carbon_allocation,
            on=Many(scale=:Plant),
            inputs=(
                :leaf_carbon_g => Many(
                    scale=:Leaf,
                    within=Subtree(),
                    application=:leaf_carbon_gain,
                    var=:carbon_gain_g,
                    policy=HoldLast(),
                ),
            ),
        ),
    )
end

function distributed_light_application(light)
    kernel = ArchimedLightModel(
        light.simulation;
        output_schema=:coupling,
        source_roots=light.source_roots,
        par_energy_to_photon=PAR_WATT_TO_MICROMOL,
    )
    application = ModelSpec(
        kernel;
        name=:archimed_light,
        on=One(scale=:Scene),
        outputs_to=(
            OutputTo(
                Many(scale=:Leaf, within=SceneScope());
                coverage=:exact,
            ),
        ),
    )
    return (; kernel, application)
end

function run_physiology_stage!(
    snapshot,
    light;
    applications=physiology_applications(),
)
    atmosphere = tutorial_atmosphere()
    initialize_leaf_physiology!(snapshot, atmosphere)
    distributed_light = distributed_light_application(light)
    model = build_model(
        snapshot.result.topology;
        development_increment=0.0,
        applications=(applications..., distributed_light.application),
        environment=atmosphere,
    )
    simulation = PlantSimEngine.run!(model; steps=1, outputs=:all)
    return (;
        model,
        simulation,
        light_kernel=distributed_light.kernel,
    )
end

function _last_published(simulation, application::Symbol, object_id, variable::Symbol)
    key = (application, object_id, variable)
    streams = PlantSimEngine.outputs(simulation)
    haskey(streams, key) || error("No retained output stream for $(repr(key))")
    history = streams[key]
    isempty(history) && error("Retained output stream $(repr(key)) is empty")
    return last(history)[2]
end

function leaf_results(model, simulation)
    rows = [
        (
            organ_id=MultiScaleTreeGraph.node_id(
                PlantSimEngine.source_node(model, leaf),
            ),
            radiative_mesh_area=Float64(_last_published(
                simulation,
                :archimed_light,
                leaf.id,
                :area,
            )),
            botanical_leaf_area=Float64(leaf.status.botanical_leaf_area),
            aPPFD_radiative=Float64(_last_published(
                simulation,
                :archimed_light,
                leaf.id,
                :aPPFD,
            )),
            aPPFD_surface=Float64(leaf.status.aPPFD),
            A=Float64(leaf.status.A),
            carbon_gain_g=Float64(leaf.status.carbon_gain_g),
        ) for leaf in model_objects(model; scale=:Leaf)
        if leaf.status.area > 0
    ]
    sort!(rows; by=row -> row.organ_id)
end

function plant_result(model)
    plant = only(model_objects(model; scale=:Plant))
    return (
        assimilated_carbon_g=Float64(plant.status.assimilated_carbon_g),
        leaf_pool_g=Float64(plant.status.leaf_pool_g),
        wood_pool_g=Float64(plant.status.wood_pool_g),
        reserve_pool_g=Float64(plant.status.reserve_pool_g),
    )
end

"""
    run_example(; horizon=2, seed=CANONICAL_SEED,
                applications=physiology_applications())

Run one explicit AMAPSim → PlantGeom → ArchimedLight → PlantBiophysics →
PlantSimEngine allocation step. The forcing, photosynthesis parameters, PAR
conversion factor, and allocation fractions are tutorial assumptions rather
than a calibrated coffee ecophysiology model. Architecture is frozen during this
single physiology step. Mesh surface area is the radiation and assimilation
reference; the botanical estimate remains a separate reported quantity.
"""
function run_example(;
    horizon::Integer=2,
    seed::Integer=CANONICAL_SEED,
    applications=physiology_applications(),
)
    snapshot = grow_coffee(horizon; seed)
    light = prepare_light_stage(snapshot)
    physiology = run_physiology_stage!(snapshot, light; applications)
    leaves = leaf_results(physiology.model, physiology.simulation)
    plant = plant_result(physiology.model)

    isempty(leaves) && error("the selected coffee horizon produced no geometric leaves")
    all(
        row -> row.radiative_mesh_area > 0 &&
               row.botanical_leaf_area > 0 &&
               row.aPPFD_radiative >= 0 &&
               row.aPPFD_surface >= 0,
        leaves,
    ) ||
        error("invalid leaf light or area values")
    all(
        row -> isapprox(
            row.aPPFD_radiative,
            row.aPPFD_surface;
            atol=1.0e-10,
            rtol=1.0e-10,
        ),
        leaves,
    ) || error("photosynthesis does not use the radiative surface PPFD")
    isapprox(
        plant.assimilated_carbon_g,
        sum(row.carbon_gain_g for row in leaves);
        atol=1.0e-10,
        rtol=1.0e-10,
    ) || error("plant allocation does not conserve leaf carbon gain")
    isapprox(
        plant.assimilated_carbon_g,
        plant.leaf_pool_g + plant.wood_pool_g + plant.reserve_pool_g;
        atol=1.0e-10,
        rtol=1.0e-10,
    ) || error("allocation pools do not conserve plant carbon gain")

    return (; snapshot, light, physiology, leaves, plant)
end

function main()
    result = run_example()
    return (
        leaf_count=length(result.leaves),
        mean_radiative_mesh_aPPFD=sum(row.aPPFD_radiative for row in result.leaves) /
                                    length(result.leaves),
        mean_surface_aPPFD=sum(row.aPPFD_surface for row in result.leaves) /
                         length(result.leaves),
        result.plant...,
    )
end

if abspath(PROGRAM_FILE) == @__FILE__
    main()
end
