"""Matched-cadence native/PSE boundary measurements; use Julia through Kaimon."""
module NativePSEBenchmark
using AMAPSim, PlantSimEngine, Statistics, Serialization, SHA, TOML
const PSE=PlantSimEngine
const DIR=normpath(joinpath(@__DIR__,"..","dev","native"))
include(joinpath(DIR,"native.jl"))
include(joinpath(DIR,"pse.jl"))
const N=NativeAMAP
const B=NativeAMAPPSE
PSE.@process "native_length_probe" verbose=false
struct LengthProbe <: AbstractNative_Length_ProbeModel end
PSE.inputs_(::LengthProbe)=(length=PSE.Required(Real),)
PSE.outputs_(::LengthProbe)=(observed_length=0.0f0,)
function PSE.run!(::LengthProbe,status,environment,constants,context)
    status.observed_length=status.length
    return nothing
end

function metric(f)
    before=ccall(:clock,Culong,())
    result=@timed Base.invokelatest(f)
    elapsed=Float64(ccall(:clock,Culong,())-before)/1_000_000
    result.value,Dict("cpu_seconds"=>elapsed,"seconds"=>result.time,
        "allocated_bytes"=>result.bytes,"allocation_count"=>Base.gc_alloc_count(result.gcstats),
        "gc_seconds"=>result.gctime,"compile_seconds"=>result.compile_time,
        "recompile_seconds"=>result.recompile_time)
end
# Hash values field by field: raw isbits-array serialization can contain padding.
function value_bytes!(io, value)
    if value === nothing
        write(io, UInt8(0))
    elseif value isa Bool
        write(io, UInt8(1), UInt8(value))
    elseif value isa Unsigned
        write(io, UInt8(2), UInt8(sizeof(value)), UInt64(value))
    elseif value isa Signed
        write(io, UInt8(3), UInt8(sizeof(value)), Int64(value))
    elseif value isa AbstractFloat
        write(io, UInt8(4), UInt8(sizeof(value)), Float64(value))
    elseif value isa Enum
        write(io, UInt8(11), Int64(Int(value)))
        value_bytes!(io,nameof(typeof(value)))
    elseif value isa Union{AbstractString,Symbol}
        text=string(value)
        write(io, UInt8(value isa Symbol ? 5 : 6), UInt64(ncodeunits(text)))
        write(io, codeunits(text))
    elseif value isa AbstractDict
        write(io, UInt8(7), UInt64(length(value)))
        for key in sort!(collect(keys(value)); by=string)
            value_bytes!(io,key); value_bytes!(io,value[key])
        end
    elseif value isa AbstractArray
        write(io, UInt8(8), UInt64(ndims(value)))
        for dimension in size(value);write(io,UInt64(dimension));end
        for item in value;value_bytes!(io,item);end
    elseif value isa Tuple
        write(io, UInt8(9), UInt64(length(value)))
        for item in value;value_bytes!(io,item);end
    else
        names=fieldnames(typeof(value))
        write(io, UInt8(10), UInt64(length(names)))
        value_bytes!(io,nameof(typeof(value)))
        for name in names
            value_bytes!(io,name); value_bytes!(io,getfield(value,name))
        end
    end
    return nothing
end
function fingerprint(native)
    io=IOBuffer()
    # Immutable compiled input tables are pinned separately by input/source hashes.
    # Capture every changing field, including raw arenas, RNG, queue and trace.
    for name in fieldnames(typeof(native.plant))
        name===:parameters && continue
        value_bytes!(io,name)
        value_bytes!(io,getfield(native.plant,name))
    end
    bytes2hex(sha256(take!(io)))
end
function write_report(path,data)
    open(path*".partial","w") do io;TOML.print(io,data;sorted=true);end
    mv(path*".partial",path;force=true)
end

function sample(parameters,increment,steps,variant)
    if variant===:native
        state,setup=metric(()->N.NativeModel(parameters;seed=1))
        _,warm=metric(()->begin
            for _ in 1:steps
                N.advance_to!(state,state.plant.time+increment;geometry=true)
            end
        end)
        return Dict("setup"=>setup,"run"=>warm,"fingerprint"=>fingerprint(state),
            "exposed_objects"=>0,"native_axes"=>count(a->a.active,state.plant.axes),
            "native_organs"=>count(o->o.active,state.plant.organs))
    end
    applications=variant===:pse ? () :
        (PSE.ModelSpec(LengthProbe();name=:length_probe,on=PSE.Many(scale=:IN)),)
    model,setup=metric(()->B.scenario(
        (B.NativePlant(:plant,parameters;seed=1,development_increment=increment),);
        applications,scales=(Internode=:IN,),geometry=true))
    simulation,compilation=metric(()->PSE.run!(model;steps=0,outputs=:none))
    _,warm=metric(()->PSE.continue!(simulation;steps=steps))
    state=B.native_state(model,:plant).native
    return Dict("setup"=>setup,"scenario_compilation"=>compilation,"run"=>warm,
        "fingerprint"=>fingerprint(state),"exposed_objects"=>length(PSE.model_objects(model;scale=:IN)),
        "native_axes"=>count(a->a.active,state.plant.axes),
        "native_organs"=>count(o->o.active,state.plant.organs))
end

"""Measure identical outer steps, geometry cadence and final architectural RNG.

Scene setup, PSE scenario compilation and first-call JIT are reported separately.
The :pse variant has no declared organ model and must expose zero organs;
:pse_internodes additionally includes actual registration/publication and a
minimal user length consumer, so its overhead is reported separately.
"""
function execute_case(input,horizon,label;output_directory,steps=4,warm_samples=5,
    variants=(:native,:pse,:pse_internodes))
    isdir(output_directory)||throw(ArgumentError("output_directory must exist"))
    steps>0&&warm_samples>0||throw(ArgumentError("positive steps/samples required"))
    all(v->v in (:native,:pse,:pse_internodes),variants)||throw(ArgumentError("unknown benchmark variant"))
    :native in variants||throw(ArgumentError("the direct native control is required"))
    length(unique(variants))==length(variants)||throw(ArgumentError("benchmark variants must be unique"))
    path=joinpath(output_directory,"native-pse-"*label*".toml")
    ispath(path)&&error("Preserve existing result: $path")
    parameters=AMAPSim.read_parameters(input)
    increment=Float64(horizon)/steps
    report=Dict{String,Any}("complete"=>false,"input"=>input,
        "input_sha256"=>bytes2hex(sha256(read(input))),"horizon"=>Float64(horizon),
        "increment"=>increment,"steps"=>steps,"samples"=>Any[],
        "julia"=>string(VERSION),"julia_optlevel"=>Int(Base.JLOptions().opt_level),
        "threads"=>Threads.nthreads(),"same_cadence"=>true,
        "fingerprint_contract"=>"Every non-parameter native plant field encoded recursively by primitive value, numeric type/array shape, and sorted dictionary keys; raw object metadata/padding excluded",
        "source_sha256"=>Dict(name=>bytes2hex(sha256(read(joinpath(DIR,name)))) for name in readdir(DIR) if endswith(name,".jl")),
        "benchmark_sha256"=>bytes2hex(sha256(read(@__FILE__))),
        "private_native_state_retained_as_output"=>false,
        "clock_contract"=>"Fresh state. Native geometry after every outer step in all variants. Setup and PSE scenario preparation separate; native+PSE run includes all runtime boundary work. Optional IN variant includes lifecycle, property publication and user probe. No light/carbon models.")
    write_report(path,report)
    expected=nothing
    try
        for index in 0:warm_samples
            # Rotate execution order to reduce systematic warm/cache ordering.
            for offset in eachindex(variants)
                variant=variants[mod1(index+offset,length(variants))]
                GC.gc()
                row=Base.invokelatest(sample,parameters,increment,Int(steps),variant)
                row["variant"]=string(variant);row["sample"]=index
                row["warm"]=index>0&&row["run"]["compile_seconds"]==row["run"]["recompile_seconds"]==0
                push!(report["samples"],row);write_report(path,report)
                expected===nothing&&(expected=row["fingerprint"])
                row["fingerprint"]==expected||error("Native state/RNG differs across variants or repetitions")
                variant===:pse&&row["exposed_objects"]!=0&&error("Unrequested organ objects were registered")
                index==0||row["warm"]||error("Warm runtime contains compilation")
            end
        end
        summaries=Dict{String,Any}()
        for variant in variants
            rows=filter(row->row["variant"]==string(variant)&&row["sample"]>0,report["samples"])
            summaries[string(variant)]=Dict(k=>median(row["run"][k] for row in rows) for k in keys(first(rows)["run"]))
        end
        report["warm_summary"]=summaries
        report["complete"]=true;write_report(path,report)
        return (;complete=true,path,warm_summary=summaries)
    catch exception
        report["failure"]=sprint(showerror,exception,catch_backtrace());write_report(path,report);rethrow()
    end
end
end
