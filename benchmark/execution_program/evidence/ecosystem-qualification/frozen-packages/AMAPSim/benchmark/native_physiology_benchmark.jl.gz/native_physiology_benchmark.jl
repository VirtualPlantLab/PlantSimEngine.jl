"""Small native light–photosynthesis–growth measurements. Run through Kaimon.

Use the optional ecophysiology environment. Loading/parsing the benchmark is
outside its clocks. Fresh scenario setup, PSE preparation and stepping are
reported separately; each profile's first observation is excluded from warm
medians. These observations share one process and package/compiler caches.
"""
module NativePhysiologyBenchmark

using AMAPSim, PlantSimEngine, Statistics, SHA, TOML

include(joinpath(pkgdir(AMAPSim), "examples", "ecophysiology", "native_growth.jl"))
const Example = NativePhysiologyExample
const Native = Example.Native
const Adapter = Example.Adapter
const CPU_TICKS = Sys.iswindows() ? 1_000.0 : 1_000_000.0

function metric(f)
    started = ccall(:clock, Culong, ())
    measured = @timed Base.invokelatest(f)
    return measured.value, Dict(
        "cpu_seconds" => Float64(ccall(:clock, Culong, ()) - started) / CPU_TICKS,
        "wall_seconds" => measured.time,
        "allocated_bytes" => measured.bytes,
        "gc_seconds" => measured.gctime,
        "compile_seconds" => measured.compile_time,
        "recompile_seconds" => measured.recompile_time)
end

snapshot(value::Union{Number,Symbol,AbstractString,Nothing,Missing}) = value
snapshot(value::Enum) = (nameof(typeof(value)), Int(value))
snapshot(value::Tuple) = map(snapshot, value)
snapshot(value::AbstractArray) = (size(value), map(snapshot, collect(value)))
snapshot(value::AbstractDict) = [(snapshot(key), snapshot(value[key]))
    for key in sort!(collect(keys(value)); by=repr)]
snapshot(value) = NamedTuple{fieldnames(typeof(value))}(
    map(name -> snapshot(getfield(value, name)), fieldnames(typeof(value))))

"""Retain every changing botanical field, queue and RNG; omit realized geometry."""
function botanical_snapshot(model)
    plant = model.plant
    names = filter(name -> name ∉ (:parameters, :organs), fieldnames(typeof(plant)))
    fields = NamedTuple{names}(map(name -> snapshot(getfield(plant, name)), names))
    return merge(fields, (organs=[(site=organ.site, axis=organ.axis, rank=organ.rank,
        active=organ.active) for organ in plant.organs],))
end

function sample_case(profile; steps=4, horizon=2.0, kwargs...)
    setup, setup_metrics = metric(() -> Example.scenario(profile; steps, horizon, kwargs...))
    simulation, preparation = metric(() -> PlantSimEngine.run!(setup.model;
        steps=0, outputs=:none))
    reference = Native.NativeModel(setup.plant.parameters; seed=setup.plant.seed)
    frames = Dict{String,Any}[]
    final_botany = nothing
    for step in 1:steps
        _, execution = metric(() -> step!(simulation))
        state = Adapter.native_state(setup.model, setup.plant.id)
        scene = only(model_objects(setup.model; scale=:Scene)).status
        status = model_status(setup.model, setup.plant.id)
        # Reference advancement, complete botanical equality and bookkeeping
        # checks occur outside the measured coupled step.
        Native.advance_to!(reference, Float64(horizon) * step / steps)
        final_botany = botanical_snapshot(state.native)
        @assert isequal(final_botany, botanical_snapshot(reference))
        @assert isapprox(setup.initial_reserve_gC + status.credited_carbon_supply_gC,
            status.remaining_carbon_gC + status.spent_carbon_gC + status.paid_carbon_loss_gC)
        @assert !state.coupled_pending && !state.organ_growth.failed
        @assert state.organ_growth.committed_revision == state.organ_growth.revision
        push!(frames, Dict("step" => step, "execution" => execution,
            "geometry_seconds" => scene.geometry_seconds,
            "light_seconds" => scene.light_seconds,
            "opening_lit_leaves" => length(scene.radiation_records),
            "living_organs" => count(organ -> organ.active, state.native.plant.organs),
            "projected_leaves" => length(model_objects(setup.model; scale=:Leaf)),
            "construction_gC" => status.spent_carbon_gC,
            "positive_net_gC" => status.credited_carbon_supply_gC,
            "negative_net_gC" => status.paid_carbon_loss_gC,
            "reserve_gC" => status.remaining_carbon_gC))
    end
    summary = Dict(key => sum(frame["execution"][key] for frame in frames)
        for key in keys(first(frames)["execution"]))
    summary["geometry_seconds"] = sum(frame["geometry_seconds"] for frame in frames)
    summary["light_seconds"] = sum(frame["light_seconds"] for frame in frames)
    return Dict("setup" => setup_metrics, "preparation" => preparation,
        "steps" => frames, "stepping" => summary,
        "botanical_fingerprint" => bytes2hex(sha256(repr(final_botany))),
        "equal_architecture_and_rng" => true)
end

"""
    run_case(profile; output_path=nothing, warm_samples=3, steps=4, horizon=2.0)

Measure one first observation and fresh warm repetitions of the documented
native physiological example. Warm stepping must contain no compilation.
Geometry and light durations are nested wall clocks; the remaining step time
also includes PSE scheduling, gas exchange, architecture, demand and expansion.
Allocated bytes are cumulative allocations, not peak or retained memory.
"""
function run_case(profile; output_path=nothing, warm_samples=3, steps=4,
    horizon=2.0, kwargs...)
    warm_samples isa Integer && !(warm_samples isa Bool) && warm_samples > 0 ||
        throw(ArgumentError("warm_samples must be a positive integer"))
    rows = Dict{String,Any}[]
    fingerprint = nothing
    for index in 1:(warm_samples + 1)
        row = sample_case(profile; steps, horizon, kwargs...)
        row["sample"] = index
        row["warm"] = index > 1
        fingerprint === nothing && (fingerprint = row["botanical_fingerprint"])
        @assert row["botanical_fingerprint"] == fingerprint
        if index > 1
            @assert iszero(row["stepping"]["compile_seconds"])
            @assert iszero(row["stepping"]["recompile_seconds"])
        end
        push!(rows, row)
    end
    warm = filter(row -> row["warm"], rows)
    medians = Dict(key => median(row["stepping"][key] for row in warm)
        for key in keys(first(warm)["stepping"]))
    report = Dict("complete" => true, "profile" => string(profile),
        "steps" => steps, "horizon" => Float64(horizon), "samples" => rows,
        "warm_medians" => medians,
        "scope" => "Fresh scenario setup and PSE preparation separate from coupled steps. " *
            "First observation excluded; shared compiler/package caches, no independent cold-start comparison. " *
            "Opening realized radiative geometry, real ArchimedLight and FvCB/Medlyn, carbon ledger and " *
            "native architectural development included. No display, output history or mesh export. " *
            "Full changing botanical state, future event queue and native RNG checked against direct " *
            "reference advancement outside clocks. Actual geometry follows the explicit growth law " *
            "and is not required to equal potential reference geometry. " *
            "Nested geometry/light wall clocks do not isolate photosynthesis from other remaining work. " *
            "Allocated bytes are cumulative allocations, not peak or retained memory.")
    if output_path !== nothing
        open(output_path, "w") do io
            TOML.print(io, report; sorted=true)
        end
    end
    return report
end

end # module NativePhysiologyBenchmark
