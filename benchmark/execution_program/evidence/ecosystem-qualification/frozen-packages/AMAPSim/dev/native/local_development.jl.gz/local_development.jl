"""A constant-rate segment of a continuous virtual developmental coordinate."""
struct _DevelopmentSegment
    physical_time::Float64
    development::Float64
    rate::Float64
end

mutable struct _AxisDevelopmentClock
    segments::Vector{_DevelopmentSegment}
end

struct _PhysicalDevelopmentEvent
    deadline::Float64
    native::NativeAMAPPlantEngine.PlantEvent
end

"""
    LocalDevelopment(model; pruning_clock=:development,
        pruning_seconds_per_stage=nothing)

Per-plant clock state for the experimental structure/function boundary. Create
it on a fresh native model. Physical time is seconds; each development rate is
an explicitly supplied number of native virtual stages per second, not a
calendar or thermal-time calibration inferred from the FPA.

`advance_development!` accepts a plant default and a complete sparse map of
axis-specific replacement rates. Missing overrides inherit the current plant
rate. Zero suspends future developmental events. Changing/removing an override
preserves attained progress. The current native lane has one apical meristem
per axis; this is not an independent clock for every dormant axillary bud.

Natural pruning follows each axis's developmental clock by default. Selecting
`:physical` requires an explicit positive `pruning_seconds_per_stage`; an FPA
pruning delay is converted with that coefficient when the event is scheduled.
Its resulting physical deadline is then independent of later growth-rate
changes. Management commands use physical coupling boundaries separately.

This sidecar owns no botanical arenas or RNG. Native event identities and their
axis-local developmental thresholds remain intact between calls. An exceptional
partial dispatch poisons the control and must not be retried.
"""
mutable struct LocalDevelopment
    physical_time::Float64
    default_development::Float64
    default_rate::Float64
    default_segments::Vector{_DevelopmentSegment}
    clocks::Vector{_AxisDevelopmentClock}
    overrides::Dict{Int,Float64}
    axis_count::Int
    used_local::Bool
    last_dispatch_physical::Float64
    pruning_clock::Symbol
    pruning_seconds_per_stage::Union{Nothing,Float64}
    pruning_deadlines::Dict{Int64,Float64}
    plant_identity::UInt
    failed::Bool
    running::Bool
end

function _development_number(value, label; positive=false)
    value isa Real && !(value isa Bool) || throw(ArgumentError("$label must be real"))
    isfinite(value) && (positive ? value>0 : value>=0) || throw(ArgumentError(
        "$label must be finite and $(positive ? "positive" : "nonnegative")"))
    typed=Float64(value)
    isfinite(typed) && (value==0 || typed>0) || throw(ArgumentError(
        "$label cannot be represented as Float64"))
    return typed
end

function LocalDevelopment(model::NativeModel; pruning_clock::Symbol=:development,
    pruning_seconds_per_stage=nothing)
    plant=model.plant
    iszero(plant.time) && iszero(plant.processed) || throw(ArgumentError(
        "attach local developmental clocks before advancing a fresh native plant"))
    pruning_clock in (:development,:physical) || throw(ArgumentError(
        "pruning_clock must be :development or :physical"))
    coefficient=if pruning_clock===:physical
        pruning_seconds_per_stage===nothing && throw(ArgumentError(
            "physical pruning requires explicit pruning_seconds_per_stage"))
        _development_number(pruning_seconds_per_stage,
            "pruning_seconds_per_stage"; positive=true)
    else
        pruning_seconds_per_stage===nothing || throw(ArgumentError(
            "pruning_seconds_per_stage is only meaningful for physical pruning"))
        nothing
    end
    return LocalDevelopment(0.,0.,1.,[_DevelopmentSegment(0.,0.,1.)],
        _AxisDevelopmentClock[],Dict{Int,Float64}(),length(plant.axes),false,0.,
        pruning_clock,coefficient,Dict{Int64,Float64}(),objectid(plant),false,false)
end

function _clock_value(segments,time::Float64)
    index=searchsortedlast(segments,time; by=x->x isa _DevelopmentSegment ? x.physical_time : x)
    segment=segments[max(1,index)]
    return segment.development+(time-segment.physical_time)*segment.rate
end

function _set_clock_rate!(segments,time,rate)
    last(segments).rate==rate && return nothing
    value=_clock_value(segments,time)
    segment=_DevelopmentSegment(time,value,rate)
    last(segments).physical_time==time ? (segments[end]=segment) : push!(segments,segment)
    return nothing
end

# Map an attained developmental threshold through the retained piecewise-linear
# history. Future thresholds use the current rate; arrested future is unbounded.
function _clock_physical_time(segments,target)
    for index in eachindex(segments)
        segment=segments[index]
        if target<=segment.development
            if index==1 && segment.rate>0
                return segment.physical_time+(target-segment.development)/segment.rate
            end
            return segment.physical_time
        end
        stop=index<length(segments) ? segments[index+1].physical_time : Inf
        if segment.rate>0 && (isinf(stop) ||
            target<=segment.development+(stop-segment.physical_time)*segment.rate)
            return segment.physical_time+(target-segment.development)/segment.rate
        end
    end
    return Inf
end

"""Current attained axis-local coordinate, including progress since its last event."""
function axis_development(control::LocalDevelopment,axis_id::Integer)
    !(axis_id isa Bool) && 1<=axis_id<=control.axis_count || throw(ArgumentError(
        "axis_id must identify an existing native axis"))
    return control.used_local ? _clock_value(control.clocks[axis_id].segments,
        control.physical_time) : control.default_development
end
axis_development_time(control::LocalDevelopment,axis_id::Integer)=
    axis_development(control,axis_id)

function _validate_development_frame(plant,duration,default_rate,axis_rates)
    seconds=_development_number(duration,"duration_seconds")
    rate=_development_number(default_rate,"development_rate")
    overrides=Dict{Int,Float64}()
    for (id,value) in pairs(axis_rates)
        id isa Integer && !(id isa Bool) && 1<=id<=length(plant.axes) ||
            throw(ArgumentError("axis-rate keys must identify existing native axes"))
        overrides[Int(id)]=_development_number(value,"axis development rate")
    end
    return seconds,rate,overrides
end

@inline function _physical_before(a::_PhysicalDevelopmentEvent,b::_PhysicalDevelopmentEvent)
    a.deadline!=b.deadline && return a.deadline<b.deadline
    x,y=a.native,b.native
    x.priority!=y.priority && return x.priority>y.priority
    x.process_id!=y.process_id && return x.process_id>y.process_id
    return x.sequence>y.sequence
end

# Engine.EPSILON is measured in native developmental stages. It cannot be
# added to a physical deadline: at a high rate that would admit arbitrarily
# much future development. Permit only one physical Float64 rounding step at
# the boundary, and never make a suspended infinite deadline eligible.
@inline _physical_due(deadline::Float64,horizon::Float64)=
    isfinite(deadline) && (deadline<=horizon || deadline==nextfloat(horizon))

function _physical_enqueue!(heap,event)
    push!(heap,event);index=length(heap)
    while index>1
        parent=index>>>1
        _physical_before(heap[parent],event) && break
        heap[index]=heap[parent];index=parent
    end
    heap[index]=event
    return nothing
end

function _physical_dequeue!(heap)
    first=heap[1];tail=pop!(heap)
    if !isempty(heap)
        index=1
        while (child=index<<1)<=length(heap)
            child<length(heap) && _physical_before(heap[child+1],heap[child]) && (child+=1)
            _physical_before(tail,heap[child]) && break
            heap[index]=heap[child];index=child
        end
        heap[index]=tail
    end
    return first
end

function _development_deadline(control,event,physical_now)
    if control.pruning_clock===:physical && event.kind!=NativeAMAPPlantEngine.APICAL
        return get(control.pruning_deadlines,event.sequence,Inf)
    end
    segments=control.clocks[event.axis].segments
    attained=_clock_value(segments,physical_now)
    event.time<=attained && return physical_now
    rate=last(segments).rate
    return iszero(rate) ? Inf : physical_now+(event.time-attained)/rate
end

function _transfer_new_events!(heap,plant,control,physical_now;
    dispatch_event=nothing)
    Engine=NativeAMAPPlantEngine
    while !isempty(plant.events)
        event=Engine.dequeue!(plant)
        axis=plant.axes[event.axis]
        if !axis.active || axis.generation!=event.generation
            plant.cancelled+=1
            delete!(control.pruning_deadlines,event.sequence)
            continue
        end
        if control.pruning_clock===:physical && event.kind!=Engine.APICAL &&
            !haskey(control.pruning_deadlines,event.sequence)
            dispatch_event===nothing && throw(ArgumentError(
                "physical pruning event has no captured scheduling origin"))
            delay=max(0.,event.time-dispatch_event.time)
            deadline=physical_now+delay*control.pruning_seconds_per_stage
            isfinite(deadline) || throw(ArgumentError("natural pruning deadline overflow"))
            control.pruning_deadlines[event.sequence]=deadline
        end
        deadline=_development_deadline(control,event,physical_now)
        _physical_enqueue!(heap,_PhysicalDevelopmentEvent(deadline,event))
    end
    return nothing
end

function _ensure_local_clocks!(control,plant)
    control.used_local && return nothing
    for _ in plant.axes
        push!(control.clocks,_AxisDevelopmentClock(copy(control.default_segments)))
    end
    control.used_local=true
    return nothing
end

function _new_axis_clocks!(control,plant,physical_now,default_rate)
    for index in length(control.clocks)+1:length(plant.axes)
        axis=plant.axes[index]
        # Native retrospective birth can precede the event that materializes
        # its axis. Retain that native birth origin and elapsed initial phase;
        # never copy the parent's biological age or restart the apical program.
        origin=axis.parent==0 ? _clock_value(control.default_segments,physical_now) :
            _clock_value(control.clocks[axis.parent].segments,physical_now)
        push!(control.clocks,_AxisDevelopmentClock([
            _DevelopmentSegment(physical_now,origin,default_rate)]))
    end
    control.axis_count=length(plant.axes)
    return nothing
end

function _mapped_bearer_end(plant,control,event,physical_now)
    axis=plant.axes[event.axis]
    axis.current_gu==0 && axis.parent!=0 && axis.first_gu_kind in (1,2) || return nothing
    parent=plant.axes[axis.parent]
    parent.current_gu!=0 || return nothing # Original kernel supplies its guard.
    target=plant.growth_units[parent.current_gu].end_time
    deadline=_clock_physical_time(control.clocks[axis.parent].segments,target)
    isinf(deadline) && return Inf
    return _clock_value(control.clocks[event.axis].segments,deadline)
end

"""Axis-local geometry observation coordinates; `nothing` preserves the reference lane."""
function development_observation_times(control::LocalDevelopment,model::NativeModel)
    objectid(model.plant)==control.plant_identity || throw(ArgumentError(
        "local development belongs to exactly one native plant"))
    control.used_local || return nothing
    return Float64[_clock_value(clock.segments,control.last_dispatch_physical)
        for clock in control.clocks]
end
development_times(control::LocalDevelopment,model::NativeModel)=
    development_observation_times(control,model)

"""Validate ownership and state before an external lifecycle transaction."""
function _bind_local_development!(control::LocalDevelopment,model::NativeModel)
    control.failed && throw(ArgumentError("local development failed; discard this simulation"))
    control.running && throw(ArgumentError("local development cannot be re-entered"))
    objectid(model.plant)==control.plant_identity || throw(ArgumentError(
        "local development belongs to exactly one native plant"))
    model.plant.time==control.default_development || throw(ArgumentError(
        "advance a clock-controlled plant only through its local development sidecar"))
    return nothing
end

"""Discard actions invalidated by an external native subtree removal."""
function _discard_stale_local_events!(control::LocalDevelopment,model::NativeModel)
    _bind_local_development!(control,model)
    plant=model.plant;Engine=NativeAMAPPlantEngine
    old=copy(plant.events)
    empty!(plant.events)
    for event in old
        axis=plant.axes[event.axis]
        if axis.active && axis.generation==event.generation
            Engine.requeue!(plant,event)
        else
            plant.cancelled+=1
            delete!(control.pruning_deadlines,event.sequence)
        end
    end
    return nothing
end

"""
    advance_development!(model, control, duration_seconds;
        default_rate=1.0, axis_rates=Dict{Int,Float64}(), geometry=true,
        max_events=10_000_000)

Advance one physical exchange with piecewise-constant developmental rates.
`axis_rates` is the complete replacement map for this exchange, not a patch;
removing an override resumes the plant default from attained local progress.
New axes inherit the plant default rate, retaining their native birth phase.
No local override is inherited implicitly by descendants.

The ordinary reference dispatcher is used unchanged while no axis override has
ever been supplied and pruning follows development. Otherwise due native
thresholds are merged on one physical event heap. Their native identity, local
threshold, source apical laws and random stream are retained. PSE or another
caller still owns resource demand, allocation and realized organ expansion.
"""
function advance_development!(model::NativeModel,control::LocalDevelopment,duration_seconds;
    default_rate=1.0,axis_rates=Dict{Int,Float64}(),geometry::Bool=true,
    max_events::Integer=10_000_000)
    plant=model.plant;Engine=NativeAMAPPlantEngine
    _bind_local_development!(control,model)
    max_events>=0 || throw(ArgumentError("native event bound must be nonnegative"))
    seconds,rate,overrides=_validate_development_frame(plant,duration_seconds,
        default_rate,axis_rates)
    horizon=control.physical_time+seconds
    development_horizon=control.default_development+rate*seconds
    isfinite(horizon) && isfinite(development_horizon) || throw(ArgumentError(
        "local development horizon overflow"))
    # Validate every local endpoint before publishing a new frame or sampling.
    if control.used_local
        for index in eachindex(control.clocks)
            isfinite(axis_development(control,index)+get(overrides,index,rate)*seconds) ||
                throw(ArgumentError("axis developmental horizon overflow"))
        end
    else
        for local_rate in values(overrides)
            isfinite(control.default_development+local_rate*seconds) || throw(ArgumentError(
                "axis developmental horizon overflow"))
        end
    end
    control.running=true
    control.failed=true
    heap=_PhysicalDevelopmentEvent[]
    current=nothing
    try
        physical_now=control.physical_time
        _set_clock_rate!(control.default_segments,physical_now,rate)
        if !control.used_local && all(==(rate),values(overrides)) &&
            control.pruning_clock===:development
            Engine.advance_to!(plant,development_horizon;max_events=max_events)
            control.axis_count=length(plant.axes)
            control.last_dispatch_physical=_clock_physical_time(
                control.default_segments,plant.last_event_time)
        else
            _ensure_local_clocks!(control,plant)
            for index in eachindex(control.clocks)
                _set_clock_rate!(control.clocks[index].segments,physical_now,
                    get(overrides,index,rate))
            end
            _transfer_new_events!(heap,plant,control,physical_now)
            attempts=0
            while !isempty(heap) && _physical_due(first(heap).deadline,horizon)
                attempts<max_events && plant.processed<max_events || error("native event bound exceeded")
                current=_physical_dequeue!(heap)
                event=current.native
                axis=plant.axes[event.axis]
                if !axis.active || axis.generation!=event.generation
                    plant.cancelled+=1
                    delete!(control.pruning_deadlines,event.sequence)
                    current=nothing
                    continue
                end
                physical_now=min(horizon,max(physical_now,current.deadline))
                plant.last_event_time=event.time
                Engine.before_event!(plant.rng,plant,event)
                if event.kind==Engine.APICAL
                    bearer_end=_mapped_bearer_end(plant,control,event,physical_now)
                    prepared=Engine.prepare_apical!(plant,event;bearer_end=bearer_end)
                    Engine.commit_apical!(plant,event,prepared)
                else
                    delete!(control.pruning_deadlines,event.sequence)
                    Engine.prune!(plant,event)
                end
                plant.processed+=1;attempts+=1
                control.last_dispatch_physical=physical_now
                _new_axis_clocks!(control,plant,physical_now,rate)
                _transfer_new_events!(heap,plant,control,physical_now;dispatch_event=event)
                current=nothing
            end
            plant.time=development_horizon
            plant.geometry_complete=false
        end
        control.physical_time=horizon
        control.default_development=development_horizon
        control.default_rate=rate
        control.overrides=overrides
        if geometry
            times=development_observation_times(control,model)
            times===nothing ? geometry!(model) : geometry!(model;observation_times=times)
        end
        control.failed=false
    finally
        # Botanical failure is an abort, not a trial rollback. Preserve pending
        # logical actions for inspection, but never permit retry after failure.
        current===nothing || Engine.requeue!(plant,current.native)
        for record in heap
            Engine.requeue!(plant,record.native)
        end
        control.running=false
    end
    return model
end
