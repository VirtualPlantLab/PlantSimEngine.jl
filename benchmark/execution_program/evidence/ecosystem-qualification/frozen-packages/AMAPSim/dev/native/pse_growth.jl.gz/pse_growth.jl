"""Plant-level architecture with optional organ-wise manual process calls."""
struct NativeArchitecture{C,A,P} <: AMAPSim.AbstractArchitectureDevelopmentModel
    before_growth_call_names::C
    carbon_policy::P
end
NativeArchitecture(names::Tuple=(); allocation_enabled::Bool=false, carbon_policy=nothing) =
    NativeArchitecture{typeof(names),allocation_enabled,typeof(carbon_policy)}(names, carbon_policy)

_allocation_enabled(::NativeArchitecture{C,A}) where {C,A} = A
_cached_carbon_enabled(model::NativeArchitecture) = model.carbon_policy !== nothing
_growth_calls_enabled(model::NativeArchitecture) =
    !isempty(model.before_growth_call_names) || _allocation_enabled(model)

function PSE.inputs_(model::NativeArchitecture)
    base = (_native_pse_state=PSE.Required(NativePSEState),
        development_increment=PSE.Required(Real))
    _cached_carbon_enabled(model) || return base
    frame = PSE.outputs_(model.carbon_policy).native_carbon_policy
    return merge(base, (native_carbon_policy=PSE.Required(typeof(frame)),))
end
function PSE.outputs_(model::NativeArchitecture)
    base = (native_revision=0,)
    if _cached_carbon_enabled(model)
        reserve = model.carbon_policy.initial_reserve_gC
        return merge(base, (remaining_carbon_gC=reserve, spent_carbon_gC=zero(reserve),
            credited_carbon_supply_gC=zero(reserve), allocated_organ_count=0,
            deferred_growth_count=0, pending_growth_count=0))
    end
    _growth_calls_enabled(model) || return base
    ports = merge(base, (growth_intents=AMAPSim.GrowthIntent{Float64}[],
        deferred_growth_count=0, pending_growth_count=0))
    return _allocation_enabled(model) ? merge(ports,
        (realized_growth_intents=AMAPSim.GrowthIntent{Float64}[],)) : ports
end
function PSE.variable_contracts_(model::NativeArchitecture)
    if _cached_carbon_enabled(model)
        return (development_increment=AMAPSim.DEVELOPMENT_INCREMENT_CONTRACT,
            native_carbon_policy=_CARBON_POLICY_CONTRACT,
            remaining_carbon_gC=_CARBON_RESERVE_CONTRACT,
            spent_carbon_gC=_CUMULATIVE_CARBON_CONTRACT,
            credited_carbon_supply_gC=_CUMULATIVE_CARBON_CONTRACT)
    end
    _growth_calls_enabled(model) || return NamedTuple()
    ports = (development_increment=AMAPSim.DEVELOPMENT_INCREMENT_CONTRACT,
        growth_intents=AMAPSim.GROWTH_INTENT_CONTRACT)
    return _allocation_enabled(model) ? merge(ports,
        (realized_growth_intents=AMAPSim.GROWTH_INTENT_CONTRACT,)) : ports
end

struct _NativeGrowthBridge{I,C}
    plant_id::I
    calls::C
    allocation_enabled::Bool
    runtime::Base.RefValue{Any}
end

function _growth_intent(bridge::_NativeGrowthBridge, intent)
    return AMAPSim.GrowthIntent(bridge.plant_id, UInt64(intent.axis_id),
        AMAPSim.EventID(UInt64(intent.event_sequence)), intent.phytomer_rank,
        intent.organ_symbol, intent.organ_index, intent.development_time)
end

function _growth_runtime(bridge::_NativeGrowthBridge)
    runtime = bridge.runtime[]
    runtime === nothing && throw(ArgumentError(
        "native PSE growth calls require the active plant architecture context"))
    return runtime
end

function _quote_native_growth!(bridge::_NativeGrowthBridge, native_intent)
    status, context = _growth_runtime(bridge)
    slot = status.growth_intents
    isempty(slot) || throw(ArgumentError("a native growth intention is already being observed"))
    intent = _growth_intent(bridge, native_intent)
    push!(slot, intent)
    try
        for name in bridge.calls
            PSE.run_call!(context, name; publish=false)
        end
        bridge.allocation_enabled || return true
        targets = PSE.run_call!(context, :growth_allocation; publish=false)
        # Reuse the package's existing organ identity/amount/decision checks.
        accepted = AMAPSim._growth_allocation_accepted(targets, intent)
        accepted || (status.deferred_growth_count += 1)
        return accepted
    finally
        empty!(slot)
    end
end

function _settle_native_growth!(bridge::_NativeGrowthBridge, native_intent)
    bridge.allocation_enabled || return nothing
    status, context = _growth_runtime(bridge)
    slot = status.realized_growth_intents
    isempty(slot) || throw(ArgumentError("a native growth settlement is already active"))
    push!(slot, _growth_intent(bridge, native_intent))
    try
        PSE.run_call!(context, :growth_allocation; publish=false)
    finally
        empty!(slot)
    end
    return nothing
end

function _plant_growth_control(plant::NativePlant, architecture::NativeArchitecture)
    runtime = Ref{Any}(nothing)
    if _cached_carbon_enabled(architecture)
        return _new_carbon_control(architecture.carbon_policy, plant.product_symbols), runtime
    end
    _growth_calls_enabled(architecture) || return nothing, runtime
    bridge = _NativeGrowthBridge(plant.id, architecture.before_growth_call_names,
        _allocation_enabled(architecture), runtime)
    control = NativeAMAP.GrowthControl(
        before_growth=intent -> _quote_native_growth!(bridge, intent),
        after_growth=intent -> _settle_native_growth!(bridge, intent),
        product_symbols=plant.product_symbols)
    return control, runtime
end

function PSE.run!(model::NativeArchitecture, status, environment, constants, context)
    state = getproperty(status, _STATE)
    increment = status.development_increment
    isfinite(increment) && increment >= 0 || throw(ArgumentError(
        "development_increment must be finite and nonnegative"))
    horizon = state.native.plant.time + increment
    isfinite(horizon) || throw(ArgumentError("native development horizon must be finite"))
    control = state.growth_control
    if control === nothing
        NativeAMAP.advance_to!(state.native, horizon; geometry=state.geometry)
    else
        control.failed && throw(ArgumentError(
            "a native growth commit or settlement failed; discard this simulation before retrying"))
        control.running && throw(ArgumentError("native growth control cannot be re-entered"))
        control.owned_plant === nothing || control.owned_plant === state.native.plant ||
            throw(ArgumentError("a native GrowthControl belongs to exactly one plant"))
        state.growth_runtime[] === nothing || throw(ArgumentError(
            "native PSE growth cannot be re-entered"))
        if _cached_carbon_enabled(model)
            bank = control.before_growth.bank
            _prepare_carbon_budget!(bank, status.native_carbon_policy)
            try
                NativeAMAP.advance_to!(state.native, horizon;
                    geometry=state.geometry, growth_control=control)
            finally
                _publish_carbon_bank!(status, bank, control)
            end
        else
            state.growth_runtime[] = (status, context)
            try
                if _allocation_enabled(model)
                    isempty(status.growth_intents) && isempty(status.realized_growth_intents) ||
                        throw(ArgumentError("native growth callback slots must be empty between steps"))
                    # Credit since-start supply even when this outer step contains
                    # no organ event. The allocator validates its cumulative ledger
                    # before any native sampling; an empty slot never spends carbon.
                    PSE.run_call!(context, :growth_allocation; publish=false)
                end
                NativeAMAP.advance_to!(state.native, horizon;
                    geometry=state.geometry, growth_control=control)
            finally
                state.growth_runtime[] = nothing
                status.pending_growth_count = length(NativeAMAP.pending_growth(control))
            end
        end
    end
    isempty(state.groups) || _synchronize!(PSE.runtime_model(context), state)
    status.native_revision += 1
    return nothing
end
