# Light and carbon supply for native growth

This optional prototype connects the native architecture arenas to ArchimedLight
and PlantBiophysics through ordinary PlantSimEngine applications. It keeps the
reference engine unchanged. Use the optional `examples/interactive_growth`
environment in Kaimon for the qualified viewer and this headless example;
light and physiology packages are not core AMAPSim dependencies. Its versioned
Project and Manifest pin the measured PlantSimEngine native-boundary revision
`592307c`. The qualification reports record the exact loaded sources. The older
`examples/ecophysiology` environment serves the earlier examples and retains
its different PSE pin.

```julia
using AMAPSim
include(joinpath(pkgdir(AMAPSim), "examples", "ecophysiology", "native_growth.jl"))
const E = NativePhysiologyExample
result = E.run_example(:merisier; steps=4, horizon=2.0, initial_reserve_gC=1.0)
last(result.frames)
```

Use `:rauh` for the other shipped FPA. Lower `initial_reserve_gC` to constrain
expansion; `par=(450.0, 450.0, 0.0, 450.0)` includes a dark interval. These
are demonstration settings, not calibrated traits or species phenology. The
initial reserve bootstraps construction: an empty seed plant with no reserve
cannot photosynthesize a first leaf into existence.

```mermaid
flowchart LR
    G["Opening realized geometry"] --> L["ArchimedLight"]
    L --> F["Leaf FvCB + Medlyn"]
    F --> C["Signed exchange, separate plant banks"]
    C --> D["Native development and potential organs"]
    D --> A["Demand, allocation, expansion"]
    A --> E["Closing realized geometry"]
    E -. "next interval" .-> G
```

## What the models calculate

`NativeAMAPPhysiology.scenario` composes scene radiation, leaf atmosphere,
photosynthesis, stomatal conductance, leaf carbon integration, plant supply,
construction demand, allocation and expansion. The photosynthesis wrapper
delegates to the existing PlantBiophysics FvCB model with its declared Medlyn
hard call. A zero-surface native organ contributes zero exchange and does not
enter a physiological calculation requiring a positive leaf area.

Temperature, surface CO₂ and leaf-to-air vapour pressure deficit are imposed
from the atmosphere. This is an explicit leaf-state hypothesis; this prototype
does not solve Monteith energy balance. The existing older ecophysiology
example still provides that separate coupling path.

Radiation uses the geometry actually constructed at the opening of the interval,
including stems that shade leaves. Photosynthesis is integrated over that same
represented surface and the explicit physical interval:

```math
\Delta C_i = A_i\,S_i\,\Delta t\,(12\times10^{-6})
```

Here `A` is net µmol CO₂ m⁻² s⁻¹, `S` is m², `Δt` is seconds and the result
is gC. Positive and negative net leaf exchanges are accumulated separately.
They are not gross photosynthesis and total plant respiration: FvCB already
includes its own respiration term, and this prototype adds no stem/root
maintenance model. Paid losses have priority over new construction. Each plant
satisfies:

```math
C_{initial}+C_{positive}=C_{reserve}+C_{construction}+C_{negative}.
```

Repeating a cumulative supply/loss does not credit or pay it twice. A loss that
would exceed the reserve after already committed construction raises an explicit
error. No carbon debt, automatic tissue destruction or remobilization is inferred.
Discard the simulation after any exchange exception, including a physiology or
preflight error before architecture advances. This composition provides no
whole-PSE rollback; completed model state cannot be treated as an untouched step.

## Geometry and ownership

FPA native product roles alone do not establish a lamina area. This example
explicitly maps Rauh's `feuille` and Merisier's `feuilles` product to Leaf, then
renders a diamond lamina whose width is a supplied multiple of the realized
native diameter. The conversion from native coordinates to metres and plant
positions in metres are explicit inputs. The represented mesh surface is the
area basis for both radiation and assimilation.

The demonstration demand law still estimates structural dry mass from the
native solid-frustum dimensions. It does not derive calibrated leaf mass or
thickness from the display lamina. Replace that PSE demand model when a
species-specific lamina mass/area law is available. Likewise the isometric
expansion law is one replaceable hypothesis.

Complete typed plant identity and native organ slot identify every radiative
owner. Two plants can have the same raw organ indices without sharing light
outputs or carbon banks. Only scales selected by the declared applications
become PSE Objects. In this composition Leaf models select the leaves;
non-photosynthetic native stem geometry can still shade them without a PSE
model on every stem.
The plant set is fixed for this prototype; native axes and organs can be born
or removed at each exchange.

## Time and feedback

Each opening geometry is committed by a previous exchange. New organs appear
after the current interval's physiological exchange and first contribute at
the next opening. A management cut issued between exchanges removes their
geometry and owners from that next light calculation. Natural removal follows
the native clock policy described in [the coupled modes guide](MODES.md).
The `management_cuts` port is consumed by the architectural phase, after this
composition's opening-geometry exchange. To remove an axis before an interval's
light calculation, use the boundary cut API between completed steps. A separate
pre-light management application is not provided by this example.

The example's physical-to-developmental rate is supplied explicitly. Carbon
limits realized construction while AMAPSim still establishes potential organs.
Developmental stress and local axis-rate controls remain separate scientific
choices; a carbon shortage is not automatically a plant-wide clock arrest.
The existing sparse axis-rate input can pause selected axes without resampling
already prepared botanical events or pausing the clocks of other axes. A
different event chronology can change how future draws from the shared native
stream are assigned. Exact RNG comparisons therefore use matching development
controls and equivalent work.

This is a maintained experimental example. The optional
[coupled interactive comparison](../../examples/interactive_growth/README.md#compare-lightcarbongrowth-scenarios)
uses this native path. The package default runtime, standalone progressive
viewer and parameter editor keep their existing engines. The architecture-only
C++ comparison is not a benchmark of these additional physiological models.
