# SPDX-License-Identifier: LGPL-3.0-or-later
# Numeric import/lookup algorithms follow AMAPsim ParamFile.cpp and
# AxisReference.cpp, copyright Jean-Francois Barczi / AMAPsim contributors.
# This prototype file does not relicense the surrounding MIT package.
"""Optional exact native Float32 parameter import and lookup.

The ordinary NativeAMAPScientificCore tables preserve the Julia reader's
Float64 contract. This separate compiler instead starts from the lossless FPA
source values, reproducing the C++ float parse, FCONV multiplication, integer
coordinates and Float32 interpolation order for native-source qualification.
"""
module NativeAMAPLegacyParameters
import AMAPSim
import ..NativeAMAPScientificCore as Science

struct LegacyParameter
    dimension::UInt8
    outer_mode::UInt8
    ages::Vector{Int32}
    offsets::Vector{Int32}
    modes::Vector{UInt8}
    positions::Vector{Int32}
    ordinates::Vector{Float32}
end
@inline source_position(x) = Int32(trunc(Int,Float32(x)-1.0f0))

function compile_parameter(p)
    if hasproperty(p,:source_value)
        raw = Float32(p.source_value)
        p.provenance.legacy_name === :glangins && abs(raw) < 1.0e-8 && (raw=1.0f-8)
        return LegacyParameter(0,0,Int32[],Int32[1,2],UInt8[0],Int32[0],
            Float32[raw*Float32(p.provenance.conversion)])
    elseif hasproperty(p,:curves)
        positions = Int32[]; ordinates = Float32[]; offsets = Int32[1]; modes = UInt8[]
        conversion = Float32(p.provenance.conversion)
        for curve in p.curves
            append!(positions,source_position.(curve.source_positions))
            append!(ordinates,[Float32(value)*conversion for value in curve.source_values])
            push!(offsets,Int32(length(positions)+1));push!(modes,UInt8(curve.interpolation))
        end
        return LegacyParameter(2,UInt8(p.interpolation),source_position.(p.source_physiological_ages),
            offsets,modes,positions,ordinates)
    elseif hasproperty(p,:source_values)
        conversion = Float32(p.provenance.conversion)
        return LegacyParameter(1,0,Int32[],Int32[1,length(p.positions)+1],
            UInt8[UInt8(p.interpolation)],source_position.(p.source_positions),
            [Float32(value)*conversion for value in p.source_values])
    end
    throw(ArgumentError("compile native parameters from original lossless parsed FPA records"))
end

@inline function first_ge(values::Vector{Int32},query::Int,lo::Int,hi::Int)
    while lo < hi
        middle = (lo+hi) >>> 1
        if values[middle] < query
            lo = middle+1
        else
            hi = middle
        end
    end
    return lo
end
@inline function curve_value(p::LegacyParameter,curve::Int,query::Int)::Float32
    lo = Int(p.offsets[curve]);hi = Int(p.offsets[curve+1])-1
    x = p.positions;y = p.ordinates
    query <= x[lo] && return y[lo]
    query >= x[hi] && return y[hi]
    upper = first_ge(x,query,lo,hi)
    lower = upper-1
    if p.modes[curve] == 0
        return query == x[upper] ? y[upper] : y[lower]
    end
    # AxisReference::val1DParameter: y0 + (y1-y0)*(x-x0)/(x1-x0).
    return y[lower]+((y[upper]-y[lower])*Float32(query-x[lower]))/Float32(x[upper]-x[lower])
end
@inline function AMAPSim.valueat(p::LegacyParameter,position::Real)::Float64
    p.dimension <= 1 || throw(ArgumentError("surface requires age and position"))
    return Float64(curve_value(p,1,trunc(Int,position)))
end
@inline function AMAPSim.valueat(p::LegacyParameter,age::Real,position::Real)::Float64
    p.dimension == 2 || throw(ArgumentError("only a surface accepts age and position"))
    query = trunc(Int,age);pos = trunc(Int,position);ages = p.ages
    query <= first(ages) && return Float64(curve_value(p,1,pos))
    query >= last(ages) && return Float64(curve_value(p,length(ages),pos))
    upper = first_ge(ages,query,1,length(ages))
    query == ages[upper] && return Float64(curve_value(p,upper,pos))
    lower = upper-1
    p.outer_mode == 0 && return Float64(curve_value(p,lower,pos))
    y0 = curve_value(p,lower,pos);y1 = curve_value(p,upper,pos)
    return Float64(y0+((y1-y0)*Float32(query-ages[lower]))/Float32(ages[upper]-ages[lower]))
end
function AMAPSim._next_surface_control_position(p::LegacyParameter,age::Real,position::Real)
    p.dimension == 2 || throw(ArgumentError("control query requires a surface"))
    query = trunc(Int,age)
    curve = if query <= first(p.ages)
        1
    elseif query >= last(p.ages)
        length(p.ages)
    else
        upper = first_ge(p.ages,query,1,length(p.ages))
        p.ages[upper] == query || p.outer_mode != 0 ? upper : upper-1
    end
    lo = Int(p.offsets[curve]);hi = Int(p.offsets[curve+1])-1
    lo == hi && return 9999.0
    for index in lo:hi
        p.positions[index] > position && return Float64(p.positions[index])
    end
    return 9999.0
end

# GrowthEngineAMAP casts rtmaxetap to long and clamps to the source's
# hardcoded glmaxref=9999. Apply only in the explicitly native precision lane.
Science.maximum_reference_age(parameter::LegacyParameter,reference_age) =
    Float64(min(9999,trunc(Int,AMAPSim.valueat(parameter,reference_age))))

function compile_group(group)
    fields = getfield(group,:values)
    return AMAPSim.ParameterGroup(NamedTuple{keys(fields)}(map(compile_parameter,values(fields))))
end
function compile_lateral(lp)
    zones = map(z -> AMAPSim.LateralProductionZone(z.index,compile_group(z.branching)),lp.zones)
    return AMAPSim.LateralProductionParameters(lp.name,compile_group(lp.global_parameters),
        lp.branching_models,zones;organ_symbol=lp.organ_symbol)
end
function compile_parameters(parameters)
    Science.ensure_supported_initial_dormancy(parameters)
    a = parameters.axis
    axis = AMAPSim.AxisParameters(compile_group(a.topology),compile_group(a.differentiation),
        compile_group(a.growth),compile_group(a.geometry))
    first_lp = compile_lateral(first(parameters.lateral_productions))
    laterals = typeof(first_lp)[first_lp]
    for lp in Iterators.drop(parameters.lateral_productions,1)
        push!(laterals,compile_lateral(lp))
    end
    return AMAPSim.AMAPSimParameters(parameters.source,parameters.initialization,axis,laterals,parameters.legacy)
end
compile_parameters(fpa::AbstractString) = compile_parameters(AMAPSim.read_parameters(fpa))
end
