# SPDX-License-Identifier: LGPL-3.0-or-later
# Native geometry algorithms ported from AMAPsim (1995-2018),
# copyright Jean-Francois Barczi and AMAPsim contributors.
# Source: amapsim/thevitisnew/src/VitisModels/AmapSimMod/GeomBrancAMAP.cpp
# and VitisCore/{GeomBrancCone.cpp,Matrix.cpp,Vector.cpp,Include/UtilMath.h}.
# Original files license: GNU Lesser General Public License, version 3 or later.
# New native-arena integration by the AMAPSim.jl contributors; this header
# applies to this prototype file and does not relicense the surrounding package.
"""Analytic native-cone geometry over NativeAMAPPlantEngine's integer arenas.

All placement/bending uses raw Float32 native frames. No MTG geometry views,
PlantGeom instances, PSE status/registry or triangle materialization is used.
Per-axis native geometry draws can be supplied for exact cross-language replay.
"""
module NativeAMAPPlantGeometry
import AMAPSim
using Random
import ..NativeAMAPCore as Core
import ..NativeAMAPGeometryPrimitives as Primitives
import ..NativeAMAPGeometryScalars as Scalars
import ..NativeAMAPGeometryBending as Bending
import ..NativeAMAPPlantEngine as Engine
import ..NativeAMAPPlantEngine: geometry!

const V3 = NTuple{3,Float32}
const Frame = NTuple{3,V3}
const PI32 = Float32(π)
const TWO_PI32 = Float32(2π)
@inline value(p,args...) = AMAPSim.valueat(p,args...)
@inline add(a::V3,b::V3)::V3 = Core.add(a,b)
@inline scale(a::V3,s::Float32)::V3 = Core.scale(a,s)
@inline sub(a::V3,b::V3)::V3 = (a[1]-b[1],a[2]-b[2],a[3]-b[3])
@inline dot3(a::V3,b::V3)::Float32 = Primitives.dot3(a,b)
@inline unit(a::V3)::V3 = Primitives.unit(a)
@inline normalized(frame::Frame)::Frame = (unit(frame[1]),unit(frame[2]),unit(frame[3]))
@inline function guard(main::V3)::V3
    abs(main[1]) < 1e-4 && abs(main[2]) < 1e-4 ? (1.0f-4,main[2],main[3]) : main
end
@inline function secondary(main::V3,target::Float32)::V3
    return unit(Primitives.projection(main,(0.0f0,0.0f0,target)))
end
@inline function rotate(vector::V3,axis::V3,angle::Float32;vector_order=false)::V3
    vector_order && return Primitives.vector_rotation(axis,vector,angle,Val(:system_cexp))
    return matrix_vector(rotation_matrix(axis,angle),vector)
end
@inline function level(main::V3)::Frame
    transverse = secondary(main,1.0f0)
    normal = rotate(transverse,main,Float32(π/2);vector_order=true)
    return (main,transverse,normal)
end
@inline function matrix_vector(matrix::Frame,vector::V3)::V3
    # Qualified Matrix4 product initializes Y, then fuses X, Z and W.
    return ntuple(row -> fma(0.0f0,0.0f0,
        fma(vector[3],matrix[3][row],fma(vector[1],matrix[1][row],
        vector[2]*matrix[2][row]))),3)
end
@inline matrix_product(left::Frame,right::Frame)::Frame =
    ntuple(column -> matrix_vector(left,right[column]),3)
@inline function rotation_matrix(axis::V3,angle::Float32)::Frame
    matrix=Primitives.matrix_rotation(axis,angle,Val(:system_cexp))
    return ntuple(column -> ntuple(row -> matrix[4(row-1)+column],3),3)
end
@inline function bend(frame::Frame,angle::Float32)::Frame
    main = guard(frame[1])
    transverse = secondary(main,100.0f0)
    normal = rotate(transverse,main,Float32(π/2);vector_order=true)
    return level(rotate(main,normal,angle))
end
@inline wrapped(angle::Float32)::Float32 = Scalars.wrapped(angle)

function insertion_frame(reference::Frame,insertion::Float32,phyllotaxy::Float32,
    mode::Int,randomness::Float32,draw::Float32)::Frame
    mode in (1,4,5,6) || throw(ArgumentError("production native geometry supports modes 1,4,5,6"))
    main = guard(reference[1])
    ins = wrapped(insertion); phy = wrapped(phyllotaxy)
    ins,phy = Scalars.random_angles(ins,phy,randomness,draw)
    if mode == 4
        abs(ins) < 1.0e-5 && (ins = 1.0f-5)
        gravity=((0.0f0,-1.0f0,0.0f0),(1.0f0,0.0f0,0.0f0),(0.0f0,0.0f0,1.0f0))
        current=matrix_product(gravity,rotation_matrix(gravity[2],-ins))
        current=matrix_product(rotation_matrix(gravity[3],phy),current)
        return (current[3],current[1],current[2])
    elseif mode == 5
        vertical = clamp(unit(main)[3],-1.0f0,1.0f0)
        phy = Scalars.pseudo_plagiotropic_phyllotaxy(phy,vertical)
        current = level(main)
        axis = current[2]
        rotation = matrix_product(rotation_matrix(main,phy),rotation_matrix(axis,-ins))
        return matrix_product(rotation,current)
    end
    # Preserve C++ left association: (R_phyllotaxy * R_insertion) * frame.
    rotation = matrix_product(rotation_matrix(main,phy),rotation_matrix(reference[3],-ins))
    frame = matrix_product(rotation,reference)
    return mode == 6 ? level(frame[1]) : frame
end

@inline legacy_bending_target(young::Float32,dirz::Float32,length::Float32,conicity::Float32) =
    Bending.bending(young,dirz,length,conicity)

function attachment_base(bearer,child_frame::Frame,mode::Int,nominal_insertion::Float32)::V3
    if mode == 1 || nominal_insertion == 0
        # The source insertion guard mutates only this copied reference main.
        return add(bearer.base,scale(guard(bearer.frame[1]),bearer.length))
    end
    # GeomBrancCone::computeInsertTranslation projects with the original
    # raw bearer main, then adds 40% of the bearer top diameter radially.
    main = bearer.frame[1]
    radial = sub(child_frame[1],scale(main,dot3(child_frame[1],main)))
    radial = scale(unit(radial),bearer.diameter_top*0.4f0)
    return add(add(radial,scale(main,bearer.length)),bearer.base)
end

function projection(plant,axis,parameters=plant.parameters;
    observation_time=plant.last_event_time)
    gids = [id for id in axis.gu_ids if plant.growth_units[id].active]
    isempty(gids) && return (tests=0,growth_units=0)
    gu = plant.growth_units[last(gids)]
    actual = count(id -> plant.sites[id].active,axis.site_ids)
    count_gu = length(gids)
    projected = actual
    instant = Float32(gu.end_time)
    # Source Bud::getPhyAge retains the initial growth physiological age.
    # Projection uses the nominal rhythm, independently of a clipped GU end.
    duration = (1.0f0/Float32(axis.state.rhythm))/Float32(value(
        parameters.axis.growth.local_growth_rhythm,axis.initial_age))
    duration > 0 || throw(ArgumentError("geometry projection requires positive GU duration"))
    while instant < observation_time-1e-6
        projected += Int(gu.test_count)
        count_gu += 1
        instant += duration
    end
    return (tests=projected,growth_units=count_gu)
end

function insertion_angle(geometry,initial_age,first_gu_age,position)::Float32
    maximum=Float32(value(geometry.initial_organ_insertion_angle,initial_age))
    minimum=maximum*Float32(value(geometry.insertion_angle_variation_ratio,first_gu_age))
    lag=Float32(value(geometry.insertion_angle_variation_lag,first_gu_age))
    position > lag || return maximum
    stop=trunc(Int,value(geometry.insertion_angle_variation_zone,first_gu_age))
    return Scalars.reversed_linear(1,trunc(Int,lag),minimum,stop,maximum,trunc(Int,position))
end

function geometry_draw(draws,rng,axis_id,axis)
    if draws === nothing
        draw = 0.0
        for _ in 1:4
            draw = rand(rng)
        end
        return Float32(draw)
    end
    draw = draws isa Function ? draws(axis_id,axis) : draws[axis_id]
    isfinite(draw) && 0 <= draw <= 1 || throw(ArgumentError("geometry draw must lie in [0,1]"))
    return Float32(draw)
end

"""Full dimensions and analytic placement, with optional retained C++ axis draws."""
function geometry!(plant::Engine.NativePlant;geometry_draws=nothing,rng=Random.Xoshiro(0),
    geometry_parameters=nothing, dimension_provider=nothing, observation_times=nothing)
    parameters = geometry_parameters === nothing ? plant.parameters : geometry_parameters
    geometry = parameters.axis.geometry
    projections = [(tests=0,growth_units=0) for _ in plant.axes]
    # C++ geometry accumulates LP phase in Float32 and advances it AFTER
    # visiting branches on the current physical organ. Recompute this geometry
    # phase independently of the growth engine's Float64 scientific metadata.
    site_phases = fill((0.0f0,0.0f0,0.0f0),length(plant.sites))
    for (id,axis) in enumerate(plant.axes)
        axis.active || continue
        observation_time = observation_times === nothing ? plant.last_event_time : observation_times[id]
        projections[id] = projection(plant,axis,parameters; observation_time=observation_time)
        phases = (0.0f0,0.0f0,0.0f0)
        for organ_id in axis.organ_ids
            organ = plant.organs[organ_id]
            organ.active || continue
            site = plant.sites[organ.site]
            site_phases[organ.site] = phases
            for lp in eachindex(parameters.lateral_productions)
                step = Float32(value(parameters.lateral_productions[lp].global_parameters.phyllotaxy_angle,
                    site.reference_age+1.0))
                phases = Base.setindex(phases,phases[lp]+step,lp)
            end
        end
    end
    for (axis_id,axis) in enumerate(plant.axes)
        axis.active || continue
        ids = [id for id in axis.organ_ids if plant.organs[id].active]
        isempty(ids) && continue
        first_site = plant.sites[plant.organs[first(ids)].site]
        last_site = plant.sites[plant.organs[last(ids)].site]
        first_age = first_site.reference_age
        initial_age = axis.initial_age-1.0
        final_age = last_site.reference_age
        mode = trunc(Int,value(geometry.insertion_type,first_age))
        randomness = Float32(value(geometry.geometric_randomness_ratio,first_age))
        deviation = value(geometry.bearing_axis_deviation_angle,initial_age)
        deviation == 0 || throw(ArgumentError("native production geometry has not implemented bearer deviation"))
        draw = geometry_draw(geometry_draws,rng,axis_id,axis)
        if axis.parent == 0
            reference = Core.INITIAL_FRAME
            position = projections[axis_id].growth_units-2
            nominal_phase = 0.0f0
            bearer = nothing
        else
            bearer_site = plant.sites[axis.bearer_site]
            bearer_site.organ > 0 || throw(ArgumentError("native branch requires a realized bearer"))
            bearer = plant.organs[bearer_site.organ]
            reference = bearer.frame
            bearer_gu = plant.growth_units[bearer_site.gu]
            position = projections[axis.parent].growth_units-Int(bearer_gu.index)-1+
                (axis.branching_kind == 1 ? 1 : 0)
            lp = Int(axis.lateral_index)
            nominal_phase = Float32(plant.axes[axis.parent].initial_phyllotaxy)+
                site_phases[axis.bearer_site][lp]
            nominal_phase += TWO_PI32*Float32(axis.slot)/Float32(axis.whorl_size)
            nominal_phase += Float32(value(parameters.lateral_productions[lp].global_parameters.axillary_phase_angle,
                bearer_site.reference_age))
        end
        nominal_insertion = insertion_angle(geometry,initial_age,first_age,position)
        frame = insertion_frame(reference,nominal_insertion,nominal_phase,mode,randomness,draw)
        n = length(ids)
        young = Float32(value(geometry.young_modulus,initial_age))
        young > 0 || throw(ArgumentError("Young modulus must be positive"))
        conicity = Float32(value(geometry.conicity,first_age))/Float32(n)
        single = axis.nature == 2 && n == 1
        young_effective = axis.parent != 0 ? Scalars.young_effective(young,randomness,draw) : young
        target = legacy_bending_target(1.0f0/sqrt(young_effective),
            frame[1][3],Float32(n),conicity)
        if single
            organ_angle = Float32(value(geometry.organ_bending_angle,first_age))
            z = frame[1][3]
            bend_angle = organ_angle < 0 ? organ_angle*(z-1.0f0) : -organ_angle*(z+1.0f0)
            frame = bend(frame,bend_angle)
        end
        base = bearer === nothing ? Core.ZERO3 : attachment_base(bearer,frame,mode,nominal_insertion)
        actual_tests = count(id -> plant.sites[id].active,axis.site_ids)
        theoretical_tests = projections[axis_id].tests
        straight_angle = Float32(value(geometry.straightening_angle,final_age))
        straight_zone = Float32(value(geometry.straightening_zone,final_age))
        inflexion = Float32(value(geometry.bending_force_location_ratio,axis.initial_age))
        previous_diameter = 0.0f0
        previous_potential_diameter = 0.0f0
        terminal_increment = 0.0f0
        for (position_on_axis,organ_id) in enumerate(ids)
            organ = plant.organs[organ_id]
            site = plant.sites[organ.site]
            gu = plant.growth_units[site.gu]
            age = site.reference_age
            unit = trunc(Int,value(parameters.axis.topology.topology_counting_unit,age))
            unit == 0 || throw(ArgumentError("native production geometry currently requires GU counting"))
            base_kind = trunc(Int,value(parameters.axis.topology.topology_counting_base,age))
            direction = trunc(Int,value(geometry.geometry_counting_direction,age))
            index = base_kind == 0 ? Int(site.gu_test) : Int(site.gu_organ)
            total = base_kind == 0 ? Int(gu.test_count) : Int(gu.realized_count)
            topology_position = direction == 0 ? index-1 : total-index
            dimensions = AMAPSim.internode_dimensions(parameters,initial_age,age,
                topology_position,theoretical_tests-Int(site.axis_test))
            frame = normalized(frame)
            z = clamp(frame[1][3],-1.0f0,1.0f0)
            rank = position_on_axis-1
            if rank == 0
                denominator = min(Float32(theoretical_tests-Int(site.axis_test)),straight_zone)
                denominator == 0 && (denominator=1.0f0)
                terminal_increment = Bending.terminal_increment(z,straight_angle,denominator)
            elseif !single
                increment = Bending.flexion_increment(young,conicity,rank,z,target,
                    Int(max(1,gu.realized_count)))
                rank > trunc(Int,abs(inflexion)*n)-1 && (increment = -increment)
                distance = actual_tests-Int(site.axis_test)
                if straight_zone > 0 && distance <= straight_zone
                    if distance == straight_zone
                        terminal_increment = Bending.terminal_increment(z,straight_angle,straight_zone)
                    else
                        increment = terminal_increment
                    end
                end
                frame = bend(frame,-increment)
            end
            if dimension_provider === nothing
                organ.length = Float32(dimensions.length)
                organ.diameter_top = Float32(dimensions.diameter)
                organ.diameter_bottom = rank == 0 ? organ.diameter_top : previous_diameter
            else
                potential_top = Float32(dimensions.diameter)
                potential_bottom = rank == 0 ? potential_top : previous_potential_diameter
                actual = dimension_provider(organ_id, (length=Float32(dimensions.length),
                    diameter_top=potential_top, diameter_bottom=potential_bottom))
                all(value -> isfinite(value) && value >= 0,
                    (actual.length, actual.diameter_top, actual.diameter_bottom)) ||
                    throw(ArgumentError("realized organ dimensions must be finite and nonnegative"))
                organ.length = Float32(actual.length)
                organ.diameter_top = Float32(actual.diameter_top)
                organ.diameter_bottom = Float32(actual.diameter_bottom)
                all(isfinite, (organ.length, organ.diameter_top, organ.diameter_bottom)) ||
                    throw(ArgumentError("realized dimensions cannot be represented in native Float32"))
                previous_potential_diameter = potential_top
            end
            organ.frame = frame
            organ.base = base
            organ.tip = add(base,scale(frame[1],organ.length))
            previous_diameter = organ.diameter_top
            base = organ.tip
        end
    end
    plant.geometry_complete = true
    return plant
end
end
