"""Local organ dimensions in native length units; no physical-unit conversion is implied."""
struct OrganDimensions{T<:AbstractFloat}
    length::T
    diameter_top::T
    diameter_bottom::T
    function OrganDimensions{T}(length::T, diameter_top::T, diameter_bottom::T) where {T<:AbstractFloat}
        all(value -> isfinite(value) && value >= 0,
            (length, diameter_top, diameter_bottom)) || throw(ArgumentError(
            "organ dimensions must be finite and nonnegative"))
        return new{T}(length, diameter_top, diameter_bottom)
    end
end

function OrganDimensions(length::Real, diameter_top::Real, diameter_bottom::Real)
    values = promote(float(length), float(diameter_top), float(diameter_bottom))
    all(value -> isfinite(value) && value >= 0, values) || throw(ArgumentError(
        "organ dimensions must be finite and nonnegative"))
    return OrganDimensions{typeof(first(values))}(values...)
end

_zero_organ_dimensions() = OrganDimensions(0.0f0, 0.0f0, 0.0f0)
_dimension_values(dimensions::OrganDimensions) = (
    length=dimensions.length, diameter_top=dimensions.diameter_top,
    diameter_bottom=dimensions.diameter_bottom)

"""
    OrganGrowthState(Float64)

Per-plant coupled growth state. Native slots remain stable, including after
removal. `potential` records nominal AMAPSim allometry; `realized` and
`structural_mass_gDM` are committed by the selected growth model. New native
organs start with zero realized dimensions and mass. This deliberately permits
architectural initiation before construction and is not an organ-initiation
carbon threshold.

Carbon totals count construction expenditure and paid net-exchange losses
separately since start. Removed structural mass is a separate cumulative sink;
removal does not refund spent carbon.
"""
mutable struct OrganGrowthState{T<:AbstractFloat}
    potential::Vector{OrganDimensions{Float32}}
    realized::Vector{OrganDimensions{Float32}}
    structural_mass_gDM::Vector{T}
    active::BitVector
    removed_dry_mass_gDM::T
    revision::UInt64
    committed_revision::UInt64
    bank_initialized::Bool
    initial_reserve_gC::T
    credited_supply_gC::T
    spent_carbon_gC::T
    paid_carbon_loss_gC::T
    owned_plant::Any
    failed::Bool
end

function OrganGrowthState(::Type{T}=Float64) where {T<:AbstractFloat}
    return OrganGrowthState{T}(OrganDimensions{Float32}[], OrganDimensions{Float32}[],
        T[], falses(0), zero(T), UInt64(0), UInt64(0), false, zero(T), zero(T),
        zero(T), zero(T), nothing, false)
end

function _bind_organ_growth!(growth::OrganGrowthState, model)
    growth.failed && throw(ArgumentError(
        "coupled organ growth failed after mutation; discard this simulation"))
    growth.owned_plant === nothing || growth.owned_plant === model.plant ||
        throw(ArgumentError("an OrganGrowthState belongs to exactly one native plant"))
    growth.owned_plant = model.plant
    return nothing
end

function _synchronize_growth_slots!(growth::OrganGrowthState{T}, plant) where {T}
    while length(growth.active) < length(plant.organs)
        push!(growth.potential, _zero_organ_dimensions())
        push!(growth.realized, _zero_organ_dimensions())
        push!(growth.structural_mass_gDM, zero(T))
        push!(growth.active, false)
    end
    for (id, organ) in enumerate(plant.organs)
        if growth.active[id] && !organ.active
            removed = growth.removed_dry_mass_gDM + growth.structural_mass_gDM[id]
            isfinite(removed) || throw(ArgumentError("removed dry mass overflowed"))
            growth.removed_dry_mass_gDM = removed
            growth.structural_mass_gDM[id] = zero(T)
            growth.realized[id] = _zero_organ_dimensions()
            growth.potential[id] = _zero_organ_dimensions()
        end
        growth.active[id] = organ.active
    end
    return nothing
end

struct _CapturePotentialDimensions{S}
    state::S
end
function (provider::_CapturePotentialDimensions)(id, dimensions)
    provider.state.potential[id] = OrganDimensions(Float32(dimensions.length),
        Float32(dimensions.diameter_top), Float32(dimensions.diameter_bottom))
    return _dimension_values(provider.state.realized[id])
end

struct _RealizedDimensions{S}
    state::S
end
(provider::_RealizedDimensions)(id, _) = _dimension_values(provider.state.realized[id])

function _project_growth_dimensions!(growth::OrganGrowthState, model, provider;
    observation_times=nothing)
    NativeAMAPPlantEngine.geometry!(model.plant;
        geometry_parameters=model.geometry_parameters,
        geometry_draws=NativeAMAPLegacyRNG.geometry_draws(model.plant),
        dimension_provider=provider, observation_times=observation_times)
    return model
end

"""Refresh nominal targets while preserving the currently realized geometry."""
function refresh_potential!(growth::OrganGrowthState, model; observation_times=nothing)
    _bind_organ_growth!(growth, model)
    growth.failed = true
    _synchronize_growth_slots!(growth, model.plant)
    _project_growth_dimensions!(growth, model, _CapturePotentialDimensions(growth);
        observation_times=observation_times)
    growth.revision += UInt64(1)
    growth.failed = false
    return growth
end

"""Recompute placement from committed dimensions without overwriting potential targets."""
function project_realized!(growth::OrganGrowthState, model; observation_times=nothing)
    _bind_organ_growth!(growth, model)
    growth.failed = true
    _synchronize_growth_slots!(growth, model.plant)
    _project_growth_dimensions!(growth, model, _RealizedDimensions(growth);
        observation_times=observation_times)
    growth.failed = false
    return growth
end

"""Explicit geometry-only coupled mode: use nominal dimensions, without a biomass law."""
function copy_potential_to_realized!(growth::OrganGrowthState, model; observation_times=nothing)
    _bind_organ_growth!(growth, model)
    growth.realized .= growth.potential
    return project_realized!(growth, model; observation_times=observation_times)
end
