"""
    cut_axis!(model::NativeModel, axis_id; development=nothing,
        organ_growth=nothing, geometry=true)

Remove a complete native axis and its descendants at an exchange boundary.
Arena identities are never reused. Pending botanical events are invalidated by
the native generation mechanism. Existing construction carbon is not refunded;
an optional organ-growth state records removed structural mass separately.
This command neither models remobilization nor induces a calibrated regrowth law.
"""
function cut_axis!(model::NativeModel, axis_id::Integer; development=nothing,
    organ_growth=nothing, geometry::Bool=true)
    axis_id isa Bool && throw(ArgumentError("axis_id must be a native axis index"))
    1 <= axis_id <= length(model.plant.axes) || throw(ArgumentError(
        "axis_id must identify an existing native axis"))
    if development !== nothing
        development.running && throw(ArgumentError(
            "management cuts must occur between native development advances"))
        development.failed && throw(ArgumentError(
            "discard a failed local-development simulation before further commands"))
        _bind_local_development!(development, model)
    end
    organ_growth === nothing || !organ_growth.failed || throw(ArgumentError(
        "discard a failed organ-growth simulation before further commands"))
    organ_growth === nothing || _bind_organ_growth!(organ_growth, model)
    active = model.plant.axes[axis_id].active
    active || return (removed=false, axis_id=Int(axis_id))
    NativeAMAPPlantEngine.remove_axis!(model.plant, axis_id)
    # The coupled scheduler drops obsolete actions immediately. Ordinary
    # reference-mode pruning keeps its historical lazy cancellation behavior.
    development === nothing || _discard_stale_local_events!(development, model)
    model.plant.geometry_complete = false
    times = development === nothing ? nothing :
        development_observation_times(development, model)
    if organ_growth !== nothing
        refresh_potential!(organ_growth, model; observation_times=times)
    elseif geometry
        geometry!(model; observation_times=times)
    end
    return (removed=true, axis_id=Int(axis_id))
end
