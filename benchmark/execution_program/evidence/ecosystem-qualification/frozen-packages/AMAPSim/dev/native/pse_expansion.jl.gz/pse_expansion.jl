# Ordinary plant-level PSE models. They exchange typed batches once per coupling
# step; no framework call is made inside the native organ/event loop.
const _ORGAN_DEMAND_BATCH_CONTRACT = PSE.VariableContract(unit=:organ_growth_demand,
    basis=:organ, temporal=:step, aggregation=:state, extent=:extensive)
const _ORGAN_ALLOCATION_BATCH_CONTRACT = PSE.VariableContract(unit=:organ_growth_allocation,
    basis=:organ, temporal=:step, aggregation=:state, extent=:extensive)
const _DRY_MASS_CONTRACT = PSE.VariableContract(unit=:g_dry_matter,
    basis=:plant, temporal=:instantaneous, aggregation=:state, extent=:extensive)
const _REMOVED_DRY_MASS_CONTRACT = PSE.VariableContract(unit=:g_dry_matter,
    basis=:plant, temporal=:since_start, aggregation=:total, extent=:extensive)
const ORGAN_TARGET_MASS_CONTRACT = PSE.VariableContract(unit=:g_dry_matter,
    basis=:organ, temporal=:instantaneous, aggregation=:state, extent=:extensive)
const ORGAN_CONSTRUCTION_COST_CONTRACT = PSE.VariableContract(unit=:g_carbon_per_g_dry_matter,
    basis=:organ, temporal=:instantaneous, aggregation=:state, extent=:intensive)
const ORGAN_GROWTH_ID_CONTRACT = PSE.VariableContract(unit=:native_organ_id,
    basis=:organ, temporal=:instantaneous, aggregation=:state, extent=:intensive)

struct OrganGrowthDemand{T<:AbstractFloat}
    organ_id::Int32
    current_mass_gDM::T
    target_mass_gDM::T
    increment_gDM::T
    construction_cost_gC_per_gDM::T
    carbon_gC::T
    target_dimensions::NativeAMAP.OrganDimensions{Float32}
end

struct OrganDemandBatch{T<:AbstractFloat}
    plant_id::PSE.ObjectId
    revision::UInt64
    rows::Vector{OrganGrowthDemand{T}}
end

struct AllocatedOrganGrowth{T<:AbstractFloat}
    demand::OrganGrowthDemand{T}
    increment_gDM::T
    carbon_gC::T
end

struct OrganAllocationBatch{T<:AbstractFloat}
    plant_id::PSE.ObjectId
    revision::UInt64
    initial_reserve_gC::T
    cumulative_supply_gC::T
    cumulative_loss_gC::T
    paid_loss_before_gC::T
    spent_before_gC::T
    spent_after_gC::T
    rows::Vector{AllocatedOrganGrowth{T}}
end

# Preserve the original construction-only quote interface. Its zero-loss
# proposal is rejected if a plant has already paid nonzero exchange losses.
OrganAllocationBatch(plant_id, revision, reserve::T, supply::T, spent_before::T,
    spent_after::T, rows::Vector{AllocatedOrganGrowth{T}}) where {T<:AbstractFloat} =
    OrganAllocationBatch(plant_id, revision, reserve, supply, zero(T), zero(T),
        spent_before, spent_after, rows)

_empty_organ_demands(::Type{T}) where {T} = OrganDemandBatch(
    PSE.ObjectId(:_unassigned_native_growth), UInt64(0), OrganGrowthDemand{T}[])
_empty_organ_allocations(::Type{T}, reserve) where {T} = OrganAllocationBatch(
    PSE.ObjectId(:_unassigned_native_growth), UInt64(0), T(reserve), zero(T),
    zero(T), zero(T), AllocatedOrganGrowth{T}[])

"""
    FrustumGrowthDemand(; density_gDM_per_cm3,
        construction_cost_gC_per_gDM, cm_per_native_unit)

Illustrative solid-frustum construction demand, not a calibrated biomass law.
Both native diameters and length are converted to cm explicitly. The supplied
density is gDM/cm³ and the construction cost is integrated gC/gDM. Demand is
the positive difference between the current potential target mass and already
committed structural mass. A smaller target does not destroy existing tissue.
No leaf area, hollow tissue, maintenance or respiration conversion is inferred.
"""
struct FrustumGrowthDemand{T<:AbstractFloat} <: PSE.Examples.AbstractCarbon_DemandModel
    density_gDM_per_cm3::T
    construction_cost_gC_per_gDM::T
    cm_per_native_unit::T
end

function FrustumGrowthDemand(; density_gDM_per_cm3,
    construction_cost_gC_per_gDM, cm_per_native_unit)
    density = _nonnegative_carbon(density_gDM_per_cm3, "density_gDM_per_cm3")
    density > 0 || throw(ArgumentError("density_gDM_per_cm3 must be positive"))
    cost = _nonnegative_carbon(construction_cost_gC_per_gDM,
        "construction_cost_gC_per_gDM")
    scale = _nonnegative_carbon(cm_per_native_unit, "cm_per_native_unit")
    scale > 0 || throw(ArgumentError("cm_per_native_unit must be positive"))
    density, cost, scale = promote(float(density), float(cost), float(scale))
    return FrustumGrowthDemand(density, cost, scale)
end
_growth_numeric_type(::FrustumGrowthDemand{T}) where {T} = T

PSE.inputs_(::FrustumGrowthDemand) = (
    _native_pse_state=PSE.Required(NativePSEState),
    native_revision=PSE.Required(Integer))
PSE.outputs_(::FrustumGrowthDemand{T}) where {T} = (
    growth_demands=_empty_organ_demands(T),)
PSE.variable_contracts_(::FrustumGrowthDemand) = (
    growth_demands=_ORGAN_DEMAND_BATCH_CONTRACT,)

function _coupled_growth_state(state, ::Type{T}) where {T}
    growth = state.organ_growth
    growth isa NativeAMAP.OrganGrowthState{T} || throw(ArgumentError(
        "coupled growth state and demand/allocation/expansion models must use the same numeric type $T"))
    growth.failed && throw(ArgumentError(
        "coupled organ growth failed after mutation; discard this simulation"))
    growth.owned_plant === state.native.plant || throw(ArgumentError(
        "coupled growth state belongs to a different native plant"))
    return growth
end

function _growth_product(::Type{T}, first, second, label) where {T}
    result = first * second
    _nonnegative_carbon(result, label)
    first > 0 && second > 0 && iszero(result) && throw(ArgumentError(
        "$label underflows in $T"))
    return result
end

"""Volume of a solid frustum in cm³; dimensions remain native until conversion."""
function potential_frustum_volume(model::FrustumGrowthDemand{T}, dimensions) where {T}
    length = T(dimensions.length) * model.cm_per_native_unit
    top = T(dimensions.diameter_top) * model.cm_per_native_unit
    bottom = T(dimensions.diameter_bottom) * model.cm_per_native_unit
    volume = T(pi) / T(12) * length * (top * top + top * bottom + bottom * bottom)
    dimensions.length > 0 &&
        (dimensions.diameter_top > 0 || dimensions.diameter_bottom > 0) &&
        iszero(volume) && throw(ArgumentError("potential frustum volume underflows in $T"))
    return _nonnegative_carbon(volume, "potential frustum volume_cm3")
end

function PSE.run!(model::FrustumGrowthDemand{T}, status, environment, constants, context) where {T}
    state = getproperty(status, _STATE)
    growth = _coupled_growth_state(state, T)
    rows = OrganGrowthDemand{T}[]
    sizehint!(rows, length(growth.active))
    for id in eachindex(growth.active)
        growth.active[id] || continue
        dimensions = growth.potential[id]
        volume = potential_frustum_volume(model, dimensions)
        target = _growth_product(T, volume, model.density_gDM_per_cm3,
            "potential structural mass_gDM")
        current = growth.structural_mass_gDM[id]
        increment = max(zero(T), target - current)
        iszero(increment) && continue
        carbon = _growth_product(T, increment, model.construction_cost_gC_per_gDM,
            "incremental construction carbon_gC")
        push!(rows, OrganGrowthDemand(Int32(id), current, target, increment,
            model.construction_cost_gC_per_gDM, carbon, dimensions))
    end
    status.growth_demands = OrganDemandBatch(state.plant_id, growth.revision, rows)
    return nothing
end

"""
    OrganDemandCollector(Float64)

Collect organ-scale PSE model outputs into the plant allocation interface.
Bind `native_ids`, `target_masses_gDM` and `construction_costs_gC_per_gDM`
through identical plant-scoped `Many` selectors on the same source application.
The source can use any scientific demand hypothesis; this bridge subtracts
committed native structural mass and orders the resulting requests by native
organ slot. It does not create extra organ Objects or infer missing targets.

An organ source can copy the native publisher's `native_id` input to its own
`organ_growth_id` output. This avoids claiming canonical ownership of the
publisher's ID. Only selected source organs receive construction requests.
"""
struct OrganDemandCollector{T<:AbstractFloat} <: PSE.Examples.AbstractCarbon_DemandModel end
OrganDemandCollector(::Type{T}=Float64) where {T<:AbstractFloat} = OrganDemandCollector{T}()
_growth_numeric_type(::OrganDemandCollector{T}) where {T} = T
PSE.inputs_(::OrganDemandCollector) = (
    _native_pse_state=PSE.Required(NativePSEState),
    native_revision=PSE.Required(Integer),
    native_ids=PSE.Required(AbstractVector),
    target_masses_gDM=PSE.Required(AbstractVector),
    construction_costs_gC_per_gDM=PSE.Required(AbstractVector))
PSE.outputs_(::OrganDemandCollector{T}) where {T} = (
    growth_demands=_empty_organ_demands(T),)
PSE.variable_contracts_(::OrganDemandCollector) = (
    native_ids=ORGAN_GROWTH_ID_CONTRACT,
    target_masses_gDM=ORGAN_TARGET_MASS_CONTRACT,
    construction_costs_gC_per_gDM=ORGAN_CONSTRUCTION_COST_CONTRACT,
    growth_demands=_ORGAN_DEMAND_BATCH_CONTRACT)

function PSE.run!(::OrganDemandCollector{T}, status, environment, constants, context) where {T}
    state = getproperty(status, _STATE)
    growth = _coupled_growth_state(state, T)
    ids = status.native_ids
    targets = status.target_masses_gDM
    costs = status.construction_costs_gC_per_gDM
    length(ids) == length(targets) == length(costs) || throw(ArgumentError(
        "organ demand columns must have equal lengths and matching source selectors"))
    records = Tuple{Int,T,T}[]
    seen = Set{Int}()
    for index in eachindex(ids)
        id = ids[index]
        id isa Integer && !(id isa Bool) && 1 <= id <= length(growth.active) ||
            throw(ArgumentError("organ demand ID must identify an existing native organ slot"))
        id = Int(id)
        growth.active[id] && state.native.plant.organs[id].active || throw(ArgumentError(
            "organ demand source identifies a removed native organ"))
        id in seen && throw(ArgumentError("organ demand columns contain a duplicate native ID"))
        push!(seen, id)
        target = _carbon_in_type(T, targets[index], "potential organ mass_gDM")
        cost = _carbon_in_type(T, costs[index], "organ construction cost_gC_per_gDM")
        push!(records, (id, target, cost))
    end
    sort!(records; by=first)
    rows = OrganGrowthDemand{T}[]
    sizehint!(rows, length(records))
    for (id, target, cost) in records
        current = growth.structural_mass_gDM[id]
        increment = max(zero(T), target-current)
        iszero(increment) && continue
        carbon = _growth_product(T, increment, cost, "organ construction demand_gC")
        push!(rows, OrganGrowthDemand(Int32(id), current, target, increment, cost,
            carbon, growth.potential[id]))
    end
    status.growth_demands = OrganDemandBatch(state.plant_id, growth.revision, rows)
    return nothing
end

"""
    SequentialGrowthAllocation(; initial_reserve_gC)

Quote incremental construction in native slot order. Each positive-cost sink
can receive partial funding; zero-cost sinks receive their full requested mass.
This is an explicit priority hypothesis. Quoting changes no bank or organ.
The expansion application settles the validated quote after native geometry
has been updated successfully. This construction-only model reads cumulative
integrated supply in gC since start. The optional physiology allocation model
also quotes signed-exchange losses through the shared ledger; those losses
are paid before construction, without implicit debt or remobilization.
"""
struct SequentialGrowthAllocation{T<:AbstractFloat} <: PSE.Examples.AbstractCarbon_AllocationModel
    initial_reserve_gC::T
end
function SequentialGrowthAllocation(; initial_reserve_gC)
    reserve = float(_nonnegative_carbon(initial_reserve_gC, "initial_reserve_gC"))
    return SequentialGrowthAllocation(reserve)
end
_growth_numeric_type(::SequentialGrowthAllocation{T}) where {T} = T

PSE.inputs_(::SequentialGrowthAllocation{T}) where {T} = (
    _native_pse_state=PSE.Required(NativePSEState),
    growth_demands=PSE.Required(OrganDemandBatch{T}))
PSE.environment_inputs_(model::SequentialGrowthAllocation) = (
    cumulative_carbon_supply_gC=zero(model.initial_reserve_gC),)
PSE.outputs_(model::SequentialGrowthAllocation{T}) where {T} = (
    growth_allocation=_empty_organ_allocations(T, model.initial_reserve_gC),)
PSE.variable_contracts_(::SequentialGrowthAllocation) = (
    growth_demands=_ORGAN_DEMAND_BATCH_CONTRACT,
    growth_allocation=_ORGAN_ALLOCATION_BATCH_CONTRACT,
    cumulative_carbon_supply_gC=_CUMULATIVE_CARBON_CONTRACT)

function _validate_growth_demand(row::OrganGrowthDemand{T}, growth) where {T}
    id = Int(row.organ_id)
    1 <= id <= length(growth.active) && growth.active[id] || throw(ArgumentError(
        "growth demand targets a missing or removed native organ"))
    growth.owned_plant.organs[id].active || throw(ArgumentError(
        "growth demand targets a natively removed organ"))
    row.target_dimensions == growth.potential[id] || throw(ArgumentError(
        "growth demand no longer matches the potential dimensions"))
    row.current_mass_gDM == growth.structural_mass_gDM[id] || throw(ArgumentError(
        "growth demand no longer matches committed structural mass"))
    for (label, value) in (("current mass", row.current_mass_gDM),
        ("target mass", row.target_mass_gDM), ("mass increment", row.increment_gDM),
        ("construction cost", row.construction_cost_gC_per_gDM), ("carbon demand", row.carbon_gC))
        _nonnegative_carbon(value, label)
    end
    row.increment_gDM == max(zero(T), row.target_mass_gDM - row.current_mass_gDM) ||
        throw(ArgumentError("growth demand has inconsistent target and increment"))
    row.carbon_gC == _growth_product(T, row.increment_gDM,
        row.construction_cost_gC_per_gDM, "quoted construction carbon") ||
        throw(ArgumentError("growth demand has inconsistent construction carbon"))
    return id
end

function PSE.run!(model::SequentialGrowthAllocation{T}, status, environment, constants, context) where {T}
    state = getproperty(status, _STATE)
    status.growth_allocation = _quote_growth_allocation(state, status.growth_demands,
        model.initial_reserve_gC, environment.cumulative_carbon_supply_gC)
    return nothing
end

function _quote_growth_allocation(state::NativePSEState, demands::OrganDemandBatch{T},
    initial_reserve, cumulative_supply, cumulative_loss=zero(T)) where {T}
    growth = _coupled_growth_state(state, T)
    reserve = _carbon_in_type(T, initial_reserve, "initial_reserve_gC")
    demands.plant_id == state.plant_id && demands.revision == growth.revision ||
        throw(ArgumentError("growth demand belongs to a different plant or revision"))
    !growth.bank_initialized || reserve == growth.initial_reserve_gC ||
        throw(ArgumentError("initial reserve cannot change after growth settlement"))
    supply = _carbon_in_type(T, cumulative_supply,
        "cumulative_carbon_supply_gC")
    supply >= growth.credited_supply_gC || throw(ArgumentError(
        "cumulative_carbon_supply_gC cannot decrease"))
    loss = _carbon_in_type(T, cumulative_loss, "cumulative_carbon_loss_gC")
    loss >= growth.paid_carbon_loss_gC || throw(ArgumentError(
        "cumulative_carbon_loss_gC cannot decrease"))
    total = _nonnegative_carbon(reserve + supply, "total supplied carbon")
    loss <= total || throw(ArgumentError("net-exchange losses exceed supplied carbon"))
    budget = total - loss
    spent = growth.spent_carbon_gC
    spent <= budget || throw(ArgumentError("committed carbon exceeds total supplied carbon"))
    rows = AllocatedOrganGrowth{T}[]
    seen = Set{Int32}()
    for demand in demands.rows
        _validate_growth_demand(demand, growth)
        demand.organ_id in seen && throw(ArgumentError("duplicate organ in growth demand"))
        push!(seen, demand.organ_id)
        cost = demand.construction_cost_gC_per_gDM
        available = max(zero(T), budget - spent)
        mass = iszero(cost) ? demand.increment_gDM :
            min(demand.increment_gDM, available / cost)
        carbon = _nonnegative_carbon(mass * cost, "allocated construction carbon")
        # Division and subsequent multiplication can round a partial quote up
        # by one ulp. Lower the mass rather than overdrawing the carbon bank.
        attempts = 0
        while spent + carbon > budget
            mass = prevfloat(mass)
            mass >= 0 && attempts < 8 || throw(ArgumentError(
                "partial growth allocation cannot be represented conservatively"))
            carbon = mass * cost
            attempts += 1
        end
        spent = _nonnegative_carbon(spent + carbon, "cumulative construction carbon")
        push!(rows, AllocatedOrganGrowth(demand, mass, carbon))
    end
    return OrganAllocationBatch(state.plant_id, growth.revision,
        reserve, supply, loss, growth.paid_carbon_loss_gC,
        growth.spent_carbon_gC, spent, rows)
end

"""
    IsometricExpansion(Float64)

Realize an allocated structural mass by scaling the current potential frustum
shape isotropically. A potential target below existing mass does not shrink or
refund that tissue. During positive growth, changed potential aspect ratios
can change individual dimensions; this illustrative law is replaceable.
Native displayed dimensions use Float32, so mass/volume agreement has that
rounding precision. It is not a calibrated elongation/thickening model.
"""
struct IsometricExpansion{T<:AbstractFloat} <: PSE.Examples.AbstractGrowthModel end
IsometricExpansion(::Type{T}=Float64) where {T<:AbstractFloat} = IsometricExpansion{T}()
_growth_numeric_type(::IsometricExpansion{T}) where {T} = T

PSE.inputs_(::IsometricExpansion{T}) where {T} = (
    _native_pse_state=PSE.Required(NativePSEState),
    native_revision=PSE.Required(Integer),
    growth_allocation=PSE.Required(OrganAllocationBatch{T}))
PSE.outputs_(::IsometricExpansion{T}) where {T} = (
    actual_geometry_revision=0, remaining_carbon_gC=zero(T), spent_carbon_gC=zero(T),
    credited_carbon_supply_gC=zero(T), paid_carbon_loss_gC=zero(T),
    living_dry_mass_gDM=zero(T),
    removed_dry_mass_gDM=zero(T), realized_organ_count=0)
PSE.variable_contracts_(::IsometricExpansion) = (
    growth_allocation=_ORGAN_ALLOCATION_BATCH_CONTRACT,
    remaining_carbon_gC=_CARBON_RESERVE_CONTRACT,
    spent_carbon_gC=_CUMULATIVE_CARBON_CONTRACT,
    credited_carbon_supply_gC=_CUMULATIVE_CARBON_CONTRACT,
    paid_carbon_loss_gC=_CUMULATIVE_CARBON_CONTRACT,
    living_dry_mass_gDM=_DRY_MASS_CONTRACT,
    removed_dry_mass_gDM=_REMOVED_DRY_MASS_CONTRACT)

function _expanded_dimensions(dimensions, mass, target)
    scale = cbrt(min(one(mass), mass / target))
    return NativeAMAP.OrganDimensions(dimensions.length * scale,
        dimensions.diameter_top * scale, dimensions.diameter_bottom * scale)
end

struct _IsometricDimensionLaw end
(::_IsometricDimensionLaw)(demand, mass, previous_dimensions) =
    _expanded_dimensions(demand.target_dimensions, mass, demand.target_mass_gDM)

"""
    realize_growth!(native_state, allocation, dimension_law)

Validate and settle a per-plant allocation through a replaceable dimension law.
The callable receives immutable `(demand, new_mass_gDM, previous_dimensions)`
for each positive increment and returns dimensions in native length units.
It receives no RNG or native arena. All returned dimensions and every ledger
row are validated before mutation; failed geometric placement poisons growth.

This shared transaction permits another PSE expansion model to reuse lifecycle
and carbon accounting while supplying its own elongation/thickening hypothesis.
That model must publish the returned scalar balance and a new
`actual_geometry_revision`. Consistency of its shape law with its chosen mass
and density law is the model author's scientific responsibility.
"""
function realize_growth!(state::NativePSEState, allocation::OrganAllocationBatch{T},
    dimension_law) where {T}
    growth = _coupled_growth_state(state, T)
    allocation.plant_id == state.plant_id && allocation.revision == growth.revision ||
        throw(ArgumentError("growth allocation belongs to a different plant or revision"))
    allocation.revision > growth.committed_revision || throw(ArgumentError(
        "growth revision was already settled"))
    allocation.spent_before_gC == growth.spent_carbon_gC || throw(ArgumentError(
        "growth allocation no longer matches the carbon bank"))
    allocation.paid_loss_before_gC == growth.paid_carbon_loss_gC || throw(ArgumentError(
        "growth allocation no longer matches the paid exchange losses"))
    !growth.bank_initialized || allocation.initial_reserve_gC == growth.initial_reserve_gC ||
        throw(ArgumentError("growth allocation changed the initial reserve"))
    for (label, value) in (("initial reserve", allocation.initial_reserve_gC),
        ("cumulative supply", allocation.cumulative_supply_gC),
        ("cumulative loss", allocation.cumulative_loss_gC),
        ("paid loss before", allocation.paid_loss_before_gC),
        ("spent before", allocation.spent_before_gC), ("spent after", allocation.spent_after_gC))
        _nonnegative_carbon(value, label)
    end
    allocation.cumulative_supply_gC >= growth.credited_supply_gC || throw(ArgumentError(
        "cumulative supply cannot decrease during growth settlement"))
    allocation.cumulative_loss_gC >= growth.paid_carbon_loss_gC || throw(ArgumentError(
        "cumulative loss cannot decrease during growth settlement"))
    total = _nonnegative_carbon(allocation.initial_reserve_gC +
        allocation.cumulative_supply_gC, "total supplied carbon")
    allocation.cumulative_loss_gC <= total || throw(ArgumentError(
        "net-exchange losses exceed supplied carbon"))
    budget = total - allocation.cumulative_loss_gC
    growth.spent_carbon_gC <= budget || throw(ArgumentError(
        "net-exchange losses exceed reserve after committed construction"))
    next_dimensions = copy(growth.realized)
    next_mass = copy(growth.structural_mass_gDM)
    spent = growth.spent_carbon_gC
    seen = Set{Int32}()
    for row in allocation.rows
        demand = row.demand
        id = _validate_growth_demand(demand, growth)
        demand.organ_id in seen && throw(ArgumentError("duplicate organ in growth allocation"))
        push!(seen, demand.organ_id)
        _nonnegative_carbon(row.increment_gDM, "allocated mass increment")
        _nonnegative_carbon(row.carbon_gC, "allocated carbon")
        row.increment_gDM <= demand.increment_gDM || throw(ArgumentError(
            "allocated growth exceeds requested mass"))
        row.carbon_gC == row.increment_gDM * demand.construction_cost_gC_per_gDM ||
            throw(ArgumentError("allocated mass and construction carbon disagree"))
        mass = _nonnegative_carbon(demand.current_mass_gDM + row.increment_gDM,
            "realized structural mass")
        next_mass[id] = mass
        if row.increment_gDM > 0
            demand.target_mass_gDM > 0 || throw(ArgumentError("positive growth needs a positive target"))
            actual = dimension_law(demand, mass, growth.realized[id])
            raw = (actual.length, actual.diameter_top, actual.diameter_bottom)
            all(value -> value isa Real && isfinite(value) && value >= 0, raw) ||
                throw(ArgumentError("expansion law returned invalid dimensions"))
            typed = Float32.(raw)
            any(index -> raw[index] > 0 && iszero(typed[index]), eachindex(raw)) &&
                throw(ArgumentError("expansion dimensions underflow native Float32"))
            next_dimensions[id] = NativeAMAP.OrganDimensions(typed...)
        end
        spent = _nonnegative_carbon(spent + row.carbon_gC, "settled construction carbon")
        spent <= budget || throw(ArgumentError("growth settlement overdraws carbon"))
    end
    spent == allocation.spent_after_gC || throw(ArgumentError(
        "growth allocation total disagrees with its organ rows"))
    living_mass = _nonnegative_carbon(sum(next_mass; init=zero(T)),
        "total living structural mass")
    observation_times = state.development === nothing ? nothing :
        NativeAMAP.development_observation_times(state.development, state.native)
    # Validate the complete proposal before mutation. A subsequent projection
    # error poisons this state rather than permitting a partially committed retry.
    growth.failed = true
    growth.realized .= next_dimensions
    growth.structural_mass_gDM .= next_mass
    growth.failed = false
    NativeAMAP.project_realized!(growth, state.native; observation_times=observation_times)
    growth.initial_reserve_gC = allocation.initial_reserve_gC
    growth.credited_supply_gC = allocation.cumulative_supply_gC
    growth.spent_carbon_gC = spent
    growth.paid_carbon_loss_gC = allocation.cumulative_loss_gC
    growth.bank_initialized = true
    growth.committed_revision = allocation.revision
    return (remaining_carbon_gC=budget-spent, spent_carbon_gC=spent,
        credited_carbon_supply_gC=allocation.cumulative_supply_gC,
        paid_carbon_loss_gC=allocation.cumulative_loss_gC,
        living_dry_mass_gDM=living_mass,
        removed_dry_mass_gDM=growth.removed_dry_mass_gDM,
        realized_organ_count=count(>(zero(T)), growth.structural_mass_gDM))
end

function PSE.run!(::IsometricExpansion, status, environment, constants, context)
    result = realize_growth!(getproperty(status, _STATE), status.growth_allocation,
        _IsometricDimensionLaw())
    for name in keys(result)
        setproperty!(status, name, getproperty(result, name))
    end
    status.actual_geometry_revision += 1
    return nothing
end
