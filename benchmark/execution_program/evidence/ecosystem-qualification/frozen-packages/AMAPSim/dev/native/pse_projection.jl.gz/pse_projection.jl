# Construction and selective projection only. Native computational files are
# deliberately not included or modified here.

_criterion(c, name, default=nothing) = haskey(c, name) ? getproperty(c, name) : default
_matches(value, requested) = isnothing(requested) ||
    (requested isa Tuple ? value in requested : value == requested)

function _scope(selector)
    c = selector.criteria
    positional = nothing
    for atom in c.selectors
        atom isa Union{PSE.SceneScope,PSE.Scope,PSE.Self,PSE.Subtree,PSE.SelfPlant,PSE.Ancestor} ||
            throw(ArgumentError("unsupported native projection selector atom $(repr(atom))"))
        isnothing(positional) || positional == atom || throw(ArgumentError(
            "multiple native projection selector scopes are ambiguous"))
        positional = atom
    end
    keyword = _criterion(c, :within)
    !isnothing(keyword) && !isnothing(positional) && keyword != positional &&
        throw(ArgumentError("conflicting native projection selector scopes"))
    return isnothing(keyword) ? positional : keyword
end

function _plant_in_scope(model, selector, plant_id; source_context=false)
    scope = _scope(selector)
    isnothing(scope) && return true
    scope isa PSE.SceneScope && return true
    # Relative input bindings are checked in the current plant's subtree. The
    # application-target grammar itself allows only scene and named scopes.
    source_context && scope isa Union{PSE.Self,PSE.Subtree,PSE.SelfPlant} && return true
    scope isa PSE.Scope || throw(ArgumentError(
        "native projection supports scene/plant/instance scopes; unsupported scope $(repr(scope))"))
    ids = try
        PSE.resolve_object_ids(model, PSE.Many(scope))
    catch error
        throw(ArgumentError("native projection scope $(repr(scope)) must resolve to an existing scene, plant, or instance root: $(sprint(showerror, error))"))
    end
    root = scope.root
    if root isa Symbol
        for instance in model.instances
            instance.name == root || continue
            root = instance.root isa PSE.Object ? instance.root.id : PSE.ObjectId(instance.root)
            break
        end
    end
    root_object = PSE.model_object(model, root)
    root_object.scale in (:Scene, :Plant) || throw(ArgumentError(
        "native projection does not support scopes rooted below a plant; select its plant/instance scope explicitly"))
    return plant_id in ids
end

function _selector_labels_match(selector, mapping, plant)
    c = selector.criteria
    return _matches(mapping.scale, _criterion(c, :scale)) &&
        _matches(mapping.kind, _criterion(c, :kind)) &&
        _matches(plant.species, _criterion(c, :species))
end

function _selector_ids(selector, plant_id, symbol)
    requested = _criterion(selector.criteria, :id)
    isnothing(requested) && return nothing
    ids = requested isa Tuple ? requested : (requested,)
    selected = Set{PSE.ObjectId}()
    for id in ids
        value = id.value
        value isa Tuple && length(value) == 3 || continue
        value[1] == plant_id.value && value[2] == symbol || continue
        value[3] isa Integer && value[3] > 0 || throw(ArgumentError(
            "native object IDs require a positive arena slot"))
        push!(selected, id)
    end
    return selected
end

function _mappings(scales)
    result = _Mapping[]
    for (symbol_, declaration) in pairs(scales)
        symbol = Symbol(symbol_)
        if declaration isa Union{Symbol,AbstractString}
            scale = Symbol(declaration)
            kind = symbol === :GrowthUnit ? :growth_unit : Symbol(lowercase(String(symbol)))
        elseif declaration isa NamedTuple && haskey(declaration, :scale)
            extra = setdiff(keys(declaration), (:scale, :kind))
            isempty(extra) || throw(ArgumentError("unsupported native scale mapping keys $(Tuple(extra))"))
            scale = Symbol(declaration.scale)
            kind = Symbol(get(declaration, :kind,
                symbol === :GrowthUnit ? :growth_unit : Symbol(lowercase(String(symbol)))))
        else
            throw(ArgumentError("native scale mappings require a scale Symbol or (scale=..., kind=...)"))
        end
        scale in (:Scene, :Plant) && throw(ArgumentError("native entity scale cannot be reserved $scale"))
        any(mapping -> mapping.scale == scale && mapping.kind == kind, result) &&
            throw(ArgumentError("native symbols must have distinct (scale, kind) mappings; duplicate ($scale, $kind)"))
        push!(result, _Mapping(symbol, scale, kind))
    end
    return result
end

_spec_model(spec::PSE.ModelSpec) = spec.model

function _exposure_groups(model, plant, mappings, plant_index)
    groups = _ExposureGroup[]
    effective_plant = PSE.model_object(model, plant.id)
    for mapping in mappings
        matched = Any[]
        selected = Set{PSE.ObjectId}()
        all_ids = false
        for spec in model.applications
            selector = PSE.applies_to(spec)
            isnothing(selector) && throw(ArgumentError(
                "native scenarios require explicit ModelSpec(...; on=...) selectors"))
            _selector_labels_match(selector, mapping, effective_plant) || continue
            _plant_in_scope(model, selector, plant.id) || continue
            ids = _selector_ids(selector, plant.id, mapping.symbol)
            !isnothing(ids) && isempty(ids) && continue
            push!(matched, spec)
            isnothing(ids) ? (all_ids = true) : union!(selected, ids)
        end
        isempty(matched) && continue
        # Declaration order is stable and also distinguishes differently typed
        # object identities whose textual display is identical.
        publisher = Symbol("native_properties_", string(plant_index), "_", mapping.symbol)
        push!(groups, _ExposureGroup(mapping, all_ids ? nothing : selected,
            matched, Pair{Symbol,Symbol}[], Set{Symbol}(), publisher))
    end
    return groups
end

function _validate_target_scales(model, mappings)
    known = Set(mapping.scale for mapping in mappings)
    union!(known, (:Scene, :Plant))
    for spec in model.applications
        selector = PSE.applies_to(spec)
        isnothing(selector) && throw(ArgumentError(
            "native scenarios require explicit ModelSpec(...; on=...) selectors"))
        c = selector.criteria
        scale = _criterion(c, :scale)
        id = _criterion(c, :id)
        isnothing(scale) && isnothing(id) && throw(ArgumentError(
            "native application targets must declare scale or id; an unlabelled target is ambiguous"))
        isnothing(scale) && continue
        for item in (scale isa Tuple ? scale : (scale,))
            item in known || throw(ArgumentError(
                "application $(repr(PSE.application_name(spec))) requests unmapped native scale $item; declare it in scales"))
        end
    end
end

function _domain_relation(model, selector, group, plant; source_context=false)
    _selector_labels_match(selector, group.mapping, PSE.model_object(model, plant.id)) || return :disjoint
    _plant_in_scope(model, selector, plant.id; source_context) || return :disjoint
    return _domain_id_relation(selector, group, plant)
end

function _domain_id_relation(selector, group, plant)
    selected = _selector_ids(selector, plant.id, group.mapping.symbol)
    isnothing(selected) && return :covers
    isempty(selected) && return :disjoint
    isnothing(group.ids) && return :partial
    isempty(intersect(selected, group.ids)) && return :disjoint
    issubset(group.ids, selected) ? :covers : :partial
end

function _execution_contexts(model, spec)
    criteria = PSE.applies_to(spec).criteria
    keywords = (; (name => value for (name, value) in pairs(criteria)
        if name !== :selectors)...)
    return PSE.resolve_object_ids(model, PSE.Many(criteria.selectors...; keywords...))
end

function _relative_root_relation(model, spec, scope, selector, group, plant, role)
    contexts = _execution_contexts(model, spec)
    if isempty(contexts)
        scales = _criterion(PSE.applies_to(spec).criteria, :scale)
        scales = scales isa Tuple ? scales : (scales,)
        all(scale -> scale in (:Scene, :Plant), scales) || throw(ArgumentError(
            "relative native $role scopes require known execution roots; cannot infer scopes of unborn native objects"))
        return :disjoint
    end
    scope isa PSE.Self && return :disjoint # Existing roots are not native arena entities.
    for context in contexts
        scoped_ids = try
            PSE.resolve_object_ids(model, PSE.Many(scope); context)
        catch error
            throw(ArgumentError("cannot resolve native $role scope $(repr(scope)) from execution object $(repr(context.value)): $(sprint(showerror, error))"))
        end
        plant.id in scoped_ids && return _domain_id_relation(selector, group, plant)
    end
    return :disjoint
end

function _output_domain_relation(model, spec, selector, group, plant)
    _selector_labels_match(selector, group.mapping, PSE.model_object(model, plant.id)) ||
        return :disjoint
    isnothing(_criterion(selector.criteria, :relation)) || throw(ArgumentError(
        "native property ownership does not support relation OutputTo selectors; use an explicit scene or plant scope"))
    scope = _scope(selector)
    if isnothing(scope) || scope isa Union{PSE.SceneScope,PSE.Scope}
        return _domain_relation(model, selector, group, plant; source_context=true)
    end
    return _relative_root_relation(model, spec, scope, selector, group, plant, :OutputTo)
end

function _input_domain_relation(model, spec, selector, group, plant)
    _selector_labels_match(selector, group.mapping, PSE.model_object(model, plant.id)) ||
        return :disjoint
    isnothing(_criterion(selector.criteria, :relation)) || throw(ArgumentError(
        "native property discovery does not support relation input selectors; use an explicit scene or plant scope"))
    scope = _scope(selector)
    if scope isa Union{PSE.SceneScope,PSE.Scope}
        return _domain_relation(model, selector, group, plant; source_context=true)
    elseif isnothing(scope) || scope isa PSE.Self
        spec in group.specs && return _domain_id_relation(selector, group, plant)
        # PSE defaults unscoped inputs to Self(), except scene consumers whose
        # dependency scope defaults to SceneScope().
        if isnothing(scope)
            for context in _execution_contexts(model, spec)
                object = PSE.model_object(model, context)
                (object.scale === :Scene || object.kind === :scene) &&
                    return _domain_id_relation(selector, group, plant)
            end
        end
        return :disjoint
    end
    return _relative_root_relation(model, spec, scope, selector, group, plant, :input)
end

function _canonical_owner(model, variable, group, plant)
    result = :none
    for spec in model.applications
        interface = PSE.Authoring.model_interface(_spec_model(spec))
        haskey(interface.outputs, variable) || continue
        declaration = interface.outputs[variable]
        if declaration isa PSE.Distributed
            destinations = PSE.outputs_to(spec)
            for destination in destinations
                vars = destination.vars
                !isnothing(vars) && !(variable in vars) && continue
                relation = _output_domain_relation(model, spec, destination.selector, group, plant)
                relation == :partial && return :partial
                relation == :covers && (result = :owned)
            end
        elseif get(PSE.output_routing(spec), variable, :canonical) == :canonical
            relation = _domain_relation(model, PSE.applies_to(spec), group, plant)
            relation == :partial && return :partial
            relation == :covers && (result = :owned)
        end
    end
    return result
end

function _property_aliases(properties)
    return Dict{Symbol,Symbol}(Symbol(name) => Symbol(source) for (name, source) in pairs(properties))
end

function _plan_properties!(model, group, plant, aliases, status_factory, geometry;
    state=nothing)
    needed = Set{Symbol}()
    required = Set{Symbol}()
    # Local inputs of applications selecting this native domain.
    for spec in group.specs
        interface = PSE.Authoring.model_interface(_spec_model(spec))
        bindings = PSE.value_inputs(spec)
        for (name, declaration) in pairs(interface.inputs)
            if haskey(bindings, name)
                binding = bindings[name]
                producer = _criterion(binding.criteria, :application)
                !isnothing(producer) && producer != group.publisher && continue
                source = _criterion(binding.criteria, :var, name)
                # A named different source cannot be provided under the local
                # input name. Let its explicitly selected producer supply it.
                source != name && !isnothing(producer) && producer != group.publisher && continue
                _input_domain_relation(model, spec, binding, group, plant) == :disjoint && continue
                push!(needed, source)
                declaration isa PSE.Required && push!(required, source)
            else
                push!(needed, name)
                declaration isa PSE.Required && push!(required, name)
            end
        end
    end
    # Explicit cross-object inputs can request a native property of an already
    # demanded scale, but do not themselves create exposure.
    for spec in model.applications
        interface = PSE.Authoring.model_interface(_spec_model(spec))
        for (name, binding) in pairs(PSE.value_inputs(spec))
            producer = _criterion(binding.criteria, :application)
            !isnothing(producer) && producer != group.publisher && continue
            scope = _scope(binding)
            scope isa PSE.Self && !(spec in group.specs) && continue
            relation = _input_domain_relation(model, spec, binding, group, plant)
            relation == :disjoint && continue
            source = _criterion(binding.criteria, :var, name)
            push!(needed, source)
            haskey(interface.inputs, name) && interface.inputs[name] isa PSE.Required &&
                push!(required, source)
        end
    end
    for name in sort!(collect(needed); by=string)
        ownership = _canonical_owner(model, name, group, plant)
        ownership == :partial && throw(ArgumentError(
            "native property $name has partial external ownership on scale $(group.mapping.scale); split its kind/scale mapping explicitly"))
        ownership == :owned && continue
        source = get(aliases, name, name)
        coupled = state !== nothing && state.development !== nothing
        growth = state !== nothing && state.organ_growth !== nothing
        if source in native_properties(group.mapping.symbol; coupled, growth)
            !geometry && source in _GEOMETRY_PROPERTIES && throw(ArgumentError(
                "native property $name requires geometry=true"))
            push!(group.properties, name => source)
        elseif name in required
            isnothing(status_factory) && throw(ArgumentError(
                "native $(group.mapping.symbol) does not supply required property $name; declare a real producer or status_factory (area is never fabricated)"))
            push!(group.required, name)
        end
    end
    return group
end

function _property(symbol, slot, record, property)
    property === :native_id && return Int(slot)
    property === :birth_time && return symbol === :Axis ? record.birth : record.first_dispatch
    property === :initial_physiological_age && return record.initial_age
    property === :axis_id && return record.axis
    property === :site_id && return record.site
    return getproperty(record, property)
end

function _property(state, symbol, slot, record, property)
    if property in _POTENTIAL_PROPERTIES
        state.organ_growth === nothing && throw(ArgumentError(
            "potential geometry requires modeled coupled growth"))
        dimensions = state.organ_growth.potential[slot]
        return property === :potential_length ? dimensions.length :
            property === :potential_diameter_top ? dimensions.diameter_top : dimensions.diameter_bottom
    elseif property === :structural_mass_gDM
        state.organ_growth === nothing && throw(ArgumentError(
            "structural mass requires an explicit coupled biomass model"))
        return state.organ_growth.structural_mass_gDM[slot]
    elseif property === :development_time
        return NativeAMAP.axis_development(state.development, slot)
    end
    return _property(symbol, slot, record, property)
end

function _property_default(symbol, property)
    property === :native_id && return 0
    property === :active && return true
    property in (:base, :tip) && return (0f0, 0f0, 0f0)
    property === :frame && return ((0f0, 0f0, 1f0), (1f0, 0f0, 0f0), (0f0, 1f0, 0f0))
    property in (:length, :diameter_top, :diameter_bottom, _POTENTIAL_PROPERTIES...) && return 0f0
    property in (:nature, :order, :reiteration_order, :immediate_order,
        :index, :test_count, :realized_count, :rank, :axis_id, :site_id) && return Int32(0)
    return 0.0
end

function _publisher_destination(group)
    return if isnothing(group.ids)
        PSE.Many(scale=group.mapping.scale, kind=group.mapping.kind, within=PSE.Subtree())
    else
        PSE.Many(scale=group.mapping.scale, kind=group.mapping.kind,
            within=PSE.Subtree(), id=Tuple(group.ids))
    end
end

function _publisher_spec(plant, group; coupled=false, state=nothing,
    properties=group.properties, early=false)
    names = Tuple(first.(properties))
    defaults = NamedTuple{names}(Tuple(source === :structural_mass_gDM ?
        zero(eltype(state.organ_growth.structural_mass_gDM)) :
        _property_default(group.mapping.symbol, source)
        for (_, source) in properties))
    destination = _publisher_destination(group)
    revision = coupled && !early ? :native_geometry_revision : :native_revision
    producer = coupled && !early ? :native_synchronization : _ARCHITECTURE
    binding = NamedTuple{(revision,)}((PSE.One(within=PSE.Self(),
        application=producer, var=revision),))
    name = early ? Symbol(group.publisher, "_potential") : group.publisher
    return PSE.ModelSpec(NativePropertyPublisher(defaults, Tuple(properties), revision);
        name, on=PSE.One(id=plant.id),
        inputs=binding,
        outputs_to=(PSE.OutputTo(destination),))
end

function _validate_projection_target(state, id)
    value = id.value
    valid_key = value isa Tuple && length(value) == 3 &&
        typeof(value[1]) === typeof(state.plant_id.value) &&
        isequal(value[1], state.plant_id.value) && value[2] isa Symbol &&
        value[3] isa Int && value[3] > 0
    key = valid_key ? (value[2], value[3]) : nothing
    expected = isnothing(key) ? nothing : get(state.registered, key, nothing)
    !isnothing(expected) && isequal(expected, id) || throw(ArgumentError(
        "native property publisher encountered foreign object $(repr(value)); its destination scale/kind domain is reserved for registered native objects of plant $(repr(state.plant_id.value))"))
    return nothing
end

function _validate_publisher_domains(model, state)
    for group in state.groups
        isempty(group.properties) && continue
        for id in PSE.resolve_object_ids(model, _publisher_destination(group);
            context=state.plant_id)
            _validate_projection_target(state, id)
        end
    end
    return nothing
end

function _product_symbol(state, organ)
    axis = state.native.plant.axes[organ.axis]
    return get(state.product_symbols, Int(axis.lateral_index), :Internode)
end

_record(state, symbol, slot) = symbol === :Axis ? state.native.plant.axes[slot] :
    symbol === :GrowthUnit ? state.native.plant.growth_units[slot] : state.native.plant.organs[slot]

function _candidate_records(state, group)
    symbol = group.mapping.symbol
    records = symbol === :Axis ? state.native.plant.axes :
        symbol === :GrowthUnit ? state.native.plant.growth_units : state.native.plant.organs
    return ((slot, record) for (slot, record) in enumerate(records)
        if record.active && (symbol in (:Axis, :GrowthUnit) || _product_symbol(state, record) == symbol) &&
           (isnothing(group.ids) || native_object_id(state.plant_id, symbol, slot) in group.ids))
end

function _nearest_parent(state, symbol, record, desired)
    plant = state.native.plant
    if symbol === :Axis
        axis = Int(record.parent)
    elseif symbol === :GrowthUnit
        axis = Int(record.axis)
    else
        site = plant.sites[record.site]
        gu = (:GrowthUnit, Int(site.gu))
        haskey(desired, gu) && return state.registered[gu]
        axis = Int(record.axis)
    end
    while axis != 0
        key = (:Axis, axis)
        haskey(desired, key) && return state.registered[key]
        axis = Int(plant.axes[axis].parent)
    end
    return state.plant_id
end

function _initial_status(state, group, slot, record)
    extra = isnothing(state.status_factory) ? NamedTuple() :
        _status_values(state.status_factory(state.plant_id.value, group.mapping.symbol, slot, record))
    for name in group.required
        haskey(extra, name) || throw(ArgumentError(
            "status_factory did not supply required property $name for $(group.mapping.symbol) slot $slot"))
    end
    names = Tuple(first.(group.properties))
    values = Tuple(_property(state, group.mapping.symbol, slot, record, source)
        for (_, source) in group.properties)
    return PSE.Status(merge(extra, NamedTuple{names}(values)))
end

function _geometry_snapshot(state, symbol, record)
    (!state.geometry || symbol in (:Axis, :GrowthUnit)) && return nothing
    # The native arenas mutate before the lifecycle boundary. Never leak their
    # mutable records into Object.geometry: the preceding immutable snapshot is
    # also the correct old_geometry value in a PSE move event.
    return (base=record.base, tip=record.tip, frame=record.frame,
        length=record.length, diameter_top=record.diameter_top,
        diameter_bottom=record.diameter_bottom)
end

function _synchronize!(model, state)
    isempty(state.groups) && return nothing
    desired = Dict{Tuple{Symbol,Int},Any}()
    for group in state.groups
        for (slot, record) in _candidate_records(state, group)
            desired[(group.mapping.symbol, slot)] = (group, record)
        end
    end
    # Structural arenas are append-only. Sorting structural parents by slot
    # makes their nearest exposed ancestors available before their children.
    keys_ = sort!(collect(keys(desired)); by=key ->
        (key[1] === :Axis ? 0 : key[1] === :GrowthUnit ? 1 : 2, key[2], string(key[1])))
    for key in keys_
        group, record = desired[key]
        symbol, slot = key
        parent = _nearest_parent(state, symbol, record, desired)
        geometry = _geometry_snapshot(state, symbol, record)
        if !haskey(state.registered, key)
            id = native_object_id(state.plant_id, symbol, slot)
            object = PSE.Object(id; scale=group.mapping.scale, kind=group.mapping.kind,
                species=PSE.model_object(model, state.plant_id).species, parent=parent,
                geometry=geometry,
                status=_initial_status(state, group, slot, record))
            PSE.register_object!(model, object)
            state.registered[key] = id
        else
            id = state.registered[key]
            object = PSE.model_object(model, id)
            object.parent == parent || PSE.reparent_object!(model, id, parent)
            isequal(PSE.geometry(object), geometry) || PSE.update_geometry!(model, id, geometry)
        end
    end
    stale = [key for key in keys(state.registered) if !haskey(desired, key)]
    sort!(stale; by=key ->
        (key[1] === :Axis ? 0 : key[1] === :GrowthUnit ? 1 : 2, key[2]), rev=true)
    for key in stale
        PSE.remove_object!(model, state.registered[key]; recursive=false)
        delete!(state.registered, key)
    end
    return nothing
end

"""
    scenario(plants; applications=(), instances=(), scales=..., properties=(),
        geometry=true, root_id=:scene, status_factory=nothing,
        before_growth_calls=NamedTuple(), growth_allocation_call=nothing,
        carbon_policy=nothing)

Build a CompositeModel with one native state per plant. `scales` maps semantic
native symbols to PSE scale labels (or `(scale=..., kind=...)`). Only mounted
application `on` selectors demand exposure. Explicit input selectors request
properties of those exposed entities but do not themselves create objects.
`properties` provides explicit aliases, e.g. `(Length=:length,)`.

Scene, plant, and instance scopes are supported. Scopes rooted below a plant
must be declared through a richer topology adapter and are rejected here.
Native publisher destination scale/kind domains are reserved for native Objects;
foreign Objects with overlapping labels are rejected before native values are written.
`status_factory(plant_id, native_symbol, native_index, record)` may supply real
initial values for non-native required fields. Native dimensions retain their
source representation/units; no leaf area or PlantBiophysics contract is inferred.

Optional `before_growth_calls` names PSE manual calls made before each native
organ is realized. `growth_allocation_call` enables sampled-once preparation,
organ-specific refusal and postcommit settlement through the existing
`GrowthIntent`/allocation-decision ports. Select the target applications by name;
leave both options unset for ordinary native advancement. See `CARBON.md` for
the cumulative gC ledger, explicit mass/cost example and catch-up limitations.
Alternatively, `carbon_policy=FixedCarbonPolicy(...)` prepares a typed fixed
construction rule once per PSE step and applies it directly in the native
loop. This mode publishes compact scalar balances and retains only waiting
quotes; it is mutually exclusive with per-organ PSE call options.
"""
function scenario(plants; applications=(), instances=(), scales=_DEFAULT_SCALES,
    properties=NamedTuple(), geometry::Bool=true, root_id=:scene, status_factory=nothing,
    environment=nothing, before_growth_calls=NamedTuple(), growth_allocation_call=nothing,
    carbon_policy=nothing, mode::Symbol=:reference, growth_models=nothing,
    realization::Symbol=:potential, growth_numeric_type=nothing,
    pruning_clock::Symbol=:development, pruning_seconds_per_stage=nothing)
    declarations = plants isa NativePlant ? (plants,) : Tuple(plants)
    isempty(declarations) && throw(ArgumentError("native scenario requires at least one NativePlant"))
    all(plant -> plant isa NativePlant, declarations) ||
        throw(ArgumentError("scenario plants must be NativePlant declarations"))
    before_growth_calls isa NamedTuple || throw(ArgumentError(
        "before_growth_calls must be a NamedTuple of named PSE call selectors"))
    haskey(before_growth_calls, :growth_allocation) && throw(ArgumentError(
        "growth_allocation is reserved; use growth_allocation_call"))
    allocation_enabled = growth_allocation_call !== nothing
    mode in (:reference, :coupled) || throw(ArgumentError(
        "mode must be :reference or :coupled"))
    realization in (:potential, :models) || throw(ArgumentError(
        "realization must be :potential or :models"))
    coupled = mode === :coupled
    !coupled || (carbon_policy === nothing && isempty(before_growth_calls) && !allocation_enabled) ||
        throw(ArgumentError("coupled expansion is separate from the organ-creation carbon gate"))
    coupled || (growth_models === nothing && realization === :potential &&
        pruning_clock === :development && pruning_seconds_per_stage === nothing) ||
        throw(ArgumentError("local development and expansion options require mode=:coupled"))
    modeled_growth = coupled && (growth_models !== nothing || realization === :models)
    growth_models === nothing || (growth_models isa NamedTuple &&
        Set(keys(growth_models)) == Set((:demand, :allocation, :expansion))) ||
        throw(ArgumentError("growth_models must contain demand, allocation and expansion models"))
    numeric_type = if growth_numeric_type === nothing
        growth_models !== nothing && applicable(_growth_numeric_type, growth_models.demand) ?
            _growth_numeric_type(growth_models.demand) : Float64
    else
        growth_numeric_type
    end
    numeric_type isa Type && numeric_type <: AbstractFloat || throw(ArgumentError(
        "growth_numeric_type must be an AbstractFloat type"))
    !modeled_growth || geometry || throw(ArgumentError(
        "geometry-based growth requires geometry=true"))
    carbon_policy === nothing || carbon_policy isa FixedCarbonPolicy || throw(ArgumentError(
        "carbon_policy must be a FixedCarbonPolicy"))
    carbon_policy === nothing || (isempty(before_growth_calls) && !allocation_enabled) ||
        throw(ArgumentError("carbon_policy cannot be combined with per-organ PSE calls"))
    coupled && (environment = _coupled_environment(environment))
    architecture = coupled ? CoupledArchitecture(Float64(PSE.EnvironmentAPI.base_step_seconds(
        PSE.EnvironmentAPI.environment_backend(environment)))) :
        NativeArchitecture(Tuple(keys(before_growth_calls)); allocation_enabled, carbon_policy)
    architecture_calls = allocation_enabled ? merge(before_growth_calls,
        (growth_allocation=growth_allocation_call,)) : before_growth_calls
    mappings = _mappings(scales)
    root = PSE.Object(root_id; scale=:Scene, kind=:scene)
    objects = PSE.Object[root]
    states = Dict{PSE.ObjectId,NativePSEState}()
    for plant in declarations
        native = NativeAMAP.NativeModel(plant.parameters; seed=plant.seed)
        control, runtime = coupled ? (nothing, Ref{Any}(nothing)) :
            _plant_growth_control(plant, architecture)
        development = coupled ? NativeAMAP.LocalDevelopment(native;
            pruning_clock, pruning_seconds_per_stage) : nothing
        organ_growth = modeled_growth ? NativeAMAP.OrganGrowthState(numeric_type) : nothing
        state = NativePSEState(native, plant.id,
            copy(plant.product_symbols), _ExposureGroup[],
            Dict{Tuple{Symbol,Int},PSE.ObjectId}(), geometry, status_factory,
            control, runtime, development, organ_growth, false)
        states[plant.id] = state
        status = PSE.Status(merge(deepcopy(plant.status),
            (; _native_pse_state=state, development_increment=plant.development_increment)))
        push!(objects, PSE.Object(plant.id; scale=:Plant, kind=plant.kind,
            species=plant.species, parent=root.id, status=status))
    end
    supplied = applications isa Tuple ? applications :
        applications isa AbstractVector ? Tuple(applications) : (applications,)
    all(spec -> spec isa PSE.ModelSpec, supplied) || throw(ArgumentError(
        "native scenario applications must be explicit ModelSpec declarations"))
    plant_ids = Tuple(plant.id for plant in declarations)
    if growth_models !== nothing
        supplied = (supplied..., _growth_application_specs(growth_models, plant_ids)...)
    end
    model = PSE.CompositeModel(objects...; applications=supplied, instances=instances,
        environment=environment)
    _validate_target_scales(model, mappings)
    aliases = _property_aliases(properties)
    # Construction-time access only: the constructor has already mounted every
    # instance declaration; no compiled cache or runtime exists yet.
    publishers = Any[]
    for (plant_index, plant) in enumerate(declarations)
        state = states[plant.id]
        state.groups = _exposure_groups(model, plant, mappings, plant_index)
        for group in state.groups
            _plan_properties!(model, group, plant, aliases, status_factory, geometry; state)
            if coupled && modeled_growth
                # A potential consumer may itself feed allocation. Its source
                # must precede expansion; realized observations follow it.
                early = filter(pair -> !(last(pair) in _GEOMETRY_PROPERTIES) &&
                    last(pair) !== :structural_mass_gDM, group.properties)
                late = filter(pair -> last(pair) in _GEOMETRY_PROPERTIES ||
                    last(pair) === :structural_mass_gDM, group.properties)
                isempty(early) || push!(publishers, _publisher_spec(plant, group;
                    coupled, state, properties=early, early=true))
                isempty(late) || push!(publishers, _publisher_spec(plant, group;
                    coupled, state, properties=late))
            else
                isempty(group.properties) || push!(publishers,
                    _publisher_spec(plant, group; coupled, state))
            end
        end
    end
    # PSE uses stable topological order. Growth is first even when a projected
    # output-only model needs no native-property writer/dependency edge.
    architecture_inputs = carbon_policy === nothing ? NamedTuple() :
        (native_carbon_policy=PSE.One(within=PSE.Self(),
            application=:native_carbon_policy, var=:native_carbon_policy),)
    if carbon_policy !== nothing
        any(spec -> spec.name === :native_carbon_policy, model.applications) &&
            throw(ArgumentError("native_carbon_policy is a reserved application name in cached carbon mode"))
        pushfirst!(model.applications, PSE.ModelSpec(carbon_policy;
            name=:native_carbon_policy, on=PSE.Many(scale=:Plant,
                id=Tuple(plant.id for plant in declarations))))
    end
    pushfirst!(model.applications, PSE.ModelSpec(architecture;
        name=_ARCHITECTURE, on=PSE.Many(scale=:Plant,
            id=Tuple(plant.id for plant in declarations)), calls=architecture_calls,
        inputs=architecture_inputs))
    if coupled
        any(spec -> spec.name === :native_synchronization, model.applications) &&
            throw(ArgumentError("native_synchronization is a reserved application name"))
        sync_inputs = (native_revision=PSE.One(within=PSE.Self(),
            application=_ARCHITECTURE, var=:native_revision),)
        if modeled_growth
            sync_inputs = merge(sync_inputs,
                (actual_geometry_revision=PSE.One(within=PSE.Self(),
                    var=:actual_geometry_revision),))
        end
        # A stable early position also keeps output-only organ applications
        # behind the lifecycle boundary when no explicit property edge exists.
        insert!(model.applications, 2, PSE.ModelSpec(
            CoupledSynchronization{modeled_growth}(); name=:native_synchronization,
            on=PSE.Many(scale=:Plant, id=plant_ids), inputs=sync_inputs))
    end
    append!(model.applications, publishers)
    for plant in declarations
        isempty(states[plant.id].groups) || _synchronize!(model, states[plant.id])
        _validate_publisher_domains(model, states[plant.id])
    end
    return model
end
