# SPDX-License-Identifier: LGPL-3.0-or-later
# Native scalar geometry algorithms ported from AMAPsim (1995-2018),
# copyright Jean-Francois Barczi and AMAPsim contributors.
# Source: amapsim/thevitisnew/src/VitisCore/{Matrix.cpp,Vector.cpp,Include/UtilMath.h}
# and VitisModels/AmapSimMod/GeomBrancAMAP.cpp.
# Original files license: GNU Lesser General Public License, version 3 or later.
# The typed arena, compiler and scheduler are independent Julia implementations.
# This header applies to this prototype file, not the surrounding MIT package.
"""
Experimental native AMAPSim arena engine. The hot growth and geometry passes use
only concrete Julia structs, contiguous organ storage, and integer links.

Supported laws: constant parameters, complete preformed GUs, deterministic
survival/differentiation, Markov immediate branching, nature-zero or inhibited
lateral production, relative insertion mode 1, deterministic dimensions and
legacy mechanical bending. The compiler rejects all other active mechanisms.
It deliberately produces no MTG/PSE registry or synthetic scaffold nodes.
"""
module NativeAMAPCore
import AMAPSim

const V3 = NTuple{3,Float32}
const Frame = NTuple{3,V3} # main, secondary, normal (native cone axes)
const ZERO3 = (0.0f0,0.0f0,0.0f0)
const INITIAL_FRAME = ((0.0f0,0.0f0,1.0f0),(1.0f0,0.0f0,0.0f0),(0.0f0,1.0f0,0.0f0))
const EPSILON = 1.0e-6

struct NativeConfig
    max_age::Int
    initial_age::Float64
    max_gu::Int
    tests_per_gu::Int
    duration::Float64
    max_branch_order::Int
    max_immediate_order::Int
    max_reiteration::Int
    lateral_nature::Int
    whorl_count::Int
    axillary_enabled::Bool
    production_start::Int
    production_end::Int
    immediate_initial::Bool
    unbranched_transition::Bool
    branched_transition::Bool
    child_age_jump::Float64
    child_rhythm::Float64
    organ_length::Float32
    organ_diameter::Float32
    insertion::Float32
    phase::Float32
    phyllotaxy::Float32
    young::Float32
    conicity::Float32
    inflexion::Float32
    length_ratio::Float32
    diameter_ratio::Float32
    length_zone::Float32
    diameter_zone::Float32
    length_lag::Float32
    diameter_lag::Float32
end

"""Check every control point, including inactive positional/physiological levels."""
function constant_value(p)
    if hasproperty(p, :value)
        return Float64(p.value)
    elseif hasproperty(p, :values)
        values = p.values
        first_value = Float64(first(values))
        all(x -> Float64(x) == first_value, values) ||
            throw(ArgumentError("native prototype requires constant parameter $(p.provenance.legacy_name)"))
        return first_value
    elseif hasproperty(p, :curves)
        values = map(constant_value, p.curves)
        all(==(first(values)), values) ||
            throw(ArgumentError("native prototype requires constant parameter $(p.provenance.legacy_name)"))
        return first(values)
    end
    throw(ArgumentError("unsupported parameter record $(typeof(p))"))
end

function compile_parameters(parameters)
    values = Dict(i => constant_value(parameters.legacy[i]) for i in keys(parameters.legacy))
    v(i) = values[i]
    function require(i, expected)
        v(i) == expected || throw(ArgumentError(
            "native prototype does not support legacy parameter $i = $(v(i)); required $expected"))
    end
    function integer(i; minimum=0)
        x = v(i)
        isfinite(x) && x == trunc(x) && x >= minimum ||
            throw(ArgumentError("legacy parameter $i must be an integer >= $minimum"))
        return Int(x)
    end
    function probability(i)
        x = v(i)
        x in (0.0,1.0) || throw(ArgumentError("native prototype requires deterministic probability at legacy index $i"))
        return x == 1.0
    end
    # Active unsupported growth mechanisms. Dormancy durations and unused later
    # cycle controls are irrelevant because each first cycle exactly fills a GU.
    for i in (19,124,21,22,23,24,25,29,30,43,44,111,112,118,74,78,79,80,81,92,93,96)
        require(i,0.0)
    end
    require(122,1.0) # survival
    require(97,0.0); require(99,1.0); require(100,1.0); require(101,0.0)
    require(46,1.0); require(73,1.0); require(86,1.0)
    require(94,1.0); require(95,1.0)
    require(82,0.0)
    # The first compiler deliberately fixes maturity ratios; supporting a
    # varying ratio also requires the source theoretical-horizon projection.
    require(83,1.0); require(89,1.0)
    ntests = integer(32; minimum=1)
    require(45,ntests)
    # Counting base truncates source 0.5 to 0; base 0 is GU-local tests.
    trunc(Int,v(26)) == 0 || throw(ArgumentError("only test counting base 0 is supported"))
    require(27,0.0)
    v(123) > 0 || throw(ArgumentError("growth rhythm must be positive"))
    length(parameters.lateral_productions) == 1 || throw(ArgumentError("prototype supports exactly one LP"))
    lp = only(parameters.lateral_productions)
    all(==(AMAPSim.MarkovModel), lp.branching_models) ||
        throw(ArgumentError("prototype supports Markov branching models only"))
    lp.organ_symbol === :Internode || throw(ArgumentError("prototype supports Internode products only"))
    # Lateral-global legacy indices are 127 + field index; zone 1 follows ten globals.
    L = 127
    Z = L + 10
    nature = integer(L+1)
    nature == 0 || nature >= 10 || throw(ArgumentError("supported LP natures are 0 and inhibited >= 10"))
    require(L+8,0.0); require(L+10,0.0)
    for z in (Z, Z+55)
        require(z+9,1.0); require(z+10,0.0); require(z+11,1.0); require(z+14,0.0)
        require(z+24,0.0)
    end
    # No cycle-delayed branches occur: the first cycle reaches the GU test cap.
    # No traumatic branching occurs: survival is fixed to one.
    for i in (L+3,Z+27,Z+28,Z+31)
        probability(i)
    end
    v(Z+26) > 0 || throw(ArgumentError("child rhythm must be positive"))
    v(75) > 0 || throw(ArgumentError("Young modulus must be positive"))
    v(77) < 1 || throw(ArgumentError("conicity must remain below 1"))
    init = parameters.initialization
    init.initial_physiological_age == 1 || throw(ArgumentError("prototype requires initial physiological age 1"))
    require(Z+23,-2.0)
    v(119) >= 2 || throw(ArgumentError("maximum physiological age must permit ages 1 and 2"))
    v(115) >= 0 && v(116) > 0 || throw(ArgumentError("organ dimensions must be nonnegative with positive diameter"))
    return NativeConfig(init.maximum_age, Float64(init.initial_physiological_age),
        integer(15;minimum=1), ntests, inv(v(123)), trunc(Int,v(11)),
        trunc(Int,v(13)), integer(12), nature, integer(L+2), probability(L+3),
        integer(L+4;minimum=1)-1, integer(L+5;minimum=1)-1,
        probability(Z+27), !probability(Z+28), probability(Z+31),
        v(Z+23), v(Z+26), Float32(v(115)), Float32(v(116)), Float32(v(117)),
        Float32(v(L+6)), Float32(v(L+7)), Float32(v(75)), Float32(v(77)),
        Float32(v(76)), Float32(v(83)), Float32(abs(v(89))),
        Float32(v(84)), Float32(v(90)), Float32(v(85)), Float32(v(91)))
end
compile_parameters(fpa::AbstractString) = compile_parameters(AMAPSim.read_parameters(fpa))

mutable struct NativeAxis
    parent::Int32
    bearer_organ::Int32
    bearer_test::Int32
    slot::Int32
    whorl_size::Int32
    order::Int32
    immediate_order::Int32
    reiteration_order::Int32
    age::Float64
    birth::Float64
    first_organ::Int32
    last_organ::Int32
    realized::Int32
    tests::Int32
    gu_count::Int32
    gu_tests::Int32
    next_time::Float64
    gu_end::Float64
    dt::Float64
    duration::Float64
    markov_initialized::Bool
    markov_state::Bool
end

struct NativeOrgan
    axis::Int32
    rank::Int32
    gu::Int32
    gu_rank::Int32
    next::Int32
    birth::Float64
    length::Float32
    diameter_top::Float32
    diameter_bottom::Float32
    base::V3
    tip::V3
    frame::Frame
end

struct NativeEvent
    time::Float64
    priority::Int32
    sequence::Int64
    axis::Int32
end
@inline before(a::NativeEvent,b::NativeEvent) =
    a.time < b.time || (a.time == b.time && (a.priority < b.priority ||
    (a.priority == b.priority && a.sequence < b.sequence)))

mutable struct NativeTree
    config::NativeConfig
    axes::Vector{NativeAxis}
    organs::Vector{NativeOrgan}
    heap::Vector{NativeEvent}
    sequence::Int64
    development_time::Float64
    last_event_time::Float64
    processed_events::Int64
    geometry_complete::Bool
end

function enqueue!(tree::NativeTree, axis::Int)
    a = tree.axes[axis]
    tree.sequence += 1
    e = NativeEvent(a.next_time, Int32(11*a.immediate_order),tree.sequence,Int32(axis))
    push!(tree.heap,e)
    i = length(tree.heap)
    while i > 1
        p = i >>> 1
        before(tree.heap[p],e) && break
        tree.heap[i] = tree.heap[p]
        i = p
    end
    tree.heap[i] = e
    return nothing
end

function dequeue!(tree::NativeTree)
    h = tree.heap
    e = h[1]
    last_event = pop!(h)
    if !isempty(h)
        i = 1; n = length(h)
        while (left = 2i) <= n
            right = left+1
            child = right <= n && before(h[right],h[left]) ? right : left
            before(last_event,h[child]) && break
            h[i] = h[child]
            i = child
        end
        h[i] = last_event
    end
    return e
end

function initialize(config::NativeConfig; reserve_axes=16, reserve_organs=1024)
    dt = config.duration / config.tests_per_gu
    root = NativeAxis(0,0,-1,0,1,0,0,0,config.initial_age,0.0,
        0,0,0,0,0,0,dt,config.duration,dt,config.duration,false,false)
    axes = NativeAxis[root]; sizehint!(axes,reserve_axes)
    organs = NativeOrgan[]; sizehint!(organs,reserve_organs)
    tree = NativeTree(config,axes,organs,NativeEvent[],0,0.0,0.0,0,false)
    enqueue!(tree,1)
    return tree
end

function append_organ!(tree::NativeTree, axis_id::Int, time::Float64)
    a = tree.axes[axis_id]
    a.gu_tests == 0 && (a.gu_count += 1)
    a.gu_tests += 1; a.tests += 1; a.realized += 1
    id = length(tree.organs)+1
    push!(tree.organs,NativeOrgan(axis_id,a.realized-1,a.gu_count-1,
        a.gu_tests-1,0,time,0,0,0,ZERO3,ZERO3,INITIAL_FRAME))
    if a.last_organ > 0
        old = tree.organs[a.last_organ]
        tree.organs[a.last_organ] = NativeOrgan(old.axis,old.rank,old.gu,old.gu_rank,
            Int32(id),old.birth,old.length,old.diameter_top,old.diameter_bottom,old.base,old.tip,old.frame)
    else
        a.first_organ = Int32(id)
    end
    a.last_organ = Int32(id)
    return id
end

function branch!(tree::NativeTree, axis_id::Int, organ_id::Int, time::Float64)
    c = tree.config; a = tree.axes[axis_id]
    c.lateral_nature >= 10 && return nothing
    c.axillary_enabled && a.order < c.max_branch_order || return nothing
    a.gu_tests-1 in c.production_start:c.production_end || return nothing
    # Source testInitialState starts a new Markov chain at each GU basal site.
    a.gu_tests == 1 && (a.markov_initialized = false)
    a.markov_state = if !a.markov_initialized
        c.immediate_initial
    elseif a.markov_state
        c.branched_transition
    else
        c.unbranched_transition
    end
    a.markov_initialized = true
    a.markov_state || return nothing
    next_age = c.child_age_jump < 0 ? abs(c.child_age_jump) : max(a.age,a.age+c.child_age_jump)
    reiteration = next_age <= a.age+1 ? a.reiteration_order+1 : 0
    reiteration > c.max_reiteration && return nothing
    for slot in 0:c.whorl_count-1
        duration = c.duration / c.child_rhythm
        dt = duration / c.tests_per_gu
        # The first immediate GU is limited to the bearer's current GU end.
        gu_end = min(time+duration,a.gu_end)
        child = NativeAxis(Int32(axis_id),Int32(organ_id),a.tests-1,Int32(slot),
            Int32(c.whorl_count),a.order+1,a.immediate_order+1,Int32(reiteration),
            next_age,time,0,0,0,0,0,0,time+dt,gu_end,dt,duration,false,false)
        push!(tree.axes,child)
        if child.immediate_order <= c.max_immediate_order+1 &&
           child.next_time <= child.gu_end+EPSILON
            enqueue!(tree,length(tree.axes))
        end
    end
    return nothing
end

"""Advance by real test events; no output projection or geometry work is hidden here."""
function advance_to!(tree::NativeTree, horizon::Real)
    tmax = Float64(horizon)
    isfinite(tmax) && tree.development_time <= tmax <= tree.config.max_age ||
        throw(ArgumentError("horizon must be monotonic, finite and <= maximum age"))
    c = tree.config
    c.axillary_enabled && tmax > 1.0 && throw(ArgumentError(
        "this scalar prototype qualifies branching only through stage 1; use the full native engine for later first-GU conversions"))
    while !isempty(tree.heap) && tree.heap[1].time <= tmax+EPSILON
        e = dequeue!(tree)
        axis_id = Int(e.axis); a = tree.axes[axis_id]
        time = e.time
        a.next_time == time || error("stale native growth event")
        organ_id = append_organ!(tree,axis_id,time)
        branch!(tree,axis_id,organ_id,time)
        tree.last_event_time = time
        tree.processed_events += 1
        nexttime = time+a.dt
        if a.gu_tests >= c.tests_per_gu || nexttime > a.gu_end+EPSILON
            if a.gu_count < c.max_gu
                a.gu_tests = 0
                # New GU begins after its first test duration, as in endGu/getTime.
                a.next_time = a.gu_end+a.dt
                a.gu_end += a.duration
                enqueue!(tree,axis_id)
            end
        else
            a.next_time = nexttime
            enqueue!(tree,axis_id)
        end
    end
    tree.development_time = tmax
    tree.geometry_complete = false
    return tree
end

@inline add(a::V3,b::V3)::V3 = (a[1]+b[1],a[2]+b[2],a[3]+b[3])
@inline scale(a::V3,s::Float32)::V3 = (a[1]*s,a[2]*s,a[3]*s)
@inline norm3(a::V3)::Float32 = Float32(sqrt(Float64(a[1]^2+a[2]^2+a[3]^2)))
@inline unit(a::V3)::V3 = scale(a,inv(norm3(a)))
@inline function rotate(v::V3,axis::V3,angle::Float32; vector_order=false)::V3
    x,y,z = axis; a,b,d = v
    c = Float32(cos(Float64(angle))); s = Float32(sin(Float64(angle))); t = 1.0f0-c
    xx,xy,xz,yy,yz,zz = vector_order ?
        (x*x*t,x*y*t,x*z*t,y*y*t,y*z*t,z*z*t) :
        (t*x*x,t*x*y,t*x*z,t*y*y,t*y*z,t*z*z)
    sx,sy,sz = s*x,s*y,s*z
    return ((xx+c)*a+(xy-sz)*b+(xz+sy)*d,
        (xy+sz)*a+(yy+c)*b+(yz-sx)*d,
        (xz-sy)*a+(yz+sx)*b+(zz+c)*d)
end
@inline function secondary(main::V3,target::Float32)::V3
    x,y,z = main
    v = (-x*z*target,-y*z*target,(1.0f0-z*z)*target)
    v[1]^2+v[2]^2+v[3]^2 < 1.0e-4 && return (1.0f0,0.0f0,0.0f0)
    return unit(v)
end
@inline function insert(frame::Frame,insertion::Float32,phase::Float32)::Frame
    m,s,n = frame
    refm = abs(m[1]) < 1.0e-4 && abs(m[2]) < 1.0e-4 ? (1.0f-4,m[2],m[3]) : m
    return ntuple(i -> rotate(rotate(frame[i],n,-insertion),refm,phase),3)
end
@inline function bend(frame::Frame,angle::Float32)::Frame
    m = frame[1]
    if abs(m[1]) < 1.0e-4 && abs(m[2]) < 1.0e-4
        m = (1.0f-4,m[2],m[3])
    end
    s = secondary(m,100.0f0)
    n = rotate(s,m,Float32(π/2);vector_order=true)
    m = rotate(m,n,angle)
    s = secondary(m,1.0f0)
    n = rotate(s,m,Float32(π/2);vector_order=true)
    return (m,s,n)
end
@inline function maturation(distance::Int,lag::Float32,zone::Float32,ratio::Float32)::Float32
    distance >= lag+zone && return ratio
    distance < lag && return 1.0f0
    zone == 0 && return ratio
    return 1.0f0+(Float32(distance)-lag)/zone*(ratio-1.0f0)
end

"""Scalar translation of VitisCore/Include/UtilMath.h::bending (Float32 state)."""
function legacy_bending_target(young::Float32,dirz::Float32,length::Float32,conicity::Float32)
    dirz = clamp(dirz,-1.0f0,1.0f0)
    theta = Float32(acos(Float64(dirz)))
    amin = 0.0f0; amax = Float32(π)-theta
    h = abs(length/(1.0f0-conicity*length))
    coef = young*h*Float32(sqrt(Float64(abs(dirz))))
    score = coef*200.0f0/Float32(π)
    angle = if 1.553 < theta < 1.588
        young*young*h*h/2.0f0
    else
        Float32(Float32(sin(Float64(theta)))*Float32(1.0-cos(Float64(coef)))/
            cos(Float64(coef))/abs(dirz))
    end
    score <= 40 && angle <= 0.2 && return Float32(cos(Float64(angle+theta)))
    while amax-amin > Float32(0.5*0.0174533)
        angle = (amax+amin)/2.0f0
        omega = 0.0f0; integrated = 0.0f0; increment = 1.0f0; iteration = 0
        while omega < angle && increment != 0 && iteration < 500
            increment = 1.414f0*young*Float32(sqrt(abs(
                cos(Float64(theta+omega))-cos(Float64(theta+angle)))))
            omega += increment; integrated += 1.0f0; iteration += 1
        end
        if integrated <= h-1.0f0
            amin = angle
        else
            amax = angle
        end
    end
    return Float32(cos(Float64((amin+amax)/2.0f0+theta)))
end

"""Full final dimensions, analytic cone placement and source mechanical bending."""
function geometry!(tree::NativeTree)
    c = tree.config
    for axis_id in eachindex(tree.axes)
        a = tree.axes[axis_id]
        a.realized == 0 && continue
        if a.parent == 0
            frame = insert(INITIAL_FRAME,c.insertion,0.0f0)
            base = ZERO3
        else
            bearer = tree.organs[a.bearer_organ]
            phase = Float32(2π)*Float32(a.slot)/Float32(a.whorl_size)+
                c.phase+c.phyllotaxy*Float32(a.bearer_test)
            frame = insert(bearer.frame,c.insertion,phase)
            # C++ initGeomtry's insertion guard mutates the reference main
            # before attachment translation, including for relative mode 1.
            # Near-vertical bearers therefore attach at the guarded endpoint,
            # which can differ from their already-stored geometric tip.
            reference_main = bearer.frame[1]
            if abs(reference_main[1]) < 1.0e-4 && abs(reference_main[2]) < 1.0e-4
                reference_main = (1.0f-4,reference_main[2],reference_main[3])
            end
            base = add(bearer.base,scale(reference_main,bearer.length))
        end
        # Native geometry stores the target in Float32. This pure scalar kernel
        # preserves the same scientific equation, including nonlinear fallback.
        target = legacy_bending_target(Float32(inv(sqrt(Float64(c.young)))),
            frame[1][3],Float32(a.realized),c.conicity/Float32(a.realized))
        previous_diameter = c.organ_diameter
        id = Int(a.first_organ)
        while id != 0
            organ = tree.organs[id]
            # Constant active laws can still mature dimensions by distance.
            distance = Int(a.tests-organ.rank-1)
            len = c.organ_length*maturation(distance,c.length_lag,c.length_zone,c.length_ratio)
            diameter = c.organ_diameter*maturation(distance,c.diameter_lag,c.diameter_zone,c.diameter_ratio)
            if organ.rank != 0
                main = unit(frame[1]); frame = (main,frame[2],frame[3])
                z = clamp(main[3],-1.0f0,1.0f0)
                gap = max(2.0f0*(z-target),0.0f0)
                taper = 1.0f0-c.conicity/Float32(a.realized)*Float32(organ.rank)
                # In this subset a GU contains tests_per_gu real organs,
                # except the first clipped GU on an immediate axis.
                gu_size = a.gu_count == 1 ? a.realized :
                    (organ.gu == 0 && a.parent != 0 ?
                        max(1,round(Int,(min(a.birth+a.duration,tree.axes[a.parent].gu_end)-a.birth)/a.dt)) : c.tests_per_gu)
                angle = Float32(sqrt(Float64(gap))/(sqrt(Float64(c.young))*Float64(taper*taper))/gu_size)
                organ.rank > trunc(Int,abs(c.inflexion)*a.realized)-1 && (angle = -angle)
                frame = bend(frame,-angle)
            end
            tip = add(base,scale(frame[1],len))
            bottom = organ.rank == 0 ? diameter : previous_diameter
            tree.organs[id] = NativeOrgan(organ.axis,organ.rank,organ.gu,organ.gu_rank,
                organ.next,organ.birth,len,diameter,bottom,base,tip,frame)
            previous_diameter = diameter
            base = tip
            id = Int(organ.next)
        end
    end
    tree.geometry_complete = true
    return tree
end

function simulate(config::NativeConfig,stage::Real;geometry=true,kwargs...)
    tree = initialize(config;kwargs...)
    advance_to!(tree,stage)
    geometry && geometry!(tree)
    return tree
end
run(fpa::AbstractString,stage::Real;kwargs...) = simulate(compile_parameters(fpa),stage;kwargs...)

"""Unmeasured public observation boundary; IDs are local arena ordinals."""
function observations(tree::NativeTree;geometry=tree.geometry_complete)
    geometry && !tree.geometry_complete && throw(ArgumentError("geometry! must run before geometry observations"))
    axes = [Dict{String,Any}("axis_id"=>i,"parent_axis_id"=>Int(a.parent),
        "bearer_test_index_zero_based"=>Int(a.bearer_test),
        "nature"=>a.parent==0 ? 0 : tree.config.lateral_nature,
        "lp_index_zero_based"=>0,"whorl_slot_zero_based"=>Int(a.slot),
        "whorl_size"=>Int(a.whorl_size),"phy_age_initial"=>a.age,
        "growth_unit_count"=>Int(a.gu_count),"realized_count"=>Int(a.realized),
        "test_count"=>Int(a.tests),"birth_time"=>a.birth)
        for (i,a) in enumerate(tree.axes)]
    organs = geometry ? [Dict{String,Any}("axis_id"=>Int(o.axis),
        "axis_internode_index_zero_based"=>Int(o.rank),
        "base"=>Float64[o.base...],"tip"=>Float64[o.tip...],
        "length"=>Float64(o.length),"diameter_bottom"=>Float64(o.diameter_bottom),
        "diameter_top"=>Float64(o.diameter_top)) for o in tree.organs] : Dict{String,Any}[]
    sort!(organs;by=o->(o["axis_id"],o["axis_internode_index_zero_based"]))
    return Dict{String,Any}("axes"=>axes,"organs"=>organs,
        "development_time"=>tree.development_time,
        "last_event_time"=>tree.last_event_time,
        "counts"=>Dict("axes"=>length(axes),"realized"=>length(tree.organs),
        "tests"=>sum(a.tests for a in tree.axes),"geometry_organs"=>length(organs),
        "processed_events"=>tree.processed_events))
end
end
