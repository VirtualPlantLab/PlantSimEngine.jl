"""
Experimental native AMAPSim architecture engine.

This development module keeps MTG/PSE materialization outside growth. It uses
source-compatible native LP64 sampling and retains an independent geometry
parameter table so repeated geometry updates use the qualified source precision.
The ordinary AMAPSim package runtime remains the default.
"""
module NativeAMAP
import AMAPSim
include("core.jl")
include("parameters.jl")
include("engine.jl")
include("geometry_primitives.jl")
include("geometry_scalars.jl")
include("geometry_bending.jl")
include("geometry.jl")
include("random.jl")
include("legacy_parameters.jl")
include("growth_control.jl")

export NativeModel, simulate, advance_to!, geometry!, observations
export NativeGrowthIntent, GrowthControl, pending_growth

"""Owned native arenas and their source-precision analytic-geometry parameters."""
struct NativeModel{P,G}
    plant::P
    geometry_parameters::G
end

function NativeModel(parameters; seed::Integer=1)
    growth = NativeAMAPScientificCore.compile_parameters(parameters)
    geometry = NativeAMAPLegacyParameters.compile_parameters(parameters)
    plant = NativeAMAPPlantEngine.initialize(growth,
        NativeAMAPLegacyRNG.ObservedRNG(seed); compiled=true)
    return NativeModel(plant, geometry)
end
NativeModel(fpa::AbstractString; kwargs...) =
    NativeModel(AMAPSim.read_parameters(fpa); kwargs...)

"""Recompute native analytic cones and all three placement-frame vectors."""
function geometry!(model::NativeModel; observation_times=nothing)
    NativeAMAPPlantEngine.geometry!(model.plant;
        geometry_parameters=model.geometry_parameters,
        geometry_draws=NativeAMAPLegacyRNG.geometry_draws(model.plant),
        observation_times)
    return model
end

"""Advance the actual event queue and optionally refresh analytic geometry.

Pass an optional per-plant `GrowthControl` to quote and settle each organ while
retaining refused preparations. Its original event times can catch up to this
outer horizon. Without a control, the ordinary native dispatcher is used.
"""
function advance_to!(model::NativeModel, horizon::Real;
    geometry::Bool=true, max_events::Integer=10_000_000,
    growth_control::Union{Nothing,GrowthControl}=nothing)
    if growth_control===nothing
        NativeAMAPPlantEngine.advance_to!(model.plant,horizon;max_events=max_events)
    else
        _advance_with_growth_control!(model.plant,horizon,growth_control;max_events=max_events)
    end
    geometry && geometry!(model)
    return model
end

"""Construct a fresh model, advance growth and retain its analytic geometry."""
function simulate(input, horizon::Real; seed::Integer=1,
    geometry::Bool=true, max_events::Integer=10_000_000,
    growth_control::Union{Nothing,GrowthControl}=nothing)
    model = NativeModel(input; seed=seed)
    return advance_to!(model,horizon;geometry=geometry,max_events=max_events,
        growth_control=growth_control)
end

"""Export final scientific observations; serialization is outside engine clocks."""
observations(model::NativeModel; kwargs...) =
    NativeAMAPPlantEngine.observations(model.plant; kwargs...)

include("local_development.jl")
include("organ_growth.jl")
include("management.jl")

export LocalDevelopment, advance_development!, axis_development, axis_development_time
export development_observation_times, OrganGrowthState, OrganDimensions
export refresh_potential!, project_realized!, copy_potential_to_realized!, cut_axis!
end
