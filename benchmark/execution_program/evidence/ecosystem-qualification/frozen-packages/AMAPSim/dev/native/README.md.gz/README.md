# Native architecture engine experiments

This directory contains the first validated native Julia engine for AMAPSim
architecture and analytic geometry. Its growth loop uses typed axes, contiguous
organ records, integer links and a binary event heap. It creates no MTG nodes,
PSE objects, registry statuses or geometry-view copies during growth.

Run the shipped deterministic example from a checkout, using Julia through
Kaimon:

```julia
using AMAPSim
include(joinpath(pkgdir(AMAPSim), "dev", "native", "core.jl"))
input = joinpath(pkgdir(AMAPSim), "test", "fixtures", "native_arena", "branch46.fpa")
plant = NativeAMAPCore.run(input, 1.0)
summary = NativeAMAPCore.observations(plant)
summary["counts"]                 # 3 axes, 46 organs
plant.organs[1].frame              # all three raw Float32 basis vectors
```

The stochastic native arena has a separate entry point for original species:

```julia
using AMAPSim
include(joinpath(pkgdir(AMAPSim), "dev", "native", "native.jl"))
input = joinpath(pkgdir(AMAPSim), "test", "fixtures", "native_originals", "merisier.fpa")
model = NativeAMAP.NativeModel(input; seed=1)
NativeAMAP.advance_to!(model, 1.0)
NativeAMAP.advance_to!(model, 2.0)
NativeAMAP.observations(model)["counts"]
```

This engine stores axes, GUs, test sites and organs in typed index arenas; its
mutable organ records are referenced by typed vectors. It reuses the pure
botanical kernels, with concrete compiled parameter tables, source-compatible
LP64 random sampling, first-GU timing, retrospective branching and pruning.
The model retains separate growth and source-precision geometry tables, so
later display updates use the same arithmetic policy. Geometry does not consume
the architectural stream. This is an experimental core, without automatic MTG
or PSE boundary materialization; the ordinary package runtime remains default.

The optional [model-driven PlantSimEngine boundary](PSE.md) calls this core at
plant coupling steps. Native symbols are mapped explicitly to PSE scales, and
only entities selected by declared applications are registered. Its separate
`pse.jl` entry point preserves native botanical ownership and the package default.
The [two execution modes](MODES.md) distinguish reference architectural
development from PSE-controlled structure–function growth. Coupled mode adds
sparse local axis clocks, separate potential/realized dimensions, replaceable
PSE demand/allocation/expansion models and boundary management commands.
The optional [light and carbon supply example](PHYSIOLOGY.md) connects that
boundary to ArchimedLight and PlantBiophysics with signed carbon accounting.
Optional [organ resource control](CARBON.md) prepares each intention once and
supports selective refusal and settlement. The first PSE carbon example makes
manual model calls per organ; its measured cost is separate from a cheap native
policy and the ordinary no-policy path. The [cached carbon policy](FAST_CARBON.md)
instead prepares fixed construction costs and cumulative supply at each PSE
boundary, then quotes and settles organs directly in the native loop.

The original FPA tests retain independent C++ architecture digests and all
surviving organ geometry at stage 2, plus source integer-age-limit regressions.
Four original-species workloads now pass the same complete output gate and
the requested 1.5x C++ ceiling:

| Original case | Julia CPU ms | C++ CPU ms | Julia / C++ |
| --- | ---: | ---: | ---: |
| Rauh 8 | 204.452 | 364.726 | 0.561 |
| Rauh 14 | 1,462.086 | 6,522.381 | 0.224 |
| Merisier 6 | 17.547 | 15.134 | 1.159 |
| Merisier 20 | 812.517 | 1,798.451 | 0.452 |

Seven fresh warm Julia simulations and seven fresh C++ processes per case
include fresh configuration/RNG/arena setup, complete growth and analytic
geometry. Parsing, loading/JIT, export, mesh tessellation, light and rendering
are outside this target. Complete architecture and every organ's dimensions,
endpoints and three raw frame vectors pass unchanged tolerances; see the
[original-species qualification](../evidence/native-originals-2026-10-28/README.md).

The C++ comparison completes growth before final geometry. Native geometry
preserves growth RNG state; it does not reproduce the extra random word that
the C++ manager consumes after geometry. C++-identical continuation after
intervening C++ geometry calls is outside this gate.

The explicit initialization guard requires zero initial dormancy and the
current native product lane uses Internode LPs. These qualifications do not
establish every historical FPA mechanism or the coupled/rendered pipeline.

The scalar `branch46.fpa`, `depth3.fpa` and `depth4.fpa` fixtures are authored
computational cases, not calibrated species.
The larger shipped `depth3.fpa` generates 4,993 axes and 17,056 organs. It also
exercises nested attachment and zero-organ axes born exactly at the horizon.

`core.jl` supports a guarded constant-parameter, deterministic lane. The shipped
stage-1 branching cases define this checkpoint's qualified scope; later first-GU
conversion, pruning and varying/stochastic laws require the separate full
engine. It rejects unsupported active mechanisms rather than simplifying real Rauh or Merisier
silently. The separate varying-parameter/stochastic engine above is qualified
on the original cases listed; this first scalar checkpoint does not replace the
package's default engine or promise complete FPA coverage.

The independent C++ reference checks cover the complete rooted architecture,
physiological ages, birth times, growth-unit/test/product counts and final
analytic geometry. All bases, tips, dimensions and three raw frame vectors
pass the declared `1e-6 + 1e-6 * abs(reference)` bound. No alignment, fitting or
widened tolerance is used. Tests retain complete architecture hashes and
selected independent geometry checkpoints; the benchmark qualification checked
every organ in the larger workloads. Numerical C++ guards, including its
near-vertical attachment offset, are reproduced explicitly.

Seven fresh warm Julia runs and seven fresh C++ processes per case qualified
these CPU measurements on the same host. Fresh configuration conversion,
arena/queue initialization, growth and retained analytic geometry are charged;
parsing, loading/JIT, process startup, validation and export are separate.

| Matched workload | Julia CPU | C++ CPU | Julia / C++ |
| --- | ---: | ---: | ---: |
| 3 axes / 46 organs | 0.365 ms | 0.285 ms | 1.281 |
| 4,993 axes / 17,056 organs | 2.344 ms | 113.964 ms | 0.0206 |
| 34,113 axes / 86,944 organs | 11.857 ms | 2,718.076 ms | 0.00436 |

These are implementation/algorithm results on deterministic workloads. The
historical C++ scheduler uses sorted-vector insertion; the native Julia engine
uses a binary heap. Julia also avoids repeated full-axis dimensional scans and
framework bookkeeping. The table does not establish general stochastic
Rauh/Merisier performance, cold application latency, mesh tessellation, rendering,
light or carbon-coupling performance. Native cones and full placement frames are
computed on both sides; transformed triangle meshes are not requested.

The existing FPA reader is reused in the cold input path. MTG/PSE materialization
and functional coupling remain explicit integration boundaries, not work hidden
inside a claimed core speedup. The deterministic proof does not claim matching
internal PRNG states; source-compatible stochastic sampling is a separate gate.

The geometry ports in `core.jl` retain their original AMAPsim attribution and
LGPL-3.0-or-later notice. The applicable license texts are included here; this
does not change the surrounding package's MIT license.
