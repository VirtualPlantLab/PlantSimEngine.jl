# SPDX-License-Identifier: LGPL-3.0-or-later
# Ported from AMAPsim Include/UtilMath.h::bending and
# GeomBrancAMAP.cpp::flexionAtNode, copyright Jean-Francois Barczi
# and AMAPsim contributors, 1995-2018. This file does not relicense its host.
"""Source standalone Float32 libm/bending, qualified by independent grids."""
module NativeAMAPGeometryBending
const PI32=Float32(π)
const SOURCE_LIBM=Sys.isapple() ? "/usr/lib/libSystem.B.dylib" : "libm.so.6"
@inline source_cos(x::Float32)=ccall((:cosf,SOURCE_LIBM),Float32,(Float32,),x)
@inline source_sin(x::Float32)=ccall((:sinf,SOURCE_LIBM),Float32,(Float32,),x)
@inline source_acos(x::Float32)=ccall((:acosf,SOURCE_LIBM),Float32,(Float32,),x)
@inline source_asin(x::Float32)=ccall((:asinf,SOURCE_LIBM),Float32,(Float32,),x)
@inline source_sqrt(x::Float32)=sqrt(x)

function bending(young::Float32,dirz::Float32,length::Float32,conicity::Float32)::Float32
    dirz=clamp(dirz,-1.0f0,1.0f0)
    theta=source_acos(dirz)
    amin=0.0f0;amax=PI32-theta
    h=abs(length/fma(-conicity,length,1.0f0))
    coefficient=young*h*source_sqrt(abs(dirz))
    score=coefficient*200.0f0/PI32
    angle=if 1.553<theta<1.588
        young*young*h*h/2.0f0
    else
        source_sin(theta)*Float32(1.0-Float64(source_cos(coefficient)))/
            source_cos(coefficient)/abs(dirz)
    end
    score<=40.0 && angle<=0.2 && return source_cos(angle+theta)
    while amax-amin>0.5f0*Float32(0.0174533)
        angle=(amax+amin)/2.0f0
        omega=0.0f0;integrated=0.0f0;increment=1.0f0;iteration=0
        while omega<angle && increment!=0.0 && iteration<500
            increment=1.414f0*young*source_sqrt(abs(source_cos(theta+omega)-source_cos(theta+angle)))
            omega+=increment;integrated+=1.0f0;iteration+=1
        end
        if integrated<=h-1.0f0
            amin=angle
        else
            amax=angle
        end
    end
    return source_cos(fma(amin+amax,0.5f0,theta))
end
@inline terminal_increment(dirz::Float32,angle::Float32,denominator::Float32)::Float32 =
    (source_asin(clamp(dirz,-1.0f0,1.0f0))-angle)/denominator
function flexion_increment(young::Float32,conicity::Float32,rank::Int,
    dirz::Float32,target::Float32,organ_count::Int)::Float32
    gap=2.0f0*(clamp(dirz,-1.0f0,1.0f0)-target)
    taper=fma(-conicity,Float32(rank),1.0f0)
    multiplier=1.0f0/(source_sqrt(young)*(taper*taper))
    gap<0.0 && (gap=0.0f0)
    return (multiplier*source_sqrt(gap))/Float32(organ_count)
end
@inline fromhex(value)=reinterpret(Float32,parse(UInt32,replace(String(value),"0x"=>"");base=16))
@inline hex(value::Float32)=string(reinterpret(UInt32,value);base=16,pad=8)
function validate_oracle(records)
    checked=0;differences=NamedTuple[];cases=Dict{String,Int}()
    for row in records
        kind=String(row["kind"]);cases[kind]=get(cases,kind,0)+1
        observed=if kind=="bending_target"
            bending(fromhex(row["young"]),fromhex(row["vertical"]),fromhex(row["length"]),fromhex(row["conicity"]))
        elseif kind=="terminal_increment"
            terminal_increment(fromhex(row["vertical"]),fromhex(row["straightening"]),fromhex(row["denominator"]))
        elseif kind=="node_increment"
            flexion_increment(fromhex(row["young"]),fromhex(row["conicity"]),Int(row["rank"]),
                fromhex(row["vertical"]),fromhex(row["target"]),Int(row["gu_organs"]))
        else
            error("unsupported bending oracle row $kind")
        end
        checked+=1;actual=hex(observed);expected=lowercase(replace(String(row["output"]),"0x"=>""))
        if actual!=expected
            length(differences)<20 && push!(differences,(kind=kind,case=Int(row["case"]),expected=expected,observed=actual))
        end
    end
    return (checked_bits=checked,cases=cases,first_mismatches=differences,passed=isempty(differences))
end
end
