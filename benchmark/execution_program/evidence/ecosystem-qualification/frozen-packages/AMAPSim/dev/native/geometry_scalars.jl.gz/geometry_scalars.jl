# SPDX-License-Identifier: LGPL-3.0-or-later
# Scalar laws ported from AMAPsim GeomBrancAMAP.cpp and Include/UtilMath.h.
# Copyright Jean-Francois Barczi and AMAPsim contributors, 1995-2018.
# This prototype header applies to this file, not the surrounding package.
"""Float32 source scalar laws, qualified by independent nonresidual grids."""
module NativeAMAPGeometryScalars
const PI32 = Float32(π)
const TWO_PI32 = Float32(2π)
const SOURCE_LIBM = Sys.isapple() ? "/usr/lib/libSystem.B.dylib" : "libm.so.6"
@inline source_log10(value::Float32) = ccall((:log10f,SOURCE_LIBM),Float32,(Float32,),value)
@inline source_pow(value::Float32,exponent::Float32) = ccall((:powf,SOURCE_LIBM),Float32,(Float32,Float32),value,exponent)

@inline function wrapped(angle::Float32)::Float32
    multiple=trunc(Int,angle/TWO_PI32)
    multiple==0 ? angle : fma(-Float32(multiple),TWO_PI32,angle)
end
@inline function random_angles(insertion::Float32,phyllotaxy::Float32,
    randomness::Float32,draw::Float32)
    centered=Float32(0.5-Float64(draw))
    return (insertion*fma(centered,randomness,1.0f0),
        fma(centered,randomness*PI32,phyllotaxy))
end
@inline young_effective(young::Float32,randomness::Float32,draw::Float32)::Float32 =
    young*fma(randomness/10.0f0,draw,1.0f0)
@inline taper(conicity::Float32,position::Float32)::Float32 =
    fma(-conicity,position,1.0f0)

"""GeomBrancAMAP::axeInsertionOn mode5 scalar azimuth law."""
function pseudo_plagiotropic_phyllotaxy(phy::Float32,vertical::Float32)::Float32
    compression = if abs(vertical) < 1.0e-4
        0.0f0
    else
        exponent = ceil(abs(source_log10(abs(vertical))))
        abs(source_pow(vertical,exponent))
    end
    phy = Float32(rem(Float64(phy),2.0*Float64(PI32)))
    phy < 0 && (phy += 2*PI32)
    if phy < Float64(PI32)/2.0
        phy *= compression
    elseif phy < 3.0*Float64(PI32)/2.0
        phy -= PI32
        phy = fma(phy,compression,PI32)
    else
        phy = Float32(Float64(phy)-2.0*Float64(PI32))
        phy *= compression
    end
    return phy
end

"""UtilMath::interpole_lineaire, including its reversed source endpoints."""
function reversed_linear(code::Int,bound1::Int,value1::Float32,bound2::Int,
    value2::Float32,position::Int)::Float32
    bound1 == bound2 && return value2 > value1 ? value2 : value1
    if bound2 < bound1
        bound1,bound2 = bound2,bound1
        value1,value2 = value2,value1
    end
    position < bound1 && return code != 0 ? value2 : 0.0f0
    position > bound2 && return code != 0 ? value1 : 0.0f0
    coefficient = Float32(position-bound1)/Float32(bound2-bound1)
    return fma(1.0f0-coefficient,value2,coefficient*value1)
end

@inline fromhex(value) = reinterpret(Float32,parse(UInt32,replace(String(value),"0x"=>"");base=16))
@inline hex(value::Float32) = string(reinterpret(UInt32,value);base=16,pad=8)
function validate_oracle(records)
    checked=0;differences=NamedTuple[];cases=Dict{String,Int}()
    function compare(row,field,observed::Float32)
        wanted=lowercase(replace(String(row[field]),"0x"=>""));actual=hex(observed)
        checked+=1
        if actual!=wanted
            length(differences)<20 && push!(differences,(kind=String(row["kind"]),
                case=Int(row["case"]),field=field,expected=wanted,observed=actual))
        end
    end
    for row in records
        kind=String(row["kind"])
        cases[kind]=get(cases,kind,0)+1
        if kind=="pseudo_plagio"
            compare(row,"output",pseudo_plagiotropic_phyllotaxy(
                fromhex(row["phyllotaxy"]),fromhex(row["vertical"])))
        elseif kind=="reversed_linear"
            compare(row,"output",reversed_linear(Int(row["code"]),Int(row["bound1"]),
                fromhex(row["value1"]),Int(row["bound2"]),fromhex(row["value2"]),Int(row["position"])))
        elseif kind=="wrap_angle"
            compare(row,"output",wrapped(fromhex(row["angle"])))
        elseif kind=="random_angles"
            insertion,phyllotaxy=random_angles(fromhex(row["insertion"]),
                fromhex(row["phyllotaxy"]),fromhex(row["randomness"]),fromhex(row["draw"]))
            compare(row,"insertion_output",insertion)
            compare(row,"phyllotaxy_output",phyllotaxy)
        elseif kind=="young_effective"
            compare(row,"output",young_effective(fromhex(row["young"]),
                fromhex(row["randomness"]),fromhex(row["draw"])))
        elseif kind=="conicity_taper"
            result=taper(fromhex(row["conicity"]),Float32(row["rank"]))
            compare(row,"taper",result)
            compare(row,"squared",result*result)
        else
            error("unsupported scalar oracle row $kind")
        end
    end
    return (checked_bits=checked,cases=cases,first_mismatches=differences,passed=isempty(differences))
end
end
