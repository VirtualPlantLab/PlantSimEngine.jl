# Model-driven PlantSimEngine boundary

The native engine can keep its fast event loop while PlantSimEngine composes
models at plant and organ scales. This experimental adapter registers native
entities only when an application declaration selects them. Mapping a symbol
alone does not register objects.

The optional [cached carbon policy](FAST_CARBON.md) prepares a fixed construction
rule and cumulative supply once per plant and step. Native allocation then
funds or defers individual organs without per-organ PSE calls. The
[manual-call reference](CARBON.md) remains available for explicit applications
and full demand/allocation histories.

Load the two development modules from a checkout, through Kaimon:

```julia
using AMAPSim, PlantSimEngine
include(joinpath(pkgdir(AMAPSim), "dev", "native", "native.jl"))
include(joinpath(pkgdir(AMAPSim), "dev", "native", "pse.jl"))
```

A small observer illustrates the boundary. This copies a dimension for testing;
it is not a physiological model or biological calibration.

```julia
@process "dimension_observation" verbose=false
struct DimensionObservation <: AbstractDimension_ObservationModel end
PlantSimEngine.inputs_(::DimensionObservation) = (Length=Required(Real),)
PlantSimEngine.outputs_(::DimensionObservation) = (length_seen=0.0,)
function PlantSimEngine.run!(::DimensionObservation, status, environment, constants, context)
    status.length_seen = status.Length
    return nothing
end

input = joinpath(pkgdir(AMAPSim), "test", "fixtures", "native_originals", "merisier.fpa")
plant = NativeAMAPPSE.NativePlant(:tree, input;
    seed=1, development_increment=0.5,
    product_symbols=Dict("feuilles" => :Leaf))
model = NativeAMAPPSE.scenario((plant,);
    applications=(
        ModelSpec(DimensionObservation(); name=:dimensions, on=Many(scale=:IN)),
    ),
    scales=(Internode=:IN, GrowthUnit=:GU, Axis=:Axis, Leaf=:Leaf),
    properties=(Length=:length,))
simulation = PlantSimEngine.run!(model; steps=2, outputs=:none)
lengths = [object.status.length_seen for object in model_objects(model; scale=:IN)]
```

Only matching internodes become PSE objects. The native foliar program keeps
growing, but no `:Leaf`, `:GU` or `:Axis` object is registered in this scenario.
To select leaves instead, put `on=Many(scale=:Leaf)` on an actual model. To select
growth units, put `on=Many(scale=:GU)`. Native axes, GUs and products remain in
the native arenas whether or not they are exposed.

`product_symbols` explicitly maps exact FPA lateral-production names or
one-based LP indices to semantic product symbols. It changes the projection
role of actual native products, not the botanical program or RNG. Numeric
Nature 2 alone does not establish a Leaf role. The primary axis keeps its
Internode role. `scales` maps semantic symbols to PSE scale names, optionally
with a kind, for example `(Internode=(scale=:IN, kind=:internode),)`.

## Properties follow declared model needs

The adapter examines application declarations before any organs exist. It
preserves scale, kind, species, typed identity and supported plant/instance
scope restrictions. Matching consumers request native properties; the adapter
publishes only supported requested fields that lack another canonical writer.
An explicit source application remains the selected producer. Partial external
ownership that cannot be represented by this first adapter is rejected.
Native property discovery resolves relative input and distributed-output scopes
from existing execution roots. Relative scopes of unborn organ consumers or producers are rejected;
use an explicit scene or plant scope for cross-object inputs. Unscoped inputs
retain PSE's defaults: `Self()` for ordinary objects and `SceneScope()` for scenes.
Relation-based property discovery is also rejected. Explicit external-producer
bindings remain managed by PSE.

Inspect the available fields with `NativeAMAPPSE.native_properties()`:

| Native entity | Examples of available native fields |
| --- | --- |
| Axis | `initial_physiological_age`, birth time, order, nature, initial phyllotaxy |
| GrowthUnit | Reference age, index, test/product counts, timing |
| Internode or explicitly classified product | Length, top/bottom diameters, base, tip, raw frame, ranks and native indices |

`properties=(Length=:length,)` aliases an output name to an existing native
field. It does not change values or units. Native numerical representation and
source units are retained; this prototype does not infer PlantBiophysics unit,
area-basis or temporal contracts. Put explicit scientific conversions in models
when connecting contracted components.

There is no automatic leaf `area` export. A foliar program's native analytic
cone does not establish its lamina or assimilation area. A real area/geometry
model may produce `area`, and PSE then connects its consumers normally. An
unsupported required field without a real producer or explicit initial-state
factory is an error. The optional `status_factory(plant_id, symbol, slot, record)`
can supply genuine initial values; it must treat the native record as read-only.

Properties are published by a plant-level distributed application per exposed
native symbol, not an extra geometry application per organ. A `native_revision`
input orders each publisher after native growth. Distributed target views are
acquired again after lifecycle refresh. Each PSE organ contains the properties
and model state it needs; it does not receive a copy of all botanical attributes.

## State, identity and lifecycle

Each plant owns an independently initialized native model and RNG in a private
Status input. The fixed architecture model is shared. Use
`NativeAMAPPSE.native_state(model, :tree).native` for live inspection. Do not
call `final_state` on that plant at every interactive frame: PSE intentionally
deepcopies the complete Status, including the native arenas. Ordinary declared
outputs do not include this private state.

A projected ID combines the enduring plant ID, semantic entity kind and raw
native arena slot. Native export ordinals are not identities. Surviving PSE
Object and Status instances persist; pruning removes actual disappeared
objects through PSE lifecycle APIs. Geometry uses small immutable snapshots,
so an external model cannot mutate the native arena through Object.geometry
and old/new spatial invalidation values remain distinct. Axis/GU geometry is
`nothing` until an explicit spatial representation is defined.

The first projection computes desired membership from the selected typed
arenas at each coupling boundary. Registration/removal and changed-geometry
updates are selective, but the current membership comparison still scans the
selected domains; it is not claimed to be constant-time in the number of changes.
The empty-exposure path skips this work entirely.

Scene, plant and mounted-instance scopes are supported. Arbitrary scopes rooted
inside a native hierarchy require additional topology support and are rejected
explicitly. The exposed hierarchy uses the nearest exposed native ancestor.
PSE lifecycle scheduling still applies: a newborn may run applications remaining
in that timestep; applications already executed do not rerun automatically.
Native property dependencies provide explicit producer ordering. The initial
architecture declaration is first only as the stable-order default for
otherwise independent applications.

## Time and next coupling stages

The [two-mode guide](MODES.md) adds `mode=:coupled`: PSE supplies a development
rate and sparse axis overrides on a common physical timeline. Optional
structure–function models compute demand from nominal dimensions, allocate
carbon and realize expansion before final geometry/property synchronization.
Potential properties are available before organ demand; actual properties
follow expansion. `mode=:reference` preserves the existing interface below.

`development_increment` is a real PSE input. The per-plant constructor value
initializes it; another plant model can produce it through ordinary PSE
bindings. The value is a virtual AMAPsim development increment, not an implicit
conversion from an hour, a day or temperature. A physical-time/development-time
model must state that relationship explicitly.

The wrapper advances native growth and optionally recomputes analytic geometry
once at each chosen coupling boundary. Optional [organ-wise resource control](CARBON.md)
connects named PSE demand/allocation calls to native prepare/realize/defer and
postcommit settlement. Its example supplies mass, cost and cumulative carbon
explicitly. Light/assimilation/energy-balance models and PlantGeom mesh
materialization remain subsequent integration stages. This file does not
replace the existing coupled visualizer or the package's default runtime.

The matched benchmark in `benchmark/native_pse_benchmark.jl` compares direct
native calls and the PSE wrapper at identical outer steps, geometry cadence,
final architecture, RNG and pending queue. Scene setup and PSE preparation are
reported separately from warm execution. The organ-model variant additionally
charges registration, distributed publication and an actual declared consumer;
its costs are not attributed to the wrapper alone.

On the four-boundary Rauh 8 case, five warm repetitions measured about 0.203 s
for direct native execution, 0.205 s through PSE without organ applications,
and 1.763 s with a Length consumer on all 16,387 native products. Merisier 6
measured 0.0168, 0.0169 and 0.1380 s respectively. The dense case includes
creating/removing PSE objects and running the declared consumer. It still has
substantial boundary costs; the small plant-level wrapper overhead does not
establish negligible overhead when thousands of organ objects are exposed.

These dense results require the isolated PSE structural-delta intersection
correction described in the [measurement record](../evidence/native-pse-boundary-2026-10-28/README.md).
With unmodified PSE `3d1e9e3f`, Rauh took 5.228 s and Merisier 0.302 s.
The adapter itself uses public PSE lifecycle APIs in both versions.
