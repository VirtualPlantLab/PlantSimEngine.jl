# Architectural development and structure–function growth

The experimental native engine has two entry points. Use the reference mode
to reproduce AMAPsim architectural development at successive virtual ages.
Use the coupled mode when PlantSimEngine models control developmental rates
and realized growth. The package's default runtime is unchanged; the optional
coupled visualizer uses this native boundary.

Run these checkout examples through Kaimon. The rates, density, conversion and
cost used below are demonstration values, not a calibration of Merisier.

## Reference architecture at different ages

```julia
using AMAPSim
include(joinpath(pkgdir(AMAPSim), "dev", "native", "native.jl"))
input = joinpath(pkgdir(AMAPSim), "test", "fixtures", "native_originals", "merisier.fpa")
reference = NativeAMAP.NativeModel(input; seed=1)
for age in (0.5, 1.0, 2.0)
    NativeAMAP.advance_to!(reference, age)
end
@assert reference.plant.time == 2.0
```

This uses the original native dispatcher and nominal analytic geometry. It
does not install local clocks or a biomass/allocation model. The existing
`NativeAMAPPSE.scenario(...; mode=:reference)` remains the default PSE wrapper
for that same engine, including its previous `development_increment` interface.

## PSE controls development and realized growth

The following composition uses four explicit scientific models: a constant
development rate, a geometric construction demand, a sequential allocation
rule and an isometric expansion law. Each can be replaced by another PSE
model with the appropriate ports and scientific contracts.
The [optional physiology example](PHYSIOLOGY.md) replaces prescribed carbon
supply with ArchimedLight and PlantBiophysics net leaf exchange.

```mermaid
flowchart LR
    C["PSE: rates and management"] --> N["AMAPSim: development and potential organs"]
    N --> D["PSE: construction demand"]
    D --> A["PSE: allocation"]
    A --> E["PSE: realized expansion"]
    E --> G["Actual geometry and selected PSE objects"]
```

```julia
using PlantSimEngine
include(joinpath(pkgdir(AMAPSim), "dev", "native", "pse.jl"))
const A = NativeAMAPPSE
plant = A.NativePlant(:tree, input; seed=1,
    product_symbols=Dict("feuilles" => :Leaf))
clock = ModelSpec(A.ConstantDevelopmentRate(; rate_per_second=0.5);
    name=:development, on=Many(scale=:Plant))
growth = (
    demand=A.FrustumGrowthDemand(; density_gDM_per_cm3=0.5,
        construction_cost_gC_per_gDM=0.5, cm_per_native_unit=0.01),
    allocation=A.SequentialGrowthAllocation(; initial_reserve_gC=0.0),
    expansion=A.IsometricExpansion(),
)
coupled = A.scenario((plant,); mode=:coupled,
    applications=(clock,), growth_models=growth,
    environment=[(duration=1.0, duration_seconds=1.0, cumulative_carbon_supply_gC=supply)
        for supply in (0.0, 0.01, 0.1, 1.0)])
simulation = PlantSimEngine.run!(coupled; steps=1, outputs=:none)
status = model_status(coupled, :tree)
state = A.native_state(coupled, :tree)
@assert iszero(status.spent_carbon_gC)

# Pause only the primary apical clock for the next physical second.
attained = NativeAMAP.axis_development(state.development, 1)
status.axis_development_rates = Dict(1 => 0.0)
step!(simulation)
@assert NativeAMAP.axis_development(state.development, 1) == attained

# Removing the override restores the default rate without catching up the lag.
status.axis_development_rates = Dict{Int,Float64}()
PlantSimEngine.continue!(simulation; steps=2)
@assert state.development.physical_time == 4.0
@assert NativeAMAP.axis_development(state.development, 1) == attained + 1.0
@assert status.credited_carbon_supply_gC ≈
    status.remaining_carbon_gC + status.spent_carbon_gC
@assert status.living_dry_mass_gDM + status.removed_dry_mass_gDM ≈
    status.spent_carbon_gC / growth.demand.construction_cost_gC_per_gDM
@assert isempty(model_objects(coupled; scale=:Leaf))
```

The direct input assignment illustrates the protocol. A regular PSE producer
can instead write `axis_development_rates`, with
`A.AXIS_DEVELOPMENT_RATES_CONTRACT`. It supplies a complete sparse dictionary
for each exchange: an omitted axis uses the plant default, and zero suspends
its future developmental progress. `development_rate` is a required input in
virtual stages per physical second. No conversion from FPA stages to calendar
time is inferred.

The PSE timeline and native physical exchange use the same duration. For plain
NamedTuple environments, the adapter fills a missing PSE `duration` from
`duration_seconds`; when both are supplied, they must agree. This prototype
uses PSE's fixed base cadence. Local rates can vary at each exchange without
changing that physical cadence.

These clocks currently target the one apical state of each existing native
axis. New axes inherit the plant default rate, not their parent's override;
they retain their native birth phase. A separate dormant-axillary-meristem
clock is not implemented. Rate changes preserve attained local development,
and the scheduler converts pending local thresholds to common physical
deadlines. Changing rates does not redraw botanical events.

At the first GU initialization, the bearer's forecast end is converted into
the child's developmental coordinate and retained as an initial constraint.
Later rate changes reschedule its execution without rebuilding that botanical
plan. Continuous parent/child co-ending after subsequent differential rate
changes is not implemented. Development and geometry retain the existing
native model's other qualified mechanism limits.

Without `growth_models`, coupled mode computes nominal geometry and introduces
no biomass state. This is the cheap clock-only boundary. With growth models,
native architectural initiation creates potential organ slots first; newly
unfunded organs have zero realized dimensions/mass. This is distinct from the
[earlier whole-organ creation gate](CARBON.md), which remains available in
reference mode. The two allocation mechanisms cannot be enabled together.

## Potential dimensions, demand and expansion

`OrganGrowthState.potential` and `.realized` store separate dimensions for
stable native organ slots. Nominal AMAPsim allometry supplies the current
potential target. The demand model converts solid-frustum volume into dry
mass using explicit cm/native-unit and gDM/cm³ coefficients, then requests
only the positive difference from already constructed mass. It does not
charge the full target on every step. A hollow tube or lamina needs another
model; a native Leaf role still describes the native product geometry and
does not establish a lamina area.

Sequential allocation quotes partial construction in native organ order.
Quoting changes neither organs nor reserves. The expansion model settles a
validated plant/revision-specific batch, updates mass and dimensions, then
reconstructs placement from the realized dimensions. Supply is cumulative
integrated gC; repeating it does not credit it twice.

The example expansion law scales the potential shape isotropically. A smaller
potential mass does not shrink or refund existing tissue. During positive
growth, a changing potential aspect ratio can change individual dimensions;
this is not a guarantee of monotonic elongation/thickening. Geometry retains
native Float32 precision. Neither the FPA nor this example establishes a
calibrated expansion duration, maintenance respiration or lifetime carbon law.

For a different expansion hypothesis, implement an ordinary PSE model and
call `A.realize_growth!(state, allocation_batch, dimension_law)`. The law
receives an immutable demand record, the accepted new mass and previous
dimensions, and returns `NativeAMAP.OrganDimensions`. Shared validation and
accounting do not need to be copied. The model publishes the returned scalar
summary and increments `actual_geometry_revision`. A custom law is responsible
for its own mass/geometry interpretation.

`growth_models=(demand=..., allocation=..., expansion=...)` mounts the three
standard applications. Alternatively, supply explicit `ModelSpec`s through
`applications`, select `realization=:models`, and connect their batch ports.
The final adapter synchronization waits for `actual_geometry_revision` and
checks that the current growth revision was committed. Different plant target
selectors can select different scientific models. For nondefault numeric
types use matching model types; `growth_numeric_type` can specify the shared
state type explicitly.

Declared organ applications can request actual `length`/diameters and
`potential_length`, `potential_diameter_top`, `potential_diameter_bottom`, or
`structural_mass_gDM`. Declared Axis applications can request
`development_time`. Only requested fields are published; these declarations
alone determine which native entities become PSE Objects. Structural mass
and axis development have exported contracts. Native dimensional units remain
explicit rather than acquiring an automatic physiological conversion.

Potential newborn objects and intrinsic/potential properties are made available
after architectural development, before organ demand. Actual geometry and
structural mass are published after expansion. This ordering permits an
organ-scale demand model to contribute to the same exchange's allocation.
`A.OrganDemandCollector` collects compatible per-organ target masses, costs
and native IDs into the existing plant demand batch, subtracting already
committed mass. Its three `Many` inputs must select the same objects in the
same order. The maintained organ-demand bridge test supplies a full example.

Feedback must have an explicit time meaning. A rate controller cannot read
the development time produced by its own future advance in the same explicit
step. It can read previously committed state or use PSE's `PreviousTimeStep`
binding. Likewise a demand model needing prior mass must not create a
same-step dependency on the post-expansion mass publisher. The collector uses
committed pre-expansion mass directly. Algebraic feedback needs an explicit
coupled solver rather than an implicit ordering trick.

## Natural removal and management cuts

Natural pruning uses existing AMAPsim rules. `pruning_clock=:development`
is the reference convention. To let already scheduled post-death/end pruning
delays elapse in physical time despite later developmental arrest, set
`pruning_clock=:physical` and supply a positive `pruning_seconds_per_stage`.
This converts existing FPA delays; it does not invent a lifespan for every
organ or equate meristem arrest with stopped tissue aging.

A management model can write `management_cuts`, a vector of native axis
indices with `A.MANAGEMENT_CUTS_CONTRACT`. Commands apply at the beginning of
the exchange. The public boundary API performs the same whole-axis/subtree cut:

```julia
mass_before_cut = sum(state.organ_growth.structural_mass_gDM)
removed_before = state.organ_growth.removed_dry_mass_gDM
spent_before = state.organ_growth.spent_carbon_gC
result = A.cut_axis!(coupled, :tree, 1)
@assert result.removed
@assert all(axis -> !axis.active, state.native.plant.axes)
@assert isempty(state.native.plant.events)
@assert state.organ_growth.removed_dry_mass_gDM ≈ removed_before + mass_before_cut
@assert state.organ_growth.spent_carbon_gC == spent_before
```

Cuts invalidate future events and remove projected objects through PSE lifecycle
APIs. Removed structural mass is recorded once; construction carbon is not
refunded. Direct boundary commands update native state and object membership
immediately; scalar model outputs update when their canonical PSE application
next executes. Natural remobilization, partial-axis cuts and induced regrowth
are separate model extensions.

A failed native dispatch, geometry commit or unfinished coupled
architecture/expansion/synchronization exchange must be discarded. This is not
a rollback engine: errors in a later PSE model can occur after architecture has
advanced. The guard prevents repeating that partial exchange as if nothing
happened. Existing surviving Object and Status identities remain stable at
successful exchanges.
