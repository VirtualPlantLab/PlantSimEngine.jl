"""
Experimental PlantSimEngine boundary for the native AMAPSim arenas.

Load `native.jl` first, then include this file in the same parent module. Native
growth remains independent of PSE. This adapter projects only entities requested
by declared application targets, at the outer coupling boundary. Native product
roles and scale aliases are explicit; they do not change the native botany.
"""
module NativeAMAPPSE

import AMAPSim
import PlantSimEngine as PSE
import ..NativeAMAP
import ..NativeAMAP: cut_axis!

export NativePlant, scenario, native_state, native_object_id, native_properties
export FixedCarbonPolicy
export ConstantDevelopmentRate, cut_axis!
export FrustumGrowthDemand, SequentialGrowthAllocation, IsometricExpansion
export OrganGrowthDemand, OrganDemandBatch, AllocatedOrganGrowth, OrganAllocationBatch
export realize_growth!
export OrganDemandCollector, ORGAN_TARGET_MASS_CONTRACT
export ORGAN_CONSTRUCTION_COST_CONTRACT, ORGAN_GROWTH_ID_CONTRACT
export DEVELOPMENT_RATE_CONTRACT, AXIS_DEVELOPMENT_RATES_CONTRACT
export MANAGEMENT_CUTS_CONTRACT, COUPLING_DURATION_CONTRACT
export STRUCTURAL_MASS_CONTRACT, AXIS_DEVELOPMENT_TIME_CONTRACT

const _STATE = :_native_pse_state
const _ARCHITECTURE = :native_architecture
const _DEFAULT_SCALES = (Axis=:Axis, GrowthUnit=:GrowthUnit,
    Internode=:Internode, Leaf=:Leaf)
const _AXIS_PROPERTIES = (:native_id, :birth_time, :initial_physiological_age, :nature,
    :order, :reiteration_order, :immediate_order, :phyllotaxy, :active)
const _GU_PROPERTIES = (:native_id, :index, :reference_age, :birth_time,
    :end_time, :duration, :test_count, :realized_count, :active)
const _ORGAN_PROPERTIES = (:native_id, :length, :diameter_top, :diameter_bottom,
    :base, :tip, :frame, :rank, :axis_id, :site_id, :active)
const _GEOMETRY_PROPERTIES = (:length, :diameter_top, :diameter_bottom,
    :base, :tip, :frame)
const _POTENTIAL_PROPERTIES = (:potential_length, :potential_diameter_top,
    :potential_diameter_bottom)
const STRUCTURAL_MASS_CONTRACT = PSE.VariableContract(unit=:g_dry_matter,
    basis=:organ, temporal=:instantaneous, aggregation=:state, extent=:extensive)
const AXIS_DEVELOPMENT_TIME_CONTRACT = PSE.VariableContract(unit=:development_stage,
    basis=:axis, temporal=:instantaneous, aggregation=:state, extent=:intensive)

"""Names of actual native properties; no area or physical-unit conversion is inferred."""
function native_properties(kind::Symbol; coupled=false, growth=false)
    base = kind === :Axis ? _AXIS_PROPERTIES :
        kind === :GrowthUnit ? _GU_PROPERTIES : _ORGAN_PROPERTIES
    kind === :Axis && coupled && return (base..., :development_time)
    kind in (:Axis, :GrowthUnit) && return base
    return growth ? (base..., _POTENTIAL_PROPERTIES..., :structural_mass_gDM) : base
end
native_properties(; kwargs...) = (Axis=native_properties(:Axis; kwargs...),
    GrowthUnit=native_properties(:GrowthUnit; kwargs...),
    Internode=native_properties(:Internode; kwargs...),
    Leaf=native_properties(:Leaf; kwargs...))

"""Stable projection identity, independent of export ordinals and active membership."""
native_object_id(plant_id, kind::Symbol, slot::Integer) =
    PSE.ObjectId((PSE.ObjectId(plant_id).value, kind, Int(slot)))

"""
    NativePlant(id, parameters_or_fpa; seed=1, development_increment=1.0,
        product_symbols=NamedTuple(), species=nothing, kind=:plant,
        status=NamedTuple())

One plant declaration. Each `scenario` creates fresh native arenas and RNG.
`product_symbols` maps one-based LP indices or exact LP names to semantic product
symbols, e.g. `Dict("leaf LP" => :Leaf)`. It reclassifies existing native products
for projection and neither creates extra leaves nor changes the native kernel.
The primary axis retains its Internode role. Development increments use the
native virtual coordinate, not seconds, days, or thermal time.
"""
struct NativePlant{P,D,S}
    id::PSE.ObjectId
    parameters::P
    seed::UInt64
    development_increment::D
    product_symbols::Dict{Int,Symbol}
    species::Union{Nothing,Symbol}
    kind::Symbol
    status::S
end

function _status_values(status)
    status isa PSE.Status && return NamedTuple(status)
    status isa NamedTuple && return status
    status isa AbstractDict && return (; (Symbol(k) => v for (k, v) in pairs(status))...)
    throw(ArgumentError("initial status must be a NamedTuple, Status, or dictionary"))
end

function NativePlant(id, input; seed::Integer=1, development_increment::Real=1.0,
    product_symbols=NamedTuple(), species=nothing, kind=:plant,
    status=NamedTuple())
    isfinite(development_increment) && development_increment >= 0 ||
        throw(ArgumentError("development_increment must be finite and nonnegative"))
    0 <= seed <= typemax(UInt64) || throw(ArgumentError("seed must fit UInt64"))
    parameters = input isa AbstractString ? AMAPSim.read_parameters(input) : input
    roles = Dict{Int,Symbol}()
    for (key, value) in pairs(product_symbols)
        value isa Union{Symbol,AbstractString} || throw(ArgumentError(
            "product_symbols values must be semantic product symbols"))
        symbol = Symbol(value)
        symbol in (:Axis, :GrowthUnit) && throw(ArgumentError(
            "product roles cannot use reserved structural symbol $symbol"))
        index = if key isa Integer
            Int(key)
        else
            matches = findall(lp -> lp.name == String(key), parameters.lateral_productions)
            length(matches) == 1 || throw(ArgumentError(
                "product_symbols key $(repr(key)) must identify exactly one LP name"))
            only(matches)
        end
        1 <= index <= length(parameters.lateral_productions) ||
            throw(ArgumentError("product_symbols LP index $index is out of range"))
        roles[index] = symbol
    end
    initial = _status_values(status)
    any(k -> k in keys(initial), (_STATE, :native_revision)) && throw(ArgumentError(
        "$_STATE and native_revision are reserved native adapter fields"))
    return NativePlant(PSE.ObjectId(id), parameters, UInt64(seed), development_increment,
        roles, isnothing(species) ? nothing : Symbol(species), Symbol(kind), initial)
end

struct _Mapping
    symbol::Symbol
    scale::Symbol
    kind::Symbol
end

mutable struct _ExposureGroup
    mapping::_Mapping
    # nothing means every native entity matching the fixed labels; a set is an
    # explicit, immutable ID selection. Never derive this from current targets.
    ids::Union{Nothing,Set{PSE.ObjectId}}
    specs::Vector{Any}
    properties::Vector{Pair{Symbol,Symbol}}
    required::Set{Symbol}
    publisher::Symbol
end

mutable struct NativePSEState{N,F,C,D,G}
    native::N
    plant_id::PSE.ObjectId
    product_symbols::Dict{Int,Symbol}
    groups::Vector{_ExposureGroup}
    registered::Dict{Tuple{Symbol,Int},PSE.ObjectId}
    geometry::Bool
    status_factory::F
    growth_control::C
    growth_runtime::Base.RefValue{Any}
    development::D
    organ_growth::G
    coupled_pending::Bool
end

"""Return the live native state; unlike `final_state`, this does not copy arenas."""
native_state(model, plant_id) = getproperty(PSE.model_status(model, plant_id), _STATE)

include("pse_carbon_policy.jl")
include("pse_growth.jl")
include("pse_expansion.jl")
include("pse_coupled.jl")

abstract type AbstractNativePropertiesModel <: PSE.AbstractModel end
PSE.process_(::Type{<:AbstractNativePropertiesModel}) = :native_properties

struct NativePropertyPublisher{D,P} <: AbstractNativePropertiesModel
    defaults::D
    properties::P
    revision_input::Symbol
end
NativePropertyPublisher(defaults, properties) =
    NativePropertyPublisher(defaults, properties, :native_revision)
PSE.inputs_(model::NativePropertyPublisher) =
    NamedTuple{(_STATE, model.revision_input)}((
        PSE.Required(NativePSEState), PSE.Required(Integer)))
PSE.outputs_(model::NativePropertyPublisher) = NamedTuple{keys(model.defaults)}(
    map(v -> PSE.Distributed(PSE.Default(v)), values(model.defaults)))
function PSE.variable_contracts_(model::NativePropertyPublisher)
    contracts = Pair{Symbol,Any}[]
    for (name, source) in model.properties
        source === :structural_mass_gDM && push!(contracts, name => STRUCTURAL_MASS_CONTRACT)
        source === :development_time && push!(contracts, name => AXIS_DEVELOPMENT_TIME_CONTRACT)
    end
    return (; contracts...)
end

function PSE.run!(model::NativePropertyPublisher, status, environment, constants, context)
    state = getproperty(status, _STATE)
    names = keys(model.defaults)
    targets = PSE.output_targets(context, names)
    # Validate the complete domain before writing any column. A foreign Object
    # with equal labels must never be mistaken for one of this arena's records.
    for id in PSE.object_ids(targets)
        _validate_projection_target(state, id)
    end
    for (position, id) in enumerate(PSE.object_ids(targets))
        _, symbol, slot = id.value
        record = _record(state, symbol, slot)
        for (name, source) in model.properties
            getproperty(targets.columns, name)[position] = _property(state, symbol, slot, record, source)
        end
    end
    return nothing
end

include("pse_projection.jl")

end
