# SPDX-License-Identifier: LGPL-3.0-or-later
# Source math: AMAPsim Matrix.cpp, Vector.cpp and UtilMath.h,
# copyright Jean-Francois Barczi / AMAPsim contributors.
"""Source arithmetic for the qualified GCC arm64 geometry contract.

Fusion sites and operand order come from the qualified binary disassembly.
The independent dense/near-vertical actual-method oracle qualifies every
primitive output bit. These functions do not fit scene outputs.
"""
module NativeAMAPGeometryPrimitives
const V3 = NTuple{3,Float32}
const M4 = NTuple{16,Float32} # row-major, matching the source constructor
const SOURCE_LIBM = Sys.isapple() ? "/usr/lib/libSystem.B.dylib" : "libm.so.6"
@inline source_sincos(angle::Float32,::Val{:base}) = (sin(angle),cos(angle))
@inline function source_sincos(angle::Float32,::Val{:system_cexp})
    value = ccall((:cexpf,SOURCE_LIBM),ComplexF32,(ComplexF32,),ComplexF32(0.0f0,angle))
    return (imag(value),real(value))
end
@inline norm_squared(v::V3)::Float32 = fma(v[3],v[3],fma(v[1],v[1],v[2]*v[2]))
@inline norm3(v::V3)::Float32 = sqrt(norm_squared(v))
@inline function unit(v::V3)::V3
    n = norm3(v)
    n > 1.0e-10 ? (v[1]/n,v[2]/n,v[3]/n) : v
end
@inline dot3(a::V3,b::V3)::Float32 = fma(a[3],b[3],fma(a[1],b[1],a[2]*b[2]))

@inline function matrix_product(a::M4,b::M4)::M4
    return ntuple(16) do index
        row = (index-1) >>> 2
        column = (index-1) & 3
        offset = 4row
        accumulator = b[5+column]*a[offset+2]
        accumulator = fma(b[1+column],a[offset+1],accumulator)
        accumulator = fma(b[9+column],a[offset+3],accumulator)
        return fma(b[13+column],a[offset+4],accumulator)
    end
end

@inline function matrix_rotation(axis::V3,angle::Float32,trig=Val(:base))::M4
    sine,c = source_sincos(angle,trig)
    t = 1.0f0-c
    x,y,z = axis
    tx,ty,tz = t*x,t*y,t*z
    txy,txz,tyz = tx*y,tx*z,ty*z
    xx = fma(tx,x,c); yy = fma(ty,y,c); zz = fma(tz,z,c)
    xy_minus = fma(-z,sine,txy); xy_plus = fma(z,sine,txy)
    xz_plus = fma(y,sine,txz); xz_minus = fma(-y,sine,txz)
    yz_minus = fma(-x,sine,tyz); yz_plus = fma(x,sine,tyz)
    return (xx,xy_minus,xz_plus,0.0f0,xy_plus,yy,yz_minus,0.0f0,
        xz_minus,yz_plus,zz,0.0f0,0.0f0,0.0f0,0.0f0,1.0f0)
end

@inline function vector_rotation(axis::V3,vector::V3,angle::Float32,trig=Val(:base))::V3
    sine,c = source_sincos(angle,trig)
    t = 1.0f0-c
    x,y,z = axis
    xx,xy,xz,yy,yz,zz = x*x,x*y,x*z,y*y,y*z,z*z
    sx,sy,sz = x*sine,y*sine,z*sine
    xx = fma(xx,t,c); yy = fma(yy,t,c); zz = fma(zz,t,c)
    xy_minus = fma(xy,t,-sz); xy_plus = fma(xy,t,sz)
    xz_plus = fma(xz,t,sy); xz_minus = fma(xz,t,-sy)
    yz_minus = fma(yz,t,-sx); yz_plus = fma(yz,t,sx)
    a,b,d = vector
    return (fma(xz_plus,d,fma(xx,a,xy_minus*b)),
        fma(yz_minus,d,fma(xy_plus,a,yy*b)),
        fma(zz,d,fma(xz_minus,a,yz_plus*b)))
end

@inline function projection(normal::V3,vector::V3)::V3
    x,y,z = normal; a,b,c = vector
    xx = fma(-x,x,1.0f0); yy = fma(-y,y,1.0f0); zz = fma(-z,z,1.0f0)
    xy,xz,yz = x*y,x*z,y*z
    projected = (fma(-xz,c,fma(xx,a,-(xy*b))),
        fma(-yz,c,fma(-xy,a,yy*b)),
        fma(zz,c,fma(-xz,a,-(yz*b))))
    return norm_squared(projected) < 1.0e-4 ? (1.0f0,0.0f0,0.0f0) : projected
end
@inline function determine_plagio(reference::V3,plane::V3,trig=Val(:base))::M4
    secondary = unit(projection(reference,plane))
    normal = vector_rotation(reference,secondary,Float32(π/2),trig)
    return (secondary[1],normal[1],reference[1],0.0f0,
        secondary[2],normal[2],reference[2],0.0f0,
        secondary[3],normal[3],reference[3],0.0f0,
        0.0f0,0.0f0,0.0f0,1.0f0)
end

@inline fromhex(value) = reinterpret(Float32,parse(UInt32,replace(String(value),"0x"=>"");base=16))
@inline hex(value::Float32) = string(reinterpret(UInt32,value);base=16,pad=8)
@inline vector_fromhex(values) = ntuple(i -> fromhex(values[i]),3)
@inline matrix_fromhex(values) = ntuple(i -> fromhex(values[i]),16)

"""Compare every primitive output bit, retaining first mismatch details."""
function validate_oracle(records;trig=Val(:base))
    checked = 0; differences = NamedTuple[]; cases = Dict{String,Int}()
    function compare(row,field,observed)
        expected = row[field]
        expected_values = expected isa AbstractString ? [expected] : expected
        observed_values = observed isa Float32 ? (observed,) : observed
        length(expected_values) == length(observed_values) || error("primitive output shape differs")
        for i in eachindex(observed_values)
            checked += 1
            actual = hex(observed_values[i])
            wanted = lowercase(replace(String(expected_values[i]),"0x"=>""))
            if actual != wanted
                length(differences) < 20 && push!(differences,(kind=String(row["kind"]),
                    case=Int(row["case"]),field=field,component=i,expected=wanted,observed=actual))
            end
        end
    end
    for row in records
        kind = String(row["kind"])
        cases[kind] = get(cases,kind,0)+1
        if kind == "normalize"
            vector = vector_fromhex(row["input"])
            compare(row,"norm_squared",norm_squared(vector))
            compare(row,"norm",norm3(vector))
            compare(row,"output",unit(vector))
        elseif kind == "rotation"
            axis = vector_fromhex(row["axis"])
            vector = vector_fromhex(row["input"])
            angle = fromhex(row["angle_bits"])
            compare(row,"vector_output",vector_rotation(axis,vector,angle,trig))
            compare(row,"matrix_output",matrix_rotation(axis,angle,trig))
        elseif kind == "matrix_product"
            left = matrix_fromhex(row["left"]);right = matrix_fromhex(row["right"])
            compare(row,"output",matrix_product(left,right))
        elseif kind == "determine_plagio"
            reference = vector_fromhex(row["reference"]);plane = vector_fromhex(row["plane"])
            compare(row,"output",determine_plagio(reference,plane,trig))
        else
            error("unsupported primitive oracle row $kind")
        end
    end
    return (checked_bits=checked,cases=cases,first_mismatches=differences,passed=isempty(differences))
end
end
