"""
One immutable native organ intention, before any botanical object is created.

`axis_id`, `generation` and `event_sequence` identify the existing meristem and
its original scheduled action within one native plant. `phytomer_rank` is the
one-based physical organ rank on that axis; `organ_index` is currently one.
`development_time` retains the original virtual developmental coordinate across
refusals. It is neither physical time nor the outer step at which funding arrives.
No future organ ID, dimensions, mass or construction cost is inferred.
"""
struct NativeGrowthIntent
    axis_id::Int32
    generation::UInt64
    event_sequence::Int64
    phytomer_rank::Int
    organ_symbol::Symbol
    organ_index::Int
    development_time::Float64
end

struct _PreparedNativeGrowth{P}
    event::NativeAMAPPlantEngine.PlantEvent
    transition::P
    intent::NativeGrowthIntent
end

"""
    GrowthControl(; before_growth=intent -> true,
        after_growth=intent -> nothing, product_symbols=Dict{Int,Symbol}())

Optional per-plant resource control. The native engine samples each potential
apical organ once, then calls `before_growth` with its immutable intention. The
callback must return a `Bool`: refusal retains that exact preparation and lets
other axes and pruning continue. Each refused event is tried at most once per
`advance_to!` call. A successful native event calls `after_growth` once, suitable
for settling its accepted resource quote. Quotes must not spend resources.

Callbacks receive no RNG or arenas and must consume no random numbers. Product
symbols explicitly classify existing lateral productions by their one-based LP
index; the primary axis remains `:Internode`. A control owns exactly one native
plant. Reuse it for subsequent advances of that plant.

Retries retain original developmental times and can catch up within the current
horizon. This is an organ realization gate, not a new physical-time growth,
starvation mortality, dimension or carbon-demand model. A partially committed
native event or failed settlement poisons this control and cannot be retried.
"""
mutable struct GrowthControl{B,A}
    before_growth::B
    after_growth::A
    product_symbols::Dict{Int,Symbol}
    pending::Dict{Int64,Any}
    owned_plant::Any
    failed::Bool
    running::Bool
    has_deferred::Bool
end

function GrowthControl(; before_growth=intent -> true,
    after_growth=intent -> nothing, product_symbols=Dict{Int,Symbol}())
    symbols=Dict{Int,Symbol}()
    for (key,symbol) in pairs(product_symbols)
        key isa Integer && !(key isa Bool) && key>0 || throw(ArgumentError(
            "growth-control product_symbols keys must be positive LP indices"))
        symbol isa Symbol || throw(ArgumentError(
            "growth-control product_symbols values must be Symbols"))
        symbol in (:Axis,:GrowthUnit) && throw(ArgumentError(
            "growth-control product roles cannot use structural symbol $symbol"))
        symbols[Int(key)]=symbol
    end
    return GrowthControl(before_growth,after_growth,symbols,Dict{Int64,Any}(),
        nothing,false,false,false)
end

@inline function _live_growth_event(plant,event)
    axis=plant.axes[event.axis]
    return axis.active && axis.generation==event.generation
end

function _discard_stale_growth!(control::GrowthControl)
    plant=control.owned_plant
    plant===nothing && return nothing
    for sequence in collect(keys(control.pending))
        _live_growth_event(plant,control.pending[sequence].event) ||
            delete!(control.pending,sequence)
    end
    return nothing
end

"""Return an immutable tuple of waiting organ intentions in native event order."""
function pending_growth(control::GrowthControl)
    _discard_stale_growth!(control)
    records=collect(values(control.pending))
    sort!(records;lt=(a,b)->NativeAMAPPlantEngine.before(a.event,b.event))
    return Tuple(record.intent for record in records)
end

function _bind_growth_control!(control::GrowthControl,plant)
    control.failed && throw(ArgumentError(
        "a native growth commit or settlement failed; discard this simulation before retrying"))
    control.running && throw(ArgumentError("native growth control cannot be re-entered"))
    control.owned_plant===nothing || control.owned_plant===plant || throw(ArgumentError(
        "a native GrowthControl belongs to exactly one plant"))
    for index in keys(control.product_symbols)
        index<=length(plant.parameters.lateral_productions) || throw(ArgumentError(
            "growth-control product_symbols LP index $index is out of range"))
    end
    control.owned_plant=plant
    _discard_stale_growth!(control)
    return nothing
end

# Every field currently held by NativeApicalState is a scalar or an immutable
# VigorState/CycleInitialization. Copy only that state, never a future plant or
# the RNG: preparation advances the live stream once even if funding is refused.
function _copy_native_apical_state(state::NativeAMAPScientificCore.NativeApicalState)
    return NativeAMAPScientificCore.NativeApicalState(
        (getfield(state,name) for name in fieldnames(typeof(state)))...)
end

function _native_growth_intent(control,plant,event,transition)
    axis=plant.axes[event.axis]
    symbol=axis.parent==0 ? :Internode :
        get(control.product_symbols,Int(axis.lateral_index),:Internode)
    return NativeGrowthIntent(event.axis,event.generation,event.sequence,
        transition.state.internode_count_on_axis,symbol,1,event.time)
end

function _advance_with_growth_control!(plant,horizon::Real,control::GrowthControl;
    max_events::Integer=10_000_000)
    Engine=NativeAMAPPlantEngine
    isfinite(horizon) && horizon>=plant.time || throw(ArgumentError("native horizon must increase"))
    max_events>=0 || throw(ArgumentError("native event bound must be nonnegative"))
    _bind_growth_control!(control,plant)
    control.running=true
    held=Engine.PlantEvent[]
    current=nothing
    attempts=0
    dirty=false
    try
        while !isempty(plant.events) && first(plant.events).time<=horizon+Engine.EPSILON
            # Refusals count toward this call's bound, while successful events
            # retain the historical cumulative processed-event bound.
            attempts<max_events && plant.processed<max_events ||
                error("native event bound exceeded")
            current=Engine.dequeue!(plant)
            attempts+=1
            if !_live_growth_event(plant,current)
                plant.cancelled+=1
                delete!(control.pending,current.sequence)
                current=nothing
                continue
            end
            if current.kind==Engine.APICAL
                cached=get(control.pending,current.sequence,nothing)
                if cached===nothing
                    # An exceptional partially sampled transition cannot be
                    # reconstructed by retrying with the already advanced RNG.
                    control.failed=true
                    clock_before=plant.last_event_time
                    try
                        # Existing validation hooks see the same event clock
                        # as the direct lane. A potential organ does not itself
                        # advance the public clock while waiting for funding.
                        plant.last_event_time=control.has_deferred ?
                            max(clock_before,current.time) : current.time
                        Engine.before_event!(plant.rng,plant,current)
                        state=_copy_native_apical_state(plant.axes[current.axis].state)
                        transition=Engine.prepare_apical!(plant,current,state)
                    finally
                        plant.last_event_time=clock_before
                    end
                    if transition.plan!==nothing && transition.plan.realized
                        intent=_native_growth_intent(control,plant,current,transition)
                        cached=_PreparedNativeGrowth(current,transition,intent)
                        control.pending[current.sequence]=cached
                    end
                    control.failed=false
                else
                    all(name->isequal(getfield(current,name),getfield(cached.event,name)),
                        fieldnames(typeof(current))) || throw(ArgumentError(
                        "a prepared native organ's original event cannot be rescheduled or changed"))
                    transition=cached.transition
                end
                if cached!==nothing
                    accepted=control.before_growth(cached.intent)
                    accepted isa Bool || throw(ArgumentError(
                        "native before_growth must return a Bool for one organ"))
                    if !accepted
                        control.has_deferred=true
                        push!(held,current)
                        current=nothing
                        continue
                    end
                end
                # Before any refusal, preserve even the historical native
                # backdated-event clock exactly. Once resource deferral occurs,
                # overdue funding must not rewind the geometry's clock.
                control.failed=true
                plant.last_event_time=control.has_deferred ?
                    max(plant.last_event_time,current.time) : current.time
                dirty=true
                Engine.commit_apical!(plant,current,transition)
                delete!(control.pending,current.sequence)
                cached===nothing || control.after_growth(cached.intent)
                control.failed=false
            else
                control.failed=true
                plant.last_event_time=control.has_deferred ?
                    max(plant.last_event_time,current.time) : current.time
                dirty=true
                Engine.before_event!(plant.rng,plant,current)
                Engine.prune!(plant,current)
                control.failed=false
            end
            plant.processed+=1
            current=nothing
        end
        plant.time=Float64(horizon)
        plant.geometry_complete=false
    finally
        # A quote callback error leaves the sampled organ and its exact event
        # retryable. A partial lifecycle/settlement error remains an abort.
        current===nothing || control.failed || push!(held,current)
        for event in held
            Engine.requeue!(plant,event)
        end
        _discard_stale_growth!(control)
        dirty && (plant.geometry_complete=false)
        control.running=false
    end
    return plant
end
