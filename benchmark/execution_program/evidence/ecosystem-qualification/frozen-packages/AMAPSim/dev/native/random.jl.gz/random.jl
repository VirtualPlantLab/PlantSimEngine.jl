# Numerical PRNG routines ported from AMAPsim VitisCore/mersenne.cpp and
# Include/randomMers.h, copyright 2001-2004 A. Fog / Agner Fog.
# Original notice: GNU General Public License www.gnu.org/copyleft/gpl.html.
# Original source files do not state a GPL version; this notice is retained.
# Legacy discrete-law routines ported from VitisCore/randomFct.cpp,
# copyright Jean-Francois Barczi / AMAPsim contributors, LGPL-3.0-or-later.
# This file's notices apply to this prototype, not the surrounding MIT package.
"""
Observed native LP64 AMAPsim generator and native discrete sampling.

This intentionally reproduces the qualified binary's unsigned-long UInt64
variant, including its non-IEEE conversion r / 2^64 and first-counter twist.
It does not claim to implement the intended historical 32-bit MT19937 stream.

Both generated and prescribed uniforms share the same Float32 native-law
adapter. No audit dictionaries, logging or predetermined branching results are
used in the hot path. Uniform consumption is exposed as primitive counters.
"""
module NativeAMAPLegacyRNG
using Random
import AMAPSim

abstract type AbstractLegacyRNG <: Random.AbstractRNG end
const STATE_WORDS = 624
const STREAMS = 50
const SPLIT = 397
const LOWER_MASK = UInt64(0x7fffffff)
const UPPER_MASK = ~LOWER_MASK
const TEMPER_B = UInt64(0x9d2c5680)
const TEMPER_C = UInt64(0xefc60000)
const MAG = UInt64(0x9908b0df)
const INV_UINT64_RANGE = 0x1.0p-64

mutable struct ObservedRNG <: AbstractLegacyRNG
    seed::UInt64
    words::Matrix{UInt64}
    saved_counters::Vector{Int32}
    needs_reinitialization::BitVector
    stream::Int32 # zero-based native stream number
    counter::Int32 # zero-based next word; 624 triggers a twist
    draws::Int64
end

function initialize_stream!(rng::ObservedRNG,stream::Int)
    column = stream+1
    rng.words[1,column] = rng.seed+UInt64(stream)
    for i in 1:STATE_WORDS-1
        previous = rng.words[i,column]
        rng.words[i+1,column] = UInt64(1812433253)*(previous ⊻ (previous >> 30))+UInt64(i)
    end
    return nothing
end

function ObservedRNG(seed::Integer=1)
    0 <= seed <= typemax(UInt64) || throw(ArgumentError("seed must fit UInt64"))
    rng = ObservedRNG(UInt64(seed),Matrix{UInt64}(undef,STATE_WORDS,STREAMS),
        zeros(Int32,STREAMS),falses(STREAMS),0,STATE_WORDS,0)
    for stream in 0:STREAMS-1
        initialize_stream!(rng,stream)
    end
    return rng
end

@inline function temper(word::UInt64)::UInt64
    word ⊻= word >> 11
    word ⊻= (word << 7) & TEMPER_B
    word ⊻= (word << 15) & TEMPER_C
    word ⊻= word >> 18
    return word
end

function twist!(rng::ObservedRNG)
    column = Int(rng.stream)+1
    words = rng.words
    @inbounds for i in 1:STATE_WORDS-SPLIT
        y = (words[i,column] & UPPER_MASK) | (words[i+1,column] & LOWER_MASK)
        words[i,column] = words[i+SPLIT,column] ⊻ (y >> 1) ⊻ ((y & 1) == 0 ? UInt64(0) : MAG)
    end
    @inbounds for i in STATE_WORDS-SPLIT+1:STATE_WORDS-1
        y = (words[i,column] & UPPER_MASK) | (words[i+1,column] & LOWER_MASK)
        words[i,column] = words[i+SPLIT-STATE_WORDS,column] ⊻ (y >> 1) ⊻ ((y & 1) == 0 ? UInt64(0) : MAG)
    end
    @inbounds begin
        y = (words[STATE_WORDS,column] & UPPER_MASK) | (words[1,column] & LOWER_MASK)
        words[STATE_WORDS,column] = words[SPLIT,column] ⊻ (y >> 1) ⊻ ((y & 1) == 0 ? UInt64(0) : MAG)
    end
    rng.counter = 0
    rng.needs_reinitialization[column] = true
    return nothing
end

@inline function next_word!(rng::ObservedRNG)::UInt64
    rng.counter >= STATE_WORDS && twist!(rng)
    rng.counter += 1
    rng.draws += 1
    @inbounds return temper(rng.words[rng.counter,Int(rng.stream)+1])
end
@inline next_uniform!(rng::ObservedRNG)::Float64 = Float64(next_word!(rng))*INV_UINT64_RANGE

"""Switch native stream, returning the previous zero-based stream number."""
function set_stream!(rng::ObservedRNG,stream::Integer)
    0 <= stream < STREAMS || throw(ArgumentError("native stream must be in 0:49"))
    previous = rng.stream
    rng.saved_counters[Int(previous)+1] = rng.counter
    rng.counter = rng.saved_counters[Int(stream)+1]
    rng.stream = Int32(stream)
    return Int(previous)
end

"""Source initState: reset cursor and regenerate a previously twisted stream."""
function reset_stream!(rng::ObservedRNG,stream::Integer)
    0 <= stream < STREAMS || throw(ArgumentError("native stream must be in 0:49"))
    rng.saved_counters[Int(stream)+1] = 0
    rng.stream == stream && (rng.counter = 0)
    if rng.needs_reinitialization[Int(stream)+1]
        initialize_stream!(rng,Int(stream))
        rng.needs_reinitialization[Int(stream)+1] = false
    end
    return rng
end
function set_counter!(rng::ObservedRNG,counter::Integer)
    0 <= counter <= STATE_WORDS || throw(ArgumentError("native counter must be in 0:624"))
    rng.counter = Int32(counter)
    return rng
end

"""Prescribed common uniforms; values are inputs, never decisions or outcomes."""
mutable struct UniformTape <: AbstractLegacyRNG
    values::Vector{Float64}
    cursor::Int
    draws::Int64
end
function UniformTape(values::AbstractVector{<:Real})
    uniforms = Float64.(values)
    all(x -> isfinite(x) && 0 <= x <= 1,uniforms) ||
        throw(ArgumentError("all prescribed uniforms must be in [0,1]"))
    return UniformTape(uniforms,1,0)
end
@inline function next_uniform!(rng::UniformTape)::Float64
    rng.cursor <= length(rng.values) || throw(EOFError())
    @inbounds value = rng.values[rng.cursor]
    rng.cursor += 1; rng.draws += 1
    return value
end
Random.rand(rng::AbstractLegacyRNG) = next_uniform!(rng)
Random.rand(rng::AbstractLegacyRNG,::Type{Float64}) = next_uniform!(rng)
Random.rand(rng::AbstractLegacyRNG,::Random.SamplerType{Float64}) = next_uniform!(rng)

@inline function bernoulli(rng::AbstractLegacyRNG,probability::Real)::Bool
    p = Float32(probability)
    p <= 0 && return false
    p >= 1 && return true
    return Float32(next_uniform!(rng)) < p
end

"""Native binodecf, including one threshold draw at p=1 and the 5000 bound."""
function negative_count(rng::AbstractLegacyRNG,parameter::Float32,probability::Float32,shift::Int)
    threshold = Float64(Float32(next_uniform!(rng)))
    failure = 1.0-Float64(probability); success = Float64(probability)
    subset = Float64(parameter)-1.0; set = subset; i = shift
    if sqrt(Float64(parameter))/success < 500.0
        term = success^Float64(parameter)
        cumulative = term
        while cumulative < threshold && i < 5000
            set += 1.0
            term *= set/(set-subset)*failure
            cumulative += term
            i += 1
        end
    else
        term = Float64(parameter)*log(success)
        cumulative = exp(term)
        log_failure = log(failure)
        while cumulative < threshold && i < 5000
            set += 1.0
            term += log(set/(set-subset))+log_failure
            # Retain the source's log-branch accumulation literally.
            cumulative += term
            i += 1
        end
    end
    return i
end

function shifted_count(rng::AbstractLegacyRNG,trials::Real,probability::Real,shift::Real)
    n = Float32(trials); p = Float32(probability); d = trunc(Int,shift)
    if n < 0
        return negative_count(rng,-n,p,d)
    end
    count = trunc(Int,n)
    n-Float32(count) >= 0.5f0 && (count += 1)
    successes = 0
    for _ in 1:count
        successes += bernoulli(rng,p)
    end
    return successes+d
end

function cumulative_index(rng::AbstractLegacyRNG,weights)
    isempty(weights) && throw(ArgumentError("categorical law needs weights"))
    cumulative = 0.0f0
    # Source cumulativeLaw avoids a draw when one of its first3 cumulative
    # values first reaches exactly one after preceding exact zeros.
    for i in 1:min(3,length(weights))
        weight = Float32(weights[i])
        if cumulative == 0 && weight == 1
            return i
        end
        cumulative += weight
    end
    threshold = Float32(next_uniform!(rng))
    cumulative = 0.0f0
    for i in eachindex(weights)
        cumulative += Float32(weights[i])
        cumulative > threshold && return Int(i)
    end
    throw(ArgumentError("source categorical cumulative mass does not exceed sampled threshold"))
end

AMAPSim.sample_bernoulli(rng::AbstractLegacyRNG,p::Real;
    policy::AMAPSim.AbstractSamplingPolicy=AMAPSim.StandardSampling()) = bernoulli(rng,p)
AMAPSim.sample_binomial(rng::AbstractLegacyRNG,n::Integer,p::Real;
    policy::AMAPSim.AbstractSamplingPolicy=AMAPSim.StandardSampling()) = shifted_count(rng,n,p,0)
AMAPSim.sample_negative_binomial(rng::AbstractLegacyRNG,n::Real,p::Real;
    policy::AMAPSim.AbstractSamplingPolicy=AMAPSim.StandardSampling()) = negative_count(rng,Float32(n),Float32(p),0)
AMAPSim.sample_shifted_count(rng::AbstractLegacyRNG,n::Real,p::Real,d::Real;
    policy::AMAPSim.AbstractSamplingPolicy=AMAPSim.StandardSampling()) = shifted_count(rng,n,p,d)
AMAPSim._sample_legacy_shifted_count(rng::AbstractLegacyRNG,n,p,d;policy) = shifted_count(rng,n,p,d)
AMAPSim.sample_categorical(rng::AbstractLegacyRNG,weights::AbstractVector{<:Real};
    policy::AMAPSim.AbstractSamplingPolicy=AMAPSim.StandardSampling()) = cumulative_index(rng,weights)

"""Source two-state Markov selection uses u >= CDF0 (not u < branch-p)."""
@inline function markov_branched(rng::AbstractLegacyRNG,cdf_zero::Float32)::Bool
    cdf_zero <= 0 && return true
    cdf_zero >= 1 && return false
    return Float32(next_uniform!(rng)) >= cdf_zero
end
function markov_result(rng::AbstractLegacyRNG,branching,age,position,previous,previous_initial,
    initial_field,unbranched_field,branched_field)
    initial = AMAPSim.valueat(getproperty(branching,initial_field),age,position)
    reset = previous !== nothing && previous_initial !== nothing && initial != previous_initial
    old = reset ? nothing : previous
    cdf = old === nothing ? 1.0f0-Float32(initial) : old ?
        1.0f0-Float32(AMAPSim.valueat(getproperty(branching,branched_field),age,position)) :
        Float32(AMAPSim.valueat(getproperty(branching,unbranched_field),age,position))
    result = markov_branched(rng,cdf)
    return (old,Float64(initial),reset,Float64(1.0f0-cdf),result)
end
function AMAPSim.sample_immediate_markov_state(rng::AbstractLegacyRNG,
    branching::AMAPSim.ParameterGroup,age::Real,position::Real,previous::Union{Nothing,Bool}=nothing;
    previous_branching=nothing,previous_position=nothing,previous_initial_probability=nothing,
    policy::AMAPSim.AbstractSamplingPolicy=AMAPSim.StandardSampling())
    prior = previous_initial_probability
    if previous_branching !== nothing
        previous_position === nothing && throw(ArgumentError("previous site position is required"))
        prior = AMAPSim.valueat(previous_branching.immediate_initial_probability,age,previous_position)
    end
    return AMAPSim.ImmediateMarkovTransition(markov_result(rng,branching,age,position,
        previous,prior,:immediate_initial_probability,:immediate_unbranched_state_probability,
        :immediate_branched_state_probability)...)
end
function AMAPSim.sample_cycle_delayed_markov_state(rng::AbstractLegacyRNG,
    branching::AMAPSim.ParameterGroup,age::Real,position::Real,previous::Union{Nothing,Bool}=nothing;
    previous_initial_probability=nothing,
    policy::AMAPSim.AbstractSamplingPolicy=AMAPSim.StandardSampling())
    return AMAPSim.CycleDelayedMarkovTransition(markov_result(rng,branching,age,position,
        previous,previous_initial_probability,:cycle_delayed_initial_probability,
        :cycle_delayed_unbranched_state_probability,:cycle_delayed_branched_state_probability)...)
end
function AMAPSim.sample_traumatic_markov_state(rng::AbstractLegacyRNG,
    branching::AMAPSim.ParameterGroup,age::Real,position::Real,previous::Union{Nothing,Bool}=nothing;
    previous_initial_probability=nothing,
    policy::AMAPSim.AbstractSamplingPolicy=AMAPSim.StandardSampling())
    return AMAPSim.TraumaticMarkovTransition(markov_result(rng,branching,age,position,
        previous,previous_initial_probability,:traumatic_initial_probability,
        :traumatic_unbranched_state_probability,:traumatic_branched_state_probability)...)
end

"""Three-state delayed CDF in native family order, before semantic permutation."""
function AMAPSim.sample_delayed_markov_state(rng::AbstractLegacyRNG,
    branching::AMAPSim.ParameterGroup,age::Real,position::Real,
    previous::Union{Nothing,AMAPSim.DelayedBranchState}=nothing;
    policy::AMAPSim.AbstractSamplingPolicy=AMAPSim.StandardSampling())
    first,second,family = if previous === nothing
        (AMAPSim.valueat(branching.delayed_initial_state_0_probability,age,position),
            AMAPSim.valueat(branching.delayed_initial_state_1_probability,age,position),255)
    elseif previous == AMAPSim.DelayedUnbranched
        (AMAPSim.valueat(branching.delayed_state_0_stay_probability,age,position),
            AMAPSim.valueat(branching.delayed_state_0_to_1_probability,age,position),0)
    elseif previous == AMAPSim.DelayedType1
        (AMAPSim.valueat(branching.delayed_state_1_stay_probability,age,position),
            AMAPSim.valueat(branching.delayed_state_1_to_0_probability,age,position),2)
    else
        (AMAPSim.valueat(branching.delayed_state_2_stay_probability,age,position),
            AMAPSim.valueat(branching.delayed_state_2_to_0_probability,age,position),3)
    end
    p0 = Float32(first); p1 = Float32(second); p2 = 1.0f0-p0-p1
    index = cumulative_index(rng,(p0,p1,p2))
    canonical = AMAPSim._delayed_probability_triplet(first,second)
    probabilities = family == 2 ? (canonical[2],canonical[1],canonical[3]) :
        family == 3 ? (canonical[2],canonical[3],canonical[1]) : canonical
    mapping = family == 2 ? (2,1,3) : family == 3 ? (3,1,2) : (1,2,3)
    return AMAPSim.DelayedMarkovTransition(previous,probabilities,
        AMAPSim.DelayedBranchState(mapping[index]-1))
end

"""Fourth reset-stream geometry draw, evaluated without mutating growth RNG."""
function geometry_alea(seed::Integer,stream::Integer)::Float32
    0 <= stream < STREAMS || throw(ArgumentError("geometry stream must be in 0:49"))
    word = UInt64(seed)+UInt64(stream)
    for i in 1:3
        word = UInt64(1812433253)*(word ⊻ (word >> 30))+UInt64(i)
    end
    return Float32(Float64(temper(word))*INV_UINT64_RANGE)
end

"""Closure supplying native geometry streams from structural parent/site/slot IDs."""
function geometry_draws(plant)
    plant.rng isa ObservedRNG || throw(ArgumentError("native generated geometry requires ObservedRNG seed"))
    seed = plant.rng.seed
    depths = zeros(Int,length(plant.axes))
    for (id,axis) in enumerate(plant.axes)
        axis.parent == 0 || (depths[id] = depths[axis.parent]+1)
    end
    return (id,axis) -> begin
        bearer_rank = axis.bearer_site == 0 ? 0 : Int(plant.sites[axis.bearer_site].axis_organ)-1
        stream = 3+mod(mod(depths[id],STREAMS-3)+bearer_rank+Int(axis.slot)+1,STREAMS-3)
        geometry_alea(seed,stream)
    end
end

"""Validate every raw word, Float64 value and cursor against the extracted C++ oracle."""
function validate_source_oracle(records)
    grouped = Dict{String,Vector{Any}}()
    abi = nothing
    for row in records
        if get(row,"record_kind","") == "abi"
            abi = row
        else
            push!(get!(grouped,String(row["scenario"]),Any[]),row)
        end
    end
    abi === nothing && throw(ArgumentError("source oracle requires ABI evidence"))
    abi["uint32_bytes"] == 8 && abi["int32_bytes"] == 8 &&
        abi["selected_architecture"] == 2 && abi["initial_counter"] == 624 ||
        throw(ArgumentError("source ABI differs from the observed LP64 contract"))
    checked = 0
    function check!(label,rng)
        rows = grouped[label]
        for (index,row) in enumerate(rows)
            row["ordinal"] == index || error("source row ordinal differs")
            row["stream"] == rng.stream || error("source stream differs at $label/$index")
            row["counter_before"] == rng.counter || error("source pre-counter differs at $label/$index")
            expected = haskey(row,"word_hex") ? parse(UInt64,row["word_hex"];base=16) : UInt64(row["word"])
            observed = next_word!(rng)
            expected == observed || error("source raw word differs at $label/$index")
            Float64(observed)*INV_UINT64_RANGE == row["uniform"] ||
                error("source Float64 uniform differs at $label/$index")
            row["counter_after"] == rng.counter || error("source post-counter differs at $label/$index")
            checked += 1
        end
    end
    rng = ObservedRNG(1)
    check!("seed1_stream0_1300",rng)
    rng = ObservedRNG(1)
    set_stream!(rng,4);reset_stream!(rng,4)
    check!("geometry_stream4_initial",rng)
    set_stream!(rng,0)
    check!("restore_stream0_630",rng)
    saved = rng.counter
    previous = set_stream!(rng,13);reset_stream!(rng,13)
    check!("geometry_stream13_initial",rng)
    set_stream!(rng,previous);set_counter!(rng,saved)
    check!("restore_stream0_saved_counter",rng)
    reset_stream!(rng,0)
    check!("stream0_reinitialized_after_twist",rng)
    rng = ObservedRNG(1)
    set_stream!(rng,13);reset_stream!(rng,13)
    check!("stream13_cross_first_twist",rng)
    reset_stream!(rng,13)
    check!("stream13_reinitialized_after_twist",rng)
    checked == sum(length,values(grouped)) || error("source oracle has unverified rows")
    return (raw_word_matches=checked,exact_float64_matches=checked,
        stream_and_counter_matches=3checked,scenarios=length(grouped),abi="observed LP64 UInt64 / nonIEEE")
end
end
