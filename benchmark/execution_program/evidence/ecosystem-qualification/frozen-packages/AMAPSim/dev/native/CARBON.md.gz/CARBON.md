# Organ-wise resource control in the native engine

The experimental native/PSE boundary can ask a demand and allocation model
before creating each organ. A shortage retains that organ's prepared transition
while other existing axes and pruning continue. The fast native event loop
continues to own botanical development.

For fixed explicit construction costs, the [cached policy path](FAST_CARBON.md)
prepares one PSE frame per outer step and applies allocation directly in the
native loop. The example below remains the inspectable reference with manual
calls and full organ histories.

For incremental expansion from potential geometry, use the
[structure–function mode](MODES.md). That mode initiates architectural organs
before construction and delegates demand/allocation/realized dimensions to
ordinary PSE models. It is distinct from the whole-organ creation gate here.

## A small carbon example

Load the development modules from a checkout, through Kaimon. The example uses
the existing illustrative mass/construction-cost and reserve models. Their
coefficients below are supplied demonstration values, not an FPA allometry or
a calibration of Merisier.

```julia
using AMAPSim, PlantSimEngine
include(joinpath(pkgdir(AMAPSim), "dev", "native", "native.jl"))
include(joinpath(pkgdir(AMAPSim), "dev", "native", "pse.jl"))
include(joinpath(pkgdir(AMAPSim), "examples", "growth_demand", "models.jl"))
const G = GrowthDemandModels
```

Each construction request is `potential_dry_mass_g * construction_cost_gC_per_gDM`.
Supply is cumulative gC since the start, excluding the initial reserve. Repeating
the same cumulative supply does not credit it again. Here the first two outer
steps supply no carbon, and the next two make one gram available in total.

```julia
organs = (
    Internode=(potential_dry_mass_g=0.02, construction_cost_gC_per_gDM=0.5),
    Leaf=(potential_dry_mass_g=0.01, construction_cost_gC_per_gDM=0.6),
)
demand = ModelSpec(G.MassConstructionDemand(; organs);
    name=:demand, on=Many(scale=:Plant),
    inputs=(growth_intents=One(within=Self(),
        application=:native_architecture, var=:growth_intents),))
allocation = ModelSpec(G.CarbonReserveAllocation(; initial_reserve_gC=0.0);
    name=:allocation, on=Many(scale=:Plant),
    inputs=(
        growth_intents=One(within=Self(),
            application=:native_architecture, var=:growth_intents),
        realized_growth_intents=One(within=Self(),
            application=:native_architecture, var=:realized_growth_intents),
        demand_history=One(within=Self(), application=:demand, var=:demand_history),
    ))
input = joinpath(pkgdir(AMAPSim), "test", "fixtures", "native_originals", "merisier.fpa")
plant = NativeAMAPPSE.NativePlant(:tree, input; seed=1,
    development_increment=0.5, product_symbols=Dict("feuilles" => :Leaf))
model = NativeAMAPPSE.scenario((plant,);
    applications=(demand, allocation),
    before_growth_calls=(demand=One(within=Self(), application=:demand),),
    growth_allocation_call=One(within=Self(), application=:allocation),
    environment=[(duration=1.0, cumulative_carbon_supply_gC=supply)
        for supply in (0.0, 0.0, 1.0, 1.0)])
simulation = PlantSimEngine.run!(model; steps=4, outputs=:none)
status = model_status(model, :tree)
@assert status.credited_carbon_supply_gC ≈
    status.remaining_carbon_gC + status.spent_carbon_gC
@assert status.spent_carbon_gC ≈ sum((row.allocated_gC
    for row in status.allocation_history); init=0.0)
@assert isempty(status.growth_intents) && isempty(status.realized_growth_intents)
@assert isempty(model_objects(model; scale=:Leaf))
```

The last assertion follows the exposure contract: no model was declared **on**
Leaf, so no Leaf PSE object is needed. Leaf intentions and construction payments
still concern real native products. Add an actual Leaf application when organ
models need those Objects. Supply, allocation and demand remain plant-level
applications with an independent Status and ledger for each plant.

`development_increment=0.5` is a virtual AMAPsim increment per outer exchange.
The duration in this example does not calibrate its relationship to physical
time. Light/assimilation integration must explicitly convert rates to integrated
gC before producing the cumulative supply.

## Quote, realization and settlement

1. At outer-step entry, the allocator receives empty intention/settlement slots.
   This validates and credits cumulative supply even if no organ is due.
2. Native growth prepares one apical transition using the live native RNG. A
   realized primary product produces one immutable intention. Failed botanical
   tests and non-organ events require no construction payment.
3. Named `before_growth_calls` run as PSE manual calls. The allocation call
   returns exactly one decision with the matching organ key. A quote spends no
   carbon. Refusal retains the sampled transition and original scheduled event.
4. Acceptance commits the normal GU/site/organ, phyllotaxy, branching, trace
   and scheduling operations in their existing order. The allocation call then
   settles the realized intention exactly once.
5. Transient slots and the stored runtime context are cleared. Ordinary native
   property/object synchronization takes place at the outer boundary.

`publish=false` on manual calls suppresses output history; it does **not** roll
back the target Status. The illustrative allocator therefore separates quoting
from actual debit. A failure after native materialization starts or during
settlement aborts that control: discard the simulation rather than retrying a
partly committed event. A quote failure retains the prepared event for an
explicit retry without resampling it.

The current architecture ports are `growth_intents`, `realized_growth_intents`
(allocation mode), `pending_growth_count`, and cumulative
`deferred_growth_count` (refused attempts). They complement `native_revision`.
Leave both call options unset for the ordinary native/PSE path. Set only
`before_growth_calls` for a demand observer without growth restriction.

## Native policy and scientific limits

Without PSE, `NativeAMAP.GrowthControl` accepts `before_growth(intent)::Bool`
and `after_growth(intent)` callbacks. Pass it as `growth_control` to
`advance_to!`; reuse that sidecar for the same native plant. Inspect waiting
immutable intentions with `pending_growth(control)`. It owns the cached
preparations separately from the botanical arenas. Callbacks receive no native
arena or RNG and must not mutate them indirectly.

A native intention identifies the axis, generation, original event sequence,
one-based physical rank, explicit product symbol/index, and original virtual
development time. PSE adds the complete, typed plant ObjectId. Its `bud_id`
denotes the native source axis/meristem slot, not a projected MTG node. Each
event currently creates one primary organ; lateral birth creates a bare axis,
whose own later apical events request their organs independently.

An unfunded organ blocks its own dependent axis continuation and branch births,
not unrelated existing axes. Each waiting event is tried once per outer call;
retries preserve its original identity and time. Later funding permits catch-up
to the current horizon. This preserves the earlier organ-allocation contract;
it is not a calibrated pause of biological development. Under limitation,
realization order can change subsequent branching-draw assignment. The abundant
case preserves the original native architecture, event queue, trace and RNG.

The public event clock is kept monotonic after the first refusal for geometry
projection. Native dimensions still follow nominal AMAPsim allometry: this gate
does not yet constrain expansion of existing organs, infer biomass from cones,
or charge maintenance/independent starvation mortality. Mass and construction
cost are explicit model inputs, with no automatic leaf area or unit conversion.
The example history models copy inspectable records and suit small coupling
demonstrations; a cheap native acceptance policy has a separate measured cost.

PlantGeom meshes, dynamic light and physiological models remain subsequent
adapters on this boundary. The existing coupled visualizer still uses the
package runtime.
