# A separate architectural model keeps reference-mode dispatch unchanged.
const DEVELOPMENT_RATE_CONTRACT = PSE.VariableContract(
    unit=:development_stage_per_second, basis=:plant, temporal=:step,
    aggregation=:mean, extent=:intensive)
const AXIS_DEVELOPMENT_RATES_CONTRACT = PSE.VariableContract(
    unit=:development_stage_per_second, basis=:axis, temporal=:step,
    aggregation=:state, extent=:intensive)
const MANAGEMENT_CUTS_CONTRACT = PSE.VariableContract(
    unit=:native_axis_cut, basis=:axis, temporal=:step,
    aggregation=:state, extent=:extensive)
const COUPLING_DURATION_CONTRACT = PSE.VariableContract(
    unit=:second, temporal=:step, aggregation=:total, extent=:intensive)

abstract type AbstractNativeDevelopmentRateModel <: PSE.AbstractModel end
PSE.process_(::Type{<:AbstractNativeDevelopmentRateModel}) = :native_development_rate

"""An explicitly supplied rate in virtual development stages per physical second."""
struct ConstantDevelopmentRate{T<:Real} <: AbstractNativeDevelopmentRateModel
    rate_per_second::T
end
function ConstantDevelopmentRate(; rate_per_second)
    value = _nonnegative_carbon(rate_per_second, "rate_per_second")
    return ConstantDevelopmentRate(float(value))
end
PSE.outputs_(model::ConstantDevelopmentRate) = (development_rate=model.rate_per_second,)
PSE.variable_contracts_(::ConstantDevelopmentRate) =
    (development_rate=DEVELOPMENT_RATE_CONTRACT,)
function PSE.run!(model::ConstantDevelopmentRate, status, environment, constants, context)
    status.development_rate = model.rate_per_second
    return nothing
end

function _coupled_duration_row(row::NamedTuple)
    haskey(row, :duration_seconds) || throw(ArgumentError(
        "coupled environments must provide duration_seconds"))
    seconds = NativeAMAP._development_number(row.duration_seconds,
        "duration_seconds"; positive=true)
    prepared = haskey(row, :duration) ? row : merge(row, (duration=seconds,))
    timeline_seconds = PSE.EnvironmentAPI.base_step_seconds(
        PSE.EnvironmentAPI.environment_backend(prepared))
    isapprox(seconds, timeline_seconds; atol=0.0, rtol=1e-12) || throw(ArgumentError(
        "duration_seconds must match the PSE timeline duration"))
    return prepared
end
function _coupled_environment(environment)
    environment isa NamedTuple && return _coupled_duration_row(environment)
    environment isa AbstractVector && all(row -> row isa NamedTuple, environment) &&
        return map(_coupled_duration_row, environment)
    return environment
end

struct CoupledArchitecture <: AMAPSim.AbstractArchitectureDevelopmentModel
    step_seconds::Float64
end
PSE.inputs_(::CoupledArchitecture) = (
    _native_pse_state=PSE.Required(NativePSEState),
    development_rate=PSE.Required(Real),
    axis_development_rates=PSE.Default(Dict{Int,Float64}()),
    management_cuts=PSE.Default(Int[]),
)
PSE.environment_inputs_(::CoupledArchitecture) = (duration_seconds=0.0,)
PSE.outputs_(::CoupledArchitecture) = (native_revision=0, physical_time_seconds=0.0)
PSE.variable_contracts_(::CoupledArchitecture) = (
    development_rate=DEVELOPMENT_RATE_CONTRACT,
    axis_development_rates=AXIS_DEVELOPMENT_RATES_CONTRACT,
    management_cuts=MANAGEMENT_CUTS_CONTRACT,
    duration_seconds=COUPLING_DURATION_CONTRACT,
    physical_time_seconds=PSE.VariableContract(unit=:second, basis=:plant,
        temporal=:instantaneous, aggregation=:state, extent=:intensive),
)

function _coupled_preflight(state, duration, rate, axis_rates, cuts)
    state.coupled_pending && throw(ArgumentError(
        "the previous coupled exchange did not complete; discard this simulation"))
    seconds = NativeAMAP._development_number(duration, "duration_seconds")
    typed_rate = NativeAMAP._development_number(rate, "development_rate")
    isfinite(state.development.physical_time + seconds) &&
        isfinite(state.development.default_development + typed_rate * seconds) || throw(ArgumentError(
        "coupled physical horizon must be finite"))
    NativeAMAP._bind_local_development!(state.development, state.native)
    state.organ_growth === nothing || !state.organ_growth.failed ||
        throw(ArgumentError("organ realization has failed"))
    axis_rates isa AbstractDict || throw(ArgumentError(
        "axis_development_rates must be a dictionary of native axis indices to rates"))
    for (id, value) in pairs(axis_rates)
        id isa Integer && !(id isa Bool) && 1 <= id <= length(state.native.plant.axes) ||
            throw(ArgumentError("a local rate requires an existing native axis index"))
        local_rate = NativeAMAP._development_number(value, "axis development rate")
        isfinite(NativeAMAP.axis_development(state.development, id) + local_rate * seconds) ||
            throw(ArgumentError("local developmental horizon must be finite"))
    end
    if state.development.used_local
        for id in 1:state.development.axis_count
            value = get(axis_rates, id, typed_rate)
            isfinite(NativeAMAP.axis_development(state.development, id) + value * seconds) ||
                throw(ArgumentError("local developmental horizon must be finite"))
        end
    end
    cuts isa AbstractVector || throw(ArgumentError("management_cuts must be an axis-index vector"))
    for id in cuts
        id isa Integer && !(id isa Bool) && 1 <= id <= length(state.native.plant.axes) ||
            throw(ArgumentError("a management cut requires an existing native axis index"))
    end
    return nothing
end

function PSE.run!(model::CoupledArchitecture, status, environment, constants, context)
    state = getproperty(status, _STATE)
    duration = environment.duration_seconds
    isapprox(duration, model.step_seconds; atol=0.0, rtol=1e-12) || throw(ArgumentError(
        "duration_seconds must match the PSE base step"))
    _coupled_preflight(state, duration, status.development_rate,
        status.axis_development_rates, status.management_cuts)
    state.coupled_pending = true
    # Commands apply at the beginning of this exchange. The full command batch
    # and clock inputs have been validated before any structural mutation.
    for id in status.management_cuts
        NativeAMAP.cut_axis!(state.native, id; development=state.development,
            geometry=false)
    end
    NativeAMAP.advance_development!(state.native, state.development, duration;
        default_rate=status.development_rate, axis_rates=status.axis_development_rates,
        geometry=state.geometry && state.organ_growth === nothing)
    if state.organ_growth !== nothing
        NativeAMAP.refresh_potential!(state.organ_growth, state.native;
            observation_times=NativeAMAP.development_observation_times(
                state.development, state.native))
        # Register potential newborns before organ-scale demand applications.
        # Their actual geometry is finalized at the later synchronization.
        isempty(state.groups) || _synchronize!(PSE.runtime_model(context), state)
    end
    status.physical_time_seconds = state.development.physical_time
    status.native_revision += 1
    return nothing
end

abstract type AbstractNativeSynchronizationModel <: PSE.AbstractModel end
PSE.process_(::Type{<:AbstractNativeSynchronizationModel}) = :native_synchronization
struct CoupledSynchronization{G} <: AbstractNativeSynchronizationModel end
function PSE.inputs_(::CoupledSynchronization{G}) where {G}
    base = (_native_pse_state=PSE.Required(NativePSEState),
        native_revision=PSE.Required(Integer))
    return G ? merge(base, (actual_geometry_revision=PSE.Required(Integer),)) : base
end
PSE.outputs_(::CoupledSynchronization) = (native_geometry_revision=0,)
function PSE.run!(::CoupledSynchronization{G}, status, environment, constants, context) where {G}
    state = getproperty(status, _STATE)
    state.coupled_pending || throw(ArgumentError("native synchronization has no active exchange"))
    if G
        state.organ_growth.committed_revision == state.organ_growth.revision ||
            throw(ArgumentError("actual expansion did not settle the current potential revision"))
    end
    isempty(state.groups) || _synchronize!(PSE.runtime_model(context), state)
    status.native_geometry_revision += 1
    state.coupled_pending = false
    return nothing
end

"""Cut a whole native axis/subtree and synchronize its projected PSE membership."""
function cut_axis!(model::PSE.CompositeModel, plant_id, axis_id::Integer)
    state = native_state(model, plant_id)
    state.development === nothing && throw(ArgumentError(
        "the boundary management API requires mode=:coupled"))
    state.coupled_pending && throw(ArgumentError(
        "management commands require a completed coupled exchange"))
    # Preflight before marking this exchange boundary as in progress.
    axis_id isa Bool && throw(ArgumentError("axis_id must be a native axis index"))
    1 <= axis_id <= length(state.native.plant.axes) || throw(ArgumentError(
        "axis_id must identify an existing native axis"))
    NativeAMAP._bind_local_development!(state.development, state.native)
    state.organ_growth === nothing || NativeAMAP._bind_organ_growth!(
        state.organ_growth, state.native)
    state.coupled_pending = true
    result = NativeAMAP.cut_axis!(state.native, axis_id;
        development=state.development, organ_growth=state.organ_growth,
        geometry=state.geometry)
    isempty(state.groups) || _synchronize!(model, state)
    state.coupled_pending = false
    return result
end

function _growth_application_specs(growth_models, plant_ids)
    growth_models isa NamedTuple && Set(keys(growth_models)) ==
        Set((:demand, :allocation, :expansion)) || throw(ArgumentError(
        "growth_models must contain demand, allocation and expansion models"))
    on = PSE.Many(scale=:Plant, id=plant_ids)
    return (
        PSE.ModelSpec(growth_models.demand; name=:native_demand, on),
        PSE.ModelSpec(growth_models.allocation; name=:native_allocation, on,
            inputs=(growth_demands=PSE.One(within=PSE.Self(),
                application=:native_demand, var=:growth_demands),)),
        PSE.ModelSpec(growth_models.expansion; name=:native_expansion, on,
            inputs=(growth_allocation=PSE.One(within=PSE.Self(),
                application=:native_allocation, var=:growth_allocation),)),
    )
end
