# Carbon allocation at the native/PSE boundary

Use this experimental path when each native organ has an explicit, fixed
construction demand and carbon supply changes at PSE exchange steps. PSE
prepares one typed policy frame per plant and step. The native growth loop
quotes and settles organs directly, without calling PSE for every organ.

For PSE models that calculate incremental demand from potential geometry and
control realized expansion, use the [structure–function mode](MODES.md).
The fixed whole-organ gate below remains an optional reference-mode policy;
the two accounting mechanisms cannot be combined in one scenario.

Load the development modules from a checkout, through Kaimon:

```julia
using AMAPSim, PlantSimEngine
include(joinpath(pkgdir(AMAPSim), "dev", "native", "native.jl"))
include(joinpath(pkgdir(AMAPSim), "dev", "native", "pse.jl"))
```

This example uses demonstration coefficients, not calibrated biomass or
allocation parameters for Merisier. Mass is in gDM and construction cost in
gC/gDM. Supply is cumulative gC since start, excluding the initial reserve.

```julia
policy = NativeAMAPPSE.FixedCarbonPolicy(
    organs=(
        Internode=(potential_dry_mass_g=0.02, construction_cost_gC_per_gDM=0.5),
        Leaf=(potential_dry_mass_g=0.01, construction_cost_gC_per_gDM=0.6),
    ),
    initial_reserve_gC=0.0,
)
input = joinpath(pkgdir(AMAPSim), "test", "fixtures", "native_originals", "merisier.fpa")
plant = NativeAMAPPSE.NativePlant(:tree, input; seed=1,
    development_increment=0.5, product_symbols=Dict("feuilles" => :Leaf))
model = NativeAMAPPSE.scenario((plant,); carbon_policy=policy,
    environment=[(duration=1.0, cumulative_carbon_supply_gC=supply)
        for supply in (0.0, 0.0, 1.0, 1.0)])
simulation = PlantSimEngine.run!(model; steps=4, outputs=:none)
status = model_status(model, :tree)
@assert status.carbon_policy_revision == status.native_revision == 4
@assert status.credited_carbon_supply_gC ≈
    status.remaining_carbon_gC + status.spent_carbon_gC
@assert status.allocated_organ_count > 0
@assert status.pending_growth_count == 0
@assert isempty(model_objects(model; scale=:Leaf))
```

The last assertion follows the model-driven exposure rule. Funding a Leaf
intention does not declare a PSE model on Leaf. To run a physiological model
there, add a real `ModelSpec` selecting that scale in `applications`. Native
leaves and their construction demands exist whether or not they are exposed.

## Policy execution and published state

The ordinary PSE dependency graph runs the policy application before native
architecture. Each plant receives an immutable policy frame and owns its own
typed reserve, cached waiting quotes and sampled native preparations. Typed
plant identities remain distinct even if their display strings are equal.

For each realized organ, the native controller quotes `spent + demand` against
`initial reserve + cumulative supply`. Quoting spends nothing. Only a successful
native commit adds demand to spent carbon. Remaining carbon is recomputed as
total supplied minus spent; repeated cumulative supply does not add it twice.
A refusal keeps the exact original preparation and demand for a later step,
while independent axes and pruning continue. Pruning discards obsolete quotes.

The native architecture publishes `remaining_carbon_gC`, `spent_carbon_gC`,
`credited_carbon_supply_gC`, `allocated_organ_count`, `pending_growth_count` and
cumulative `deferred_growth_count`. The policy's `carbon_policy_revision`
counts PSE preparations, not organ events. No per-organ demand, decision or
allocation history is retained by this path. Read the scalar totals rather
than copying the full private native state at every frame.

`carbon_policy` is exclusive with `before_growth_calls` and
`growth_allocation_call`. Keep the [per-organ PSE call example](CARBON.md) when
testing arbitrary demand/allocation applications or inspecting their full
histories. This optimization implements the same fixed whole-organ allocation
rule; it does not compile an arbitrary PSE model into a native callback.

## Scientific and lifecycle limits

Organ masses and construction costs stay fixed for the lifetime of this policy.
Supply must be finite, nonnegative and nondecreasing. Supply and allocations use
the initial reserve's floating-point type; unrepresentable values are rejected.
No mass, area, maintenance, respiration or carbon conversion is inferred from
the FPA or native geometry.

Each native preparation is sampled once, and allocation consumes no RNG.
Abundant carbon preserves the direct native architecture, queue, trace,
geometry and RNG. Under limited carbon, later branching draws can be assigned
in a different realization order. Retries retain original virtual event times
and can catch up; this remains a construction gate, not a calibrated biological
pause or progressive organ expansion law. Partial commit/settlement failures
poison the control, as in the [native transaction contract](CARBON.md).

The package runtime and visualizer still use their existing path. Dynamic
geometry, light and assimilation need explicit adapters and unit/time
conversions before they can supply integrated gC at this boundary.
