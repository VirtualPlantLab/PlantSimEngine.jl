# SPDX-License-Identifier: LGPL-3.0-or-later
# Scientific architecture rules derive from AMAPsim (1995-2018),
# copyright Jean-Francois Barczi and AMAPsim contributors, and AMAPSim.jl.
"""Experimental node-free plant scheduler. Correctness qualification is required.

This engine preserves the scientific apical kernels and implements botanical
ownership with integer links. It creates no MTG/PSE nodes, statuses or registry.
The only supported initialization is the zero-dormancy lane explicitly checked
by NativeAMAPScientificCore. Geometry is an independent arena pass.
"""
module NativeAMAPPlantEngine
import AMAPSim
using Random
import ..NativeAMAPScientificCore as Science

const V3 = NTuple{3,Float32}
const Frame = NTuple{3,V3}
const ZERO3 = (0f0,0f0,0f0)
const IDFRAME = ((0f0,0f0,1f0),(1f0,0f0,0f0),(0f0,1f0,0f0))
const UNDEFINED = UInt8(255)
const EPSILON = 1e-6
const APICAL = UInt8(1)
const PROGRESSIVE_PRUNING = UInt8(2)
const TOTAL_PRUNING = UInt8(3)

mutable struct PlantAxis
    parent::Int32
    bearer_site::Int32
    lateral_index::Int32
    slot::Int32
    whorl_size::Int32
    nature::Int32
    order::Int32
    reiteration_order::Int32
    immediate_order::Int32
    initial_age::Float64
    birth::Float64
    state::Science.NativeApicalState
    gu_ids::Vector{Int32}
    site_ids::Vector{Int32}
    organ_ids::Vector{Int32}
    children::Vector{Int32}
    active::Bool
    current_gu::Int32
    clip_first_gu_end::Float64
    legacy_states::NTuple{3,UInt8}
    immediate_positions::NTuple{3,Float64}
    immediate_zones::NTuple{3,Int32}
    immediate_semi::NTuple{3,AMAPSim.ImmediateSemiMarkovState}
    phyllotaxy_accumulator::NTuple{3,Float64}
    initial_phyllotaxy::Float64
    phyllotaxy::Float64
    priority::Int32
    process_id::Int64
    generation::UInt64
    branching_kind::UInt8
    first_gu_kind::UInt8
    pruning_reference_age::Float64
end

mutable struct PlantGU
    axis::Int32
    index::Int32
    reference_age::Float64
    first_dispatch::Float64
    end_time::Float64
    duration::Float64
    test_count::Int32
    realized_count::Int32
    site_ids::Vector{Int32}
    active::Bool
end

mutable struct PlantSite
    axis::Int32
    gu::Int32
    cycle::Int32
    zone::UInt8
    axis_test::Int32
    gu_test::Int32
    cycle_test::Int32
    axis_organ::Int32
    gu_organ::Int32
    cycle_organ::Int32
    time::Float64
    reference_age::Float64
    organ::Int32
    previous_organ_site::Int32
    next_organ_site::Int32
    branch_states::NTuple{3,UInt8}
    phyllotaxy::NTuple{3,Float64}
    active::Bool
end

mutable struct PlantOrgan
    site::Int32
    axis::Int32
    rank::Int32
    length::Float32
    diameter_top::Float32
    diameter_bottom::Float32
    base::V3
    tip::V3
    frame::Frame
    active::Bool
end

struct PlantEvent
    time::Float64
    priority::Int32
    process_id::Int64
    sequence::Int64
    axis::Int32
    generation::UInt64
    kind::UInt8
end

struct PlantTrace
    time::Float64
    axis::Int32
    process::UInt8
    gu::Int32
    cycle::Int32
    reference_age::Float64
    realized::Bool
    created_test::Bool
    growth_unit_ended::Bool
    bud_died::Bool
    tests::Int32
    organs::Int32
    next_time::Float64
end

mutable struct NativePlant{P,R<:AbstractRNG}
    parameters::P
    rng::R
    axes::Vector{PlantAxis}
    growth_units::Vector{PlantGU}
    sites::Vector{PlantSite}
    organs::Vector{PlantOrgan}
    events::Vector{PlantEvent}
    trace::Vector{PlantTrace}
    time::Float64
    last_event_time::Float64
    sequence::Int64
    processed::Int64
    cancelled::Int64
    geometry_complete::Bool
end

@inline value(p,args...) = AMAPSim.valueat(p,args...)
@inline integer(p,args...) = trunc(Int,value(p,args...))
@inline legacy(x::UInt8) = AMAPSim.LegacyBranchingSiteState(x)
@inline put3(t::NTuple{3,T},i::Int,v) where T = Base.setindex(t,convert(T,v),i)
@inline function before(a::PlantEvent,b::PlantEvent)
    a.time != b.time && return a.time < b.time
    a.priority != b.priority && return a.priority > b.priority
    a.process_id != b.process_id && return a.process_id > b.process_id
    return a.sequence > b.sequence
end

function enqueue!(plant::NativePlant,axis_id::Integer,time::Real,kind::UInt8=APICAL)
    isfinite(time) && time >= 0 || throw(ArgumentError("invalid native event time"))
    a=plant.axes[axis_id]; a.active || return nothing
    plant.sequence += 1
    e=PlantEvent(Float64(time),a.priority,a.process_id,plant.sequence,Int32(axis_id),a.generation,kind)
    return requeue!(plant,e)
end

"""Put an existing event back without changing its botanical scheduling identity."""
function requeue!(plant::NativePlant,e::PlantEvent)
    push!(plant.events,e); i=length(plant.events)
    while i>1
        parent=i>>>1
        before(plant.events[parent],e) && break
        plant.events[i]=plant.events[parent]; i=parent
    end
    plant.events[i]=e
    return e
end

function dequeue!(plant::NativePlant)
    heap=plant.events; first=heap[1]; last=pop!(heap)
    if !isempty(heap)
        i=1; n=length(heap)
        while 2i<=n
            left=2i; right=left+1
            child=right<=n && before(heap[right],heap[left]) ? right : left
            before(last,heap[child]) && break
            heap[i]=heap[child]; i=child
        end
        heap[i]=last
    end
    return first
end

"""Optional validation hooks; the production hot path has no observers."""
before_event!(::AbstractRNG,plant::NativePlant,event::PlantEvent)=nothing
after_event!(::AbstractRNG,plant::NativePlant,event::PlantEvent,plan)=nothing
before_branch_law!(::AbstractRNG,plant::NativePlant,axis::Int,site::Int,lp::Int,kind::UInt8)=nothing
before_axis_initialization!(::AbstractRNG,axis_id::Integer)=nothing
after_axis_initialization!(::AbstractRNG,token)=nothing
axillary_trial!(rng::AbstractRNG,plant::NativePlant,site_id::Int,lp_id::Int,slot::Int,count::Int,p)=
    AMAPSim.sample_bernoulli(rng,p)

function new_axis(parameters,rng,age,birth;parent=0,bearer_site=0,lateral_index=0,
    slot=0,whorl_size=1,nature=0,order=0,reiteration_order=0,immediate_order=0,
    priority=10,process_id=1,rhythm=1.0,branching_kind=0,clip=Inf,phyllotaxy=0.0)
    token=before_axis_initialization!(rng,process_id)
    state=try
        Science.initialize_apical(parameters,rng,age;rhythm,birth)
    finally
        after_axis_initialization!(rng,token)
    end
    clipped_end=isfinite(clip) ? min(Float64(clip),Float64(birth)+
        state.growth_unit_test_count*state.time_per_test) : Inf
    return PlantAxis(parent,bearer_site,lateral_index,slot,whorl_size,nature,order,
        reiteration_order,immediate_order,age,birth,state,Int32[],Int32[],Int32[],Int32[],
        true,0,clipped_end,(UNDEFINED,UNDEFINED,UNDEFINED),(NaN,NaN,NaN),(0,0,0),
        ntuple(_->AMAPSim.ImmediateSemiMarkovState(),3),(0.,0.,0.),0.,phyllotaxy,
        priority,process_id,0,branching_kind,branching_kind,NaN)
end

function initialize(parameters,rng::AbstractRNG=Xoshiro(1);compiled=false)
    p=compiled ? parameters : Science.compile_parameters(parameters)
    1<=length(p.lateral_productions)<=3 || throw(ArgumentError("native plant supports one to three LPs"))
    for lp in p.lateral_productions
        lp.organ_symbol===:Internode || throw(ArgumentError("native plant currently requires Internode LP products"))
    end
    if isdefined(Science,:ensure_supported_initial_dormancy)
        Science.ensure_supported_initial_dormancy(p)
    end
    root=new_axis(p,rng,Float64(p.initialization.initial_physiological_age),0.)
    plant=NativePlant(p,rng,PlantAxis[root],PlantGU[],PlantSite[],PlantOrgan[],
        PlantEvent[],PlantTrace[],0.,0.,0,0,0,false)
    enqueue!(plant,1,root.state.next_time)
    return plant
end
initialize(fpa::AbstractString,rng::AbstractRNG=Xoshiro(1);kwargs...)=
    initialize(AMAPSim.read_parameters(fpa),rng;kwargs...)

@inline function child_order(plant,a,lp,age)
    outer=integer(lp.global_parameters.nature,age+1)
    outer>=10 && return nothing
    if outer==0
        maximum=integer(plant.parameters.axis.topology.maximum_branching_order_nature_zero,a.initial_age-1)
        a.order+1>maximum && return nothing
    end
    nature=integer(lp.global_parameters.nature,age)
    return (nature=nature,order=nature==0 ? Int(a.order)+1 : Int(a.order))
end

function birth_slots!(plant,axis_id,site_id,lp_id,init,birth,kind::UInt8,age)
    a=plant.axes[axis_id]; lp=plant.parameters.lateral_productions[lp_id]
    context=child_order(plant,a,lp,age); context===nothing && return
    reiteration=AMAPSim.reiteration_order(plant.parameters.axis.topology,a.initial_age-1,
        age,init.physiological_age,Int(a.reiteration_order))
    reiteration===nothing && return
    count=integer(lp.global_parameters.axillary_count,age)
    probability=value(lp.global_parameters.axillary_probability,age)
    site=plant.sites[site_id]
    for slot in 1:count
        axillary_trial!(plant.rng,plant,site_id,lp_id,slot,count,probability) || continue
        immediate=kind==1 || kind==2
        immediate_order=immediate ? Int(a.immediate_order)+1 : 0
        clip=immediate ? plant.growth_units[site.gu].end_time : Inf
        phyllotaxy=AMAPSim.branch_azimuth(site.phyllotaxy[lp_id],lp,age,slot,count;
            initial_angle=a.initial_phyllotaxy)
        child=new_axis(plant.parameters,plant.rng,init.physiological_age,Float64(birth);
            parent=Int32(axis_id),bearer_site=Int32(site_id),lateral_index=Int32(lp_id),
            slot=Int32(slot-1),whorl_size=Int32(count),nature=Int32(context.nature),
            order=Int32(context.order),reiteration_order=Int32(reiteration),
            immediate_order=Int32(immediate_order),priority=a.priority+11,
            process_id=Int64(length(plant.axes)+1),rhythm=init.rhythm,
            branching_kind=kind,clip,phyllotaxy)
        push!(plant.axes,child); id=Int32(length(plant.axes)); push!(a.children,id)
        # A first dispatch beyond the bearer end still runs in the source. Its
        # first GU can convert from immediate to delayed at that dispatch.
        enqueue!(plant,id,child.state.next_time)
    end
    return nothing
end

function immediate!(plant,axis_id,site_id,lp_id,plan,time)
    a=plant.axes[axis_id]; state=a.state; lp=plant.parameters.lateral_productions[lp_id]
    age=plan.reference_age; pos=plan.branch_position; zone_id=plan.branching_zone_index
    context=child_order(plant,a,lp,age)
    existing_axes=length(plant.axes); floating=false
    if context!==nothing && a.nature!=2 && AMAPSim.is_immediate_production_position(lp,age,pos)
        floating=integer(lp.global_parameters.delayed_branch_counting_direction,age)!=0
        if AMAPSim.is_immediate_state_reset_position(plant.parameters,age+1;
            test_index_within_growth_unit=state.test_index_within_growth_unit,
            test_index_within_cycle=state.test_index_within_cycle,test_index_on_axis=state.test_count_on_axis)
            a.legacy_states=put3(a.legacy_states,lp_id,UNDEFINED)
            a.immediate_positions=put3(a.immediate_positions,lp_id,NaN)
            a.immediate_zones=put3(a.immediate_zones,lp_id,0)
            a.immediate_semi=put3(a.immediate_semi,lp_id,AMAPSim.ImmediateSemiMarkovState())
        end
        zone=lp.zones[zone_id]
        before_branch_law!(plant.rng,plant,axis_id,site_id,lp_id,UInt8(1))
        if lp.branching_models[2]==AMAPSim.MarkovModel
            old=legacy(a.legacy_states[lp_id]); previous=AMAPSim._immediate_state_from_branching_site(old)
            previous===nothing && old==AMAPSim.BranchingSiteUndefined && pos>0 && state.internode_count_on_axis>1 && (previous=false)
            previous_zone=Int(a.immediate_zones[lp_id]); previous_pos=a.immediate_positions[lp_id]
            transition=AMAPSim.sample_immediate_markov_state(plant.rng,zone,age,pos,previous;
                previous_branching=previous_zone==0 ? nothing : lp.zones[previous_zone].branching,
                previous_position=isnan(previous_pos) ? nothing : previous_pos)
            branched=transition.branched
            code=UInt8(branched ? AMAPSim.BranchingSiteImmediate : AMAPSim.BranchingSiteImmediateUnbranched)
            a.legacy_states=put3(a.legacy_states,lp_id,code)
            plant.sites[site_id].branch_states=put3(plant.sites[site_id].branch_states,lp_id,code)
        else
            old=AMAPSim._immediate_semimarkov_input_state(a.immediate_semi[lp_id],legacy(a.legacy_states[lp_id]))
            next=AMAPSim.advance_immediate_semimarkov_state(plant.rng,zone,age,pos,old)
            a.immediate_semi=put3(a.immediate_semi,lp_id,next); branched=next.branched::Bool
            if old.remaining_positions<=0
                a.legacy_states=put3(a.legacy_states,lp_id,UInt8(branched ? AMAPSim.BranchingSiteImmediate : AMAPSim.BranchingSiteImmediateUnbranched))
            end
        end
        if branched && value(lp.global_parameters.axillary_probability,age)>0
            init=AMAPSim.sample_immediate_branch_initialization(plant.rng,zone,age,pos;
                current_reference_age=state.vigor.reference_age,growth_unit_ended=plan.growth_unit_ended)
            birth=context.nature==2 ? time-state.time_per_test : time
            birth_slots!(plant,axis_id,site_id,lp_id,init,birth,UInt8(1),age)
        end
    end
    a.immediate_positions=put3(a.immediate_positions,lp_id,Float64(pos))
    a.immediate_zones=put3(a.immediate_zones,lp_id,Int32(zone_id))
    floating && floating_cleanup!(plant,axis_id,lp_id,age,existing_axes)
    return nothing
end

function position(plant,site::PlantSite,age,direction;unit_override=nothing,existing=false)
    a=plant.axes[site.axis]; state=a.state; p=plant.parameters
    base=integer(p.axis.topology.topology_counting_base,age)
    unit=unit_override===nothing ? integer(p.axis.topology.topology_counting_unit,age) : unit_override
    gu=plant.growth_units[site.gu]
    if base==0
        rank=unit==0 ? site.gu_test : unit==1 ? site.cycle_test : site.axis_test
        total=unit==0 ? (existing ? gu.test_count : state.test_index_within_growth_unit) :
            unit==1 ? cycle_count(plant,site.gu,site.cycle,false) : state.test_count_on_axis
    else
        rank=unit==0 ? site.gu_organ : unit==1 ? site.cycle_organ : site.axis_organ
        total=unit==0 ? (existing ? gu.realized_count : state.internode_count_within_growth_unit) :
            unit==1 ? cycle_count(plant,site.gu,site.cycle,true) : state.internode_count_on_axis
    end
    rank>0 || throw(ArgumentError("physical branching site lacks required rank"))
    return direction==0 ? Int(rank)-1 : Int(total-rank)
end

function cycle_count(plant,gu_id,cycle,physical)
    count=0
    for id in plant.growth_units[gu_id].site_ids
        s=plant.sites[id]; s.active && s.cycle==cycle || continue
        (!physical || s.organ!=0) && (count+=1)
    end
    return count
end

function neighbor(plant,site,direction)
    id=direction==0 ? site.previous_organ_site : site.next_organ_site
    return id==0 ? nothing : plant.sites[id]
end

function initial_scan_state(plant,a,site,age,direction,lp_id)
    direction!=0 && return AMAPSim.BranchingSiteUndefined
    unit=integer(plant.parameters.axis.topology.topology_counting_unit,age+1)
    rank=unit==0 ? site.gu_test : unit==1 ? site.cycle_test : site.axis_test
    rank==1 && return AMAPSim.BranchingSiteUndefined
    a.legacy_states[lp_id]==UNDEFINED && return AMAPSim.BranchingSiteUndefined
    previous=neighbor(plant,site,direction)
    return previous===nothing ? AMAPSim.BranchingSiteUndefined : legacy(previous.branch_states[lp_id])
end

function delayed_unit(plant,site,lp,zone,age)
    configured=integer(plant.parameters.axis.topology.topology_counting_unit,age)
    dir=integer(lp.global_parameters.delayed_branch_strength_direction,age)
    pos=position(plant,site,age,dir;unit_override=configured)
    jump=integer(zone.branching.delayed_type_1_minimum_jump,age,pos)
    return jump==0 ? 0 : configured
end

"""Retrospective delayed, cycle-delayed and traumatic scans in LP source order."""
function retrospective!(plant,axis_id,lp_id,plan,kind::UInt8)
    a=plant.axes[axis_id]; a.nature==2 && return
    lp=plant.parameters.lateral_productions[lp_id]; age=plan.reference_age
    child_order(plant,a,lp,age)===nothing && return
    kind==UInt8(2) && !(plan.cycle_ended && !plan.growth_unit_ended) && return
    kind==UInt8(3) && !plan.growth_unit_ended && return
    if kind==UInt8(5)
        plan.bud_died || return
        integer(lp.global_parameters.bearing_axis_death_influence,age+1)==1 || return
    end
    markov=kind==UInt8(2) ? lp.branching_models[3]==AMAPSim.MarkovModel : lp.branching_models[1]==AMAPSim.MarkovModel
    kind==UInt8(2) && !markov && return # source ignores this unsupported lane
    gu=plant.growth_units[a.current_gu]
    ids=Int32[]
    for id in gu.site_ids
        s=plant.sites[id]
        s.active && s.organ!=0 || continue
        kind==UInt8(2) && s.cycle!=a.state.cycle_index && continue
        push!(ids,id)
    end
    isempty(ids) && return
    direction=integer(lp.global_parameters.delayed_branch_counting_direction,age)
    direction!=0 && reverse!(ids)
    previous=initial_scan_state(plant,a,plant.sites[first(ids)],age,direction,lp_id)
    semi=AMAPSim.DelayedSemiMarkovState(AMAPSim._delayed_semimarkov_state_from_branching_site(previous),0)
    trauma=AMAPSim.TraumaticSemiMarkovState(AMAPSim._traumatic_semimarkov_seed(previous),0)
    start=value(lp.global_parameters.production_start,age)-1
    stop=value(lp.global_parameters.production_end,age)-1
    occurrence=value(lp.global_parameters.axillary_probability,age)
    for id in ids
        s=plant.sites[id]; code=legacy(s.branch_states[lp_id])
        available=kind==UInt8(2) ? AMAPSim._markov_cycle_delayed_site_available(code) : AMAPSim._markov_delayed_site_available(code)
        markov && (occurrence==0 || !available) && continue
        zone=lp.zones[s.zone]
        unit=kind==UInt8(3) && markov ? delayed_unit(plant,s,lp,zone,age) : nothing
        basal=position(plant,s,age,0;unit_override=unit)
        if markov && basal<start
            previous=AMAPSim.BranchingSiteUndefined
            s.branch_states=put3(s.branch_states,lp_id,UInt8(previous)); continue
        elseif markov && basal>stop
            previous=AMAPSim.BranchingSiteUnbranched
            s.branch_states=put3(s.branch_states,lp_id,UInt8(previous)); continue
        end
        pos=position(plant,s,age,direction;unit_override=unit)
        before_branch_law!(plant.rng,plant,axis_id,Int(id),lp_id,kind)
        physical=neighbor(plant,s,direction)
        if kind==UInt8(3)
            if markov
                effective=previous
                if pos==0 || physical===nothing
                    effective=AMAPSim.BranchingSiteUndefined
                elseif previous!=AMAPSim.BranchingSiteUndefined
                    prev_zone=lp.zones[physical.zone]
                    prev_dir=integer(lp.global_parameters.delayed_branch_counting_direction,physical.reference_age)
                    prev_pos=position(plant,physical,physical.reference_age,prev_dir;unit_override=unit,existing=true)
                    current_p=AMAPSim._delayed_initial_probability(zone.branching,age,pos,previous)
                    previous_p=AMAPSim._delayed_initial_probability(prev_zone.branching,age,prev_pos,previous)
                    current_p!=previous_p && (effective=AMAPSim.BranchingSiteUndefined)
                end
                transition=AMAPSim.sample_delayed_markov_state(plant.rng,zone,age,pos,
                    AMAPSim._delayed_state_from_branching_site(effective))
                previous=AMAPSim._delayed_markov_result_state(effective,transition.state)
                branch_type=transition.state
                emitted=previous in (AMAPSim.BranchingSiteDelayedType1,AMAPSim.BranchingSiteDelayedType2)
            else
                transition=AMAPSim.advance_delayed_semimarkov_state(plant.rng,zone,age,pos,semi)
                semi=transition.next_state; branch_type=transition.current_state
                previous=branch_type==AMAPSim.DelayedUnbranched ? AMAPSim.BranchingSiteUnbranched :
                    branch_type==AMAPSim.DelayedType1 ? AMAPSim.BranchingSiteDelayedType1 : AMAPSim.BranchingSiteDelayedType2
                emitted=transition.emitted_branch && start<=basal<=stop
            end
        elseif kind==UInt8(2)
            old=AMAPSim._cycle_delayed_state_from_branching_site(previous)
            reset=AMAPSim._cycle_delayed_reset_state(previous)
            prev_p=reset===nothing || physical===nothing ? nothing :
                value(lp.zones[physical.zone].branching.cycle_delayed_initial_probability,age,
                    position(plant,physical,physical.reference_age,direction;existing=true))
            transition=AMAPSim.sample_cycle_delayed_markov_state(plant.rng,zone,age,pos,old;
                previous_initial_probability=prev_p)
            emitted=transition.branched
            previous=emitted ? AMAPSim.BranchingSiteCycleDelayed : AMAPSim.BranchingSiteCycleDelayedUnbranched
        else
            if markov
                old=AMAPSim._traumatic_state_from_branching_site(previous)
                reset=AMAPSim._traumatic_reset_state(previous)
                prev_p=reset===nothing || physical===nothing ? nothing :
                    value(lp.zones[physical.zone].branching.traumatic_initial_probability,age,
                        position(plant,physical,physical.reference_age,direction;existing=true))
                transition=AMAPSim.sample_traumatic_markov_state(plant.rng,zone,age,pos,old;
                    previous_initial_probability=prev_p)
                emitted=transition.branched
            else
                transition=AMAPSim.advance_traumatic_semimarkov_state(plant.rng,zone,age,pos,trauma)
                trauma=transition.next_state; emitted=transition.emitted_branch && start<=basal<=stop
            end
            previous=emitted ? AMAPSim.BranchingSiteTraumatic : AMAPSim.BranchingSiteTraumaticUnbranched
        end
        s.branch_states=put3(s.branch_states,lp_id,UInt8(previous))
        emitted && occurrence>0 || continue
        strength=position(plant,s,age,integer(lp.global_parameters.delayed_branch_strength_direction,age))
        if kind==UInt8(3)
            init=AMAPSim.sample_delayed_branch_initialization(plant.rng,zone,plant.parameters.axis.growth,
                age,strength,branch_type;current_reference_age=a.state.vigor.reference_age)
            child_kind=branch_type==AMAPSim.DelayedType1 ? UInt8(3) : UInt8(4)
        elseif kind==UInt8(2)
            init=AMAPSim.sample_cycle_delayed_branch_initialization(plant.rng,zone,age,strength;
                current_reference_age=a.state.vigor.reference_age)
            child_kind=UInt8(2)
        else
            init=AMAPSim.sample_traumatic_branch_initialization(plant.rng,zone,plant.parameters.axis.growth,
                age,strength;current_reference_age=a.state.vigor.reference_age)
            child_kind=UInt8(5)
        end
        birth_slots!(plant,axis_id,Int(id),lp_id,init,plan.theoretical_growth_unit_end_time,child_kind,age)
    end
    a.legacy_states=put3(a.legacy_states,lp_id,UInt8(previous))
    return nothing
end

function remove_axis!(plant,id::Integer)
    a=plant.axes[id]; a.active || return
    a.active=false; a.generation+=1
    for child in a.children; remove_axis!(plant,child); end
    for gu_id in a.gu_ids; plant.growth_units[gu_id].active=false; end
    for sid in a.site_ids; plant.sites[sid].active=false; end
    for oid in a.organ_ids; plant.organs[oid].active=false; end
    return nothing
end

function remove_terminal_gu!(plant,id::Integer)
    a=plant.axes[id]
    index=findlast(gid->plant.growth_units[gid].active,a.gu_ids)
    index===nothing && return remove_axis!(plant,id)
    gid=a.gu_ids[index]; gu=plant.growth_units[gid]; gu.active=false
    for sid in gu.site_ids
        s=plant.sites[sid]; s.active=false
        s.organ!=0 && (plant.organs[s.organ].active=false)
        for child in a.children
            plant.axes[child].bearer_site==sid && remove_axis!(plant,child)
        end
    end
    # Counters are surviving botanical ranks, as after native terminal GU removal.
    a.state.test_count_on_axis-=gu.test_count
    a.state.internode_count_on_axis-=gu.realized_count
    a.state.growth_unit_index-=1
    return nothing
end

function floating_cleanup!(plant,axis_id,lp_id,age,existing_axes::Int)
    a=plant.axes[axis_id]; lp=plant.parameters.lateral_productions[lp_id]
    direction=integer(lp.global_parameters.delayed_branch_counting_direction,age)
    direction==0 && return
    stop=value(lp.global_parameters.production_end,age)
    unit=integer(plant.parameters.axis.topology.topology_counting_unit,age)
    scope=unit==0 ? a.state.internode_count_within_growth_unit :
        unit==1 ? a.state.internode_count_within_cycle : a.state.internode_count_on_axis
    for child_id in a.children
        child_id<=existing_axes || continue
        child=plant.axes[child_id]
        child.active && child.lateral_index==lp_id && child.branching_kind==1 || continue
        site=plant.sites[child.bearer_site]
        if AMAPSim.is_outside_apical_production_window(a.state.internode_count_on_axis,
            scope,Int(site.axis_organ),stop)
            remove_axis!(plant,child_id)
        end
    end
    return nothing
end

function schedule_pruning!(plant,id,plan,time)
    a=plant.axes[id]; isempty(a.gu_ids) && return
    age=max(0.,plant.growth_units[first(a.gu_ids)].reference_age)
    a.pruning_reference_age=age
    p=plant.parameters.axis.topology
    death=plan.bud_died ? Float32(value(p.pruning_lag_after_axis_death,age)) : 9999f0
    ended=plan.axis_ended ? Float32(value(p.pruning_lag_after_axis_end,age))+2f-6 : 9999f0
    total=Float64(Float32(time)+min(death,ended))
    coefficient=value(p.progressive_pruning_coefficient,age)
    # endGu raises native Bud.nextTime to endInstant before pruning is planned.
    # Total pruning still starts from the dispatch clock in Float32.
    native_next=plan.growth_unit_ended ? max(Float64(time),
        Float64(plan.theoretical_growth_unit_end_time)) : Float64(time)
    if coefficient>0 && native_next+1<total
        enqueue!(plant,id,native_next+1,PROGRESSIVE_PRUNING)
    else
        enqueue!(plant,id,total,TOTAL_PRUNING)
    end
    return nothing
end

function prune!(plant,event)
    a=plant.axes[event.axis]
    if event.kind==PROGRESSIVE_PRUNING
        coefficient=value(plant.parameters.axis.topology.progressive_pruning_coefficient,a.pruning_reference_age)
        has_gu=any(id->plant.growth_units[id].active,a.gu_ids)
        result=AMAPSim.sample_progressive_pruning_step(plant.rng,coefficient;has_growth_units=has_gu)
        if result.action==AMAPSim.RemoveTerminalGrowthUnit
            remove_terminal_gu!(plant,event.axis)
            a.active && enqueue!(plant,event.axis,event.time+1,PROGRESSIVE_PRUNING)
            return
        end
    end
    remove_axis!(plant,event.axis)
end

function append_site!(plant,axis_id,plan,time,tail_offset::Int=0)
    a=plant.axes[axis_id]; state=a.state; gu=plant.growth_units[a.current_gu]
    tail=Int(plan.cycle_tail_test_count)
    axis_test=state.test_count_on_axis-tail+tail_offset
    gu_test=state.test_index_within_growth_unit-tail+tail_offset
    cycle_test=state.test_index_within_cycle-tail+tail_offset
    realized=tail_offset==0 && plan.realized
    previous=isempty(a.organ_ids) ? 0 : plant.organs[last(a.organ_ids)].site
    site=PlantSite(axis_id,a.current_gu,state.cycle_index,UInt8(plan.branching_zone_index),
        axis_test,gu_test,cycle_test,realized ? state.internode_count_on_axis : 0,
        realized ? state.internode_count_within_growth_unit : 0,
        realized ? state.internode_count_within_cycle : 0,Float64(time),plan.reference_age,
        0,previous,0,(UNDEFINED,UNDEFINED,UNDEFINED),a.phyllotaxy_accumulator,true)
    push!(plant.sites,site); sid=Int32(length(plant.sites)); push!(a.site_ids,sid); push!(gu.site_ids,sid)
    if realized
        previous!=0 && (plant.sites[previous].next_organ_site=sid)
        oid=Int32(length(plant.organs)+1); site.organ=oid
        push!(plant.organs,PlantOrgan(sid,axis_id,state.internode_count_on_axis-1,
            0f0,0f0,0f0,ZERO3,ZERO3,IDFRAME,true));push!(a.organ_ids,oid)
        phase=a.phyllotaxy_accumulator
        for lp_id in eachindex(plant.parameters.lateral_productions)
            phase=put3(phase,lp_id,AMAPSim.advance_phyllotaxy(phase[lp_id],
                plant.parameters.lateral_productions[lp_id],plan.reference_age+1))
        end
        a.phyllotaxy_accumulator=phase
    end
    return sid
end

"""Source limitGuTime, calculated against the bearer at the original dispatch."""
function first_gu_timing(plant,a,state,event_time; bearer_end=nothing)
    clip=a.clip_first_gu_end; kind=a.first_gu_kind
    a.current_gu==0 && a.parent!=0 && (kind==1 || kind==2) || return (;clip,kind)
    bearer=plant.axes[a.parent]
    bearer.current_gu!=0 || throw(ArgumentError("first native GU requires a bearer GU"))
    bearer_end=bearer_end===nothing ? plant.growth_units[bearer.current_gu].end_time :
        Float64(bearer_end)
    duration=Float64(AMAPSim.growth_unit_timing(plant.parameters,
        state.vigor.reference_age;rhythm=state.rhythm).duration)
    own_end=Float64(event_time)-state.time_per_test+duration
    clip=min(own_end,bearer_end)
    if a.nature!=2 && event_time>bearer_end+EPSILON
        # Keep branching_kind: geometry uses the original birth mechanism.
        kind=UInt8(3)
        clip+=duration
    end
    return (;clip,kind)
end

"""Source limitGuTime, applied at the first dispatch before creating its GU."""
function initialize_first_gu_time!(plant,axis_id,event_time)
    a=plant.axes[axis_id]
    timing=first_gu_timing(plant,a,a.state,event_time)
    a.clip_first_gu_end=timing.clip; a.first_gu_kind=timing.kind
    return nothing
end

"""Prepare only one apical transition; the caller owns the supplied state.

The ordinary lane supplies its live state. Growth control supplies a separate
state and retains this transition while an organ waits for resources. No arena,
branching or phyllotaxy mutation occurs here, and first-GU clipping is captured
now rather than recomputed against a later bearer GU when the organ is funded.
"""
function prepare_apical!(plant,event,state=plant.axes[event.axis].state; bearer_end=nothing)
    a=plant.axes[event.axis]
    timing=first_gu_timing(plant,a,state,event.time; bearer_end=bearer_end)
    interval_before=state.time_per_test
    nominal_tests_before=state.growth_unit_test_count
    if state.growth_unit_index==0 && a.immediate_order>0 && a.nature!=2
        maximum=integer(plant.parameters.axis.topology.maximum_immediate_branching_order,state.vigor.reference_age)
        if a.immediate_order>maximum+1
            state.ended=true
            return (;state,timing,interval_before,nominal_tests_before,plan=nothing)
        end
    end
    plan=Science.apical_plan!(state,plant.parameters,plant.rng,event.time)
    if isfinite(timing.clip) && (plan.growth_unit_ended ||
        event.time+interval_before>timing.clip+EPSILON)
        plan=Science.force_growth_unit_end!(state,plant.parameters,plant.rng,plan;
            end_time=timing.clip)
        if !state.ended && event.time>timing.clip
            # A nature-2 first dispatch can be later than its clipped end.
            # Source endGu retains max(nextTime,endInstant) for future events.
            plan=merge(plan,(next_time=Float64(event.time)+state.time_per_test,))
        end
    end
    return (;state,timing,interval_before,nominal_tests_before,plan)
end

"""Commit one prepared transition in the original native botanical/RNG order."""
function commit_apical!(plant,event,prepared)
    id=Int(event.axis); a=plant.axes[id]
    state=prepared.state; a.state=state
    a.clip_first_gu_end=prepared.timing.clip; a.first_gu_kind=prepared.timing.kind
    plan=prepared.plan
    plan===nothing && return nothing
    gu_end=isfinite(a.clip_first_gu_end) ? a.clip_first_gu_end :
        plan.theoretical_growth_unit_end_time
    if plan.starts_growth_unit
        gu=PlantGU(id,state.growth_unit_index,plan.reference_age,event.time,
            gu_end,
            prepared.nominal_tests_before*prepared.interval_before,0,0,Int32[],true)
        push!(plant.growth_units,gu);a.current_gu=Int32(length(plant.growth_units));push!(a.gu_ids,a.current_gu)
    end
    gu=plant.growth_units[a.current_gu]
    gu.test_count=Int32(state.test_index_within_growth_unit)
    gu.realized_count=Int32(state.internode_count_within_growth_unit)
    gu.end_time=gu_end
    sid=plan.creates_test_site ? append_site!(plant,id,plan,event.time) : Int32(0)
    for offset in 1:Int(plan.cycle_tail_test_count);append_site!(plant,id,plan,event.time,offset);end
    for lp_id in eachindex(plant.parameters.lateral_productions)
        sid!=0 && plan.realized && immediate!(plant,id,Int(sid),lp_id,plan,event.time)
        retrospective!(plant,id,lp_id,plan,UInt8(2))
        retrospective!(plant,id,lp_id,plan,UInt8(5))
        retrospective!(plant,id,lp_id,plan,UInt8(3))
    end
    plan.growth_unit_ended && (a.clip_first_gu_end=Inf)
    after_event!(plant.rng,plant,event,plan)
    push!(plant.trace,PlantTrace(event.time,id,APICAL,state.growth_unit_index,state.cycle_index,
        plan.reference_age,plan.realized,plan.creates_test_site,plan.growth_unit_ended,plan.bud_died,
        state.test_count_on_axis,state.internode_count_on_axis,plan.next_time===nothing ? Inf : plan.next_time))
    Science.finish_apical!(state,plan)
    if state.ended
        schedule_pruning!(plant,id,plan,event.time)
    else
        enqueue!(plant,id,state.next_time)
    end
    return plan
end

function apical!(plant,event)
    return commit_apical!(plant,event,prepare_apical!(plant,event))
end

function advance_to!(plant::NativePlant,horizon::Real;max_events=10_000_000)
    isfinite(horizon) && horizon>=plant.time || throw(ArgumentError("native horizon must increase"))
    while !isempty(plant.events) && first(plant.events).time<=horizon+EPSILON
        plant.processed<max_events || error("native event bound exceeded")
        event=dequeue!(plant); a=plant.axes[event.axis]
        if !a.active || event.generation!=a.generation
            plant.cancelled+=1;continue
        end
        plant.last_event_time=event.time
        before_event!(plant.rng,plant,event)
        event.kind==APICAL ? apical!(plant,event) : prune!(plant,event)
        plant.processed+=1
    end
    plant.time=Float64(horizon);plant.geometry_complete=false
    return plant
end

"""Separate implementation supplied by the native geometry pass."""
function geometry! end

function observations(plant::NativePlant;geometry=plant.geometry_complete)
    geometry && !plant.geometry_complete && throw(ArgumentError("native geometry has not been computed"))
    live=findall(a->a.active,plant.axes); ordinals=zeros(Int,length(plant.axes))
    for (i,id) in enumerate(live);ordinals[id]=i;end
    axes=Dict{String,Any}[]
    for id in live
        a=plant.axes[id];s=a.bearer_site==0 ? nothing : plant.sites[a.bearer_site]
        physical_bearer=s===nothing ? -1 : Int(s.axis_organ)-1
        test_bearer=s===nothing ? -1 : Int(s.axis_test)-1
        push!(axes,Dict{String,Any}("axis_id"=>ordinals[id],"parent_axis_id"=>a.parent==0 ? 0 : ordinals[a.parent],
            # The historical C++ performance key names its physical INTERNODE
            # index as a test index. Preserve that wire key, expose both ranks.
            "bearer_test_index_zero_based"=>physical_bearer,
            "bearer_physical_index_zero_based"=>physical_bearer,
            "bearer_axis_test_index_zero_based"=>test_bearer,
            "nature"=>Int(a.nature),"lp_index_zero_based"=>max(0,Int(a.lateral_index)-1),
            "whorl_slot_zero_based"=>Int(a.slot),"whorl_size"=>Int(a.whorl_size),
            "phy_age_initial"=>a.initial_age,"growth_unit_count"=>count(gid->plant.growth_units[gid].active,a.gu_ids),
            "realized_count"=>count(oid->plant.organs[oid].active,a.organ_ids),
            "test_count"=>count(sid->plant.sites[sid].active,a.site_ids),"birth_time"=>a.birth))
    end
    organs=Dict{String,Any}[]
    if geometry
        for o in plant.organs
            o.active && ordinals[o.axis]>0 || continue
            push!(organs,Dict{String,Any}("axis_id"=>ordinals[o.axis],"axis_internode_index_zero_based"=>Int(o.rank),
                "base"=>Float64[o.base...],"tip"=>Float64[o.tip...],"length"=>Float64(o.length),
                "diameter_top"=>Float64(o.diameter_top),"diameter_bottom"=>Float64(o.diameter_bottom),
                "frame_main"=>Float64[o.frame[1]...],"frame_secondary"=>Float64[o.frame[2]...],"frame_normal"=>Float64[o.frame[3]...]))
        end
    end
    return Dict{String,Any}("axes"=>axes,"organs"=>organs,
        "observation_schema"=>Dict("version"=>2,
            "legacy_cpp_bearer_field"=>"bearer_test_index_zero_based is the zero-based physical INTERNODE carrier rank in the historical C++ performance oracle",
            "physical_bearer_field"=>"bearer_physical_index_zero_based explicitly repeats that physical rank",
            "true_test_bearer_field"=>"bearer_axis_test_index_zero_based retains the original true test rank used by law contexts",
            "root_sentinel"=>-1),"development_time"=>plant.time,
        "last_event_time"=>plant.last_event_time,"counts"=>Dict("axes"=>length(axes),
        "realized"=>count(o->o.active,plant.organs),"tests"=>count(s->s.active,plant.sites),
        "geometry_organs"=>length(organs),"processed_events"=>plant.processed,"cancelled_events"=>plant.cancelled))
end

end
