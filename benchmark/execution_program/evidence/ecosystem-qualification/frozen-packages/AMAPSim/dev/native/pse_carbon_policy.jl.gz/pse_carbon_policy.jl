# Fixed, explicitly supplied organ construction costs. PSE prepares one typed
# frame per outer exchange; this module's bank is private to one native plant.
const _CARBON_RESERVE_CONTRACT = PSE.VariableContract(unit=:g_carbon,
    basis=:plant, temporal=:instantaneous, aggregation=:state, extent=:extensive)
const _CUMULATIVE_CARBON_CONTRACT = PSE.VariableContract(unit=:g_carbon,
    basis=:plant, temporal=:since_start, aggregation=:total, extent=:extensive)
const _CARBON_POLICY_CONTRACT = PSE.VariableContract(unit=:native_carbon_policy,
    basis=:plant, temporal=:step, aggregation=:state, extent=:extensive)

abstract type AbstractNativeCarbonPolicyModel <: PSE.AbstractModel end
PSE.process_(::Type{<:AbstractNativeCarbonPolicyModel}) = :native_carbon_policy

function _nonnegative_carbon(value, label)
    value isa Real && !(value isa Bool) || throw(ArgumentError("$label must be real"))
    isfinite(value) || throw(ArgumentError("$label must be finite"))
    value >= zero(value) || throw(DomainError(value, "$label cannot be negative"))
    return value
end

function _carbon_in_type(::Type{T}, value, label) where {T}
    _nonnegative_carbon(value, label)
    typed = try
        convert(T, value)
    catch exception
        throw(ArgumentError("$label cannot be represented as $T: " *
            sprint(showerror, exception)))
    end
    value > zero(value) && iszero(typed) && throw(ArgumentError(
        "$label is positive but underflows to zero in $T"))
    return _nonnegative_carbon(typed, "$label in $T")
end

"""
    FixedCarbonPolicy(; organs, initial_reserve_gC)

An illustrative fixed construction rule, prepared once per PSE outer step.
`organs` explicitly supplies `potential_dry_mass_g` and
`construction_cost_gC_per_gDM` for each native product symbol. Their product is
the full-organ demand in gC. It is not inferred from an FPA or organ geometry.
The allocation arithmetic uses the reserve's floating-point type.

Use `scenario(...; carbon_policy=policy)`. The PSE policy application reads
`cumulative_carbon_supply_gC` (gC since start, excluding the initial reserve).
The native architecture owns each plant's separate reserve and scalar totals.
Per-organ quote/commit callbacks perform no PSE calls and retain only waiting
quotes. Full historical demand and allocation tables are deliberately absent.
"""
struct FixedCarbonPolicy{T<:Real,O} <: AbstractNativeCarbonPolicyModel
    initial_reserve_gC::T
    organ_demands_gC::O
end

function FixedCarbonPolicy(; organs, initial_reserve_gC)
    reserve = float(_nonnegative_carbon(initial_reserve_gC, "initial_reserve_gC"))
    T = typeof(reserve)
    organs isa NamedTuple && !isempty(organs) || throw(ArgumentError(
        "organs must be a nonempty named tuple of explicit organ configurations"))
    demands = map(organs) do configuration
        configuration isa NamedTuple && length(configuration) == 2 &&
            haskey(configuration, :potential_dry_mass_g) &&
            haskey(configuration, :construction_cost_gC_per_gDM) || throw(ArgumentError(
                "each organ configuration must contain only potential_dry_mass_g " *
                "and construction_cost_gC_per_gDM"))
        mass = _nonnegative_carbon(configuration.potential_dry_mass_g, "potential_dry_mass_g")
        cost = _nonnegative_carbon(configuration.construction_cost_gC_per_gDM,
            "construction_cost_gC_per_gDM")
        mass, cost = promote(float(mass), float(cost))
        return _carbon_in_type(T, mass * cost, "organ demand_gC")
    end
    return FixedCarbonPolicy{T,typeof(demands)}(reserve, demands)
end

struct _CarbonPolicyFrame{T,O}
    initial_reserve_gC::T
    cumulative_carbon_supply_gC::T
    organ_demands_gC::O
end

function _carbon_policy_frame(model::FixedCarbonPolicy{T}, supply) where {T}
    typed = _carbon_in_type(T, supply, "cumulative_carbon_supply_gC")
    return _CarbonPolicyFrame(model.initial_reserve_gC, typed, model.organ_demands_gC)
end

PSE.environment_inputs_(model::FixedCarbonPolicy) = (
    cumulative_carbon_supply_gC=zero(model.initial_reserve_gC),)
PSE.outputs_(model::FixedCarbonPolicy) = (
    native_carbon_policy=_carbon_policy_frame(model, zero(model.initial_reserve_gC)),
    carbon_policy_revision=0,)
PSE.variable_contracts_(::FixedCarbonPolicy) = (
    cumulative_carbon_supply_gC=_CUMULATIVE_CARBON_CONTRACT,
    native_carbon_policy=_CARBON_POLICY_CONTRACT,)

function PSE.run!(model::FixedCarbonPolicy, status, environment, constants, context)
    frame = _carbon_policy_frame(model, environment.cumulative_carbon_supply_gC)
    status.native_carbon_policy = frame
    status.carbon_policy_revision += 1
    return nothing
end

struct _CachedOrganQuote{T}
    intent::NativeAMAP.NativeGrowthIntent
    demand_gC::T
    accepted::Bool
end

mutable struct _NativeCarbonBank{T,O}
    initial_reserve_gC::T
    organ_demands_gC::O
    credited_supply_gC::T
    budget_gC::T
    spent_gC::T
    allocated_count::Int
    deferred_count::Int
    quotes::Dict{Int64,_CachedOrganQuote{T}}
end

function _NativeCarbonBank(model::FixedCarbonPolicy{T}) where {T}
    return _NativeCarbonBank(model.initial_reserve_gC, model.organ_demands_gC,
        zero(T), model.initial_reserve_gC, zero(T), 0, 0,
        Dict{Int64,_CachedOrganQuote{T}}())
end

function _prepare_carbon_budget!(bank::_NativeCarbonBank{T,O}, frame::_CarbonPolicyFrame{T,O}) where {T,O}
    isequal(frame.initial_reserve_gC, bank.initial_reserve_gC) &&
        isequal(frame.organ_demands_gC, bank.organ_demands_gC) || throw(ArgumentError(
            "a fixed native carbon policy cannot change its reserve or organ costs"))
    supply = _carbon_in_type(T, frame.cumulative_carbon_supply_gC,
        "cumulative_carbon_supply_gC")
    supply >= bank.credited_supply_gC || throw(ArgumentError(
        "cumulative_carbon_supply_gC cannot decrease"))
    budget = _nonnegative_carbon(bank.initial_reserve_gC + supply, "total supplied carbon")
    bank.spent_gC <= budget || throw(ArgumentError("committed carbon exceeds supplied carbon"))
    # All validation precedes publication, including exchanges with no events.
    bank.credited_supply_gC = supply
    bank.budget_gC = budget
    return nothing
end

struct _CachedCarbonQuote{B}
    bank::B
end
struct _CachedCarbonSettlement{B}
    bank::B
end

function (quote_growth::_CachedCarbonQuote)(intent::NativeAMAP.NativeGrowthIntent)
    bank = quote_growth.bank
    previous = get(bank.quotes, intent.event_sequence, nothing)
    demand = if previous === nothing
        haskey(bank.organ_demands_gC, intent.organ_symbol) || throw(ArgumentError(
            "no mass and construction-cost configuration for organ $(repr(intent.organ_symbol))"))
        bank.organ_demands_gC[intent.organ_symbol]
    else
        isequal(previous.intent, intent) || throw(ArgumentError(
            "a cached carbon quote cannot change its native organ identity"))
        previous.demand_gC
    end
    next_spent = _nonnegative_carbon(bank.spent_gC + demand, "quoted carbon")
    accepted = next_spent <= bank.budget_gC
    bank.quotes[intent.event_sequence] = _CachedOrganQuote(intent, demand, accepted)
    accepted || (bank.deferred_count += 1)
    return accepted
end

function (settle_growth::_CachedCarbonSettlement)(intent::NativeAMAP.NativeGrowthIntent)
    bank = settle_growth.bank
    quoted = get(bank.quotes, intent.event_sequence, nothing)
    quoted !== nothing && isequal(quoted.intent, intent) && quoted.accepted ||
        throw(ArgumentError("cannot settle a native organ without its accepted carbon quote"))
    spent = _nonnegative_carbon(bank.spent_gC + quoted.demand_gC, "spent carbon")
    spent <= bank.budget_gC || throw(ArgumentError("settled carbon exceeds supplied carbon"))
    bank.spent_gC = spent
    bank.allocated_count += 1
    delete!(bank.quotes, intent.event_sequence)
    return nothing
end

function _new_carbon_control(model::FixedCarbonPolicy, product_symbols)
    bank = _NativeCarbonBank(model)
    return NativeAMAP.GrowthControl(before_growth=_CachedCarbonQuote(bank),
        after_growth=_CachedCarbonSettlement(bank), product_symbols=product_symbols)
end

function _discard_stale_carbon_quotes!(bank, control)
    NativeAMAP.pending_growth(control) # Invalidates pruned native preparations.
    for key in keys(bank.quotes)
        haskey(control.pending, key) || delete!(bank.quotes, key)
    end
    return nothing
end

function _publish_carbon_bank!(status, bank, control)
    _discard_stale_carbon_quotes!(bank, control)
    status.remaining_carbon_gC = bank.budget_gC - bank.spent_gC
    status.spent_carbon_gC = bank.spent_gC
    status.credited_carbon_supply_gC = bank.credited_supply_gC
    status.allocated_organ_count = bank.allocated_count
    status.deferred_growth_count = bank.deferred_count
    status.pending_growth_count = length(control.pending)
    return nothing
end
