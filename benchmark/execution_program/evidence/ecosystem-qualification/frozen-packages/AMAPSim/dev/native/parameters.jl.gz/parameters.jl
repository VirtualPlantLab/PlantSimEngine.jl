"""
Native scientific-law foundation for real Rauh and Merisier parameters.

This independent extension does not change the validated NativeAMAPCore engine.
It compiles every curve/surface into one concrete flat-table representation,
reuses existing pure scientific kernels, and provides node-free cycle state.
The sibling engine.jl implements retrospective scans, scheduling and pruning.
This module provides parameter tables and the pure apical planner; it does not
create graph nodes or own an event queue.
"""
module NativeAMAPScientificCore
import AMAPSim
using Random

"""Concrete ragged scalar/curve/surface storage, with no abstract child curves."""
struct NativeParameter
    dimension::UInt8
    outer_mode::UInt8
    ages::Vector{Float64}
    offsets::Vector{Int32}
    modes::Vector{UInt8}
    positions::Vector{Float64}
    ordinates::Vector{Float64}
end

function compile_parameter(p)
    if hasproperty(p,:value)
        return NativeParameter(0,0,Float64[],Int32[1,2],UInt8[0],Float64[0],Float64[p.value])
    elseif hasproperty(p,:curves)
        positions = Float64[]; ordinates = Float64[]; offsets = Int32[1]; modes = UInt8[]
        for curve in p.curves
            append!(positions,curve.positions); append!(ordinates,curve.values)
            push!(offsets,Int32(length(positions)+1)); push!(modes,UInt8(curve.interpolation))
        end
        return NativeParameter(2,UInt8(p.interpolation),copy(p.physiological_ages),
            offsets,modes,positions,ordinates)
    elseif hasproperty(p,:positions)
        return NativeParameter(1,0,Float64[],Int32[1,length(p.positions)+1],
            UInt8[UInt8(p.interpolation)],copy(p.positions),Float64.(p.values))
    end
    throw(ArgumentError("unsupported parameter record $(typeof(p))"))
end

@inline function first_ge(values::Vector{Float64},query::Float64,lo::Int,hi::Int)
    while lo < hi
        middle = (lo+hi) >>> 1
        if values[middle] < query
            lo = middle+1
        else
            hi = middle
        end
    end
    return lo
end

@inline function curve_value(p::NativeParameter,curve::Int,query::Float64)::Float64
    lo = Int(p.offsets[curve]); hi = Int(p.offsets[curve+1])-1
    positions = p.positions; ordinates = p.ordinates
    query <= positions[lo] && return ordinates[lo]
    query >= positions[hi] && return ordinates[hi]
    upper = first_ge(positions,query,lo,hi)
    query == positions[upper] && return ordinates[upper]
    lower = upper-1
    p.modes[curve] == 0 && return ordinates[lower]
    weight = (query-positions[lower])/(positions[upper]-positions[lower])
    # Both source modes 1 and 2 use linear interpolation after FPA parsing.
    return ordinates[lower]*(1.0-weight)+ordinates[upper]*weight
end

@inline function AMAPSim.valueat(p::NativeParameter,position::Real)::Float64
    p.dimension <= 1 || throw(ArgumentError("surface requires age and position"))
    return curve_value(p,1,Float64(position))
end

@inline function AMAPSim.valueat(p::NativeParameter,age::Real,position::Real)::Float64
    p.dimension == 2 || throw(ArgumentError("only a surface accepts age and position"))
    query = Float64(age); pos = Float64(position); ages = p.ages
    query <= first(ages) && return curve_value(p,1,pos)
    query >= last(ages) && return curve_value(p,length(ages),pos)
    upper = first_ge(ages,query,1,length(ages))
    query == ages[upper] && return curve_value(p,upper,pos)
    lower = upper-1
    p.outer_mode == 0 && return curve_value(p,lower,pos)
    y0 = curve_value(p,lower,pos); y1 = curve_value(p,upper,pos)
    weight = (query-ages[lower])/(ages[upper]-ages[lower])
    return y0+(y1-y0)*weight
end

function AMAPSim._next_surface_control_position(p::NativeParameter,age::Real,position::Real)
    p.dimension == 2 || throw(ArgumentError("control query requires a surface"))
    ages = p.ages; query = Float64(age)
    curve = if query <= first(ages)
        1
    elseif query >= last(ages)
        length(ages)
    else
        upper = first_ge(ages,query,1,length(ages))
        ages[upper] == query || p.outer_mode != 0 ? upper : upper-1
    end
    lo = Int(p.offsets[curve]); hi = Int(p.offsets[curve+1])-1
    lo == hi && return 9999.0
    for index in lo:hi
        p.positions[index] > position && return p.positions[index]
    end
    return 9999.0
end

function compile_group(group)
    fields = getfield(group,:values)
    return AMAPSim.ParameterGroup(NamedTuple{keys(fields)}(map(compile_parameter,values(fields))))
end
function compile_lateral(lp)
    zones = map(z -> AMAPSim.LateralProductionZone(z.index,compile_group(z.branching)),lp.zones)
    return AMAPSim.LateralProductionParameters(lp.name,compile_group(lp.global_parameters),
        lp.branching_models,zones;organ_symbol=lp.organ_symbol)
end

"""Compile all botanical/geometry groups; legacy/source provenance stays cold."""
function ensure_supported_initial_dormancy(parameters)
    growth = parameters.axis.growth
    for field in (:growth_unit_dormancy_probability,:growth_unit_dormancy_duration,
        :test_dormancy_trial_count,:test_dormancy_probability,:test_dormancy_lag)
        p = getproperty(growth,field)
        ordinates = hasproperty(p,:ordinates) ? p.ordinates :
            (hasproperty(p,:curves) ? reduce(vcat,[c.values for c in p.curves]) : p.values)
        all(iszero,ordinates) || throw(ArgumentError(
            "native production scheduler currently requires zero initial dormancy: $field"))
    end
    return nothing
end

function compile_parameters(parameters)
    ensure_supported_initial_dormancy(parameters)
    source_axis = parameters.axis
    axis = AMAPSim.AxisParameters(compile_group(source_axis.topology),
        compile_group(source_axis.differentiation),compile_group(source_axis.growth),
        compile_group(source_axis.geometry))
    first_lp = compile_lateral(first(parameters.lateral_productions))
    laterals = typeof(first_lp)[first_lp]
    for lp in Iterators.drop(parameters.lateral_productions,1)
        push!(laterals,compile_lateral(lp))
    end
    return AMAPSim.AMAPSimParameters(parameters.source,parameters.initialization,
        axis,laterals,parameters.legacy)
end
compile_parameters(fpa::AbstractString) = compile_parameters(AMAPSim.read_parameters(fpa))

"""Check flat tables against the original curves at control points and midpoints."""
function validate_tables(original)
    checked = 0; max_error = 0.0
    function check(a,b)
        error = abs(a-b)
        max_error = max(max_error,error)
        isapprox(a,b;atol=2e-12,rtol=2e-12) ||
            throw(ArgumentError("native table interpolation differs: $a versus $b"))
        checked += 1
    end
    function queries(values)
        points = sort!(unique!(Float64[values...]))
        middle = [(points[i]+points[i+1])/2 for i in 1:length(points)-1]
        return [first(points)-1;points;middle;last(points)+1]
    end
    for id in keys(original.legacy)
        p = original.legacy[id]; compiled = compile_parameter(p)
        if compiled.dimension == 0
            check(Float64(p.value),compiled.ordinates[1])
        elseif compiled.dimension == 1
            for x in queries(p.positions)
                check(AMAPSim.valueat(p,x),AMAPSim.valueat(compiled,x))
            end
        else
            # Retain ragged control grids. Every age/position corner and
            # interpolated midpoint is checked, including flat endpoint clamps.
            positions = reduce(vcat,[curve.positions for curve in p.curves])
            for age in queries(p.physiological_ages), position in queries(positions)
                check(AMAPSim.valueat(p,age,position),AMAPSim.valueat(compiled,age,position))
            end
        end
    end
    return (parameter_count=length(original.legacy),queries=checked,max_absolute_error=max_error)
end

"""Node-free progress within a preformed/neoformed growth cycle."""
mutable struct NativeCycleState
    initialization::AMAPSim.CycleInitialization
    tests::Int32
    realized::Int32
    neoformed_tests::Int32
    zone_started::Bool
    ended::Bool
end
function initialize_cycle(parameters,rng::AbstractRNG,age::Real,maximum_tests::Integer;
    cycle_index=1,completed_tests=0)
    cycle = AMAPSim.initialize_cycle(rng,parameters.axis.growth,age,cycle_index,maximum_tests;
        completed_test_count=completed_tests)
    return NativeCycleState(cycle,0,0,0,false,false)
end

struct NativeCycleStep
    created_test::Bool
    realized::Bool
    started_zone::Bool
    zone::UInt8
    zone_test_index::Int32
    ended::Bool
end

"""Exact pure realization/stop portion of _plan_apical_test!, before mortality."""
function next_cycle_test!(state::NativeCycleState,rng::AbstractRNG)
    state.ended && throw(ArgumentError("cycle already ended"))
    c = state.initialization
    in_neoformed = c.has_neoformed_zone &&
        (state.zone_started || state.tests >= c.preformed_internode_count)
    if in_neoformed
        result = AMAPSim.sample_neoformed_test(rng,c;zone_started=state.zone_started,
            completed_test_count=state.neoformed_tests)
        state.zone_started |= result.started_zone
        state.ended = result.ended_cycle
        if result.created_test_site
            state.tests += 1
            state.neoformed_tests = Int32(result.test_index)
        end
        result.realized_internode && (state.realized += 1)
        return NativeCycleStep(result.created_test_site,result.realized_internode,
            result.started_zone,2,Int32(result.test_index),state.ended)
    end
    state.tests += 1
    realized = state.tests <= c.preformed_internode_count
    realized && (state.realized += 1)
    state.ended = !c.has_neoformed_zone &&
        (c.preformed_internode_count == 0 || state.tests >= c.preformed_internode_count)
    return NativeCycleStep(true,realized,false,1,state.tests,state.ended)
end

"""Replay a native cycle into primitive records without creating topology nodes."""
function cycle_trace(parameters,rng::AbstractRNG,age::Real;
    cycle_index=1,maximum_tests=AMAPSim.growth_unit_timing(parameters,age).test_count)
    state = initialize_cycle(parameters,rng,age,maximum_tests;cycle_index)
    steps = NativeCycleStep[]
    while !state.ended && state.tests < maximum_tests
        push!(steps,next_cycle_test!(state,rng))
    end
    return (initialization=state.initialization,steps=steps,
        tests=Int(state.tests),realized=Int(state.realized),ended=state.ended)
end

"""Seed the exact constructor's scientific vigor state, with no bud/MTG node."""
function initial_vigor(parameters,rng::AbstractRNG,physiological_age::Real)
    state = AMAPSim.initial_vigor_state(rng,parameters.axis.differentiation,physiological_age)
    state = AMAPSim.advance_vigor(rng,parameters.axis.differentiation,state)
    return AMAPSim.VigorState(state.reference_age,state.next_reference_age,
        state.remaining_growth_units-1)
end

"""Lean per-bud scientific state; sentinel GU ID is a phase flag, never an MTG ID."""
mutable struct NativeApicalState
    vigor::AMAPSim.VigorState
    rhythm::Float64
    previous_polycyclic::Union{Nothing,Bool}
    growth_unit_index::Int
    maximum_growth_unit_count::Int
    maximum_reference_age::Float64
    ended::Bool
    growth_unit_test_count::Int
    time_per_test::Float64
    planned_cycle_count::Int
    cycle_index::Int
    test_index_within_growth_unit::Int
    test_index_within_cycle::Int
    test_count_on_axis::Int
    internode_count_within_growth_unit::Int
    internode_count_within_cycle::Int
    internode_count_on_axis::Int
    phytomer_count_within_zone::Int
    neoformed_zone_started::Bool
    neoformed_test_count::Int
    growth_unit_node_id::UInt64
    cycle::Union{Nothing,AMAPSim.CycleInitialization}
    first_dispatch_time::Float64
    next_time::Float64
end

"""Source lifecycle bound; table lookup itself retains its original precision."""
maximum_reference_age(parameter,reference_age) = AMAPSim.valueat(parameter,reference_age)
maximum_reference_age(parameter::NativeParameter,reference_age) =
    Float64(min(9999,trunc(Int,AMAPSim.valueat(parameter,reference_age))))

function initialize_apical(parameters,rng::AbstractRNG,age::Real=1.0;rhythm=1.0,birth=0.0)
    vigor = initial_vigor(parameters,rng,age)
    timing = AMAPSim.growth_unit_timing(parameters,vigor.reference_age;rhythm)
    max_gu = trunc(Int,AMAPSim.valueat(parameters.axis.topology.maximum_growth_unit_count,vigor.reference_age))
    max_age = maximum_reference_age(parameters.axis.topology.maximum_axis_physiological_age,vigor.reference_age)
    return NativeApicalState(vigor,Float64(rhythm),nothing,0,max_gu,max_age,false,
        timing.test_count,Float64(timing.time_per_test),0,0,0,0,0,0,0,0,0,false,0,0,
        nothing,0.0,Float64(birth+timing.time_per_test))
end

"""
One complete pure apical test, including failed tests, cycle tails, mortality,
vigor and timing. The returned plan is ready for native arena births/branching;
this function intentionally does not create or register botanical objects.
"""
function apical_plan!(state::NativeApicalState,parameters,rng::AbstractRNG,time::Real)
    state.ended && throw(ArgumentError("apical program already ended"))
    iszero(state.growth_unit_node_id) && (state.first_dispatch_time=Float64(time))
    return AMAPSim._plan_apical_test!(state,rng,parameters,Float64(time),0,0,0.0,
        false,nothing,nothing,nothing,state.first_dispatch_time)
end

"""End a first immediate GU at its bearer clock without changing nominal cycle laws.

If the ordinary planner already ended the GU, only its next-time anchor changes.
Otherwise the exact source vigor/timing/termination transition runs once, before
lateral branching consumes its post-growth scientific state.
"""
function force_growth_unit_end!(state::NativeApicalState,parameters,rng::AbstractRNG,plan;
    end_time::Real=plan.theoretical_growth_unit_end_time)
    clipped_end = Float64(end_time)
    isfinite(clipped_end) || throw(ArgumentError("clipped GU end must be finite"))
    axis_ended = plan.axis_ended
    if !plan.growth_unit_ended
        state.vigor = AMAPSim.advance_vigor(rng,parameters,state.vigor)
        axis_ended = state.growth_unit_index >= state.maximum_growth_unit_count ||
            state.vigor.reference_age >= state.maximum_reference_age
        state.ended = plan.bud_died || axis_ended
        if state.vigor.reference_age < state.maximum_reference_age
            timing = AMAPSim.growth_unit_timing(parameters,state.vigor.reference_age;rhythm=state.rhythm)
            state.growth_unit_test_count = timing.test_count
            state.time_per_test = Float64(timing.time_per_test)
        end
    end
    duration = state.ended ? AMAPSim.growth_unit_timing(parameters,state.vigor.reference_age;
        rhythm=state.rhythm).duration : nothing
    next_time = state.ended ? nothing : clipped_end+state.time_per_test
    return merge(plan,(growth_unit_ended=true,axis_ended=axis_ended,
        theoretical_growth_unit_end_time=clipped_end,
        theoretical_growth_unit_duration=duration,next_time=next_time))
end

"""Finish phase counters AFTER native LP-ordered branching has read the plan."""
function finish_apical!(state::NativeApicalState,plan)
    if plan.growth_unit_ended
        state.growth_unit_node_id = 0
        state.planned_cycle_count = 0
        state.cycle_index = 0
        state.test_index_within_growth_unit = 0
        state.test_index_within_cycle = 0
        state.cycle = nothing
    elseif plan.cycle_ended
        state.growth_unit_node_id = 1
        state.test_index_within_cycle = 0
        state.cycle = nothing
    else
        state.growth_unit_node_id = 1
    end
    state.next_time = plan.next_time === nothing ? Inf : plan.next_time
    return state
end

function apical_test!(state::NativeApicalState,parameters,rng::AbstractRNG,time::Real)
    plan = apical_plan!(state,parameters,rng,time)
    finish_apical!(state,plan)
    return plan
end

"""
Isolated apical-program trace for law validation; this is explicitly NOT a full
plant simulation because lateral births, retrospective scans and pruning are
integrated by the future native scheduler, not omitted from a plant claim.
"""
function apical_trace(parameters,rng::AbstractRNG,age::Real=1.0;
    horizon=2.0,rhythm=1.0,birth=0.0,max_events=100000)
    state = initialize_apical(parameters,rng,age;rhythm,birth)
    events = NamedTuple[]
    while !state.ended && state.next_time <= horizon+1e-6
        length(events) < max_events || error("isolated apical trace exceeded event bound")
        time = state.next_time
        plan = apical_test!(state,parameters,rng,time)
        push!(events,(time=time,reference_age=plan.reference_age,
            gu=state.growth_unit_index,realized=plan.realized,
            creates_test=plan.creates_test_site,cycle_ended=plan.cycle_ended,
            growth_unit_ended=plan.growth_unit_ended,axis_ended=plan.axis_ended,
            cycle_tail_tests=plan.cycle_tail_test_count,
            test_count=state.test_count_on_axis,realized_count=state.internode_count_on_axis,
            next_time=state.next_time))
    end
    return (events=events,tests=state.test_count_on_axis,
        realized=state.internode_count_on_axis,vigor=state.vigor,
        next_time=state.next_time,ended=state.ended)
end
end
