# Original FPA inputs and independent native references

`mod_Rauh.fpa` and `merisier.fpa` are byte-exact copies of the historical
AMAPsim species files, not the modified Merisier mechanism fixture. Their source
locations in the parent AMAPSim checkout are
`amapsim/AmapSimEnv/bdd/ParameterFiles.archi/mod_Rauh.fpa` and
`amapsim/AmapSimEnv/bdd/ParameterFiles.Plant/merisier.fpa`.

`reference.toml` contains the independent C++ seed-1, stage-2 observations:
complete architecture digests and every surviving organ's dimensions, base,
tip and three raw placement vectors. Expected geometry is exported directly
from C++; it is not generated from the Julia implementation. The input and raw
C++ snapshot hashes are embedded in each case. The existing absolute/relative
bound is retained in native model units, without alignment or fitting.

Architecture digests encode the rooted LP/physical-carrier/whorl-slot path,
nature, LP, whorl slot and size, GU/product/test counts, physiological age and
birth time, with explicit little-endian integers and IEEE Float64 values.
The historical C++ wire key `bearer_test_index_zero_based` actually denotes a
physical internode rank; native observations expose both physical and true test
ranks so this distinction is explicit.

These are numerical regression references, not biological calibration. Light,
carbon allocation, triangle meshes and rendering are outside this core gate.

`age_boundary.toml` adds two independent architectural regressions. Original
Merisier at stage 7 catches the first observed fractional-age-limit divergence.
The authored `fractional-maximum-age-v2.fpa` isolates a maximum of 3.5: C++ casts
it to a native integer and ends after three GUs (48 organs). Retaining the
fraction incorrectly produces four GUs (64 organs). These age-limit checks
exclude geometry so their cause stays explicit.
