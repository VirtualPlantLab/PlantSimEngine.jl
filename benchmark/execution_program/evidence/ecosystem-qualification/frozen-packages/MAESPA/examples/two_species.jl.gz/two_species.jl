# A small, native Julia scenario: two artificial species, one tree per species,
# one soil layer and two repeated light/temperature cycles. The second morning
# receives 3 mm of rain. These values are for integration testing and teaching;
# they are not a calibrated site or an independent scientific reference.
#
# Run from the MAESPA project with:
#   include("examples/two_species.jl")
#   model = two_species_model()
#   simulation = PlantSimEngine.run!(model; steps=96, outputs=:none)
#
# No namelist files, Fortran source, or test fixtures are read. Current MAESPA
# configuration types retain the historical "Legacy" names; they also accept
# ordinary Julia arrays and structs, as demonstrated below.

using MAESPA
using PlantSimEngine

"""Build the complete small scenario using Float64 parameters by default."""
function two_species_model(; T=Float64, type_promotion=nothing)
    input = two_species_parameters(T)
    return build_model(
        input.config,
        input.scene;
        species_set=input.species,
        meteorology=input.meteorology,
        soil=input.soil,
        mount_leaf_exchange=true,
        type_promotion,
    )
end

"""Native Julia parameters shared by the executable example and regression."""
function two_species_parameters(::Type{T}=Float64) where {T<:AbstractFloat}
    dates = legacy_date.(["01/01/10", "02/01/10"])
    site = SolarGeometryConfig(zero(T), zero(T), zero(T), 48)
    config = SimulationConfig{T}(
        first(dates), last(dates), 48,
        2, ["HighCapacity", "LowCapacity"],
        ["native", "native"], ["native", "native"],
        AllTargetTrees(), 2, zero(T), 1,
        2, 0, 0, 0, 0, 2, 0, 1, 1, 4, 1, 1,
        site, nothing, nothing, false,
    )

    # Equal tree geometry isolates the effect of photosynthetic capacity.
    plot = LegacyPlotConfig{T}(
        (zero(T), zero(T)), (T(10), T(10)), (zero(T), zero(T)),
        zero(T), zero(T), 0, 2, T(100), T(0.02),
        T(10), T(0.3), T(2),
    )
    trees = [
        LegacyTreeRecord{T}(1, 1, 1, (T(3), T(5), zero(T))),
        LegacyTreeRecord{T}(2, 2, 2, (T(7), T(5), zero(T))),
    ]
    trajectory(value) = TreeDimensionTable([first(dates)], fill(T(value), 1, 2))
    dimensions = LegacyTreeTrajectories(
        trajectory(1), trajectory(1), trajectory(2), trajectory(1),
        trajectory(4), nothing,
    )
    scene = LegacyTreeScene(plot, trees, dimensions)
    species = SpeciesSet(
        [
            two_species_physiology(T, 1, "HighCapacity", 140, first(dates)),
            two_species_physiology(T, 2, "LowCapacity", 80, first(dates)),
        ],
    )
    return (
        config, scene, species,
        meteorology=two_species_weather(T, dates),
        soil=two_species_soil(T, first(dates)),
    )
end

function two_species_physiology(::Type{T}, id, name, jmax, date) where {T}
    dates = [date]
    one_angle = LeafAngleDistribution(
        :native, T[π / 4], dates, ones(T, 1, 1), T[π / 4], one(T),
    )
    no_allometry = AllometricEquation(zero(T), zero(T), zero(T))
    structure = SpeciesStructureConfig(
        "native", CrownShape(:cylinder, "CYL", 5, one(T)),
        CanopyAerodynamics(T(2)), one_angle,
        LeafAreaDensity(:uniform, 0, 1, one(T), dates, zeros(T, 8, 1, 1)),
        SpeciesAllometry(no_allometry, no_allometry, no_allometry, zero(T)), 1,
    )

    optics = LeafOptics(
        T[0.1 0.3 0.05], T[0.05 0.2 0.01], T[0.85 0.5 0.94],
        (T(0.1), T(0.2), T(0.05)),
    )
    stomata = BallBerryStomatalParameters(
        dates, T(0.001), T(0.002), T[0.01], T[2], T[0], T[0],
        T(0.5), T(400), dates, T[0.02], 1, :co2, false,
        zero(T), zero(T), zero(T), one(T), zero(T),
    )
    leaf_respiration = LeafRespirationParameters(
        dates, T[0.07], zero(T), T(25), T(-100), one(T), T(0.4),
    )
    woody_respiration = WoodyRespirationParameters(
        0, zero(T), zero(T), zero(T), T(25), dates, T[0.07],
        one(T), zero(T), zero(T), zero(T),
    )
    root_respiration = RootRespirationParameters(zero(T), zero(T), T(0.07), T(25))
    branch_respiration = BranchRespirationParameters(zero(T), T(0.07), T(25))
    capacity = PhotosyntheticCapacityParameters(
        0, T(43790), T(200000), T(644.4338), T(60790), T(200000), T(636),
        T(0), T(-5), T(0.7), 0, zero(T), zero(T), zero(T),
    )
    table(value) = SpeciesParameterTable(dates, fill(T(value), 1, 1, 1))
    physiology = SpeciesPhysiologyConfig(
        "native", 1, FoliageAgeClasses(1, 1, T[1], T[1]), optics, stomata,
        leaf_respiration, woody_respiration, root_respiration, branch_respiration,
        capacity, table(jmax), table(jmax / 2), table(1), table(10), table(0.4),
    )
    return SpeciesConfig(id, name, structure, physiology)
end

function two_species_weather(::Type{T}, dates) where {T}
    column_names = ["DATE", "TIME", "RAD", "TAIR", "RH", "PRESS", "WIND", "PPT"]
    variables = [
        :declared_day, :declared_step, :global_radiation, :air_temperature,
        :relative_humidity, :air_pressure, :wind_speed, :precipitation,
    ]
    columns = [MeteorologyColumn(i, name, variables[i]) for (i, name) in enumerate(column_names)]
    metadata = MeteorologyConfig{T}(
        "native", "Two artificial days with rain on the second morning", 0,
        1, SubdailyMeteorology, 48, T(1800), 8, 8, columns,
        Dict(variable => i for (i, variable) in enumerate(variables)),
        first(dates), last(dates), T(400), T(101325), zero(T), zero(T), one(T),
        MeteorologyDiagnostic[], nothing,
    )
    values = Matrix{T}(undef, 96, 8)
    for day in 1:2, step in 1:48
        hour = (step - 0.5) / 2
        daylight = max(0, sinpi((hour - 6) / 12))
        rain = day == 2 && step == 13 ? T(3) : zero(T)
        values[(day - 1) * 48 + step, :] .= (
            day, step, 600 * daylight, 20 + 8 * daylight,
            0.7 - 0.2 * daylight, 101325, 2, rain,
        )
    end
    return LegacyMeteorology(
        metadata, values,
        repeat(getfield.(dates, :days_since_1950); inner=48),
        repeat(collect(1:48), 2), repeat([1, 2]; inner=48),
        repeat(collect(1:48), 2), zeros(Int, 96), MeteorologyDiagnostic[],
    )
end

function two_species_soil(::Type{T}, date) where {T}
    dates = [date]
    options = WaterBalanceOptions(0, 0, 0, 0, 1, 3, 0, 0, 0, 1, 2, 0, 0, 0)
    layers = SoilLayerConfig(
        1, T[0.2], T(0.1), T[0.4], T[0.1], T[0], nothing, zero(T),
    )
    retention = SoilRetentionConfig{T}(
        3, nothing, nothing, T[8.85e-7], T[100], T[0.4], T[0.05], T[1.5],
    )
    roots = RootParametersConfig(
        dates, 1, 1, 2, T(0.4), T[0.001], T[20], T[100],
        ones(T, 1, 1, 2), T(0.97), :root_srl,
        [0], T[0], T[0], T[0], false,
    )
    hydraulics = PlantHydraulicConfig(dates, T(-1.5), T[-2, -2], T[2], zero(T))
    return SoilConfig{T}(
        "native", options, layers, retention, InitialSoilState(T[0.2], T[20]),
        SoilEvaporationConfig(T(0.01), T(0.5), T(0.25)),
        SoilInfiltrationConfig(one(T)), nothing, roots, hydraulics, nothing,
    )
end
