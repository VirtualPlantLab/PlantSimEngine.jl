# Materialize accepted public histories, not final statuses reconstructed as time series.
function retained_history(simulation, requests)
    history = Dict{Tuple{Symbol,Any,Int},Any}()
    for request in requests
        for row in collect_outputs(simulation, request.name; sink=nothing)
            key = (request.name, row.object_id, Int(row.timestep))
            haskey(history, key) && error("Duplicate retained sample $key")
            row.application_id === request.application || error("Retained publisher changed")
            history[key] = deepcopy(row)
        end
    end
    return history
end

value(history, id, variable, step) = history[(stream_key(id, variable), id, step)].value

function write_history(path, history)
    rows = [(request_name=key[1], object_id=row.object_id, application_id=row.application_id,
        timestep=row.timestep, datetime=row.datetime, value_type=string(typeof(row.value)),
        value_julia_repr=repr(row.value)) for (key, row) in sort(collect(history);
            by=pair -> (pair.first[3], string(pair.first[1]), string(pair.first[2])))]
    write_table(path, keys(first(rows)), rows)
end

function tables_from_history(history, input, implementation)
    n = maximum(key[3] for key in keys(history))
    v(id, variable, step) = value(history, id, variable, step)
    tree_rows, scene_rows, water_rows, diagnostics, points, hydric = (NamedTuple[] for _ in 1:6)
    previous_soil = previous_canopy = nothing
    for step in 1:n
        source_step = v(:scene, :simulation_step, step)
        day = v(:scene, :simulation_day, step) + 1
        slot = v(:scene, :step_index, step)
        hour = 24 * (day - 1) + (slot - .5) / 2
        energy_available = v(:soil, :soil_surface_energy_available, step) &&
            v(:soil, :soil_surface_energy_components_evaluated, step)
        water_available = all(v(id, gate, step) for (id, gate) in (
            (:soil, :soil_water_balance_available), (:scene, :canopy_water_storage_available),
            (:scene, :stand_water_flux_scaling_available), (:soil, :soil_surface_evaporation_available),
            (:soil, :soil_water_flux_partition_available)))
        atmosphere_available = v(:scene, :canopy_air_microclimate_available, step)
        soil_pre = 1000 * v(:soil, :soil_storage_before_m, step)
        soil_post = 1000 * v(:soil, :soil_storage_after_m, step)
        canopy_post = v(:scene, :canopy_water_storage_mm, step)
        canopy_correction = v(:scene, :canopy_water_storage_correction_mm, step)
        canopy_pre = canopy_post - v(:scene, :canopy_water_storage_change_mm, step) - canopy_correction
        precipitation = v(:scene, :precipitation_mm, step)
        throughfall = v(:scene, :surface_water_mm, step)
        transpiration = v(:scene, :canopy_transpiration_mm_timestep, step)
        soil_evaporation = v(:soil, :soil_evaporation_mm_timestep, step)
        wet_evaporation = v(:scene, :wet_canopy_evaporation_mm_timestep, step)
        actual_canopy_evaporation = v(:scene, :canopy_evaporation_mm, step)
        et = transpiration + soil_evaporation + wet_evaporation
        drainage = 1000 * v(:soil, :soil_total_boundary_outflow_m, step)
        runoff = 1000 * v(:soil, :soil_surface_overflow_m, step)
        corrections = 1000 * sum(v(:soil, variable, step) for variable in (
            :soil_lower_bound_correction_m, :soil_water_table_exchange_m, :soil_imposed_stock_exchange_m))
        # Independent reconstruction from stocks and separately published fluxes.
        # These raw physical residuals deliberately do not hide imposed/corrective exchanges.
        soil_residual = soil_post - soil_pre - throughfall + transpiration + soil_evaporation + drainage + runoff
        total_residual = soil_post + canopy_post - soil_pre - canopy_pre - precipitation + et + drainage + runoff
        native_soil_residual = 1000 * v(:soil, :soil_water_mass_balance_residual_m, step)
        native_canopy_residual = v(:scene, :canopy_water_mass_balance_residual_mm, step)
        soil_energy_residual = energy_available ? v(:soil, :soil_net_radiation_w_m2, step) -
            v(:soil, :soil_sensible_heat_flux_w_m2, step) -
            v(:soil, :soil_latent_heat_flux_w_m2, step) - v(:soil, :soil_heat_flux_w_m2, step) : NaN
        lambda = v(:scene, :canopy_latent_heat_vaporization_j_mol, step)
        for tree in input.tree_scene.trees
            crown = Symbol("crown_", tree.id)
            available = v(crown, :crown_leaf_exchange_aggregation_available, step) &&
                v(crown, :crown_thermal_radiation_aggregation_available, step)
            safe(x) = available ? x : NaN
            dry = v(crown, :dry_transpiration_crown_umol_h2o_s, step)
            wet = v(crown, :wet_evaporation_crown_umol_h2o_s, step)
            push!(tree_rows, (implementation, step, day, hour, tree_id=tree.id, species_id=tree.species_id,
                A_umol_s=safe(v(crown, :net_assimilation_crown_umol_co2_s, step)), E_mmol_s=safe(dry / 1000),
                H_W=safe(v(crown, :sensible_heat_crown_w, step)),
                Tleaf_C=safe(v(crown, :mean_leaf_temperature_crown_c, step)),
                Rn_W=safe(sum(v(crown, variable, step) for variable in
                    (:absorbed_par_crown_w, :absorbed_nir_crown_w, :absorbed_thermal_crown_w))),
                LE_W=safe((dry + wet) * 1e-6 * lambda)))
            layout_available = v(crown, :logical_leaf_unit_layout_available, step)
            controller_available = v(crown, :non_tuzet_crown_leaf_exchange_controller_available, step)
            snapshot_available = v(crown, :crown_leaf_thermal_snapshot_available, step)
            active = v(crown, :logical_leaf_unit_active, step)
            area = v(crown, :logical_leaf_area_m2, step)
            point_index = v(crown, :logical_leaf_point_index, step)
            assimilation = v(crown, :non_tuzet_accepted_logical_leaf_net_assimilation_umol_co2_m2_s, step)
            evaporation = v(crown, :non_tuzet_accepted_logical_leaf_actual_transpiration_umol_h2o_m2_s, step)
            temperatures = v(crown, :point_leaf_temperature_c, step)
            x, y, z = (v(crown, Symbol("representative_", axis), step) for axis in (:x, :y, :z))
            for p in eachindex(x)
                units = [i for i in eachindex(area) if active[i] && point_index[i] == p]
                weight = sum(area[i] for i in units; init=0.0)
                point_available = layout_available && controller_available && snapshot_available && weight > 0
                push!(points, (implementation, step, day, hour, tree_id=tree.id, species_id=tree.species_id,
                    point_id=p, x=x[p], y=y[p], z=z[p],
                    A_umol_m2_s=point_available ? sum(assimilation[i] * area[i] for i in units) / weight : NaN,
                    E_umol_m2_s=point_available ? sum(evaporation[i] * area[i] for i in units) / weight : NaN,
                    Tleaf_C=point_available ? temperatures[p] : NaN, leaf_area_m2=weight,
                    active=weight > 0, available=point_available))
            end
            root = Symbol("root_system_", tree.id)
            root_available = v(root, :root_water_uptake_available, step) &&
                v(root, :soil_to_leaf_hydraulic_supply_available, step)
            psi_available = v(:soil, :soil_pre_water_potential_available, step)
            limited = v(crown, :non_tuzet_logical_leaf_hydraulic_limitation_applied, step)
            total_area = sum(area[i] for i in eachindex(area) if active[i]; init=0.0)
            limited_area = sum(area[i] for i in eachindex(area) if active[i] && limited[i]; init=0.0)
            push!(hydric, (implementation, step, day, hour, tree_id=tree.id, species_id=tree.species_id,
                theta_post_m3_m3=only(v(:soil, :soil_water_contents, step)),
                psi_pre_MPa=psi_available ? only(v(:soil, :soil_water_potentials_before_water_balance_mpa, step)) : NaN,
                psi_pre_available=psi_available, root_available,
                root_weighted_psi_MPa=v(root, :weighted_soil_water_potential_mpa, step),
                soil_evaporation_mm_step=soil_evaporation,
                Emax_mmol_m2_leaf_s=v(root, :maximum_leaf_transpiration_mmol_m2_leaf_s, step),
                limited_leaf_area_fraction=total_area > 0 ? limited_area / total_area : NaN))
        end
        safe_scene(x) = atmosphere_available ? x : NaN
        push!(scene_rows, (implementation, step, day, hour,
            Rn_W_m2=safe_scene(v(:scene, :canopy_total_net_radiation_w_m2, step)),
            H_W_m2=safe_scene(v(:scene, :canopy_total_sensible_heat_flux_w_m2, step)),
            LE_W_m2=safe_scene(v(:scene, :canopy_total_latent_heat_flux_w_m2, step)),
            G_W_m2=energy_available ? v(:soil, :soil_heat_flux_w_m2, step) : NaN,
            ET_mm_step=water_available ? et : NaN, soil_energy_residual_W_m2=soil_energy_residual))
        safe_water(x) = water_available ? x : NaN
        push!(water_rows, (implementation, step, day, hour,
            soil_storage_pre_mm=safe_water(soil_pre), soil_storage_post_mm=safe_water(soil_post),
            canopy_storage_pre_mm=safe_water(canopy_pre), canopy_storage_post_mm=safe_water(canopy_post),
            P_mm_step=precipitation, throughfall_mm_step=safe_water(throughfall),
            canopy_T_mm_step=safe_water(transpiration), soil_E_mm_step=safe_water(soil_evaporation),
            wet_E_mm_step=safe_water(wet_evaporation), ET_mm_step=safe_water(et),
            drainage_mm_step=safe_water(drainage), runoff_mm_step=safe_water(runoff),
            soil_water_residual_mm_step=safe_water(soil_residual),
            total_water_residual_mm_step=safe_water(total_residual),
            native_soil_water_residual_mm_step=safe_water(native_soil_residual)))
        root_withdrawal = 1000 * sum(v(:soil, :root_water_uptake_m, step))
        allocated_soil_evaporation = 1000 * (sum(v(:soil, :soil_evaporation_m, step)) - sum(v(:soil, :soil_dew_m, step)))
        push!(diagnostics, (implementation, step, day, hour, source_step,
            date50=v(:scene, :date50, step), step_index=slot, water_available, atmosphere_available, energy_available,
            soil_state_gap_mm=isnothing(previous_soil) ? NaN : soil_pre - previous_soil,
            canopy_state_gap_mm=isnothing(previous_canopy) ? NaN : canopy_pre - previous_canopy,
            soil_external_net_mm_step=1000 * v(:soil, :soil_external_net_flux_m, step),
            soil_lower_bound_correction_mm_step=1000 * v(:soil, :soil_lower_bound_correction_m, step),
            soil_water_table_exchange_mm_step=1000 * v(:soil, :soil_water_table_exchange_m, step),
            soil_imposed_stock_exchange_mm_step=1000 * v(:soil, :soil_imposed_stock_exchange_m, step),
            canopy_correction_mm_step=canopy_correction,
            soil_water_residual_corrected_mm_step=soil_residual - corrections,
            total_water_residual_corrected_mm_step=total_residual - corrections - canopy_correction,
            native_canopy_residual_mm_step=native_canopy_residual,
            native_infiltration_residual_mm_step=1000 * v(:soil, :soil_infiltration_mass_balance_residual_m, step),
            root_withdrawal_minus_canopy_T_mm_step=root_withdrawal - transpiration,
            allocated_soil_E_minus_surface_E_mm_step=allocated_soil_evaporation - soil_evaporation,
            stand_wet_E_minus_canopy_evaporation_mm_step=wet_evaporation - actual_canopy_evaporation,
            canopy_evaporation_residual_mm_step=v(:scene, :canopy_evaporation_residual_mm, step),
            native_soil_energy_residual_W_m2=v(:soil, :soil_energy_balance_residual_w_m2, step),
            soil_energy_residual_reconstruction_error_W_m2=soil_energy_residual - v(:soil, :soil_energy_balance_residual_w_m2, step),
            soil_energy_converged=v(:soil, :soil_surface_energy_converged, step),
            soil_energy_at_lower_bound=v(:soil, :soil_surface_energy_solution_at_lower_bound, step),
            soil_energy_at_upper_bound=v(:soil, :soil_surface_energy_solution_at_upper_bound, step)))
        previous_soil, previous_canopy = soil_post, canopy_post
    end
    return (; tree=tree_rows, scene=scene_rows, water=water_rows, diagnostics, points, hydric)
end


