module MAESPAEvaluationPlots

using MAESPA
using Makie

export evaluation_figures, save_evaluation_figures

const IMPLEMENTATIONS = ("Julia-continuous", "Julia-resumed", "Fortran")
const COLORS = Dict("Julia-continuous" => :seagreen4,
    "Julia-resumed" => :darkorange2, "Fortran" => :purple3)
const STYLES = Dict("Julia-continuous" => :solid,
    "Julia-resumed" => :dash, "Fortran" => :dot)
const CONTRASTS = ("equal-physiology", "low-radiation", "dry-air", "dry-soil")

# These helpers arrange already acquired output. They do not run models,
# interpolate histories, replace missing values, or change reference results.
function selected(rows, implementation; tree_id=nothing)
    result = filter(rows) do row
        row.implementation == implementation &&
            (isnothing(tree_id) || row.tree_id == tree_id)
    end
    return sort(result; by=row -> row.step)
end

function axis_at(position; hours=24, title="", ylabel="")
    axis = Axis(position; title, xlabel="Elapsed hour", ylabel,
        xticks=0:6:hours, ylabelsize=13)
    xlims!(axis, 0, hours)
    for boundary in 24:24:(hours - 1)
        vlines!(axis, [boundary]; color=:gray65, linestyle=:dash, linewidth=1)
    end
    return axis
end

function no_data!(axis, message="Not independently reported")
    text!(axis, 0.5, 0.5; text=message, space=:relative, align=(:center, :center),
        color=:gray45, fontsize=12)
    return nothing
end

function implementations(rows)
    return [name for name in IMPLEMENTATIONS if any(row -> row.implementation == name, rows)]
end

function legend_at(position, names)
    Legend(position,
        [LineElement(color=COLORS[name], linestyle=STYLES[name], linewidth=2.4) for name in names],
        collect(names); orientation=:horizontal, framevisible=false)
end

function draw!(axis, rows, variable; tree_id=nothing, cumulative=false,
        factor=1.0, color=nothing)
    drawn = false
    for name in implementations(rows)
        current = selected(rows, name; tree_id)
        isempty(current) && continue
        x = [row.hour for row in current]
        y = [getproperty(row, variable) for row in current]
        if cumulative
            # A missing intermediate step is not a valid cumulative trajectory.
            all(diff([row.step for row in current]) .== 1) ||
                error("Noncontiguous acquired steps in cumulative $variable")
            y = cumsum(y) .* factor
        else
            y = y .* factor
        end
        any(isfinite, y) || continue
        lines!(axis, x, y; color=isnothing(color) ? COLORS[name] : color,
            linestyle=STYLES[name], linewidth=2.2)
        drawn = true
    end
    drawn || no_data!(axis)
    return axis
end

function tree_figure(case; title="Two-day tree trajectories", hours=48)
    ids = sort(unique(row.tree_id for row in case.tree))
    fig = Figure(size=(max(1050, 510 * length(ids)), 820), fontsize=14)
    Label(fig[0, 1:length(ids)], title; fontsize=21, font=:bold)
    variables = ((:A_umol_s, "A (µmol CO₂ tree⁻¹ s⁻¹)"),
        (:E_mmol_s, "E (mmol H₂O tree⁻¹ s⁻¹)"), (:Tleaf_C, "Tleaf (°C)"))
    for (row, (variable, ylabel)) in enumerate(variables)
        axes = Axis[]
        for (column, id) in enumerate(ids)
            species = unique(item.species_id for item in case.tree if item.tree_id == id)
            length(species) == 1 || error("Tree $id has no stable species identity")
            axis = axis_at(fig[row, column]; hours,
                ylabel=column == 1 ? ylabel : "",
                title=row == 1 ? "Tree $id · species $(only(species))" : "")
            push!(axes, axis)
            draw!(axis, case.tree, variable; tree_id=id)
        end
        length(axes) > 1 && linkyaxes!(axes...)
    end
    legend_at(fig[4, 1:length(ids)], implementations(case.tree))
    return fig
end

function scene_energy(case; step_seconds=1800)
    fig = Figure(size=(1500, 740), fontsize=14)
    Label(fig[0, 1:4], "Scene energy · fluxes and signed timestep integrals"; fontsize=21, font=:bold)
    for (column, (variable, title)) in enumerate(((:Rn_W_m2, "Rn"), (:H_W_m2, "H"),
            (:LE_W_m2, "LE"), (:G_W_m2, "G soil")))
        instant = axis_at(fig[1, column]; hours=48, title,
            ylabel=column == 1 ? "Flux (W m⁻² ground)" : "")
        integral = axis_at(fig[2, column]; hours=48,
            ylabel=column == 1 ? "Energy (MJ m⁻² ground)" : "")
        draw!(instant, case.scene, variable)
        draw!(integral, case.scene, variable; cumulative=true, factor=step_seconds / 1e6)
    end
    legend_at(fig[3, 1:4], implementations(case.scene))
    Label(fig[4, 1:4], "Scene H is residual-defined. Signed integrals retain nighttime losses; scene closure is not independent validation.";
        fontsize=11)
    return fig
end

function cumulative_energy(case; step_seconds=1800)
    names = implementations(case.scene)
    fig = Figure(size=(max(1100, 480 * length(names)), 650), fontsize=14)
    Label(fig[0, 1:length(names)], "Signed cumulative energy · Rn = H + LE + G"; fontsize=21, font=:bold)
    labels = ("Rn", "H", "LE", "G soil", "H + LE", "H + LE + G")
    colors = (:black, :darkorange2, :dodgerblue3, :sienna3, :gray55, :seagreen4)
    styles = (:solid, :solid, :solid, :solid, :dot, :dash)
    axes = Axis[]
    for (column, name) in enumerate(names)
        axis = axis_at(fig[1, column]; hours=48, title=name,
            ylabel=column == 1 ? "Energy (MJ m⁻² ground)" : "")
        push!(axes, axis)
        rows = selected(case.scene, name)
        all(diff([row.step for row in rows]) .== 1) || error("Noncontiguous energy trajectory")
        rn, h, le, g = ([getproperty(row, variable) for row in rows]
            for variable in (:Rn_W_m2, :H_W_m2, :LE_W_m2, :G_W_m2))
        for (index, values) in enumerate((rn, h, le, g, h .+ le, h .+ le .+ g))
            lines!(axis, [row.hour for row in rows], cumsum(values) .* (step_seconds / 1e6);
                color=colors[index], linestyle=styles[index], linewidth=index == 6 ? 2.8 : 2)
        end
    end
    linkyaxes!(axes...)
    Legend(fig[2, 1:length(names)],
        [LineElement(color=colors[i], linestyle=styles[i], linewidth=2.4) for i in eachindex(labels)],
        collect(labels); orientation=:horizontal, framevisible=false)
    Label(fig[3, 1:length(names)], "H + LE alone excludes soil heat G. H is calculated by difference; overlap is an accounting check.";
        fontsize=12)
    return fig
end

function water_figure(case)
    variables = ((:soil_storage_post_mm, "Soil stock after step (mm)"),
        (:canopy_storage_post_mm, "Canopy stock after step (mm)"),
        (:P_mm_step, "Rain (mm step⁻¹)"), (:throughfall_mm_step, "Throughfall (mm step⁻¹)"),
        (:canopy_T_mm_step, "Canopy T (mm step⁻¹)"), (:soil_E_mm_step, "Soil E (mm step⁻¹)"),
        (:wet_E_mm_step, "Wet E (mm step⁻¹)"), (:ET_mm_step, "Total ET (mm step⁻¹)"),
        (:drainage_mm_step, "Drainage (mm step⁻¹)"), (:runoff_mm_step, "Runoff (mm step⁻¹)"),
        (:soil_water_residual_mm_step, "Soil ΔS − net flux (mm step⁻¹)"),
        (:total_water_residual_mm_step, "Total ΔS − net flux (mm step⁻¹)"))
    fig = Figure(size=(1500, 1280), fontsize=14)
    Label(fig[0, 1:3], "Two-day accepted water stocks and fluxes"; fontsize=21, font=:bold)
    for (index, (variable, ylabel)) in enumerate(variables)
        row, column = fld(index - 1, 3) + 1, mod(index - 1, 3) + 1
        draw!(axis_at(fig[row, column]; hours=48, ylabel), case.water, variable)
    end
    legend_at(fig[5, 1:3], implementations(case.water))
    Label(fig[6, 1:3], "All fluxes are per half-hour. Throughfall = 1 sends rain directly to soil: this fixture does not test interception dynamics.";
        fontsize=11)
    return fig
end

function balance_figure(case)
    fig = Figure(size=(1350, 790), fontsize=14)
    Label(fig[0, 1:2], "Balance diagnostics · actual residuals, never tuned to zero"; fontsize=21, font=:bold)
    scene_axis = axis_at(fig[1, 1]; hours=48, title="Scene energy (algebraic)",
        ylabel="Rn − H − LE − G (W m⁻²)")
    for name in implementations(case.scene)
        rows = selected(case.scene, name)
        errors = [row.Rn_W_m2 - row.H_W_m2 - row.LE_W_m2 - row.G_W_m2 for row in rows]
        lines!(scene_axis, [row.hour for row in rows], errors;
            color=COLORS[name], linestyle=STYLES[name], linewidth=2.2)
    end
    draw!(axis_at(fig[1, 2]; hours=48, title="Independent soil-energy components",
        ylabel="Soil energy residual (W m⁻²)"), case.scene, :soil_energy_residual_W_m2)
    draw!(axis_at(fig[2, 1]; hours=48, title="Pre/post stock and fluxes",
        ylabel="Whole water residual (mm step⁻¹)"), case.water, :total_water_residual_mm_step)
    draw!(axis_at(fig[2, 2]; hours=48, title="Native soil-water diagnostic",
        ylabel="Native soil residual (mm step⁻¹)"), case.water, :native_soil_water_residual_mm_step)
    legend_at(fig[3, 1:2], implementations(case.scene))
    Label(fig[4, 1:2], "Unavailable native Fortran diagnostics stay unavailable. Residual-defined H cannot independently validate the scene energy equation.";
        fontsize=11)
    return fig
end

function matched_differences(rows, variable; tree_id=nothing)
    key(row) = isnothing(tree_id) ? (row.step, row.day, row.hour) :
        (row.step, row.day, row.hour, row.tree_id, row.species_id)
    continuous = selected(rows, "Julia-continuous"; tree_id)
    resumed = selected(rows, "Julia-resumed"; tree_id)
    a, b = Dict(key(row) => row for row in continuous), Dict(key(row) => row for row in resumed)
    length(a) == length(continuous) && length(b) == length(resumed) || error("Duplicate continuation keys")
    Set(keys(a)) == Set(keys(b)) || error("Continuation keys do not match")
    return [(hour=row.hour, difference=getproperty(b[key(row)], variable) - getproperty(row, variable))
        for row in continuous]
end

function continuation_figure(case)
    fig = Figure(size=(1200, 1120), fontsize=14)
    Label(fig[0, 1:2], "Julia resumed − continuous · same timestamps and identities"; fontsize=21, font=:bold)
    variables = ((:tree, :A_umol_s, "ΔA (µmol CO₂ tree⁻¹ s⁻¹)"),
        (:tree, :E_mmol_s, "ΔE (mmol H₂O tree⁻¹ s⁻¹)"),
        (:tree, :Tleaf_C, "ΔTleaf (°C)"), (:scene, :ET_mm_step, "ΔET (mm step⁻¹)"),
        (:water, :soil_storage_post_mm, "Δsoil stock (mm)"))
    for (row, (scope, variable, ylabel)) in enumerate(variables), column in 1:2
        axis = axis_at(fig[row, column]; hours=48, ylabel=column == 1 ? ylabel : "",
            title=row == 1 ? "Tree $column" : "")
        errors = matched_differences(getproperty(case, scope), variable;
            tree_id=scope == :tree ? column : nothing)
        lines!(axis, [item.hour for item in errors], [item.difference for item in errors];
            color=:darkorange2, linewidth=2.2)
    end
    Label(fig[6, 1:2], "In-memory continue! on the same Simulation, not disk restart. Scene/water errors repeat by column; no tolerance clipping.";
        fontsize=11)
    return fig
end

function contrast_figure(cases, scope, variables; title, cumulative=false, step_seconds=1800)
    names = [name for name in CONTRASTS if haskey(cases, name)]
    isempty(names) && throw(ArgumentError("No contrast cases supplied"))
    # Signed-integral tick labels require a little more layout room; keep the
    # shared legend inside the canvas after the final automatic layout pass.
    fig = Figure(size=(max(1100, 395 * length(names)),
        260 * length(variables) + (cumulative ? 240 : 180)),
        figure_padding=cumulative ? (10, 10, 35, 10) : 10, fontsize=14)
    Label(fig[0, 1:length(names)], title; fontsize=21, font=:bold)
    for (row, (variable, ylabel)) in enumerate(variables)
        axes = Axis[]
        for (column, name) in enumerate(names)
            axis = axis_at(fig[row, column]; ylabel=column == 1 ? ylabel : "",
                title=row == 1 ? replace(name, '-' => ' ') : "")
            push!(axes, axis)
            if scope == :tree
                # Species colour and implementation style remain independent.
                for id in sort(unique(item.tree_id for item in cases[name].tree))
                    draw!(axis, cases[name].tree, variable; tree_id=id, cumulative,
                        factor=cumulative ? step_seconds / 1e6 : 1.0,
                        color=id == 1 ? :seagreen4 : :darkorange2)
                end
            else
                draw!(axis, getproperty(cases[name], scope), variable; cumulative,
                    factor=cumulative ? step_seconds / 1e6 : 1.0)
            end
        end
        linkyaxes!(axes...)
    end
    if scope == :tree
        Legend(fig[length(variables) + 1, 1:length(names)],
            [LineElement(color=color, linestyle=STYLES[implementation], linewidth=2.4)
                for (id, color) in ((1, :seagreen4), (2, :darkorange2))
                for implementation in ("Julia-continuous", "Fortran")],
            ["Tree $id / species $id · $implementation" for id in (1, 2)
                for implementation in ("Julia-continuous", "Fortran")];
            orientation=:horizontal, framevisible=false, labelsize=11)
    else
        legend_at(fig[length(variables) + 1, 1:length(names)], ("Julia-continuous", "Fortran"))
    end
    return fig
end

function hydraulic_figure(cases)
    names = [name for name in CONTRASTS if haskey(cases, name)]
    fig = Figure(size=(max(1100, 410 * length(names)), 1230), fontsize=14)
    Label(fig[0, 1:length(names)], "Native Julia hydraulic diagnostics · not Fortran equivalents";
        fontsize=21, font=:bold)
    variables = ((:theta_post_m3_m3, "Post-step θ (m³ m⁻³)"),
        (:root_weighted_psi_MPa, "Pre-water root-weighted Ψ (MPa)"),
        (:Emax_mmol_m2_leaf_s, "Emax (mmol H₂O m⁻² leaf s⁻¹)"),
        (:limited_leaf_area_fraction, "Limited leaf-area fraction"),
        (:soil_evaporation_mm_step, "Soil E (mm step⁻¹)"))
    for (row, (variable, ylabel)) in enumerate(variables)
        axes = Axis[]
        for (column, name) in enumerate(names)
            axis = axis_at(fig[row, column]; ylabel=column == 1 ? ylabel : "",
                title=row == 1 ? replace(name, '-' => ' ') : "")
            push!(axes, axis)
            for (id, color) in ((1, :seagreen4), (2, :darkorange2))
                current = selected(cases[name].hydric, "Julia-continuous"; tree_id=id)
                isempty(current) && continue
                lines!(axis, [item.hour for item in current], [getproperty(item, variable) for item in current];
                    color, linestyle=id == 1 ? :solid : :dash, linewidth=2.2)
            end
            variable == :limited_leaf_area_fraction && ylims!(axis, -0.025, 1.025)
        end
        linkyaxes!(axes...)
    end
    Legend(fig[6, 1:length(names)],
        [LineElement(color=:seagreen4, linewidth=2.4), LineElement(color=:darkorange2, linestyle=:dash, linewidth=2.4)],
        ["Tree 1 / species 1", "Tree 2 / species 2"]; orientation=:horizontal, framevisible=false)
    Label(fig[7, 1:length(names)], "Soil content is post-step; potentials and Emax drive that step. Limitation uses the native accepted mask, not a threshold on E.";
        fontsize=11)
    return fig
end

function point_figure(case, variable, label; hours=(6.25, 12.25, 18.25))
    rows = filter(row -> row.implementation == "Julia-continuous" && row.active && row.available &&
        row.hour in hours, case.points)
    isempty(rows) && throw(ArgumentError("No acquired point outputs at requested hours"))
    all(row -> isfinite(getproperty(row, variable)), rows) || error("Nonfinite accepted point output")
    limits = extrema(getproperty(row, variable) for row in rows)
    limits[1] == limits[2] && (limits = (limits[1] - 0.5, limits[2] + 0.5))
    fig = Figure(size=(1350, 540), fontsize=14)
    Label(fig[0, 1:length(hours)], "Actual Julia simulation points · $label"; fontsize=21, font=:bold)
    snapshot = scene_snapshot(case.input)
    plot = nothing
    for (column, hour) in enumerate(hours)
        current = filter(row -> row.hour == hour, rows)
        isempty(current) && error("Missing acquired 3D point snapshot at $hour h")
        axis = Axis3(fig[1, column]; title="$hour h", xlabel="x (m)", ylabel="y (m)", zlabel="z (m)", aspect=:data)
        plot_scene!(axis, snapshot; crown_alpha=0.06, show_stems=false, show_ids=false)
        plot = scatter!(axis, [row.x for row in current], [row.y for row in current], [row.z for row in current];
            color=[getproperty(row, variable) for row in current], colormap=:viridis,
            colorrange=limits, markersize=13)
    end
    Colorbar(fig[1, length(hours) + 1], plot; label)
    Label(fig[2, 1:length(hours)], "Colours are accepted point outputs, not crown averages or interpolated voxels. One shared colour scale across times.";
        fontsize=11)
    return fig
end

"""
    evaluation_figures(result; step_seconds=1800)

Build Makie figures from `MAESPAEvaluation.evaluation_suite()` outputs without
running or modifying a simulation. Requires a loaded Makie backend. All curves
use acquired values; cumulative energy is a signed timestep integral. The
Fortran series are frozen regression references, not observations.
"""
function evaluation_figures(result; step_seconds=1800)
    cases = result.cases
    figures = Dict{String,Figure}()
    if haskey(cases, "two-day")
        case = cases["two-day"]
        figures["two_day_tree_trajectories"] = tree_figure(case)
        figures["two_day_scene_energy"] = scene_energy(case; step_seconds)
        figures["two_day_cumulative_energy_partition"] = cumulative_energy(case; step_seconds)
        figures["two_day_water_stocks_fluxes"] = water_figure(case)
        figures["two_day_balance_diagnostics"] = balance_figure(case)
        figures["two_day_resumed_minus_continuous"] = continuation_figure(case)
    end
    if any(name -> haskey(cases, name), CONTRASTS)
        figures["contrast_tree_trajectories"] = contrast_figure(cases, :tree,
            ((:A_umol_s, "A (µmol CO₂ tree⁻¹ s⁻¹)"), (:E_mmol_s, "E (mmol H₂O tree⁻¹ s⁻¹)"),
                (:Tleaf_C, "Tleaf (°C)")); title="Weather and soil-water contrasts · both trees")
        figures["contrast_scene_energy"] = contrast_figure(cases, :scene,
            ((:Rn_W_m2, "Rn (W m⁻²)"), (:H_W_m2, "H (W m⁻²)"),
                (:LE_W_m2, "LE (W m⁻²)"), (:G_W_m2, "G (W m⁻²)")); title="Weather and soil-water contrasts · scene energy")
        figures["contrast_signed_energy"] = contrast_figure(cases, :scene,
            ((:Rn_W_m2, "∫Rn (MJ m⁻²)"), (:H_W_m2, "∫H (MJ m⁻²)"),
                (:LE_W_m2, "∫LE (MJ m⁻²)"), (:G_W_m2, "∫G (MJ m⁻²)"));
            title="Weather and soil-water contrasts · signed energy", cumulative=true, step_seconds)
        figures["contrast_water_components"] = contrast_figure(cases, :water,
            ((:canopy_T_mm_step, "Canopy T (mm step⁻¹)"), (:soil_E_mm_step, "Soil E (mm step⁻¹)"),
                (:ET_mm_step, "Total ET (mm step⁻¹)")); title="Weather and soil-water contrasts · native water components")
        figures["contrast_native_hydric_diagnostics"] = hydraulic_figure(cases)
    end
    if haskey(cases, "different-physiology")
        figures["different_physiology_known_fortran_bug"] = tree_figure(cases["different-physiology"];
            title="Different physiology · expected Fortran species-context defect (not fixed)", hours=24)
    end
    if haskey(cases, "equal-physiology")
        for (variable, name, label) in ((:Tleaf_C, "Tleaf", "Tleaf (°C)"),
                (:A_umol_m2_s, "assimilation", "A (µmol CO₂ m⁻² leaf s⁻¹)"),
                (:E_umol_m2_s, "transpiration", "E (µmol H₂O m⁻² leaf s⁻¹)"))
            figures["scene_points_$name"] = point_figure(cases["equal-physiology"], variable, label)
        end
    end
    return figures
end

"""Render the suite, save each named figure as PNG, and return its paths."""
function save_evaluation_figures(result, directory; px_per_unit=1.5, kwargs...)
    mkpath(directory)
    figures = evaluation_figures(result; kwargs...)
    paths = Dict{String,String}()
    for name in sort(collect(keys(figures)))
        path = joinpath(directory, "$name.png")
        save(path, figures[name]; px_per_unit)
        paths[name] = path
    end
    return paths
end

end # module
