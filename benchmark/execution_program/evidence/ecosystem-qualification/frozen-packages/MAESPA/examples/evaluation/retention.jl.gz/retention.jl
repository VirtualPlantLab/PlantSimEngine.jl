# Public output-retention definitions shared by integration tests and executable documentation.
# No process equations or runtime status ports are introduced by this evaluator.
stream_key(id, variable) = Symbol(id, "__", variable)
clean(value) = replace(string(value), '\t' => ' ', '\n' => ' ')
digest(path) = bytes2hex(sha256(read(path)))

function write_table(path, names, rows)
    open(path, "w") do io
        println(io, join(string.(names), '\t'))
        for row in rows
            println(io, join(clean.(Tuple(row)), '\t'))
        end
    end
    return nothing
end

function retain!(requests, metadata, applications, id, process, variables;
    unit, basis, temporal, availability=nothing, held_geometry=false, notes="")
    for variable in variables
        application = only(filter(app -> app.process === process &&
            id in app.target_ids && variable in app.outputs, applications))
        request = OutputRequest(One(id=id), variable;
            application=application.application_id,
            clock=held_geometry ? nothing : application.clock,
            name=stream_key(id, variable))
        push!(requests, request)
        push!(metadata, (object_id=id, application_id=application.application_id,
            process, variable, request_name=request.name, unit, basis, temporal,
            source_clock=repr(application.clock),
            export_clock=held_geometry ? "base-step HoldLast" : repr(application.clock),
            policy="HoldLast", availability_application=isnothing(availability) ?
                "unmapped" : string(application.application_id),
            availability_variable=isnothing(availability) ? "unmapped" : string(availability),
            availability_join=isnothing(availability) ? "not inferred" : "same timestep",
            scientific_provenance="explicit comparator definition; source port may be uncontracted",
            notes))
    end
    return nothing
end

function base_requests(model)
    applications = Diagnostics.explain_applications(model)
    requests, metadata = OutputRequest[], NamedTuple[]
    retain!(requests, metadata, applications, :scene, :legacy_calendar,
        (:step_index,); unit="index", basis="source day", temporal="current source step")
    retain!(requests, metadata, applications, :scene, :canopy_air_microclimate,
        (:canopy_total_net_radiation_w_m2, :canopy_total_latent_heat_flux_w_m2,
         :canopy_total_sensible_heat_flux_w_m2);
        unit="W m^-2", basis="ground area", temporal="accepted timestep flux",
        availability=:canopy_air_microclimate_available,
        notes="H is calculated as Rn-LE-G; closure is not an independent validation")
    retain!(requests, metadata, applications, :scene, :canopy_air_microclimate,
        (:canopy_latent_heat_vaporization_j_mol,); unit="J mol^-1 H2O",
        basis="water", temporal="accepted timestep conversion",
        availability=:canopy_air_microclimate_available,
        notes="lambda evaluated at trial canopy-air temperature; used for derived tree LE")
    retain!(requests, metadata, applications, :scene, :canopy_air_microclimate,
        (:canopy_air_microclimate_available,); unit="Bool", basis="scene",
        temporal="accepted timestep availability")
    retain!(requests, metadata, applications, :scene, :stand_water_flux_scaling,
        (:canopy_transpiration_mm_timestep, :wet_canopy_evaporation_mm_timestep);
        unit="mm timestep^-1", basis="ground area", temporal="accepted interval amount",
        availability=:stand_water_flux_scaling_available,
        notes="signed water flux; negative evaporation is condensation")
    retain!(requests, metadata, applications, :scene, :stand_water_flux_scaling,
        (:stand_water_flux_scaling_available,); unit="Bool", basis="scene",
        temporal="accepted timestep availability")
    energy = only(filter(app -> :soil in app.target_ids &&
        :soil_energy_balance_residual_w_m2 in app.outputs, applications))
    retain!(requests, metadata, applications, :soil, energy.process,
        (:soil_heat_flux_w_m2,); unit="W m^-2", basis="ground area",
        temporal="accepted timestep flux", availability=:soil_surface_energy_available,
        notes="positive conductive heat flux into soil")
    retain!(requests, metadata, applications, :soil, energy.process,
        (:soil_surface_energy_available,); unit="Bool", basis="soil surface",
        temporal="accepted timestep availability")
    retain!(requests, metadata, applications, :soil, :soil_surface_evaporation,
        (:soil_evaporation_mm_timestep,); unit="mm timestep^-1", basis="ground area",
        temporal="accepted interval amount", availability=:soil_surface_evaporation_available)
    retain!(requests, metadata, applications, :soil, :soil_surface_evaporation,
        (:soil_surface_evaporation_available,); unit="Bool", basis="soil surface",
        temporal="accepted timestep availability")
    for tree in 1:2
        crown = Symbol("crown_", tree)
        aggregation = :crown_leaf_exchange_aggregation
        gate = :crown_leaf_exchange_aggregation_available
        retain!(requests, metadata, applications, crown, aggregation,
            (:net_assimilation_crown_umol_co2_s,); unit="umol CO2 s^-1",
            basis="individual tree", temporal="accepted timestep flux", availability=gate)
        retain!(requests, metadata, applications, crown, aggregation,
            (:dry_transpiration_crown_umol_h2o_s, :wet_evaporation_crown_umol_h2o_s);
            unit="umol H2O s^-1", basis="individual tree", temporal="accepted timestep flux",
            availability=gate)
        retain!(requests, metadata, applications, crown, aggregation,
            (:sensible_heat_crown_w,); unit="W", basis="individual tree",
            temporal="accepted timestep flux", availability=gate)
        retain!(requests, metadata, applications, crown, aggregation,
            (:mean_leaf_temperature_crown_c,); unit="degC", basis="leaf-area weighted tree mean",
            temporal="accepted timestep state", availability=gate)
        retain!(requests, metadata, applications, crown, aggregation, (gate,);
            unit="Bool", basis="individual tree", temporal="accepted timestep availability")
        radiation = :crown_radiation_aggregation
        retain!(requests, metadata, applications, crown, radiation,
            (:absorbed_par_crown_w, :absorbed_nir_crown_w);
            unit="W", basis="individual tree", temporal="accepted timestep flux",
            availability=:crown_radiation_aggregation_available,
            notes="Night shortwave outputs are reset to zero, not declared available")
        retain!(requests, metadata, applications, crown, radiation,
            (:absorbed_thermal_crown_w,);
            unit="W", basis="individual tree", temporal="accepted timestep flux",
            availability=:crown_thermal_radiation_aggregation_available,
            notes="tree Rn=sum(PAR,NIR,signed net thermal); shortwave gate retained separately")
        retain!(requests, metadata, applications, crown, radiation,
            (:crown_radiation_aggregation_available, :crown_thermal_radiation_aggregation_available);
            unit="Bool", basis="individual tree", temporal="accepted timestep availability")
        retain!(requests, metadata, applications, crown, :canopy_sampling,
            (:representative_x, :representative_y, :representative_z);
            unit="m", basis="local plot coordinates", temporal="daily geometry state",
            held_geometry=true, notes="daily source explicitly held at base-step export cadence")
        layout = :logical_leaf_unit_layout
        retain!(requests, metadata, applications, crown, layout,
            (:logical_leaf_point_index,); unit="index", basis="geometric simulation point",
            temporal="accepted timestep layout", availability=:logical_leaf_unit_layout_available)
        retain!(requests, metadata, applications, crown, layout,
            (:logical_leaf_area_m2,); unit="m^2", basis="logical leaf unit",
            temporal="accepted timestep area", availability=:logical_leaf_unit_layout_available)
        retain!(requests, metadata, applications, crown, layout,
            (:logical_leaf_unit_active, :logical_leaf_unit_layout_available);
            unit="Bool", basis="logical leaf units/layout", temporal="accepted timestep activity")
        controller = :non_tuzet_crown_leaf_exchange_controller
        gate = :non_tuzet_crown_leaf_exchange_controller_available
        retain!(requests, metadata, applications, crown, controller,
            (:non_tuzet_accepted_logical_leaf_net_assimilation_umol_co2_m2_s,);
            unit="umol CO2 m^-2 s^-1", basis="leaf area", temporal="accepted timestep flux",
            availability=gate)
        retain!(requests, metadata, applications, crown, controller,
            (:non_tuzet_accepted_logical_leaf_actual_transpiration_umol_h2o_m2_s,);
            unit="umol H2O m^-2 s^-1", basis="leaf area", temporal="accepted timestep flux",
            availability=gate)
        retain!(requests, metadata, applications, crown, controller, (gate,);
            unit="Bool", basis="individual tree", temporal="accepted timestep availability")
        snapshot = :crown_leaf_thermal_snapshot
        retain!(requests, metadata, applications, crown, snapshot,
            (:point_leaf_temperature_c,); unit="degC", basis="leaf-area weighted simulation point",
            temporal="accepted timestep state", availability=:crown_leaf_thermal_snapshot_available)
        retain!(requests, metadata, applications, crown, snapshot,
            (:crown_leaf_thermal_snapshot_available,); unit="Bool", basis="individual tree",
            temporal="accepted timestep availability")
    end
    return requests, metadata
end

function comparison_requests(model)
    requests, metadata = base_requests(model)
    apps = Diagnostics.explain_applications(model)
    retain(id, process, variables; kwargs...) = retain!(requests, metadata,
        apps, id, process, variables; kwargs...)
    retain(:soil, :soil_water_balance, (:soil_water_contents,);
        unit="m^3 m^-3", basis="soil layer profile", temporal="accepted post-water-update state",
        availability=:soil_water_balance_available)
    retain(:soil, :soil_water_balance, (:soil_water_potentials_before_water_balance_mpa,);
        unit="MPa", basis="soil layer profile", temporal="pre-water-update state",
        availability=:soil_pre_water_potential_available,
        notes="Not the same instant as post-update water content")
    retain(:soil, :soil_water_balance,
        (:soil_water_balance_available, :soil_pre_water_potential_available);
        unit="Bool", basis="soil profile", temporal="accepted timestep availability")
    for tree in 1:2
        root, crown = Symbol("root_system_", tree), Symbol("crown_", tree)
        retain(root, :root_water_uptake, (:weighted_soil_water_potential_mpa,);
            unit="MPa", basis="root-weighted soil potential",
            temporal="hydraulic forcing used in accepted timestep",
            availability=:root_water_uptake_available)
        retain(root, :root_water_uptake, (:root_water_uptake_available,);
            unit="Bool", basis="root system", temporal="accepted timestep availability")
        retain(root, :soil_to_leaf_hydraulic_supply,
            (:maximum_leaf_transpiration_mmol_m2_leaf_s,);
            unit="mmol H2O m^-2 leaf s^-1", basis="leaf area",
            temporal="supply used in accepted timestep",
            availability=:soil_to_leaf_hydraulic_supply_available)
        retain(root, :soil_to_leaf_hydraulic_supply,
            (:soil_to_leaf_hydraulic_supply_available,); unit="Bool", basis="root system",
            temporal="accepted timestep availability")
        retain(crown, :non_tuzet_crown_leaf_exchange_controller,
            (:non_tuzet_logical_leaf_hydraulic_limitation_applied,);
            unit="Bool", basis="logical leaf units", temporal="accepted timestep branch mask",
            availability=:non_tuzet_crown_leaf_exchange_controller_available,
            notes="True means native Emax branch applied, not inferred from a flux decrease")
    end
    return requests, metadata
end

function output_requests(model)
    requests, metadata = comparison_requests(model)
    applications = Diagnostics.explain_applications(model)
    function retain(id, process, variables; kwargs...)
        absent = filter(variable -> all(request -> request.name !==
            stream_key(id, variable), requests), variables)
        retain!(requests, metadata, applications, id, process, absent; kwargs...)
    end
    retain(:scene, :legacy_calendar, (:simulation_step, :simulation_day, :date50);
        unit="index", basis="source calendar", temporal="current accepted source position")
    retain(:scene, :open_top_chamber_meteorology, (:precipitation_mm,);
        unit="mm timestep^-1", basis="ground area", temporal="forcing interval amount",
        availability=:meteorology_reconstruction_available)
    retain(:scene, :open_top_chamber_meteorology, (:incident_par_w_m2, :incident_nir_w_m2);
        unit="W m^-2", basis="horizontal ground area", temporal="accepted forcing",
        availability=:meteorology_reconstruction_available)
    # This final publisher forwards the reconstruction flag. The separate OTC
    # flag means that the optional chamber transformation was active, not that
    # the untransformed meteorology is unavailable.
    retain(:scene, :open_top_chamber_meteorology, (:meteorology_reconstruction_available,);
        unit="Bool", basis="scene", temporal="accepted forcing availability")
    retain(:soil, :soil_water_balance, (
        :soil_storage_before_m, :soil_storage_after_m, :soil_external_net_flux_m,
        :soil_lower_bound_correction_m, :soil_water_table_exchange_m,
        :soil_imposed_stock_exchange_m, :soil_surface_overflow_m,
        :soil_total_boundary_outflow_m, :soil_deep_drainage_m,
        :soil_lateral_discharge_m, :soil_water_table_boundary_drainage_m,
        :soil_water_mass_balance_residual_m, :soil_infiltration_mass_balance_residual_m);
        unit="m water", basis="ground area", temporal="accepted interval state/amount (port name distinguishes)",
        availability=:soil_water_balance_available,
        notes="Boundary outflow already includes its components; internal vertical transfers are not additional losses")
    retain(:scene, :canopy_water_storage, (
        :canopy_water_storage_mm, :canopy_water_storage_change_mm,
        :canopy_water_storage_correction_mm, :surface_water_mm,
        :direct_throughfall_mm, :canopy_drainage_mm, :canopy_evaporation_mm,
        :canopy_water_mass_balance_residual_mm, :canopy_evaporation_residual_mm);
        unit="mm water", basis="ground area", temporal="accepted interval state/amount (port name distinguishes)",
        availability=:canopy_water_storage_available,
        notes="Pre-stock=post-stock-change-correction; surface_water is total throughfall including canopy drainage")
    retain(:scene, :canopy_water_storage, (:canopy_water_storage_available,);
        unit="Bool", basis="canopy water", temporal="accepted timestep availability")
    retain(:soil, :soil_water_flux_partition, (
        :root_water_uptake_m, :soil_evaporation_m, :soil_dew_m);
        unit="m water", basis="ground area by soil layer", temporal="accepted interval withdrawal/deposition",
        availability=:soil_water_flux_partition_available)
    retain(:soil, :soil_water_flux_partition, (:soil_water_flux_partition_available,);
        unit="Bool", basis="soil flux partition", temporal="accepted timestep availability")
    retain(:soil, :soil_surface_energy_balance, (
        :soil_net_radiation_w_m2, :soil_sensible_heat_flux_w_m2,
        :soil_latent_heat_flux_w_m2, :soil_energy_balance_residual_w_m2);
        unit="W m^-2", basis="ground area", temporal="accepted timestep energy flux/residual",
        availability=:soil_surface_energy_available)
    retain(:soil, :soil_surface_energy_balance, (
        :soil_surface_energy_components_evaluated, :soil_surface_energy_converged,
        :soil_surface_energy_solution_at_lower_bound, :soil_surface_energy_solution_at_upper_bound);
        unit="Bool", basis="soil energy solve", temporal="accepted timestep diagnostic")
    return requests, metadata
end


