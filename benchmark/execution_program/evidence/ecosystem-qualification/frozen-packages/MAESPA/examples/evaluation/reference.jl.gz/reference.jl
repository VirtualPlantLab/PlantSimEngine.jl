# Read frozen raw text outputs. This module never starts or regenerates a reference executable.
latent_heat_mass(temperature_c) = 2.501e6 - 2365 * temperature_c

function read_raw(path, column_count)
    lines = readlines(path)
    header = findfirst(line -> startswith(strip(line), "Columns:"), lines)
    isnothing(header) && error("No Fortran Columns header in $path")
    rows = Vector{Float64}[]
    for (offset, line) in enumerate(lines[header + 1:end])
        isempty(strip(line)) && continue
        fields = split(line)
        length(fields) == column_count || error("Wrong raw field count at $path:$(header + offset)")
        push!(rows, [parse(Float64, replace(field, 'D' => 'E', 'd' => 'e')) for field in fields])
    end
    isempty(rows) && error("No acquired Fortran data in $path")
    return rows
end

function integer_field(value, name)
    isfinite(value) && isinteger(value) || error("Invalid integer Fortran $name")
    return Int(value)
end

"""
    read_fortran(raw_directory; initial_soil_mm=150,
                     initial_canopy_mm=0, step_seconds=1800, expected_days=2)

Convert actual `1_hrflux.dat` and `1_watbal.dat` records. Raw DAY is a
simulation-day index, not a calendar date. The first acquired DAY is mapped to
canonical day 1; elapsed hour uses the real day offset and within-day hour.
All required days/slots must exist. No day/hour is inferred from row order.

The initial stocks are explicit input conditions, not guessed from the first
post-step output. For this no-water-table/no-lateral/KEEPWET=0 case the profile
balance is ΔSsoil = throughfall − T − soil E − drainage − overflow. Discharge
and overflow are already millimetres in the Fortran writer. An unavailable
native Fortran residual is retained as NaN, distinct from the physical residual
computed here from actual stock changes and fluxes.
"""
function read_fortran(raw_directory; initial_soil_mm=150.0,
                         initial_canopy_mm=0.0, step_seconds=1800.0, expected_days=2)
    all(isfinite, (initial_soil_mm, initial_canopy_mm, step_seconds)) && step_seconds > 0 ||
        throw(ArgumentError("Finite explicit initial stocks and positive timestep required"))
    slots = round(Int, 86400 / step_seconds)
    slots * step_seconds == 86400 || error("Timestep must divide one day")
    scene_path, tree_path = (joinpath(raw_directory, file) for file in ("1_watbal.dat", "1_hrflux.dat"))
    raw_scene, raw_tree = read_raw(scene_path, 48), read_raw(tree_path, 27)
    days = sort(unique(integer_field(row[1], "DAY") for row in raw_scene))
    days == collect(first(days):last(days)) || error("Noncontiguous acquired Fortran days")
    isnothing(expected_days) || length(days) == expected_days || error("Unexpected number of acquired days")
    first_day = first(days)
    scene_key(row) = (integer_field(row[1], "DAY"), integer_field(row[2], "IHR"))
    expected_keys = Set((day, slot) for day in days for slot in 1:slots)
    allunique(scene_key(row) for row in raw_scene) || error("Duplicate acquired scene day/hour")
    Set(scene_key(row) for row in raw_scene) == expected_keys || error("Incomplete acquired scene day/hour grid")
    sort!(raw_scene; by=scene_key)
    by_key = Dict(scene_key(row) => row for row in raw_scene)
    tree_key(row) = (integer_field(row[1], "DAY"), integer_field(row[4], "IHR"),
        integer_field(row[2], "ITREE"))
    allunique(tree_key(row) for row in raw_tree) || error("Duplicate acquired physical-tree day/hour")
    Set(tree_key(row) for row in raw_tree) ==
        Set((day, slot, tree) for day in days for slot in 1:slots for tree in 1:2) ||
        error("Incomplete acquired two-tree day/hour grid")
    Set((integer_field(row[2], "ITREE"), integer_field(row[3], "ISPECIES")) for row in raw_tree) ==
        Set(((1, 1), (2, 2))) || error("Changed physical/species identity")
    stamp(day, slot) = (step=(day - first_day) * slots + slot, day=day - first_day + 1,
        hour=24 * (day - first_day) + (slot - 0.5) * step_seconds / 3600)
    scene_rows, tree_rows, water_rows = NamedTuple[], NamedTuple[], NamedTuple[]
    soil_pre, canopy_pre = initial_soil_mm, initial_canopy_mm
    for row in raw_scene
        all(isfinite, row[[3, 5, 6, 9, 10, 12, 13, 17, 20, 21, 22, 23, 26, 30, 43, 47]]) ||
            error("Nonfinite Fortran quantity needed for physical comparison")
        day, slot = scene_key(row)
        time = stamp(day, slot)
        et = row[10] + row[47] + row[17]
        soil_residual = (row[3] - soil_pre) - (row[9] - row[10] - row[17] - row[12] - row[13])
        total_residual = (row[3] - soil_pre + row[6] - canopy_pre) -
            (row[5] - row[10] - row[17] - row[47] - row[12] - row[13])
        push!(scene_rows, (implementation="Fortran", time..., Rn_W_m2=row[22] + row[26], H_W_m2=row[43],
            LE_W_m2=row[21] + (row[10] + row[47]) * latent_heat_mass(row[30]) / step_seconds,
            G_W_m2=row[23], ET_mm_step=et,
            soil_energy_residual_W_m2=row[22] - row[20] - row[21] - row[23]))
        push!(water_rows, (implementation="Fortran", time..., soil_storage_pre_mm=soil_pre,
            soil_storage_post_mm=row[3], canopy_storage_pre_mm=canopy_pre,
            canopy_storage_post_mm=row[6], P_mm_step=row[5], throughfall_mm_step=row[9],
            canopy_T_mm_step=row[10], soil_E_mm_step=row[17], wet_E_mm_step=row[47],
            ET_mm_step=et, drainage_mm_step=row[12], runoff_mm_step=row[13],
            soil_water_residual_mm_step=soil_residual, total_water_residual_mm_step=total_residual,
            native_soil_water_residual_mm_step=NaN))
        soil_pre, canopy_pre = row[3], row[6]
    end
    unavailable_tree_LE = 0
    for row in sort(raw_tree; by=tree_key)
        all(isfinite, row[[5, 6, 7, 8, 11, 15, 16]]) || error("Nonfinite required tree output")
        day, slot, tree = tree_key(row)
        scene = by_key[(day, slot)]
        dry_case = iszero(scene[47]) && iszero(scene[6])
        dry_case || (unavailable_tree_LE += 1)
        push!(tree_rows, (implementation="Fortran", stamp(day, slot)..., tree_id=tree,
            species_id=integer_field(row[3], "ISPECIES"), A_umol_s=row[8], E_mmol_s=row[11],
            H_W=row[15] * 1000, Tleaf_C=row[16], Rn_W=row[5] / 4.57 + row[6] + row[7],
            LE_W=dry_case ? row[11] * 1e-3 * 0.018 * latent_heat_mass(scene[30]) : NaN))
    end
    return (; tree=tree_rows, scene=scene_rows, water=water_rows)
end

