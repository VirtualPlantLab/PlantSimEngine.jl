module MAESPAEvaluation

# Offline scientific-regression examples shared by tests and executable docs.
# This is not a production model, a calibration, or a reference generator.
using MAESPA, PlantSimEngine, Dates, SHA, TOML

export evaluation_suite, assert_evaluation, verify_fixtures, comparison_checks,
    read_fortran, canonical_units, CASES, FIXTURE_ROOT

const FIXTURE_ROOT = joinpath(pkgdir(MAESPA), "test", "fixtures", "evaluation")
const FIXTURE_MANIFEST_SHA256 = "e914052e75f9842c78c43fde0b165177339d2b1cb1b79c94466bef134ffc39ea"
const CASES = ("equal-physiology", "low-radiation", "dry-air", "dry-soil",
    "two-day", "different-physiology")

include("retention.jl")
include("reference.jl")
include("collection.jl")
include("checks.jl")

"""Check the immutable offline payload; never compile or regenerate a reference."""
function verify_fixtures(root=FIXTURE_ROOT)
    manifest = joinpath(root, "PROVENANCE.toml")
    if abspath(root) == abspath(FIXTURE_ROOT)
        digest(manifest) == FIXTURE_MANIFEST_SHA256 ||
            throw(ArgumentError("Frozen provenance changed; a reference refresh requires explicit review"))
    end
    provenance = TOML.parsefile(manifest)
    for (relative, expected) in provenance["files"]
        if isabspath(relative) || first(splitpath(normpath(relative))) == ".."
            throw(ArgumentError("Fixture path escapes its root: $relative"))
        end
        path = normpath(joinpath(root, relative))
        isfile(path) && digest(path) == expected ||
            throw(ArgumentError("Frozen reference changed or missing: $relative; do not regenerate it during tests"))
    end
    return provenance
end

function execute_case(directory; implementation="Julia-continuous", split_at=nothing)
    input = read_maespa(joinpath(directory, "inputs"); mode=:legacy, T=Float64,
        species_files=:required, water_balance=:required)
    days = input.config.end_date.days_since_1950 - input.config.start_date.days_since_1950 + 1
    steps = days * input.config.steps_per_day
    model = build_model(input; mount_leaf_exchange=true)
    requests, metadata = output_requests(model)
    initial_soil = 1000 * sum(input.soil.initial_state.water_content .* input.soil.layers.thickness_m)
    canopy = only(spec.model for spec in model.applications if
        spec isa ModelSpec && PlantSimEngine.process(spec.model) === :canopy_water_storage)
    initial_canopy = canopy.initial_canopy_water_storage_mm
    simulation = run!(model; steps=isnothing(split_at) ? steps : split_at, outputs=requests)
    prefix = nothing
    if !isnothing(split_at)
        prefix = retained_history(simulation, requests)
        continue!(simulation; steps=steps-split_at)
    end
    history = retained_history(simulation, requests)
    current_step(simulation) == steps || error("Incomplete accepted scenario")
    tables = tables_from_history(history, input, implementation)
    return (; input, requests, metadata, history, prefix, tables, days, steps,
        initial_soil, initial_canopy)
end

"""
    evaluation_suite(; cases=CASES, verify=true, fixture_root=FIXTURE_ROOT)

Run fresh Julia predictions against frozen Fortran text outputs. The two-day
case also executes a fresh `48 + continue!(48)` path. No graphical dependency
is loaded. With `verify=false`, return failed numerical checks for inspection;
immutable fixture hashes and structural validity are always checked.
"""
function evaluation_suite(; cases=CASES, verify=true, fixture_root=FIXTURE_ROOT)
    all(in(CASES), cases) && allunique(cases) || throw(ArgumentError("Unknown or repeated evaluation case"))
    provenance = verify_fixtures(fixture_root)
    results = Dict{String,NamedTuple}()
    checks = NamedTuple[]
    continuation = (available=false, exact_equal=false, prefix_unchanged=false,
        max_abs_difference=NaN, streams=0, samples=0)
    for name in cases
        @info "MAESPA evaluation" case=name
        directory = joinpath(fixture_root, name)
        run = execute_case(directory)
        run.steps == provenance["cases"][name]["steps"] || error("Fixture duration changed")
        reference = read_fortran(joinpath(directory, "fortran");
            initial_soil_mm=run.initial_soil, initial_canopy_mm=run.initial_canopy,
            expected_days=run.days)
        append!(checks, native_checks(run; case=name))
        combined = Dict(field => vcat(getproperty(run.tables, field),
            hasproperty(reference, field) ? getproperty(reference, field) : NamedTuple[])
            for field in (:tree, :scene, :water, :points, :hydric, :diagnostics))
        metrics = NamedTuple[]
        for table in (:tree, :scene, :water)
            comparison = comparison_checks(getproperty(run.tables, table), getproperty(reference, table);
                table, case=name)
            append!(metrics, comparison.metrics)
            # All differences remain visible. The defective historical driver
            # is not a parity oracle for the coupled different-physiology case.
            provenance["cases"][name]["reference_comparable"] && append!(checks, comparison.checks)
        end
        if name == "two-day"
            resumed = execute_case(directory; implementation="Julia-resumed", split_at=48)
            append!(checks, native_checks(resumed; case="two-day/resumed"))
            prefix_unchanged = all(haskey(resumed.history, key) && isequal(row, resumed.history[key])
                for (key, row) in resumed.prefix)
            exact_equal = isequal(run.history, resumed.history)
            continuation = (available=true, exact_equal, prefix_unchanged,
                max_abs_difference=exact_equal ? 0.0 : Inf,
                streams=length(run.requests), samples=length(run.history))
            push!(checks, check("two-day", "continuation", :retained_history, exact_equal ? 0.0 : Inf, 0.0))
            push!(checks, check("two-day", "continuation", :saved_prefix, prefix_unchanged ? 0.0 : Inf, 0.0))
            for field in keys(combined)
                append!(combined[field], getproperty(resumed.tables, field))
            end
        end
        if name == "different-physiology"
            a(id) = sum(row.A_umol_s for row in run.tables.tree if row.tree_id == id)
            push!(checks, check(name, "species", :distinct_native_assimilation,
                a(1) > a(2) ? 0.0 : Inf, 0.0;
                notes="Native species remain distinct; defective Fortran differences are shown, not enforced"))
        end
        results[name] = (; input=run.input, combined..., metrics)
    end
    verify_fixtures(fixture_root)
    result = (; cases=results, continuation, checks, provenance)
    verify && assert_evaluation(result)
    return result
end

"""Throw with named failed acceptance checks; no reference update is attempted."""
function assert_evaluation(result)
    failures = filter(row -> !row.passed, result.checks)
    isempty(failures) || error("MAESPA evaluation failed:\n" * join(
        ("$(row.case)/$(row.group)/$(row.variable): $(row.metric) > $(row.limit)" for row in failures), '\n'))
    return nothing
end

end # module
