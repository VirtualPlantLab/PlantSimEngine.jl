# Regression acceptance policy, not empirical measurement uncertainty.
# Absolute floors protect night/zero fluxes; daily integrations remain signed.
const FLUX_RTOL = 1e-3
# Approved scientific resolution, not an N-ULP/global RK error guarantee.
# Historical drainage is obtained from quantized REAL water-content states;
# at theta=0.3 and 0.5 m, one state spacing already represents 1.49e-5 mm.
# Use the existing 1e-4 mm water-balance resolution only for instantaneous
# drainage. Signed daily drainage and all other flux policies stay unchanged.
const DRAINAGE_ATOL_MM = 1e-4
const TREE_POLICY = (
    A_umol_s=(atol=0.02, rtol=FLUX_RTOL, factor=1800e-6, integration_floor=5e-6),
    E_mmol_s=(atol=0.001, rtol=FLUX_RTOL, factor=1800e-3, integration_floor=5e-6),
    H_W=(atol=0.05, rtol=FLUX_RTOL, factor=1800e-6, integration_floor=0.005),
    Tleaf_C=(atol=0.02, rtol=0.0, factor=nothing, integration_floor=5e-6),
    Rn_W=(atol=0.05, rtol=FLUX_RTOL, factor=1800e-6, integration_floor=0.005),
    LE_W=(atol=0.05, rtol=FLUX_RTOL, factor=1800e-6, integration_floor=0.005),
)
const SCENE_POLICY = (
    Rn_W_m2=(atol=0.1, rtol=FLUX_RTOL, factor=1800e-6, integration_floor=0.002),
    H_W_m2=(atol=0.1, rtol=FLUX_RTOL, factor=1800e-6, integration_floor=0.002),
    LE_W_m2=(atol=0.1, rtol=FLUX_RTOL, factor=1800e-6, integration_floor=0.002),
    G_W_m2=(atol=0.1, rtol=FLUX_RTOL, factor=1800e-6, integration_floor=0.002),
    ET_mm_step=(atol=1e-5, rtol=FLUX_RTOL, factor=1.0, integration_floor=1e-6),
)
const WATER_FLUXES = (:P_mm_step, :throughfall_mm_step, :canopy_T_mm_step,
    :soil_E_mm_step, :wet_E_mm_step, :ET_mm_step, :drainage_mm_step, :runoff_mm_step)
const STOCKS = (:soil_storage_pre_mm, :soil_storage_post_mm,
    :canopy_storage_pre_mm, :canopy_storage_post_mm)

function canonical_units(table)
    table == :tree && return Dict(:A_umol_s=>"umol CO2 tree^-1 s^-1", :E_mmol_s=>"mmol H2O tree^-1 s^-1",
        :H_W=>"W tree^-1", :Tleaf_C=>"degC", :Rn_W=>"W tree^-1", :LE_W=>"W tree^-1")
    table == :scene && return Dict(:Rn_W_m2=>"W m^-2 ground", :H_W_m2=>"W m^-2 ground",
        :LE_W_m2=>"W m^-2 ground", :G_W_m2=>"W m^-2 ground", :ET_mm_step=>"mm timestep^-1",
        :soil_energy_residual_W_m2=>"W m^-2 ground")
    table == :water && return Dict([field=>"mm" for field in STOCKS]...,
        [field=>"mm timestep^-1" for field in (WATER_FLUXES...,
            :soil_water_residual_mm_step, :total_water_residual_mm_step,
            :native_soil_water_residual_mm_step)]...)
    throw(ArgumentError("Unknown physical table $table"))
end

function check(case, group, variable, metric, limit; notes="")
    return (; case=string(case), group=string(group), variable,
        passed=isfinite(metric) && metric <= limit, metric=Float64(metric), limit=Float64(limit), notes)
end

row_key(row, table) = table == :tree ? (row.step, row.day, row.hour, row.tree_id, row.species_id) :
    (row.step, row.day, row.hour)

function checked_rows(rows, table)
    isempty(rows) && throw(ArgumentError("Empty $table comparison"))
    all(row -> all(hasproperty(row, field) for field in keys(canonical_units(table))), rows) ||
        throw(ArgumentError("Missing $table variable"))
    keys_ = [row_key(row, table) for row in rows]
    allunique(keys_) || throw(ArgumentError("Duplicate $table sample identity"))
    steps = sort(unique(row.step for row in rows))
    n = length(steps)
    n in (48, 96) && steps == collect(1:n) || throw(ArgumentError("Incomplete $table timeline"))
    all(row -> row.day == cld(row.step, 48) && row.hour == (row.step - 0.5) / 2, rows) ||
        throw(ArgumentError("Incorrect $table calendar or half-hour cadence"))
    length(unique(row.implementation for row in rows)) == 1 ||
        throw(ArgumentError("A comparison must contain one implementation"))
    if table == :tree
        Set((row.tree_id, row.species_id) for row in rows) == Set(((1, 1), (2, 2))) ||
            throw(ArgumentError("Changed physical tree/species identity"))
        length(rows) == 2n || throw(ArgumentError("Missing tree sample"))
    else
        length(rows) == n || throw(ArgumentError("Missing scene sample"))
    end
    for row in rows, field in keys(canonical_units(table))
        # This native residual genuinely does not exist in the archived writer.
        if table == :water && field == :native_soil_water_residual_mm_step && row.implementation == "Fortran"
            isnan(getproperty(row, field)) || throw(ArgumentError("Fortran native residual must remain unavailable"))
        else
            isfinite(getproperty(row, field)) || throw(ArgumentError("Nonfinite required $table/$field"))
        end
    end
    return Dict(zip(keys_, rows))
end

function comparison_checks(predicted, reference; table, case="synthetic",
    units=canonical_units(table), reference_units=canonical_units(table))
    units == reference_units == canonical_units(table) || throw(ArgumentError("Physical units/bases differ"))
    a, b = checked_rows(predicted, table), checked_rows(reference, table)
    Set(keys(a)) == Set(keys(b)) || throw(ArgumentError("Unmatched $table identities/times"))
    policy = table == :tree ? pairs(TREE_POLICY) : table == :scene ? pairs(SCENE_POLICY) :
        [field => (atol=field in STOCKS ? 0.002 :
                field === :drainage_mm_step ? DRAINAGE_ATOL_MM : 1e-5,
            rtol=field in STOCKS ? 0.0 : FLUX_RTOL,
            factor=field in STOCKS ? nothing : 1.0, integration_floor=1e-6)
            for field in (STOCKS..., WATER_FLUXES...)]
    checks, metrics = NamedTuple[], NamedTuple[]
    ids = table == :tree ? (1, 2) : (0,)
    days = sort(unique(row.day for row in predicted))
    for id in ids, day in days, (variable, p) in policy
        keys_ = sort([key for key in keys(a) if a[key].day == day &&
            (table != :tree || a[key].tree_id == id)])
        x = [getproperty(a[key], variable) for key in keys_]
        y = [getproperty(b[key], variable) for key in keys_]
        differences = x .- y
        limits = p.atol .+ p.rtol .* abs.(y)
        normalized_error = maximum(abs.(differences) ./ limits)
        push!(checks, check(case, "$table/instantaneous/tree$id/day$day", variable, normalized_error, 1.0))
        daily_x = isnothing(p.factor) ? NaN : sum(x) * p.factor
        daily_y = isnothing(p.factor) ? NaN : sum(y) * p.factor
        if !isnothing(p.factor)
            limit = length(x) * p.integration_floor * p.factor + p.rtol * abs(daily_y)
            push!(checks, check(case, "$table/daily/tree$id/day$day", variable,
                abs(daily_x - daily_y), limit; notes="Signed interval sum; explicit numerical integration floor plus relative tolerance"))
        end
        push!(metrics, (; table, tree_id=id, day, variable, samples=length(x),
            bias=sum(differences)/length(x), rmse=sqrt(sum(abs2, differences)/length(x)),
            maxabs=maximum(abs, differences), julia_integral=daily_x, fortran_integral=daily_y))
    end
    return (; checks, metrics)
end

function native_checks(run; case)
    t = run.tables
    checked_rows(t.tree, :tree); checked_rows(t.scene, :scene); checked_rows(t.water, :water)
    checks = NamedTuple[]
    add(group, field, metric, limit; kwargs...) = push!(checks, check(case, group, field, metric, limit; kwargs...))
    v(id, variable, step) = value(run.history, id, variable, step)
    for request in run.requests
        rows = [row for (key, row) in run.history if key[1] === request.name]
        length(rows) == run.steps && sort([row.timestep for row in rows]) == collect(1:run.steps) ||
            throw(ArgumentError("Incomplete retained request $(request.name)"))
    end
    for metadata in run.metadata
        metadata.availability_variable == "unmapped" && continue
        gate = Symbol(metadata.availability_variable)
        for step in 1:run.steps
            available = v(metadata.object_id, gate, step)
            available isa Bool || throw(ArgumentError("Availability is not Bool"))
            if gate == :crown_radiation_aggregation_available && !available
                v(:scene, :incident_par_w_m2, step) <= 0 && v(:scene, :incident_nir_w_m2, step) <= 0 &&
                    all(iszero(v(metadata.object_id, field, step)) for field in
                    (:absorbed_par_crown_w, :absorbed_nir_crown_w)) ||
                    throw(ArgumentError("Shortwave unavailable during daylight or not reset to zero"))
            elseif gate != :soil_pre_water_potential_available
                available || throw(ArgumentError("Required scientific output unavailable: $(metadata.object_id)/$gate"))
            end
        end
    end
    for (i, row) in enumerate(t.diagnostics)
        row.source_step == i && row.day == cld(i, 48) && row.step_index == mod1(i, 48) &&
            row.date50 == run.input.config.start_date.days_since_1950 + row.day - 1 ||
            throw(ArgumentError("Native source calendar changed"))
        row.water_available && row.atmosphere_available && row.energy_available ||
            throw(ArgumentError("Accepted water/energy components unavailable"))
    end
    add("water", :initial_soil_storage, abs(first(t.water).soil_storage_pre_mm-run.initial_soil), 1e-9)
    add("water", :initial_canopy_storage, abs(first(t.water).canopy_storage_pre_mm-run.initial_canopy), 1e-9)
    for field in (:soil_water_residual_mm_step, :total_water_residual_mm_step, :native_soil_water_residual_mm_step)
        add("water", field, maximum(abs(getproperty(row, field)) for row in t.water), 1e-4)
    end
    for field in (:soil_state_gap_mm, :canopy_state_gap_mm)
        add("continuity", field, maximum((abs(getproperty(row, field)) for row in t.diagnostics[2:end]); init=0.0), 1e-9)
    end
    for field in (:soil_lower_bound_correction_mm_step, :soil_water_table_exchange_mm_step,
        :soil_imposed_stock_exchange_mm_step, :canopy_correction_mm_step)
        add("water/corrections", field, maximum(abs(getproperty(row, field)) for row in t.diagnostics), 0.0)
    end
    for field in (:root_withdrawal_minus_canopy_T_mm_step, :allocated_soil_E_minus_surface_E_mm_step,
        :stand_wet_E_minus_canopy_evaporation_mm_step)
        add("water/coupling", field, maximum(abs(getproperty(row, field)) for row in t.diagnostics), 1e-9)
    end
    for field in (:native_canopy_residual_mm_step, :native_infiltration_residual_mm_step,
        :canopy_evaporation_residual_mm_step)
        add("water/native", field, maximum(abs(getproperty(row, field)) for row in t.diagnostics), 1e-4)
    end
    add("soil-energy", :residual_W_m2, maximum(abs(row.soil_energy_residual_W_m2) for row in t.scene), 0.1)
    add("soil-energy", :converged, all(row.soil_energy_converged for row in t.diagnostics) ? 0.0 : Inf, 0.0)
    add("soil-energy", :reconstruction, maximum(abs(row.soil_energy_residual_reconstruction_error_W_m2) for row in t.diagnostics), 1e-9)
    for row in t.hydric
        row.psi_pre_available isa Bool || throw(ArgumentError("Soil-potential availability is not Bool"))
        (!row.psi_pre_available || isfinite(row.psi_pre_MPa)) ||
            throw(ArgumentError("Nonfinite available pre-water soil potential"))
        row.root_available && all(isfinite, (row.theta_post_m3_m3, row.root_weighted_psi_MPa,
            row.Emax_mmol_m2_leaf_s, row.limited_leaf_area_fraction)) || throw(ArgumentError("Unavailable/nonfinite hydraulics"))
        0 <= row.limited_leaf_area_fraction <= 1 && row.Emax_mmol_m2_leaf_s > 0 ||
            throw(ArgumentError("Invalid hydraulic limitation"))
    end
    if case in ("equal-physiology", "low-radiation", "dry-air", "dry-soil")
        limited = any(row.limited_leaf_area_fraction > 0 for row in t.hydric)
        add("hydraulics", :native_limitation_branch, limited == (case == "dry-soil") ? 0.0 : Inf, 0.0)
    end
    for row in t.points
        row.active && row.available && all(isfinite, (row.x, row.y, row.z,
            row.A_umol_m2_s, row.E_umol_m2_s, row.Tleaf_C, row.leaf_area_m2)) ||
            throw(ArgumentError("Unavailable/nonfinite simulation point"))
    end
    for row in t.tree
        points = filter(p -> p.step == row.step && p.tree_id == row.tree_id, t.points)
        length(points) == 4 || throw(ArgumentError("Changed point count for this frozen geometry"))
        add("point-aggregation", :A_umol_s, abs(sum(p.A_umol_m2_s*p.leaf_area_m2 for p in points)-row.A_umol_s), 1e-8)
        add("point-aggregation", :E_mmol_s, abs(sum(p.E_umol_m2_s*p.leaf_area_m2 for p in points)/1000-row.E_mmol_s), 1e-8)
    end
    return checks
end
