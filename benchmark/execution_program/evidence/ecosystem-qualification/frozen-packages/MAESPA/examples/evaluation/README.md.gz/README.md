# Offline Fortran-reference evaluation

This directory holds **post-processing examples**, not scientific process
kernels. `evaluate.jl` runs fresh native MAESPA scenarios and reads immutable
raw Fortran outputs from `test/fixtures/evaluation`. It needs no Fortran,
compiler, network or temporary reference checkout. `plots.jl` loads Makie only
when explicitly included. The same evaluator drives integration tests and
the executable Evaluation documentation page.

```julia
include(joinpath(pkgdir(MAESPA), "examples", "evaluation", "evaluate.jl"))
using .MAESPAEvaluation
result = evaluation_suite()
```

`verify_fixtures()` checks all input/output/documentation payload hashes.
Normal tests and documentation never rewrite the reference. A future reference
refresh is a separately reviewed scientific action, not a way to resolve a
failing regression. The differing-physiology case deliberately shows the
unchanged historical species-context bug: deviations remain in its metrics,
but it is not treated as a valid coupled parity oracle. Native Julia identity,
availability, conservation and species-distinction checks still apply.

## Explicit acceptance policy

These are regression accuracy targets, **not empirical confidence intervals**
or rigorous error bounds for every solve. They are fixed in `checks.jl`, not
computed by multiplying the current observed discrepancy.

- Instantaneous fluxes use `atol + 0.001*abs(reference)`, with finite absolute
  floors at night and near zero. Tree assimilation: 0.02 µmol CO₂/tree/s
  (0.005 µmol/m² leaf/s times the prescribed 4 m²). Transpiration: 0.001 mmol
  H₂O/tree/s. Tree energy: 0.05 W/tree. Scene energy: 0.1 W/m² ground.
  Water interval amounts: 0.00001 mm, except instantaneous drainage: 0.0001 mm.
- The drainage exception is an explicitly approved scientific resolution,
  matching the native water-balance residual target, not an error guarantee
  for Fortran arithmetic. Historical drainage subtracts two water-content
  states after an adaptive REAL ODE solve. At θ=0.3 in this 0.5 m layer, one
  Float32 state spacing corresponds to about 0.0000149 mm, already comparable
  to the former common flux floor. The subtraction exposes the quantized
  endpoint states; no fixed number of ULP is claimed to bound the accumulated
  solve error. This resolution was approved after recording the initial five
  strict failures, rather than defined as an observed maximum times a factor.
  Daily drainage keeps its original 0.1% plus integration-floor check, so a
  persistent small bias can still fail. No other water-flux floor is relaxed.
- Mean leaf temperature uses 0.02 °C absolute tolerance, without relative
  scaling of a Celsius temperature. This is the leaf model's documented
  pre-relaxation convergence-tolerance scale, not a requirement to reproduce
  historical iteration counts.
- Soil/canopy storage uses 0.002 mm absolute tolerance. This sub-0.01 mm
  target also accommodates the scale of accumulated historical REAL
  rounding (96×eps(Float32)×150 mm is about 0.00172 mm).
- Daily flux comparisons integrate signed rates with 1800 s and the declared
  unit conversion. They use 0.1% relative tolerance on the signed daily sum,
  plus an explicit per-interval integration floor. H's historical F12.5 kW/tree
  output alone has a half-quantum of 0.005 W/tree; the same coarse numerical
  resolution is deliberately used as the integration floor for the other tree
  energies, not claimed as their own text precision. Scene energies allow
  0.002 W/m² per interval for numerical/solver resolution and composing rounded
  water/energy columns; this is not the precision of a primitive Fortran
  F14.6 energy field (whose half-quantum is 0.0000005 W/m²). Printed
  water amounts allow 0.000001 mm per interval. No temperatures or stocks are
  integrated. Both pointwise and daily checks run, so cancelling errors cannot
  hide a changed diurnal shape.
- Native water residuals use an absolute 0.0001 mm bound, pre/post continuity
  0.000000001 mm. Corrections and imposed/groundwater exchanges must remain
  zero in these specifically configured fixtures. Root uptake and soil
  evaporation allocations are checked against their independently published
  stand/surface amounts.
- Soil energy uses an absolute 0.1 W/m² residual bound, actual component
  availability, and convergence. Scene H is calculated by difference, so
  scene closure is not independent validation.
- Keys, identities, cadence, availability and required finite values are not
  relaxed by a numerical tolerance. Fortran's unreported native water
  residual remains NaN, not an invented zero. The controlled dry-soil case
  must activate the actual hydraulic-limitation mask; the other one-day
  common-physiology contrasts must not. Exact limited-step counts are not
  scientific acceptance criteria.
- Fresh 96-step and fresh 48+`continue!`48 runs on the same build must have
  exactly equal retained histories and an unchanged saved prefix. This tests
  **in-memory** continuation, not disk checkpoint restoration.

The unit checker includes deliberately perturbed fluxes, cancelling daily
errors, missing/duplicate/time-shifted samples, changed identities, units and
nonfinite values. It also verifies rejection of changed or missing frozen
payloads. Passing an unchallenged comparison alone is insufficient evidence
that the evaluator can detect a regression.

## Plotting and CI

In an environment containing Makie and a backend:

```julia
using Makie, CairoMakie
include(joinpath(pkgdir(MAESPA), "examples", "evaluation", "plots.jl"))
MAESPAEvaluationPlots.save_evaluation_figures(result, "evaluation-figures")
```

The docs build runs the numerical suite once, then creates all figures from
that result using named Documenter `@example` blocks. The optional graphical
test in `test/visualization/test-evaluation.jl` verifies generated PNGs and
that rendering did not mutate numerical tables. It does not compare pixels.
Ordinary package tests load neither Makie nor CairoMakie.

The page uses `verify=false` to display any failed numerical checks alongside
the curves, with their unchanged thresholds. This makes diagnostic plots
available even when a regression fails; a successful docs render is not a
scientific acceptance verdict. The ordinary integration test still enforces
every check with `assert_evaluation(result)` and fails on any deviation.
