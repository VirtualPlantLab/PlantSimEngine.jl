# Native spatial-output example. Simulation parameters determine the 48
# sampling locations per Crown; no plotting library or backend is loaded here.
# This artificial scene illustrates the viewer, not spatial convergence or a
# calibrated stand. No Fortran directory or frozen reference data are read.

using MAESPA
using PlantSimEngine

if !isdefined(@__MODULE__, :two_species_parameters)
    include(joinpath(@__DIR__, "two_species.jl"))
end

function _spatial_example_layer_table(table::SpeciesParameterTable, layers::Int)
    size(table.values, 2) == 1 || throw(ArgumentError(
        "this example only expands homogeneous, one-layer physiology"))
    return SpeciesParameterTable(table.dates, repeat(table.values, 1, layers, 1))
end

_spatial_example_layer_table(::Nothing, layers::Int) = nothing

function _spatial_example_physiology(physiology::SpeciesPhysiologyConfig, layers::Int)
    physiology.canopy_layers == 1 || throw(ArgumentError(
        "this example requires the original one-layer homogeneous physiology"))
    optics = physiology.optics
    all(matrix -> size(matrix, 1) == 1,
        (optics.reflectance, optics.transmittance, optics.absorptance)) ||
        throw(ArgumentError("this example only expands homogeneous one-layer optics"))
    expanded_optics = LeafOptics(repeat(optics.reflectance, layers, 1),
        repeat(optics.transmittance, layers, 1),
        repeat(optics.absorptance, layers, 1), optics.soil_reflectance)
    # All dated tables use date × canopy-layer × physiological-age order.
    # Repeating their sole layer preserves the original homogeneous profile,
    # including SLA; fixed/dated stomatal leaf width is not a layer profile.
    return SpeciesPhysiologyConfig(physiology.source, layers,
        physiology.age_classes, expanded_optics, physiology.stomatal,
        physiology.leaf_respiration, physiology.woody_respiration,
        physiology.root_respiration, physiology.branch_respiration,
        physiology.photosynthetic_capacity,
        _spatial_example_layer_table(physiology.jmax, layers),
        _spatial_example_layer_table(physiology.vcmax, layers),
        _spatial_example_layer_table(physiology.rd, layers),
        _spatial_example_layer_table(physiology.sla, layers),
        _spatial_example_layer_table(physiology.ajq, layers))
end

"""Create the native two-species input with a homogeneous resolved crown layout."""
function spatial_viewer_parameters(; T=Float64, nolay::Integer=4, pplay::Integer=12)
    nolay isa Bool && throw(ArgumentError("nolay must not be Bool"))
    nolay > 0 || throw(ArgumentError("nolay must be positive"))
    input = two_species_parameters(T)
    overrides = (canopy_layers=Int(nolay), points_per_layer=Int(pplay))
    config = typeof(input.config)((get(overrides, field, getfield(input.config, field))
        for field in fieldnames(typeof(input.config)))...)
    species = SpeciesSet([SpeciesConfig(original.id, original.name, original.structure,
        _spatial_example_physiology(original.physiology, Int(nolay)))
        for original in input.species])
    return merge(input, (; config, species))
end

"""
    run_spatial_example(; T=Float64, nolay=4, pplay=12, step_index=16,
                        steps=18, type_promotion=nothing)

Run the native two-tree scenario from morning into afternoon and retain its
accepted spatial outputs. Return `(input, model, plan, simulation)`. Load
`Makie` and a backend explicitly before plotting the result, for example:

```julia
using Makie, CairoMakie
example = run_spatial_example()
snapshot = spatial_snapshot(example.simulation, example.plan;
    timestep=9, variable=:leaf_temperature)
view = plot_spatial(snapshot; representation=:cells)
save("leaf-temperature.png", view.figure)
```

`nolay` and `pplay` are scientific parameters. Plotting `resolution` controls
only geometry tessellation and cannot add simulated sampling locations.
"""
function run_spatial_example(; T=Float64, nolay::Integer=4, pplay::Integer=12,
    step_index::Integer=16, steps::Integer=18, type_promotion=nothing)
    input = spatial_viewer_parameters(; T, nolay, pplay)
    model = build_model(input.config, input.scene;
        species_set=input.species, meteorology=input.meteorology, soil=input.soil,
        mount_leaf_exchange=true, step_index, type_promotion)
    plan = spatial_output_plan(model, input)
    simulation = PlantSimEngine.run!(model; steps, outputs=plan.requests)
    return (; input, model, plan, simulation)
end
