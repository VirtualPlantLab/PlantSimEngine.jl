# AGENTS.md

Guidance for AI agents working in the MAESPA.jl repository.

## Overview

MAESPA.jl is a Julia package. Source lives in `src/`, tests in `test/`, and
documentation in `docs/`. `legacy_fortran/` is a local, temporary scientific
reference; production code and permanent tests must not depend on it.

## Julia workflow

Load the global `kaimon-julia` skill before working with Julia code or project
files. Start or connect all Julia processes through Kaimon. Create a project
session when no suitable session exists; do not spawn an unmanaged Julia process.
For model and coupling work, also follow the current `plantsimengine` skill.

Use the project root for development and `/Users/rvezy/Documents/dev/maespa/test`
for the test session. Verify the active project, `Base.pathof(MAESPA)`, and the
loaded PlantSimEngine path/version before attributing a result to this checkout.
Load `TestItemRunner` in that session, then run:

- All tests: `@run_package_tests verbose=false`
- By test name: `@run_package_tests verbose=false filter=ti->contains(ti.name, "some name")`
- By filename: `@run_package_tests verbose=false filter=ti->contains(ti.filename, "some-file")`

## Conventions

- Make `run!` the readable scientific calculation: drivers, named equations,
  output assignments, `return nothing`. Extract helpers for named equations,
  real reuse, or numerical algorithms; avoid mechanical one-line helpers.
- Validate fixed parameters, dimensions, identities, and configuration at the
  constructor/parser/scenario boundary, and revalidate explicit structural
  changes there. Do not repeat those scans in every timestep kernel.
  Dynamic physical branches, necessary activity handling, numerical domain
  protection, and convergence checks belong in the calculation.
- Keep replaceable subprocesses as declared models chosen through `ModelSpec`
  and public calls. Keep scenario selectors and orchestration out of equations.
  Declare scientific contracts beside ports; test actual model substitution.
- Keep values generic. `type_promotion` maps status storage, not model parameters
  or environmental data. Supply those types generically and avoid hard-coded
  `Float32`/`Float64` conversions in equations.
- Preserve historical science with explicit decisions for undefined Fortran
  behavior. Test trends, invariants, units, and daily balances; exact iterations
  and bitwise parity are not acceptance criteria.
- Add meaningful unit/integration regressions for behavior changes. A passing
  kernel or static graph inspection does not prove an executed full scenario.
  Report fresh test evidence separately from historical counts.
- Keep public API changes documented. Preserve unrelated user changes and
  dependency checkouts; do not publish or change remotes without authorization.

## Git workflow

- The user requests regular commits and pushes during authorized implementation
  work. At coherent, proportionately validated milestones, commit the scoped
  changes and push them; do not wait for another reminder or accumulate a large
  uncommitted implementation. This does not authorize writes for read-only
  requests or inclusion of unrelated user changes.
- Publish this Julia package to the private `github` remote,
  `https://github.com/VEZY/MAESPA.jl.git`. The `origin` remote and local `master`
  retain the historical CIRAD Fortran repository; do not push Julia changes
  there. The Julia publication history intentionally has no Fortran ancestors.
- `codex/initial-julia-package` tracks `github/main`. On this branch, use
  `git push github HEAD:main` explicitly because local and upstream branch
  names differ. For other branches, inspect and respect their own upstream.
- Keep `legacy_fortran/`, generated documentation, local manifests and machine
  preferences local. The frozen data under `test/fixtures/evaluation/` are
  permanent, versioned test fixtures; preserve their exact bytes and hashes.
- A routine push is not authorization for force-pushes, upstream merges,
  releases, repository-visibility changes, or licensing changes. Distinguish
  local validation from remote CI results when reporting a published checkpoint.
