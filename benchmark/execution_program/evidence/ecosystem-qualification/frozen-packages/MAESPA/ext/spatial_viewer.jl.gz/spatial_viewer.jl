# Rendering consumes retained scientific samples. No layout, physiological
# classes or interpolated samples are manufactured by this extension.
function _spatial_cell_mesh(tree, cell, resolution)
    azimuthal, vertical = _render_resolution(resolution)
    points = GB.Point3d[]
    faces = GB.TriangleFace{Int}[]
    indices = Dict{NTuple{3,Float64},Int}()
    function vertex(point)
        xyz = Tuple(Float64.(point))
        return get!(indices, xyz) do
            push!(points, GB.Point3d(xyz))
            length(points)
        end
    end
    function triangle(a, b, c; reverse=false)
        ia, ib, ic = vertex(a), vertex(b), vertex(c)
        length(Set((ia, ib, ic))) == 3 || return
        u, v = points[ib] - points[ia], points[ic] - points[ia]
        area2 = (u[2]*v[3]-u[3]*v[2])^2 + (u[3]*v[1]-u[1]*v[3])^2 +
            (u[1]*v[2]-u[2]*v[1])^2
        iszero(area2) && return
        push!(faces, reverse ? GB.TriangleFace(ia, ic, ib) : GB.TriangleFace(ia, ib, ic))
        return nothing
    end
    function quad(a, b, c, d; reverse=false)
        triangle(a, b, c; reverse)
        triangle(a, c, d; reverse)
        return nothing
    end
    x, y, z = tree.position
    base = z + tree.crown_base_height
    h0, h1 = cell.normalized_height_bounds
    if !isnothing(cell.cross_section)
        # Earcut handles the genuine concave BOX L-polygons. A fan or convex
        # hull would incorrectly fill the omitted inner square annulus.
        section = GB.triangle_mesh(GB.Polygon(GB.Point2d.(collect(cell.cross_section))))
        section_points = GB.coordinates(section)
        box_point = (p, h) -> GB.Point3d(x + tree.radius_x*p[1], y + tree.radius_y*p[2],
            base + tree.crown_depth*h)
        for face in GB.faces(section)
            # GeometryBasics faces may carry offset indices. Array indexing
            # applies their public to_index conversion; Int(i) is not defined.
            a, b, c = (section_points[i] for i in face)
            clockwise = (b[1]-a[1])*(c[2]-a[2]) - (b[2]-a[2])*(c[1]-a[1]) < 0
            triangle(box_point(a, h0), box_point(b, h0), box_point(c, h0); reverse=!clockwise)
            triangle(box_point(a, h1), box_point(b, h1), box_point(c, h1); reverse=clockwise)
        end
        polygon = cell.cross_section
        for i in eachindex(polygon)
            a, b = polygon[i], polygon[mod1(i + 1, length(polygon))]
            quad(box_point(a, h0), box_point(b, h0), box_point(b, h1), box_point(a, h1))
        end
    else
        r0, r1 = cell.radial_bounds
        θ0, θ1 = cell.angular_bounds
        nθ = max(1, ceil(Int, azimuthal * Float64(θ1 - θ0) / (2π)))
        nh = max(1, ceil(Int, vertical * Float64(h1 - h0)))
        # Include the actual representative direction and layer midpoint in
        # the boundary tessellation. Otherwise a coarse outer chord could
        # visually exclude a high-PPQ point from its exact curved cell.
        sample_angle = if isodd(cell.geometric_layer)
            (θ0 + θ1) / 2
        else
            α = typeof(θ0)(atan(tree.radius_x, tree.radius_y))
            (α, typeof(θ0)(π)-α, typeof(θ0)(π)+α, typeof(θ0)(2π)-α)[cell.quadrant]
        end
        angles = sort!(unique!([collect(range(θ0, θ1; length=nθ+1)); sample_angle]))
        heights = sort!(unique!([collect(range(h0, h1; length=nh+1)); (h0+h1)/2]))
        nθ, nh = length(angles)-1, length(heights)-1
        round_point = function(r, θ, h)
            factor = MAESPA.crown_surface_factor(h, tree.crown_shape.legacy_code)
            return GB.Point3d(x + tree.radius_x*factor*r*cos(θ),
                y + tree.radius_y*factor*r*sin(θ), base + tree.crown_depth*h)
        end
        for j in 1:nθ
            a, b = angles[j], angles[j+1]
            quad(round_point(r0,a,h0), round_point(r1,a,h0), round_point(r1,b,h0), round_point(r0,b,h0); reverse=true)
            quad(round_point(r0,a,h1), round_point(r1,a,h1), round_point(r1,b,h1), round_point(r0,b,h1))
            for k in 1:nh
                lo, hi = heights[k], heights[k+1]
                quad(round_point(r1,a,lo), round_point(r1,b,lo), round_point(r1,b,hi), round_point(r1,a,hi))
                quad(round_point(r0,a,lo), round_point(r0,b,lo), round_point(r0,b,hi), round_point(r0,a,hi); reverse=true)
            end
        end
        for k in 1:nh
            lo, hi = heights[k], heights[k+1]
            quad(round_point(r0,θ0,lo), round_point(r1,θ0,lo), round_point(r1,θ0,hi), round_point(r0,θ0,hi))
            quad(round_point(r0,θ1,lo), round_point(r1,θ1,lo), round_point(r1,θ1,hi), round_point(r0,θ1,hi); reverse=true)
        end
    end
    return GB.Mesh(points, faces)
end

function _spatial_colorrange(snapshot, requested=nothing)
    if !isnothing(requested)
        length(requested) == 2 && all(x -> x isa Real && isfinite(x), requested) &&
            requested[1] < requested[2] ||
            throw(ArgumentError("colorrange must contain two finite increasing numbers"))
        return (Float64(requested[1]), Float64(requested[2]))
    end
    values = [Float64(point.value) for point in snapshot.points
        if point.available && !ismissing(point.value) && isfinite(point.value)]
    return _spatial_extrema_range(values)
end

function _spatial_extrema_range(values)
    isempty(values) && return (0.0, 1.0)
    lo, hi = extrema(values)
    if lo == hi
        margin = max(abs(lo) * 0.01, 0.01)
        return (lo - margin, hi + margin)
    end
    return (lo, hi)
end

function _spatial_label(snapshot)
    metadata = getproperty(MAESPA.spatial_output_variables(), snapshot.variable)
    return "$(metadata.label) ($(snapshot.unit))"
end

function _spatial_title(snapshot)
    n = count(point -> point.available, snapshot.points)
    time = ismissing(snapshot.time.datetime) ? "step $(snapshot.time.timestep)" : string(snapshot.time.datetime)
    return "$(_spatial_label(snapshot))\n$time · source step $(snapshot.time.step_index) · $n/$(length(snapshot.points)) available points"
end

function _spatial_inspector_label(point, unit)
    value = point.available && !ismissing(point.value) ? "$(point.value) $unit" :
        "unavailable ($(point.availability_reason))"
    return "Tree $(point.tree_id) · $(point.species_name) [$(point.species_id)]\n" *
        "Point $(point.point_index) · layer $(point.physiological_layer)\n" *
        "$(point.position) m\n$value\n" *
        "Leaf area $(point.available_area_m2)/$(point.leaf_area_m2) m² available\n" *
        "$(point.logical_class_count) logical leaf classes · $(point.representative_volume_m3) m³"
end

function _scene_handles(plots)
    isnothing(plots) && return Any[]
    return Any[plots.ground, plots.boundary, values(plots.crowns)...,
        values(plots.stems)..., values(plots.labels)...]
end

function MAESPA.plot_spatial!(axis::Makie.Axis3, snapshot::MAESPA.SpatialSnapshot;
    representation::Symbol=:points, colorrange=nothing, colormap=:viridis,
    missing_color=:gray65, markersize=10, resolution=(32, 16),
    show_scene::Bool=true, scene::NamedTuple=(;), cell_alpha=0.85,
)
    representation in (:points, :cells) ||
        throw(ArgumentError("representation must be :points or :cells"))
    _render_resolution(resolution)
    markersize isa Real && isfinite(markersize) && markersize > 0 ||
        throw(ArgumentError("markersize must be finite and positive"))
    cell_alpha isa Real && isfinite(cell_alpha) && 0 <= cell_alpha <= 1 ||
        throw(ArgumentError("cell_alpha must lie in [0, 1]"))
    limits = _spatial_colorrange(snapshot, colorrange)
    available_indices = findall(point -> point.available && !ismissing(point.value) &&
        isfinite(point.value), snapshot.points)
    missing_indices = setdiff(eachindex(snapshot.points), available_indices)
    if representation == :cells
        all(point -> !isnothing(point.cell), snapshot.points) ||
            throw(ArgumentError("cell geometry is unavailable for some points; use representation=:points"))
    end

    scene_plots = show_scene ? MAESPA.plot_scene!(axis, snapshot.scene;
        merge((resolution=resolution, crown_alpha=0.08, show_stems=true), scene)...) : nothing
    owned = _scene_handles(scene_plots)
    available = Any[]
    unavailable = Any[]
    if representation == :points
        # Keep the two subsets separate: missing data never enter a colour map.
        for (indices, destination, present) in ((available_indices, available, true),
                                                   (missing_indices, unavailable, false))
            isempty(indices) && continue
            records = snapshot.points[indices]
            positions = [GB.Point3d(point.position) for point in records]
            label = (plot, index, position) -> _spatial_inspector_label(records[index], snapshot.unit)
            handle = if present
                Makie.scatter!(axis, positions; color=[Float64(point.value) for point in records],
                    colormap, colorrange=limits, markersize, inspector_label=label)
            else
                Makie.scatter!(axis, positions; color=missing_color, markersize,
                    marker=:xcross, inspector_label=label)
            end
            push!(destination, handle)
            push!(owned, handle)
        end
    else
        trees = Dict(tree.id => tree for tree in snapshot.scene.trees)
        for (indices, destination, present) in ((available_indices, available, true),
                                                   (missing_indices, unavailable, false))
            for index in indices
                point = snapshot.points[index]
                mesh = _spatial_cell_mesh(trees[point.tree_id], point.cell, resolution)
                label = (plot, index, position) -> _spatial_inspector_label(point, snapshot.unit)
                handle = if present
                    Makie.mesh!(axis, mesh; color=fill(Float64(point.value), length(GB.coordinates(mesh))),
                        colormap, colorrange=limits, alpha=cell_alpha,
                        transparency=cell_alpha < 1, inspector_label=label)
                else
                    Makie.mesh!(axis, mesh; color=(missing_color, cell_alpha),
                        transparency=cell_alpha < 1, inspector_label=label)
                end
                push!(destination, handle)
                push!(owned, handle)
            end
        end
    end
    return (; available, unavailable, scene=scene_plots, owned, available_indices,
        missing_indices, records=snapshot.points, sources=snapshot.sources,
        colorrange=limits, representation)
end

function MAESPA.plot_spatial(snapshot::MAESPA.SpatialSnapshot;
    figure::NamedTuple=(;), axis::NamedTuple=(;), colorbar::Bool=true,
    inspector::Bool=true, kwargs...)
    fig = Makie.Figure(; merge((size=(1100, 750),), figure)...)
    ax = Makie.Axis3(fig[1, 1]; merge((xlabel="x (m)", ylabel="y (m)", zlabel="z (m)",
        aspect=:data, protrusions=60, title=_spatial_title(snapshot)), axis)...)
    plots = MAESPA.plot_spatial!(ax, snapshot; kwargs...)
    bar = colorbar ? Makie.Colorbar(fig[1, 2]; colormap=get(kwargs, :colormap, :viridis),
        limits=plots.colorrange, label=_spatial_label(snapshot)) : nothing
    inspection = inspector ? Makie.DataInspector(fig) : nothing
    return (; figure=fig, axis=ax, plots, colorbar=bar, inspector=inspection)
end

function _spatial_series_range(snapshots)
    lo, hi = Inf, -Inf
    for snapshot in snapshots
        for point in snapshot.points
            if point.available && !ismissing(point.value) && isfinite(point.value)
                value = Float64(point.value)
                lo, hi = min(lo, value), max(hi, value)
            end
        end
    end
    return lo == Inf ? (0.0, 1.0) : _spatial_extrema_range((lo, hi))
end

function MAESPA.spatial_viewer(simulation, plan; timestep=nothing,
    variable::Symbol=:assimilation, representation::Symbol=:points,
    controls::Bool=true, figure::NamedTuple=(;), axis::NamedTuple=(;),
    colorrange=nothing, inspector::Bool=true, colorbar::Bool=true, kwargs...)
    times = MAESPA.spatial_times(simulation, plan)
    isempty(times) && throw(ArgumentError("no retained spatial timesteps are available"))
    variables = MAESPA.spatial_output_variables()
    haskey(variables, variable) || throw(ArgumentError("unknown spatial variable $variable"))
    initial = MAESPA.spatial_snapshot(simulation, plan; timestep, variable)
    index = findfirst(time -> time.timestep == initial.time.timestep, times)
    isnothing(index) && throw(ArgumentError("selected timestep is absent from spatial_times"))
    selected_time = Makie.Observable{NamedTuple}(times[index])
    selected_variable = Makie.Observable(variable)
    snapshot = Makie.Observable{MAESPA.SpatialSnapshot}(initial)
    ranges = Dict{Symbol,Tuple{Float64,Float64}}()
    series = Dict{Symbol,Any}()
    samples = Dict{Tuple{Int,Symbol},MAESPA.SpatialSnapshot}((initial.time.timestep, variable) => initial)
    function series_for(var)
        return get!(series, var) do
            retained = MAESPA.spatial_snapshots(simulation, plan; variable=var)
            for sample in retained
                samples[(sample.time.timestep, var)] = sample
            end
            retained
        end
    end
    range_for(var) = get!(ranges, var) do
        isnothing(colorrange) ? _spatial_series_range(series_for(var)) :
            _spatial_colorrange(initial, colorrange)
    end
    sample_for(time, var) = get!(samples, (time.timestep, var)) do
        MAESPA.spatial_snapshot(simulation, plan; timestep=time.timestep, variable=var)
    end
    initial_plot = MAESPA.plot_spatial(initial; figure, axis, inspector, colorbar,
        representation, colorrange=range_for(variable), kwargs...)
    fig, ax = initial_plot.figure, initial_plot.axis
    plots = Makie.Observable{NamedTuple}(initial_plot.plots)
    bar = initial_plot.colorbar
    widgets = nothing
    if controls
        layout = Makie.GridLayout(fig[2, 1:2])
        # Makie's Slider requires at least two range entries. A one-step
        # simulation has a useful label and variable menu, but no fake time.
        slider = length(times) > 1 ? Makie.Slider(layout[1, 1]; range=1:length(times), startvalue=index) : nothing
        menu = Makie.Menu(layout[1, 2]; options=[(metadata.label, name) for (name, metadata) in pairs(variables)],
            default=findfirst(==(variable), collect(keys(variables))))
        label = Makie.Label(layout[2, 1:2], _spatial_title(initial))
        widgets = (; layout, slider, variable=menu, label)
    end

    function refresh!()
        var = selected_variable[]
        haskey(variables, var) || throw(ArgumentError("unknown spatial variable $var"))
        time = selected_time[]
        chosen_index = findfirst(candidate -> isequal(candidate, time), times)
        isnothing(chosen_index) && throw(ArgumentError("selected_time must be a record from this viewer's times"))
        limits = range_for(var)
        next = sample_for(time, var)
        # Remove only plots owned by this viewer. Caller overlays, axis limits,
        # aspect, azimuth and elevation are not reset when selecting a sample.
        for handle in plots[].owned
            Makie.delete!(ax, handle)
        end
        plots[] = MAESPA.plot_spatial!(ax, next; representation,
            colorrange=limits, kwargs...)
        snapshot[] = next
        ax.title[] = _spatial_title(next)
        if !isnothing(bar)
            bar.limits[] = limits
            bar.label[] = _spatial_label(next)
        end
        if !isnothing(widgets)
            widgets.label.text[] = _spatial_title(next)
            if !isnothing(widgets.slider) && widgets.slider.value[] != chosen_index
                Makie.set_close_to!(widgets.slider, chosen_index)
            end
            desired_menu_index = findfirst(==(var), collect(keys(variables)))
            widgets.variable.i_selected[] == desired_menu_index ||
                (widgets.variable.i_selected[] = desired_menu_index)
        end
        return next
    end
    Makie.on(selected_time) do _
        refresh!()
    end
    Makie.on(selected_variable) do _
        refresh!()
    end
    if !isnothing(widgets)
        if !isnothing(widgets.slider)
            Makie.on(widgets.slider.value) do value
                time = times[Int(value)]
                isequal(selected_time[], time) || (selected_time[] = time)
            end
        end
        Makie.on(widgets.variable.selection) do value
            selected_variable[] == value || (selected_variable[] = value)
        end
    end
    return (; figure=fig, axis=ax, snapshot, selected_time, selected_variable,
        times, controls=widgets, plots, colorbar=bar, inspector=initial_plot.inspector,
        colorranges=ranges, cached_series=series, cached_samples=samples, refresh!)
end
