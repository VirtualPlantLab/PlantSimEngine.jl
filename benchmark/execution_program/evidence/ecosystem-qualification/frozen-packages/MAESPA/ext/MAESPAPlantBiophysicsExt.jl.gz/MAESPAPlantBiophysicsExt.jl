module MAESPAPlantBiophysicsExt

using MAESPA
import PlantBiophysics as PB
import PlantMeteo
import PlantSimEngine as PSE

struct PlantBiophysicsLeafComposition{F,M}
    fvcb::F
    medlyn::M
    leaf_deficit::Symbol
end

function MAESPA.plantbiophysics_leaf_composition(fvcb::PB.Fvcb, medlyn::PB.Medlyn;
    leaf_deficit)
    leaf_deficit isa Symbol && leaf_deficit in (:leaf_to_air, :ambient_vpd) ||
        throw(ArgumentError("leaf_deficit must be explicitly :leaf_to_air or :ambient_vpd"))
    for model in (fvcb, medlyn)
        all(name -> begin
            value = getfield(model, name)
            value isa Real && !(value isa Bool) && isfinite(value)
        end, fieldnames(typeof(model))) ||
            throw(ArgumentError("PlantBiophysics model parameters must be finite real scalars, not Bool"))
        PSE.Authoring.validate_model(model).valid ||
            throw(ArgumentError("PlantBiophysics model has an invalid declared boundary"))
    end
    fvcb.Tᵣ > PlantMeteo.Constants().K₀ ||
        throw(DomainError(fvcb.Tᵣ, "Fvcb reference temperature must exceed absolute zero"))
    medlyn.gs_min >= zero(medlyn.gs_min) ||
        throw(DomainError(medlyn.gs_min, "Medlyn minimum conductance must be non-negative"))
    return PlantBiophysicsLeafComposition(fvcb, medlyn, leaf_deficit)
end

# The graph is deliberately reconfigured, not a relaxed leaf_models override.
# Fixed PB parameters do not consume MAESPA's dated biochemical input tables.
struct PlantBiophysicsLeafPhotosynthesis{T} <:
    MAESPA.AbstractStomatal_Photosynthesis_CouplingModel
    water_to_co2_conductance_ratio::T
    leaf_deficit::Symbol
end

PSE.inputs_(::PlantBiophysicsLeafPhotosynthesis) = (
    leaf_temperature_c=PSE.Required(Real),
    absorbed_par_umol_m2_s=PSE.Required(Real),
    surface_co2_umol_mol=PSE.Required(Real),
    astronomical_daylight=PSE.Required(Bool),
    leaf_radiative_forcing_available=PSE.Required(Bool),
    photosynthetic_capacity_inputs_available=PSE.Required(Bool),
    emax_non_tuzet_constraint_active=PSE.Default(false),
    second_stomatal_curve=PSE.Default(false),
)

PSE.outputs_(model::PlantBiophysicsLeafPhotosynthesis) = (
    net_assimilation_umol_co2_m2_s=zero(model.water_to_co2_conductance_ratio),
    intercellular_co2_umol_mol=zero(model.water_to_co2_conductance_ratio),
    stomatal_conductance_co2_mol_m2_s=zero(model.water_to_co2_conductance_ratio),
    stomatal_conductance_h2o_mol_m2_s=zero(model.water_to_co2_conductance_ratio),
    rd_umol_m2_s=zero(model.water_to_co2_conductance_ratio),
    hydraulic_limitation_applied=false,
    stomatal_photosynthesis_coupling_available=false,
)

function PSE.environment_inputs_(model::PlantBiophysicsLeafPhotosynthesis)
    z = zero(model.water_to_co2_conductance_ratio)
    return model.leaf_deficit === :leaf_to_air ?
        (air_temperature_c=z, relative_humidity=z) : (vapour_pressure_deficit_pa=z,)
end
PSE.environment_outputs_(::PlantBiophysicsLeafPhotosynthesis) = NamedTuple()
PSE.dep(::PlantBiophysicsLeafPhotosynthesis) = (
    plantbiophysics=PSE.Call(PSE.One(within=PSE.Self(), process=:photosynthesis)),
)

function PSE.variable_contracts_(model::PlantBiophysicsLeafPhotosynthesis)
    state(unit, basis) = PSE.VariableContract(;
        unit, basis, temporal=:instantaneous, aggregation=:state, extent=:intensive)
    rate(unit, basis) = PSE.VariableContract(;
        unit, basis, temporal=:second, aggregation=:local, extent=:intensive)
    air = model.leaf_deficit === :leaf_to_air ? (
        air_temperature_c=state(:degree_celsius, :air),
        relative_humidity=state(:fraction, :air),
    ) : (vapour_pressure_deficit_pa=state(:pascal, :air),)
    return merge((
        leaf_temperature_c=state(:degree_celsius, :leaf),
        absorbed_par_umol_m2_s=PSE.VariableContract(unit=:micromol_photon,
            basis=:surface_area, temporal=:second, aggregation=:rate, extent=:intensive),
        surface_co2_umol_mol=state(:micromole_per_mole, :leaf_surface_air),
        astronomical_daylight=state(:boolean, :scene),
        leaf_radiative_forcing_available=state(:boolean, :leaf),
        photosynthetic_capacity_inputs_available=state(:boolean, :leaf),
        emax_non_tuzet_constraint_active=state(:boolean, :leaf),
        second_stomatal_curve=state(:boolean, :leaf),
        net_assimilation_umol_co2_m2_s=rate(:micromole_co2, :leaf_area),
        intercellular_co2_umol_mol=state(:micromole_per_mole, :intercellular_air),
        stomatal_conductance_co2_mol_m2_s=rate(:mole_co2, :leaf_area),
        stomatal_conductance_h2o_mol_m2_s=rate(:mole_h2o, :leaf_area),
        rd_umol_m2_s=rate(:micromole_co2, :leaf_area),
        hydraulic_limitation_applied=state(:boolean, :leaf),
        stomatal_photosynthesis_coupling_available=state(:boolean, :leaf),
    ), air)
end

function (factory::PlantBiophysicsLeafComposition)(context)
    controller = context.controller
    controller isa MAESPA.MAESPANonTuzetCrownLeafExchangeController ||
        throw(ArgumentError("the PlantBiophysics hybrid supports only non-Tuzet Crown controllers"))
    ratio = controller.stomatal_model.water_to_co2_conductance_ratio
    adapter = PlantBiophysicsLeafPhotosynthesis(ratio, factory.leaf_deficit)
    energy = MAESPA.MAESPACoupledLeafEnergyBalance(controller)
    adapter_name = Symbol("logical_leaf_stomatal_coupling_", context.tree_id)
    fvcb_name = Symbol("plantbiophysics_fvcb_", context.tree_id)
    medlyn_name = Symbol("plantbiophysics_medlyn_", context.tree_id)
    T = typeof(ratio)
    return (applications=(
        PSE.ModelSpec(energy; name=context.energy_application, on=context.on,
            environment=context.environment, output_routing=MAESPA._stream_only_outputs(energy),
            calls=(photosynthesis=PSE.One(within=PSE.Self(), application=adapter_name),)),
        PSE.ModelSpec(adapter; name=adapter_name, on=context.on,
            environment=context.environment, output_routing=MAESPA._stream_only_outputs(adapter),
            calls=(plantbiophysics=PSE.One(within=PSE.Self(), application=fvcb_name),)),
        # PB's Fvcb and Medlyn intentionally share canonical A/Gₛ/Cᵢ fields.
        # In particular, do not make Medlyn's Gₛ application-local.
        PSE.ModelSpec(factory.fvcb; name=fvcb_name, on=context.on,
            environment=context.environment,
            calls=(stomatal_conductance=PSE.One(within=PSE.Self(), application=medlyn_name),)),
        PSE.ModelSpec(factory.medlyn; name=medlyn_name, on=context.on,
            environment=context.environment),
    ), scratch_seeds=(aPPFD=zero(T), Tₗ=zero(T), Cₛ=one(T), Dₗ=zero(T)))
end

function PSE.run!(model::PlantBiophysicsLeafPhotosynthesis, status, environment,
    constants, context)
    T = typeof(status.rd_umol_m2_s)
    status.net_assimilation_umol_co2_m2_s = zero(T)
    status.intercellular_co2_umol_mol = zero(T)
    status.stomatal_conductance_co2_mol_m2_s = zero(T)
    status.stomatal_conductance_h2o_mol_m2_s = zero(T)
    status.rd_umol_m2_s = zero(T)
    status.hydraulic_limitation_applied = false
    status.stomatal_photosynthesis_coupling_available = false
    status.astronomical_daylight && status.leaf_radiative_forcing_available &&
        status.photosynthetic_capacity_inputs_available || return nothing
    status.emax_non_tuzet_constraint_active &&
        throw(ArgumentError("the PlantBiophysics hybrid does not implement non-Tuzet Emax"))
    status.second_stomatal_curve &&
        throw(ArgumentError("the PlantBiophysics hybrid does not implement a second stomatal curve"))

    temperature = T(status.leaf_temperature_c)
    photons = T(status.absorbed_par_umol_m2_s)
    surface_co2 = T(status.surface_co2_umol_mol)
    all(isfinite, (temperature, photons, surface_co2)) &&
        temperature > T(constants.K₀) && photons >= zero(T) && surface_co2 > zero(T) ||
        throw(DomainError((temperature, photons, surface_co2), "invalid PB leaf temperature/PAR/surface CO₂ drivers"))
    deficit = if model.leaf_deficit === :leaf_to_air
        air_temperature = T(environment.air_temperature_c)
        humidity = T(environment.relative_humidity)
        isfinite(air_temperature) && air_temperature > T(constants.K₀) &&
            isfinite(humidity) && zero(T) <= humidity <= one(T) ||
            throw(DomainError((air_temperature, humidity), "invalid ambient temperature or relative humidity"))
        T(PlantMeteo.e_sat(temperature) - PlantMeteo.e_sat(air_temperature) * humidity)
    else
        T(environment.vapour_pressure_deficit_pa) / T(1000)
    end
    isfinite(deficit) || throw(DomainError(deficit, "PB leaf deficit must be finite"))

    target = only(PSE.call_targets(context, :plantbiophysics))
    target.status.aPPFD = photons
    target.status.Tₗ = temperature
    target.status.Cₛ = surface_co2
    target.status.Dₗ = deficit # kPa, including negative leaf-to-air deficits.
    PSE.run_call!(target; publish=true)
    fvcb = PSE.call_model(context, :plantbiophysics)
    respiration = PB.arrhenius(fvcb.RdRef, fvcb.Eₐᵣ,
        target.status.Tₗ - constants.K₀, fvcb.Tᵣ - constants.K₀, constants.R)
    assimilation, conductance, ci, rd = T(target.status.A), T(target.status.Gₛ),
        T(target.status.Cᵢ), T(respiration)
    water_conductance = conductance * T(model.water_to_co2_conductance_ratio)
    all(isfinite, (assimilation, conductance, water_conductance, ci, rd)) ||
        throw(DomainError((assimilation, conductance, water_conductance, ci, rd), "PB exchange results must be finite"))
    status.net_assimilation_umol_co2_m2_s = assimilation
    status.intercellular_co2_umol_mol = ci
    status.stomatal_conductance_co2_mol_m2_s = conductance
    status.stomatal_conductance_h2o_mol_m2_s = water_conductance
    status.rd_umol_m2_s = rd
    status.stomatal_photosynthesis_coupling_available = true
    return nothing
end

PSE.Authoring.model_metadata(::PlantBiophysicsLeafPhotosynthesis) = (
    hypothesis="Fixed PB Fvcb/Medlyn daylight physiology within unchanged MAESPA energy/night/wet equations.",
    reference="Selected PlantBiophysics Fvcb and Medlyn implementations; explicit deficit policy.",
    maturity=:experimental_hybrid,
    validation=:unqualified_optional_prototype,
)

include("plantbiophysics_tuzet.jl")

end
