module MAESPAMakieExt

using MAESPA
import Makie

const GB = Makie.GeometryBasics
const SPECIES_PALETTE = (:seagreen3, :dodgerblue3, :darkorange2, :orchid3,
    :goldenrod2, :slateblue3, :brown3, :teal)

function _render_resolution(resolution)
    length(resolution) == 2 || throw(ArgumentError("resolution must contain azimuthal and vertical segment counts"))
    all(x -> x isa Integer && !(x isa Bool), resolution) ||
        throw(ArgumentError("rendering segment counts must be integers, not Bool"))
    azimuthal, vertical = Int.(resolution)
    azimuthal >= 4 && vertical >= 2 ||
        throw(ArgumentError("rendering requires at least 4 azimuthal and 2 vertical segments"))
    return azimuthal, vertical
end

_species_color(id, ::Nothing) = SPECIES_PALETTE[mod1(id, length(SPECIES_PALETTE))]
_species_color(id, colors) = colors[id]

# Closed surface of an elliptical-section crown. End poles use single vertices,
# not collapsed rings: this avoids zero-area triangles and undefined normals.
# The radius profile is the same public SURFACE equation used by the science.
function _round_mesh(position::NTuple{3,T}, radius_x::T, radius_y::T,
                     depth::T, shape_code::Int, azimuthal::Int, vertical::Int) where {T}
    points = GB.Point{3,T}[]
    faces = GB.TriangleFace{Int}[]
    rings = Vector{Vector{Int}}()
    for k in 0:vertical
        relative_height = T(k) / T(vertical)
        factor = MAESPA.crown_surface_factor(relative_height, shape_code)
        z = position[3] + depth * relative_height
        if iszero(factor)
            push!(points, GB.Point{3,T}(position[1], position[2], z))
            push!(rings, [length(points)])
        else
            ring = Int[]
            for j in 0:(azimuthal - 1)
                angle = T(2) * T(π) * T(j) / T(azimuthal)
                push!(points, GB.Point{3,T}(position[1] + radius_x * factor * cos(angle),
                    position[2] + radius_y * factor * sin(angle), z))
                push!(ring, length(points))
            end
            push!(rings, ring)
        end
    end
    for k in 1:vertical
        lower, upper = rings[k], rings[k+1]
        for j in 1:azimuthal
            next = mod1(j + 1, azimuthal)
            if length(lower) == 1
                push!(faces, GB.TriangleFace(lower[1], upper[next], upper[j]))
            elseif length(upper) == 1
                push!(faces, GB.TriangleFace(lower[j], lower[next], upper[1]))
            else
                push!(faces, GB.TriangleFace(lower[j], lower[next], upper[next]))
                push!(faces, GB.TriangleFace(lower[j], upper[next], upper[j]))
            end
        end
    end
    for (ring, z, bottom) in ((first(rings), position[3], true),
                             (last(rings), position[3] + depth, false))
        length(ring) == 1 && continue
        push!(points, GB.Point{3,T}(position[1], position[2], z))
        center = length(points)
        for j in 1:azimuthal
            next = mod1(j + 1, azimuthal)
            face = bottom ? (center, ring[next], ring[j]) : (center, ring[j], ring[next])
            push!(faces, GB.TriangleFace(face))
        end
    end
    return GB.Mesh(points, faces)
end

function _crown_mesh(tree::MAESPA.TreeSnapshot{T}, azimuthal::Int, vertical::Int) where {T}
    x, y, ground_z = tree.position
    base_z = ground_z + tree.crown_base_height
    if tree.crown_shape.legacy_code != 6
        return _round_mesh((x, y, base_z), tree.radius_x, tree.radius_y,
            tree.crown_depth, tree.crown_shape.legacy_code, azimuthal, vertical)
    end
    # BOX is a rectangular prism, not a cylinder with the same two radii.
    rx, ry = tree.radius_x, tree.radius_y
    corners = ((x-rx, y-ry), (x+rx, y-ry), (x+rx, y+ry), (x-rx, y+ry))
    points = [GB.Point{3,T}(cx, cy, z) for z in (base_z, base_z+tree.crown_depth) for (cx, cy) in corners]
    faces = GB.TriangleFace{Int}.([(1,3,2), (1,4,3), (5,6,7), (5,7,8),
        (1,2,6), (1,6,5), (2,3,7), (2,7,6), (3,4,8), (3,8,7), (4,1,5), (4,5,8)])
    return GB.Mesh(points, faces)
end

function MAESPA.plot_scene!(axis::Makie.Axis3, snapshot::MAESPA.SceneSnapshot{T};
    resolution=(32, 16), species_colors=nothing, crown_alpha=0.75,
    show_stems::Bool=true, show_ids::Bool=false, ground_color=:wheat,
    boundary_color=:gray35, stem_color=:sienna4,
) where {T}
    azimuthal, vertical = _render_resolution(resolution)
    crown_alpha isa Real && isfinite(crown_alpha) && 0 <= crown_alpha <= 1 ||
        throw(ArgumentError("crown_alpha must lie in [0, 1]"))
    # Resolve user colours before mutating the axis, with a useful missing-ID error.
    colors = Dict(id => _species_color(id, species_colors) for id in unique(t.species_id for t in snapshot.trees))
    corners = GB.Point{3,T}.(snapshot.ground_corners)
    ground = Makie.mesh!(axis, GB.Mesh(collect(corners), GB.TriangleFace{Int}.([(1,2,3), (1,3,4)]));
        color=ground_color)
    boundary = Makie.lines!(axis, [corners..., first(corners)]; color=boundary_color, linewidth=1.5)
    crowns = Dict{Int,Any}()
    stems = Dict{Int,Any}()
    labels = Dict{Int,Any}()
    for tree in snapshot.trees
        if tree.radius_x > 0 && tree.radius_y > 0 && tree.crown_depth > 0
            crowns[tree.id] = Makie.mesh!(axis, _crown_mesh(tree, azimuthal, vertical);
                color=(colors[tree.species_id], crown_alpha))
        end
        if show_stems && !isnothing(tree.stem_diameter) && tree.stem_diameter > 0 && tree.crown_base_height > 0
            radius = tree.stem_diameter / T(2)
            stems[tree.id] = Makie.mesh!(axis,
                _round_mesh(tree.position, radius, radius, tree.crown_base_height, 5, azimuthal, 1);
                color=stem_color)
        end
        if show_ids
            x, y, z = tree.position
            top = GB.Point{3,T}(x, y, z + tree.crown_base_height + tree.crown_depth)
            labels[tree.id] = Makie.text!(axis, [top]; text=[string(tree.id)],
                align=(:center, :bottom), offset=(0, 3), color=:black, fontsize=12)
        end
    end
    return (; ground, boundary, crowns, stems, labels)
end

function MAESPA.plot_scene(snapshot::MAESPA.SceneSnapshot;
    figure::NamedTuple=(;), axis::NamedTuple=(;), legend::Bool=true, kwargs...)
    fig = Makie.Figure(; merge((size=(950, 650),), figure)...)
    ax = Makie.Axis3(fig[1, 1]; merge((xlabel="x (m)", ylabel="y (m)", zlabel="z (m)",
        aspect=:data, title="MAESPA scene · day $(snapshot.date50)"), axis)...)
    plots = MAESPA.plot_scene!(ax, snapshot; kwargs...)
    if legend && !isempty(snapshot.trees)
        species_ids = sort!(unique(t.species_id for t in snapshot.trees))
        colors = get(kwargs, :species_colors, nothing)
        elements = [Makie.PolyElement(color=_species_color(id, colors)) for id in species_ids]
        names = [only(unique(t.species_name for t in snapshot.trees if t.species_id == id)) for id in species_ids]
        Makie.Legend(fig[1, 2], elements, names, "Species")
    end
    return (figure=fig, axis=ax, plots=plots)
end

include("spatial_viewer.jl")

end
