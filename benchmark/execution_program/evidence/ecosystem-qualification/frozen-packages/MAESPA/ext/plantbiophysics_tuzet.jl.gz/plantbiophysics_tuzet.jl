# Optional fixed PB Tuzet physiology, included inside MAESPAPlantBiophysicsExt.
struct PlantBiophysicsTuzetLeafComposition{F,S}
    fvcb::F
    tuzet::S
end

function MAESPA.plantbiophysics_leaf_composition(fvcb::PB.Fvcb, tuzet::PB.Tuzet)
    for model in (fvcb, tuzet)
        all(name -> begin
            value = getfield(model, name)
            value isa Real && !(value isa Bool) && isfinite(value)
        end, fieldnames(typeof(model))) ||
            throw(ArgumentError("PlantBiophysics model parameters must be finite real scalars, not Bool"))
        PSE.Authoring.validate_model(model).valid ||
            throw(ArgumentError("PlantBiophysics model has an invalid declared boundary"))
    end
    fvcb.Tᵣ > PlantMeteo.Constants().K₀ ||
        throw(DomainError(fvcb.Tᵣ, "Fvcb reference temperature must exceed absolute zero"))
    tuzet.gs_min >= zero(tuzet.gs_min) ||
        throw(DomainError(tuzet.gs_min, "Tuzet minimum conductance must be non-negative"))
    tuzet.sf > zero(tuzet.sf) ||
        throw(DomainError(tuzet.sf, "Tuzet sensitivity must be positive, as in the native closure"))
    tuzet.Ψᵥ < zero(tuzet.Ψᵥ) ||
        throw(DomainError(tuzet.Ψᵥ, "Tuzet reference water potential must be negative, as in the native closure"))
    return PlantBiophysicsTuzetLeafComposition(fvcb, tuzet)
end

# Γ is derived once from the same immutable PB.Tuzet mounted by the factory.
# It is not a separate user parameter or the biochemical temperature-dependent Γ*.
struct PlantBiophysicsTuzetLeafPhotosynthesis{T,G} <:
    MAESPA.AbstractStomatal_Photosynthesis_CouplingModel
    water_to_co2_conductance_ratio::T
    stomatal_co2_compensation_point_umol_mol::G

    function PlantBiophysicsTuzetLeafPhotosynthesis(ratio::T, gamma::G) where {T<:Real,G<:Real}
        !(ratio isa Bool) && isfinite(ratio) && ratio > zero(ratio) ||
            throw(DomainError(ratio, "water-to-CO₂ conductance ratio must be finite and positive"))
        !(gamma isa Bool) && isfinite(gamma) ||
            throw(DomainError(gamma, "stomatal CO₂ compensation point must be finite"))
        return new{T,G}(ratio, gamma)
    end
end

PSE.inputs_(::PlantBiophysicsTuzetLeafPhotosynthesis) = (
    leaf_temperature_c=PSE.Required(Real),
    absorbed_par_umol_m2_s=PSE.Required(Real),
    surface_co2_umol_mol=PSE.Required(Real),
    candidate_leaf_water_potential_mpa=PSE.Required(Real),
    astronomical_daylight=PSE.Required(Bool),
    leaf_radiative_forcing_available=PSE.Required(Bool),
    photosynthetic_capacity_inputs_available=PSE.Required(Bool),
    second_stomatal_curve=PSE.Default(false),
)

PSE.outputs_(model::PlantBiophysicsTuzetLeafPhotosynthesis) = (
    net_assimilation_umol_co2_m2_s=zero(model.water_to_co2_conductance_ratio),
    intercellular_co2_umol_mol=zero(model.water_to_co2_conductance_ratio),
    stomatal_conductance_co2_mol_m2_s=zero(model.water_to_co2_conductance_ratio),
    stomatal_conductance_h2o_mol_m2_s=zero(model.water_to_co2_conductance_ratio),
    rd_umol_m2_s=zero(model.water_to_co2_conductance_ratio),
    hydraulic_limitation_applied=false,
    stomatal_photosynthesis_coupling_available=false,
)
PSE.environment_inputs_(::PlantBiophysicsTuzetLeafPhotosynthesis) = NamedTuple()
PSE.environment_outputs_(::PlantBiophysicsTuzetLeafPhotosynthesis) = NamedTuple()
PSE.dep(::PlantBiophysicsTuzetLeafPhotosynthesis) = (
    plantbiophysics=PSE.Call(PSE.One(within=PSE.Self(), process=:photosynthesis)),
)

function PSE.variable_contracts_(::PlantBiophysicsTuzetLeafPhotosynthesis)
    state(unit, basis) = PSE.VariableContract(;
        unit, basis, temporal=:instantaneous, aggregation=:state, extent=:intensive)
    rate(unit, basis) = PSE.VariableContract(;
        unit, basis, temporal=:second, aggregation=:local, extent=:intensive)
    return (
        leaf_temperature_c=state(:degree_celsius, :leaf),
        absorbed_par_umol_m2_s=PSE.VariableContract(unit=:micromol_photon,
            basis=:surface_area, temporal=:second, aggregation=:rate, extent=:intensive),
        surface_co2_umol_mol=state(:micromole_per_mole, :leaf_surface_air),
        candidate_leaf_water_potential_mpa=MAESPA.LEAF_WATER_POTENTIAL_CONTRACT,
        astronomical_daylight=state(:boolean, :scene),
        leaf_radiative_forcing_available=state(:boolean, :leaf),
        photosynthetic_capacity_inputs_available=state(:boolean, :leaf),
        second_stomatal_curve=state(:boolean, :leaf),
        net_assimilation_umol_co2_m2_s=rate(:micromole_co2, :leaf_area),
        intercellular_co2_umol_mol=state(:micromole_per_mole, :intercellular_air),
        stomatal_conductance_co2_mol_m2_s=rate(:mole_co2, :leaf_area),
        stomatal_conductance_h2o_mol_m2_s=rate(:mole_h2o, :leaf_area),
        rd_umol_m2_s=rate(:micromole_co2, :leaf_area),
        hydraulic_limitation_applied=state(:boolean, :leaf),
        stomatal_photosynthesis_coupling_available=state(:boolean, :leaf),
    )
end

function (factory::PlantBiophysicsTuzetLeafComposition)(context)
    controller = context.controller
    controller isa MAESPA.MAESPATuzetCrownLeafExchangeController ||
        throw(ArgumentError("PB.Tuzet requires the native Crown Tuzet hydraulic controller"))
    closure = controller.hydraulic_closure_model
    factory.tuzet.sf == closure.sensitivity_factor_mpa_inverse &&
        factory.tuzet.Ψᵥ == closure.reference_water_potential_mpa ||
        throw(ArgumentError("PB.Tuzet sf and Ψᵥ must equal the prescribed native closure parameters exactly"))
    ratio = controller.stomatal_model.water_to_co2_conductance_ratio
    adapter = PlantBiophysicsTuzetLeafPhotosynthesis(ratio, factory.tuzet.Γ)
    energy = MAESPA.MAESPACoupledLeafEnergyBalance(controller)
    adapter_name = Symbol("logical_leaf_pb_tuzet_coupling_", context.tree_id)
    fvcb_name = Symbol("plantbiophysics_fvcb_", context.tree_id)
    tuzet_name = Symbol("plantbiophysics_tuzet_", context.tree_id)
    T = typeof(ratio)
    return (applications=(
        PSE.ModelSpec(energy; name=context.energy_application, on=context.on,
            environment=context.environment, output_routing=MAESPA._stream_only_outputs(energy),
            calls=(photosynthesis=PSE.One(within=PSE.Self(), application=adapter_name),)),
        PSE.ModelSpec(adapter; name=adapter_name, on=context.on,
            environment=context.environment, output_routing=MAESPA._stream_only_outputs(adapter),
            calls=(plantbiophysics=PSE.One(within=PSE.Self(), application=fvcb_name),)),
        # Fvcb owns canonical shared A/Gₛ/Cᵢ; its Tuzet call stays unpublished.
        PSE.ModelSpec(factory.fvcb; name=fvcb_name, on=context.on,
            environment=context.environment,
            calls=(stomatal_conductance=PSE.One(within=PSE.Self(), application=tuzet_name),)),
        PSE.ModelSpec(factory.tuzet; name=tuzet_name, on=context.on,
            environment=context.environment),
    ), scratch_seeds=(aPPFD=zero(T), Tₗ=zero(T), Cₛ=one(T), Ψₗ=T(NaN)))
end

function PSE.run!(model::PlantBiophysicsTuzetLeafPhotosynthesis, status, environment,
    constants, context)
    T = typeof(status.rd_umol_m2_s)
    status.net_assimilation_umol_co2_m2_s = zero(T)
    status.intercellular_co2_umol_mol = zero(T)
    status.stomatal_conductance_co2_mol_m2_s = zero(T)
    status.stomatal_conductance_h2o_mol_m2_s = zero(T)
    status.rd_umol_m2_s = zero(T)
    status.hydraulic_limitation_applied = false
    status.stomatal_photosynthesis_coupling_available = false
    status.astronomical_daylight && status.leaf_radiative_forcing_available &&
        status.photosynthetic_capacity_inputs_available || return nothing
    status.second_stomatal_curve &&
        throw(ArgumentError("the PB.Tuzet hybrid does not implement a second stomatal curve"))

    temperature = T(status.leaf_temperature_c)
    photons = T(status.absorbed_par_umol_m2_s)
    surface_co2 = T(status.surface_co2_umol_mol)
    candidate = T(status.candidate_leaf_water_potential_mpa)
    all(isfinite, (temperature, photons, surface_co2, candidate)) &&
        temperature > constants.K₀ && photons >= zero(T) &&
        surface_co2 > zero(T) && surface_co2 > model.stomatal_co2_compensation_point_umol_mol ||
        throw(DomainError((temperature, photons, surface_co2, candidate),
            "PB.Tuzet needs finite leaf drivers, nonnegative PAR and surface CO₂ above Γ"))

    target = only(PSE.call_targets(context, :plantbiophysics))
    target.status.aPPFD = photons
    target.status.Tₗ = temperature
    target.status.Cₛ = surface_co2
    target.status.Ψₗ = candidate # Actual native MPa trial; PB computes FPSIF once.
    PSE.run_call!(target; publish=true)
    fvcb = PSE.call_model(context, :plantbiophysics)
    respiration = PB.arrhenius(fvcb.RdRef, fvcb.Eₐᵣ,
        target.status.Tₗ - constants.K₀, fvcb.Tᵣ - constants.K₀, constants.R)
    assimilation, conductance, ci, rd = T(target.status.A), T(target.status.Gₛ),
        T(target.status.Cᵢ), T(respiration)
    water_conductance = conductance * T(model.water_to_co2_conductance_ratio)
    all(isfinite, (assimilation, conductance, water_conductance, ci, rd)) ||
        throw(DomainError((assimilation, conductance, water_conductance, ci, rd),
            "PB exchange results must be finite"))
    status.net_assimilation_umol_co2_m2_s = assimilation
    status.intercellular_co2_umol_mol = ci
    status.stomatal_conductance_co2_mol_m2_s = conductance
    status.stomatal_conductance_h2o_mol_m2_s = water_conductance
    status.rd_umol_m2_s = rd
    status.stomatal_photosynthesis_coupling_available = true
    return nothing
end

PSE.Authoring.model_metadata(::PlantBiophysicsTuzetLeafPhotosynthesis) = (
    hypothesis="Fixed PB Fvcb/Tuzet daylight physiology driven by the native hydraulic candidate; unchanged native energy/night/wet equations.",
    reference="Selected registered PlantBiophysics Fvcb/Tuzet implementations and native Crown Tuzet closure.",
    maturity=:experimental_hybrid,
    validation=:see_optional_reference_and_scenario_tests,
)
