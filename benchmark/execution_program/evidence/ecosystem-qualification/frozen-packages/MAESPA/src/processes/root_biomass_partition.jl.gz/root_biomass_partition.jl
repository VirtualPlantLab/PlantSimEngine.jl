PlantSimEngine.@process "root_biomass_partition" verbose = false

"""
Fine- and coarse-root biomass pools and their daily increments.

The coarse-root values are calculated as residuals from the supplied totals,
so the two pools retain the total biomass and the two increments retain the
total increment, including when that increment is negative.

This isolates the `FRFRAC` multiplications applied to `RBIOM` and `RBINC` by
the historical `CALCWBIOM` respiration call sites. `RBIOM` is kg dry matter
per tree and `RBINC` is g dry matter per tree and day.
"""
struct RootBiomassPartitionResult{T<:AbstractFloat}
    fine_root_biomass_kg_dry_matter_tree::T
    coarse_root_biomass_kg_dry_matter_tree::T
    fine_root_biomass_increment_g_dry_matter_tree_day::T
    coarse_root_biomass_increment_g_dry_matter_tree_day::T
end

@noinline function _throw_root_biomass_partition_numeric(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _root_biomass_partition_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real ||
        _throw_root_biomass_partition_numeric(name, value, :real)
    value isa Bool &&
        _throw_root_biomass_partition_numeric(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_root_biomass_partition_numeric(name, converted, :finite)
    return converted
end

@inline function _root_biomass_partition_fraction(
    ::Type{T},
    value,
) where {T<:AbstractFloat}
    return _root_biomass_partition_float(T, value, :fine_root_fraction)
end

"""
    MAESPARootBiomassPartition(T=Float64; fine_root_fraction)

Partition total root biomass and its daily increment into fine- and
coarse-root pools. `fine_root_fraction` is a finite dimensionless species
parameter. The historical MAESPA reader did not constrain it to `[0, 1]`;
`read_species_structure(...; mode=:strict)` provides that optional physical
validation, while the model preserves legacy extrapolation semantics.

The parameter is stored using `T`, but the PlantSimEngine wrapper converts it
to the output carrier's type at each call. Consequently a global status type
promotion controls the calculation without requiring model code specialised
for `Float32` or `Float64`.
"""
struct MAESPARootBiomassPartition{T<:AbstractFloat} <:
       AbstractRoot_Biomass_PartitionModel
    fine_root_fraction::T
end

function MAESPARootBiomassPartition(
    ::Type{T}=Float64;
    fine_root_fraction,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the root-biomass-partition numeric type must be concrete"),
    )
    fraction = _root_biomass_partition_fraction(T, fine_root_fraction)
    return MAESPARootBiomassPartition{T}(fraction)
end

@inline function _root_biomass_partition(
    model::MAESPARootBiomassPartition,
    ::Type{T},
    total_root_biomass_kg_dry_matter_tree,
    total_root_biomass_increment_g_dry_matter_tree_day,
) where {T<:AbstractFloat}
    biomass = _root_biomass_partition_float(
        T,
        total_root_biomass_kg_dry_matter_tree,
        :total_root_biomass_kg_dry_matter_tree,
    )
    biomass >= zero(T) || _throw_root_biomass_partition_numeric(
        :total_root_biomass_kg_dry_matter_tree,
        biomass,
        :nonnegative,
    )
    increment = _root_biomass_partition_float(
        T,
        total_root_biomass_increment_g_dry_matter_tree_day,
        :total_root_biomass_increment_g_dry_matter_tree_day,
    )
    fraction = _root_biomass_partition_fraction(T, model.fine_root_fraction)

    fine_biomass = biomass * fraction
    coarse_biomass = biomass - fine_biomass
    fine_increment = increment * fraction
    coarse_increment = increment - fine_increment
    return RootBiomassPartitionResult{T}(
        fine_biomass,
        coarse_biomass,
        fine_increment,
        coarse_increment,
    )
end

"""
    root_biomass_partition(model, total_biomass, total_increment)
    root_biomass_partition(total_biomass, total_increment;
                           fine_root_fraction)

Split total root biomass (kg dry matter tree⁻¹) and its signed daily increment
(g dry matter tree⁻¹ day⁻¹). A negative increment is retained and partitioned;
only biomass itself must be non-negative.

The result type is obtained by promoting the model parameter and numeric
inputs. The PlantSimEngine wrapper instead deliberately takes its calculation
type from the status output carrier.
"""
function root_biomass_partition(
    model::MAESPARootBiomassPartition{M},
    total_root_biomass_kg_dry_matter_tree::Real,
    total_root_biomass_increment_g_dry_matter_tree_day::Real,
) where {M<:AbstractFloat}
    total_root_biomass_kg_dry_matter_tree isa Bool &&
        _throw_root_biomass_partition_numeric(
            :total_root_biomass_kg_dry_matter_tree,
            total_root_biomass_kg_dry_matter_tree,
            :bool,
        )
    total_root_biomass_increment_g_dry_matter_tree_day isa Bool &&
        _throw_root_biomass_partition_numeric(
            :total_root_biomass_increment_g_dry_matter_tree_day,
            total_root_biomass_increment_g_dry_matter_tree_day,
            :bool,
        )
    T = float(
        promote_type(
            M,
            typeof(total_root_biomass_kg_dry_matter_tree),
            typeof(total_root_biomass_increment_g_dry_matter_tree_day),
        ),
    )
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "root-biomass-partition inputs must promote to a concrete AbstractFloat",
        ),
    )
    return _root_biomass_partition(
        model,
        T,
        total_root_biomass_kg_dry_matter_tree,
        total_root_biomass_increment_g_dry_matter_tree_day,
    )
end

function root_biomass_partition(
    total_root_biomass_kg_dry_matter_tree::Real,
    total_root_biomass_increment_g_dry_matter_tree_day::Real;
    fine_root_fraction,
)
    total_root_biomass_kg_dry_matter_tree isa Bool &&
        _throw_root_biomass_partition_numeric(
            :total_root_biomass_kg_dry_matter_tree,
            total_root_biomass_kg_dry_matter_tree,
            :bool,
        )
    total_root_biomass_increment_g_dry_matter_tree_day isa Bool &&
        _throw_root_biomass_partition_numeric(
            :total_root_biomass_increment_g_dry_matter_tree_day,
            total_root_biomass_increment_g_dry_matter_tree_day,
            :bool,
        )
    fine_root_fraction isa Real || _throw_root_biomass_partition_numeric(
        :fine_root_fraction,
        fine_root_fraction,
        :real,
    )
    fine_root_fraction isa Bool && _throw_root_biomass_partition_numeric(
        :fine_root_fraction,
        fine_root_fraction,
        :bool,
    )
    T = float(
        promote_type(
            typeof(total_root_biomass_kg_dry_matter_tree),
            typeof(total_root_biomass_increment_g_dry_matter_tree_day),
            typeof(fine_root_fraction),
        ),
    )
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "root-biomass-partition inputs must promote to a concrete AbstractFloat",
        ),
    )
    model = MAESPARootBiomassPartition(T; fine_root_fraction)
    return _root_biomass_partition(
        model,
        T,
        total_root_biomass_kg_dry_matter_tree,
        total_root_biomass_increment_g_dry_matter_tree_day,
    )
end

PlantSimEngine.inputs_(::MAESPARootBiomassPartition) = (
    total_root_biomass_kg_dry_matter_tree=PlantSimEngine.Required(Real),
    total_root_biomass_increment_g_dry_matter_tree_day=
        PlantSimEngine.Required(Real),
    root_biomass_partition_active=PlantSimEngine.Default(true),
    root_biomass_partition_inputs_available=PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(model::MAESPARootBiomassPartition{T}) where {T} = (
    fine_root_biomass_kg_dry_matter_tree=zero(T),
    coarse_root_biomass_kg_dry_matter_tree=zero(T),
    fine_root_biomass_increment_g_dry_matter_tree_day=zero(T),
    coarse_root_biomass_increment_g_dry_matter_tree_day=zero(T),
    root_biomass_partition_available=false,
)

@inline function _reset_root_biomass_partition!(status, ::Type{T}) where {T}
    status.fine_root_biomass_kg_dry_matter_tree = zero(T)
    status.coarse_root_biomass_kg_dry_matter_tree = zero(T)
    status.fine_root_biomass_increment_g_dry_matter_tree_day = zero(T)
    status.coarse_root_biomass_increment_g_dry_matter_tree_day = zero(T)
    status.root_biomass_partition_available = false
    return nothing
end

@inline function _root_biomass_partition_output_type(status)
    T = typeof(status.fine_root_biomass_kg_dry_matter_tree)
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "fine_root_biomass_kg_dry_matter_tree must use a concrete AbstractFloat type",
        ),
    )
    for name in (
        :coarse_root_biomass_kg_dry_matter_tree,
        :fine_root_biomass_increment_g_dry_matter_tree_day,
        :coarse_root_biomass_increment_g_dry_matter_tree_day,
    )
        typeof(getproperty(status, name)) === T || throw(
            ArgumentError(
                "$(String(name)) must use the same $T output carrier as fine-root biomass",
            ),
        )
    end
    status.root_biomass_partition_available isa Bool || throw(
        ArgumentError("root_biomass_partition_available must be Bool"),
    )
    return T
end

function PlantSimEngine.run!(
    model::MAESPARootBiomassPartition,
    status,
    environment,
    constants,
    context,
)
    T = _root_biomass_partition_output_type(status)

    active = status.root_biomass_partition_active
    available = status.root_biomass_partition_inputs_available
    active isa Bool ||
        throw(ArgumentError("root_biomass_partition_active must be Bool"))
    available isa Bool || throw(
        ArgumentError("root_biomass_partition_inputs_available must be Bool"),
    )
    if !(active && available)
        _reset_root_biomass_partition!(status, T)
        return nothing
    end

    result = _root_biomass_partition(
        model,
        T,
        status.total_root_biomass_kg_dry_matter_tree,
        status.total_root_biomass_increment_g_dry_matter_tree_day,
    )
    status.fine_root_biomass_kg_dry_matter_tree =
        result.fine_root_biomass_kg_dry_matter_tree
    status.coarse_root_biomass_kg_dry_matter_tree =
        result.coarse_root_biomass_kg_dry_matter_tree
    status.fine_root_biomass_increment_g_dry_matter_tree_day =
        result.fine_root_biomass_increment_g_dry_matter_tree_day
    status.coarse_root_biomass_increment_g_dry_matter_tree_day =
        result.coarse_root_biomass_increment_g_dry_matter_tree_day
    status.root_biomass_partition_available = true
    return nothing
end
