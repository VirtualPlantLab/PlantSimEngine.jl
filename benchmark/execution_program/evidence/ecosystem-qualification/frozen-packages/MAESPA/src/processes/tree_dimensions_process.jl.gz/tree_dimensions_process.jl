PlantSimEngine.@process "tree_dimensions" verbose = false

"""
    MAESPATreeDimensions(trajectories)

Shared PlantSimEngine model for MAESPA tree structural trajectories. The
model owns one scene-wide `LegacyTreeTrajectories` value; each target object
selects its stable tree column through the `tree_index` status input.

All geometric outputs are in metres except `leaf_area`, which is in square
metres per tree. When the legacy diameter table is absent, `stem_diameter` is
`nothing` and `stem_diameter_available` is `false`.
"""
struct MAESPATreeDimensions{T<:AbstractFloat} <: AbstractTree_DimensionsModel
    trajectories::LegacyTreeTrajectories{T}
    tree_count::Int

    function MAESPATreeDimensions(
        trajectories::LegacyTreeTrajectories{T},
    ) where {T<:AbstractFloat}
        tree_count = size(trajectories.radius_x.values, 2)
        tables = (
            radius_y=trajectories.radius_y,
            crown_depth=trajectories.crown_depth,
            crown_base_height=trajectories.crown_base_height,
            leaf_area=trajectories.leaf_area,
        )
        for (name, table) in pairs(tables)
            size(table.values, 2) == tree_count || throw(
                DimensionMismatch(
                    "$name has $(size(table.values, 2)) tree columns; radius_x has $tree_count",
                ),
            )
        end
        if !isnothing(trajectories.stem_diameter)
            diameter_count = size(trajectories.stem_diameter.values, 2)
            diameter_count == tree_count || throw(
                DimensionMismatch(
                    "stem_diameter has $diameter_count tree columns; radius_x has $tree_count",
                ),
            )
        end
        return new{T}(trajectories, tree_count)
    end
end

PlantSimEngine.inputs_(::MAESPATreeDimensions) = (
    date50=PlantSimEngine.Required(Integer),
    tree_index=PlantSimEngine.Required(Integer),
)

function PlantSimEngine.outputs_(model::MAESPATreeDimensions{T}) where {T}
    return (
        radius_x=zero(T),
        radius_y=zero(T),
        crown_depth=zero(T),
        crown_base_height=zero(T),
        tree_height=zero(T),
        leaf_area=zero(T),
        stem_diameter=isnothing(model.trajectories.stem_diameter) ? nothing : zero(T),
        stem_diameter_available=!isnothing(model.trajectories.stem_diameter),
    )
end

function _tree_dimensions_at(
    model::MAESPATreeDimensions{T},
    date50::Integer,
    tree_index::Integer,
) where {T}
    tree_index isa Bool && throw(ArgumentError("tree_index must be an integer, not Bool"))
    1 <= tree_index <= model.tree_count || throw(BoundsError(model, tree_index))
    index = Int(tree_index)
    trajectories = model.trajectories

    radius_x = interpolate_tree_dimension(trajectories.radius_x, date50, index)
    radius_y = interpolate_tree_dimension(trajectories.radius_y, date50, index)
    crown_depth = interpolate_tree_dimension(trajectories.crown_depth, date50, index)
    crown_base_height = interpolate_tree_dimension(
        trajectories.crown_base_height,
        date50,
        index,
    )
    leaf_area = interpolate_tree_dimension(trajectories.leaf_area, date50, index)

    diameter_table = trajectories.stem_diameter
    stem_diameter_available = !isnothing(diameter_table)
    stem_diameter = if stem_diameter_available
        interpolate_tree_dimension(diameter_table, date50, index)
    else
        nothing
    end

    return (
        radius_x=radius_x,
        radius_y=radius_y,
        crown_depth=crown_depth,
        crown_base_height=crown_base_height,
        tree_height=crown_base_height + crown_depth,
        leaf_area=leaf_area,
        stem_diameter=stem_diameter,
        stem_diameter_available=stem_diameter_available,
    )
end

function PlantSimEngine.run!(
    model::MAESPATreeDimensions,
    status,
    environment,
    constants,
    context,
)
    dimensions = _tree_dimensions_at(model, status.date50, status.tree_index)
    status.radius_x = dimensions.radius_x
    status.radius_y = dimensions.radius_y
    status.crown_depth = dimensions.crown_depth
    status.crown_base_height = dimensions.crown_base_height
    status.tree_height = dimensions.tree_height
    status.leaf_area = dimensions.leaf_area
    status.stem_diameter = dimensions.stem_diameter
    status.stem_diameter_available = dimensions.stem_diameter_available
    return nothing
end
