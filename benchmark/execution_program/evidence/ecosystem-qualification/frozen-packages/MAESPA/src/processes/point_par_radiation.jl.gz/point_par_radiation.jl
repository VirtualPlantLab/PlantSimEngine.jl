"""
    PointPAROptics(leaf_reflectance, leaf_transmittance, soil_reflectance)

Validated PAR fractions for one explicit target optical context. Leaf values
are that target's layer-1 values, not an average over the shading crowns.
Construct a new context when dated optics change; do not mutate the context.
"""
struct PointPAROptics{T<:AbstractFloat}
    leaf_reflectance::T
    leaf_transmittance::T
    soil_reflectance::T

    function PointPAROptics(leaf_reflectance::T, leaf_transmittance::T,
                            soil_reflectance::T) where {T<:AbstractFloat}
        _scattering_unit_interval(leaf_reflectance, :leaf_reflectance)
        _scattering_unit_interval(leaf_transmittance, :leaf_transmittance)
        _scattering_unit_interval(soil_reflectance, :soil_reflectance)
        leaf_reflectance + leaf_transmittance <= one(T) + T(8) * eps(T) || throw(
            DomainError(leaf_reflectance + leaf_transmittance,
                "PAR leaf reflectance plus transmittance must not exceed one"),
        )
        return new{T}(leaf_reflectance, leaf_transmittance, soil_reflectance)
    end
end

function PointPAROptics(leaf_reflectance::Real, leaf_transmittance::Real,
                        soil_reflectance::Real)
    values = (leaf_reflectance, leaf_transmittance, soil_reflectance)
    any(value -> value isa Bool, values) && throw(
        ArgumentError("PAR optical fractions must be numeric values, not Bool"),
    )
    return PointPAROptics(promote(float.(values)...)...)
end

"""
    _point_par_components!(direct, diffuse, scattered, total, iterations,
        workspace, prepared_diffuse, prepared_direct, ehc, optics; drivers...)

Lean PAR component calculation for one already prepared complete field.
The checked public caller or a model boundary owns source/activity gates,
same-T one-based layout, matching point counts, nonaliasing output/work/input
buffers, workspace capacity, validated optics and fixed positive solver limits.
Current physical drivers and prepared ray/EHC results must already be valid.

This helper performs no fixed-schema scans, cache decisions, availability
assignment or transactional publication. On failure, workspace and any earlier
point outputs may have changed: the caller must not publish them as accepted.
The unchanged one-wave solver retains its dynamic denominator/finiteness and
convergence checks. A whole-field PSE hypothesis may reuse this numerical
helper, but must not bypass another declared replaceable model with it.
"""
function _point_par_components!(
    direct_par_w_m2::AbstractVector{T},
    diffuse_par_w_m2::AbstractVector{T},
    scattered_par_w_m2::AbstractVector{T},
    total_par_w_m2::AbstractVector{T},
    scattering_iterations::AbstractVector{Int},
    workspace::ShortwaveScatteringWorkspace{T},
    prepared_diffuse,
    prepared_direct,
    ehc::EquivalentHorizontalCanopyResult{T},
    optics::PointPAROptics{T};
    sun_zenith_rad::T,
    incident_par_w_m2::T,
    beam_fraction_par::T,
    slope_diffuse_multiplier::T,
    slope_reflection_multiplier::T,
    slope_beam_multiplier::T,
    scattering_tolerance::T,
    maximum_scattering_iterations::Int,
) where {T<:AbstractFloat}
    for point in eachindex(total_par_w_m2)
        scattered = _shortwave_scattering_point!(workspace,
            ehc.point_layer_count[point], ehc.point_layer_index[point],
            ehc.layer_leaf_area_index, ehc.diffuse_layer_transmittance,
            sun_zenith_rad, prepared_direct.effective_extinction[point],
            slope_diffuse_multiplier, slope_reflection_multiplier, slope_beam_multiplier,
            incident_par_w_m2, beam_fraction_par,
            optics.leaf_reflectance, optics.leaf_transmittance, optics.soil_reflectance,
            scattering_tolerance, maximum_scattering_iterations, point, 1)
        direct_par_w_m2[point] = incident_par_w_m2 * beam_fraction_par *
            prepared_direct.transmittance[point]
        diffuse_par_w_m2[point] = incident_par_w_m2 * (one(T) - beam_fraction_par) *
            prepared_diffuse.downward_transmittance[point]
        scattered_par_w_m2[point] = scattered.downward
        total_par_w_m2[point] = direct_par_w_m2[point] + diffuse_par_w_m2[point] +
            scattered_par_w_m2[point]
        scattering_iterations[point] = scattered.iterations
    end
    return nothing
end

"""
    point_par_radiation(x, y, z, crowns, diffuse_zenith_angles,
        selected_target_lai, optics; azimuth_angles, sun_zenith_rad,
        sun_azimuth_rad, astronomical_daylight, incident_par_w_m2,
        beam_fraction_par, plot_width, plot_height, slope_diffuse_multiplier,
        slope_reflection_multiplier, slope_beam_multiplier, ...)

Compute one field-wide, target-conditioned PAR calculation. Ordered crowns
represent all shading trees; their scalar extinction is current beam BEXT and
their angle-specific vector supplies diffuse DEXT. The supplied LAI is the
selected-target LAI, not a value inferred from those all-tree ray states.

Return direct, diffuse, scattered and total incident PAR energy rates in
W m^-2, plus the shared EHC and ray diagnostics. Components are local incident
irradiances, not leaf absorption, point-area totals or photon fluxes. No extra
slope multiplier is applied to the direct/diffuse sensor components. The
three supplied slope multipliers enter SCATTER exactly as in its source call.

This raw kernel requires eligible daylight with PAR > 1 W m^-2 and positive
selected-target LAI. Target foliage eligibility and accepted/unavailable/night
publication belong to `MAESPASensorRadiation`, not an invented zero here.
The given computational point order is preserved, including final-DEXT carry.
It is not a point-order-invariance policy or a complete IPOINTS/PSE model.
"""
function point_par_radiation(
    x::AbstractVector{T},
    y::AbstractVector{T},
    z::AbstractVector{T},
    crowns::AbstractVector{<:AbstractCrownRayState{T}},
    diffuse_zenith_angles::AbstractVector{T},
    selected_target_lai::T,
    optics::PointPAROptics{T};
    azimuth_angles::Integer,
    sun_zenith_rad::T,
    sun_azimuth_rad::T,
    astronomical_daylight::Bool,
    incident_par_w_m2::T,
    beam_fraction_par::T,
    plot_width::T,
    plot_height::T,
    slope_diffuse_multiplier::T,
    slope_reflection_multiplier::T,
    slope_beam_multiplier::T,
    diffuse_sky::T=zero(T),
    slope_x_rad::T=zero(T),
    slope_y_rad::T=zero(T),
    shade_height::T=zero(T),
    maximum_layer_count::Integer=150,
    scattering_tolerance::T=T(0.01),
    maximum_scattering_iterations::Integer=10_000,
    scattering_workspace=nothing,
) where {T<:AbstractFloat}
    point_count = _transmission_point_count(x, y, z)
    astronomical_daylight || throw(DomainError(astronomical_daylight,
        "point PAR kernel requires eligible daylight"))
    isfinite(incident_par_w_m2) && incident_par_w_m2 > one(T) || throw(
        DomainError(incident_par_w_m2, "point PAR kernel requires incident PAR > 1 W m^-2"),
    )
    _scattering_unit_interval(beam_fraction_par, :beam_fraction_par)
    isfinite(selected_target_lai) && selected_target_lai > zero(T) || throw(
        DomainError(selected_target_lai, "selected-target LAI must be finite and positive"),
    )
    zero(T) <= sun_zenith_rad < T(π) / T(2) || throw(
        DomainError(sun_zenith_rad, "daylight zenith must lie in [0, pi/2)"),
    )
    for (value, name) in ((slope_diffuse_multiplier, "slope_diffuse_multiplier"),
                          (slope_reflection_multiplier, "slope_reflection_multiplier"))
        isfinite(value) && value >= zero(T) || throw(
            ArgumentError("$name must be finite and nonnegative"),
        )
    end
    isfinite(slope_beam_multiplier) || throw(
        ArgumentError("slope_beam_multiplier must be finite"),
    )
    isfinite(scattering_tolerance) && scattering_tolerance > zero(T) || throw(
        ArgumentError("scattering_tolerance must be finite and positive"),
    )
    maximum_scattering_iterations isa Bool && throw(
        ArgumentError("maximum_scattering_iterations must be an integer, not Bool"),
    )
    iteration_limit = Int(maximum_scattering_iterations)
    iteration_limit > 0 || throw(ArgumentError("maximum_scattering_iterations must be positive"))

    diffuse = diffuse_transmission_to_points(x, y, z, crowns, diffuse_zenith_angles;
        azimuth_angles, diffuse_sky, slope_x_rad, slope_y_rad, plot_width, plot_height, shade_height)
    # One shared chart uses the complete field's minimum TD/TU and final DEXT.
    ehc = equivalent_horizontal_canopy(diffuse.upward_transmittance,
        diffuse.downward_transmittance, selected_target_lai, slope_x_rad, slope_y_rad,
        diffuse_zenith_angles, diffuse.legacy_final_effective_extinction;
        azimuth_count=azimuth_angles, maximum_layer_count)
    direct = direct_transmission_to_points(x, y, z, crowns;
        sun_zenith_rad, sun_azimuth_rad, astronomical_daylight, incident_par_w_m2,
        beam_fraction_par, beam_fraction_nir=zero(T), slope_x_rad, slope_y_rad,
        plot_width, plot_height, shade_height)

    required_layers = maximum(ehc.point_layer_count)
    workspace = isnothing(scattering_workspace) ?
        ShortwaveScatteringWorkspace(T, required_layers) : scattering_workspace
    workspace isa ShortwaveScatteringWorkspace{T} || throw(
        ArgumentError("scattering_workspace must share the field numeric type"),
    )
    _validate_shortwave_workspace(workspace, required_layers)
    direct_par_w_m2 = Vector{T}(undef, point_count)
    diffuse_par_w_m2 = Vector{T}(undef, point_count)
    scattered_par_w_m2 = Vector{T}(undef, point_count)
    total_par_w_m2 = Vector{T}(undef, point_count)
    scattering_iterations = Vector{Int}(undef, point_count)
    _point_par_components!(direct_par_w_m2, diffuse_par_w_m2, scattered_par_w_m2,
        total_par_w_m2, scattering_iterations, workspace, diffuse, direct, ehc, optics;
        sun_zenith_rad, incident_par_w_m2, beam_fraction_par, slope_diffuse_multiplier,
        slope_reflection_multiplier, slope_beam_multiplier, scattering_tolerance,
        maximum_scattering_iterations=iteration_limit)
    return (; direct_par_w_m2, diffuse_par_w_m2, scattered_par_w_m2, total_par_w_m2,
        scattering_iterations, diffuse_transmission=diffuse, direct_transmission=direct,
        equivalent_canopy=ehc)
end
