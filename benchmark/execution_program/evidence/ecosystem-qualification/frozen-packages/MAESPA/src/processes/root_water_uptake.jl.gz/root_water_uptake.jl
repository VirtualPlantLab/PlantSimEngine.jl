PlantSimEngine.@process "root_water_uptake" verbose = false

"""
Multi-layer outputs of the executable soil-to-root uptake path in MAESPA.

The three vectors are in canonical soil-layer order, independently of the
order of the input vectors:

- `soil_to_root_hydraulic_resistance_mpa_m2_ground_s_per_mmol` is the radial
  soil resistance `SOILRRES1` in MPa s m² ground mmol⁻¹;
- `maximum_root_water_uptake_mmol_m2_ground_s` is the non-negative layer
  capacity `ESTEVAP` after the historical frozen-layer gate;
- `root_water_uptake_fraction` is the executable SPA distribution and sums to
  one when total capacity is positive.

`total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol` is the parallel soil
resistance converted to a leaf-area basis with total LAI. The result is marked
unavailable when no layer contains a finite soil-to-root path.
"""
struct RootWaterUptakeResult{T<:AbstractFloat}
    soil_to_root_hydraulic_resistance_mpa_m2_ground_s_per_mmol::Vector{T}
    maximum_root_water_uptake_mmol_m2_ground_s::Vector{T}
    root_water_uptake_fraction::Vector{T}
    weighted_soil_water_potential_mpa::T
    total_maximum_root_water_uptake_mmol_m2_ground_s::T
    total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol::T
    hydraulic_path_available::Bool
end

"""
    MAESPARootWaterUptake(T=Float64, layer_count; kwargs...)

PlantSimEngine model for the smallest coupled slice shared by `SOILRESCALC`
and `WATERUPTAKELAYER`: radial soil resistance, layer uptake capacity, the
actually selected SPA uptake fractions, weighted soil water potential, and
parallel total soil resistance.

The slice deliberately excludes three pieces which cannot be retained without
recreating caller-level orchestration:

- measured-soil-water mode (`USEMEASSW == 1`), which collapses resistance and
  potential to the first layer;
- equal-uptake debugging mode (`EQUALUPTAKE == 1`);
- `SOILRRES2`, the root-hydraulic component calculated by `SOILRESCALC` but
  explicitly omitted by `WATERUPTAKELAYER` because root resistance already
  belongs to the plant pathway.

The Taylor--Keppler fractions are also not outputs: legacy code calculates
them, but the only assignment that would replace `FRACUPTAKE` is commented.
Actual removal of transpired water remains the responsibility of `WATBALLAY`;
this process only publishes its normalized allocation fractions. A strictly
positive total LAI is required by the numerical kernel because the published
total resistance has an explicit leaf-area basis; the PlantSimEngine process
publishes an unavailable, zeroed result when LAI is exactly zero, so a leafless
scene can later become active without changing model configuration. The legacy
zero-LAI branch leaves resistance on a ground-area basis and is not published.
"""
struct MAESPARootWaterUptake{T<:AbstractFloat} <:
       AbstractRoot_Water_UptakeModel
    layer_count::Int
    water_partial_molar_volume_m3_mol::T
    gravitational_acceleration_m_s2::T
    legacy_pi::T
    mol_to_mmol_resistance_scale::T
    minimum_converted_soil_conductivity_mol_m_s_mpa::T
end

@noinline function _throw_root_water_uptake(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :nonpositive
        throw(DomainError(value, "$label must be non-positive"))
    elseif reason === :negative
        throw(DomainError(value, "$label must be negative"))
    elseif reason === :fraction
        throw(DomainError(value, "$label must lie in [0, 1]"))
    elseif reason === :root_geometry
        throw(
            DomainError(
                value,
                "fine_root_radius_m must be smaller than the soil-cylinder radius",
            ),
        )
    elseif reason === :conductivity_floor
        throw(
            DomainError(
                value,
                "$label enters the legacy branch that leaves SOILRRES1 undefined",
            ),
        )
    elseif reason === :solution
        throw(DomainError(value, "the root-water-uptake solution must be finite"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _root_water_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real || _throw_root_water_uptake(name, value, :real)
    value isa Bool && _throw_root_water_uptake(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) || _throw_root_water_uptake(name, converted, :finite)
    return converted
end

@inline function _root_water_positive(value::T, name::Symbol) where {T}
    value > zero(T) || _throw_root_water_uptake(name, value, :positive)
    return value
end

@inline function _root_water_nonnegative(value::T, name::Symbol) where {T}
    value >= zero(T) || _throw_root_water_uptake(name, value, :nonnegative)
    return value
end

@inline function _root_water_nonpositive(value::T, name::Symbol) where {T}
    value <= zero(T) || _throw_root_water_uptake(name, value, :nonpositive)
    return value
end

@inline function _root_water_fraction(value::T, name::Symbol) where {T}
    zero(T) <= value <= one(T) ||
        _throw_root_water_uptake(name, value, :fraction)
    return value
end

@inline function _root_water_layer_count(value)
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError("layer_count must be an integer, not Bool"),
    )
    count = Int(value)
    count > 0 || throw(DomainError(count, "layer_count must be positive"))
    return count
end

function MAESPARootWaterUptake(
    ::Type{T},
    layer_count;
    water_partial_molar_volume_m3_mol=18.05e-6,
    gravitational_acceleration_m_s2=9.8067,
    legacy_pi=3.1415927,
    mol_to_mmol_resistance_scale=1e-3,
    minimum_converted_soil_conductivity_mol_m_s_mpa=1e-35,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the root-water-uptake numeric type must be concrete"),
    )
    count = _root_water_layer_count(layer_count)
    water_volume = _root_water_positive(
        _root_water_float(
            T,
            water_partial_molar_volume_m3_mol,
            :water_partial_molar_volume_m3_mol,
        ),
        :water_partial_molar_volume_m3_mol,
    )
    gravity = _root_water_positive(
        _root_water_float(
            T,
            gravitational_acceleration_m_s2,
            :gravitational_acceleration_m_s2,
        ),
        :gravitational_acceleration_m_s2,
    )
    pi_value = _root_water_positive(
        _root_water_float(T, legacy_pi, :legacy_pi),
        :legacy_pi,
    )
    resistance_scale = _root_water_positive(
        _root_water_float(
            T,
            mol_to_mmol_resistance_scale,
            :mol_to_mmol_resistance_scale,
        ),
        :mol_to_mmol_resistance_scale,
    )
    conductivity_floor = _root_water_positive(
        _root_water_float(
            T,
            minimum_converted_soil_conductivity_mol_m_s_mpa,
            :minimum_converted_soil_conductivity_mol_m_s_mpa,
        ),
        :minimum_converted_soil_conductivity_mol_m_s_mpa,
    )
    return MAESPARootWaterUptake{T}(
        count,
        water_volume,
        gravity,
        pi_value,
        resistance_scale,
        conductivity_floor,
    )
end

MAESPARootWaterUptake(layer_count; kwargs...) =
    MAESPARootWaterUptake(Float64, layer_count; kwargs...)

@inline function _root_water_require_vector(
    values,
    layer_count::Int,
    name::Symbol,
)
    values isa AbstractVector || throw(
        ArgumentError("$(String(name)) must be an AbstractVector"),
    )
    length(values) == layer_count || throw(
        DimensionMismatch("$(String(name)) must contain $layer_count values"),
    )
    axes(values, 1) == Base.OneTo(layer_count) || throw(
        ArgumentError("$(String(name)) must use one-based contiguous indexing"),
    )
    return values
end

@inline function _root_water_layer_index(value, layer_count::Int, position::Int)
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError("rooted_soil_layer_indices[$position] must be an integer"),
    )
    index = Int(value)
    1 <= index <= layer_count || throw(
        BoundsError(1:layer_count, index),
    )
    return index
end

@inline function _root_water_position_for_layer(
    rooted_soil_layer_indices,
    layer_index::Int,
    layer_count::Int,
)
    for position in 1:layer_count
        rooted_soil_layer_indices[position] == layer_index && return position
    end
    throw(ArgumentError("missing rooted soil layer index $layer_index"))
end

@inline function _validate_root_water_indices!(
    rooted_soil_layer_indices,
    layer_count::Int,
)
    for position in 1:layer_count
        index = _root_water_layer_index(
            rooted_soil_layer_indices[position],
            layer_count,
            position,
        )
        for earlier in 1:(position - 1)
            rooted_soil_layer_indices[earlier] == index && throw(
                ArgumentError("rooted soil layer index $index occurs more than once"),
            )
        end
    end
    return nothing
end

@inline function _root_water_model_constants(
    model::MAESPARootWaterUptake,
    ::Type{T},
) where {T<:AbstractFloat}
    water_volume = _root_water_positive(
        _root_water_float(
            T,
            model.water_partial_molar_volume_m3_mol,
            :water_partial_molar_volume_m3_mol,
        ),
        :water_partial_molar_volume_m3_mol,
    )
    gravity = _root_water_positive(
        _root_water_float(
            T,
            model.gravitational_acceleration_m_s2,
            :gravitational_acceleration_m_s2,
        ),
        :gravitational_acceleration_m_s2,
    )
    pi_value = _root_water_positive(
        _root_water_float(T, model.legacy_pi, :legacy_pi),
        :legacy_pi,
    )
    resistance_scale = _root_water_positive(
        _root_water_float(
            T,
            model.mol_to_mmol_resistance_scale,
            :mol_to_mmol_resistance_scale,
        ),
        :mol_to_mmol_resistance_scale,
    )
    conductivity_floor = _root_water_positive(
        _root_water_float(
            T,
            model.minimum_converted_soil_conductivity_mol_m_s_mpa,
            :minimum_converted_soil_conductivity_mol_m_s_mpa,
        ),
        :minimum_converted_soil_conductivity_mol_m_s_mpa,
    )
    return water_volume, gravity, pi_value, resistance_scale, conductivity_floor
end

@inline function _root_water_uptake!(
    soil_resistance::AbstractVector{T},
    maximum_uptake::AbstractVector{T},
    uptake_fraction::AbstractVector{T},
    model::MAESPARootWaterUptake,
    rooted_soil_layer_indices,
    soil_water_potential_mpa,
    soil_hydraulic_conductivity_m_s,
    root_length_density_m_m3,
    soil_layer_thickness_m,
    soil_ice_fraction,
    fine_root_radius_m,
    minimum_root_water_potential_mpa,
    total_leaf_area_index,
    tree_height_m,
) where {T<:AbstractFloat}
    layer_count = model.layer_count
    _root_water_require_vector(
        rooted_soil_layer_indices,
        layer_count,
        :rooted_soil_layer_indices,
    )
    _root_water_require_vector(
        soil_water_potential_mpa,
        layer_count,
        :soil_water_potential_mpa,
    )
    _root_water_require_vector(
        soil_hydraulic_conductivity_m_s,
        layer_count,
        :soil_hydraulic_conductivity_m_s,
    )
    _root_water_require_vector(
        root_length_density_m_m3,
        layer_count,
        :root_length_density_m_m3,
    )
    _root_water_require_vector(
        soil_layer_thickness_m,
        layer_count,
        :soil_layer_thickness_m,
    )
    _root_water_require_vector(
        soil_ice_fraction,
        layer_count,
        :soil_ice_fraction,
    )
    _root_water_require_vector(soil_resistance, layer_count, :soil_resistance)
    _root_water_require_vector(maximum_uptake, layer_count, :maximum_uptake)
    _root_water_require_vector(uptake_fraction, layer_count, :uptake_fraction)
    _validate_root_water_indices!(rooted_soil_layer_indices, layer_count)

    fill!(soil_resistance, zero(T))
    fill!(maximum_uptake, zero(T))
    fill!(uptake_fraction, zero(T))

    water_volume, gravity, pi_value, resistance_scale, conductivity_floor =
        _root_water_model_constants(model, T)
    root_radius = _root_water_positive(
        _root_water_float(T, fine_root_radius_m, :fine_root_radius_m),
        :fine_root_radius_m,
    )
    minimum_root_potential = _root_water_float(
        T,
        minimum_root_water_potential_mpa,
        :minimum_root_water_potential_mpa,
    )
    minimum_root_potential < zero(T) || _throw_root_water_uptake(
        :minimum_root_water_potential_mpa,
        minimum_root_potential,
        :negative,
    )
    leaf_area_index = _root_water_positive(
        _root_water_float(T, total_leaf_area_index, :total_leaf_area_index),
        :total_leaf_area_index,
    )
    tree_height = _root_water_nonnegative(
        _root_water_float(T, tree_height_m, :tree_height_m),
        :tree_height_m,
    )

    converted_conductivity_denominator =
        water_volume * gravity * resistance_scale
    isfinite(converted_conductivity_denominator) &&
        converted_conductivity_denominator > zero(T) ||
        _throw_root_water_uptake(
            :soil_conductivity_conversion,
            converted_conductivity_denominator,
            :solution,
        )

    # Validate every input before publishing any layer result. ICEPROP is a
    # binary gate in executable behavior: every strictly positive fraction
    # suppresses uptake completely rather than scaling it continuously.
    for position in 1:layer_count
        _root_water_nonpositive(
            _root_water_float(
                T,
                soil_water_potential_mpa[position],
                :soil_water_potential_mpa,
            ),
            :soil_water_potential_mpa,
        )
        conductivity = _root_water_positive(
            _root_water_float(
                T,
                soil_hydraulic_conductivity_m_s[position],
                :soil_hydraulic_conductivity_m_s,
            ),
            :soil_hydraulic_conductivity_m_s,
        )
        root_density = _root_water_nonnegative(
            _root_water_float(
                T,
                root_length_density_m_m3[position],
                :root_length_density_m_m3,
            ),
            :root_length_density_m_m3,
        )
        _root_water_positive(
            _root_water_float(
                T,
                soil_layer_thickness_m[position],
                :soil_layer_thickness_m,
            ),
            :soil_layer_thickness_m,
        )
        _root_water_fraction(
            _root_water_float(
                T,
                soil_ice_fraction[position],
                :soil_ice_fraction,
            ),
            :soil_ice_fraction,
        )

        converted_conductivity =
            conductivity / converted_conductivity_denominator
        converted_conductivity >= conductivity_floor ||
            _throw_root_water_uptake(
                :converted_soil_hydraulic_conductivity_mol_m_s_mpa,
                converted_conductivity,
                :conductivity_floor,
            )
        if root_density > zero(T)
            soil_cylinder_radius = sqrt(one(T) / (root_density * pi_value))
            soil_cylinder_radius > root_radius || _throw_root_water_uptake(
                :fine_root_radius_m,
                root_radius,
                :root_geometry,
            )
            logarithmic_radius_ratio = log(soil_cylinder_radius / root_radius)
            logarithmic_radius_ratio > zero(T) &&
                isfinite(logarithmic_radius_ratio) ||
                _throw_root_water_uptake(
                    :logarithmic_root_radius_ratio,
                    logarithmic_radius_ratio,
                    :solution,
                )
        end
    end

    inverse_resistance_sum = zero(T)
    for layer_index in 1:layer_count
        position = _root_water_position_for_layer(
            rooted_soil_layer_indices,
            layer_index,
            layer_count,
        )
        root_density = _root_water_float(
            T,
            root_length_density_m_m3[position],
            :root_length_density_m_m3,
        )
        if root_density > zero(T)
            conductivity = _root_water_float(
                T,
                soil_hydraulic_conductivity_m_s[position],
                :soil_hydraulic_conductivity_m_s,
            )
            thickness = _root_water_float(
                T,
                soil_layer_thickness_m[position],
                :soil_layer_thickness_m,
            )
            converted_conductivity =
                conductivity / converted_conductivity_denominator
            layer_resistance = _soil_to_root_radial_resistance(
                root_density, thickness, converted_conductivity, root_radius,
                pi_value, resistance_scale)
            isfinite(layer_resistance) && layer_resistance > zero(T) ||
                _throw_root_water_uptake(
                    :soil_to_root_hydraulic_resistance,
                    layer_resistance,
                    :solution,
                )
            soil_resistance[layer_index] = layer_resistance
            inverse_resistance_sum += inv(layer_resistance)
            isfinite(inverse_resistance_sum) || _throw_root_water_uptake(
                :parallel_soil_hydraulic_conductance,
                inverse_resistance_sum,
                :solution,
            )
        end
    end

    if iszero(inverse_resistance_sum)
        # Legacy evaluates 1/0 here. Publish a deterministic unavailable state
        # instead; callers must not feed a fabricated resistance downstream.
        fill!(soil_resistance, zero(T))
        return (
            weighted_soil_water_potential_mpa=zero(T),
            total_maximum_root_water_uptake_mmol_m2_ground_s=zero(T),
            total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol=zero(T),
            hydraulic_path_available=false,
        )
    end

    weighted_potential, total_uptake = _spa_root_water_allocation!(
        maximum_uptake, uptake_fraction, soil_resistance,
        rooted_soil_layer_indices, soil_water_potential_mpa,
        soil_layer_thickness_m, soil_ice_fraction, minimum_root_potential,
        tree_height, gravity * resistance_scale,
    )
    total_resistance = inv(inverse_resistance_sum) * leaf_area_index
    values = (weighted_potential, total_uptake, total_resistance)
    all(isfinite, values) || _throw_root_water_uptake(
        :root_water_uptake,
        values,
        :solution,
    )
    return (
        weighted_soil_water_potential_mpa=weighted_potential,
        total_maximum_root_water_uptake_mmol_m2_ground_s=total_uptake,
        total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol=total_resistance,
        hydraulic_path_available=true,
    )
end

"""
SPA layer capacities and allocation from already resolved radial resistances.
The legacy pre-freeze weighted-potential numerator is deliberately retained.
Measured-potential uptake can reuse the allocation before replacing that
potential and selecting its first-layer resistance.
"""
@inline function _spa_root_water_allocation!(
    maximum_uptake::AbstractVector{T}, uptake_fraction::AbstractVector{T},
    soil_resistance::AbstractVector{T}, rooted_soil_layer_indices,
    soil_water_potential_mpa, soil_layer_thickness_m, soil_ice_fraction,
    minimum_root_potential, tree_height, gravity_mpa_per_m,
) where {T}
    layer_count = length(soil_resistance)
    cumulative_depth = zero(T)
    thickness_sum = zero(T)
    thickness_weighted_potential = zero(T)
    historical_weighted_numerator = zero(T)
    total_uptake = zero(T)
    for layer_index in 1:layer_count
        position = _root_water_position_for_layer(
            rooted_soil_layer_indices,
            layer_index,
            layer_count,
        )
        thickness = _root_water_float(
            T,
            soil_layer_thickness_m[position],
            :soil_layer_thickness_m,
        )
        soil_potential = _root_water_float(
            T,
            soil_water_potential_mpa[position],
            :soil_water_potential_mpa,
        )
        ice_fraction = _root_water_float(
            T,
            soil_ice_fraction[position],
            :soil_ice_fraction,
        )
        cumulative_depth += thickness
        midpoint_depth = cumulative_depth - thickness / T(2)
        thickness_sum += thickness
        thickness_weighted_potential += soil_potential * thickness

        layer_resistance = soil_resistance[layer_index]
        unconstrained_uptake = if layer_resistance > zero(T)
            (
                soil_potential - minimum_root_potential -
                gravity_mpa_per_m * (tree_height + midpoint_depth)
            ) / layer_resistance
        else
            zero(T)
        end
        layer_uptake = max(zero(T), unconstrained_uptake)
        isfinite(layer_uptake) || _throw_root_water_uptake(
            :maximum_root_water_uptake_mmol_m2_ground_s,
            layer_uptake,
            :solution,
        )

        # Preserve lines 1103--1107 exactly: the weighted numerator is updated
        # before frozen soil sets ESTEVAP to zero. This asymmetry only affects
        # WEIGHTEDSWP when some, but not all, productive layers are frozen.
        historical_weighted_numerator += soil_potential * layer_uptake
        ice_fraction > zero(T) && (layer_uptake = zero(T))
        maximum_uptake[layer_index] = layer_uptake
        total_uptake += layer_uptake
    end

    weighted_potential = if total_uptake > zero(T)
        for layer_index in 1:layer_count
            uptake_fraction[layer_index] =
                maximum_uptake[layer_index] / total_uptake
        end
        historical_weighted_numerator / total_uptake
    else
        thickness_weighted_potential / thickness_sum
    end
    return weighted_potential, total_uptake
end

@inline function _root_water_input_type(values, name::Symbol)
    values isa AbstractVector || throw(
        ArgumentError("$(String(name)) must be an AbstractVector"),
    )
    element_type = eltype(values)
    element_type <: Real && isconcretetype(element_type) || throw(
        ArgumentError("$(String(name)) must have a concrete Real element type"),
    )
    element_type === Bool && throw(
        ArgumentError("$(String(name)) must not contain Bool values"),
    )
    return typeof(float(zero(element_type)))
end

"""
    root_water_uptake(rooted_soil_layer_indices,
                      soil_water_potential_mpa,
                      soil_hydraulic_conductivity_m_s,
                      root_length_density_m_m3,
                      soil_layer_thickness_m,
                      soil_ice_fraction;
                      fine_root_radius_m,
                      minimum_root_water_potential_mpa,
                      total_leaf_area_index,
                      tree_height_m,
                      kwargs...)

Evaluate the executable, non-measured, non-equal-uptake branch for one rooted
soil profile. Input vectors may arrive in any order, but
`rooted_soil_layer_indices` must be a permutation of `1:n`; returned vectors
always use canonical layer order. This explicit indexing makes multi-layer and
multi-species applications independent of PlantSimEngine object ordering.

Every positive `soil_ice_fraction` suppresses uptake in that layer exactly as
legacy `ICEPROP > 0` does. The layer still contributes to parallel hydraulic
resistance, and its pre-freeze capacity still contributes to the historical
weighted-potential numerator. These two asymmetries are retained and
documented rather than silently corrected.
"""
function root_water_uptake(
    rooted_soil_layer_indices,
    soil_water_potential_mpa,
    soil_hydraulic_conductivity_m_s,
    root_length_density_m_m3,
    soil_layer_thickness_m,
    soil_ice_fraction;
    fine_root_radius_m,
    minimum_root_water_potential_mpa,
    total_leaf_area_index,
    tree_height_m,
    kwargs...,
)
    layer_count = length(rooted_soil_layer_indices)
    layer_count > 0 || throw(
        ArgumentError("a rooted soil profile must contain at least one layer"),
    )
    scalar_values = (
        fine_root_radius_m,
        minimum_root_water_potential_mpa,
        total_leaf_area_index,
        tree_height_m,
    )
    scalar_names = (
        :fine_root_radius_m,
        :minimum_root_water_potential_mpa,
        :total_leaf_area_index,
        :tree_height_m,
    )
    scalar_types = ntuple(length(scalar_values)) do index
        value = scalar_values[index]
        value isa Real ||
            _throw_root_water_uptake(scalar_names[index], value, :real)
        value isa Bool &&
            _throw_root_water_uptake(scalar_names[index], value, :bool)
        typeof(float(value))
    end
    vector_types = (
        _root_water_input_type(
            soil_water_potential_mpa,
            :soil_water_potential_mpa,
        ),
        _root_water_input_type(
            soil_hydraulic_conductivity_m_s,
            :soil_hydraulic_conductivity_m_s,
        ),
        _root_water_input_type(
            root_length_density_m_m3,
            :root_length_density_m_m3,
        ),
        _root_water_input_type(
            soil_layer_thickness_m,
            :soil_layer_thickness_m,
        ),
        _root_water_input_type(soil_ice_fraction, :soil_ice_fraction),
    )
    T = promote_type(scalar_types..., vector_types...)
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "root-water-uptake inputs must promote to a concrete AbstractFloat",
        ),
    )
    model = MAESPARootWaterUptake(T, layer_count; kwargs...)
    soil_resistance = zeros(T, layer_count)
    maximum_uptake = zeros(T, layer_count)
    uptake_fraction = zeros(T, layer_count)
    scalars = _root_water_uptake!(
        soil_resistance,
        maximum_uptake,
        uptake_fraction,
        model,
        rooted_soil_layer_indices,
        soil_water_potential_mpa,
        soil_hydraulic_conductivity_m_s,
        root_length_density_m_m3,
        soil_layer_thickness_m,
        soil_ice_fraction,
        fine_root_radius_m,
        minimum_root_water_potential_mpa,
        total_leaf_area_index,
        tree_height_m,
    )
    return RootWaterUptakeResult{T}(
        soil_resistance,
        maximum_uptake,
        uptake_fraction,
        scalars.weighted_soil_water_potential_mpa,
        scalars.total_maximum_root_water_uptake_mmol_m2_ground_s,
        scalars.total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol,
        scalars.hydraulic_path_available,
    )
end

"""SOILRESCALC's measured-water path: top conductivity with all fine roots."""
function _all_root_surface_resistance(
    root_density, layer_thickness, conductivity::T, root_radius, pi_value, resistance_scale,
) where {T}
    total_depth = zero(T)
    total_root_length = zero(T)
    for position in eachindex(root_density, layer_thickness)
        thickness = T(layer_thickness[position])
        total_depth += thickness
        total_root_length += T(root_density[position]) * thickness
    end
    iszero(total_root_length) && return nothing
    return _soil_to_root_radial_resistance(total_root_length / total_depth,
        total_depth, conductivity, root_radius, pi_value, resistance_scale)
end

"""Radial soil resistance from the executable SOILRESCALC single-root cylinder."""
@inline function _soil_to_root_radial_resistance(
    root_density, thickness, converted_conductivity, root_radius, pi_value, resistance_scale,
)
    soil_cylinder_radius = sqrt(one(root_density) / (root_density * pi_value))
    logarithmic_radius_ratio = log(soil_cylinder_radius / root_radius)
    logarithmic_radius_ratio > zero(logarithmic_radius_ratio) ||
        throw(DomainError(logarithmic_radius_ratio, "invalid soil-to-root cylinder geometry"))
    layer_conductance = root_density * thickness * oftype(root_density, 2) *
        pi_value * converted_conductivity / logarithmic_radius_ratio
    return resistance_scale / layer_conductance
end

PlantSimEngine.variable_contracts_(::MAESPARootWaterUptake) = merge(
    ROOT_WATER_UPTAKE_OUTPUT_CONTRACTS,
    (soil_water_potential_mpa=SOIL_LAYER_WATER_POTENTIAL_CONTRACT,),
)

PlantSimEngine.inputs_(::MAESPARootWaterUptake) = (
    rooted_soil_layer_indices=PlantSimEngine.Required(AbstractVector),
    soil_water_potential_mpa=PlantSimEngine.Required(AbstractVector),
    soil_hydraulic_conductivity_m_s=PlantSimEngine.Required(AbstractVector),
    root_length_density_m_m3=PlantSimEngine.Required(AbstractVector),
    soil_layer_thickness_m=PlantSimEngine.Required(AbstractVector),
    soil_ice_fraction=PlantSimEngine.Required(AbstractVector),
    fine_root_radius_m=PlantSimEngine.Required(Real),
    minimum_root_water_potential_mpa=PlantSimEngine.Required(Real),
    total_leaf_area_index=PlantSimEngine.Required(Real),
    tree_height_m=PlantSimEngine.Required(Real),
    root_water_uptake_active=PlantSimEngine.Required(Bool),
    root_water_uptake_inputs_available=PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(model::MAESPARootWaterUptake{T}) where {T} = (
    soil_to_root_hydraulic_resistance_mpa_m2_ground_s_per_mmol=
        zeros(T, model.layer_count),
    maximum_root_water_uptake_mmol_m2_ground_s=zeros(T, model.layer_count),
    root_water_uptake_fraction=zeros(T, model.layer_count),
    weighted_soil_water_potential_mpa=zero(T),
    total_maximum_root_water_uptake_mmol_m2_ground_s=zero(T),
    total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol=zero(T),
    root_water_uptake_available=false,
)

@inline function _reset_root_water_uptake!(status, ::Type{T}) where {T}
    fill!(
        status.soil_to_root_hydraulic_resistance_mpa_m2_ground_s_per_mmol,
        zero(T),
    )
    fill!(status.maximum_root_water_uptake_mmol_m2_ground_s, zero(T))
    fill!(status.root_water_uptake_fraction, zero(T))
    status.weighted_soil_water_potential_mpa = zero(T)
    status.total_maximum_root_water_uptake_mmol_m2_ground_s = zero(T)
    status.total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol = zero(T)
    status.root_water_uptake_available = false
    return nothing
end

@noinline function _throw_root_water_output_type(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and root-water-uptake output carriers must " *
            "share a floating-point type",
        ),
    )
end

@inline function _validate_root_water_output_vector(
    values,
    ::Type{T},
    layer_count::Int,
    name::Symbol,
) where {T}
    values isa AbstractVector || _throw_root_water_output_type(name)
    eltype(values) === T || _throw_root_water_output_type(name)
    length(values) == layer_count || throw(
        DimensionMismatch("$(String(name)) must contain $layer_count values"),
    )
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPARootWaterUptake,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.weighted_soil_water_potential_mpa)
    T <: AbstractFloat ||
        _throw_root_water_output_type(:weighted_soil_water_potential_mpa)
    _reset_root_water_uptake!(status, T)
    _validate_root_water_output_vector(
        status.soil_to_root_hydraulic_resistance_mpa_m2_ground_s_per_mmol,
        T,
        model.layer_count,
        :soil_to_root_hydraulic_resistance_mpa_m2_ground_s_per_mmol,
    )
    _validate_root_water_output_vector(
        status.maximum_root_water_uptake_mmol_m2_ground_s,
        T,
        model.layer_count,
        :maximum_root_water_uptake_mmol_m2_ground_s,
    )
    _validate_root_water_output_vector(
        status.root_water_uptake_fraction,
        T,
        model.layer_count,
        :root_water_uptake_fraction,
    )
    typeof(status.total_maximum_root_water_uptake_mmol_m2_ground_s) === T ||
        _throw_root_water_output_type(
            :total_maximum_root_water_uptake_mmol_m2_ground_s,
        )
    typeof(
        status.total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol,
    ) === T || _throw_root_water_output_type(
        :total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol,
    )

    active = status.root_water_uptake_active
    available = status.root_water_uptake_inputs_available
    active isa Bool || throw(
        ArgumentError("root_water_uptake_active must be Bool"),
    )
    available isa Bool || throw(
        ArgumentError("root_water_uptake_inputs_available must be Bool"),
    )
    active && available || return nothing

    leaf_area_index = _root_water_nonnegative(
        _root_water_float(
            T,
            status.total_leaf_area_index,
            :total_leaf_area_index,
        ),
        :total_leaf_area_index,
    )
    iszero(leaf_area_index) && return nothing

    scalars = try
        _root_water_uptake!(
            status.soil_to_root_hydraulic_resistance_mpa_m2_ground_s_per_mmol,
            status.maximum_root_water_uptake_mmol_m2_ground_s,
            status.root_water_uptake_fraction,
            model,
            status.rooted_soil_layer_indices,
            status.soil_water_potential_mpa,
            status.soil_hydraulic_conductivity_m_s,
            status.root_length_density_m_m3,
            status.soil_layer_thickness_m,
            status.soil_ice_fraction,
            status.fine_root_radius_m,
            status.minimum_root_water_potential_mpa,
            status.total_leaf_area_index,
            status.tree_height_m,
        )
    catch
        _reset_root_water_uptake!(status, T)
        rethrow()
    end
    scalars.hydraulic_path_available || return nothing
    status.weighted_soil_water_potential_mpa =
        scalars.weighted_soil_water_potential_mpa
    status.total_maximum_root_water_uptake_mmol_m2_ground_s =
        scalars.total_maximum_root_water_uptake_mmol_m2_ground_s
    status.total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol =
        scalars.total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol
    status.root_water_uptake_available = true
    return nothing
end
