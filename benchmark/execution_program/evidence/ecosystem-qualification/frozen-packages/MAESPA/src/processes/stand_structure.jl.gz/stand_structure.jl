PlantSimEngine.@process "target_leaf_area" verbose = false
PlantSimEngine.@process "stand_leaf_area_index" verbose = false

"""
Weight one Crown's physical `leaf_area` by its target-list multiplicity.

`target_leaf_area_contribution_m2` is the repeated contribution to the selected
stand, not the physical Crown area consumed by radiation. Repeated selections
must not change the Crown's geometry.
"""
struct MAESPATargetLeafArea{T<:AbstractFloat} <: AbstractTarget_Leaf_AreaModel
    zero_value::T
end

MAESPATargetLeafArea(::Type{T}) where {T<:AbstractFloat} =
    MAESPATargetLeafArea(zero(T))

PlantSimEngine.inputs_(::MAESPATargetLeafArea) = (
    leaf_area=PlantSimEngine.Required(Real),
    target_weight=PlantSimEngine.Required(Integer),
)
PlantSimEngine.outputs_(model::MAESPATargetLeafArea) = (
    target_leaf_area_contribution_m2=zero(model.zero_value),
    target_multiplicity=0,
)

function PlantSimEngine.run!(
    model::MAESPATargetLeafArea,
    status,
    environment,
    constants,
    context,
)
    status.target_weight isa Bool && throw(
        ArgumentError("target_weight must be an integer multiplicity, not Bool"),
    )
    status.target_weight >= 0 || throw(
        DomainError(status.target_weight, "target_weight must be non-negative"),
    )
    status.target_leaf_area_contribution_m2 = status.leaf_area * status.target_weight
    status.target_multiplicity = status.target_weight
    return nothing
end

"""Aggregate target-tree leaf area and normalize it by water-balance area."""
struct MAESPAStandLeafAreaIndex{T<:AbstractFloat} <: AbstractStand_Leaf_Area_IndexModel
    water_balance_area::T

    function MAESPAStandLeafAreaIndex(water_balance_area::T) where {T<:AbstractFloat}
        water_balance_area > zero(T) || throw(
            ArgumentError("water_balance_area must be positive"),
        )
        return new{T}(water_balance_area)
    end
end

PlantSimEngine.inputs_(::MAESPAStandLeafAreaIndex) = (
    target_leaf_areas=PlantSimEngine.Required(AbstractVector),
)
PlantSimEngine.outputs_(model::MAESPAStandLeafAreaIndex) = (
    stand_leaf_area=zero(model.water_balance_area),
    stand_lai=zero(model.water_balance_area),
)

function PlantSimEngine.run!(
    model::MAESPAStandLeafAreaIndex,
    status,
    environment,
    constants,
    context,
)
    total = zero(model.water_balance_area)
    for leaf_area in status.target_leaf_areas
        total += leaf_area
    end
    status.stand_leaf_area = total
    status.stand_lai = total / model.water_balance_area
    return nothing
end
