"""Gross C3, C4 and blended assimilation for one understorey patch."""
struct UnderstoreyC3C4PhotosynthesisResult{T<:AbstractFloat}
    c3_gross_assimilation_umol_co2_m2_ground_s::T
    c4_gross_assimilation_umol_co2_m2_ground_s::T
    gross_assimilation_umol_co2_m2_ground_s::T
    exchange_active::Bool
end

"""
Historical MAESPA C3/C4 understorey photosynthesis alternative.

The C4 kernel intentionally retains two legacy numerical conventions for the
first faithful MAESPA implementation: direct PAR is converted with
`photons_per_joule` while diffuse PAR enters the Collatz equations with its
W m⁻² numerical value, and sunlit LAI is used as the sunlit/shaded mixing
weight. These conventions are local to this model. Patch APAR remains owned by
`understorey_shortwave_absorption` and is never overwritten by physiology.
"""
struct MAESPAUnderstoreyC3C4Photosynthesis{T<:AbstractFloat} <:
       AbstractUnderstorey_PhotosynthesisModel
    c3::MAESPAUnderstoreyBewdyPhotosynthesis{T}
    c4::UnderstoreyC4Physiology{T}
    c4_fraction::T
    gas_constant_j_mol_k::T
    kelvin_offset_c::T
    light_carboxylation_curvature::T
    co2_colimitation_curvature::T
    initial_co2_slope::T
    quantum_efficiency::T

    function MAESPAUnderstoreyC3C4Photosynthesis{T}(
        c3::MAESPAUnderstoreyBewdyPhotosynthesis{T},
        c4::UnderstoreyC4Physiology{T},
        c4_fraction::T,
        gas_constant_j_mol_k::T,
        kelvin_offset_c::T,
        light_carboxylation_curvature::T,
        co2_colimitation_curvature::T,
        initial_co2_slope::T,
        quantum_efficiency::T,
    ) where {T<:AbstractFloat}
        all(
            isfinite,
            (
                c4_fraction,
                gas_constant_j_mol_k,
                kelvin_offset_c,
                light_carboxylation_curvature,
                co2_colimitation_curvature,
                initial_co2_slope,
                quantum_efficiency,
            ),
        ) || throw(ArgumentError("understorey C3/C4 parameters must be finite"))
        zero(T) < c4_fraction <= one(T) || throw(
            DomainError(
                c4_fraction,
                "C3/C4 photosynthesis requires 0 < c4_fraction <= 1",
            ),
        )
        gas_constant_j_mol_k > zero(T) || throw(
            DomainError(gas_constant_j_mol_k, "gas constant must be positive"),
        )
        kelvin_offset_c > zero(T) || throw(
            DomainError(kelvin_offset_c, "kelvin offset must be positive"),
        )
        zero(T) < light_carboxylation_curvature <= one(T) || throw(
            DomainError(
                light_carboxylation_curvature,
                "C4 light/carboxylation curvature must lie in (0, 1]",
            ),
        )
        zero(T) < co2_colimitation_curvature <= one(T) || throw(
            DomainError(
                co2_colimitation_curvature,
                "C4 CO2 co-limitation curvature must lie in (0, 1]",
            ),
        )
        initial_co2_slope > zero(T) || throw(
            DomainError(initial_co2_slope, "C4 initial CO2 slope must be positive"),
        )
        quantum_efficiency > zero(T) || throw(
            DomainError(quantum_efficiency, "C4 quantum efficiency must be positive"),
        )
        return new{T}(
            c3,
            c4,
            c4_fraction,
            gas_constant_j_mol_k,
            kelvin_offset_c,
            light_carboxylation_curvature,
            co2_colimitation_curvature,
            initial_co2_slope,
            quantum_efficiency,
        )
    end
end

function MAESPAUnderstoreyC3C4Photosynthesis(
    c3::MAESPAUnderstoreyBewdyPhotosynthesis{T},
    c4::UnderstoreyC4Physiology{T},
    c4_fraction::Real;
    gas_constant_j_mol_k::Real=T(8.314),
    kelvin_offset_c::Real=T(273.15),
    light_carboxylation_curvature::Real=T(0.83),
    co2_colimitation_curvature::Real=T(0.83),
    initial_co2_slope::Real=T(0.7),
    quantum_efficiency::Real=T(0.06),
) where {T<:AbstractFloat}
    values = (
        c4_fraction,
        gas_constant_j_mol_k,
        kelvin_offset_c,
        light_carboxylation_curvature,
        co2_colimitation_curvature,
        initial_co2_slope,
        quantum_efficiency,
    )
    any(value -> value isa Bool, values) && throw(
        ArgumentError("understorey C3/C4 parameters must be numeric, not Bool"),
    )
    return MAESPAUnderstoreyC3C4Photosynthesis{T}(
        c3,
        c4,
        map(value -> convert(T, value), values)...,
    )
end

function MAESPAUnderstoreyC3C4Photosynthesis(
    config::UnderstoreyConfig{T};
    kwargs...,
) where {T<:AbstractFloat}
    c4 = config.physiology.c4
    isnothing(c4) && throw(
        ArgumentError("C3/C4 photosynthesis requires USC4PARS"),
    )
    return MAESPAUnderstoreyC3C4Photosynthesis(
        MAESPAUnderstoreyBewdyPhotosynthesis(config),
        c4,
        config.physiology.c4_fraction;
        kwargs...,
    )
end

@inline function _understorey_c4_diffuse_scaling(x::T) where {T<:AbstractFloat}
    iszero(x) && return one(T)
    return -expm1(-x) / x
end

function understorey_collatz_c4_photosynthesis(
    model::MAESPAUnderstoreyC3C4Photosynthesis,
    direct_par_w_m2::Real,
    diffuse_par_w_m2::Real,
    sunlit_leaf_area_index::Real,
    leaf_area_index::Real,
    air_temperature_c::Real,
    atmospheric_co2_umol_mol::Real;
    astronomical_daylight::Bool=true,
)
    values = (
        direct_par_w_m2,
        diffuse_par_w_m2,
        sunlit_leaf_area_index,
        leaf_area_index,
        air_temperature_c,
        atmospheric_co2_umol_mol,
    )
    T = promote_type(
        typeof(model.c4_fraction),
        map(value -> typeof(float(value)), values)...,
    )
    return understorey_collatz_c4_photosynthesis(
        T,
        model,
        values...;
        astronomical_daylight,
    )
end

function understorey_collatz_c4_photosynthesis(
    ::Type{T},
    model::MAESPAUnderstoreyC3C4Photosynthesis,
    direct_par_w_m2::Real,
    diffuse_par_w_m2::Real,
    sunlit_leaf_area_index::Real,
    leaf_area_index::Real,
    air_temperature_c::Real,
    atmospheric_co2_umol_mol::Real;
    astronomical_daylight::Bool=true,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("C4 photosynthesis calculation type must be concrete"),
    )
    values = (
        direct_par_w_m2,
        diffuse_par_w_m2,
        sunlit_leaf_area_index,
        leaf_area_index,
        air_temperature_c,
        atmospheric_co2_umol_mol,
    )
    any(value -> value isa Bool, values) && throw(
        ArgumentError("C4 photosynthesis inputs must be numeric, not Bool"),
    )
    direct, diffuse, sunlit_lai, lai, temperature, co2 =
        map(value -> convert(T, value), values)
    all(isfinite, (direct, diffuse, sunlit_lai, lai, temperature, co2)) || throw(
        ArgumentError("C4 photosynthesis inputs must be finite"),
    )
    direct >= zero(T) && diffuse >= zero(T) || throw(
        DomainError((direct, diffuse), "understorey PAR must be non-negative"),
    )
    sunlit_lai >= zero(T) && lai >= zero(T) || throw(
        DomainError((sunlit_lai, lai), "understorey LAI must be non-negative"),
    )
    sunlit_lai <= lai + T(32) * eps(T) * max(one(T), lai) || throw(
        DomainError(sunlit_lai, "sunlit LAI must not exceed total LAI"),
    )
    temperature > -convert(T, model.kelvin_offset_c) || throw(
        DomainError(temperature, "air_temperature_c must be above absolute zero"),
    )
    co2 > zero(T) || throw(
        DomainError(co2, "atmospheric_co2_umol_mol must be positive"),
    )
    c3 = model.c3
    absorptance = convert(T, c3.par_absorptance)
    if !astronomical_daylight || iszero(lai) || iszero(absorptance)
        return UnderstoreyPhotosynthesisResult{T}(zero(T), false)
    end

    extinction = convert(T, c3.vertical_extinction_coefficient)
    photons_per_joule = convert(T, c3.photons_per_joule)
    direct_photons = photons_per_joule * direct
    x = sqrt(absorptance) * extinction * lai
    # Legacy MAESPA passes diffuse W m⁻² unchanged while converting the direct
    # component to photons. Keep that numerical convention local and visible.
    shaded_par = diffuse * _understorey_c4_diffuse_scaling(x)
    sunlit_par = absorptance * (extinction * direct_photons + shaded_par)

    physiology = model.c4
    vcmax = _capacity_vcmax(
        convert(T, physiology.vcmax25_umol_co2_m2_s),
        temperature,
        convert(T, physiology.vcmax_activation_energy_j_mol),
        convert(T, physiology.vcmax_deactivation_energy_j_mol),
        convert(T, physiology.vcmax_entropy_j_mol_k),
        convert(T, physiology.low_temperature_ramp_upper_c),
        convert(T, physiology.low_temperature_ramp_lower_c),
        convert(T, model.gas_constant_j_mol_k),
        convert(T, model.kelvin_offset_c),
    )
    beta_light = convert(T, model.light_carboxylation_curvature)
    beta_co2 = convert(T, model.co2_colimitation_curvature)
    quantum_efficiency = convert(T, model.quantum_efficiency)
    co2_limited_flux = convert(T, model.initial_co2_slope) *
                       convert(T, physiology.ci_to_ca_ratio) * co2
    sunlit_light_flux = quantum_efficiency * sunlit_par
    shaded_light_flux = quantum_efficiency * shaded_par
    sunlit_capacity = _understorey_smaller_quadratic_root(
        beta_light,
        -(vcmax + sunlit_light_flux),
        vcmax * sunlit_light_flux,
    )
    shaded_capacity = _understorey_smaller_quadratic_root(
        beta_light,
        -(vcmax + shaded_light_flux),
        vcmax * shaded_light_flux,
    )
    sunlit_assimilation = _understorey_smaller_quadratic_root(
        beta_co2,
        -(sunlit_capacity + co2_limited_flux),
        sunlit_capacity * co2_limited_flux,
    )
    shaded_assimilation = _understorey_smaller_quadratic_root(
        beta_co2,
        -(shaded_capacity + co2_limited_flux),
        shaded_capacity * co2_limited_flux,
    )
    # SUNLA is an absolute sunlit LAI upstream, but COLLATZC4 historically
    # uses it as this mixing weight. A future corrected model must be a
    # separate PlantSimEngine alternative rather than a silent equation edit.
    gross = lai * (
        sunlit_lai * sunlit_assimilation +
        (one(T) - sunlit_lai) * shaded_assimilation
    )
    isfinite(gross) && gross >= zero(T) || throw(
        DomainError(gross, "C4 gross assimilation must be finite and non-negative"),
    )
    return UnderstoreyPhotosynthesisResult{T}(gross, true)
end

function understorey_c3c4_photosynthesis(
    ::Type{T},
    model::MAESPAUnderstoreyC3C4Photosynthesis,
    direct_par_w_m2::Real,
    diffuse_par_w_m2::Real,
    sunlit_leaf_area_index::Real,
    canopy_interception_fraction::Real,
    leaf_area_index::Real,
    top_leaf_nitrogen_g_m2::Real,
    alpha::Real,
    lambda::Real,
    air_temperature_c::Real,
    atmospheric_co2_umol_mol::Real;
    astronomical_daylight::Bool=true,
) where {T<:AbstractFloat}
    fraction = convert(T, model.c4_fraction)
    c3_result = if fraction < one(T)
        understorey_bewdy_photosynthesis(
            T,
            model.c3,
            direct_par_w_m2,
            diffuse_par_w_m2,
            sunlit_leaf_area_index,
            canopy_interception_fraction,
            top_leaf_nitrogen_g_m2,
            alpha,
            lambda;
            astronomical_daylight,
        )
    else
        UnderstoreyPhotosynthesisResult{T}(zero(T), false)
    end
    c4_result = understorey_collatz_c4_photosynthesis(
        T,
        model,
        direct_par_w_m2,
        diffuse_par_w_m2,
        sunlit_leaf_area_index,
        leaf_area_index,
        air_temperature_c,
        atmospheric_co2_umol_mol;
        astronomical_daylight,
    )
    c3_gross = c3_result.gross_assimilation_umol_co2_m2_ground_s
    c4_gross = c4_result.gross_assimilation_umol_co2_m2_ground_s
    gross = muladd(fraction, c4_gross, (one(T) - fraction) * c3_gross)
    return UnderstoreyC3C4PhotosynthesisResult{T}(
        c3_gross,
        c4_gross,
        gross,
        c3_result.exchange_active || c4_result.exchange_active,
    )
end


function understorey_c3c4_photosynthesis(
    model::MAESPAUnderstoreyC3C4Photosynthesis,
    direct_par_w_m2::Real,
    diffuse_par_w_m2::Real,
    sunlit_leaf_area_index::Real,
    canopy_interception_fraction::Real,
    leaf_area_index::Real,
    top_leaf_nitrogen_g_m2::Real,
    alpha::Real,
    lambda::Real,
    air_temperature_c::Real,
    atmospheric_co2_umol_mol::Real;
    astronomical_daylight::Bool=true,
)
    values = (
        direct_par_w_m2,
        diffuse_par_w_m2,
        sunlit_leaf_area_index,
        canopy_interception_fraction,
        leaf_area_index,
        top_leaf_nitrogen_g_m2,
        alpha,
        lambda,
        air_temperature_c,
        atmospheric_co2_umol_mol,
    )
    T = promote_type(
        typeof(model.c4_fraction),
        map(value -> typeof(float(value)), values)...,
    )
    return understorey_c3c4_photosynthesis(
        T,
        model,
        values...;
        astronomical_daylight,
    )
end

PlantSimEngine.inputs_(::MAESPAUnderstoreyC3C4Photosynthesis) = (
    understorey_direct_par_w_m2=PlantSimEngine.Required(Real),
    understorey_diffuse_par_w_m2=PlantSimEngine.Required(Real),
    understorey_sunlit_leaf_area_index=PlantSimEngine.Required(Real),
    understorey_canopy_interception_fraction=PlantSimEngine.Required(Real),
    understorey_leaf_area_index=PlantSimEngine.Required(Real),
    understorey_top_leaf_nitrogen_g_m2=PlantSimEngine.Required(Real),
    understorey_bewdy_alpha=PlantSimEngine.Required(Real),
    understorey_bewdy_lambda=PlantSimEngine.Required(Real),
    air_temperature_c=PlantSimEngine.Required(Real),
    co2_umol_mol=PlantSimEngine.Required(Real),
    astronomical_daylight=PlantSimEngine.Required(Bool),
    understorey_shortwave_absorption_available=PlantSimEngine.Default(true),
    understorey_bewdy_parameters_available=PlantSimEngine.Default(true),
    meteorology_reconstruction_available=PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(
    ::MAESPAUnderstoreyC3C4Photosynthesis{T},
) where {T} = (
    understorey_c3_gross_assimilation_umol_co2_m2_ground_s=zero(T),
    understorey_c4_gross_assimilation_umol_co2_m2_ground_s=zero(T),
    understorey_gross_assimilation_umol_co2_m2_ground_s=zero(T),
    understorey_exchange_active=false,
    understorey_photosynthesis_available=false,
)

PlantSimEngine.variable_contracts_(::MAESPAUnderstoreyC3C4Photosynthesis) = (
    understorey_direct_par_w_m2=UNDERSTOREY_DIRECT_BEAM_PAR_CONTRACT,
    understorey_diffuse_par_w_m2=UNDERSTOREY_PATCH_PAR_CONTRACT,
    understorey_sunlit_leaf_area_index=UNDERSTOREY_LOCAL_LAI_CONTRACT,
    understorey_leaf_area_index=UNDERSTOREY_LOCAL_LAI_CONTRACT,
    understorey_canopy_interception_fraction=
        UNDERSTOREY_LOCAL_FRACTION_CONTRACT,
    understorey_c3_gross_assimilation_umol_co2_m2_ground_s=
        UNDERSTOREY_LOCAL_CO2_FLUX_CONTRACT,
    understorey_c4_gross_assimilation_umol_co2_m2_ground_s=
        UNDERSTOREY_LOCAL_CO2_FLUX_CONTRACT,
    understorey_gross_assimilation_umol_co2_m2_ground_s=
        UNDERSTOREY_LOCAL_CO2_FLUX_CONTRACT,
)

function PlantSimEngine.run!(
    model::MAESPAUnderstoreyC3C4Photosynthesis,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.understorey_gross_assimilation_umol_co2_m2_ground_s)
    T <: AbstractFloat || throw(
        ArgumentError("understorey photosynthesis outputs must be floating-point values"),
    )
    status.understorey_c3_gross_assimilation_umol_co2_m2_ground_s = zero(T)
    status.understorey_c4_gross_assimilation_umol_co2_m2_ground_s = zero(T)
    _reset_understorey_photosynthesis!(status, T)
    flags = (
        status.understorey_shortwave_absorption_available,
        status.understorey_bewdy_parameters_available,
        status.meteorology_reconstruction_available,
    )
    all(flag -> flag isa Bool, flags) || throw(
        ArgumentError("understorey photosynthesis availability flags must be Bool"),
    )
    all(flags) || return nothing
    daylight = status.astronomical_daylight
    daylight isa Bool || throw(ArgumentError("astronomical_daylight must be Bool"))
    result = understorey_c3c4_photosynthesis(
        T,
        model,
        status.understorey_direct_par_w_m2,
        status.understorey_diffuse_par_w_m2,
        status.understorey_sunlit_leaf_area_index,
        status.understorey_canopy_interception_fraction,
        status.understorey_leaf_area_index,
        status.understorey_top_leaf_nitrogen_g_m2,
        status.understorey_bewdy_alpha,
        status.understorey_bewdy_lambda,
        status.air_temperature_c,
        status.co2_umol_mol;
        astronomical_daylight=daylight,
    )
    status.understorey_c3_gross_assimilation_umol_co2_m2_ground_s =
        result.c3_gross_assimilation_umol_co2_m2_ground_s
    status.understorey_c4_gross_assimilation_umol_co2_m2_ground_s =
        result.c4_gross_assimilation_umol_co2_m2_ground_s
    status.understorey_gross_assimilation_umol_co2_m2_ground_s =
        result.gross_assimilation_umol_co2_m2_ground_s
    status.understorey_exchange_active = result.exchange_active
    status.understorey_photosynthesis_available = true
    return nothing
end

"""Legacy C3/C4 blend of whole-patch stomatal conductances."""
struct MAESPAUnderstoreyC3C4StomatalConductance{
    T<:AbstractFloat,
    S<:AbstractUnderstoreyStomatalParameters{T},
} <: AbstractUnderstorey_Stomatal_ConductanceModel
    c3::MAESPAUnderstoreyStomatalConductance{T,S}
    c4_ci_to_ca_ratio::T
    c4_fraction::T

    function MAESPAUnderstoreyC3C4StomatalConductance{T,S}(
        c3::MAESPAUnderstoreyStomatalConductance{T,S},
        c4_ci_to_ca_ratio::T,
        c4_fraction::T,
    ) where {T<:AbstractFloat,S<:AbstractUnderstoreyStomatalParameters{T}}
        isfinite(c4_ci_to_ca_ratio) &&
            zero(T) <= c4_ci_to_ca_ratio < one(T) || throw(
            DomainError(c4_ci_to_ca_ratio, "C4 Ci/Ca ratio must lie in [0, 1)"),
        )
        isfinite(c4_fraction) && zero(T) < c4_fraction <= one(T) || throw(
            DomainError(c4_fraction, "C4 fraction must lie in (0, 1]"),
        )
        return new{T,S}(c3, c4_ci_to_ca_ratio, c4_fraction)
    end
end

function MAESPAUnderstoreyC3C4StomatalConductance(
    c3::MAESPAUnderstoreyStomatalConductance{T,S},
    c4_ci_to_ca_ratio::Real,
    c4_fraction::Real,
) where {T<:AbstractFloat,S<:AbstractUnderstoreyStomatalParameters{T}}
    values = (c4_ci_to_ca_ratio, c4_fraction)
    any(value -> value isa Bool, values) && throw(
        ArgumentError("C3/C4 conductance parameters must be numeric, not Bool"),
    )
    return MAESPAUnderstoreyC3C4StomatalConductance{T,S}(
        c3,
        convert(T, c4_ci_to_ca_ratio),
        convert(T, c4_fraction),
    )
end

function MAESPAUnderstoreyC3C4StomatalConductance(
    config::UnderstoreyConfig{T,S},
) where {T<:AbstractFloat,S<:AbstractUnderstoreyStomatalParameters{T}}
    c4 = config.physiology.c4
    isnothing(c4) && throw(
        ArgumentError("C3/C4 stomatal conductance requires USC4PARS"),
    )
    return MAESPAUnderstoreyC3C4StomatalConductance{T,S}(
        MAESPAUnderstoreyStomatalConductance(config),
        c4.ci_to_ca_ratio,
        config.physiology.c4_fraction,
    )
end

function understorey_c3c4_stomatal_conductance(
    ::Type{T},
    model::MAESPAUnderstoreyC3C4StomatalConductance,
    c3_gross_assimilation_umol_co2_m2_ground_s::Real,
    c4_gross_assimilation_umol_co2_m2_ground_s::Real,
    relative_humidity::Real,
    atmospheric_co2_umol_mol::Real;
    exchange_active::Bool=true,
) where {T<:AbstractFloat}
    c3_gross = convert(T, c3_gross_assimilation_umol_co2_m2_ground_s)
    c4_gross = convert(T, c4_gross_assimilation_umol_co2_m2_ground_s)
    humidity = convert(T, relative_humidity)
    co2 = convert(T, atmospheric_co2_umol_mol)
    all(isfinite, (c3_gross, c4_gross, humidity, co2)) || throw(
        ArgumentError("C3/C4 conductance inputs must be finite"),
    )
    c3_gross >= zero(T) && c4_gross >= zero(T) || throw(
        DomainError((c3_gross, c4_gross), "gross assimilation must be non-negative"),
    )
    zero(T) <= humidity <= one(T) || throw(
        DomainError(humidity, "relative_humidity must lie between zero and one"),
    )
    co2 > zero(T) || throw(
        DomainError(co2, "atmospheric_co2_umol_mol must be positive"),
    )
    exchange_active || return UnderstoreyStomatalConductanceResult{T}(
        zero(T),
        zero(T),
    )
    fraction = convert(T, model.c4_fraction)
    c3_conductance = if fraction < one(T)
        understorey_stomatal_conductance(
            T,
            model.c3,
            c3_gross,
            humidity,
            co2;
            exchange_active=true,
        ).co2_mol_m2_ground_s
    else
        zero(T)
    end
    c4_conductance = c4_gross /
                     (co2 * (one(T) - convert(T, model.c4_ci_to_ca_ratio)))
    co2_conductance = muladd(
        fraction,
        c4_conductance,
        (one(T) - fraction) * c3_conductance,
    )
    ratio = convert(T, model.c3.water_to_co2_conductance_ratio)
    return UnderstoreyStomatalConductanceResult{T}(
        co2_conductance,
        ratio * co2_conductance,
    )
end


function understorey_c3c4_stomatal_conductance(
    model::MAESPAUnderstoreyC3C4StomatalConductance,
    c3_gross_assimilation_umol_co2_m2_ground_s::Real,
    c4_gross_assimilation_umol_co2_m2_ground_s::Real,
    relative_humidity::Real,
    atmospheric_co2_umol_mol::Real;
    exchange_active::Bool=true,
)
    values = (
        c3_gross_assimilation_umol_co2_m2_ground_s,
        c4_gross_assimilation_umol_co2_m2_ground_s,
        relative_humidity,
        atmospheric_co2_umol_mol,
    )
    T = promote_type(
        typeof(model.c4_fraction),
        map(value -> typeof(float(value)), values)...,
    )
    return understorey_c3c4_stomatal_conductance(
        T,
        model,
        values...;
        exchange_active,
    )
end

PlantSimEngine.inputs_(::MAESPAUnderstoreyC3C4StomatalConductance) = (
    understorey_c3_gross_assimilation_umol_co2_m2_ground_s=
        PlantSimEngine.Required(Real),
    understorey_c4_gross_assimilation_umol_co2_m2_ground_s=
        PlantSimEngine.Required(Real),
    relative_humidity=PlantSimEngine.Required(Real),
    co2_umol_mol=PlantSimEngine.Required(Real),
    understorey_exchange_active=PlantSimEngine.Required(Bool),
    understorey_photosynthesis_available=PlantSimEngine.Default(true),
    meteorology_reconstruction_available=PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(
    ::MAESPAUnderstoreyC3C4StomatalConductance{T},
) where {T} = (
    understorey_stomatal_conductance_co2_mol_m2_ground_s=zero(T),
    understorey_stomatal_conductance_h2o_mol_m2_ground_s=zero(T),
    understorey_stomatal_conductance_available=false,
)

PlantSimEngine.variable_contracts_(
    ::MAESPAUnderstoreyC3C4StomatalConductance,
) = (
    understorey_c3_gross_assimilation_umol_co2_m2_ground_s=
        UNDERSTOREY_LOCAL_CO2_FLUX_CONTRACT,
    understorey_c4_gross_assimilation_umol_co2_m2_ground_s=
        UNDERSTOREY_LOCAL_CO2_FLUX_CONTRACT,
    understorey_stomatal_conductance_co2_mol_m2_ground_s=
        UNDERSTOREY_LOCAL_CO2_CONDUCTANCE_CONTRACT,
    understorey_stomatal_conductance_h2o_mol_m2_ground_s=
        UNDERSTOREY_LOCAL_H2O_CONDUCTANCE_CONTRACT,
)

function PlantSimEngine.run!(
    model::MAESPAUnderstoreyC3C4StomatalConductance,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.understorey_stomatal_conductance_co2_mol_m2_ground_s)
    T <: AbstractFloat || throw(
        ArgumentError("understorey conductance outputs must be floating-point values"),
    )
    status.understorey_stomatal_conductance_co2_mol_m2_ground_s = zero(T)
    status.understorey_stomatal_conductance_h2o_mol_m2_ground_s = zero(T)
    status.understorey_stomatal_conductance_available = false
    flags = (
        status.understorey_photosynthesis_available,
        status.meteorology_reconstruction_available,
    )
    all(flag -> flag isa Bool, flags) || throw(
        ArgumentError("understorey conductance availability flags must be Bool"),
    )
    all(flags) || return nothing
    active = status.understorey_exchange_active
    active isa Bool || throw(ArgumentError("understorey_exchange_active must be Bool"))
    result = understorey_c3c4_stomatal_conductance(
        T,
        model,
        status.understorey_c3_gross_assimilation_umol_co2_m2_ground_s,
        status.understorey_c4_gross_assimilation_umol_co2_m2_ground_s,
        status.relative_humidity,
        status.co2_umol_mol;
        exchange_active=active,
    )
    status.understorey_stomatal_conductance_co2_mol_m2_ground_s =
        result.co2_mol_m2_ground_s
    status.understorey_stomatal_conductance_h2o_mol_m2_ground_s =
        result.h2o_mol_m2_ground_s
    status.understorey_stomatal_conductance_available = true
    return nothing
end
