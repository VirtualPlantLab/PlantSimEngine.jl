# Contracts describe each element; point identities, spectral/class axes and
# validity gates remain explicit parts of the documented radiation schemas.
# Held diffuse/EHC values are accepted instantaneous states, not daily means.
const LEAF_DIFFUSE_TRANSMITTANCE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:fraction, basis=:leaf,
    temporal=:instantaneous, aggregation=:state, extent=:intensive,
)

# RELDF is extinction-weighted penetration, not TU/TD or a probability. Its
# directional numerator need not be <= the sky normalizer, so values may > 1.
const LEAF_RELATIVE_DIFFUSE_PENETRATION_CONTRACT = PlantSimEngine.VariableContract(
    unit=:dimensionless, basis=:leaf,
    temporal=:instantaneous, aggregation=:state, extent=:intensive,
)
const DIFFUSE_TRANSMISSION_AVAILABLE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:boolean, basis=:diffuse_transmission,
    temporal=:instantaneous, aggregation=:state, extent=:intensive,
)
const DIFFUSE_TRANSMISSION_CONTRACTS = (
    diffuse_transmittance_up=LEAF_DIFFUSE_TRANSMITTANCE_CONTRACT,
    diffuse_transmittance_down=LEAF_DIFFUSE_TRANSMITTANCE_CONTRACT,
    relative_diffuse_penetration=LEAF_RELATIVE_DIFFUSE_PENETRATION_CONTRACT,
    diffuse_transmission_available=DIFFUSE_TRANSMISSION_AVAILABLE_CONTRACT,
)

# These virtual optical layers belong to each sampling point's constructed
# equivalent canopy. They are not geometric or physiological canopy layers.
# Counts/indices are non-additive metadata, hence intensive rather than totals.
const EQUIVALENT_CANOPY_LAYER_COUNT_CONTRACT = PlantSimEngine.VariableContract(
    unit=:count, basis=:equivalent_canopy,
    temporal=:instantaneous, aggregation=:state, extent=:intensive,
)
const EQUIVALENT_CANOPY_LAYER_INDEX_CONTRACT = PlantSimEngine.VariableContract(
    unit=:index, basis=:equivalent_canopy,
    temporal=:instantaneous, aggregation=:state, extent=:intensive,
)
const EQUIVALENT_CANOPY_DIFFUSE_TRANSMITTANCE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:fraction, basis=:equivalent_canopy_layer,
    temporal=:instantaneous, aggregation=:state, extent=:intensive,
)
const EQUIVALENT_CANOPY_AVAILABLE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:boolean, basis=:equivalent_canopy,
    temporal=:instantaneous, aggregation=:state, extent=:intensive,
)
const EQUIVALENT_CANOPY_CONTRACTS = (
    equivalent_point_layer_count=EQUIVALENT_CANOPY_LAYER_COUNT_CONTRACT,
    equivalent_point_layer_index=EQUIVALENT_CANOPY_LAYER_INDEX_CONTRACT,
    equivalent_diffuse_transmittance=EQUIVALENT_CANOPY_DIFFUSE_TRANSMITTANCE_CONTRACT,
    equivalent_canopy_available=EQUIVALENT_CANOPY_AVAILABLE_CONTRACT,
)

# Longwave exchange additionally needs prepared thermal/temperature forcing.
# Its validity is not the held EHC gate: keeping distinct port names also keeps
# their canonical Crown status references independent during atmosphere trials.
const LONGWAVE_FORCING_AVAILABLE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:boolean, basis=:longwave_forcing,
    temporal=:instantaneous, aggregation=:state, extent=:intensive,
)

# MODELSS classes partition the represented leaf area at each point. Absorbed
# irradiance is conditional on a class's leaf area, including shaded and mean
# classes; a universal :sunlit_leaf_area basis would be incorrect.
const LEAF_RADIATION_AREA_FRACTION_CONTRACT = PlantSimEngine.VariableContract(
    unit=:fraction, basis=:leaf_area,
    temporal=:instantaneous, aggregation=:radiation_class_partition, extent=:intensive,
)
const ABSORBED_LEAF_PAR_IRRADIANCE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:joule_par, basis=:leaf_area,
    temporal=:second, aggregation=:local, extent=:intensive,
)
const ABSORBED_LEAF_NIR_IRRADIANCE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:joule, basis=:leaf_area,
    temporal=:second, aggregation=:local, extent=:intensive,
)
const LEAF_RADIATION_CLASS_COUNT_CONTRACT = PlantSimEngine.VariableContract(
    unit=:count, basis=:radiation_class,
    temporal=:instantaneous, aggregation=:state, extent=:intensive,
)
const LEAF_RADIATION_PARTITION_AVAILABLE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:boolean, basis=:leaf_radiation_partition,
    temporal=:instantaneous, aggregation=:state, extent=:intensive,
)
const LEAF_RADIATION_PARTITION_CONTRACTS = (
    leaf_radiation_area_fraction=LEAF_RADIATION_AREA_FRACTION_CONTRACT,
    leaf_radiation_absorbed_par_w_m2_leaf=ABSORBED_LEAF_PAR_IRRADIANCE_CONTRACT,
    leaf_radiation_absorbed_nir_w_m2_leaf=ABSORBED_LEAF_NIR_IRRADIANCE_CONTRACT,
    active_leaf_radiation_class_count=LEAF_RADIATION_CLASS_COUNT_CONTRACT,
    leaf_radiation_partitioning_available=LEAF_RADIATION_PARTITION_AVAILABLE_CONTRACT,
)

# SCATTER multiplies its dimensionless upward top-of-EHC profile by incident
# horizontal irradiance. Slope factors change transport, not this reference.
# Each point x 2 entry retains that incident-normalization basis: PAR column 1,
# NIR column 2. This is neither PAR-only energy, a band sum, a leaf-area mean,
# nor flux per physical inclined ground surface. Soil scale-up averages point
# rows per band and subtracts their target-weighted mean from incident flux.
const SCATTERED_LOST_SHORTWAVE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:joule, basis=:horizontal_area,
    temporal=:second, aggregation=:local, extent=:intensive,
)
const SHORTWAVE_SCATTERING_AVAILABLE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:boolean, basis=:shortwave_scattering,
    temporal=:instantaneous, aggregation=:state, extent=:intensive,
)
const SHORTWAVE_SCATTERING_CONTRACTS = (
    scattered_lost_shortwave_w_m2=SCATTERED_LOST_SHORTWAVE_CONTRACT,
    shortwave_scattering_available=SHORTWAVE_SCATTERING_AVAILABLE_CONTRACT,
)

const CROWN_RADIATION_CACHE_CONTRACTS = merge(
    DIFFUSE_TRANSMISSION_CONTRACTS, EQUIVALENT_CANOPY_CONTRACTS,
)
const CROWN_RADIATION_CONTRACTS = merge(
    CROWN_RADIATION_CACHE_CONTRACTS,
    LEAF_RADIATION_PARTITION_CONTRACTS, SHORTWAVE_SCATTERING_CONTRACTS,
)

# Layout changes array axes from geometric points to logical leaf units, not
# the physical meaning of these three fields. Controllers inherit that meaning.
const LOGICAL_LEAF_DIFFUSE_RADIATION_CONTRACTS = (
    logical_leaf_relative_diffuse_penetration=LEAF_RELATIVE_DIFFUSE_PENETRATION_CONTRACT,
    logical_leaf_diffuse_transmittance_up=LEAF_DIFFUSE_TRANSMITTANCE_CONTRACT,
    logical_leaf_diffuse_transmittance_down=LEAF_DIFFUSE_TRANSMITTANCE_CONTRACT,
)
