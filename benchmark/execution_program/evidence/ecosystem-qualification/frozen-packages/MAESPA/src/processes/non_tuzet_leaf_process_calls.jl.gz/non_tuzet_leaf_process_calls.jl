# Crown coordination: each point owns its replaceable energy/photosynthesis solve.
PlantSimEngine.dep(::MAESPANonTuzetCrownLeafExchangeController) = (
    energy_balance=PlantSimEngine.Call(PlantSimEngine.Many(
        scale=:LogicalLeafUnit, kind=:logical_leaf_unit, within=PlantSimEngine.Subtree(),
        process=:leaf_energy_balance_controller)),
)

_leaf_exchange_standard_pressure(model::MAESPANonTuzetCrownLeafExchangeController, T) =
    convert(T, model.night_exchange_model.standard_atmospheric_pressure_pa)
_leaf_exchange_standard_pressure(model::MAESPATuzetCrownLeafExchangeController, T) =
    convert(T, model.standard_atmospheric_pressure_pa)

# Boundary conversion follows the effective status type (including the
# PlantSimEngine type_promotion mapping), not a hard-coded model precision.
function _leaf_exchange_forcing(model, status, environment, ::Type{T}) where {T}
    forcing = NamedTuple{_NON_TUZET_CROWN_FLOAT_SCALAR_INPUTS}(map(
        name -> convert(T, getproperty(name in _MAESPA_CANOPY_ATMOSPHERE_AIR_FIELDS ?
            environment : status, name)), _NON_TUZET_CROWN_FLOAT_SCALAR_INPUTS))
    daylight = isnothing(status.leaf_exchange_daylight) ?
        abs(forcing.sun_zenith_rad) < T(pi) / T(2) &&
        forcing.incident_par_w_m2 > one(T) && forcing.logical_leaf_area_total_m2 > zero(T) :
        status.leaf_exchange_daylight
    return merge(forcing, (
        stomatal_sides=status.stomatal_sides,
        second_stomatal_curve=status.second_stomatal_curve,
        emax_non_tuzet_constraint_active=model isa MAESPANonTuzetCrownLeafExchangeController &&
            status.emax_non_tuzet_constraint_active,
        leaf_exchange_daylight=daylight,
        flux_window_seconds=T(model isa MAESPATuzetCrownLeafExchangeController ?
            model.flux_window_seconds : model.surface_water_partition_model.flux_window_seconds),
    ))
end

function _non_tuzet_leaf_process_solution(model, status, environment, context, ::Type{T}) where {T}
    vectors = NamedTuple{_NON_TUZET_CROWN_FLOAT_VECTOR_INPUTS}(map(
        name -> getproperty(status, name), _NON_TUZET_CROWN_FLOAT_VECTOR_INPUTS))
    forcing = _leaf_exchange_forcing(model, status, environment, T)
    active = status.logical_leaf_unit_active
    if any(unit -> active[unit] && !status.logical_leaf_unit_forcing_available[unit], eachindex(active))
        return _fresh_non_tuzet_crown_leaf_exchange_result(T, model.unit_count;
            daylight=forcing.leaf_exchange_daylight)
    end
    calls = _leaf_energy_calls(context)
    result = _fresh_non_tuzet_crown_leaf_exchange_result(T, model.unit_count;
        daylight=forcing.leaf_exchange_daylight, available=true)

    # Solve all active leaves before publishing any accepted child output.
    solutions = map(eachindex(active)) do unit
        active[unit] || return nothing
        solution = _solve_leaf_energy!(model, calls, T, unit,
            forcing.weighted_soil_water_potential_mpa, forcing, vectors)
        _store_coupled_leaf_solution!(result, unit, solution)
        return solution
    end
    for unit in eachindex(active)
        active[unit] || continue
        _publish_leaf_solution!(calls, unit, solutions[unit], forcing.leaf_exchange_daylight)
    end
    return result
end
