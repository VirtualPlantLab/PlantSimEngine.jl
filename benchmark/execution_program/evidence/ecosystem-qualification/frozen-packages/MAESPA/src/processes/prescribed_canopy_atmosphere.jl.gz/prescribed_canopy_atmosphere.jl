"""
Prescribed, single-layer air for scenes without a canopy feedback solve.

This boundary publishes the reconstructed meteorology (after the configured
climate/chamber adjustments) to the same environment consumed by the iterated
scene. It performs no microclimate calculation. The readiness output orders
environment consumers after the commit.
"""
struct MAESPAPrescribedCanopyAtmosphere{T} <: AbstractCanopy_Air_Iteration_ControllerModel end

PlantSimEngine.inputs_(::MAESPAPrescribedCanopyAtmosphere) = merge(
    NamedTuple{_MAESPA_CANOPY_ATMOSPHERE_AIR_FIELDS}(
        ntuple(_ -> PlantSimEngine.Required(Real), length(_MAESPA_CANOPY_ATMOSPHERE_AIR_FIELDS))),
    (meteorology_reconstruction_available=PlantSimEngine.Required(Bool),))
PlantSimEngine.outputs_(::MAESPAPrescribedCanopyAtmosphere) = (atmosphere_ready=false,)
PlantSimEngine.environment_inputs_(::MAESPAPrescribedCanopyAtmosphere) =
    (duration=PlantSimEngine.Required(Union{Real,Dates.Period,Dates.CompoundPeriod}),)
PlantSimEngine.environment_outputs_(::MAESPAPrescribedCanopyAtmosphere{T}) where {T} =
    PlantSimEngine.environment_outputs_(MAESPACanopyAirIterationController(T))

function PlantSimEngine.run!(model::MAESPAPrescribedCanopyAtmosphere, status, environment, constants, context)
    T = typeof(status.air_temperature_c)
    air = NamedTuple{_MAESPA_CANOPY_ATMOSPHERE_AIR_FIELDS}(
        map(name -> getproperty(status, name), _MAESPA_CANOPY_ATMOSPHERE_AIR_FIELDS))
    state = MAESPACanopyAtmosphere(T; air..., duration=environment.duration,
        soil_surface_temperature_k=zero(T), soil_surface_temperature_available=false,
        canopy_atmosphere_available=status.meteorology_reconstruction_available)
    PlantSimEngine.commit_environment!(context, state)
    status.atmosphere_ready = state.canopy_atmosphere_available
    return nothing
end
