PlantSimEngine.@process "understorey_radiation_aggregation" verbose = false
PlantSimEngine.@process "understorey_flux_aggregation" verbose = false

"""Equal-area radiation statistics corresponding to historical SUMHRUS."""
struct UnderstoreyRadiationAggregationResult{T<:AbstractFloat}
    parusmean_w_m2::T
    parus_population_standard_deviation_w_m2::T
    thrabus_w_m2::T
    transmitted_par_mean_w_m2::T
    fraction_absorbed_par::T
    patch_count::Int
end

"""Equal-area physiological flux means corresponding to historical SUMHRUS."""
struct UnderstoreyFluxAggregationResult{T<:AbstractFloat}
    gross_assimilation_mean_umol_co2_m2_ground_s::T
    fco2us_umol_co2_m2_ground_s::T
    stomatal_conductance_co2_mean_mol_m2_ground_s::T
    fh2ous_mmol_h2o_m2_ground_s::T
    patch_count::Int
    active_patch_count::Int
end

struct MAESPAUnderstoreyRadiationAggregation{T<:AbstractFloat} <:
       AbstractUnderstorey_Radiation_AggregationModel
    expected_patch_count::Int
    zero_value::T
end

struct MAESPAUnderstoreyFluxAggregation{T<:AbstractFloat} <:
       AbstractUnderstorey_Flux_AggregationModel
    expected_patch_count::Int
    zero_value::T
end

function _understorey_aggregation_model(
    ::Type{M},
    ::Type{T},
    patch_count,
) where {M,T<:AbstractFloat}
    patch_count isa Integer && !(patch_count isa Bool) || throw(
        ArgumentError("patch_count must be an integer, not Bool"),
    )
    patch_count > 0 || throw(ArgumentError("patch_count must be positive"))
    return M(Int(patch_count), zero(T))
end

function MAESPAUnderstoreyRadiationAggregation(
    ::Type{T}=Float64;
    patch_count,
) where {T<:AbstractFloat}
    return _understorey_aggregation_model(
        MAESPAUnderstoreyRadiationAggregation{T},
        T,
        patch_count,
    )
end

function MAESPAUnderstoreyFluxAggregation(
    ::Type{T}=Float64;
    patch_count,
) where {T<:AbstractFloat}
    return _understorey_aggregation_model(
        MAESPAUnderstoreyFluxAggregation{T},
        T,
        patch_count,
    )
end

@inline function _understorey_aggregation_vector(values, name::Symbol)
    values isa AbstractVector || throw(
        ArgumentError("$(String(name)) must be an AbstractVector"),
    )
    Base.require_one_based_indexing(values)
    return values
end

function _understorey_aggregation_length(expected::Int, arrays)
    for (values, name) in arrays
        vector = _understorey_aggregation_vector(values, name)
        length(vector) == expected || throw(
            DimensionMismatch("$(String(name)) must contain $expected patch values"),
        )
    end
    return expected
end

@inline function _understorey_aggregation_value(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real && !(value isa Bool) || throw(
        ArgumentError("$(String(name)) values must be numeric, not Bool"),
    )
    converted = convert(T, value)
    isfinite(converted) || throw(
        ArgumentError("$(String(name)) values must be finite"),
    )
    return converted
end

function understorey_radiation_aggregation(
    ::Type{T},
    incident_par_w_m2,
    absorbed_par_w_m2,
    transmitted_par_w_m2;
    patch_count=length(incident_par_w_m2),
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("radiation aggregation type must be concrete"),
    )
    patch_count isa Integer && !(patch_count isa Bool) || throw(
        ArgumentError("patch_count must be an integer, not Bool"),
    )
    count = Int(patch_count)
    count > 0 || throw(ArgumentError("patch_count must be positive"))
    _understorey_aggregation_length(
        count,
        (
            (incident_par_w_m2, :incident_par_w_m2),
            (absorbed_par_w_m2, :absorbed_par_w_m2),
            (transmitted_par_w_m2, :transmitted_par_w_m2),
        ),
    )

    incident_sum = zero(T)
    absorbed_sum = zero(T)
    transmitted_sum = zero(T)
    for patch in 1:count
        incident = _understorey_aggregation_value(
            T,
            incident_par_w_m2[patch],
            :incident_par_w_m2,
        )
        absorbed = _understorey_aggregation_value(
            T,
            absorbed_par_w_m2[patch],
            :absorbed_par_w_m2,
        )
        transmitted = _understorey_aggregation_value(
            T,
            transmitted_par_w_m2[patch],
            :transmitted_par_w_m2,
        )
        incident >= zero(T) && absorbed >= zero(T) && transmitted >= zero(T) || throw(
            DomainError(
                (incident, absorbed, transmitted),
                "understorey radiation aggregates must be non-negative",
            ),
        )
        scale = max(one(T), incident, absorbed, transmitted)
        tolerance = T(32) * eps(T) * scale
        abs(incident - absorbed - transmitted) <= tolerance || throw(
            DomainError(
                (incident, absorbed, transmitted),
                "understorey patch PAR must equal absorbed plus transmitted PAR",
            ),
        )
        incident_sum += incident
        absorbed_sum += absorbed
        transmitted_sum += transmitted
    end
    divisor = T(count)
    incident_mean = incident_sum / divisor
    variance_sum = zero(T)
    for patch in 1:count
        incident = convert(T, incident_par_w_m2[patch])
        variance_sum += (incident - incident_mean)^2
    end
    absorbed_mean = absorbed_sum / divisor
    fraction_absorbed = iszero(incident_mean) ? zero(T) :
                        clamp(absorbed_mean / incident_mean, zero(T), one(T))
    return UnderstoreyRadiationAggregationResult{T}(
        incident_mean,
        sqrt(variance_sum / divisor),
        absorbed_mean,
        transmitted_sum / divisor,
        fraction_absorbed,
        count,
    )
end

function understorey_flux_aggregation(
    ::Type{T},
    gross_assimilation_umol_co2_m2_ground_s,
    net_assimilation_umol_co2_m2_ground_s,
    stomatal_conductance_co2_mol_m2_ground_s,
    transpiration_mmol_h2o_m2_ground_s,
    exchange_active;
    patch_count=length(gross_assimilation_umol_co2_m2_ground_s),
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(ArgumentError("flux aggregation type must be concrete"))
    patch_count isa Integer && !(patch_count isa Bool) || throw(
        ArgumentError("patch_count must be an integer, not Bool"),
    )
    count = Int(patch_count)
    count > 0 || throw(ArgumentError("patch_count must be positive"))
    _understorey_aggregation_length(
        count,
        (
            (
                gross_assimilation_umol_co2_m2_ground_s,
                :gross_assimilation_umol_co2_m2_ground_s,
            ),
            (
                net_assimilation_umol_co2_m2_ground_s,
                :net_assimilation_umol_co2_m2_ground_s,
            ),
            (
                stomatal_conductance_co2_mol_m2_ground_s,
                :stomatal_conductance_co2_mol_m2_ground_s,
            ),
            (
                transpiration_mmol_h2o_m2_ground_s,
                :transpiration_mmol_h2o_m2_ground_s,
            ),
            (exchange_active, :exchange_active),
        ),
    )

    gross_sum = zero(T)
    net_sum = zero(T)
    conductance_sum = zero(T)
    transpiration_sum = zero(T)
    active_count = 0
    for patch in 1:count
        active = exchange_active[patch]
        active isa Bool || throw(ArgumentError("exchange_active values must be Bool"))
        active_count += active
        gross = _understorey_aggregation_value(
            T,
            gross_assimilation_umol_co2_m2_ground_s[patch],
            :gross_assimilation_umol_co2_m2_ground_s,
        )
        net = _understorey_aggregation_value(
            T,
            net_assimilation_umol_co2_m2_ground_s[patch],
            :net_assimilation_umol_co2_m2_ground_s,
        )
        conductance = _understorey_aggregation_value(
            T,
            stomatal_conductance_co2_mol_m2_ground_s[patch],
            :stomatal_conductance_co2_mol_m2_ground_s,
        )
        transpiration = _understorey_aggregation_value(
            T,
            transpiration_mmol_h2o_m2_ground_s[patch],
            :transpiration_mmol_h2o_m2_ground_s,
        )
        gross >= zero(T) && conductance >= zero(T) && transpiration >= zero(T) || throw(
            DomainError(
                (gross, conductance, transpiration),
                "understorey gross exchange aggregates must be non-negative",
            ),
        )
        gross_sum += gross
        net_sum += net
        conductance_sum += conductance
        transpiration_sum += transpiration
    end
    divisor = T(count)
    return UnderstoreyFluxAggregationResult{T}(
        gross_sum / divisor,
        net_sum / divisor,
        conductance_sum / divisor,
        transpiration_sum / divisor,
        count,
        active_count,
    )
end

PlantSimEngine.inputs_(::MAESPAUnderstoreyRadiationAggregation) = (
    understorey_incident_par_w_m2=PlantSimEngine.Required(AbstractVector),
    understorey_absorbed_par_w_m2=PlantSimEngine.Required(AbstractVector),
    understorey_transmitted_par_w_m2=PlantSimEngine.Required(AbstractVector),
    understorey_shortwave_absorption_available=
        PlantSimEngine.Required(AbstractVector),
)

PlantSimEngine.outputs_(
    ::MAESPAUnderstoreyRadiationAggregation{T},
) where {T} = (
    parusmean_w_m2=zero(T),
    parus_population_standard_deviation_w_m2=zero(T),
    thrabus_w_m2=zero(T),
    understorey_transmitted_par_mean_w_m2=zero(T),
    understorey_fraction_absorbed_par=zero(T),
    understorey_radiation_aggregation_available=false,
)

PlantSimEngine.variable_contracts_(::MAESPAUnderstoreyRadiationAggregation) = (
    understorey_incident_par_w_m2=UNDERSTOREY_PATCH_PAR_CONTRACT,
    understorey_absorbed_par_w_m2=UNDERSTOREY_PATCH_PAR_CONTRACT,
    understorey_transmitted_par_w_m2=UNDERSTOREY_PATCH_PAR_CONTRACT,
    parusmean_w_m2=UNDERSTOREY_MEAN_PAR_CONTRACT,
    parus_population_standard_deviation_w_m2=UNDERSTOREY_PAR_SD_CONTRACT,
    thrabus_w_m2=UNDERSTOREY_MEAN_PAR_CONTRACT,
    understorey_transmitted_par_mean_w_m2=UNDERSTOREY_MEAN_PAR_CONTRACT,
    understorey_fraction_absorbed_par=UNDERSTOREY_RATIO_OF_MEANS_CONTRACT,
)

function _reset_understorey_radiation_aggregation!(status, ::Type{T}) where {T}
    status.parusmean_w_m2 = zero(T)
    status.parus_population_standard_deviation_w_m2 = zero(T)
    status.thrabus_w_m2 = zero(T)
    status.understorey_transmitted_par_mean_w_m2 = zero(T)
    status.understorey_fraction_absorbed_par = zero(T)
    status.understorey_radiation_aggregation_available = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPAUnderstoreyRadiationAggregation,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.parusmean_w_m2)
    T <: AbstractFloat || throw(
        ArgumentError("understorey radiation aggregate outputs must be floating-point"),
    )
    _reset_understorey_radiation_aggregation!(status, T)
    available = status.understorey_shortwave_absorption_available
    _understorey_aggregation_length(
        model.expected_patch_count,
        ((available, :understorey_shortwave_absorption_available),),
    )
    all(value -> value isa Bool, available) || throw(
        ArgumentError("understorey absorption availability values must be Bool"),
    )
    all(available) || return nothing
    result = understorey_radiation_aggregation(
        T,
        status.understorey_incident_par_w_m2,
        status.understorey_absorbed_par_w_m2,
        status.understorey_transmitted_par_w_m2;
        patch_count=model.expected_patch_count,
    )
    status.parusmean_w_m2 = result.parusmean_w_m2
    status.parus_population_standard_deviation_w_m2 =
        result.parus_population_standard_deviation_w_m2
    status.thrabus_w_m2 = result.thrabus_w_m2
    status.understorey_transmitted_par_mean_w_m2 =
        result.transmitted_par_mean_w_m2
    status.understorey_fraction_absorbed_par = result.fraction_absorbed_par
    status.understorey_radiation_aggregation_available = true
    return nothing
end

PlantSimEngine.inputs_(::MAESPAUnderstoreyFluxAggregation) = (
    understorey_gross_assimilation_umol_co2_m2_ground_s=
        PlantSimEngine.Required(AbstractVector),
    understorey_net_assimilation_umol_co2_m2_ground_s=
        PlantSimEngine.Required(AbstractVector),
    understorey_stomatal_conductance_co2_mol_m2_ground_s=
        PlantSimEngine.Required(AbstractVector),
    understorey_transpiration_mmol_h2o_m2_ground_s=
        PlantSimEngine.Required(AbstractVector),
    understorey_exchange_active=PlantSimEngine.Required(AbstractVector),
    understorey_photosynthesis_available=PlantSimEngine.Required(AbstractVector),
    understorey_stomatal_conductance_available=
        PlantSimEngine.Required(AbstractVector),
    understorey_respiration_accounting_available=
        PlantSimEngine.Required(AbstractVector),
    understorey_transpiration_available=PlantSimEngine.Required(AbstractVector),
)

PlantSimEngine.outputs_(
    ::MAESPAUnderstoreyFluxAggregation{T},
) where {T} = (
    understorey_gross_assimilation_mean_umol_co2_m2_ground_s=zero(T),
    fco2us_umol_co2_m2_ground_s=zero(T),
    understorey_stomatal_conductance_co2_mean_mol_m2_ground_s=zero(T),
    fh2ous_mmol_h2o_m2_ground_s=zero(T),
    understorey_active_patch_count=0,
    understorey_flux_aggregation_available=false,
)

PlantSimEngine.variable_contracts_(::MAESPAUnderstoreyFluxAggregation) = (
    understorey_gross_assimilation_umol_co2_m2_ground_s=
        UNDERSTOREY_LOCAL_CO2_FLUX_CONTRACT,
    understorey_net_assimilation_umol_co2_m2_ground_s=
        UNDERSTOREY_LOCAL_CO2_FLUX_CONTRACT,
    understorey_stomatal_conductance_co2_mol_m2_ground_s=
        UNDERSTOREY_LOCAL_CO2_CONDUCTANCE_CONTRACT,
    understorey_transpiration_mmol_h2o_m2_ground_s=
        UNDERSTOREY_LOCAL_H2O_FLUX_CONTRACT,
    understorey_gross_assimilation_mean_umol_co2_m2_ground_s=
        UNDERSTOREY_MEAN_CO2_FLUX_CONTRACT,
    fco2us_umol_co2_m2_ground_s=UNDERSTOREY_MEAN_CO2_FLUX_CONTRACT,
    understorey_stomatal_conductance_co2_mean_mol_m2_ground_s=
        UNDERSTOREY_MEAN_CO2_CONDUCTANCE_CONTRACT,
    fh2ous_mmol_h2o_m2_ground_s=UNDERSTOREY_MEAN_H2O_FLUX_CONTRACT,
)

function _reset_understorey_flux_aggregation!(status, ::Type{T}) where {T}
    status.understorey_gross_assimilation_mean_umol_co2_m2_ground_s = zero(T)
    status.fco2us_umol_co2_m2_ground_s = zero(T)
    status.understorey_stomatal_conductance_co2_mean_mol_m2_ground_s = zero(T)
    status.fh2ous_mmol_h2o_m2_ground_s = zero(T)
    status.understorey_active_patch_count = 0
    status.understorey_flux_aggregation_available = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPAUnderstoreyFluxAggregation,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.understorey_gross_assimilation_mean_umol_co2_m2_ground_s)
    T <: AbstractFloat || throw(
        ArgumentError("understorey flux aggregate outputs must be floating-point"),
    )
    _reset_understorey_flux_aggregation!(status, T)
    availability_vectors = (
        status.understorey_photosynthesis_available,
        status.understorey_stomatal_conductance_available,
        status.understorey_respiration_accounting_available,
        status.understorey_transpiration_available,
    )
    _understorey_aggregation_length(
        model.expected_patch_count,
        Tuple((values, :availability) for values in availability_vectors),
    )
    for values in availability_vectors, value in values
        value isa Bool || throw(
            ArgumentError("understorey aggregate availability values must be Bool"),
        )
    end
    all(values -> all(values), availability_vectors) || return nothing
    result = understorey_flux_aggregation(
        T,
        status.understorey_gross_assimilation_umol_co2_m2_ground_s,
        status.understorey_net_assimilation_umol_co2_m2_ground_s,
        status.understorey_stomatal_conductance_co2_mol_m2_ground_s,
        status.understorey_transpiration_mmol_h2o_m2_ground_s,
        status.understorey_exchange_active;
        patch_count=model.expected_patch_count,
    )
    status.understorey_gross_assimilation_mean_umol_co2_m2_ground_s =
        result.gross_assimilation_mean_umol_co2_m2_ground_s
    status.fco2us_umol_co2_m2_ground_s =
        result.fco2us_umol_co2_m2_ground_s
    status.understorey_stomatal_conductance_co2_mean_mol_m2_ground_s =
        result.stomatal_conductance_co2_mean_mol_m2_ground_s
    status.fh2ous_mmol_h2o_m2_ground_s = result.fh2ous_mmol_h2o_m2_ground_s
    status.understorey_active_patch_count = result.active_patch_count
    status.understorey_flux_aggregation_available = true
    return nothing
end
