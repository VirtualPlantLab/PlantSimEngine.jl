const _MAESPA_CANOPY_AIR_TRIAL_CROWN_CALLS = (
    :trial_longwave_forcing,
    :longwave_exchange,
    :leaf_radiative_forcing,
    :leaf_thermodynamic_forcing,
    :logical_leaf_layout,
    :leaf_exchange,
    :crown_leaf_thermal_snapshot,
    :crown_leaf_respiration_accounting,
    :crown_leaf_exchange_aggregation,
    :crown_radiation_aggregation,
)

const _MAESPA_CANOPY_AIR_TRIAL_LEAF_EXCHANGE_PROCESSES = (
    :non_tuzet_crown_leaf_exchange_controller,
    :tuzet_crown_leaf_exchange_controller,
)

@noinline function _throw_canopy_air_trial_evaluation(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :count
        throw(ArgumentError("$label must be a positive integer"))
    elseif reason === :process
        throw(
            ArgumentError(
                "$label must be one of " *
                "$(_MAESPA_CANOPY_AIR_TRIAL_LEAF_EXCHANGE_PROCESSES)",
            ),
        )
    elseif reason === :targets
        throw(
            DimensionMismatch(
                "$label resolved $value Crown targets instead of the " *
                "configured target count",
            ),
        )
    elseif reason === :availability
        throw(ArgumentError("$label must be Bool"))
    elseif reason === :unavailable
        throw(ArgumentError("$label returned unavailable"))
    elseif reason === :output_type
        throw(
            ArgumentError(
                "$label and all canopy-air-trial output carriers must " *
                "share one concrete floating-point type",
            ),
        )
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _canopy_air_trial_evaluation_count(value, name::Symbol)
    value isa Integer && !(value isa Bool) ||
        _throw_canopy_air_trial_evaluation(name, value, :count)
    value > 0 || _throw_canopy_air_trial_evaluation(name, value, :count)
    value <= typemax(Int) || throw(
        ArgumentError("$(String(name)) must be representable as Int"),
    )
    return Int(value)
end

@inline function _canopy_air_trial_scene_call(process::Symbol)
    return PlantSimEngine.Call(
        PlantSimEngine.One(
            scale=:Scene,
            kind=:scene,
            within=PlantSimEngine.Self(),
            process=process,
        ),
    )
end

@inline function _canopy_air_trial_crown_call(process::Symbol)
    return PlantSimEngine.Call(
        PlantSimEngine.Many(
            scale=:Crown,
            kind=:crown,
            within=PlantSimEngine.SceneScope(),
            process=process,
        ),
    )
end

@inline function _canopy_air_trial_soil_call(process::Symbol)
    return PlantSimEngine.Call(
        PlantSimEngine.One(
            scale=:Soil,
            kind=:soil,
            within=PlantSimEngine.SceneScope(),
            process=process,
        ),
    )
end

"""
    MAESPACanopyAirTrialEvaluation(T=Float64; kwargs...)

Concrete Scene orchestrator for one complete MAESPA `ITERTCAN` evaluation.
Every subprocess is a PlantSimEngine hard call. Calls use the inherited trial
environment and request publication; PlantSimEngine masks that publication
during rejected parent trials and enables it only for the accepted replay.
When `reconcile_understorey_shortwave` is true, the evaluator calls and checks
the understorey shortwave reconciliation immediately after soil shortwave and
before soil longwave.
When `aggregate_understorey_water` is true, it likewise calls the vegetation
water-flux aggregation immediately after stand water and before soil
shortwave.

This model owns no persistent water, heat, storage, growth, histogram, or I/O
state. Its children must replace their scratch outputs deterministically.
"""
struct MAESPACanopyAirTrialEvaluation{T<:AbstractFloat} <:
       AbstractCanopy_Air_Trial_EvaluationModel
    target_count::Int
    point_count::Int
    leaf_exchange_process::Symbol
    aggregate_understorey_water::Bool
    reconcile_understorey_shortwave::Bool
    zero_value::T
end

function MAESPACanopyAirTrialEvaluation(
    ::Type{T}=Float64;
    target_count::Integer,
    point_count::Integer,
    leaf_exchange_process::Symbol=
        :non_tuzet_crown_leaf_exchange_controller,
    aggregate_understorey_water::Bool=false,
    reconcile_understorey_shortwave::Bool=false,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the canopy-air-trial numeric type must be concrete"),
    )
    leaf_exchange_process in
    _MAESPA_CANOPY_AIR_TRIAL_LEAF_EXCHANGE_PROCESSES ||
        _throw_canopy_air_trial_evaluation(
            :leaf_exchange_process,
            leaf_exchange_process,
            :process,
        )
    return MAESPACanopyAirTrialEvaluation{T}(
        _canopy_air_trial_evaluation_count(target_count, :target_count),
        _canopy_air_trial_evaluation_count(point_count, :point_count),
        leaf_exchange_process,
        aggregate_understorey_water,
        reconcile_understorey_shortwave,
        zero(T),
    )
end

function PlantSimEngine.dep(model::MAESPACanopyAirTrialEvaluation)
    vegetation_water_call = if model.aggregate_understorey_water
        (
            vegetation_water=_canopy_air_trial_scene_call(
                :vegetation_water_flux_aggregation,
            ),
        )
    else
        NamedTuple()
    end
    soil_shortwave_calls = if model.reconcile_understorey_shortwave
        (
            soil_shortwave=_canopy_air_trial_soil_call(
                :soil_shortwave_radiation,
            ),
            soil_shortwave_reconciliation=_canopy_air_trial_soil_call(
                :understorey_shortwave_reconciliation,
            ),
        )
    else
        (
            soil_shortwave=_canopy_air_trial_soil_call(
                :soil_shortwave_radiation,
            ),
        )
    end
    return (
        trial_longwave_forcing=_canopy_air_trial_crown_call(
            :canopy_air_trial_longwave_forcing,
        ),
        longwave_exchange=_canopy_air_trial_crown_call(
            :longwave_canopy_exchange,
        ),
        leaf_radiative_forcing=_canopy_air_trial_crown_call(
            :leaf_radiative_forcing,
        ),
        leaf_thermodynamic_forcing=_canopy_air_trial_crown_call(
            :leaf_thermodynamic_forcing,
        ),
        logical_leaf_layout=_canopy_air_trial_crown_call(
            :logical_leaf_unit_layout,
        ),
        leaf_exchange=_canopy_air_trial_crown_call(
            model.leaf_exchange_process,
        ),
        crown_leaf_thermal_snapshot=_canopy_air_trial_crown_call(
            :crown_leaf_thermal_snapshot,
        ),
        crown_leaf_respiration_accounting=_canopy_air_trial_crown_call(
            :crown_leaf_respiration_accounting,
        ),
        crown_leaf_exchange_aggregation=_canopy_air_trial_crown_call(
            :crown_leaf_exchange_aggregation,
        ),
        crown_radiation_aggregation=_canopy_air_trial_crown_call(
            :crown_radiation_aggregation,
        ),
        stand_radiation=_canopy_air_trial_scene_call(
            :stand_radiation_scaling,
        ),
        stand_water=_canopy_air_trial_scene_call(
            :stand_water_flux_scaling,
        ),
        vegetation_water_call...,
        soil_shortwave_calls...,
        soil_longwave=_canopy_air_trial_soil_call(
            :soil_longwave_radiation,
        ),
        soil_energy_forcing=_canopy_air_trial_soil_call(
            :soil_surface_energy_forcing,
        ),
        soil_energy=_canopy_air_trial_soil_call(
            :soil_surface_energy_balance,
        ),
        thermal_collection=_canopy_air_trial_scene_call(
            :canopy_thermal_snapshot_collection,
        ),
        microclimate=_canopy_air_trial_scene_call(
            :canopy_air_microclimate,
        ),
    )
end

PlantSimEngine.inputs_(::MAESPACanopyAirTrialEvaluation) = NamedTuple()

function PlantSimEngine.environment_inputs_(
    ::MAESPACanopyAirTrialEvaluation{T},
) where {T}
    return (canopy_air_iteration_enabled=false, canopy_atmosphere_available=false,
        soil_surface_temperature_available=false, air_temperature_c=zero(T),
        vapour_pressure_deficit_pa=zero(T), relative_humidity=zero(T))
end

function PlantSimEngine.outputs_(
    model::MAESPACanopyAirTrialEvaluation{T},
) where {T}
    return (
        proposed_canopy_air_temperature_c=zero(T),
        proposed_canopy_vapour_pressure_deficit_pa=zero(T),
        proposed_canopy_relative_humidity=zero(T),
        proposed_soil_surface_temperature_k=zero(T),
        proposed_soil_surface_temperature_available=false,
        canopy_air_trial_evaluation_available=false,
        next_canopy_temperature_c=zero(T),
        next_leaf_temperature_c_by_target=zeros(
            T,
            model.target_count,
            model.point_count,
        ),
        next_canopy_thermal_snapshot_available=false,
    )
end

function _canopy_air_trial_evaluation_output_type(model, status)
    T = typeof(status.proposed_canopy_air_temperature_c)
    T <: AbstractFloat && isconcretetype(T) ||
        _throw_canopy_air_trial_evaluation(
            :proposed_canopy_air_temperature_c,
            T,
            :output_type,
        )
    for name in (
        :proposed_canopy_vapour_pressure_deficit_pa,
        :proposed_canopy_relative_humidity,
        :proposed_soil_surface_temperature_k,
        :next_canopy_temperature_c,
    )
        typeof(getproperty(status, name)) === T ||
            _throw_canopy_air_trial_evaluation(
                name,
                typeof(getproperty(status, name)),
                :output_type,
            )
    end
    matrix = status.next_leaf_temperature_c_by_target
    matrix isa AbstractMatrix ||
        _throw_canopy_air_trial_evaluation(
            :next_leaf_temperature_c_by_target,
            matrix,
            :output_type,
        )
    Base.require_one_based_indexing(matrix)
    eltype(matrix) === T ||
        _throw_canopy_air_trial_evaluation(
            :next_leaf_temperature_c_by_target,
            eltype(matrix),
            :output_type,
        )
    size(matrix) == (model.target_count, model.point_count) || throw(
        DimensionMismatch(
            "next_leaf_temperature_c_by_target must have size " *
            "$((model.target_count, model.point_count))",
        ),
    )
    for name in (
        :proposed_soil_surface_temperature_available,
        :canopy_air_trial_evaluation_available,
        :next_canopy_thermal_snapshot_available,
    )
        getproperty(status, name) isa Bool ||
            _throw_canopy_air_trial_evaluation(
                name,
                getproperty(status, name),
                :availability,
            )
    end
    return T
end

function _reset_canopy_air_trial_evaluation!(model, status, ::Type{T}) where {T}
    status.proposed_canopy_air_temperature_c = zero(T)
    status.proposed_canopy_vapour_pressure_deficit_pa = zero(T)
    status.proposed_canopy_relative_humidity = zero(T)
    status.proposed_soil_surface_temperature_k = zero(T)
    status.proposed_soil_surface_temperature_available = false
    status.canopy_air_trial_evaluation_available = false
    status.next_canopy_temperature_c = zero(T)
    status.next_leaf_temperature_c_by_target = zeros(
        T,
        model.target_count,
        model.point_count,
    )
    status.next_canopy_thermal_snapshot_available = false
    return nothing
end

@inline function _canopy_air_trial_child_available(target, name::Symbol)
    value = getproperty(target.status, name)
    value isa Bool || _throw_canopy_air_trial_evaluation(
        name,
        value,
        :availability,
    )
    return value
end

function _run_canopy_air_trial_crown_stage!(
    context,
    name::Symbol,
    expected_count::Int,
)
    targets = PlantSimEngine.run_call!(context, name; publish=true)
    length(targets) == expected_count ||
        _throw_canopy_air_trial_evaluation(
            name,
            length(targets),
            :targets,
        )
    return targets
end

@inline function _run_canopy_air_trial_single!(context, name::Symbol)
    return only(PlantSimEngine.run_call!(context, name; publish=true))
end

@inline function _canopy_air_trial_child_float(
    target,
    ::Type{T},
    name::Symbol,
) where {T<:AbstractFloat}
    value = getproperty(target.status, name)
    typeof(value) === T || _throw_canopy_air_trial_evaluation(
        name,
        typeof(value),
        :output_type,
    )
    isfinite(value) || _throw_canopy_air_trial_evaluation(
        name,
        value,
        :finite,
    )
    return value
end

function _canopy_air_trial_copy_thermal_outputs(
    model,
    target,
    ::Type{T},
) where {T<:AbstractFloat}
    _canopy_air_trial_child_available(
        target,
        :next_canopy_thermal_snapshot_available,
    ) || _throw_canopy_air_trial_evaluation(
        :next_canopy_thermal_snapshot_available,
        false,
        :unavailable,
    )
    canopy_temperature = _canopy_air_trial_child_float(
        target,
        T,
        :next_canopy_temperature_c,
    )
    matrix = target.status.next_leaf_temperature_c_by_target
    matrix isa AbstractMatrix ||
        _throw_canopy_air_trial_evaluation(
            :next_leaf_temperature_c_by_target,
            matrix,
            :output_type,
        )
    Base.require_one_based_indexing(matrix)
    eltype(matrix) === T ||
        _throw_canopy_air_trial_evaluation(
            :next_leaf_temperature_c_by_target,
            eltype(matrix),
            :output_type,
        )
    size(matrix) == (model.target_count, model.point_count) || throw(
        DimensionMismatch(
            "the thermal collector returned size $(size(matrix)), " *
            "expected $((model.target_count, model.point_count))",
        ),
    )
    all(isfinite, matrix) || _throw_canopy_air_trial_evaluation(
        :next_leaf_temperature_c_by_target,
        matrix,
        :finite,
    )
    return canopy_temperature, copy(matrix)
end

function PlantSimEngine.run!(
    model::MAESPACanopyAirTrialEvaluation,
    status,
    environment,
    constants,
    context,
)
    T = _canopy_air_trial_evaluation_output_type(model, status)
    _reset_canopy_air_trial_evaluation!(model, status, T)

    iteration_enabled = environment.canopy_air_iteration_enabled
    iteration_enabled isa Bool || _throw_canopy_air_trial_evaluation(
        :canopy_air_iteration_enabled,
        iteration_enabled,
        :availability,
    )

    environment.canopy_atmosphere_available &&
        environment.soil_surface_temperature_available || return nothing

    for name in _MAESPA_CANOPY_AIR_TRIAL_CROWN_CALLS
        _run_canopy_air_trial_crown_stage!(
            context,
            name,
            model.target_count,
        )
    end

    stand_radiation =
        _run_canopy_air_trial_single!(context, :stand_radiation)
    stand_water = _run_canopy_air_trial_single!(context, :stand_water)
    _canopy_air_trial_child_available(
        stand_radiation,
        :stand_radiation_scaling_available,
    ) || return nothing
    _canopy_air_trial_child_available(
        stand_water,
        :stand_water_flux_scaling_available,
    ) || return nothing
    if model.aggregate_understorey_water
        vegetation_water =
            _run_canopy_air_trial_single!(context, :vegetation_water)
        _canopy_air_trial_child_available(
            vegetation_water,
            :vegetation_water_flux_aggregation_available,
        ) || return nothing
    end

    soil_shortwave =
        _run_canopy_air_trial_single!(context, :soil_shortwave)
    _canopy_air_trial_child_available(
        soil_shortwave,
        :soil_shortwave_radiation_available,
    ) || return nothing
    if model.reconcile_understorey_shortwave
        soil_shortwave_reconciliation = _run_canopy_air_trial_single!(
            context,
            :soil_shortwave_reconciliation,
        )
        _canopy_air_trial_child_available(
            soil_shortwave_reconciliation,
            :understorey_shortwave_reconciliation_available,
        ) || return nothing
    end
    soil_longwave = _run_canopy_air_trial_single!(context, :soil_longwave)
    _canopy_air_trial_child_available(
        soil_longwave,
        :soil_longwave_radiation_available,
    ) || return nothing
    soil_forcing =
        _run_canopy_air_trial_single!(context, :soil_energy_forcing)
    _canopy_air_trial_child_available(
        soil_forcing,
        :soil_energy_forcing_available,
    ) || return nothing
    soil_energy = _run_canopy_air_trial_single!(context, :soil_energy)
    _canopy_air_trial_child_available(
        soil_energy,
        :soil_surface_energy_available,
    ) || return nothing

    thermal_collection =
        _run_canopy_air_trial_single!(context, :thermal_collection)
    next_canopy_temperature, next_leaf_temperature =
        _canopy_air_trial_copy_thermal_outputs(
            model,
            thermal_collection,
            T,
        )

    air_temperature, vapour_pressure_deficit, relative_humidity = if iteration_enabled
        microclimate = _run_canopy_air_trial_single!(context, :microclimate)
        _canopy_air_trial_child_available(
            microclimate, :canopy_air_microclimate_available,
        ) || return nothing
        (
            _canopy_air_trial_child_float(microclimate, T, :canopy_air_temperature_c),
            _canopy_air_trial_child_float(microclimate, T, :canopy_vapour_pressure_deficit_pa),
            _canopy_air_trial_child_float(microclimate, T, :canopy_relative_humidity),
        )
    else
        # A disabled iteration returns the evaluated air, not another copy in status.
        (T(environment.air_temperature_c), T(environment.vapour_pressure_deficit_pa),
            T(environment.relative_humidity))
    end
    vapour_pressure_deficit >= zero(T) ||
        _throw_canopy_air_trial_evaluation(
            :canopy_vapour_pressure_deficit_pa, vapour_pressure_deficit, :nonnegative,
        )
    soil_temperature = _canopy_air_trial_child_float(
        soil_energy,
        T,
        :soil_surface_temperature_k,
    )
    soil_temperature > zero(T) || _throw_canopy_air_trial_evaluation(
        :soil_surface_temperature_k,
        soil_temperature,
        :positive,
    )

    status.proposed_canopy_air_temperature_c = air_temperature
    status.proposed_canopy_vapour_pressure_deficit_pa =
        vapour_pressure_deficit
    status.proposed_canopy_relative_humidity = relative_humidity
    status.proposed_soil_surface_temperature_k = soil_temperature
    status.proposed_soil_surface_temperature_available = true
    status.next_canopy_temperature_c = next_canopy_temperature
    status.next_leaf_temperature_c_by_target = next_leaf_temperature
    status.next_canopy_thermal_snapshot_available = true
    status.canopy_air_trial_evaluation_available = true
    return nothing
end
