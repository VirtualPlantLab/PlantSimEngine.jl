PlantSimEngine.@process "mono_pass_longwave_forcing" verbose = false

"""Prepared inputs for one prescribed-temperature `ABSTHERM` pass."""
struct MonoPassLongwaveForcingResult{T<:AbstractFloat}
    incident_thermal_w_m2::T
    canopy_temperature_c::T
    leaf_temperature_c::Vector{T}
    soil_surface_temperature_k::T
    soil_reflectance_thermal::T
end

@noinline function _throw_mono_pass_longwave_forcing_value(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :absolute_zero
        throw(DomainError(value, "$label must not be below absolute zero"))
    elseif reason === :fraction
        throw(DomainError(value, "$label must lie in [0, 1]"))
    elseif reason === :output_type
        throw(
            ArgumentError(
                "$label and mono-pass longwave output carriers must share " *
                "a floating-point type",
            ),
        )
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _mono_pass_longwave_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real ||
        _throw_mono_pass_longwave_forcing_value(name, value, :real)
    value isa Bool &&
        _throw_mono_pass_longwave_forcing_value(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_mono_pass_longwave_forcing_value(name, converted, :finite)
    return converted
end

@inline function _mono_pass_longwave_nonnegative(value::T, name::Symbol) where {T}
    value >= zero(T) ||
        _throw_mono_pass_longwave_forcing_value(name, value, :nonnegative)
    return value
end

@inline function _mono_pass_longwave_temperature_c(
    value::T,
    kelvin_offset::T,
    name::Symbol,
) where {T}
    temperature_k = value + kelvin_offset
    isfinite(temperature_k) ||
        _throw_mono_pass_longwave_forcing_value(name, value, :finite)
    temperature_k >= zero(T) ||
        _throw_mono_pass_longwave_forcing_value(name, value, :absolute_zero)
    return value
end

@inline function _mono_pass_longwave_fraction(value::T, name::Symbol) where {T}
    zero(T) <= value <= one(T) ||
        _throw_mono_pass_longwave_forcing_value(name, value, :fraction)
    return value
end

function _mono_pass_longwave_point_count(value::Integer)
    value isa Bool && throw(
        ArgumentError("point_count must be an integer, not Bool"),
    )
    value > 0 || throw(ArgumentError("point_count must be positive"))
    return Int(value)
end

function _mono_pass_longwave_band(value::Integer)
    value isa Bool && throw(
        ArgumentError("thermal_waveband_index must be an integer, not Bool"),
    )
    value > 0 || throw(
        ArgumentError("thermal_waveband_index must be positive"),
    )
    return Int(value)
end

"""
    mono_pass_longwave_forcing(T, point_count, air_temperature_c,
                               prescribed_soil_temperature_c,
                               incident_thermal_w_m2, soil_reflectance;
                               thermal_waveband_index=3,
                               kelvin_offset=273.15)

Prepare the prescribed-temperature inputs used by MAESPA when
`ITERTAIRMAX <= 1` and `SIMTSOIL = 0`. The initial canopy temperature and all
representative-point leaf temperatures equal reconstructed air temperature.
The reconstructed (measured or estimated) soil temperature is converted from
degrees Celsius to kelvins. The thermal soil reflectance is the third legacy
waveband, `RHOSOL(3)`.

No availability decision depends on whether soil temperature was measured:
the meteorology reconstruction is also a valid prescribed-temperature source.
"""
function mono_pass_longwave_forcing(
    ::Type{T},
    point_count::Integer,
    air_temperature_c,
    prescribed_soil_temperature_c,
    incident_thermal_w_m2,
    soil_reflectance;
    thermal_waveband_index::Integer=3,
    kelvin_offset=273.15,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the mono-pass longwave numeric type must be concrete"),
    )
    points = _mono_pass_longwave_point_count(point_count)
    waveband = _mono_pass_longwave_band(thermal_waveband_index)
    soil_reflectance isa AbstractVector || throw(
        ArgumentError("soil_reflectance must be a vector"),
    )
    Base.require_one_based_indexing(soil_reflectance)
    length(soil_reflectance) >= waveband || throw(
        DimensionMismatch(
            "soil_reflectance must contain thermal waveband $waveband",
        ),
    )

    offset = _mono_pass_longwave_nonnegative(
        _mono_pass_longwave_float(T, kelvin_offset, :kelvin_offset),
        :kelvin_offset,
    )
    offset > zero(T) || throw(
        DomainError(offset, "kelvin_offset must be positive"),
    )
    air = _mono_pass_longwave_temperature_c(
        _mono_pass_longwave_float(T, air_temperature_c, :air_temperature_c),
        offset,
        :air_temperature_c,
    )
    soil_temperature = _mono_pass_longwave_temperature_c(
        _mono_pass_longwave_float(
            T,
            prescribed_soil_temperature_c,
            :prescribed_soil_temperature_c,
        ),
        offset,
        :prescribed_soil_temperature_c,
    )
    incident = _mono_pass_longwave_nonnegative(
        _mono_pass_longwave_float(
            T,
            incident_thermal_w_m2,
            :incident_thermal_w_m2,
        ),
        :incident_thermal_w_m2,
    )
    reflectance = _mono_pass_longwave_fraction(
        _mono_pass_longwave_float(
            T,
            soil_reflectance[waveband],
            :soil_reflectance_thermal,
        ),
        :soil_reflectance_thermal,
    )
    soil_temperature_k = soil_temperature + offset
    return MonoPassLongwaveForcingResult(
        incident,
        air,
        fill(air, points),
        soil_temperature_k,
        reflectance,
    )
end

"""
PlantSimEngine adapter for the prescribed-temperature longwave pass.

All status inputs are prefixed with `source_`, while outputs use the exact
names consumed by [`MAESPALongwaveCanopyExchange`](@ref). A new leaf-temperature
vector is published on every successful call. This makes retained output and
`PreviousTimeStep` snapshots independent instead of mutating an earlier
timestep's vector in place.

If either `source_meteorology_available` or
`source_equivalent_canopy_available` is false, the adapter leaves the last
accepted values untouched, marks the prepared forcing unavailable, and does
not inspect any numeric source. The gates are bound independently to the
meteorology reconstruction and EHC applications. Availability is intentionally
unrelated to `soil_temperature_measured`: a reconstructed prescribed soil
temperature is a valid input for this branch.
"""
struct MAESPAMonoPassLongwaveForcing{T<:AbstractFloat} <:
       AbstractMono_Pass_Longwave_ForcingModel
    point_count::Int
    thermal_waveband_index::Int
    kelvin_offset::T
end

function MAESPAMonoPassLongwaveForcing(
    ::Type{T}=Float64,
    point_count::Integer=1;
    thermal_waveband_index::Integer=3,
    kelvin_offset=273.15,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the mono-pass longwave numeric type must be concrete"),
    )
    points = _mono_pass_longwave_point_count(point_count)
    waveband = _mono_pass_longwave_band(thermal_waveband_index)
    offset = _mono_pass_longwave_nonnegative(
        _mono_pass_longwave_float(T, kelvin_offset, :kelvin_offset),
        :kelvin_offset,
    )
    offset > zero(T) || throw(
        DomainError(offset, "kelvin_offset must be positive"),
    )
    return MAESPAMonoPassLongwaveForcing{T}(points, waveband, offset)
end

PlantSimEngine.inputs_(::MAESPAMonoPassLongwaveForcing) = (
    source_meteorology_available=PlantSimEngine.Required(Bool),
    source_equivalent_canopy_available=PlantSimEngine.Required(Bool),
    source_air_temperature_c=PlantSimEngine.Required(Real),
    source_prescribed_soil_temperature_c=PlantSimEngine.Required(Real),
    source_incident_thermal_w_m2=PlantSimEngine.Required(Real),
    source_soil_reflectance=PlantSimEngine.Required(AbstractVector),
)

PlantSimEngine.variable_contracts_(::MAESPAMonoPassLongwaveForcing) = (
    source_equivalent_canopy_available=EQUIVALENT_CANOPY_AVAILABLE_CONTRACT,
    mono_pass_longwave_forcing_available=LONGWAVE_FORCING_AVAILABLE_CONTRACT,
)

function PlantSimEngine.outputs_(model::MAESPAMonoPassLongwaveForcing{T}) where {T}
    return (
        incident_thermal_w_m2=zero(T),
        canopy_temperature_c=zero(T),
        leaf_temperature_c=zeros(T, model.point_count),
        soil_surface_temperature_k=zero(T),
        soil_reflectance_thermal=zero(T),
        mono_pass_longwave_forcing_available=false,
    )
end

function PlantSimEngine.run!(
    model::MAESPAMonoPassLongwaveForcing,
    status,
    environment,
    constants,
    context,
)
    meteorology_available = status.source_meteorology_available
    meteorology_available isa Bool || throw(
        ArgumentError("source_meteorology_available must be Bool"),
    )
    equivalent_canopy_available = status.source_equivalent_canopy_available
    equivalent_canopy_available isa Bool || throw(
        ArgumentError("source_equivalent_canopy_available must be Bool"),
    )
    if !meteorology_available || !equivalent_canopy_available
        status.mono_pass_longwave_forcing_available = false
        return nothing
    end

    T = typeof(status.canopy_temperature_c)
    T <: AbstractFloat ||
        _throw_mono_pass_longwave_forcing_value(:canopy_temperature_c, T, :output_type)
    for name in (
        :incident_thermal_w_m2,
        :soil_surface_temperature_k,
        :soil_reflectance_thermal,
    )
        typeof(getproperty(status, name)) === T ||
            _throw_mono_pass_longwave_forcing_value(
                name,
                typeof(getproperty(status, name)),
                :output_type,
            )
    end
    eltype(status.leaf_temperature_c) === T ||
        _throw_mono_pass_longwave_forcing_value(
            :leaf_temperature_c,
            eltype(status.leaf_temperature_c),
            :output_type,
        )

    result = mono_pass_longwave_forcing(
        T,
        model.point_count,
        status.source_air_temperature_c,
        status.source_prescribed_soil_temperature_c,
        status.source_incident_thermal_w_m2,
        status.source_soil_reflectance;
        thermal_waveband_index=model.thermal_waveband_index,
        kelvin_offset=convert(T, model.kelvin_offset),
    )
    status.incident_thermal_w_m2 = result.incident_thermal_w_m2
    status.canopy_temperature_c = result.canopy_temperature_c
    status.leaf_temperature_c = result.leaf_temperature_c
    status.soil_surface_temperature_k = result.soil_surface_temperature_k
    status.soil_reflectance_thermal = result.soil_reflectance_thermal
    status.mono_pass_longwave_forcing_available = true
    return nothing
end
