# Ground-area water-depth amounts over the current model timestep. Signed
# wet-canopy evaporation uses the same quantity as rainfall and surface water;
# each port's sign/domain and accepted-publication rules remain separate.
# This is millimetres, not the metre-valued soil extraction contract.
const GROUND_WATER_DEPTH_TIMESTEP_CONTRACT = PlantSimEngine.VariableContract(
    unit=:mm_water,
    basis=:ground_area,
    temporal=:timestep,
    aggregation=:sum,
    extent=:intensive,
)

# Accepted canopy water depth per ground area, not a rate or per-leaf store.
# PreviousTimeStep samples this same state quantity; it does not change units.
const CANOPY_WATER_STORAGE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:mm_water,
    basis=:ground_area,
    temporal=:instantaneous,
    aggregation=:state,
    extent=:intensive,
)

# Full physical stand leaf area divided by plot ground area. The selected
# target-list LAI and local understorey LAI have distinct model meanings.
const FULL_STAND_LAI_CONTRACT = PlantSimEngine.VariableContract(
    unit=:square_metre_leaf,
    basis=:ground_area,
    temporal=:instantaneous,
    aggregation=:state,
    extent=:intensive,
)

# Historical dry fraction of the canopy leaf surface, passed to PSTRANSP.
const CANOPY_DRY_FRACTION_CONTRACT = PlantSimEngine.VariableContract(
    unit=:fraction,
    basis=:canopy_leaf_area,
    temporal=:instantaneous,
    aggregation=:state,
    extent=:intensive,
)

# Throughfall state is a dimensionless control encoding: a resolved fraction
# or the finite negative automatic sentinel retained before first activation.
# It must not be presented as an already resolved physical [0, 1] fraction.
const CANOPY_THROUGHFALL_CONTROL_CONTRACT = PlantSimEngine.VariableContract(
    unit=:dimensionless,
    basis=:canopy_throughfall_control,
    temporal=:instantaneous,
    aggregation=:state,
    extent=:intensive,
)
