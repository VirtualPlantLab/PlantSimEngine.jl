PlantSimEngine.@process "soil_surface_energy_balance" verbose = false

"""Flux components evaluated by MAESPA's historical `ENERGYCALC` kernel."""
struct SoilSurfaceEnergyComponentsResult{T<:AbstractFloat}
    soil_surface_temperature_k::T
    sensible_heat_flux_w_m2::T
    latent_heat_flux_w_m2::T
    net_radiation_w_m2::T
    soil_heat_flux_w_m2::T
    emitted_longwave_w_m2::T
    balance_residual_w_m2::T
end

"""Bounded solution of the historical `FINDSOILTK → ENERGYCALC` path."""
struct SoilSurfaceEnergyBalanceResult{T<:AbstractFloat}
    soil_temperature_k::T
    components::SoilSurfaceEnergyComponentsResult{T}
    iterations::Int
    converged::Bool
    solution_at_lower_bound::Bool
    solution_at_upper_bound::Bool
end

@noinline function _throw_soil_surface_energy_value(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :fraction
        throw(DomainError(value, "$label must lie in [0, 1]"))
    elseif reason === :nonpositive
        throw(DomainError(value, "$label must be non-positive"))
    elseif reason === :iterations
        throw(DomainError(value, "$label must be a positive integer"))
    elseif reason === :result
        throw(DomainError(value, "$label must be finite"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _soil_surface_energy_primary_float(value, name::Symbol)
    value isa Real || _throw_soil_surface_energy_value(name, value, :real)
    value isa Bool && _throw_soil_surface_energy_value(name, value, :bool)
    converted = float(value)
    converted isa AbstractFloat ||
        _throw_soil_surface_energy_value(name, value, :real)
    isfinite(converted) ||
        _throw_soil_surface_energy_value(name, converted, :finite)
    return converted
end

@inline function _soil_surface_energy_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real || _throw_soil_surface_energy_value(name, value, :real)
    value isa Bool && _throw_soil_surface_energy_value(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_soil_surface_energy_value(name, converted, :finite)
    return converted
end

@inline function _soil_surface_energy_positive(value::T, name::Symbol) where {T}
    value > zero(T) ||
        _throw_soil_surface_energy_value(name, value, :positive)
    return value
end

@inline function _soil_surface_energy_fraction(value::T, name::Symbol) where {T}
    zero(T) <= value <= one(T) ||
        _throw_soil_surface_energy_value(name, value, :fraction)
    return value
end

@inline function _soil_surface_energy_gate(value, name::Symbol)
    value isa Bool || throw(ArgumentError("$(String(name)) must be Bool"))
    return value
end

"""
    MAESPASoilSurfaceEnergyBalance(T=Float64; tortuosity, kwargs...)

Parameters for MAESPA's `FINDSOILTK` and `ENERGYCALC` soil-surface balance.
The default temperature bracket (`air_temperature ± 50 K`), tolerance
(`1e-4 K`), and physical constants reproduce the historical executable.

The declared radiation inputs use the `surface_` prefix, and the dry-layer
input is `soil_energy_previous_dry_layer_thickness_m`. These consumer ports
are distinct from the current radiation and dry-layer producer outputs;
the numerical helpers retain their physical argument names.

`dry_layer_thermal_conductivity_w_m_k=nothing` reproduces the legacy negative
sentinel by deriving the dry-layer conductivity from `THERMCONDFUN` with
water content `0`, porosity `0.35`, organic fraction `0.1`, and method `3`.

With `simulate_soil_evaporation=false`, `FINDSOILTK` still solves its ordinary
energy equation, but the caller's accepted QH/QE/QN/QC fluxes remain zero.
The surface temperature is retained from `environment.soil_surface_temperature_k`;
the solved `soil_temperature_k` still drives heat transfer and the next timestep.
`soil_surface_energy_components_evaluated=false` identifies the skipped final
`ENERGYCALC`: its emission/residual diagnostics are unavailable, not physical zeros.
"""
struct MAESPASoilSurfaceEnergyBalance{T<:AbstractFloat} <:
       AbstractSoil_Surface_Energy_BalanceModel
    evaporation::MAESPASoilSurfaceEvaporation{T}
    dry_layer_thermal_conductivity_w_m_k::Union{Nothing,T}
    default_dry_layer_thermal_conductivity_w_m_k::T
    freezing_temperature_k::T
    air_specific_heat_j_kg_k::T
    air_density_numerator_kg_k_m3::T
    soil_emissivity::T
    stefan_boltzmann_constant_w_m2_k4::T
    temperature_bound_delta_k::T
    temperature_tolerance_k::T
    maximum_iterations::Int
    simulate_soil_evaporation::Bool
end

function MAESPASoilSurfaceEnergyBalance(
    ::Type{T}=Float64;
    tortuosity,
    dry_layer_thermal_conductivity_w_m_k=nothing,
    freezing_temperature_k=273.15,
    air_specific_heat_j_kg_k=1010.0,
    air_density_numerator_kg_k_m3=353.0,
    soil_emissivity=0.975,
    stefan_boltzmann_constant_w_m2_k4=5.67e-8,
    temperature_bound_delta_k=50.0,
    temperature_tolerance_k=1e-4,
    maximum_iterations::Integer=30,
    simulate_soil_evaporation::Bool=true,
    evaporation_kwargs...,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the soil-surface-energy numeric type must be concrete"),
    )
    maximum_iterations isa Bool &&
        _throw_soil_surface_energy_value(
            :maximum_iterations,
            maximum_iterations,
            :iterations,
        )
    maximum_iterations > 0 ||
        _throw_soil_surface_energy_value(
            :maximum_iterations,
            maximum_iterations,
            :iterations,
        )
    maximum_iterations <= typemax(Int) || throw(
        ArgumentError("maximum_iterations must be representable as Int"),
    )

    freezing = _soil_surface_energy_positive(
        _soil_surface_energy_float(T, freezing_temperature_k, :freezing_temperature_k),
        :freezing_temperature_k,
    )
    air_heat_capacity = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            air_specific_heat_j_kg_k,
            :air_specific_heat_j_kg_k,
        ),
        :air_specific_heat_j_kg_k,
    )
    density_numerator = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            air_density_numerator_kg_k_m3,
            :air_density_numerator_kg_k_m3,
        ),
        :air_density_numerator_kg_k_m3,
    )
    emissivity = _soil_surface_energy_fraction(
        _soil_surface_energy_float(T, soil_emissivity, :soil_emissivity),
        :soil_emissivity,
    )
    sigma = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            stefan_boltzmann_constant_w_m2_k4,
            :stefan_boltzmann_constant_w_m2_k4,
        ),
        :stefan_boltzmann_constant_w_m2_k4,
    )
    bound = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            temperature_bound_delta_k,
            :temperature_bound_delta_k,
        ),
        :temperature_bound_delta_k,
    )
    tolerance = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            temperature_tolerance_k,
            :temperature_tolerance_k,
        ),
        :temperature_tolerance_k,
    )
    tortuosity_t = _soil_surface_energy_positive(
        _soil_surface_energy_float(T, tortuosity, :tortuosity),
        :tortuosity,
    )
    dry_conductivity = if isnothing(dry_layer_thermal_conductivity_w_m_k)
        nothing
    else
        _soil_surface_energy_positive(
            _soil_surface_energy_float(
                T,
                dry_layer_thermal_conductivity_w_m_k,
                :dry_layer_thermal_conductivity_w_m_k,
            ),
            :dry_layer_thermal_conductivity_w_m_k,
        )
    end
    default_dry_conductivity = soil_thermal_conductivity(
        zero(T),
        T(0.35),
        T(0.1),
        3,
    )
    evaporation = MAESPASoilSurfaceEvaporation(
        T;
        tortuosity=tortuosity_t,
        freezing_temperature_k=freezing,
        air_density_numerator_kg_k_m3=density_numerator,
        evaporation_kwargs...,
    )
    return MAESPASoilSurfaceEnergyBalance{T}(
        evaporation,
        dry_conductivity,
        default_dry_conductivity,
        freezing,
        air_heat_capacity,
        density_numerator,
        emissivity,
        sigma,
        bound,
        tolerance,
        Int(maximum_iterations),
        simulate_soil_evaporation,
    )
end

@inline function _soil_surface_energy_components(
    model::MAESPASoilSurfaceEnergyBalance,
    ::Type{T},
    soil_temperature_k::T,
    air_temperature_k::T,
    second_layer_temperature_k::T,
    vapour_pressure_deficit_kpa::T,
    aerodynamic_conductance_m_s::T,
    atmospheric_pressure_pa::T,
    first_layer_thermal_conductivity_w_m_k::T,
    first_layer_thickness_m::T,
    first_layer_pore_fraction::T,
    first_layer_soil_water_potential_mpa::T,
    dry_layer_thickness_m::T,
    soil_thermal_reflectance::T,
    soil_absorbed_par_w_m2::T,
    soil_absorbed_nir_w_m2::T,
    downward_thermal_radiation_w_m2::T,
    simulate_soil_dew::Bool,
) where {T<:AbstractFloat}
    for (value, name) in (
        (soil_temperature_k, :soil_temperature_k),
        (air_temperature_k, :air_temperature_k),
        (second_layer_temperature_k, :second_layer_temperature_k),
        (vapour_pressure_deficit_kpa, :vapour_pressure_deficit_kpa),
        (aerodynamic_conductance_m_s, :aerodynamic_conductance_m_s),
        (atmospheric_pressure_pa, :atmospheric_pressure_pa),
        (
            first_layer_thermal_conductivity_w_m_k,
            :first_layer_thermal_conductivity_w_m_k,
        ),
        (first_layer_thickness_m, :first_layer_thickness_m),
        (first_layer_pore_fraction, :first_layer_pore_fraction),
        (
            first_layer_soil_water_potential_mpa,
            :first_layer_soil_water_potential_mpa,
        ),
        (dry_layer_thickness_m, :dry_layer_thickness_m),
        (soil_thermal_reflectance, :soil_thermal_reflectance),
        (soil_absorbed_par_w_m2, :soil_absorbed_par_w_m2),
        (soil_absorbed_nir_w_m2, :soil_absorbed_nir_w_m2),
        (downward_thermal_radiation_w_m2, :downward_thermal_radiation_w_m2),
    )
        isfinite(value) ||
            _throw_soil_surface_energy_value(name, value, :finite)
    end
    for (value, name) in (
        (soil_temperature_k, :soil_temperature_k),
        (air_temperature_k, :air_temperature_k),
        (second_layer_temperature_k, :second_layer_temperature_k),
        (aerodynamic_conductance_m_s, :aerodynamic_conductance_m_s),
        (atmospheric_pressure_pa, :atmospheric_pressure_pa),
        (
            first_layer_thermal_conductivity_w_m_k,
            :first_layer_thermal_conductivity_w_m_k,
        ),
        (first_layer_thickness_m, :first_layer_thickness_m),
        (dry_layer_thickness_m, :dry_layer_thickness_m),
    )
        _soil_surface_energy_positive(value, name)
    end
    zero(T) < first_layer_pore_fraction <= one(T) ||
        _throw_soil_surface_energy_value(
            :first_layer_pore_fraction,
            first_layer_pore_fraction,
            :fraction,
        )
    first_layer_soil_water_potential_mpa <= zero(T) ||
        _throw_soil_surface_energy_value(
            :first_layer_soil_water_potential_mpa,
            first_layer_soil_water_potential_mpa,
            :nonpositive,
        )
    _soil_surface_energy_fraction(
        soil_thermal_reflectance,
        :soil_thermal_reflectance,
    )

    freezing = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            model.freezing_temperature_k,
            :freezing_temperature_k,
        ),
        :freezing_temperature_k,
    )
    evaporation = _soil_surface_evaporation(
        model.evaporation,
        T,
        soil_temperature_k,
        air_temperature_k,
        vapour_pressure_deficit_kpa,
        first_layer_pore_fraction,
        first_layer_soil_water_potential_mpa,
        aerodynamic_conductance_m_s,
        atmospheric_pressure_pa,
        dry_layer_thickness_m,
        zero(T),
        true,
        false,
        simulate_soil_dew,
        false,
    )
    raw_latent_heat_flux = evaporation.latent_heat_flux_w_m2
    first_layer_heat_flux =
        first_layer_thermal_conductivity_w_m_k *
        (soil_temperature_k - second_layer_temperature_k) /
        first_layer_thickness_m
    dry_conductivity_source = isnothing(
        model.dry_layer_thermal_conductivity_w_m_k,
    ) ? model.default_dry_layer_thermal_conductivity_w_m_k :
                              model.dry_layer_thermal_conductivity_w_m_k
    dry_conductivity = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            dry_conductivity_source,
            :dry_layer_thermal_conductivity_w_m_k,
        ),
        :dry_layer_thermal_conductivity_w_m_k,
    )
    soil_surface_temperature =
        soil_temperature_k +
        (raw_latent_heat_flux + first_layer_heat_flux) *
        dry_layer_thickness_m / dry_conductivity
    _soil_surface_energy_positive(
        soil_surface_temperature,
        :soil_surface_temperature_k,
    )
    air_heat_capacity = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            model.air_specific_heat_j_kg_k,
            :air_specific_heat_j_kg_k,
        ),
        :air_specific_heat_j_kg_k,
    )
    density_numerator = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            model.air_density_numerator_kg_k_m3,
            :air_density_numerator_kg_k_m3,
        ),
        :air_density_numerator_kg_k_m3,
    )
    air_density = density_numerator / air_temperature_k
    sensible_heat_flux =
        air_heat_capacity *
        air_density *
        aerodynamic_conductance_m_s *
        (soil_surface_temperature - air_temperature_k)
    latent_heat_flux =
        soil_temperature_k <= freezing ? zero(T) : raw_latent_heat_flux
    emissivity = _soil_surface_energy_fraction(
        _soil_surface_energy_float(T, model.soil_emissivity, :soil_emissivity),
        :soil_emissivity,
    )
    sigma = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            model.stefan_boltzmann_constant_w_m2_k4,
            :stefan_boltzmann_constant_w_m2_k4,
        ),
        :stefan_boltzmann_constant_w_m2_k4,
    )
    emitted_longwave =
        emissivity * sigma * soil_surface_temperature^T(4)
    net_radiation =
        downward_thermal_radiation_w_m2 *
        (one(T) - soil_thermal_reflectance) +
        soil_absorbed_par_w_m2 +
        soil_absorbed_nir_w_m2 -
        emitted_longwave
    residual =
        net_radiation - sensible_heat_flux - latent_heat_flux -
        first_layer_heat_flux
    for (value, name) in (
        (soil_surface_temperature, :soil_surface_temperature_k),
        (sensible_heat_flux, :sensible_heat_flux_w_m2),
        (latent_heat_flux, :latent_heat_flux_w_m2),
        (net_radiation, :net_radiation_w_m2),
        (first_layer_heat_flux, :soil_heat_flux_w_m2),
        (emitted_longwave, :emitted_longwave_w_m2),
        (residual, :balance_residual_w_m2),
    )
        isfinite(value) ||
            _throw_soil_surface_energy_value(name, value, :result)
    end
    return SoilSurfaceEnergyComponentsResult{T}(
        soil_surface_temperature,
        sensible_heat_flux,
        latent_heat_flux,
        net_radiation,
        first_layer_heat_flux,
        emitted_longwave,
        residual,
    )
end

@inline function _soil_surface_energy_arguments(
    ::Type{T};
    air_temperature_k,
    second_layer_temperature_k,
    vapour_pressure_deficit_kpa,
    aerodynamic_conductance_m_s,
    atmospheric_pressure_pa,
    first_layer_thermal_conductivity_w_m_k,
    first_layer_thickness_m,
    first_layer_pore_fraction,
    first_layer_soil_water_potential_mpa,
    dry_layer_thickness_m,
    soil_thermal_reflectance,
    soil_absorbed_par_w_m2,
    soil_absorbed_nir_w_m2,
    downward_thermal_radiation_w_m2,
) where {T<:AbstractFloat}
    return map(
        ((value, name),) -> _soil_surface_energy_float(T, value, name),
        (
            (air_temperature_k, :air_temperature_k),
            (second_layer_temperature_k, :second_layer_temperature_k),
            (vapour_pressure_deficit_kpa, :vapour_pressure_deficit_kpa),
            (aerodynamic_conductance_m_s, :aerodynamic_conductance_m_s),
            (atmospheric_pressure_pa, :atmospheric_pressure_pa),
            (
                first_layer_thermal_conductivity_w_m_k,
                :first_layer_thermal_conductivity_w_m_k,
            ),
            (first_layer_thickness_m, :first_layer_thickness_m),
            (first_layer_pore_fraction, :first_layer_pore_fraction),
            (
                first_layer_soil_water_potential_mpa,
                :first_layer_soil_water_potential_mpa,
            ),
            (dry_layer_thickness_m, :dry_layer_thickness_m),
            (soil_thermal_reflectance, :soil_thermal_reflectance),
            (soil_absorbed_par_w_m2, :soil_absorbed_par_w_m2),
            (soil_absorbed_nir_w_m2, :soil_absorbed_nir_w_m2),
            (
                downward_thermal_radiation_w_m2,
                :downward_thermal_radiation_w_m2,
            ),
        ),
    )
end

"""
    soil_surface_energy_components(soil_temperature_k; kwargs...)

Evaluate the historical `ENERGYCALC` fluxes at a prescribed temperature just
below the dry surface layer. Shortwave inputs are the PAR and NIR fluxes
already absorbed by the soil, as they are at the executable call site.
"""
function soil_surface_energy_components(
    soil_temperature_k;
    air_temperature_k,
    second_layer_temperature_k,
    vapour_pressure_deficit_kpa,
    aerodynamic_conductance_m_s,
    atmospheric_pressure_pa,
    first_layer_thermal_conductivity_w_m_k,
    first_layer_thickness_m,
    first_layer_pore_fraction,
    first_layer_soil_water_potential_mpa,
    dry_layer_thickness_m,
    soil_thermal_reflectance,
    soil_absorbed_par_w_m2,
    soil_absorbed_nir_w_m2,
    downward_thermal_radiation_w_m2,
    tortuosity,
    simulate_soil_dew=false,
    dry_layer_thermal_conductivity_w_m_k=nothing,
    freezing_temperature_k=273.15,
    air_specific_heat_j_kg_k=1010.0,
    air_density_numerator_kg_k_m3=353.0,
    soil_emissivity=0.975,
    stefan_boltzmann_constant_w_m2_k4=5.67e-8,
)
    promoted = promote(
        map(
            ((value, name),) ->
                _soil_surface_energy_primary_float(value, name),
            (
                (soil_temperature_k, :soil_temperature_k),
                (air_temperature_k, :air_temperature_k),
                (second_layer_temperature_k, :second_layer_temperature_k),
                (vapour_pressure_deficit_kpa, :vapour_pressure_deficit_kpa),
                (aerodynamic_conductance_m_s, :aerodynamic_conductance_m_s),
                (atmospheric_pressure_pa, :atmospheric_pressure_pa),
                (
                    first_layer_thermal_conductivity_w_m_k,
                    :first_layer_thermal_conductivity_w_m_k,
                ),
                (first_layer_thickness_m, :first_layer_thickness_m),
                (first_layer_pore_fraction, :first_layer_pore_fraction),
                (
                    first_layer_soil_water_potential_mpa,
                    :first_layer_soil_water_potential_mpa,
                ),
                (dry_layer_thickness_m, :dry_layer_thickness_m),
                (soil_thermal_reflectance, :soil_thermal_reflectance),
                (soil_absorbed_par_w_m2, :soil_absorbed_par_w_m2),
                (soil_absorbed_nir_w_m2, :soil_absorbed_nir_w_m2),
                (
                    downward_thermal_radiation_w_m2,
                    :downward_thermal_radiation_w_m2,
                ),
                (tortuosity, :tortuosity),
            ),
        )...,
    )
    T = typeof(first(promoted))
    model = MAESPASoilSurfaceEnergyBalance(
        T;
        tortuosity=promoted[16],
        dry_layer_thermal_conductivity_w_m_k,
        freezing_temperature_k,
        air_specific_heat_j_kg_k,
        air_density_numerator_kg_k_m3,
        soil_emissivity,
        stefan_boltzmann_constant_w_m2_k4,
    )
    dew = _soil_surface_energy_gate(simulate_soil_dew, :simulate_soil_dew)
    return _soil_surface_energy_components(
        model,
        T,
        promoted[1],
        promoted[2:15]...,
        dew,
    )
end


@inline function _solve_soil_surface_temperature(
    model::MAESPASoilSurfaceEnergyBalance,
    ::Type{T},
    arguments::Tuple,
    simulate_soil_dew::Bool,
) where {T<:AbstractFloat}
    air_temperature_k = arguments[1]
    bound = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            model.temperature_bound_delta_k,
            :temperature_bound_delta_k,
        ),
        :temperature_bound_delta_k,
    )
    tolerance = _soil_surface_energy_positive(
        _soil_surface_energy_float(
            T,
            model.temperature_tolerance_k,
            :temperature_tolerance_k,
        ),
        :temperature_tolerance_k,
    )
    lower = air_temperature_k - bound
    upper = air_temperature_k + bound
    _soil_surface_energy_positive(lower, :lower_temperature_bound_k)
    lower_components = _soil_surface_energy_components(
        model,
        T,
        lower,
        arguments...,
        simulate_soil_dew,
    )
    upper_components = _soil_surface_energy_components(
        model,
        T,
        upper,
        arguments...,
        simulate_soil_dew,
    )
    lower_residual = lower_components.balance_residual_w_m2
    upper_residual = upper_components.balance_residual_w_m2
    if iszero(lower_residual)
        return SoilSurfaceEnergyBalanceResult{T}(
            lower,
            lower_components,
            0,
            true,
            true,
            false,
        )
    elseif iszero(upper_residual)
        return SoilSurfaceEnergyBalanceResult{T}(
            upper,
            upper_components,
            0,
            true,
            false,
            true,
        )
    elseif signbit(lower_residual) == signbit(upper_residual)
        if abs(lower_residual) <= abs(upper_residual)
            return SoilSurfaceEnergyBalanceResult{T}(
                lower,
                lower_components,
                0,
                false,
                true,
                false,
            )
        end
        return SoilSurfaceEnergyBalanceResult{T}(
            upper,
            upper_components,
            0,
            false,
            false,
            true,
        )
    end

    best_temperature = lower
    best_components = lower_components
    iterations = 0
    converged = false
    for iteration in 1:model.maximum_iterations
        iterations = iteration
        midpoint = lower + (upper - lower) / T(2)
        midpoint_components = _soil_surface_energy_components(
            model,
            T,
            midpoint,
            arguments...,
            simulate_soil_dew,
        )
        midpoint_residual = midpoint_components.balance_residual_w_m2
        best_temperature = midpoint
        best_components = midpoint_components
        if iszero(midpoint_residual) || (upper - lower) / T(2) <= tolerance
            converged = true
            break
        end
        if signbit(midpoint_residual) == signbit(lower_residual)
            lower = midpoint
            lower_residual = midpoint_residual
        else
            upper = midpoint
            upper_residual = midpoint_residual
        end
    end
    return SoilSurfaceEnergyBalanceResult{T}(
        best_temperature,
        best_components,
        iterations,
        converged,
        best_temperature == air_temperature_k - bound,
        best_temperature == air_temperature_k + bound,
    )
end

"""
    solve_soil_surface_temperature(; kwargs...)

Solve the MAESPA soil-surface energy balance inside the historical
`air_temperature ± 50 K` bracket. Bisection is used deliberately: convergence
and the accepted temperature are scientific contracts, whereas the legacy
Brent iteration count is not. If the initial interval does not bracket a root,
the endpoint with the smaller residual is returned with `converged=false`.
"""
function solve_soil_surface_temperature(;
    air_temperature_k,
    second_layer_temperature_k,
    vapour_pressure_deficit_kpa,
    aerodynamic_conductance_m_s,
    atmospheric_pressure_pa,
    first_layer_thermal_conductivity_w_m_k,
    first_layer_thickness_m,
    first_layer_pore_fraction,
    first_layer_soil_water_potential_mpa,
    dry_layer_thickness_m,
    soil_thermal_reflectance,
    soil_absorbed_par_w_m2,
    soil_absorbed_nir_w_m2,
    downward_thermal_radiation_w_m2,
    tortuosity,
    simulate_soil_dew=false,
    dry_layer_thermal_conductivity_w_m_k=nothing,
    freezing_temperature_k=273.15,
    air_specific_heat_j_kg_k=1010.0,
    air_density_numerator_kg_k_m3=353.0,
    soil_emissivity=0.975,
    stefan_boltzmann_constant_w_m2_k4=5.67e-8,
    temperature_bound_delta_k=50.0,
    temperature_tolerance_k=1e-4,
    maximum_iterations::Integer=30,
)
    promoted = promote(
        map(
            ((value, name),) ->
                _soil_surface_energy_primary_float(value, name),
            (
                (air_temperature_k, :air_temperature_k),
                (second_layer_temperature_k, :second_layer_temperature_k),
                (vapour_pressure_deficit_kpa, :vapour_pressure_deficit_kpa),
                (aerodynamic_conductance_m_s, :aerodynamic_conductance_m_s),
                (atmospheric_pressure_pa, :atmospheric_pressure_pa),
                (
                    first_layer_thermal_conductivity_w_m_k,
                    :first_layer_thermal_conductivity_w_m_k,
                ),
                (first_layer_thickness_m, :first_layer_thickness_m),
                (first_layer_pore_fraction, :first_layer_pore_fraction),
                (
                    first_layer_soil_water_potential_mpa,
                    :first_layer_soil_water_potential_mpa,
                ),
                (dry_layer_thickness_m, :dry_layer_thickness_m),
                (soil_thermal_reflectance, :soil_thermal_reflectance),
                (soil_absorbed_par_w_m2, :soil_absorbed_par_w_m2),
                (soil_absorbed_nir_w_m2, :soil_absorbed_nir_w_m2),
                (
                    downward_thermal_radiation_w_m2,
                    :downward_thermal_radiation_w_m2,
                ),
                (tortuosity, :tortuosity),
            ),
        )...,
    )
    T = typeof(first(promoted))
    model = MAESPASoilSurfaceEnergyBalance(
        T;
        tortuosity=promoted[15],
        dry_layer_thermal_conductivity_w_m_k,
        freezing_temperature_k,
        air_specific_heat_j_kg_k,
        air_density_numerator_kg_k_m3,
        soil_emissivity,
        stefan_boltzmann_constant_w_m2_k4,
        temperature_bound_delta_k,
        temperature_tolerance_k,
        maximum_iterations,
    )
    arguments = promoted[1:14]
    dew = _soil_surface_energy_gate(simulate_soil_dew, :simulate_soil_dew)
    return _solve_soil_surface_temperature(model, T, arguments, dew)
end


PlantSimEngine.environment_inputs_(model::MAESPASoilSurfaceEnergyBalance) =
    model.simulate_soil_evaporation ? NamedTuple() :
    (soil_surface_temperature_k=PlantSimEngine.Required(Real),)

PlantSimEngine.inputs_(::MAESPASoilSurfaceEnergyBalance) = (
    air_temperature_k=PlantSimEngine.Required(Real),
    second_layer_temperature_k=PlantSimEngine.Required(Real),
    vapour_pressure_deficit_kpa=PlantSimEngine.Required(Real),
    aerodynamic_conductance_m_s=PlantSimEngine.Required(Real),
    atmospheric_pressure_pa=PlantSimEngine.Required(Real),
    first_layer_thermal_conductivity_w_m_k=PlantSimEngine.Required(Real),
    first_layer_thickness_m=PlantSimEngine.Required(Real),
    first_layer_pore_fraction=PlantSimEngine.Required(Real),
    first_layer_soil_water_potential_mpa=PlantSimEngine.Required(Real),
    soil_energy_previous_dry_layer_thickness_m=PlantSimEngine.Required(Real),
    soil_thermal_reflectance=PlantSimEngine.Required(Real),
    surface_absorbed_par_w_m2=PlantSimEngine.Required(Real),
    surface_absorbed_nir_w_m2=PlantSimEngine.Required(Real),
    surface_downward_thermal_radiation_w_m2=PlantSimEngine.Required(Real),
    simulate_soil_dew=PlantSimEngine.Default(false),
    soil_surface_energy_inputs_available=PlantSimEngine.Default(true),
)

function PlantSimEngine.outputs_(::MAESPASoilSurfaceEnergyBalance{T}) where {T}
    return (
        soil_temperature_k=zero(T),
        soil_surface_temperature_k=zero(T),
        soil_sensible_heat_flux_w_m2=zero(T),
        soil_latent_heat_flux_w_m2=zero(T),
        soil_net_radiation_w_m2=zero(T),
        soil_heat_flux_w_m2=zero(T),
        soil_emitted_longwave_w_m2=zero(T),
        soil_energy_balance_residual_w_m2=zero(T),
        soil_surface_energy_iterations=0,
        soil_surface_energy_converged=false,
        soil_surface_energy_solution_at_lower_bound=false,
        soil_surface_energy_solution_at_upper_bound=false,
        soil_surface_energy_available=false,
        soil_surface_energy_components_evaluated=false,
    )
end

PlantSimEngine.variable_contracts_(::MAESPASoilSurfaceEnergyBalance) = (
    second_layer_temperature_k=SOIL_PROFILE_NODE_TEMPERATURE_CONTRACT,
    soil_temperature_k=SOIL_HEAT_SURFACE_BOUNDARY_TEMPERATURE_CONTRACT,
    first_layer_soil_water_potential_mpa=SOIL_LAYER_WATER_POTENTIAL_CONTRACT,
    soil_surface_energy_inputs_available=SOIL_SURFACE_ENERGY_CONTEXT_AVAILABLE_CONTRACT,
    soil_surface_energy_available=SOIL_SURFACE_ENERGY_CONTEXT_AVAILABLE_CONTRACT,
    soil_surface_energy_converged=SOIL_SURFACE_ENERGY_SOLVE_CONVERGED_CONTRACT,
    soil_surface_energy_solution_at_lower_bound=
        SOIL_SURFACE_ENERGY_SOLVE_CONVERGED_CONTRACT,
    soil_surface_energy_solution_at_upper_bound=
        SOIL_SURFACE_ENERGY_SOLVE_CONVERGED_CONTRACT,
    soil_surface_energy_components_evaluated=
        SOIL_SURFACE_ENERGY_COMPONENTS_EVALUATED_CONTRACT,
)

@inline function _reset_soil_surface_energy!(status, ::Type{T}) where {T}
    status.soil_temperature_k = zero(T)
    status.soil_surface_temperature_k = zero(T)
    status.soil_sensible_heat_flux_w_m2 = zero(T)
    status.soil_latent_heat_flux_w_m2 = zero(T)
    status.soil_net_radiation_w_m2 = zero(T)
    status.soil_heat_flux_w_m2 = zero(T)
    status.soil_emitted_longwave_w_m2 = zero(T)
    status.soil_energy_balance_residual_w_m2 = zero(T)
    status.soil_surface_energy_iterations = 0
    status.soil_surface_energy_converged = false
    status.soil_surface_energy_solution_at_lower_bound = false
    status.soil_surface_energy_solution_at_upper_bound = false
    status.soil_surface_energy_available = false
    status.soil_surface_energy_components_evaluated = false
    return nothing
end

@noinline function _throw_soil_surface_energy_output_type(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and soil-surface-energy output carriers " *
            "must share a floating-point type",
        ),
    )
end

function PlantSimEngine.run!(
    model::MAESPASoilSurfaceEnergyBalance,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.soil_temperature_k)
    T <: AbstractFloat ||
        _throw_soil_surface_energy_output_type(:soil_temperature_k)
    _reset_soil_surface_energy!(status, T)
    for name in (
        :soil_surface_temperature_k,
        :soil_sensible_heat_flux_w_m2,
        :soil_latent_heat_flux_w_m2,
        :soil_net_radiation_w_m2,
        :soil_heat_flux_w_m2,
        :soil_emitted_longwave_w_m2,
        :soil_energy_balance_residual_w_m2,
    )
        typeof(getproperty(status, name)) === T ||
            _throw_soil_surface_energy_output_type(name)
    end
    available = _soil_surface_energy_gate(
        status.soil_surface_energy_inputs_available,
        :soil_surface_energy_inputs_available,
    )
    available || return nothing
    dew = _soil_surface_energy_gate(status.simulate_soil_dew, :simulate_soil_dew)
    arguments = _soil_surface_energy_arguments(
        T;
        air_temperature_k=status.air_temperature_k,
        second_layer_temperature_k=status.second_layer_temperature_k,
        vapour_pressure_deficit_kpa=status.vapour_pressure_deficit_kpa,
        aerodynamic_conductance_m_s=status.aerodynamic_conductance_m_s,
        atmospheric_pressure_pa=status.atmospheric_pressure_pa,
        first_layer_thermal_conductivity_w_m_k=
            status.first_layer_thermal_conductivity_w_m_k,
        first_layer_thickness_m=status.first_layer_thickness_m,
        first_layer_pore_fraction=status.first_layer_pore_fraction,
        first_layer_soil_water_potential_mpa=
            status.first_layer_soil_water_potential_mpa,
        dry_layer_thickness_m=status.soil_energy_previous_dry_layer_thickness_m,
        soil_thermal_reflectance=status.soil_thermal_reflectance,
        soil_absorbed_par_w_m2=status.surface_absorbed_par_w_m2,
        soil_absorbed_nir_w_m2=status.surface_absorbed_nir_w_m2,
        downward_thermal_radiation_w_m2=
            status.surface_downward_thermal_radiation_w_m2,
    )
    result = _solve_soil_surface_temperature(model, T, arguments, dew)
    status.soil_temperature_k = result.soil_temperature_k
    if model.simulate_soil_evaporation
        components = result.components
        status.soil_surface_temperature_k = components.soil_surface_temperature_k
        status.soil_sensible_heat_flux_w_m2 = components.sensible_heat_flux_w_m2
        status.soil_latent_heat_flux_w_m2 = components.latent_heat_flux_w_m2
        status.soil_net_radiation_w_m2 = components.net_radiation_w_m2
        status.soil_heat_flux_w_m2 = components.soil_heat_flux_w_m2
        status.soil_emitted_longwave_w_m2 = components.emitted_longwave_w_m2
        status.soil_energy_balance_residual_w_m2 = components.balance_residual_w_m2
        status.soil_surface_energy_components_evaluated = true
    else
        # FINDSOILTK still solves with its ordinary internal components. The
        # caller imposes zero accepted QH/QE/QN/QC and retains trial TSOILSURFACE.
        status.soil_surface_temperature_k = _soil_surface_energy_positive(
            _soil_surface_energy_float(T, environment.soil_surface_temperature_k,
                :soil_surface_temperature_k), :soil_surface_temperature_k)
    end
    status.soil_surface_energy_iterations = result.iterations
    status.soil_surface_energy_converged = result.converged
    status.soil_surface_energy_solution_at_lower_bound =
        result.solution_at_lower_bound
    status.soil_surface_energy_solution_at_upper_bound =
        result.solution_at_upper_bound
    status.soil_surface_energy_available = true
    return nothing
end

"""
    MAESPAPrescribedSoilSurfaceEnergyBalance(T=Float64; tortuosity, kwargs...)

PlantSimEngine implementation of the historical `SIMTSOIL=0` branch. It
evaluates `ENERGYCALC` once at the runtime `soil_temperature_k`; unlike
[`MAESPASoilSurfaceEnergyBalance`](@ref), it never calls `FINDSOILTK` and does
not claim convergence.

Radiation uses the same distinct `surface_` consumer ports as the simulated
model, with `soil_energy_previous_dry_layer_thickness_m` for the dry layer.

The wrapped model only supplies the physical parameters already consumed by
[`soil_surface_energy_components`](@ref). Any temperature-bracket or iteration
parameters retained by that parameter container are inactive in this
formulation.

When the runtime `simulate_soil_evaporation` flag is false, retain the prescribed
temperature and publish the historical zero accepted QH/QE/QN/QC fluxes without
evaluating `ENERGYCALC`. The availability flag remains true, while
`soil_surface_energy_components_evaluated` is false. Measured ET remains outside
this model's supported branch.
"""
struct MAESPAPrescribedSoilSurfaceEnergyBalance{T<:AbstractFloat} <:
       AbstractSoil_Surface_Energy_BalanceModel
    components_model::MAESPASoilSurfaceEnergyBalance{T}
end

function MAESPAPrescribedSoilSurfaceEnergyBalance(
    ::Type{T}=Float64;
    tortuosity,
    dry_layer_thermal_conductivity_w_m_k=nothing,
    freezing_temperature_k=273.15,
    air_specific_heat_j_kg_k=1010.0,
    air_density_numerator_kg_k_m3=353.0,
    soil_emissivity=0.975,
    stefan_boltzmann_constant_w_m2_k4=5.67e-8,
    evaporation_kwargs...,
) where {T<:AbstractFloat}
    components_model = MAESPASoilSurfaceEnergyBalance(
        T;
        tortuosity,
        dry_layer_thermal_conductivity_w_m_k,
        freezing_temperature_k,
        air_specific_heat_j_kg_k,
        air_density_numerator_kg_k_m3,
        soil_emissivity,
        stefan_boltzmann_constant_w_m2_k4,
        evaporation_kwargs...,
    )
    return MAESPAPrescribedSoilSurfaceEnergyBalance{T}(components_model)
end

PlantSimEngine.inputs_(::MAESPAPrescribedSoilSurfaceEnergyBalance) = (
    soil_temperature_k=PlantSimEngine.Required(Real),
    air_temperature_k=PlantSimEngine.Required(Real),
    second_layer_temperature_k=PlantSimEngine.Required(Real),
    vapour_pressure_deficit_kpa=PlantSimEngine.Required(Real),
    aerodynamic_conductance_m_s=PlantSimEngine.Required(Real),
    atmospheric_pressure_pa=PlantSimEngine.Required(Real),
    first_layer_thermal_conductivity_w_m_k=PlantSimEngine.Required(Real),
    first_layer_thickness_m=PlantSimEngine.Required(Real),
    first_layer_pore_fraction=PlantSimEngine.Required(Real),
    first_layer_soil_water_potential_mpa=PlantSimEngine.Required(Real),
    soil_energy_previous_dry_layer_thickness_m=
        PlantSimEngine.Required(Real),
    soil_thermal_reflectance=PlantSimEngine.Required(Real),
    surface_absorbed_par_w_m2=PlantSimEngine.Required(Real),
    surface_absorbed_nir_w_m2=PlantSimEngine.Required(Real),
    surface_downward_thermal_radiation_w_m2=PlantSimEngine.Required(Real),
    simulate_soil_temperature=PlantSimEngine.Default(false),
    simulate_soil_evaporation=PlantSimEngine.Default(true),
    use_measured_evapotranspiration=PlantSimEngine.Default(false),
    simulate_soil_dew=PlantSimEngine.Default(false),
    soil_surface_energy_inputs_available=PlantSimEngine.Default(true),
)

function PlantSimEngine.outputs_(
    ::MAESPAPrescribedSoilSurfaceEnergyBalance{T},
) where {T}
    return (
        soil_surface_temperature_k=zero(T),
        soil_sensible_heat_flux_w_m2=zero(T),
        soil_latent_heat_flux_w_m2=zero(T),
        soil_net_radiation_w_m2=zero(T),
        soil_heat_flux_w_m2=zero(T),
        soil_emitted_longwave_w_m2=zero(T),
        soil_energy_balance_residual_w_m2=zero(T),
        soil_surface_energy_iterations=0,
        soil_surface_energy_converged=false,
        soil_surface_energy_solution_at_lower_bound=false,
        soil_surface_energy_solution_at_upper_bound=false,
        soil_surface_energy_temperature_prescribed=true,
        soil_surface_energy_convergence_attempted=false,
        soil_surface_energy_available=false,
        soil_surface_energy_components_evaluated=false,
    )
end

PlantSimEngine.variable_contracts_(::MAESPAPrescribedSoilSurfaceEnergyBalance) = (
    second_layer_temperature_k=SOIL_PROFILE_NODE_TEMPERATURE_CONTRACT,
    soil_temperature_k=SOIL_HEAT_SURFACE_BOUNDARY_TEMPERATURE_CONTRACT,
    first_layer_soil_water_potential_mpa=SOIL_LAYER_WATER_POTENTIAL_CONTRACT,
    soil_surface_energy_inputs_available=SOIL_SURFACE_ENERGY_CONTEXT_AVAILABLE_CONTRACT,
    soil_surface_energy_available=SOIL_SURFACE_ENERGY_CONTEXT_AVAILABLE_CONTRACT,
    soil_surface_energy_converged=SOIL_SURFACE_ENERGY_SOLVE_CONVERGED_CONTRACT,
    soil_surface_energy_solution_at_lower_bound=
        SOIL_SURFACE_ENERGY_SOLVE_CONVERGED_CONTRACT,
    soil_surface_energy_solution_at_upper_bound=
        SOIL_SURFACE_ENERGY_SOLVE_CONVERGED_CONTRACT,
    soil_surface_energy_temperature_prescribed=
        SOIL_SURFACE_ENERGY_SOLVE_CONVERGED_CONTRACT,
    soil_surface_energy_convergence_attempted=
        SOIL_SURFACE_ENERGY_SOLVE_CONVERGED_CONTRACT,
    soil_surface_energy_components_evaluated=
        SOIL_SURFACE_ENERGY_COMPONENTS_EVALUATED_CONTRACT,
)

@inline function _reset_prescribed_soil_surface_energy!(
    status,
    ::Type{T},
) where {T}
    status.soil_surface_temperature_k = zero(T)
    status.soil_sensible_heat_flux_w_m2 = zero(T)
    status.soil_latent_heat_flux_w_m2 = zero(T)
    status.soil_net_radiation_w_m2 = zero(T)
    status.soil_heat_flux_w_m2 = zero(T)
    status.soil_emitted_longwave_w_m2 = zero(T)
    status.soil_energy_balance_residual_w_m2 = zero(T)
    status.soil_surface_energy_iterations = 0
    status.soil_surface_energy_converged = false
    status.soil_surface_energy_solution_at_lower_bound = false
    status.soil_surface_energy_solution_at_upper_bound = false
    status.soil_surface_energy_temperature_prescribed = true
    status.soil_surface_energy_convergence_attempted = false
    status.soil_surface_energy_available = false
    status.soil_surface_energy_components_evaluated = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPAPrescribedSoilSurfaceEnergyBalance,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.soil_surface_temperature_k)
    T <: AbstractFloat ||
        _throw_soil_surface_energy_output_type(:soil_surface_temperature_k)
    _reset_prescribed_soil_surface_energy!(status, T)
    for name in (
        :soil_sensible_heat_flux_w_m2,
        :soil_latent_heat_flux_w_m2,
        :soil_net_radiation_w_m2,
        :soil_heat_flux_w_m2,
        :soil_emitted_longwave_w_m2,
        :soil_energy_balance_residual_w_m2,
    )
        typeof(getproperty(status, name)) === T ||
            _throw_soil_surface_energy_output_type(name)
    end

    inputs_available = _soil_surface_energy_gate(
        status.soil_surface_energy_inputs_available,
        :soil_surface_energy_inputs_available,
    )
    inputs_available || return nothing
    simulate_soil_temperature = _soil_surface_energy_gate(
        status.simulate_soil_temperature,
        :simulate_soil_temperature,
    )
    simulate_soil_evaporation = _soil_surface_energy_gate(
        status.simulate_soil_evaporation,
        :simulate_soil_evaporation,
    )
    use_measured_evapotranspiration = _soil_surface_energy_gate(
        status.use_measured_evapotranspiration,
        :use_measured_evapotranspiration,
    )
    simulate_soil_dew = _soil_surface_energy_gate(
        status.simulate_soil_dew,
        :simulate_soil_dew,
    )

    # Unsupported temperature/measured-ET branches are unavailable; disabled
    # evaporation instead publishes the caller's imposed zero energy fluxes.
    (!simulate_soil_temperature && !use_measured_evapotranspiration) || return nothing

    soil_temperature_k = _soil_surface_energy_positive(
        _soil_surface_energy_float(T, status.soil_temperature_k, :soil_temperature_k),
        :soil_temperature_k)
    if !simulate_soil_evaporation
        status.soil_surface_temperature_k = soil_temperature_k
        status.soil_surface_energy_available = true
        return nothing
    end
    arguments = _soil_surface_energy_arguments(
        T;
        air_temperature_k=status.air_temperature_k,
        second_layer_temperature_k=status.second_layer_temperature_k,
        vapour_pressure_deficit_kpa=status.vapour_pressure_deficit_kpa,
        aerodynamic_conductance_m_s=status.aerodynamic_conductance_m_s,
        atmospheric_pressure_pa=status.atmospheric_pressure_pa,
        first_layer_thermal_conductivity_w_m_k=
            status.first_layer_thermal_conductivity_w_m_k,
        first_layer_thickness_m=status.first_layer_thickness_m,
        first_layer_pore_fraction=status.first_layer_pore_fraction,
        first_layer_soil_water_potential_mpa=
            status.first_layer_soil_water_potential_mpa,
        dry_layer_thickness_m=
            status.soil_energy_previous_dry_layer_thickness_m,
        soil_thermal_reflectance=status.soil_thermal_reflectance,
        soil_absorbed_par_w_m2=status.surface_absorbed_par_w_m2,
        soil_absorbed_nir_w_m2=status.surface_absorbed_nir_w_m2,
        downward_thermal_radiation_w_m2=
            status.surface_downward_thermal_radiation_w_m2,
    )
    components = _soil_surface_energy_components(
        model.components_model,
        T,
        soil_temperature_k,
        arguments...,
        simulate_soil_dew,
    )
    status.soil_surface_temperature_k = components.soil_surface_temperature_k
    status.soil_sensible_heat_flux_w_m2 = components.sensible_heat_flux_w_m2
    status.soil_latent_heat_flux_w_m2 = components.latent_heat_flux_w_m2
    status.soil_net_radiation_w_m2 = components.net_radiation_w_m2
    status.soil_heat_flux_w_m2 = components.soil_heat_flux_w_m2
    status.soil_emitted_longwave_w_m2 = components.emitted_longwave_w_m2
    status.soil_energy_balance_residual_w_m2 =
        components.balance_residual_w_m2
    status.soil_surface_energy_components_evaluated = true
    status.soil_surface_energy_available = true
    return nothing
end
