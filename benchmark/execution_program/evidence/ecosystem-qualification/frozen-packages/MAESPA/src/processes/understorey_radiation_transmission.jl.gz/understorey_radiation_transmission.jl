struct MAESPAUnderstoreyDiffuseTransmission{T<:AbstractFloat} <:
       AbstractDiffuse_TransmissionModel
    neighbourhood::RadiationFieldNeighbourhood
    zenith_count::Int
    azimuth_count::Int
    patch_count::Int
    zero_value::T
end

function MAESPAUnderstoreyDiffuseTransmission(
    ::Type{T},
    neighbourhood::RadiationFieldNeighbourhood,
    zenith_count::Integer,
    azimuth_count::Integer,
    patch_count::Integer,
) where {T<:AbstractFloat}
    zenith_count > 0 || throw(ArgumentError("zenith_count must be positive"))
    azimuth_count > 0 || throw(ArgumentError("azimuth_count must be positive"))
    patch_count > 0 || throw(ArgumentError("patch_count must be positive"))
    return MAESPAUnderstoreyDiffuseTransmission{T}(
        neighbourhood,
        Int(zenith_count),
        Int(azimuth_count),
        Int(patch_count),
        zero(T),
    )
end

struct MAESPAUnderstoreyDirectTransmission{T<:AbstractFloat} <:
       AbstractDirect_TransmissionModel
    neighbourhood::RadiationFieldNeighbourhood
    patch_count::Int
    zero_value::T
    retain_crown_structure::Bool
end

"""
    MAESPAUnderstoreyDirectTransmission(T, neighbourhood, patch_count;
        retain_crown_structure=false)

Trace current beam radiation through the selected physical crowns. The default
uses live structure, preserving the standalone model's original boundary.
With `retain_crown_structure=true`, capture detached Crown structure only after
a successful diffuse generation, and retain it until the next generation.
Beam extinction (including leaf-angle coefficients), sun, meteorology and the
daily patch-height trajectory remain current. An uninitialized or unavailable
diffuse field makes this retained route unavailable, never a live fallback.
"""
function MAESPAUnderstoreyDirectTransmission(
    ::Type{T},
    neighbourhood::RadiationFieldNeighbourhood,
    patch_count::Integer;
    retain_crown_structure::Bool=false,
) where {T<:AbstractFloat}
    patch_count > 0 || throw(ArgumentError("patch_count must be positive"))
    return MAESPAUnderstoreyDirectTransmission{T}(
        neighbourhood,
        Int(patch_count),
        zero(T),
        retain_crown_structure,
    )
end

# Preserve the original explicitly parameterized positional constructor.
MAESPAUnderstoreyDirectTransmission{T}(
    neighbourhood::RadiationFieldNeighbourhood,
    patch_count::Int,
    zero_value::T,
) where {T<:AbstractFloat} = MAESPAUnderstoreyDirectTransmission{T}(
    neighbourhood, patch_count, zero_value, false,
)

MAESPAUnderstoreyDirectTransmission(
    neighbourhood::RadiationFieldNeighbourhood,
    patch_count::Int,
    zero_value::T,
) where {T<:AbstractFloat} = MAESPAUnderstoreyDirectTransmission{T}(
    neighbourhood, patch_count, zero_value, false,
)

struct MAESPAUnderstoreyDiffuseTransmissionController{T<:AbstractFloat} <:
       AbstractDiffuse_Transmission_ControlModel
    interval_steps::Union{Nothing,Int}
    zero_value::T

    function MAESPAUnderstoreyDiffuseTransmissionController(
        ::Type{T},
        interval_steps::Union{Nothing,Integer},
    ) where {T<:AbstractFloat}
        if !isnothing(interval_steps)
            interval_steps isa Bool && throw(
                ArgumentError("interval_steps must be an integer, not Bool"),
            )
            interval_steps > 0 || throw(
                ArgumentError("interval_steps must be positive or nothing"),
            )
        end
        return new{T}(
            isnothing(interval_steps) ? nothing : Int(interval_steps),
            zero(T),
        )
    end
end

const _UNDERSTOREY_RADIATION_FIELD_GEOMETRY_INPUTS = (
    all_tree_x_m=PlantSimEngine.Required(AbstractVector),
    all_tree_y_m=PlantSimEngine.Required(AbstractVector),
    all_tree_z_m=PlantSimEngine.Required(AbstractVector),
    all_radius_x=PlantSimEngine.Required(AbstractVector),
    all_radius_y=PlantSimEngine.Required(AbstractVector),
    all_crown_depth=PlantSimEngine.Required(AbstractVector),
    all_crown_base_height=PlantSimEngine.Required(AbstractVector),
    all_leaf_area=PlantSimEngine.Required(AbstractVector),
    all_uniform_leaf_area_density=PlantSimEngine.Required(AbstractVector),
    all_leaf_density_coefficients=PlantSimEngine.Required(AbstractVector),
    all_structural_age_proportions=PlantSimEngine.Required(AbstractVector),
    all_crown_shape_code=PlantSimEngine.Required(AbstractVector),
    all_leaf_density_legacy_mode=PlantSimEngine.Required(AbstractVector),
    all_understorey_patch_index=PlantSimEngine.Required(AbstractVector),
    all_understorey_patch_x_m=PlantSimEngine.Required(AbstractVector),
    all_understorey_patch_y_m=PlantSimEngine.Required(AbstractVector),
    all_understorey_height_m=PlantSimEngine.Required(AbstractVector),
    all_understorey_structure_available=PlantSimEngine.Required(AbstractVector),
    slope_x_rad=PlantSimEngine.Required(Real),
    slope_y_rad=PlantSimEngine.Required(Real),
    plot_width=PlantSimEngine.Required(Real),
    plot_height=PlantSimEngine.Required(Real),
    shade_height=PlantSimEngine.Required(Real),
)

PlantSimEngine.inputs_(::MAESPAUnderstoreyDiffuseTransmission) = merge(
    _UNDERSTOREY_RADIATION_FIELD_GEOMETRY_INPUTS,
    (
        diffuse_zenith_angles_rad=PlantSimEngine.Required(AbstractVector),
        all_diffuse_zenith_angles_rad=PlantSimEngine.Required(AbstractVector),
        all_diffuse_extinction_coefficients=PlantSimEngine.Required(AbstractVector),
        diffuse_sky=PlantSimEngine.Required(Real),
    ),
)

PlantSimEngine.inputs_(model::MAESPAUnderstoreyDirectTransmission) = merge(
    _UNDERSTOREY_RADIATION_FIELD_GEOMETRY_INPUTS,
    (
        all_beam_extinction_coefficient=PlantSimEngine.Required(AbstractVector),
        all_beam_extinction_by_leaf_angle=PlantSimEngine.Required(AbstractVector),
        sun_zenith_rad=PlantSimEngine.Required(Real),
        sun_azimuth_rad=PlantSimEngine.Required(Real),
        astronomical_daylight=PlantSimEngine.Required(Bool),
        incident_par_w_m2=PlantSimEngine.Required(Real),
        beam_fraction_par=PlantSimEngine.Required(Real),
        beam_fraction_nir=PlantSimEngine.Required(Real),
    ),
    model.retain_crown_structure ? (
        understorey_diffuse_transmission_generation=PlantSimEngine.Required(Integer),
        understorey_diffuse_field_available=PlantSimEngine.Required(Bool),
    ) : NamedTuple(),
)

PlantSimEngine.inputs_(::MAESPAUnderstoreyDiffuseTransmissionController) = (
    simulation_step=PlantSimEngine.Required(Integer),
    all_understorey_height_m=PlantSimEngine.Required(AbstractVector),
    all_crown_radius_x=PlantSimEngine.Required(AbstractVector),
    all_diffuse_extinction_coefficients=PlantSimEngine.Required(AbstractVector),
)

function PlantSimEngine.outputs_(
    model::MAESPAUnderstoreyDiffuseTransmission{T},
) where {T}
    return (
        understorey_diffuse_transmittance=zeros(T, model.patch_count),
        understorey_diffuse_ray_x_m=zeros(T, model.patch_count),
        understorey_diffuse_ray_y_m=zeros(T, model.patch_count),
        understorey_diffuse_ray_z_m=zeros(T, model.patch_count),
        understorey_diffuse_leaf_path_buffer=zeros(
            T,
            length(model.neighbourhood.tree_ids),
        ),
        understorey_diffuse_field_available=false,
    )
end

function PlantSimEngine.outputs_(
    model::MAESPAUnderstoreyDirectTransmission{T},
) where {T}
    outputs = (
        understorey_direct_transmittance=zeros(T, model.patch_count),
        understorey_direct_optical_depth=zeros(T, model.patch_count),
        understorey_direct_ray_available=falses(model.patch_count),
        understorey_direct_optical_path_available=falses(model.patch_count),
        understorey_direct_ray_x_m=zeros(T, model.patch_count),
        understorey_direct_ray_y_m=zeros(T, model.patch_count),
        understorey_direct_ray_z_m=zeros(T, model.patch_count),
        understorey_direct_leaf_path_buffer=zeros(
            T,
            length(model.neighbourhood.tree_ids),
        ),
        understorey_direct_field_available=false,
    )
    # No parameter-T objects in the default: the first successful generation
    # materializes checked states in the effective numeric type of the status.
    return model.retain_crown_structure ? merge(outputs, (
        understorey_direct_crown_cache=CrownRayState[],
        understorey_direct_crown_cache_generation=0,
    )) : outputs
end

function PlantSimEngine.outputs_(
    model::MAESPAUnderstoreyDiffuseTransmissionController,
)
    return (
        understorey_diffuse_transmission_generation=0,
        understorey_diffuse_last_checked_step=0,
        understorey_diffuse_last_recompute_step=0,
        understorey_diffuse_recomputed_this_step=false,
        understorey_diffuse_recompute_pending=false,
        understorey_diffuse_recompute_initialization=false,
        understorey_diffuse_recompute_periodic=false,
    )
end

PlantSimEngine.variable_contracts_(::MAESPAUnderstoreyDiffuseTransmission) = (
    understorey_diffuse_transmittance=UNDERSTOREY_LOCAL_FRACTION_CONTRACT,
)

PlantSimEngine.variable_contracts_(::MAESPAUnderstoreyDirectTransmission) = merge(
    (understorey_direct_transmittance=UNDERSTOREY_LOCAL_FRACTION_CONTRACT,),
    HORIZONTAL_PAR_FORCING_CONTRACTS,
)

const _UNDERSTOREY_PATCH_FIELD_INPUT_NAMES = (
    :all_understorey_patch_index,
    :all_understorey_patch_x_m,
    :all_understorey_patch_y_m,
    :all_understorey_height_m,
    :all_understorey_structure_available,
)

function _understorey_patch_field_inputs(context)
    values = map(
        name -> PlantSimEngine.bound_input(context, name),
        _UNDERSTOREY_PATCH_FIELD_INPUT_NAMES,
    )
    ids = PlantSimEngine.object_ids(first(values))
    for value in Base.tail(values)
        PlantSimEngine.object_ids(value) == ids || throw(
            ArgumentError(
                "understorey radiation inputs do not share the same patch identities",
            ),
        )
    end
    return values
end

function _understorey_patch_field_points!(
    x::AbstractVector{T},
    y::AbstractVector{T},
    z::AbstractVector{T},
    context,
    patch_count::Int,
) where {T<:AbstractFloat}
    patch_index, patch_x, patch_y, patch_height, structure_available =
        _understorey_patch_field_inputs(context)
    object_ids = PlantSimEngine.object_ids(patch_index)
    seen = falses(patch_count)
    all_available = true
    for object_id in object_ids
        index = patch_index[object_id]
        index isa Integer && !(index isa Bool) || throw(
            ArgumentError("understorey patch indices must be integers"),
        )
        1 <= index <= patch_count || throw(BoundsError(x, index))
        seen[Int(index)] && throw(
            ArgumentError("understorey patch indices must be unique"),
        )
        available = structure_available[object_id]
        available isa Bool || throw(
            ArgumentError("understorey structure availability must be Bool"),
        )
        seen[Int(index)] = true
        all_available &= available
        x[Int(index)] = _transmission_float(T, patch_x[object_id], "patch x")
        y[Int(index)] = _transmission_float(T, patch_y[object_id], "patch y")
        z[Int(index)] = _transmission_float(
            T,
            patch_height[object_id],
            "understorey height",
        )
    end
    all(seen) || throw(
        DimensionMismatch("understorey radiation field is missing one or more patches"),
    )
    return all_available
end

function PlantSimEngine.run!(
    model::MAESPAUnderstoreyDiffuseTransmission,
    status,
    environment,
    constants,
    context,
)
    T = eltype(status.understorey_diffuse_transmittance)
    status.understorey_diffuse_field_available = false
    fill!(status.understorey_diffuse_transmittance, zero(T))
    available = _understorey_patch_field_points!(
        status.understorey_diffuse_ray_x_m,
        status.understorey_diffuse_ray_y_m,
        status.understorey_diffuse_ray_z_m,
        context,
        model.patch_count,
    )
    available || return nothing
    zenith_angles = status.diffuse_zenith_angles_rad
    length(zenith_angles) == model.zenith_count || throw(
        DimensionMismatch("diffuse zenith grid changed after model construction"),
    )
    typed_zenith_angles = zenith_angles isa Vector{T} ?
                          zenith_angles : Vector{T}(zenith_angles)
    crowns = _selected_crowns(
        model.neighbourhood,
        context,
        T,
        nothing,
        :all_diffuse_extinction_coefficients,
    )
    _validate_selected_angle_grids(
        model.neighbourhood,
        context,
        :all_diffuse_zenith_angles_rad,
        typed_zenith_angles,
    )
    diffuse_transmittance_to_points!(
        status.understorey_diffuse_transmittance,
        status.understorey_diffuse_ray_x_m,
        status.understorey_diffuse_ray_y_m,
        status.understorey_diffuse_ray_z_m,
        crowns,
        typed_zenith_angles;
        azimuth_angles=model.azimuth_count,
        diffuse_sky=_transmission_float(T, status.diffuse_sky, "diffuse_sky"),
        slope_x_rad=_transmission_float(T, status.slope_x_rad, "slope_x_rad"),
        slope_y_rad=_transmission_float(T, status.slope_y_rad, "slope_y_rad"),
        plot_width=_transmission_float(T, status.plot_width, "plot_width"),
        plot_height=_transmission_float(T, status.plot_height, "plot_height"),
        shade_height=_transmission_float(T, status.shade_height, "shade_height"),
        leaf_path_buffer=status.understorey_diffuse_leaf_path_buffer,
    )
    status.understorey_diffuse_field_available = true
    return nothing
end

"""Retain checked structure by diffuse generation, with current beam optics."""
function _understorey_retained_beam_crowns!(
    model::MAESPAUnderstoreyDirectTransmission,
    status,
    context,
    ::Type{T},
) where {T<:AbstractFloat}
    generation = status.understorey_diffuse_transmission_generation
    generation isa Integer && !(generation isa Bool) || throw(
        ArgumentError("understorey diffuse generation must be an integer, not Bool"),
    )
    generation >= 0 || throw(ArgumentError("understorey diffuse generation must be non-negative"))
    available = status.understorey_diffuse_field_available
    available isa Bool || throw(ArgumentError("understorey diffuse availability must be Bool"))
    available && generation > 0 || return nothing

    previous_generation = status.understorey_direct_crown_cache_generation
    generation >= previous_generation || throw(
        ArgumentError("understorey diffuse generation cannot move backwards"),
    )
    retained = status.understorey_direct_crown_cache
    if generation != previous_generation
        # The generation binding orders this capture after successful diffuse
        # publication. Copy every borrowed beta/age/optical array once here;
        # later live producer updates must not alter retained structure.
        current = _selected_crowns(
            model.neighbourhood, context, T,
            :all_beam_extinction_coefficient, :all_beam_extinction_by_leaf_angle,
        )
        # Full checked constructors copy each array separately. Deepcopy of a
        # whole state would preserve valid source aliases between its age
        # proportions and angular optics, which must not share warm scratch.
        detached = map(current) do crown
            if crown isa UniformCrownRayState{T}
                UniformCrownRayState{T}(
                    crown.id, crown.crown_shape_code, crown.position,
                    crown.crown_base, crown.radius_x, crown.radius_y,
                    crown.crown_depth, crown.leaf_area_density,
                    crown.extinction, crown.extinction_by_angle,
                )
            else
                BetaCrownRayState{T}(
                    crown.id, crown.crown_shape_code, crown.position,
                    crown.crown_base, crown.radius_x, crown.radius_y,
                    crown.crown_depth, crown.leaf_area,
                    crown.leaf_density_legacy_mode,
                    crown.leaf_density_coefficients,
                    crown.structural_age_proportions,
                    crown.extinction, crown.extinction_by_angle,
                )
            end
        end
        empty!(retained)
        append!(retained, detached)
        status.understorey_direct_crown_cache_generation = Int(generation)
    end

    beam = PlantSimEngine.bound_input(context, :all_beam_extinction_coefficient)
    beam_by_angle = PlantSimEngine.bound_input(context, :all_beam_extinction_by_leaf_angle)
    crowns = Vector{CrownRayState{T}}(undef, length(model.neighbourhood.tree_ids))
    for (index, object_id) in pairs(model.neighbourhood.crown_object_ids)
        snapshot = retained[index]::CrownRayState{T}
        current_angles = beam_by_angle[object_id]
        length(current_angles) == length(snapshot.extinction_by_angle) || throw(
            DimensionMismatch("understorey beam leaf-angle layout changed after cache capture"),
        )
        # These are direct-owned optical scratch arrays, not the producer's
        # arrays. Geometry, beta coefficients and age proportions stay held.
        for angle in eachindex(snapshot.extinction_by_angle)
            coefficient = _transmission_float(T, current_angles[angle], "beam angle-specific extinction")
            _transmission_nonnegative(coefficient, "beam angle-specific extinction")
            snapshot.extinction_by_angle[angle] = coefficient
        end
        coefficient = _transmission_float(T, beam[object_id], "beam extinction")
        crowns[index] = typeof(snapshot)(snapshot, coefficient)
        retained[index] = crowns[index]
    end
    return crowns
end

function PlantSimEngine.run!(
    model::MAESPAUnderstoreyDirectTransmission,
    status,
    environment,
    constants,
    context,
)
    T = eltype(status.understorey_direct_transmittance)
    status.understorey_direct_field_available = false
    fill!(status.understorey_direct_transmittance, zero(T))
    fill!(status.understorey_direct_optical_depth, zero(T))
    fill!(status.understorey_direct_ray_available, false)
    fill!(status.understorey_direct_optical_path_available, false)
    available = _understorey_patch_field_points!(
        status.understorey_direct_ray_x_m,
        status.understorey_direct_ray_y_m,
        status.understorey_direct_ray_z_m,
        context,
        model.patch_count,
    )
    available || return nothing
    crowns = if model.retain_crown_structure
        _understorey_retained_beam_crowns!(model, status, context, T)
    else
        _selected_crowns(
            model.neighbourhood, context, T,
            :all_beam_extinction_coefficient, :all_beam_extinction_by_leaf_angle,
        )
    end
    isnothing(crowns) && return nothing
    daylight = status.astronomical_daylight
    daylight isa Bool || throw(ArgumentError("astronomical_daylight must be Bool"))
    direct_transmittance_to_points!(
        status.understorey_direct_transmittance,
        status.understorey_direct_optical_depth,
        status.understorey_direct_ray_available,
        status.understorey_direct_optical_path_available,
        status.understorey_direct_ray_x_m,
        status.understorey_direct_ray_y_m,
        status.understorey_direct_ray_z_m,
        crowns;
        sun_zenith_rad=_transmission_float(
            T,
            status.sun_zenith_rad,
            "sun_zenith_rad",
        ),
        sun_azimuth_rad=_transmission_float(
            T,
            status.sun_azimuth_rad,
            "sun_azimuth_rad",
        ),
        astronomical_daylight=daylight,
        incident_par_w_m2=_transmission_float(
            T,
            status.incident_par_w_m2,
            "incident_par_w_m2",
        ),
        beam_fraction_par=_transmission_float(
            T,
            status.beam_fraction_par,
            "beam_fraction_par",
        ),
        beam_fraction_nir=_transmission_float(
            T,
            status.beam_fraction_nir,
            "beam_fraction_nir",
        ),
        slope_x_rad=_transmission_float(T, status.slope_x_rad, "slope_x_rad"),
        slope_y_rad=_transmission_float(T, status.slope_y_rad, "slope_y_rad"),
        plot_width=_transmission_float(T, status.plot_width, "plot_width"),
        plot_height=_transmission_float(T, status.plot_height, "plot_height"),
        shade_height=_transmission_float(T, status.shade_height, "shade_height"),
        leaf_path_buffer=status.understorey_direct_leaf_path_buffer,
    )
    status.understorey_direct_field_available = true
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPAUnderstoreyDiffuseTransmissionController,
    status,
    environment,
    constants,
    context,
)
    step = status.simulation_step
    step isa Integer && !(step isa Bool) || throw(
        ArgumentError("simulation_step must be an integer, not Bool"),
    )
    step > 0 || throw(ArgumentError("simulation_step must be positive"))
    PlantSimEngine.bound_input(context, :all_understorey_height_m)
    PlantSimEngine.bound_input(context, :all_crown_radius_x)
    PlantSimEngine.bound_input(context, :all_diffuse_extinction_coefficients)
    status.understorey_diffuse_last_checked_step = Int(step)
    status.understorey_diffuse_recomputed_this_step = false
    status.understorey_diffuse_recompute_initialization = false
    status.understorey_diffuse_recompute_periodic = false
    initialization = iszero(status.understorey_diffuse_transmission_generation)
    retry = status.understorey_diffuse_recompute_pending
    retry isa Bool || throw(
        ArgumentError("understorey_diffuse_recompute_pending must be Bool"),
    )
    periodic = !initialization && !retry && !isnothing(model.interval_steps) &&
               mod(Int(step) - 1, model.interval_steps) == 0 &&
               status.understorey_diffuse_last_recompute_step != Int(step)
    if initialization || retry || periodic
        target = only(
            PlantSimEngine.run_call!(context, :transmission; publish=true),
        )
        field_available = target.status.understorey_diffuse_field_available
        field_available isa Bool || throw(
            ArgumentError("understorey_diffuse_field_available must be Bool"),
        )
        if !field_available
            status.understorey_diffuse_recompute_pending = true
            return nothing
        end
        status.understorey_diffuse_recompute_pending = false
        status.understorey_diffuse_transmission_generation += 1
        status.understorey_diffuse_last_recompute_step = Int(step)
        status.understorey_diffuse_recomputed_this_step = true
        status.understorey_diffuse_recompute_initialization = initialization
        status.understorey_diffuse_recompute_periodic = periodic
    end
    return nothing
end
