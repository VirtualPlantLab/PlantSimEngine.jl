PlantSimEngine.@process "shortwave_radiation_absorption" verbose = false

"""Allocated point-by-PAR/NIR result of MAESPA's shortwave `ABSRAD` branch."""
struct ShortwaveRadiationAbsorptionResult{T<:AbstractFloat}
    absorbed_direct_beam_normal_w_m2::Matrix{T}
    absorbed_diffuse_shortwave_w_m2_leaf::Matrix{T}
    absorbed_scattered_shortwave_w_m2_leaf::Matrix{T}
end

@inline function _absorption_float(
    ::Type{T},
    value::Real,
    name::AbstractString,
) where {T<:AbstractFloat}
    value isa Bool && throw(ArgumentError("$name must be numeric, not Bool"))
    converted = convert(T, value)
    isfinite(converted) || throw(ArgumentError("$name must be finite"))
    return converted
end

@noinline function _throw_absorption_unit_interval(
    value,
    name::Symbol,
    index::Int,
    nonfinite::Bool,
)
    indexed_name = iszero(index) ? String(name) : string(name, '[', index, ']')
    nonfinite && throw(ArgumentError("$indexed_name must be finite"))
    throw(DomainError(value, "$indexed_name must lie in [0, 1]"))
end

@inline function _absorption_unit_interval(
    value::T,
    name::Symbol,
    index::Int=0,
) where {T<:AbstractFloat}
    isfinite(value) || _throw_absorption_unit_interval(
        value,
        name,
        index,
        true,
    )
    zero(T) <= value <= one(T) || _throw_absorption_unit_interval(
        value,
        name,
        index,
        false,
    )
    return value
end

function _validate_shortwave_absorption_inputs(
    absorbed_direct_beam_normal_w_m2::AbstractMatrix{T},
    absorbed_diffuse_shortwave_w_m2_leaf::AbstractMatrix{T},
    absorbed_scattered_shortwave_w_m2_leaf::AbstractMatrix{T},
    relative_diffuse_penetration::AbstractVector{T},
    target_diffuse_extinction_coefficients::AbstractVector{T},
    sun_zenith_rad::T,
    beam_multiplier::T,
    incident_radiation_w_m2::AbstractVector{T},
    beam_fraction::AbstractVector{T},
    physiological_layers::AbstractVector{<:Integer},
    leaf_absorptance::AbstractMatrix{T},
    scattered_downward_shortwave_w_m2::AbstractMatrix{T},
    scattered_upward_shortwave_w_m2::AbstractMatrix{T},
) where {T<:AbstractFloat}
    Base.require_one_based_indexing(
        absorbed_direct_beam_normal_w_m2,
        absorbed_diffuse_shortwave_w_m2_leaf,
        absorbed_scattered_shortwave_w_m2_leaf,
        relative_diffuse_penetration,
        target_diffuse_extinction_coefficients,
        incident_radiation_w_m2,
        beam_fraction,
        physiological_layers,
        leaf_absorptance,
        scattered_downward_shortwave_w_m2,
        scattered_upward_shortwave_w_m2,
    )

    point_count = length(relative_diffuse_penetration)
    point_count > 0 || throw(ArgumentError("at least one point is required"))
    length(physiological_layers) == point_count || throw(
        DimensionMismatch("physiological_layers must contain $point_count values"),
    )
    expected_size = (point_count, 2)
    for (values, name) in (
        (
            absorbed_direct_beam_normal_w_m2,
            "absorbed_direct_beam_normal_w_m2",
        ),
        (
            absorbed_diffuse_shortwave_w_m2_leaf,
            "absorbed_diffuse_shortwave_w_m2_leaf",
        ),
        (
            absorbed_scattered_shortwave_w_m2_leaf,
            "absorbed_scattered_shortwave_w_m2_leaf",
        ),
        (
            scattered_downward_shortwave_w_m2,
            "scattered_downward_shortwave_w_m2",
        ),
        (
            scattered_upward_shortwave_w_m2,
            "scattered_upward_shortwave_w_m2",
        ),
    )
        size(values) == expected_size || throw(
            DimensionMismatch("$name must have size $expected_size"),
        )
    end
    length(incident_radiation_w_m2) == 2 || throw(
        DimensionMismatch("incident_radiation_w_m2 must contain PAR and NIR"),
    )
    length(beam_fraction) == 2 || throw(
        DimensionMismatch("beam_fraction must contain PAR and NIR"),
    )
    isempty(target_diffuse_extinction_coefficients) && throw(
        ArgumentError("target_diffuse_extinction_coefficients must not be empty"),
    )
    size(leaf_absorptance, 1) > 0 || throw(
        ArgumentError("leaf_absorptance must contain at least one canopy layer"),
    )
    size(leaf_absorptance, 2) >= 2 || throw(
        DimensionMismatch("leaf_absorptance must contain PAR and NIR columns"),
    )

    half_pi = T(π) / T(2)
    isfinite(sun_zenith_rad) || throw(
        ArgumentError("sun_zenith_rad must be finite"),
    )
    zero(T) <= sun_zenith_rad < half_pi || throw(
        DomainError(sun_zenith_rad, "sun_zenith_rad must lie in [0, π/2)"),
    )
    isfinite(beam_multiplier) || throw(
        ArgumentError("beam_multiplier must be finite"),
    )

    for (point_index, value) in pairs(relative_diffuse_penetration)
        isfinite(value) || throw(
            ArgumentError("relative_diffuse_penetration[$point_index] must be finite"),
        )
        value >= zero(T) || throw(
            DomainError(
                value,
                "relative_diffuse_penetration values must be non-negative",
            ),
        )
    end
    for (zenith_index, value) in pairs(target_diffuse_extinction_coefficients)
        isfinite(value) || throw(
            ArgumentError(
                "target_diffuse_extinction_coefficients[$zenith_index] must be finite",
            ),
        )
        value >= zero(T) || throw(
            DomainError(
                value,
                "diffuse extinction coefficients must be non-negative",
            ),
        )
    end

    optical_tolerance = T(8) * eps(T)
    optical_layer_count = size(leaf_absorptance, 1)
    for physiological_layer in axes(leaf_absorptance, 1), waveband_index in 1:2
        absorptance = leaf_absorptance[physiological_layer, waveband_index]
        isfinite(absorptance) || throw(
            ArgumentError(
                "leaf_absorptance[$physiological_layer,$waveband_index] must be finite",
            ),
        )
        -optical_tolerance <= absorptance <= one(T) + optical_tolerance || throw(
            DomainError(
                absorptance,
                "leaf absorptance must lie in [0, 1] within the parser's 8eps optical tolerance",
            ),
        )
    end
    for point_index in eachindex(physiological_layers)
        source_layer = physiological_layers[point_index]
        source_layer isa Bool && throw(
            ArgumentError("physiological_layers values must be integers, not Bool"),
        )
        physiological_layer = Int(source_layer)
        1 <= physiological_layer <= optical_layer_count || throw(
            DomainError(
                physiological_layer,
                "physiological_layers must index the leaf absorptance matrix",
            ),
        )
    end

    for waveband_index in 1:2
        incident = incident_radiation_w_m2[waveband_index]
        isfinite(incident) || throw(
            ArgumentError("incident shortwave radiation must be finite"),
        )
        incident >= zero(T) || throw(
            DomainError(
                incident,
                "incident shortwave radiation must be non-negative",
            ),
        )
        _absorption_unit_interval(
            beam_fraction[waveband_index],
            :beam_fraction,
            waveband_index,
        )
    end
    for point_index in axes(scattered_downward_shortwave_w_m2, 1),
        waveband_index in 1:2
        downward = scattered_downward_shortwave_w_m2[point_index, waveband_index]
        upward = scattered_upward_shortwave_w_m2[point_index, waveband_index]
        isfinite(downward) || throw(
            ArgumentError("scattered downward shortwave radiation must be finite"),
        )
        isfinite(upward) || throw(
            ArgumentError("scattered upward shortwave radiation must be finite"),
        )
    end
    return nothing
end

"""
    shortwave_radiation_absorption!(...)

Evaluate the PAR and NIR branches of MAESPA's historical `ABSRAD` routine.
All matrices use `point × waveband` ordering, with PAR in column 1 and NIR in
column 2.

The direct result is the absorbed beam flux normal to the beam. It deliberately
does not include `BEXT`, `BEXTANG`, `SUNLA`, or the magnitude of `BMULT`; those
belong to the downstream sunlit/shaded partition. As in Fortran, `BMULT` is
only an exact-zero gate. For `sun_zenith_rad > 1.56`, direct radiation is set
to zero for both wavebands deterministically, reproducing the mutation of
`BMULT` in the scalar legacy routine.

Diffuse extinction is the unweighted arithmetic mean across the target's
zenith classes. It multiplies only `(DIFDN + DIFUP)`: `RELDF` already contains
the direct-diffuse extinction effect and is never multiplied by this mean.
"""
function shortwave_radiation_absorption!(
    absorbed_direct_beam_normal_w_m2::AbstractMatrix{T},
    absorbed_diffuse_shortwave_w_m2_leaf::AbstractMatrix{T},
    absorbed_scattered_shortwave_w_m2_leaf::AbstractMatrix{T},
    relative_diffuse_penetration::AbstractVector{T},
    target_diffuse_extinction_coefficients::AbstractVector{T},
    sun_zenith_rad::T,
    beam_multiplier::T,
    incident_radiation_w_m2::AbstractVector{T},
    beam_fraction::AbstractVector{T},
    physiological_layers::AbstractVector{<:Integer},
    leaf_absorptance::AbstractMatrix{T},
    scattered_downward_shortwave_w_m2::AbstractMatrix{T},
    scattered_upward_shortwave_w_m2::AbstractMatrix{T},
) where {T<:AbstractFloat}
    _validate_shortwave_absorption_inputs(
        absorbed_direct_beam_normal_w_m2,
        absorbed_diffuse_shortwave_w_m2_leaf,
        absorbed_scattered_shortwave_w_m2_leaf,
        relative_diffuse_penetration,
        target_diffuse_extinction_coefficients,
        sun_zenith_rad,
        beam_multiplier,
        incident_radiation_w_m2,
        beam_fraction,
        physiological_layers,
        leaf_absorptance,
        scattered_downward_shortwave_w_m2,
        scattered_upward_shortwave_w_m2,
    )

    return _shortwave_absorption_kernel!(
        absorbed_direct_beam_normal_w_m2, absorbed_diffuse_shortwave_w_m2_leaf,
        absorbed_scattered_shortwave_w_m2_leaf, relative_diffuse_penetration,
        target_diffuse_extinction_coefficients, sun_zenith_rad, beam_multiplier,
        incident_radiation_w_m2, beam_fraction, physiological_layers, leaf_absorptance,
        scattered_downward_shortwave_w_m2, scattered_upward_shortwave_w_m2,
    )
end

# Internal calculation: fixed layout and parameter validation belong to its caller.
function _shortwave_absorption_kernel!(
    absorbed_direct_beam_normal_w_m2::AbstractMatrix{T},
    absorbed_diffuse_shortwave_w_m2_leaf::AbstractMatrix{T},
    absorbed_scattered_shortwave_w_m2_leaf::AbstractMatrix{T},
    relative_diffuse_penetration::AbstractVector{T},
    target_diffuse_extinction_coefficients::AbstractVector{T},
    sun_zenith_rad::T,
    beam_multiplier::T,
    incident_radiation_w_m2::AbstractVector{T},
    beam_fraction::AbstractVector{T},
    physiological_layers::AbstractVector{<:Integer},
    leaf_absorptance::AbstractMatrix{T},
    scattered_downward_shortwave_w_m2::AbstractMatrix{T},
    scattered_upward_shortwave_w_m2::AbstractMatrix{T},
) where {T<:AbstractFloat}
    diffuse_extinction_mean = zero(T)
    for coefficient in target_diffuse_extinction_coefficients
        diffuse_extinction_mean += coefficient
    end
    diffuse_extinction_mean /= T(length(target_diffuse_extinction_coefficients))
    direct_is_zero =
        iszero(beam_multiplier) || sun_zenith_rad > T(1.56)
    cosine_zenith = direct_is_zero ? one(T) : cos(sun_zenith_rad)

    for point_index in eachindex(relative_diffuse_penetration)
        physiological_layer = Int(physiological_layers[point_index])
        relative_diffuse = relative_diffuse_penetration[point_index]
        for waveband_index in 1:2
            incident = incident_radiation_w_m2[waveband_index]
            beam = beam_fraction[waveband_index]
            absorptance = leaf_absorptance[physiological_layer, waveband_index]
            absorbed_direct_beam_normal_w_m2[point_index, waveband_index] =
                direct_is_zero ? zero(T) :
                incident * beam / cosine_zenith * absorptance

            direct_diffuse = relative_diffuse * incident * (one(T) - beam)
            scattered = (
                scattered_downward_shortwave_w_m2[point_index, waveband_index] +
                scattered_upward_shortwave_w_m2[point_index, waveband_index]
            ) * diffuse_extinction_mean
            absorbed_scattered = scattered * absorptance
            absorbed_scattered_shortwave_w_m2_leaf[
                point_index,
                waveband_index,
            ] = absorbed_scattered
            absorbed_diffuse_shortwave_w_m2_leaf[point_index, waveband_index] =
                (direct_diffuse + scattered) * absorptance
        end
    end
    return nothing
end

"""Allocate and return MAESPA's point-by-PAR/NIR shortwave `ABSRAD` result."""
function shortwave_radiation_absorption(
    relative_diffuse_penetration::AbstractVector{T},
    target_diffuse_extinction_coefficients::AbstractVector{T},
    sun_zenith_rad::T,
    beam_multiplier::T,
    incident_radiation_w_m2::AbstractVector{T},
    beam_fraction::AbstractVector{T},
    physiological_layers::AbstractVector{<:Integer},
    leaf_absorptance::AbstractMatrix{T},
    scattered_downward_shortwave_w_m2::AbstractMatrix{T},
    scattered_upward_shortwave_w_m2::AbstractMatrix{T},
) where {T<:AbstractFloat}
    point_count = length(relative_diffuse_penetration)
    result = ShortwaveRadiationAbsorptionResult(
        zeros(T, point_count, 2),
        zeros(T, point_count, 2),
        zeros(T, point_count, 2),
    )
    shortwave_radiation_absorption!(
        result.absorbed_direct_beam_normal_w_m2,
        result.absorbed_diffuse_shortwave_w_m2_leaf,
        result.absorbed_scattered_shortwave_w_m2_leaf,
        relative_diffuse_penetration,
        target_diffuse_extinction_coefficients,
        sun_zenith_rad,
        beam_multiplier,
        incident_radiation_w_m2,
        beam_fraction,
        physiological_layers,
        leaf_absorptance,
        scattered_downward_shortwave_w_m2,
        scattered_upward_shortwave_w_m2,
    )
    return result
end

"""Per-target PlantSimEngine wrapper for shortwave `ABSRAD`."""
struct MAESPAShortwaveRadiationAbsorption{T<:AbstractFloat} <:
       AbstractShortwave_Radiation_AbsorptionModel
    point_count::Int
    zero_value::T
end

function MAESPAShortwaveRadiationAbsorption(
    ::Type{T},
    point_count::Integer,
) where {T<:AbstractFloat}
    point_count isa Bool && throw(
        ArgumentError("point_count must be an integer, not Bool"),
    )
    point_count > 0 || throw(ArgumentError("point_count must be positive"))
    return MAESPAShortwaveRadiationAbsorption{T}(Int(point_count), zero(T))
end

PlantSimEngine.inputs_(::MAESPAShortwaveRadiationAbsorption) = (
    relative_diffuse_penetration=PlantSimEngine.Required(AbstractVector),
    target_diffuse_extinction_coefficients=PlantSimEngine.Required(AbstractVector),
    sun_zenith_rad=PlantSimEngine.Required(Real),
    astronomical_daylight=PlantSimEngine.Required(Bool),
    target_leaf_area=PlantSimEngine.Required(Real),
    slope_beam_multiplier=PlantSimEngine.Required(Real),
    incident_par_w_m2=PlantSimEngine.Required(Real),
    incident_nir_w_m2=PlantSimEngine.Required(Real),
    beam_fraction_par=PlantSimEngine.Required(Real),
    beam_fraction_nir=PlantSimEngine.Required(Real),
    physiological_layers=PlantSimEngine.Required(AbstractVector),
    leaf_absorptance=PlantSimEngine.Required(AbstractMatrix),
    scattered_downward_shortwave_w_m2=PlantSimEngine.Required(AbstractMatrix),
    scattered_upward_shortwave_w_m2=PlantSimEngine.Required(AbstractMatrix),
    diffuse_transmission_available=PlantSimEngine.Required(Bool),
    shortwave_scattering_available=PlantSimEngine.Required(Bool),
)

PlantSimEngine.variable_contracts_(::MAESPAShortwaveRadiationAbsorption) =
    merge(HORIZONTAL_PAR_FORCING_CONTRACTS, (
        relative_diffuse_penetration=LEAF_RELATIVE_DIFFUSE_PENETRATION_CONTRACT,
        diffuse_transmission_available=DIFFUSE_TRANSMISSION_AVAILABLE_CONTRACT,
        shortwave_scattering_available=SHORTWAVE_SCATTERING_AVAILABLE_CONTRACT,
    ))

function PlantSimEngine.outputs_(
    model::MAESPAShortwaveRadiationAbsorption{T},
) where {T}
    return (
        absorbed_direct_beam_normal_w_m2=zeros(T, model.point_count, 2),
        absorbed_diffuse_shortwave_w_m2_leaf=zeros(T, model.point_count, 2),
        absorbed_scattered_shortwave_w_m2_leaf=zeros(T, model.point_count, 2),
        shortwave_absorption_available=false,
        shortwave_absorption_incident_radiation_buffer=zeros(T, 2),
        shortwave_absorption_beam_fraction_buffer=zeros(T, 2),
    )
end

function _reset_shortwave_absorption_outputs!(status, ::Type{T}) where {T}
    fill!(status.absorbed_direct_beam_normal_w_m2, zero(T))
    fill!(status.absorbed_diffuse_shortwave_w_m2_leaf, zero(T))
    fill!(status.absorbed_scattered_shortwave_w_m2_leaf, zero(T))
    status.shortwave_absorption_available = false
    return nothing
end

@noinline function _throw_shortwave_absorption_eltype(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and shortwave absorption output buffers must share a numeric type",
        ),
    )
end

@inline function _validate_shortwave_absorption_eltype(
    values,
    ::Type{T},
    name::Symbol,
) where {T}
    eltype(values) === T || _throw_shortwave_absorption_eltype(name)
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPAShortwaveRadiationAbsorption,
    status,
    environment,
    constants,
    context,
)
    # Invalidate before any conversion or validation can fail so no consumer
    # can mistake an earlier successful result for the current timestep.
    status.shortwave_absorption_available = false
    T = eltype(status.absorbed_direct_beam_normal_w_m2)
    _validate_shortwave_absorption_eltype(
        status.absorbed_diffuse_shortwave_w_m2_leaf,
        T,
        :absorbed_diffuse_shortwave_w_m2_leaf,
    )
    _validate_shortwave_absorption_eltype(
        status.absorbed_scattered_shortwave_w_m2_leaf,
        T,
        :absorbed_scattered_shortwave_w_m2_leaf,
    )
    _validate_shortwave_absorption_eltype(
        status.relative_diffuse_penetration,
        T,
        :relative_diffuse_penetration,
    )
    _validate_shortwave_absorption_eltype(
        status.target_diffuse_extinction_coefficients,
        T,
        :target_diffuse_extinction_coefficients,
    )
    _validate_shortwave_absorption_eltype(
        status.leaf_absorptance,
        T,
        :leaf_absorptance,
    )
    _validate_shortwave_absorption_eltype(
        status.scattered_downward_shortwave_w_m2,
        T,
        :scattered_downward_shortwave_w_m2,
    )
    _validate_shortwave_absorption_eltype(
        status.scattered_upward_shortwave_w_m2,
        T,
        :scattered_upward_shortwave_w_m2,
    )
    _validate_shortwave_absorption_eltype(
        status.shortwave_absorption_incident_radiation_buffer,
        T,
        :shortwave_absorption_incident_radiation_buffer,
    )
    _validate_shortwave_absorption_eltype(
        status.shortwave_absorption_beam_fraction_buffer,
        T,
        :shortwave_absorption_beam_fraction_buffer,
    )

    daylight = status.astronomical_daylight
    diffuse_available = status.diffuse_transmission_available
    scattering_available = status.shortwave_scattering_available
    daylight isa Bool || throw(
        ArgumentError("astronomical_daylight must be Bool"),
    )
    diffuse_available isa Bool || throw(
        ArgumentError("diffuse_transmission_available must be Bool"),
    )
    scattering_available isa Bool || throw(
        ArgumentError("shortwave_scattering_available must be Bool"),
    )
    incident_par = _absorption_float(
        T,
        status.incident_par_w_m2,
        "incident_par_w_m2",
    )
    target_leaf_area = _absorption_float(
        T,
        status.target_leaf_area,
        "target_leaf_area",
    )
    target_leaf_area >= zero(T) || throw(
        DomainError(target_leaf_area, "target_leaf_area must be non-negative"),
    )
    if !daylight || !diffuse_available || !scattering_available ||
       incident_par <= one(T) || target_leaf_area <= zero(T)
        _reset_shortwave_absorption_outputs!(status, T)
        return nothing
    end

    incident = status.shortwave_absorption_incident_radiation_buffer
    beam_fraction = status.shortwave_absorption_beam_fraction_buffer
    incident[1] = incident_par
    incident[2] = _absorption_float(
        T,
        status.incident_nir_w_m2,
        "incident_nir_w_m2",
    )
    beam_fraction[1] = _absorption_float(
        T,
        status.beam_fraction_par,
        "beam_fraction_par",
    )
    beam_fraction[2] = _absorption_float(
        T,
        status.beam_fraction_nir,
        "beam_fraction_nir",
    )
    shortwave_radiation_absorption!(
        status.absorbed_direct_beam_normal_w_m2,
        status.absorbed_diffuse_shortwave_w_m2_leaf,
        status.absorbed_scattered_shortwave_w_m2_leaf,
        status.relative_diffuse_penetration,
        status.target_diffuse_extinction_coefficients,
        _absorption_float(T, status.sun_zenith_rad, "sun_zenith_rad"),
        _absorption_float(
            T,
            status.slope_beam_multiplier,
            "slope_beam_multiplier",
        ),
        incident,
        beam_fraction,
        status.physiological_layers,
        status.leaf_absorptance,
        status.scattered_downward_shortwave_w_m2,
        status.scattered_upward_shortwave_w_m2,
    )
    status.shortwave_absorption_available = true
    return nothing
end
