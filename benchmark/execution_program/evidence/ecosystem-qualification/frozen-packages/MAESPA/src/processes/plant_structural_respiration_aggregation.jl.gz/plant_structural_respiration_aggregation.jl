PlantSimEngine.@process "plant_structural_respiration_aggregation" verbose = false

const _PLANT_STRUCTURAL_RESPIRATION_ROLES =
    (:stem, :branch_system, :fine_root, :coarse_root)

"""
Plant-level structural-respiration totals and their availability diagnostics.

The maintenance and growth channels deliberately retain different units:

- `structural_maintenance_respiration_umol_co2_tree_s` is an instantaneous
  rate in umol CO2 tree-1 s-1;
- `structural_growth_respiration_mol_co2_tree_day` is a daily amount in
  mol CO2 tree-1 day-1.
- `structural_growth_respiration_date50` is the common positive date of that
  amount, or `0` when the growth channel is unavailable.

No conversion or addition is ever performed between these two channels.
"""
struct PlantStructuralRespirationAggregationResult{T<:AbstractFloat}
    structural_maintenance_respiration_umol_co2_tree_s::T
    structural_growth_respiration_mol_co2_tree_day::T
    structural_growth_respiration_date50::Int
    structural_maintenance_respiration_available::Bool
    structural_growth_respiration_available::Bool
    structural_respiration_compartment_count::Int
    structural_respiration_missing_compartment_count::Int
    structural_maintenance_respiration_available_compartment_count::Int
    structural_growth_respiration_available_compartment_count::Int
    structural_respiration_compartment_set_complete::Bool
    plant_structural_respiration_aggregation_available::Bool
end

@noinline function _throw_plant_structural_respiration_aggregation(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :type
        throw(
            ArgumentError(
                "the plant structural-respiration numeric type must be concrete",
            ),
        )
    elseif reason === :vector
        throw(ArgumentError("$label must be an AbstractVector"))
    elseif reason === :role
        throw(
            ArgumentError(
                "$label values must be one of " *
                "$(repr(_PLANT_STRUCTURAL_RESPIRATION_ROLES)); got $(repr(value))",
            ),
        )
    elseif reason === :duplicate_role
        throw(
            ArgumentError(
                "structural compartment role $(repr(value)) occurs more than once",
            ),
        )
    elseif reason === :bool
        throw(ArgumentError("$label values must be Bool"))
    elseif reason === :real
        throw(ArgumentError("$label values must be real numbers, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label values must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label values must be non-negative"))
    elseif reason === :integer
        throw(ArgumentError("$label values must be integers, not Bool"))
    elseif reason === :int_range
        throw(ArgumentError("$label values must be representable as Int"))
    elseif reason === :positive_date
        throw(DomainError(value, "$label values must be positive"))
    elseif reason === :date_mismatch
        throw(
            ArgumentError(
                "available structural growth-respiration compartments must " *
                "share one date50; got $(repr(value))",
            ),
        )
    elseif reason === :output
        throw(
            ArgumentError(
                "plant structural-respiration floating outputs must share " *
                "one concrete AbstractFloat type",
            ),
        )
    elseif reason === :integer_output
        throw(ArgumentError("$label must use Int as its output carrier"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _plant_structural_respiration_date50(value, name::Symbol)
    value isa Integer && !(value isa Bool) ||
        _throw_plant_structural_respiration_aggregation(name, value, :integer)
    converted = try
        Int(value)
    catch exception
        exception isa InexactError || exception isa OverflowError || rethrow()
        _throw_plant_structural_respiration_aggregation(
            name,
            value,
            :int_range,
        )
    end
    converted > 0 ||
        _throw_plant_structural_respiration_aggregation(
            name,
            converted,
            :positive_date,
        )
    return converted
end

@inline function _plant_structural_respiration_vector(values, name::Symbol)
    values isa AbstractVector ||
        _throw_plant_structural_respiration_aggregation(
            name,
            values,
            :vector,
        )
    Base.require_one_based_indexing(values)
    return values
end

@inline function _plant_structural_respiration_role_index(role)
    role isa Symbol ||
        _throw_plant_structural_respiration_aggregation(
            :structural_respiration_compartment_roles,
            role,
            :role,
        )
    role === :stem && return 1
    role === :branch_system && return 2
    role === :fine_root && return 3
    role === :coarse_root && return 4
    _throw_plant_structural_respiration_aggregation(
        :structural_respiration_compartment_roles,
        role,
        :role,
    )
end

@inline function _plant_structural_respiration_bool(value, name::Symbol)
    value isa Bool ||
        _throw_plant_structural_respiration_aggregation(name, value, :bool)
    return value
end

@inline function _plant_structural_respiration_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real && !(value isa Bool) ||
        _throw_plant_structural_respiration_aggregation(name, value, :real)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_plant_structural_respiration_aggregation(
            name,
            converted,
            :finite,
        )
    converted >= zero(T) ||
        _throw_plant_structural_respiration_aggregation(
            name,
            converted,
            :nonnegative,
        )
    return converted
end

function _plant_structural_respiration_matching_lengths(reference, arrays)
    count = length(reference)
    for (values, name) in arrays
        length(values) == count || throw(
            DimensionMismatch("$(String(name)) must contain $count values"),
        )
    end
    return count
end

@inline function _plant_structural_respiration_canonical_sum(
    values::Vector{T},
    name::Symbol,
) where {T<:AbstractFloat}
    total = zero(T)
    for index in eachindex(_PLANT_STRUCTURAL_RESPIRATION_ROLES)
        total += values[index]
        isfinite(total) ||
            _throw_plant_structural_respiration_aggregation(
                name,
                total,
                :finite,
            )
    end
    return total
end

"""
    plant_structural_respiration_aggregation(
        T,
        compartment_roles,
        maintenance_rates,
        maintenance_available,
        growth_amounts,
        growth_available,
        growth_date50,
    )

Aggregate one `:stem`, one `:branch_system`, one `:fine_root`, and one
`:coarse_root` contribution for a single Plant. Input collection order has no
biological meaning: roles are validated and totals are added in the canonical
order above.

`maintenance_rates` contains umol CO2 s-1 for whole structural compartments;
its available total is therefore published as umol CO2 tree-1 s-1.
`growth_amounts` contains mol CO2 tree-1 day-1 for the same compartments and
is summed independently. Every available growth amount carries a strictly
positive `growth_date50`. The four dates must agree before the daily amount and
its common `structural_growth_respiration_date50` are published. A missing
expected role makes both totals unavailable. An unavailable channel value and
date are not inspected, so a producer can use private sentinel storage behind
a false availability flag without leaking it into the public aggregate.
Unknown and duplicate roles are configuration errors.

`T` is normally the floating output-carrier type selected by PlantSimEngine,
including through a global `type_promotion` mapping.
"""
function plant_structural_respiration_aggregation(
    ::Type{T},
    structural_respiration_compartment_roles,
    structural_compartment_maintenance_respiration_umol_co2_s,
    structural_compartment_maintenance_respiration_available,
    structural_compartment_growth_respiration_mol_co2_tree_day,
    structural_compartment_growth_respiration_available,
    structural_compartment_growth_respiration_date50,
) where {T<:AbstractFloat}
    isconcretetype(T) ||
        _throw_plant_structural_respiration_aggregation(:numeric_type, T, :type)

    roles = _plant_structural_respiration_vector(
        structural_respiration_compartment_roles,
        :structural_respiration_compartment_roles,
    )
    maintenance_rates = _plant_structural_respiration_vector(
        structural_compartment_maintenance_respiration_umol_co2_s,
        :structural_compartment_maintenance_respiration_umol_co2_s,
    )
    maintenance_flags = _plant_structural_respiration_vector(
        structural_compartment_maintenance_respiration_available,
        :structural_compartment_maintenance_respiration_available,
    )
    growth_amounts = _plant_structural_respiration_vector(
        structural_compartment_growth_respiration_mol_co2_tree_day,
        :structural_compartment_growth_respiration_mol_co2_tree_day,
    )
    growth_flags = _plant_structural_respiration_vector(
        structural_compartment_growth_respiration_available,
        :structural_compartment_growth_respiration_available,
    )
    growth_dates = _plant_structural_respiration_vector(
        structural_compartment_growth_respiration_date50,
        :structural_compartment_growth_respiration_date50,
    )
    compartment_count = _plant_structural_respiration_matching_lengths(
        roles,
        (
            (
                maintenance_rates,
                :structural_compartment_maintenance_respiration_umol_co2_s,
            ),
            (
                maintenance_flags,
                :structural_compartment_maintenance_respiration_available,
            ),
            (
                growth_amounts,
                :structural_compartment_growth_respiration_mol_co2_tree_day,
            ),
            (
                growth_flags,
                :structural_compartment_growth_respiration_available,
            ),
            (
                growth_dates,
                :structural_compartment_growth_respiration_date50,
            ),
        ),
    )

    present = fill(false, length(_PLANT_STRUCTURAL_RESPIRATION_ROLES))
    maintenance_by_role = zeros(T, length(_PLANT_STRUCTURAL_RESPIRATION_ROLES))
    growth_by_role = zeros(T, length(_PLANT_STRUCTURAL_RESPIRATION_ROLES))
    growth_date_by_role = zeros(Int, length(_PLANT_STRUCTURAL_RESPIRATION_ROLES))
    maintenance_available_by_role =
        fill(false, length(_PLANT_STRUCTURAL_RESPIRATION_ROLES))
    growth_available_by_role =
        fill(false, length(_PLANT_STRUCTURAL_RESPIRATION_ROLES))

    for position in eachindex(roles)
        role = roles[position]
        role_index = _plant_structural_respiration_role_index(role)
        present[role_index] &&
            _throw_plant_structural_respiration_aggregation(
                :structural_respiration_compartment_roles,
                role,
                :duplicate_role,
            )
        present[role_index] = true

        maintenance_flag = _plant_structural_respiration_bool(
            maintenance_flags[position],
            :structural_compartment_maintenance_respiration_available,
        )
        growth_flag = _plant_structural_respiration_bool(
            growth_flags[position],
            :structural_compartment_growth_respiration_available,
        )
        maintenance_available_by_role[role_index] = maintenance_flag
        growth_available_by_role[role_index] = growth_flag

        if maintenance_flag
            maintenance_by_role[role_index] =
                _plant_structural_respiration_float(
                    T,
                    maintenance_rates[position],
                    :structural_compartment_maintenance_respiration_umol_co2_s,
                )
        end
        if growth_flag
            growth_by_role[role_index] = _plant_structural_respiration_float(
                T,
                growth_amounts[position],
                :structural_compartment_growth_respiration_mol_co2_tree_day,
            )
            growth_date_by_role[role_index] =
                _plant_structural_respiration_date50(
                    growth_dates[position],
                    :structural_compartment_growth_respiration_date50,
                )
        end
    end

    expected_count = length(_PLANT_STRUCTURAL_RESPIRATION_ROLES)
    missing_count = expected_count - count(identity, present)
    compartment_set_complete = iszero(missing_count)
    maintenance_available_count =
        count(identity, maintenance_available_by_role)
    growth_available_count = count(identity, growth_available_by_role)
    maintenance_available =
        compartment_set_complete && maintenance_available_count == expected_count
    growth_available =
        compartment_set_complete && growth_available_count == expected_count

    maintenance_total = if maintenance_available
        _plant_structural_respiration_canonical_sum(
            maintenance_by_role,
            :structural_maintenance_respiration_umol_co2_tree_s,
        )
    else
        zero(T)
    end
    growth_total = if growth_available
        _plant_structural_respiration_canonical_sum(
            growth_by_role,
            :structural_growth_respiration_mol_co2_tree_day,
        )
    else
        zero(T)
    end
    growth_date50 = if growth_available
        common_date = first(growth_date_by_role)
        all(==(common_date), growth_date_by_role) ||
            _throw_plant_structural_respiration_aggregation(
                :structural_compartment_growth_respiration_date50,
                growth_date_by_role,
                :date_mismatch,
            )
        common_date
    else
        0
    end

    return PlantStructuralRespirationAggregationResult{T}(
        maintenance_total,
        growth_total,
        growth_date50,
        maintenance_available,
        growth_available,
        compartment_count,
        missing_count,
        maintenance_available_count,
        growth_available_count,
        compartment_set_complete,
        maintenance_available && growth_available,
    )
end

"""
    MAESPAPlantStructuralRespirationAggregation(T=Float64)

PlantSimEngine adapter for `plant_structural_respiration_aggregation`.

The six collection inputs are intended to use identical `Many(...)`
selectors over the Plant subtree. In particular, an explicit status-backed
binding can select the heterogeneous scales with
`scale=(:Stem, :BranchSystem, :RootPool), within=Subtree(),
from_status=true`. The role vector removes any dependence on the selector's
incidental object order and identifies the two RootPool objects.

The two floating output carriers select the calculation type. Invalid active
input leaves the last accepted snapshot unchanged; disabling either global
gate publishes a fresh all-zero unavailable snapshot without inspecting the
collections.
"""
struct MAESPAPlantStructuralRespirationAggregation{T<:AbstractFloat} <:
       AbstractPlant_Structural_Respiration_AggregationModel
    zero_value::T
end

function MAESPAPlantStructuralRespirationAggregation(
    ::Type{T}=Float64,
) where {T<:AbstractFloat}
    isconcretetype(T) ||
        _throw_plant_structural_respiration_aggregation(:numeric_type, T, :type)
    return MAESPAPlantStructuralRespirationAggregation{T}(zero(T))
end

PlantSimEngine.inputs_(::MAESPAPlantStructuralRespirationAggregation) = (
    structural_respiration_compartment_roles=
        PlantSimEngine.Required(AbstractVector),
    structural_compartment_maintenance_respiration_umol_co2_s=
        PlantSimEngine.Required(AbstractVector),
    structural_compartment_maintenance_respiration_available=
        PlantSimEngine.Required(AbstractVector),
    structural_compartment_growth_respiration_mol_co2_tree_day=
        PlantSimEngine.Required(AbstractVector),
    structural_compartment_growth_respiration_available=
        PlantSimEngine.Required(AbstractVector),
    structural_compartment_growth_respiration_date50=
        PlantSimEngine.Required(AbstractVector),
    plant_structural_respiration_aggregation_active=PlantSimEngine.Default(true),
    plant_structural_respiration_aggregation_inputs_available=
        PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(
    model::MAESPAPlantStructuralRespirationAggregation{T},
) where {T} = (
    structural_maintenance_respiration_umol_co2_tree_s=zero(T),
    structural_growth_respiration_mol_co2_tree_day=zero(T),
    structural_growth_respiration_date50=0,
    structural_maintenance_respiration_available=false,
    structural_growth_respiration_available=false,
    structural_respiration_compartment_count=0,
    structural_respiration_missing_compartment_count=0,
    structural_maintenance_respiration_available_compartment_count=0,
    structural_growth_respiration_available_compartment_count=0,
    structural_respiration_compartment_set_complete=false,
    plant_structural_respiration_aggregation_available=false,
)

function _plant_structural_respiration_output_type(status)
    maintenance = status.structural_maintenance_respiration_umol_co2_tree_s
    T = typeof(maintenance)
    T <: AbstractFloat && isconcretetype(T) ||
        _throw_plant_structural_respiration_aggregation(
            :structural_maintenance_respiration_umol_co2_tree_s,
            maintenance,
            :output,
        )
    growth = status.structural_growth_respiration_mol_co2_tree_day
    typeof(growth) === T ||
        _throw_plant_structural_respiration_aggregation(
            :structural_growth_respiration_mol_co2_tree_day,
            growth,
            :output,
        )

    for name in (
        :structural_growth_respiration_date50,
        :structural_respiration_compartment_count,
        :structural_respiration_missing_compartment_count,
        :structural_maintenance_respiration_available_compartment_count,
        :structural_growth_respiration_available_compartment_count,
    )
        typeof(getproperty(status, name)) === Int ||
            _throw_plant_structural_respiration_aggregation(
                name,
                getproperty(status, name),
                :integer_output,
            )
    end
    for name in (
        :structural_maintenance_respiration_available,
        :structural_growth_respiration_available,
        :structural_respiration_compartment_set_complete,
        :plant_structural_respiration_aggregation_available,
    )
        getproperty(status, name) isa Bool || throw(
            ArgumentError("$(String(name)) must be Bool"),
        )
    end
    return T
end

@inline function _reset_plant_structural_respiration_aggregation!(
    status,
    ::Type{T},
) where {T<:AbstractFloat}
    status.structural_maintenance_respiration_umol_co2_tree_s = zero(T)
    status.structural_growth_respiration_mol_co2_tree_day = zero(T)
    status.structural_growth_respiration_date50 = 0
    status.structural_maintenance_respiration_available = false
    status.structural_growth_respiration_available = false
    status.structural_respiration_compartment_count = 0
    status.structural_respiration_missing_compartment_count = 0
    status.structural_maintenance_respiration_available_compartment_count = 0
    status.structural_growth_respiration_available_compartment_count = 0
    status.structural_respiration_compartment_set_complete = false
    status.plant_structural_respiration_aggregation_available = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPAPlantStructuralRespirationAggregation,
    status,
    environment,
    constants,
    context,
)
    T = _plant_structural_respiration_output_type(status)
    active = status.plant_structural_respiration_aggregation_active
    inputs_available =
        status.plant_structural_respiration_aggregation_inputs_available
    active isa Bool || throw(
        ArgumentError(
            "plant_structural_respiration_aggregation_active must be Bool",
        ),
    )
    inputs_available isa Bool || throw(
        ArgumentError(
            "plant_structural_respiration_aggregation_inputs_available must be Bool",
        ),
    )
    if !(active && inputs_available)
        _reset_plant_structural_respiration_aggregation!(status, T)
        return nothing
    end

    result = plant_structural_respiration_aggregation(
        T,
        status.structural_respiration_compartment_roles,
        status.structural_compartment_maintenance_respiration_umol_co2_s,
        status.structural_compartment_maintenance_respiration_available,
        status.structural_compartment_growth_respiration_mol_co2_tree_day,
        status.structural_compartment_growth_respiration_available,
        status.structural_compartment_growth_respiration_date50,
    )

    status.structural_maintenance_respiration_umol_co2_tree_s =
        result.structural_maintenance_respiration_umol_co2_tree_s
    status.structural_growth_respiration_mol_co2_tree_day =
        result.structural_growth_respiration_mol_co2_tree_day
    status.structural_growth_respiration_date50 =
        result.structural_growth_respiration_date50
    status.structural_maintenance_respiration_available =
        result.structural_maintenance_respiration_available
    status.structural_growth_respiration_available =
        result.structural_growth_respiration_available
    status.structural_respiration_compartment_count =
        result.structural_respiration_compartment_count
    status.structural_respiration_missing_compartment_count =
        result.structural_respiration_missing_compartment_count
    status.structural_maintenance_respiration_available_compartment_count =
        result.structural_maintenance_respiration_available_compartment_count
    status.structural_growth_respiration_available_compartment_count =
        result.structural_growth_respiration_available_compartment_count
    status.structural_respiration_compartment_set_complete =
        result.structural_respiration_compartment_set_complete
    status.plant_structural_respiration_aggregation_available =
        result.plant_structural_respiration_aggregation_available
    return nothing
end

"""
    MAESPAUnavailablePlantStructuralRespirationAggregation(
        T=Float64;
        reason=:missing_stem_diameter,
    )

PlantSimEngine implementation of plant structural-respiration aggregation for
a Plant whose required structural geometry is unavailable.

This model has no scientific inputs. Every call publishes a fresh unavailable
snapshot using the existing structural-aggregation output contract, plus
`structural_respiration_unavailable_reason`. The floating calculation type is
taken from the live output carriers, so a global PlantSimEngine
`type_promotion` mapping remains authoritative.
"""
struct MAESPAUnavailablePlantStructuralRespirationAggregation{T<:AbstractFloat} <:
       AbstractPlant_Structural_Respiration_AggregationModel
    zero_value::T
    reason::Symbol
end

function MAESPAUnavailablePlantStructuralRespirationAggregation(
    ::Type{T}=Float64;
    reason::Symbol=:missing_stem_diameter,
) where {T<:AbstractFloat}
    isconcretetype(T) ||
        _throw_plant_structural_respiration_aggregation(:numeric_type, T, :type)
    return MAESPAUnavailablePlantStructuralRespirationAggregation{T}(
        zero(T),
        reason,
    )
end

PlantSimEngine.inputs_(
    ::MAESPAUnavailablePlantStructuralRespirationAggregation,
) = NamedTuple()

PlantSimEngine.outputs_(
    model::MAESPAUnavailablePlantStructuralRespirationAggregation{T},
) where {T} = (
    structural_maintenance_respiration_umol_co2_tree_s=zero(T),
    structural_growth_respiration_mol_co2_tree_day=zero(T),
    structural_growth_respiration_date50=0,
    structural_maintenance_respiration_available=false,
    structural_growth_respiration_available=false,
    structural_respiration_compartment_count=0,
    structural_respiration_missing_compartment_count=0,
    structural_maintenance_respiration_available_compartment_count=0,
    structural_growth_respiration_available_compartment_count=0,
    structural_respiration_compartment_set_complete=false,
    plant_structural_respiration_aggregation_available=false,
    structural_respiration_unavailable_reason=model.reason,
)

function _unavailable_plant_structural_respiration_output_type(status)
    T = _plant_structural_respiration_output_type(status)
    reason = status.structural_respiration_unavailable_reason
    reason isa Symbol || throw(
        ArgumentError(
            "structural_respiration_unavailable_reason must be a Symbol",
        ),
    )
    return T
end

function PlantSimEngine.run!(
    model::MAESPAUnavailablePlantStructuralRespirationAggregation,
    status,
    environment,
    constants,
    context,
)
    T = _unavailable_plant_structural_respiration_output_type(status)

    # Validate every carrier before changing any output. Once validated, all
    # assignments below preserve the exact carrier types selected by PSE.
    _reset_plant_structural_respiration_aggregation!(status, T)
    status.structural_respiration_unavailable_reason = model.reason
    return nothing
end
