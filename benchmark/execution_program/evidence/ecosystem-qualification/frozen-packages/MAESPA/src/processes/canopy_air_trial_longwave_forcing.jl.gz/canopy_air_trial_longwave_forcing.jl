PlantSimEngine.@process "canopy_air_trial_longwave_forcing" verbose = false

@noinline function _throw_canopy_air_trial_longwave_forcing(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :snapshot
        throw(
            ArgumentError(
                "$label must be an available MAESPACanopyThermalSnapshot " *
                "using the effective output type",
            ),
        )
    elseif reason === :target
        throw(
            BoundsError(
                "target_index does not select a row of $label",
                value,
            ),
        )
    elseif reason === :points
        throw(
            DimensionMismatch(
                "$label must contain the configured number of points",
            ),
        )
    elseif reason === :availability
        throw(ArgumentError("$label must be Bool"))
    elseif reason === :output_type
        throw(
            ArgumentError(
                "$label and all trial-longwave output carriers must share " *
                "one concrete floating-point type",
            ),
        )
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _canopy_air_trial_longwave_target_index(value::Integer)
    value isa Bool && throw(
        ArgumentError("target_index must be an integer, not Bool"),
    )
    value > 0 || throw(ArgumentError("target_index must be positive"))
    value <= typemax(Int) || throw(
        ArgumentError("target_index must be representable as Int"),
    )
    return Int(value)
end

function _canopy_air_trial_longwave_snapshot_row(
    snapshot,
    ::Type{T},
    target_index::Int,
    point_count::Int,
) where {T<:AbstractFloat}
    snapshot isa MAESPACanopyThermalSnapshot{T} ||
        _throw_canopy_air_trial_longwave_forcing(
            :canopy_thermal_snapshot,
            snapshot,
            :snapshot,
        )
    _validate_canopy_thermal_snapshot(snapshot)
    snapshot.available || _throw_canopy_air_trial_longwave_forcing(
        :canopy_thermal_snapshot,
        snapshot,
        :snapshot,
    )
    matrix = snapshot.leaf_temperature_c_by_target
    target_index <= size(matrix, 1) ||
        _throw_canopy_air_trial_longwave_forcing(
            :canopy_thermal_snapshot,
            target_index,
            :target,
        )
    size(matrix, 2) == point_count ||
        _throw_canopy_air_trial_longwave_forcing(
            :canopy_thermal_snapshot,
            size(matrix, 2),
            :points,
        )
    return copy(view(matrix, target_index, :))
end

"""
    canopy_air_trial_longwave_forcing(T, target_index, point_count,
                                      thermal_snapshot,
                                      soil_surface_temperature_k,
                                      incident_thermal_w_m2,
                                      soil_reflectance; kwargs...)

Prepare the longwave inputs of one physical target Crown from the exact
`ITERTCAN` trial state. The canopy temperature is legacy `TCAN2`; the leaf
temperatures are the target's owned row of `TLEAFTABLE`; and the soil-surface
temperature belongs to the same transient canopy atmosphere. The returned
leaf vector is always a fresh copy.
"""
function canopy_air_trial_longwave_forcing(
    ::Type{T},
    target_index::Integer,
    point_count::Integer,
    thermal_snapshot,
    soil_surface_temperature_k,
    incident_thermal_w_m2,
    soil_reflectance;
    thermal_waveband_index::Integer=3,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the trial-longwave numeric type must be concrete"),
    )
    target = _canopy_air_trial_longwave_target_index(target_index)
    points = _mono_pass_longwave_point_count(point_count)
    waveband = _mono_pass_longwave_band(thermal_waveband_index)
    soil_reflectance isa AbstractVector || throw(
        ArgumentError("soil_reflectance must be a vector"),
    )
    Base.require_one_based_indexing(soil_reflectance)
    length(soil_reflectance) >= waveband || throw(
        DimensionMismatch(
            "soil_reflectance must contain thermal waveband $waveband",
        ),
    )

    leaf_temperature = _canopy_air_trial_longwave_snapshot_row(
        thermal_snapshot,
        T,
        target,
        points,
    )
    canopy_temperature = thermal_snapshot.canopy_temperature_c
    soil_temperature = _mono_pass_longwave_nonnegative(
        _mono_pass_longwave_float(
            T,
            soil_surface_temperature_k,
            :soil_surface_temperature_k,
        ),
        :soil_surface_temperature_k,
    )
    soil_temperature > zero(T) || throw(
        DomainError(
            soil_temperature,
            "soil_surface_temperature_k must be positive",
        ),
    )
    incident = _mono_pass_longwave_nonnegative(
        _mono_pass_longwave_float(
            T,
            incident_thermal_w_m2,
            :incident_thermal_w_m2,
        ),
        :incident_thermal_w_m2,
    )
    reflectance = _mono_pass_longwave_fraction(
        _mono_pass_longwave_float(
            T,
            soil_reflectance[waveband],
            :soil_reflectance_thermal,
        ),
        :soil_reflectance_thermal,
    )
    return MonoPassLongwaveForcingResult(
        incident,
        canopy_temperature,
        leaf_temperature,
        soil_temperature,
        reflectance,
    )
end

"""PlantSimEngine adapter for one target Crown inside an `ITERTCAN` trial."""
struct MAESPACanopyAirTrialLongwaveForcing{T<:AbstractFloat} <:
       AbstractCanopy_Air_Trial_Longwave_ForcingModel
    target_index::Int
    point_count::Int
    thermal_waveband_index::Int
    zero_value::T
end

function MAESPACanopyAirTrialLongwaveForcing(
    ::Type{T}=Float64,
    target_index::Integer=1,
    point_count::Integer=1;
    thermal_waveband_index::Integer=3,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the trial-longwave numeric type must be concrete"),
    )
    return MAESPACanopyAirTrialLongwaveForcing{T}(
        _canopy_air_trial_longwave_target_index(target_index),
        _mono_pass_longwave_point_count(point_count),
        _mono_pass_longwave_band(thermal_waveband_index),
        zero(T),
    )
end

PlantSimEngine.inputs_(::MAESPACanopyAirTrialLongwaveForcing) = (
    source_equivalent_canopy_available=PlantSimEngine.Required(Bool),
    source_incident_thermal_w_m2=PlantSimEngine.Required(Real),
    source_soil_reflectance=PlantSimEngine.Required(AbstractVector),
    canopy_air_trial_longwave_forcing_inputs_available=
        PlantSimEngine.Default(true),
)

PlantSimEngine.variable_contracts_(::MAESPACanopyAirTrialLongwaveForcing) = (
    source_equivalent_canopy_available=EQUIVALENT_CANOPY_AVAILABLE_CONTRACT,
    canopy_air_trial_longwave_forcing_available=LONGWAVE_FORCING_AVAILABLE_CONTRACT,
)

function PlantSimEngine.environment_inputs_(
    model::MAESPACanopyAirTrialLongwaveForcing{T},
) where {T}
    return (
        soil_surface_temperature_k=zero(T),
        canopy_atmosphere_available=false,
        soil_surface_temperature_available=false,
        canopy_thermal_snapshot=_unavailable_canopy_thermal_snapshot(T),
    )
end

function PlantSimEngine.outputs_(
    model::MAESPACanopyAirTrialLongwaveForcing{T},
) where {T}
    return (
        incident_thermal_w_m2=zero(T),
        canopy_temperature_c=zero(T),
        leaf_temperature_c=zeros(T, model.point_count),
        soil_surface_temperature_k=zero(T),
        soil_reflectance_thermal=zero(T),
        canopy_air_trial_longwave_forcing_available=false,
    )
end

function _canopy_air_trial_longwave_output_type(model, status)
    T = typeof(status.canopy_temperature_c)
    T <: AbstractFloat && isconcretetype(T) ||
        _throw_canopy_air_trial_longwave_forcing(
            :canopy_temperature_c,
            T,
            :output_type,
        )
    for name in (
        :incident_thermal_w_m2,
        :soil_surface_temperature_k,
        :soil_reflectance_thermal,
    )
        typeof(getproperty(status, name)) === T ||
            _throw_canopy_air_trial_longwave_forcing(
                name,
                typeof(getproperty(status, name)),
                :output_type,
            )
    end
    leaf_temperature = status.leaf_temperature_c
    leaf_temperature isa AbstractVector ||
        _throw_canopy_air_trial_longwave_forcing(
            :leaf_temperature_c,
            leaf_temperature,
            :output_type,
        )
    Base.require_one_based_indexing(leaf_temperature)
    eltype(leaf_temperature) === T ||
        _throw_canopy_air_trial_longwave_forcing(
            :leaf_temperature_c,
            eltype(leaf_temperature),
            :output_type,
        )
    length(leaf_temperature) == model.point_count ||
        _throw_canopy_air_trial_longwave_forcing(
            :leaf_temperature_c,
            length(leaf_temperature),
            :points,
        )
    status.canopy_air_trial_longwave_forcing_available isa Bool ||
        _throw_canopy_air_trial_longwave_forcing(
            :canopy_air_trial_longwave_forcing_available,
            status.canopy_air_trial_longwave_forcing_available,
            :availability,
        )
    return T
end

function _reset_canopy_air_trial_longwave_forcing!(model, status, ::Type{T}) where {T}
    status.incident_thermal_w_m2 = zero(T)
    status.canopy_temperature_c = zero(T)
    status.leaf_temperature_c = zeros(T, model.point_count)
    status.soil_surface_temperature_k = zero(T)
    status.soil_reflectance_thermal = zero(T)
    status.canopy_air_trial_longwave_forcing_available = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPACanopyAirTrialLongwaveForcing,
    status,
    environment,
    constants,
    context,
)
    T = _canopy_air_trial_longwave_output_type(model, status)
    _reset_canopy_air_trial_longwave_forcing!(model, status, T)

    gates = (
        source_equivalent_canopy_available=
            status.source_equivalent_canopy_available,
        canopy_air_trial_longwave_forcing_inputs_available=
            status.canopy_air_trial_longwave_forcing_inputs_available,
        canopy_atmosphere_available=environment.canopy_atmosphere_available,
        soil_surface_temperature_available=
            environment.soil_surface_temperature_available,
    )
    for (name, value) in pairs(gates)
        value isa Bool || _throw_canopy_air_trial_longwave_forcing(
            name,
            value,
            :availability,
        )
    end
    all(values(gates)) || return nothing

    result = canopy_air_trial_longwave_forcing(
        T,
        model.target_index,
        model.point_count,
        environment.canopy_thermal_snapshot,
        environment.soil_surface_temperature_k,
        status.source_incident_thermal_w_m2,
        status.source_soil_reflectance;
        thermal_waveband_index=model.thermal_waveband_index,
    )
    status.incident_thermal_w_m2 = result.incident_thermal_w_m2
    status.canopy_temperature_c = result.canopy_temperature_c
    status.leaf_temperature_c = result.leaf_temperature_c
    status.soil_surface_temperature_k = result.soil_surface_temperature_k
    status.soil_reflectance_thermal = result.soil_reflectance_thermal
    status.canopy_air_trial_longwave_forcing_available = true
    return nothing
end
