PlantSimEngine.@process "logical_leaf_unit_layout" verbose = false

"""
Fixed-size Crown snapshot used to bridge MAESPA's point-, radiation-class-,
layer-, and physiological-age-shaped buffers to one logical-leaf-unit axis.

The unit order is the historical loop order `point -> radiation class ->
physiological age`, with age varying fastest. Inactive radiation slots remain
in every vector but have a zero area fraction and a false activity flag.
"""
struct LogicalLeafUnitLayoutResult{T<:AbstractFloat}
    logical_leaf_area_fraction::Vector{T}
    logical_leaf_area_density::Vector{T}
    logical_leaf_representative_volume_m3::Vector{T}
    logical_leaf_physiological_layer::Vector{Int}
    logical_leaf_point_index::Vector{Int}
    logical_leaf_radiation_class_index::Vector{Int}
    logical_leaf_physiological_age_index::Vector{Int}
    logical_leaf_unit_active::Vector{Bool}
    logical_leaf_area_m2::Vector{T}
    logical_leaf_absorbed_par_umol_m2_s::Vector{T}
    logical_leaf_net_radiation_w_m2::Vector{T}
    logical_leaf_relative_diffuse_penetration::Vector{T}
    logical_leaf_diffuse_transmittance_up::Vector{T}
    logical_leaf_diffuse_transmittance_down::Vector{T}
    logical_leaf_relative_wind_speed::Vector{T}
    logical_leaf_jmax25_umol_m2_s::Vector{T}
    logical_leaf_vcmax25_umol_m2_s::Vector{T}
    logical_leaf_rd0_umol_m2_s::Vector{T}
    logical_leaf_quantum_yield::Vector{T}
    logical_leaf_unit_forcing_available::Vector{Bool}
    effective_leaf_radiation_class_count::Int
    active_logical_leaf_unit_count::Int
    logical_leaf_area_total_m2::T
    logical_leaf_unit_layout_available::Bool
    logical_leaf_forcing_available::Bool
end

@inline function _logical_leaf_layout_positive_count(
    value::Integer,
    name::Symbol,
)
    value isa Bool && throw(
        ArgumentError("$(String(name)) must be an integer, not Bool"),
    )
    value > 0 || throw(ArgumentError("$(String(name)) must be positive"))
    return Int(value)
end

@inline function _logical_leaf_layout_unit_count(
    point_count::Int,
    slot_count::Int,
    physiological_age_count::Int,
)
    point_slots = Base.checked_mul(point_count, slot_count)
    return Base.checked_mul(point_slots, physiological_age_count)
end

@inline function _logical_leaf_layout_unit_index(
    point_index::Int,
    class_index::Int,
    age_index::Int,
    slot_count::Int,
    age_count::Int,
)
    return ((point_index - 1) * slot_count + class_index - 1) * age_count +
           age_index
end

@inline function _logical_leaf_layout_require_shape(
    values,
    expected::Tuple,
    name::Symbol,
)
    size(values) == expected || throw(
        DimensionMismatch("$(String(name)) must have size $expected"),
    )
    return nothing
end

@inline function _logical_leaf_layout_require_length(
    values,
    expected::Int,
    name::Symbol,
)
    length(values) == expected || throw(
        DimensionMismatch(
            "$(String(name)) must contain $expected values",
        ),
    )
    return nothing
end

@noinline function _throw_logical_leaf_layout_eltype(
    name::Symbol,
    expected,
    actual,
)
    throw(
        ArgumentError(
            "$(String(name)) must have element type $expected, got $actual",
        ),
    )
end

@inline function _logical_leaf_layout_require_eltype(
    values,
    ::Type{T},
    name::Symbol,
) where {T<:AbstractFloat}
    eltype(values) === T ||
        _throw_logical_leaf_layout_eltype(name, T, eltype(values))
    return nothing
end

@inline function _logical_leaf_layout_float(
    value::T,
    name::Symbol;
    nonnegative::Bool=false,
) where {T<:AbstractFloat}
    isfinite(value) || throw(
        ArgumentError("$(String(name)) values must be finite"),
    )
    if nonnegative && value < zero(T)
        throw(
            DomainError(
                value,
                "$(String(name)) values must be non-negative",
            ),
        )
    end
    return value
end

function _logical_leaf_layout_source_eltypes(
    ::Type{T},
    source_leaf_radiation_area_fraction,
    source_leaf_area_density_by_age,
    source_representative_volumes,
    source_leaf_radiation_absorbed_par_umol_m2_s,
    source_leaf_radiation_net_w_m2_leaf,
    source_relative_diffuse_penetration,
    source_diffuse_transmittance_up,
    source_diffuse_transmittance_down,
    source_relative_wind_speed_by_layer,
    source_jmax25_umol_m2_s,
    source_vcmax25_umol_m2_s,
    source_rd0_umol_m2_s,
    source_quantum_yield,
) where {T<:AbstractFloat}
    for (values, name) in (
        (
            source_leaf_radiation_area_fraction,
            :source_leaf_radiation_area_fraction,
        ),
        (
            source_leaf_area_density_by_age,
            :source_leaf_area_density_by_age,
        ),
        (source_representative_volumes, :source_representative_volumes),
        (
            source_leaf_radiation_absorbed_par_umol_m2_s,
            :source_leaf_radiation_absorbed_par_umol_m2_s,
        ),
        (
            source_leaf_radiation_net_w_m2_leaf,
            :source_leaf_radiation_net_w_m2_leaf,
        ),
        (
            source_relative_diffuse_penetration,
            :source_relative_diffuse_penetration,
        ),
        (
            source_diffuse_transmittance_up,
            :source_diffuse_transmittance_up,
        ),
        (
            source_diffuse_transmittance_down,
            :source_diffuse_transmittance_down,
        ),
        (
            source_relative_wind_speed_by_layer,
            :source_relative_wind_speed_by_layer,
        ),
        (source_jmax25_umol_m2_s, :source_jmax25_umol_m2_s),
        (source_vcmax25_umol_m2_s, :source_vcmax25_umol_m2_s),
        (source_rd0_umol_m2_s, :source_rd0_umol_m2_s),
        (source_quantum_yield, :source_quantum_yield),
    )
        _logical_leaf_layout_require_eltype(values, T, name)
    end
    return nothing
end

function _validate_logical_leaf_layout_geometry(
    ::Type{T},
    point_count::Int,
    slot_count::Int,
    age_count::Int,
    layer_count::Int,
    source_leaf_radiation_area_fraction::AbstractMatrix{T},
    source_leaf_area_density_by_age::AbstractMatrix{T},
    source_representative_volumes::AbstractVector{T},
    source_physiological_layers::AbstractVector,
    active_leaf_radiation_class_count::Integer,
    astronomical_daylight::Bool,
) where {T<:AbstractFloat}
    Base.require_one_based_indexing(
        source_leaf_radiation_area_fraction,
        source_leaf_area_density_by_age,
        source_representative_volumes,
        source_physiological_layers,
    )
    _logical_leaf_layout_require_shape(
        source_leaf_radiation_area_fraction,
        (point_count, slot_count),
        :source_leaf_radiation_area_fraction,
    )
    _logical_leaf_layout_require_shape(
        source_leaf_area_density_by_age,
        (age_count, point_count),
        :source_leaf_area_density_by_age,
    )
    _logical_leaf_layout_require_length(
        source_representative_volumes,
        point_count,
        :source_representative_volumes,
    )
    _logical_leaf_layout_require_length(
        source_physiological_layers,
        point_count,
        :source_physiological_layers,
    )

    active_leaf_radiation_class_count isa Bool && throw(
        ArgumentError(
            "active_leaf_radiation_class_count must be an integer, not Bool",
        ),
    )
    active_count = astronomical_daylight ?
                   Int(active_leaf_radiation_class_count) : 1
    if astronomical_daylight
        1 <= active_count <= slot_count || throw(
            DomainError(
                active_count,
                "active_leaf_radiation_class_count must lie within the fixed slots",
            ),
        )
    end

    fraction_tolerance = max(T(1.0e-4), T(20) * eps(T))
    total_area = zero(T)
    for point_index in 1:point_count
        volume = _logical_leaf_layout_float(
            source_representative_volumes[point_index],
            :source_representative_volumes;
            nonnegative=true,
        )
        source_layer = source_physiological_layers[point_index]
        source_layer isa Integer || throw(
            ArgumentError(
                "source_physiological_layers values must be integers",
            ),
        )
        source_layer isa Bool && throw(
            ArgumentError(
                "source_physiological_layers values must be integers, not Bool",
            ),
        )
        layer = Int(source_layer)
        1 <= layer <= layer_count || throw(
            DomainError(
                layer,
                "source_physiological_layers values must name a configured layer",
            ),
        )

        fraction_sum = zero(T)
        if astronomical_daylight
            for class_index in 1:active_count
                fraction = _logical_leaf_layout_float(
                    source_leaf_radiation_area_fraction[
                        point_index,
                        class_index,
                    ],
                    :source_leaf_radiation_area_fraction;
                    nonnegative=true,
                )
                fraction <= one(T) || throw(
                    DomainError(
                        fraction,
                        "active leaf-radiation fractions must lie in [0, 1]",
                    ),
                )
                fraction_sum += fraction
            end
            isapprox(
                fraction_sum,
                one(T);
                atol=fraction_tolerance,
                rtol=fraction_tolerance,
            ) || throw(
                ArgumentError(
                    "active leaf-radiation fractions must sum to one at every point",
                ),
            )
        end

        for age_index in 1:age_count
            density = _logical_leaf_layout_float(
                source_leaf_area_density_by_age[age_index, point_index],
                :source_leaf_area_density_by_age;
                nonnegative=true,
            )
            age_area = density * volume
            isfinite(age_area) || throw(
                DomainError(
                    age_area,
                    "logical leaf area must remain finite",
                ),
            )
            total_area += age_area
            isfinite(total_area) || throw(
                DomainError(
                    total_area,
                    "total logical leaf area must remain finite",
                ),
            )
            if astronomical_daylight
                for class_index in 1:active_count
                    fraction = source_leaf_radiation_area_fraction[
                        point_index,
                        class_index,
                    ]
                    isfinite(fraction * age_area) || throw(
                        DomainError(
                            fraction * age_area,
                            "logical leaf-unit area must remain finite",
                        ),
                    )
                end
            end
        end
    end
    return (; active_count, total_area)
end

function _validate_logical_leaf_layout_forcing(
    ::Type{T},
    point_count::Int,
    slot_count::Int,
    age_count::Int,
    layer_count::Int,
    active_count::Int,
    source_leaf_radiation_absorbed_par_umol_m2_s::AbstractMatrix{T},
    source_leaf_radiation_net_w_m2_leaf::AbstractMatrix{T},
    source_relative_diffuse_penetration::AbstractVector{T},
    source_diffuse_transmittance_up::AbstractVector{T},
    source_diffuse_transmittance_down::AbstractVector{T},
    source_relative_wind_speed_by_layer::AbstractVector{T},
    source_jmax25_umol_m2_s::AbstractMatrix{T},
    source_vcmax25_umol_m2_s::AbstractMatrix{T},
    source_rd0_umol_m2_s::AbstractMatrix{T},
    source_quantum_yield::AbstractMatrix{T},
) where {T<:AbstractFloat}
    Base.require_one_based_indexing(
        source_leaf_radiation_absorbed_par_umol_m2_s,
        source_leaf_radiation_net_w_m2_leaf,
        source_relative_diffuse_penetration,
        source_diffuse_transmittance_up,
        source_diffuse_transmittance_down,
        source_relative_wind_speed_by_layer,
        source_jmax25_umol_m2_s,
        source_vcmax25_umol_m2_s,
        source_rd0_umol_m2_s,
        source_quantum_yield,
    )
    for (values, name) in (
        (
            source_leaf_radiation_absorbed_par_umol_m2_s,
            :source_leaf_radiation_absorbed_par_umol_m2_s,
        ),
        (
            source_leaf_radiation_net_w_m2_leaf,
            :source_leaf_radiation_net_w_m2_leaf,
        ),
    )
        _logical_leaf_layout_require_shape(
            values,
            (point_count, slot_count),
            name,
        )
    end
    for (values, name) in (
        (
            source_relative_diffuse_penetration,
            :source_relative_diffuse_penetration,
        ),
        (
            source_diffuse_transmittance_up,
            :source_diffuse_transmittance_up,
        ),
        (
            source_diffuse_transmittance_down,
            :source_diffuse_transmittance_down,
        ),
    )
        _logical_leaf_layout_require_length(values, point_count, name)
    end
    _logical_leaf_layout_require_length(
        source_relative_wind_speed_by_layer,
        layer_count,
        :source_relative_wind_speed_by_layer,
    )
    for (values, name) in (
        (source_jmax25_umol_m2_s, :source_jmax25_umol_m2_s),
        (source_vcmax25_umol_m2_s, :source_vcmax25_umol_m2_s),
        (source_rd0_umol_m2_s, :source_rd0_umol_m2_s),
        (source_quantum_yield, :source_quantum_yield),
    )
        _logical_leaf_layout_require_shape(
            values,
            (layer_count, age_count),
            name,
        )
    end

    for point_index in 1:point_count
        _logical_leaf_layout_float(
            source_relative_diffuse_penetration[point_index],
            :source_relative_diffuse_penetration;
            nonnegative=true,
        )
        _logical_leaf_layout_float(
            source_diffuse_transmittance_up[point_index],
            :source_diffuse_transmittance_up;
            nonnegative=true,
        )
        _logical_leaf_layout_float(
            source_diffuse_transmittance_down[point_index],
            :source_diffuse_transmittance_down;
            nonnegative=true,
        )
        for class_index in 1:active_count
            _logical_leaf_layout_float(
                source_leaf_radiation_absorbed_par_umol_m2_s[
                    point_index,
                    class_index,
                ],
                :source_leaf_radiation_absorbed_par_umol_m2_s;
                nonnegative=true,
            )
            _logical_leaf_layout_float(
                source_leaf_radiation_net_w_m2_leaf[
                    point_index,
                    class_index,
                ],
                :source_leaf_radiation_net_w_m2_leaf,
            )
        end
    end
    for layer_index in 1:layer_count
        _logical_leaf_layout_float(
            source_relative_wind_speed_by_layer[layer_index],
            :source_relative_wind_speed_by_layer;
            nonnegative=true,
        )
        for age_index in 1:age_count
            for (values, name) in (
                (source_jmax25_umol_m2_s, :source_jmax25_umol_m2_s),
                (source_vcmax25_umol_m2_s, :source_vcmax25_umol_m2_s),
                (source_rd0_umol_m2_s, :source_rd0_umol_m2_s),
                (source_quantum_yield, :source_quantum_yield),
            )
                _logical_leaf_layout_float(
                    values[layer_index, age_index],
                    name;
                    nonnegative=true,
                )
            end
        end
    end
    return nothing
end

function _fresh_logical_leaf_unit_layout_result(
    ::Type{T},
    unit_count::Int,
) where {T<:AbstractFloat}
    return LogicalLeafUnitLayoutResult{T}(
        zeros(T, unit_count),
        zeros(T, unit_count),
        zeros(T, unit_count),
        zeros(Int, unit_count),
        zeros(Int, unit_count),
        zeros(Int, unit_count),
        zeros(Int, unit_count),
        fill(false, unit_count),
        zeros(T, unit_count),
        zeros(T, unit_count),
        zeros(T, unit_count),
        zeros(T, unit_count),
        zeros(T, unit_count),
        zeros(T, unit_count),
        zeros(T, unit_count),
        zeros(T, unit_count),
        zeros(T, unit_count),
        zeros(T, unit_count),
        zeros(T, unit_count),
        fill(false, unit_count),
        0,
        0,
        zero(T),
        false,
        false,
    )
end

"""
    logical_leaf_unit_layout(...)

Build a fresh fixed-size logical-leaf snapshot. Source matrices retain their
native MAESPA orientations: radiation is `point x fixed class slot`, leaf
density is `physiological age x point`, and capacity parameters are
`physiological layer x physiological age`.

During daylight, only the first `active_leaf_radiation_class_count` slots are
active and their fractions must sum to one at each point. At night, class one
is the sole active class with fraction one, independently of the unavailable
shortwave partition. Inactive slots remain present with zero fraction and zero
forcing. The optional forcing snapshots are copied only when all three source
availability flags are true.
"""
function logical_leaf_unit_layout(
    source_leaf_radiation_area_fraction::AbstractMatrix{T},
    source_leaf_area_density_by_age::AbstractMatrix{T},
    source_representative_volumes::AbstractVector{T},
    source_physiological_layers::AbstractVector,
    active_leaf_radiation_class_count::Integer,
    astronomical_daylight::Bool,
    source_leaf_radiation_absorbed_par_umol_m2_s::AbstractMatrix{T},
    source_leaf_radiation_net_w_m2_leaf::AbstractMatrix{T},
    source_relative_diffuse_penetration::AbstractVector{T},
    source_diffuse_transmittance_up::AbstractVector{T},
    source_diffuse_transmittance_down::AbstractVector{T},
    source_relative_wind_speed_by_layer::AbstractVector{T},
    source_jmax25_umol_m2_s::AbstractMatrix{T},
    source_vcmax25_umol_m2_s::AbstractMatrix{T},
    source_rd0_umol_m2_s::AbstractMatrix{T},
    source_quantum_yield::AbstractMatrix{T};
    leaf_radiative_forcing_available::Bool=true,
    diffuse_transmission_available::Bool=true,
    canopy_wind_profile_available::Bool=true,
) where {T<:AbstractFloat}
    point_count, slot_count = size(source_leaf_radiation_area_fraction)
    age_count, density_point_count = size(source_leaf_area_density_by_age)
    point_count == density_point_count || throw(
        DimensionMismatch(
            "radiation fractions and age-specific leaf density must share the point dimension",
        ),
    )
    layer_count = size(source_jmax25_umol_m2_s, 1)
    point_count > 0 || throw(ArgumentError("point_count must be positive"))
    slot_count > 0 || throw(ArgumentError("slot_count must be positive"))
    age_count > 0 || throw(
        ArgumentError("physiological_age_count must be positive"),
    )
    layer_count > 0 || throw(
        ArgumentError("physiological_layer_count must be positive"),
    )
    unit_count = _logical_leaf_layout_unit_count(
        point_count,
        slot_count,
        age_count,
    )
    result = _fresh_logical_leaf_unit_layout_result(T, unit_count)
    geometry = _validate_logical_leaf_layout_geometry(
        T,
        point_count,
        slot_count,
        age_count,
        layer_count,
        source_leaf_radiation_area_fraction,
        source_leaf_area_density_by_age,
        source_representative_volumes,
        source_physiological_layers,
        active_leaf_radiation_class_count,
        astronomical_daylight,
    )
    forcing_available = leaf_radiative_forcing_available &&
                        diffuse_transmission_available &&
                        canopy_wind_profile_available
    if forcing_available
        _validate_logical_leaf_layout_forcing(
            T,
            point_count,
            slot_count,
            age_count,
            layer_count,
            geometry.active_count,
            source_leaf_radiation_absorbed_par_umol_m2_s,
            source_leaf_radiation_net_w_m2_leaf,
            source_relative_diffuse_penetration,
            source_diffuse_transmittance_up,
            source_diffuse_transmittance_down,
            source_relative_wind_speed_by_layer,
            source_jmax25_umol_m2_s,
            source_vcmax25_umol_m2_s,
            source_rd0_umol_m2_s,
            source_quantum_yield,
        )
    end

    for point_index in 1:point_count
        volume = source_representative_volumes[point_index]
        layer = Int(source_physiological_layers[point_index])
        for class_index in 1:slot_count
            unit_active = class_index <= geometry.active_count
            fraction = if !unit_active
                zero(T)
            elseif astronomical_daylight
                source_leaf_radiation_area_fraction[point_index, class_index]
            else
                one(T)
            end
            for age_index in 1:age_count
                unit_index = _logical_leaf_layout_unit_index(
                    point_index,
                    class_index,
                    age_index,
                    slot_count,
                    age_count,
                )
                density = source_leaf_area_density_by_age[
                    age_index,
                    point_index,
                ]
                result.logical_leaf_area_fraction[unit_index] = fraction
                result.logical_leaf_area_density[unit_index] = density
                result.logical_leaf_representative_volume_m3[unit_index] =
                    volume
                result.logical_leaf_physiological_layer[unit_index] = layer
                result.logical_leaf_point_index[unit_index] = point_index
                result.logical_leaf_radiation_class_index[unit_index] =
                    class_index
                result.logical_leaf_physiological_age_index[unit_index] =
                    age_index
                result.logical_leaf_unit_active[unit_index] = unit_active
                result.logical_leaf_area_m2[unit_index] =
                    fraction * density * volume
                if forcing_available && unit_active
                    result.logical_leaf_absorbed_par_umol_m2_s[unit_index] =
                        source_leaf_radiation_absorbed_par_umol_m2_s[
                            point_index,
                            class_index,
                        ]
                    result.logical_leaf_net_radiation_w_m2[unit_index] =
                        source_leaf_radiation_net_w_m2_leaf[
                            point_index,
                            class_index,
                        ]
                    result.logical_leaf_relative_diffuse_penetration[unit_index] =
                        source_relative_diffuse_penetration[point_index]
                    result.logical_leaf_diffuse_transmittance_up[unit_index] =
                        source_diffuse_transmittance_up[point_index]
                    result.logical_leaf_diffuse_transmittance_down[unit_index] =
                        source_diffuse_transmittance_down[point_index]
                    result.logical_leaf_relative_wind_speed[unit_index] =
                        source_relative_wind_speed_by_layer[layer]
                    result.logical_leaf_jmax25_umol_m2_s[unit_index] =
                        source_jmax25_umol_m2_s[layer, age_index]
                    result.logical_leaf_vcmax25_umol_m2_s[unit_index] =
                        source_vcmax25_umol_m2_s[layer, age_index]
                    result.logical_leaf_rd0_umol_m2_s[unit_index] =
                        source_rd0_umol_m2_s[layer, age_index]
                    result.logical_leaf_quantum_yield[unit_index] =
                        source_quantum_yield[layer, age_index]
                    result.logical_leaf_unit_forcing_available[unit_index] =
                        true
                end
            end
        end
    end
    return LogicalLeafUnitLayoutResult{T}(
        result.logical_leaf_area_fraction,
        result.logical_leaf_area_density,
        result.logical_leaf_representative_volume_m3,
        result.logical_leaf_physiological_layer,
        result.logical_leaf_point_index,
        result.logical_leaf_radiation_class_index,
        result.logical_leaf_physiological_age_index,
        result.logical_leaf_unit_active,
        result.logical_leaf_area_m2,
        result.logical_leaf_absorbed_par_umol_m2_s,
        result.logical_leaf_net_radiation_w_m2,
        result.logical_leaf_relative_diffuse_penetration,
        result.logical_leaf_diffuse_transmittance_up,
        result.logical_leaf_diffuse_transmittance_down,
        result.logical_leaf_relative_wind_speed,
        result.logical_leaf_jmax25_umol_m2_s,
        result.logical_leaf_vcmax25_umol_m2_s,
        result.logical_leaf_rd0_umol_m2_s,
        result.logical_leaf_quantum_yield,
        result.logical_leaf_unit_forcing_available,
        geometry.active_count,
        point_count * geometry.active_count * age_count,
        geometry.total_area,
        true,
        forcing_available,
    )
end

"""PlantSimEngine wrapper for the fixed Crown logical-leaf-unit layout."""
struct MAESPALogicalLeafUnitLayout{T<:AbstractFloat} <:
       AbstractLogical_Leaf_Unit_LayoutModel
    point_count::Int
    slot_count::Int
    physiological_age_count::Int
    physiological_layer_count::Int
end

function MAESPALogicalLeafUnitLayout(
    ::Type{T},
    point_count::Integer,
    slot_count::Integer,
    physiological_age_count::Integer,
    physiological_layer_count::Integer,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the logical-leaf-unit numeric type must be concrete"),
    )
    points = _logical_leaf_layout_positive_count(point_count, :point_count)
    slots = _logical_leaf_layout_positive_count(slot_count, :slot_count)
    ages = _logical_leaf_layout_positive_count(
        physiological_age_count,
        :physiological_age_count,
    )
    layers = _logical_leaf_layout_positive_count(
        physiological_layer_count,
        :physiological_layer_count,
    )
    _logical_leaf_layout_unit_count(points, slots, ages)
    return MAESPALogicalLeafUnitLayout{T}(points, slots, ages, layers)
end

PlantSimEngine.inputs_(::MAESPALogicalLeafUnitLayout) = (
    source_leaf_radiation_area_fraction=PlantSimEngine.Required(AbstractMatrix),
    source_leaf_area_density_by_age=PlantSimEngine.Required(AbstractMatrix),
    source_representative_volumes=PlantSimEngine.Required(AbstractVector),
    source_physiological_layers=PlantSimEngine.Required(AbstractVector),
    active_leaf_radiation_class_count=PlantSimEngine.Required(Integer),
    astronomical_daylight=PlantSimEngine.Required(Bool),
    leaf_radiation_partitioning_available=PlantSimEngine.Required(Bool),
    source_leaf_radiation_absorbed_par_umol_m2_s=
        PlantSimEngine.Required(AbstractMatrix),
    source_leaf_radiation_net_w_m2_leaf=
        PlantSimEngine.Required(AbstractMatrix),
    leaf_radiative_forcing_available=PlantSimEngine.Required(Bool),
    source_relative_diffuse_penetration=PlantSimEngine.Required(AbstractVector),
    source_diffuse_transmittance_up=PlantSimEngine.Required(AbstractVector),
    source_diffuse_transmittance_down=PlantSimEngine.Required(AbstractVector),
    diffuse_transmission_available=PlantSimEngine.Required(Bool),
    source_relative_wind_speed_by_layer=
        PlantSimEngine.Required(AbstractVector),
    canopy_wind_profile_available=PlantSimEngine.Required(Bool),
    source_jmax25_umol_m2_s=PlantSimEngine.Required(AbstractMatrix),
    source_vcmax25_umol_m2_s=PlantSimEngine.Required(AbstractMatrix),
    source_rd0_umol_m2_s=PlantSimEngine.Required(AbstractMatrix),
    source_quantum_yield=PlantSimEngine.Required(AbstractMatrix),
    logical_leaf_unit_layout_inputs_available=PlantSimEngine.Default(true),
)

PlantSimEngine.variable_contracts_(::MAESPALogicalLeafUnitLayout) = merge(
    (
        source_leaf_radiation_area_fraction=LEAF_RADIATION_AREA_FRACTION_CONTRACT,
        active_leaf_radiation_class_count=LEAF_RADIATION_CLASS_COUNT_CONTRACT,
        leaf_radiation_partitioning_available=LEAF_RADIATION_PARTITION_AVAILABLE_CONTRACT,
        source_relative_diffuse_penetration=LEAF_RELATIVE_DIFFUSE_PENETRATION_CONTRACT,
        source_diffuse_transmittance_up=LEAF_DIFFUSE_TRANSMITTANCE_CONTRACT,
        source_diffuse_transmittance_down=LEAF_DIFFUSE_TRANSMITTANCE_CONTRACT,
        diffuse_transmission_available=DIFFUSE_TRANSMISSION_AVAILABLE_CONTRACT,
    ),
    LOGICAL_LEAF_DIFFUSE_RADIATION_CONTRACTS,
)

function PlantSimEngine.outputs_(model::MAESPALogicalLeafUnitLayout{T}) where {T}
    unit_count = _logical_leaf_layout_unit_count(
        model.point_count,
        model.slot_count,
        model.physiological_age_count,
    )
    result = _fresh_logical_leaf_unit_layout_result(T, unit_count)
    return (
        logical_leaf_area_fraction=result.logical_leaf_area_fraction,
        logical_leaf_area_density=result.logical_leaf_area_density,
        logical_leaf_representative_volume_m3=
            result.logical_leaf_representative_volume_m3,
        logical_leaf_physiological_layer=
            result.logical_leaf_physiological_layer,
        logical_leaf_point_index=result.logical_leaf_point_index,
        logical_leaf_radiation_class_index=
            result.logical_leaf_radiation_class_index,
        logical_leaf_physiological_age_index=
            result.logical_leaf_physiological_age_index,
        logical_leaf_unit_active=result.logical_leaf_unit_active,
        logical_leaf_area_m2=result.logical_leaf_area_m2,
        logical_leaf_absorbed_par_umol_m2_s=
            result.logical_leaf_absorbed_par_umol_m2_s,
        logical_leaf_net_radiation_w_m2=
            result.logical_leaf_net_radiation_w_m2,
        logical_leaf_relative_diffuse_penetration=
            result.logical_leaf_relative_diffuse_penetration,
        logical_leaf_diffuse_transmittance_up=
            result.logical_leaf_diffuse_transmittance_up,
        logical_leaf_diffuse_transmittance_down=
            result.logical_leaf_diffuse_transmittance_down,
        logical_leaf_relative_wind_speed=
            result.logical_leaf_relative_wind_speed,
        logical_leaf_jmax25_umol_m2_s=
            result.logical_leaf_jmax25_umol_m2_s,
        logical_leaf_vcmax25_umol_m2_s=
            result.logical_leaf_vcmax25_umol_m2_s,
        logical_leaf_rd0_umol_m2_s=result.logical_leaf_rd0_umol_m2_s,
        logical_leaf_quantum_yield=result.logical_leaf_quantum_yield,
        logical_leaf_unit_forcing_available=
            result.logical_leaf_unit_forcing_available,
        effective_leaf_radiation_class_count=0,
        active_logical_leaf_unit_count=0,
        logical_leaf_area_total_m2=zero(T),
        logical_leaf_unit_layout_available=false,
        logical_leaf_forcing_available=false,
    )
end

const _LOGICAL_LEAF_LAYOUT_FLOAT_VECTOR_OUTPUTS = (
    :logical_leaf_area_fraction,
    :logical_leaf_area_density,
    :logical_leaf_representative_volume_m3,
    :logical_leaf_area_m2,
    :logical_leaf_absorbed_par_umol_m2_s,
    :logical_leaf_net_radiation_w_m2,
    :logical_leaf_relative_diffuse_penetration,
    :logical_leaf_diffuse_transmittance_up,
    :logical_leaf_diffuse_transmittance_down,
    :logical_leaf_relative_wind_speed,
    :logical_leaf_jmax25_umol_m2_s,
    :logical_leaf_vcmax25_umol_m2_s,
    :logical_leaf_rd0_umol_m2_s,
    :logical_leaf_quantum_yield,
)

const _LOGICAL_LEAF_LAYOUT_INTEGER_VECTOR_OUTPUTS = (
    :logical_leaf_physiological_layer,
    :logical_leaf_point_index,
    :logical_leaf_radiation_class_index,
    :logical_leaf_physiological_age_index,
)

const _LOGICAL_LEAF_LAYOUT_BOOL_VECTOR_OUTPUTS = (
    :logical_leaf_unit_active,
    :logical_leaf_unit_forcing_available,
)

function _logical_leaf_layout_output_type(
    model::MAESPALogicalLeafUnitLayout,
    status,
)
    unit_count = _logical_leaf_layout_unit_count(
        model.point_count,
        model.slot_count,
        model.physiological_age_count,
    )
    first_output = status.logical_leaf_area_fraction
    first_output isa AbstractVector || throw(
        ArgumentError("logical_leaf_area_fraction must be an AbstractVector"),
    )
    T = eltype(first_output)
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "logical-leaf-unit outputs must have a concrete AbstractFloat element type",
        ),
    )
    for name in _LOGICAL_LEAF_LAYOUT_FLOAT_VECTOR_OUTPUTS
        values = getproperty(status, name)
        values isa AbstractVector || throw(
            ArgumentError("$(String(name)) must be an AbstractVector"),
        )
        _logical_leaf_layout_require_eltype(values, T, name)
        _logical_leaf_layout_require_length(values, unit_count, name)
    end
    for name in _LOGICAL_LEAF_LAYOUT_INTEGER_VECTOR_OUTPUTS
        values = getproperty(status, name)
        values isa AbstractVector{<:Integer} || throw(
            ArgumentError("$(String(name)) must contain integer values"),
        )
        eltype(values) === Int || throw(
            ArgumentError("$(String(name)) must have element type Int"),
        )
        _logical_leaf_layout_require_length(values, unit_count, name)
    end
    for name in _LOGICAL_LEAF_LAYOUT_BOOL_VECTOR_OUTPUTS
        values = getproperty(status, name)
        values isa AbstractVector{Bool} || throw(
            ArgumentError("$(String(name)) must contain Bool values"),
        )
        _logical_leaf_layout_require_length(values, unit_count, name)
    end
    typeof(status.logical_leaf_area_total_m2) === T || throw(
        ArgumentError("logical_leaf_area_total_m2 must use output type $T"),
    )
    for name in (
        :effective_leaf_radiation_class_count,
        :active_logical_leaf_unit_count,
    )
        value = getproperty(status, name)
        value isa Integer && !(value isa Bool) || throw(
            ArgumentError("$(String(name)) must be an integer, not Bool"),
        )
    end
    for name in (
        :logical_leaf_unit_layout_available,
        :logical_leaf_forcing_available,
    )
        getproperty(status, name) isa Bool || throw(
            ArgumentError("$(String(name)) must be Bool"),
        )
    end
    return T
end

function _install_logical_leaf_unit_layout_result!(status, result)
    for name in _LOGICAL_LEAF_LAYOUT_FLOAT_VECTOR_OUTPUTS
        setproperty!(status, name, getproperty(result, name))
    end
    for name in _LOGICAL_LEAF_LAYOUT_INTEGER_VECTOR_OUTPUTS
        setproperty!(status, name, getproperty(result, name))
    end
    for name in _LOGICAL_LEAF_LAYOUT_BOOL_VECTOR_OUTPUTS
        setproperty!(status, name, getproperty(result, name))
    end
    status.effective_leaf_radiation_class_count =
        result.effective_leaf_radiation_class_count
    status.active_logical_leaf_unit_count =
        result.active_logical_leaf_unit_count
    status.logical_leaf_area_total_m2 = result.logical_leaf_area_total_m2
    status.logical_leaf_unit_layout_available =
        result.logical_leaf_unit_layout_available
    status.logical_leaf_forcing_available =
        result.logical_leaf_forcing_available
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPALogicalLeafUnitLayout,
    status,
    environment,
    constants,
    context,
)
    T = try
        _logical_leaf_layout_output_type(model, status)
    catch
        status.logical_leaf_unit_layout_available = false
        status.logical_leaf_forcing_available = false
        rethrow()
    end
    for name in (
        :astronomical_daylight,
        :leaf_radiation_partitioning_available,
        :leaf_radiative_forcing_available,
        :diffuse_transmission_available,
        :canopy_wind_profile_available,
        :logical_leaf_unit_layout_inputs_available,
    )
        getproperty(status, name) isa Bool || throw(
            ArgumentError("$(String(name)) must be Bool"),
        )
    end
    layout_inputs_available = status.logical_leaf_unit_layout_inputs_available
    partition_available = status.leaf_radiation_partitioning_available
    daylight = status.astronomical_daylight
    if !layout_inputs_available || (daylight && !partition_available)
        unavailable = _fresh_logical_leaf_unit_layout_result(
            T,
            _logical_leaf_layout_unit_count(
                model.point_count,
                model.slot_count,
                model.physiological_age_count,
            ),
        )
        _install_logical_leaf_unit_layout_result!(status, unavailable)
        return nothing
    end

    _logical_leaf_layout_source_eltypes(
        T,
        status.source_leaf_radiation_area_fraction,
        status.source_leaf_area_density_by_age,
        status.source_representative_volumes,
        status.source_leaf_radiation_absorbed_par_umol_m2_s,
        status.source_leaf_radiation_net_w_m2_leaf,
        status.source_relative_diffuse_penetration,
        status.source_diffuse_transmittance_up,
        status.source_diffuse_transmittance_down,
        status.source_relative_wind_speed_by_layer,
        status.source_jmax25_umol_m2_s,
        status.source_vcmax25_umol_m2_s,
        status.source_rd0_umol_m2_s,
        status.source_quantum_yield,
    )
    result = logical_leaf_unit_layout(
        status.source_leaf_radiation_area_fraction,
        status.source_leaf_area_density_by_age,
        status.source_representative_volumes,
        status.source_physiological_layers,
        status.active_leaf_radiation_class_count,
        daylight,
        status.source_leaf_radiation_absorbed_par_umol_m2_s,
        status.source_leaf_radiation_net_w_m2_leaf,
        status.source_relative_diffuse_penetration,
        status.source_diffuse_transmittance_up,
        status.source_diffuse_transmittance_down,
        status.source_relative_wind_speed_by_layer,
        status.source_jmax25_umol_m2_s,
        status.source_vcmax25_umol_m2_s,
        status.source_rd0_umol_m2_s,
        status.source_quantum_yield;
        leaf_radiative_forcing_available=
            status.leaf_radiative_forcing_available,
        diffuse_transmission_available=
            status.diffuse_transmission_available,
        canopy_wind_profile_available=
            status.canopy_wind_profile_available,
    )
    size(status.source_leaf_radiation_area_fraction) ==
    (model.point_count, model.slot_count) || throw(
        DimensionMismatch(
            "source_leaf_radiation_area_fraction does not match the configured point and slot counts",
        ),
    )
    size(status.source_leaf_area_density_by_age) ==
    (model.physiological_age_count, model.point_count) || throw(
        DimensionMismatch(
            "source_leaf_area_density_by_age does not match the configured age and point counts",
        ),
    )
    size(status.source_jmax25_umol_m2_s, 1) ==
    model.physiological_layer_count || throw(
        DimensionMismatch(
            "source_jmax25_umol_m2_s does not match the configured layer count",
        ),
    )
    _install_logical_leaf_unit_layout_result!(status, result)
    return nothing
end
