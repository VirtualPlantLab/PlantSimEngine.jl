PlantSimEngine.@process "soil_surface_energy_forcing" verbose = false

"""Inputs prepared for MAESPA's soil-surface energy-balance models."""
struct SoilSurfaceEnergyForcingResult{T<:AbstractFloat}
    soil_energy_prescribed_temperature_k::T
    soil_energy_air_temperature_k::T
    soil_energy_first_profile_node_temperature_k::T
    soil_energy_vapour_pressure_deficit_kpa::T
    soil_energy_aerodynamic_conductance_m_s::T
    soil_energy_atmospheric_pressure_pa::T
    soil_energy_first_layer_thermal_conductivity_w_m_k::T
    soil_energy_first_layer_thickness_m::T
    soil_energy_first_layer_pore_fraction::T
    soil_energy_first_layer_soil_water_potential_mpa::T
    soil_energy_previous_dry_layer_thickness_m::T
    soil_energy_thermal_reflectance::T
    soil_energy_absorbed_par_w_m2::T
    soil_energy_absorbed_nir_w_m2::T
    soil_energy_downward_thermal_radiation_w_m2::T
    soil_energy_simulate_soil_temperature::Bool
    soil_energy_simulate_soil_evaporation::Bool
    soil_energy_use_measured_evapotranspiration::Bool
    soil_energy_simulate_soil_dew::Bool
    soil_energy_forcing_available::Bool
end

@noinline function _throw_soil_surface_energy_forcing_value(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :fraction
        throw(DomainError(value, "$label must lie in [0, 1]"))
    elseif reason === :positive_fraction
        throw(DomainError(value, "$label must lie in (0, 1]"))
    elseif reason === :nonpositive
        throw(DomainError(value, "$label must be non-positive"))
    elseif reason === :switch
        throw(ArgumentError("$label must be Bool or the legacy integer 0 or 1"))
    elseif reason === :output_type
        throw(
            ArgumentError(
                "$label and soil-surface-energy-forcing output carriers " *
                "must share a floating-point type",
            ),
        )
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _soil_surface_energy_forcing_nonnegative(
    value::T,
    name::Symbol,
) where {T}
    value >= zero(T) ||
        _throw_soil_surface_energy_forcing_value(name, value, :nonnegative)
    return value
end

@inline function _soil_surface_energy_forcing_primary_float(value, name::Symbol)
    value isa Real ||
        _throw_soil_surface_energy_forcing_value(name, value, :real)
    value isa Bool &&
        _throw_soil_surface_energy_forcing_value(name, value, :bool)
    converted = float(value)
    converted isa AbstractFloat ||
        _throw_soil_surface_energy_forcing_value(name, value, :real)
    isfinite(converted) ||
        _throw_soil_surface_energy_forcing_value(name, converted, :finite)
    return converted
end

@inline function _soil_surface_energy_forcing_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real ||
        _throw_soil_surface_energy_forcing_value(name, value, :real)
    value isa Bool &&
        _throw_soil_surface_energy_forcing_value(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_soil_surface_energy_forcing_value(name, converted, :finite)
    return converted
end

@inline function _soil_surface_energy_forcing_positive(value::T, name::Symbol) where {T}
    value > zero(T) ||
        _throw_soil_surface_energy_forcing_value(name, value, :positive)
    return value
end

@inline function _soil_surface_energy_forcing_fraction(value::T, name::Symbol) where {T}
    zero(T) <= value <= one(T) ||
        _throw_soil_surface_energy_forcing_value(name, value, :fraction)
    return value
end

@inline function _soil_surface_energy_forcing_positive_fraction(
    value::T,
    name::Symbol,
) where {T}
    zero(T) < value <= one(T) ||
        _throw_soil_surface_energy_forcing_value(name, value, :positive_fraction)
    return value
end

@inline function _soil_surface_energy_forcing_switch(value, name::Symbol)
    value isa Bool && return value
    if value isa Integer && !(value isa Bool) && value in (0, 1)
        return value == 1
    end
    _throw_soil_surface_energy_forcing_value(name, value, :switch)
end

"""
    legacy_deep_soil_node_temperature_k(initial_state; kelvin_offset=273.15)

Return the initial value of historical `SOILTEMP(2)`. This is a thermal-profile
node, not the temperature of a Julia object selected merely because it is the
second `SoilLayer`. Before the first heat-transfer step, MAESPA uses the second
configured temperature when it exists and duplicates the sole temperature for
`NLAYER=1`.

The Julia scene preserves the raw `SOILTEMP(1)` boundary separately as
`Soil.configured_initial_soil_surface_temperature_c` and initializes physical
`SoilLayer.soil_temperature_c` values from `SOILTEMP(2:n+1)`, duplicating the
deepest configured value. Consequently this helper is equal to the first
physical profile node at initialization. It reads the raw configuration
directly so it remains valid before a scene has been built; it must not be
replaced by selecting the second `SoilLayer` object.

At runtime, [`MAESPASoilSurfaceEnergyForcing`](@ref) therefore accepts this
node as one scalar already in kelvins. A future scenario can bind that scalar
through `PreviousTimeStep` to the corresponding output of the soil heat-transfer
model without a K -> C -> K round trip.
"""
function legacy_deep_soil_node_temperature_k(
    initial_state::InitialSoilState{T};
    kelvin_offset=273.15,
) where {T<:AbstractFloat}
    temperatures = initial_state.temperature_c
    Base.require_one_based_indexing(temperatures)
    isempty(temperatures) && throw(
        ArgumentError("initial soil temperature must contain at least one layer"),
    )
    offset = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(
            T,
            kelvin_offset,
            :kelvin_offset,
        ),
        :kelvin_offset,
    )
    index = min(2, length(temperatures))
    temperature_c = _soil_surface_energy_forcing_float(
        T,
        temperatures[index],
        :deep_soil_node_temperature_c,
    )
    return _soil_surface_energy_forcing_positive(
        temperature_c + offset,
        :deep_soil_node_temperature_k,
    )
end

"""
    MAESPASoilSurfaceEnergyForcing(T=Float64; first_layer_thickness_m,
                                   first_layer_pore_fraction,
                                   soil_thermal_reflectance, kwargs...)

Typed adapter between MAESPA's actual runtime producers and the exact inputs
of `MAESPAPrescribedSoilSurfaceEnergyBalance`. The first-layer geometry,
porosity, species-one thermal soil reflectance, and legacy switches are fixed
parameters. Timestep-varying meteorology, soil state, radiation, and the
accepted previous dry-layer thickness remain status inputs.

Source names and prepared output names are intentionally disjoint
(`source_*` versus `soil_energy_*`). Several real producers already publish on
the same `Soil` object; the future scenario must explicitly alias each prepared
output to the corresponding consumer input instead of creating self-colliding
producer names. The adapter publishes one availability flag which is the
conjunction of every explicit source flag. The two first-layer property flags
are adapter contracts for the future mount; the current property models do not
yet publish those flags themselves.

`deep_soil_node_temperature_k` is an already-Kelvin scalar representing
historical `SOILTEMP(2)`. It must be bound by profile-node identity (and later
by `PreviousTimeStep`), never by selecting an incidental second `SoilLayer`
object.

When `simulate_soil_temperature=true`, the prescribed-temperature source and
its availability gate are explicitly inactive defaults. The adapter does not
inspect them and publishes a zero placeholder for
`soil_energy_prescribed_temperature_k`; current `SOILTK` is then owned solely
by [`MAESPASoilSurfaceEnergyBalance`](@ref). The prescribed branch retains its
required source and positive-temperature validation unchanged.

Vapour-pressure deficit is converted from Pa to kPa without clamping its sign.
The Fortran `QEFLUX` expression accepts a negative deficit, and the dew switch
decides whether a resulting negative latent flux is retained. PAR, NIR, and
downward thermal radiation are required to be non-negative.
"""
struct MAESPASoilSurfaceEnergyForcing{T<:AbstractFloat} <:
       AbstractSoil_Surface_Energy_ForcingModel
    first_layer_thickness_m::T
    first_layer_pore_fraction::T
    soil_thermal_reflectance::T
    simulate_soil_temperature::Bool
    simulate_soil_evaporation::Bool
    use_measured_evapotranspiration::Bool
    simulate_soil_dew::Bool
    kelvin_offset::T
    pascals_per_kilopascal::T
end

function MAESPASoilSurfaceEnergyForcing(
    ::Type{T}=Float64;
    first_layer_thickness_m,
    first_layer_pore_fraction,
    soil_thermal_reflectance,
    simulate_soil_temperature=false,
    simulate_soil_evaporation=true,
    use_measured_evapotranspiration=false,
    simulate_soil_dew=false,
    kelvin_offset=273.15,
    pascals_per_kilopascal=1000,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the soil-energy-forcing numeric type must be concrete"),
    )
    thickness = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(
            T,
            first_layer_thickness_m,
            :first_layer_thickness_m,
        ),
        :first_layer_thickness_m,
    )
    pore_fraction = _soil_surface_energy_forcing_positive_fraction(
        _soil_surface_energy_forcing_float(
            T,
            first_layer_pore_fraction,
            :first_layer_pore_fraction,
        ),
        :first_layer_pore_fraction,
    )
    reflectance = _soil_surface_energy_forcing_fraction(
        _soil_surface_energy_forcing_float(
            T,
            soil_thermal_reflectance,
            :soil_thermal_reflectance,
        ),
        :soil_thermal_reflectance,
    )
    offset = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(T, kelvin_offset, :kelvin_offset),
        :kelvin_offset,
    )
    pressure_scale = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(
            T,
            pascals_per_kilopascal,
            :pascals_per_kilopascal,
        ),
        :pascals_per_kilopascal,
    )
    return MAESPASoilSurfaceEnergyForcing{T}(
        thickness,
        pore_fraction,
        reflectance,
        _soil_surface_energy_forcing_switch(
            simulate_soil_temperature,
            :simulate_soil_temperature,
        ),
        _soil_surface_energy_forcing_switch(
            simulate_soil_evaporation,
            :simulate_soil_evaporation,
        ),
        _soil_surface_energy_forcing_switch(
            use_measured_evapotranspiration,
            :use_measured_evapotranspiration,
        ),
        _soil_surface_energy_forcing_switch(
            simulate_soil_dew,
            :simulate_soil_dew,
        ),
        offset,
        pressure_scale,
    )
end

function MAESPASoilSurfaceEnergyForcing(
    config::SoilConfig{T};
    soil_thermal_reflectance,
    kwargs...,
) where {T<:AbstractFloat}
    config.layers.layer_count > 0 || throw(
        ArgumentError("soil energy forcing requires at least one soil layer"),
    )
    return MAESPASoilSurfaceEnergyForcing(
        T;
        first_layer_thickness_m=config.layers.thickness_m[1],
        first_layer_pore_fraction=config.layers.pore_fraction[1],
        soil_thermal_reflectance,
        simulate_soil_temperature=config.options.simulate_soil_temperature,
        simulate_soil_evaporation=config.options.simulate_soil_evaporation,
        use_measured_evapotranspiration=
            config.options.use_measured_evapotranspiration,
        simulate_soil_dew=config.options.simulate_soil_dew,
        kwargs...,
    )
end

@inline function _soil_surface_energy_forcing(
    model::MAESPASoilSurfaceEnergyForcing,
    ::Type{T},
    prescribed_soil_temperature_c,
    air_temperature_c,
    deep_soil_node_temperature_k,
    vapour_pressure_deficit_pa,
    air_pressure_pa,
    soil_aerodynamic_conductance_m_s,
    surface_layer_thermal_conductivity_w_m_k,
    surface_layer_soil_water_potential_mpa,
    previous_dry_layer_thickness_m,
    absorbed_soil_par_w_m2,
    absorbed_soil_nir_w_m2,
    downward_soil_thermal_radiation_w_m2,
) where {T<:AbstractFloat}
    offset = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(T, model.kelvin_offset, :kelvin_offset),
        :kelvin_offset,
    )
    pressure_scale = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(
            T,
            model.pascals_per_kilopascal,
            :pascals_per_kilopascal,
        ),
        :pascals_per_kilopascal,
    )
    soil_temperature_k = if model.simulate_soil_temperature
        # This carrier is an explicitly inactive placeholder in SIMTSOIL=1.
        # The bounded surface-energy model produces current SOILTK instead.
        zero(T)
    else
        _soil_surface_energy_forcing_positive(
            _soil_surface_energy_forcing_float(
                T,
                prescribed_soil_temperature_c,
                :prescribed_soil_temperature_c,
            ) + offset,
            :soil_temperature_k,
        )
    end
    air_temperature_k = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(
            T,
            air_temperature_c,
            :air_temperature_c,
        ) + offset,
        :air_temperature_k,
    )
    deep_temperature = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(
            T,
            deep_soil_node_temperature_k,
            :deep_soil_node_temperature_k,
        ),
        :deep_soil_node_temperature_k,
    )
    vpd_kpa = _soil_surface_energy_forcing_float(
        T,
        vapour_pressure_deficit_pa,
        :vapour_pressure_deficit_pa,
    ) / pressure_scale
    conductance = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(
            T,
            soil_aerodynamic_conductance_m_s,
            :soil_aerodynamic_conductance_m_s,
        ),
        :soil_aerodynamic_conductance_m_s,
    )
    pressure = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(T, air_pressure_pa, :air_pressure_pa),
        :air_pressure_pa,
    )
    conductivity = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(
            T,
            surface_layer_thermal_conductivity_w_m_k,
            :surface_layer_thermal_conductivity_w_m_k,
        ),
        :surface_layer_thermal_conductivity_w_m_k,
    )
    water_potential = _soil_surface_energy_forcing_float(
        T,
        surface_layer_soil_water_potential_mpa,
        :surface_layer_soil_water_potential_mpa,
    )
    water_potential <= zero(T) ||
        _throw_soil_surface_energy_forcing_value(
            :surface_layer_soil_water_potential_mpa,
            water_potential,
            :nonpositive,
        )
    dry_layer = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(
            T,
            previous_dry_layer_thickness_m,
            :previous_dry_layer_thickness_m,
        ),
        :previous_dry_layer_thickness_m,
    )
    par = _soil_surface_energy_forcing_nonnegative(
        _soil_surface_energy_forcing_float(
            T,
            absorbed_soil_par_w_m2,
            :absorbed_soil_par_w_m2,
        ),
        :absorbed_soil_par_w_m2,
    )
    nir = _soil_surface_energy_forcing_nonnegative(
        _soil_surface_energy_forcing_float(
            T,
            absorbed_soil_nir_w_m2,
            :absorbed_soil_nir_w_m2,
        ),
        :absorbed_soil_nir_w_m2,
    )
    downward_thermal = _soil_surface_energy_forcing_nonnegative(
        _soil_surface_energy_forcing_float(
            T,
            downward_soil_thermal_radiation_w_m2,
            :downward_soil_thermal_radiation_w_m2,
        ),
        :downward_soil_thermal_radiation_w_m2,
    )
    thickness = _soil_surface_energy_forcing_positive(
        _soil_surface_energy_forcing_float(
            T,
            model.first_layer_thickness_m,
            :first_layer_thickness_m,
        ),
        :first_layer_thickness_m,
    )
    pore_fraction = _soil_surface_energy_forcing_positive_fraction(
        _soil_surface_energy_forcing_float(
            T,
            model.first_layer_pore_fraction,
            :first_layer_pore_fraction,
        ),
        :first_layer_pore_fraction,
    )
    reflectance = _soil_surface_energy_forcing_fraction(
        _soil_surface_energy_forcing_float(
            T,
            model.soil_thermal_reflectance,
            :soil_thermal_reflectance,
        ),
        :soil_thermal_reflectance,
    )
    return SoilSurfaceEnergyForcingResult{T}(
        soil_temperature_k,
        air_temperature_k,
        deep_temperature,
        vpd_kpa,
        conductance,
        pressure,
        conductivity,
        thickness,
        pore_fraction,
        water_potential,
        dry_layer,
        reflectance,
        par,
        nir,
        downward_thermal,
        model.simulate_soil_temperature,
        model.simulate_soil_evaporation,
        model.use_measured_evapotranspiration,
        model.simulate_soil_dew,
        true,
    )
end

"""Prepare the exact, unit-normalized inputs consumed by soil surface energy."""
function soil_surface_energy_forcing(
    prescribed_soil_temperature_c,
    air_temperature_c,
    deep_soil_node_temperature_k,
    vapour_pressure_deficit_pa,
    air_pressure_pa,
    soil_aerodynamic_conductance_m_s,
    surface_layer_thermal_conductivity_w_m_k,
    surface_layer_soil_water_potential_mpa,
    previous_dry_layer_thickness_m,
    absorbed_soil_par_w_m2,
    absorbed_soil_nir_w_m2,
    downward_soil_thermal_radiation_w_m2;
    first_layer_thickness_m,
    first_layer_pore_fraction,
    soil_thermal_reflectance,
    kwargs...,
)
    simulate_temperature = _soil_surface_energy_forcing_switch(
        get(kwargs, :simulate_soil_temperature, false),
        :simulate_soil_temperature,
    )
    active_promoted = promote(
        _soil_surface_energy_forcing_primary_float(
            air_temperature_c,
            :air_temperature_c,
        ),
        _soil_surface_energy_forcing_primary_float(
            deep_soil_node_temperature_k,
            :deep_soil_node_temperature_k,
        ),
        _soil_surface_energy_forcing_primary_float(
            vapour_pressure_deficit_pa,
            :vapour_pressure_deficit_pa,
        ),
        _soil_surface_energy_forcing_primary_float(
            air_pressure_pa,
            :air_pressure_pa,
        ),
        _soil_surface_energy_forcing_primary_float(
            soil_aerodynamic_conductance_m_s,
            :soil_aerodynamic_conductance_m_s,
        ),
        _soil_surface_energy_forcing_primary_float(
            surface_layer_thermal_conductivity_w_m_k,
            :surface_layer_thermal_conductivity_w_m_k,
        ),
        _soil_surface_energy_forcing_primary_float(
            surface_layer_soil_water_potential_mpa,
            :surface_layer_soil_water_potential_mpa,
        ),
        _soil_surface_energy_forcing_primary_float(
            previous_dry_layer_thickness_m,
            :previous_dry_layer_thickness_m,
        ),
        _soil_surface_energy_forcing_primary_float(
            absorbed_soil_par_w_m2,
            :absorbed_soil_par_w_m2,
        ),
        _soil_surface_energy_forcing_primary_float(
            absorbed_soil_nir_w_m2,
            :absorbed_soil_nir_w_m2,
        ),
        _soil_surface_energy_forcing_primary_float(
            downward_soil_thermal_radiation_w_m2,
            :downward_soil_thermal_radiation_w_m2,
        ),
    )
    T = typeof(first(active_promoted))
    promoted = if simulate_temperature
        # The prescribed carrier is inactive in SIMTSOIL=1 and therefore must
        # neither validate nor widen the active computation type.
        (zero(T), active_promoted...)
    else
        promote(
            _soil_surface_energy_forcing_primary_float(
                prescribed_soil_temperature_c,
                :prescribed_soil_temperature_c,
            ),
            active_promoted...,
        )
    end
    T = typeof(first(promoted))
    model = MAESPASoilSurfaceEnergyForcing(
        T;
        first_layer_thickness_m,
        first_layer_pore_fraction,
        soil_thermal_reflectance,
        kwargs...,
    )
    return _soil_surface_energy_forcing(model, T, promoted...)
end

PlantSimEngine.inputs_(model::MAESPASoilSurfaceEnergyForcing) = (
    atmosphere_ready=PlantSimEngine.Default(true),
    source_prescribed_soil_temperature_c=
        model.simulate_soil_temperature ?
        PlantSimEngine.Default(zero(model.kelvin_offset)) :
        PlantSimEngine.Required(Real),
    source_deep_soil_node_temperature_k=PlantSimEngine.Required(Real),
    source_soil_aerodynamic_conductance_m_s=PlantSimEngine.Required(Real),
    source_surface_layer_thermal_conductivity_w_m_k=
        PlantSimEngine.Required(Real),
    source_surface_layer_soil_water_potential_mpa=PlantSimEngine.Required(Real),
    source_previous_dry_layer_thickness_m=PlantSimEngine.Required(Real),
    source_absorbed_soil_par_w_m2=PlantSimEngine.Required(Real),
    source_absorbed_soil_nir_w_m2=PlantSimEngine.Required(Real),
    source_downward_soil_thermal_radiation_w_m2=PlantSimEngine.Required(Real),
    source_prescribed_soil_temperature_available=
        model.simulate_soil_temperature ? PlantSimEngine.Default(true) :
        PlantSimEngine.Required(Bool),
    source_deep_soil_node_temperature_available=PlantSimEngine.Required(Bool),
    source_soil_surface_aerodynamics_available=PlantSimEngine.Required(Bool),
    source_first_layer_thermal_properties_available=
        PlantSimEngine.Required(Bool),
    source_first_layer_hydraulic_properties_available=
        PlantSimEngine.Required(Bool),
    source_previous_soil_dry_layer_state_available=
        PlantSimEngine.Required(Bool),
    source_soil_shortwave_radiation_available=PlantSimEngine.Required(Bool),
    source_soil_longwave_radiation_available=PlantSimEngine.Required(Bool),
    source_soil_surface_energy_forcing_active=PlantSimEngine.Default(true),
)

function PlantSimEngine.outputs_(model::MAESPASoilSurfaceEnergyForcing{T}) where {T}
    return (
        soil_energy_prescribed_temperature_k=zero(T),
        soil_energy_air_temperature_k=zero(T),
        soil_energy_first_profile_node_temperature_k=zero(T),
        soil_energy_vapour_pressure_deficit_kpa=zero(T),
        soil_energy_aerodynamic_conductance_m_s=zero(T),
        soil_energy_atmospheric_pressure_pa=zero(T),
        soil_energy_first_layer_thermal_conductivity_w_m_k=zero(T),
        soil_energy_first_layer_thickness_m=zero(T),
        soil_energy_first_layer_pore_fraction=zero(T),
        soil_energy_first_layer_soil_water_potential_mpa=zero(T),
        soil_energy_previous_dry_layer_thickness_m=zero(T),
        soil_energy_thermal_reflectance=zero(T),
        soil_energy_absorbed_par_w_m2=zero(T),
        soil_energy_absorbed_nir_w_m2=zero(T),
        soil_energy_downward_thermal_radiation_w_m2=zero(T),
        soil_energy_simulate_soil_temperature=model.simulate_soil_temperature,
        soil_energy_simulate_soil_evaporation=model.simulate_soil_evaporation,
        soil_energy_use_measured_evapotranspiration=
            model.use_measured_evapotranspiration,
        soil_energy_simulate_soil_dew=model.simulate_soil_dew,
        soil_energy_forcing_available=false,
    )
end

function PlantSimEngine.variable_contracts_(model::MAESPASoilSurfaceEnergyForcing)
    contracts = (
        source_deep_soil_node_temperature_k=SOIL_PROFILE_NODE_TEMPERATURE_CONTRACT,
        soil_energy_first_profile_node_temperature_k=
            SOIL_PROFILE_NODE_TEMPERATURE_CONTRACT,
        source_surface_layer_soil_water_potential_mpa=SOIL_LAYER_WATER_POTENTIAL_CONTRACT,
        soil_energy_first_layer_soil_water_potential_mpa=SOIL_LAYER_WATER_POTENTIAL_CONTRACT,
        soil_energy_forcing_available=SOIL_SURFACE_ENERGY_CONTEXT_AVAILABLE_CONTRACT,
    )
    # In simulated mode the prescribed port is an inactive zero placeholder,
    # not an alternative publisher of the physical SOILTK boundary.
    model.simulate_soil_temperature && return contracts
    return merge(
        contracts,
        (
            soil_energy_prescribed_temperature_k=
                SOIL_HEAT_SURFACE_BOUNDARY_TEMPERATURE_CONTRACT,
        ),
    )
end

@inline function _require_soil_surface_energy_forcing_output_type(
    value,
    ::Type{T},
    name::Symbol,
) where {T<:AbstractFloat}
    typeof(value) === T ||
        _throw_soil_surface_energy_forcing_value(name, value, :output_type)
    return nothing
end

@inline function _reset_soil_surface_energy_forcing!(
    model::MAESPASoilSurfaceEnergyForcing,
    status,
    ::Type{T},
) where {T<:AbstractFloat}
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_prescribed_temperature_k,
        T,
        :soil_energy_prescribed_temperature_k,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_air_temperature_k,
        T,
        :soil_energy_air_temperature_k,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_first_profile_node_temperature_k,
        T,
        :soil_energy_first_profile_node_temperature_k,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_vapour_pressure_deficit_kpa,
        T,
        :soil_energy_vapour_pressure_deficit_kpa,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_aerodynamic_conductance_m_s,
        T,
        :soil_energy_aerodynamic_conductance_m_s,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_atmospheric_pressure_pa,
        T,
        :soil_energy_atmospheric_pressure_pa,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_first_layer_thermal_conductivity_w_m_k,
        T,
        :soil_energy_first_layer_thermal_conductivity_w_m_k,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_first_layer_thickness_m,
        T,
        :soil_energy_first_layer_thickness_m,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_first_layer_pore_fraction,
        T,
        :soil_energy_first_layer_pore_fraction,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_first_layer_soil_water_potential_mpa,
        T,
        :soil_energy_first_layer_soil_water_potential_mpa,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_previous_dry_layer_thickness_m,
        T,
        :soil_energy_previous_dry_layer_thickness_m,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_thermal_reflectance,
        T,
        :soil_energy_thermal_reflectance,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_absorbed_par_w_m2,
        T,
        :soil_energy_absorbed_par_w_m2,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_absorbed_nir_w_m2,
        T,
        :soil_energy_absorbed_nir_w_m2,
    )
    _require_soil_surface_energy_forcing_output_type(
        status.soil_energy_downward_thermal_radiation_w_m2,
        T,
        :soil_energy_downward_thermal_radiation_w_m2,
    )
    status.soil_energy_prescribed_temperature_k = zero(T)
    status.soil_energy_air_temperature_k = zero(T)
    status.soil_energy_first_profile_node_temperature_k = zero(T)
    status.soil_energy_vapour_pressure_deficit_kpa = zero(T)
    status.soil_energy_aerodynamic_conductance_m_s = zero(T)
    status.soil_energy_atmospheric_pressure_pa = zero(T)
    status.soil_energy_first_layer_thermal_conductivity_w_m_k = zero(T)
    status.soil_energy_first_layer_thickness_m = zero(T)
    status.soil_energy_first_layer_pore_fraction = zero(T)
    status.soil_energy_first_layer_soil_water_potential_mpa = zero(T)
    status.soil_energy_previous_dry_layer_thickness_m = zero(T)
    status.soil_energy_thermal_reflectance = zero(T)
    status.soil_energy_absorbed_par_w_m2 = zero(T)
    status.soil_energy_absorbed_nir_w_m2 = zero(T)
    status.soil_energy_downward_thermal_radiation_w_m2 = zero(T)
    status.soil_energy_simulate_soil_temperature =
        model.simulate_soil_temperature
    status.soil_energy_simulate_soil_evaporation =
        model.simulate_soil_evaporation
    status.soil_energy_use_measured_evapotranspiration =
        model.use_measured_evapotranspiration
    status.soil_energy_simulate_soil_dew = model.simulate_soil_dew
    status.soil_energy_forcing_available = false
    return nothing
end

@inline function _soil_surface_energy_forcing_boolean(value, name::Symbol)
    value isa Bool ||
        _throw_soil_surface_energy_forcing_value(name, value, :switch)
    return value
end

@inline function _soil_surface_energy_forcing_available(model, status)
    prescribed_temperature = if model.simulate_soil_temperature
        true
    else
        _soil_surface_energy_forcing_boolean(
            status.source_prescribed_soil_temperature_available,
            :source_prescribed_soil_temperature_available,
        )
    end
    deep_temperature = _soil_surface_energy_forcing_boolean(
        status.source_deep_soil_node_temperature_available,
        :source_deep_soil_node_temperature_available,
    )
    aerodynamics = _soil_surface_energy_forcing_boolean(
        status.source_soil_surface_aerodynamics_available,
        :source_soil_surface_aerodynamics_available,
    )
    thermal_properties = _soil_surface_energy_forcing_boolean(
        status.source_first_layer_thermal_properties_available,
        :source_first_layer_thermal_properties_available,
    )
    hydraulic_properties = _soil_surface_energy_forcing_boolean(
        status.source_first_layer_hydraulic_properties_available,
        :source_first_layer_hydraulic_properties_available,
    )
    dry_layer = _soil_surface_energy_forcing_boolean(
        status.source_previous_soil_dry_layer_state_available,
        :source_previous_soil_dry_layer_state_available,
    )
    shortwave = _soil_surface_energy_forcing_boolean(
        status.source_soil_shortwave_radiation_available,
        :source_soil_shortwave_radiation_available,
    )
    longwave = _soil_surface_energy_forcing_boolean(
        status.source_soil_longwave_radiation_available,
        :source_soil_longwave_radiation_available,
    )
    active = _soil_surface_energy_forcing_boolean(
        status.source_soil_surface_energy_forcing_active,
        :source_soil_surface_energy_forcing_active,
    )
    return prescribed_temperature &&
           deep_temperature &&
           aerodynamics &&
           thermal_properties &&
           hydraulic_properties &&
           dry_layer &&
           shortwave &&
           longwave &&
           active
end

function PlantSimEngine.run!(
    model::MAESPASoilSurfaceEnergyForcing,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.soil_energy_prescribed_temperature_k)
    T <: AbstractFloat && isconcretetype(T) ||
        _throw_soil_surface_energy_forcing_value(
            :soil_energy_prescribed_temperature_k,
            status.soil_energy_prescribed_temperature_k,
            :output_type,
        )
    _reset_soil_surface_energy_forcing!(model, status, T)
    status.atmosphere_ready && _soil_surface_energy_forcing_available(model, status) || return nothing

    result = _soil_surface_energy_forcing(
        model,
        T,
        status.source_prescribed_soil_temperature_c,
        environment.air_temperature_c,
        status.source_deep_soil_node_temperature_k,
        environment.vapour_pressure_deficit_pa,
        environment.air_pressure_pa,
        status.source_soil_aerodynamic_conductance_m_s,
        status.source_surface_layer_thermal_conductivity_w_m_k,
        status.source_surface_layer_soil_water_potential_mpa,
        status.source_previous_dry_layer_thickness_m,
        status.source_absorbed_soil_par_w_m2,
        status.source_absorbed_soil_nir_w_m2,
        status.source_downward_soil_thermal_radiation_w_m2,
    )
    status.soil_energy_prescribed_temperature_k =
        result.soil_energy_prescribed_temperature_k
    status.soil_energy_air_temperature_k = result.soil_energy_air_temperature_k
    status.soil_energy_first_profile_node_temperature_k =
        result.soil_energy_first_profile_node_temperature_k
    status.soil_energy_vapour_pressure_deficit_kpa =
        result.soil_energy_vapour_pressure_deficit_kpa
    status.soil_energy_aerodynamic_conductance_m_s =
        result.soil_energy_aerodynamic_conductance_m_s
    status.soil_energy_atmospheric_pressure_pa =
        result.soil_energy_atmospheric_pressure_pa
    status.soil_energy_first_layer_thermal_conductivity_w_m_k =
        result.soil_energy_first_layer_thermal_conductivity_w_m_k
    status.soil_energy_first_layer_thickness_m =
        result.soil_energy_first_layer_thickness_m
    status.soil_energy_first_layer_pore_fraction =
        result.soil_energy_first_layer_pore_fraction
    status.soil_energy_first_layer_soil_water_potential_mpa =
        result.soil_energy_first_layer_soil_water_potential_mpa
    status.soil_energy_previous_dry_layer_thickness_m =
        result.soil_energy_previous_dry_layer_thickness_m
    status.soil_energy_thermal_reflectance =
        result.soil_energy_thermal_reflectance
    status.soil_energy_absorbed_par_w_m2 =
        result.soil_energy_absorbed_par_w_m2
    status.soil_energy_absorbed_nir_w_m2 =
        result.soil_energy_absorbed_nir_w_m2
    status.soil_energy_downward_thermal_radiation_w_m2 =
        result.soil_energy_downward_thermal_radiation_w_m2
    status.soil_energy_forcing_available = true
    return nothing
end

PlantSimEngine.environment_inputs_(::MAESPASoilSurfaceEnergyForcing{T}) where {T} = (
    air_temperature_c=zero(T),
    vapour_pressure_deficit_pa=zero(T),
    air_pressure_pa=zero(T),
)
