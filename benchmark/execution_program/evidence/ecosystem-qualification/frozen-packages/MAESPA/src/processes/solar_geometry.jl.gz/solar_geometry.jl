PlantSimEngine.@process "solar_geometry" verbose = false

function _solar_reference_astronomical_day(reference)
    isnothing(reference) && return nothing
    reference isa Integer && !(reference isa Bool) || throw(
        ArgumentError("reference_astronomical_day must be an integer or nothing"),
    )
    return Int(reference)
end

"""
Fixed site parameters needed by the historical MAESPA solar routines.

`reference_astronomical_day=nothing` follows the current astronomical day.
Supplying an integer fixes the `SUN`/`ZENAZ` geometry to that day (KEEPZEN),
without fixing the current day-of-year used for extraterrestrial irradiance.
"""
struct SolarGeometryConfig{T<:AbstractFloat}
    latitude_rad::T
    time_difference_steps::T
    scene_bearing_rad::T
    steps_per_day::Int
    solar_constant::T
    reference_astronomical_day::Union{Nothing,Int}

    function SolarGeometryConfig(
        latitude_rad::T,
        time_difference_steps::T,
        scene_bearing_rad::T,
        steps_per_day::Integer,
        solar_constant::T;
        reference_astronomical_day=nothing,
    ) where {T<:AbstractFloat}
        steps_per_day > 0 || throw(ArgumentError("steps_per_day must be positive"))
        return new{T}(
            latitude_rad,
            time_difference_steps,
            scene_bearing_rad,
            Int(steps_per_day),
            solar_constant,
            _solar_reference_astronomical_day(reference_astronomical_day),
        )
    end
end

function SolarGeometryConfig(
    latitude_rad::T,
    time_difference_steps::T,
    scene_bearing_rad::T,
    steps_per_day::Integer;
    solar_constant=convert(T, 1370),
    reference_astronomical_day=nothing,
) where {T<:AbstractFloat}
    return SolarGeometryConfig(
        latitude_rad,
        time_difference_steps,
        scene_bearing_rad,
        steps_per_day,
        convert(T, solar_constant);
        reference_astronomical_day,
    )
end

function SolarGeometryConfig(
    latitude_rad::Real,
    time_difference_steps::Real,
    scene_bearing_rad::Real,
    steps_per_day::Integer;
    solar_constant::Real=1370,
    reference_astronomical_day=nothing,
)
    numeric_values = (
        latitude_rad,
        time_difference_steps,
        scene_bearing_rad,
        solar_constant,
    )
    any(value -> value isa Bool, numeric_values) && throw(
        ArgumentError("solar geometry parameters must be numeric values, not Bool"),
    )
    promoted = promote(float.(numeric_values)...)
    return SolarGeometryConfig(
        promoted[1], promoted[2], promoted[3], steps_per_day, promoted[4];
        reference_astronomical_day,
    )
end

"""Daily outputs of the historical `SUN` and `ZENAZ` routines."""
struct SolarDayGeometry{T<:AbstractFloat}
    solar_declination_rad::T
    equation_of_time_steps::T
    day_length_steps::T
    sunrise_step::T
    sunset_step::T
    sun_zenith_rad::Vector{T}
    sun_azimuth_scene_rad::Vector{T}
end

"""Historical MAESPA solar geometry, optionally fixed to a reference day."""
struct MAESPASolarGeometry{T<:AbstractFloat} <: AbstractSolar_GeometryModel
    latitude_rad::T
    time_difference_steps::T
    scene_bearing_rad::T
    steps_per_day::Int
    solar_constant::T
    reference_astronomical_day::Union{Nothing,Int}

    # Keep the original explicit MAESPASolarGeometry{T}(five arguments) form,
    # including its conversion of numeric parameters to the requested T.
    function MAESPASolarGeometry{T}(
        latitude_rad,
        time_difference_steps,
        scene_bearing_rad,
        steps_per_day,
        solar_constant;
        reference_astronomical_day=nothing,
    ) where {T<:AbstractFloat}
        return new{T}(
            latitude_rad,
            time_difference_steps,
            scene_bearing_rad,
            steps_per_day,
            solar_constant,
            _solar_reference_astronomical_day(reference_astronomical_day),
        )
    end
end

# Preserve the original inferred-T, five-positional-argument model constructor.
function MAESPASolarGeometry(
    latitude_rad::T,
    time_difference_steps::T,
    scene_bearing_rad::T,
    steps_per_day::Int,
    solar_constant::T;
    reference_astronomical_day=nothing,
) where {T<:AbstractFloat}
    return MAESPASolarGeometry{T}(
        latitude_rad,
        time_difference_steps,
        scene_bearing_rad,
        steps_per_day,
        solar_constant;
        reference_astronomical_day,
    )
end

MAESPASolarGeometry(config::SolarGeometryConfig{T}) where {T} = MAESPASolarGeometry{T}(
    config.latitude_rad,
    config.time_difference_steps,
    config.scene_bearing_rad,
    config.steps_per_day,
    config.solar_constant;
    reference_astronomical_day=config.reference_astronomical_day,
)

PlantSimEngine.inputs_(::MAESPASolarGeometry) = (
    astronomical_day=PlantSimEngine.Required(Integer),
    legacy_day_of_year=PlantSimEngine.Required(Integer),
    step_index=PlantSimEngine.Required(Integer),
)

PlantSimEngine.outputs_(model::MAESPASolarGeometry) = (
    solar_declination_rad=zero(model.latitude_rad),
    equation_of_time_steps=zero(model.latitude_rad),
    day_length_steps=zero(model.latitude_rad),
    sunrise_step=zero(model.latitude_rad),
    sunset_step=zero(model.latitude_rad),
    sun_zenith_rad=zero(model.latitude_rad),
    sun_elevation_rad=zero(model.latitude_rad),
    sun_azimuth_scene_rad=zero(model.latitude_rad),
    extraterrestrial_irradiance=zero(model.latitude_rad),
    astronomical_daylight=false,
)

_as(::Type{T}, value) where {T} = convert(T, value)

function _solar_orbit(astronomical_day::Integer, ::Type{T}) where {T<:AbstractFloat}
    one_t = one(T)
    pi_t = _as(T, π)
    two_pi = _as(T, 2) * pi_t
    day = _as(T, astronomical_day)
    time = day / _as(T, 36525)

    eccentricity = _as(T, 0.01675104) -
                   (_as(T, 4.08e-5) + _as(T, 1.26e-7) * time) * time
    mean_anomaly = -_as(T, 1.52417) +
                   (_as(T, 1.5e-4) + _as(T, 3.0e-6) * time) * time * time
    mean_anomaly += _as(T, 0.98560) * day
    mean_anomaly > _as(T, 360) &&
        (mean_anomaly -= _as(T, 360) * trunc(mean_anomaly / _as(T, 360)))
    mean_anomaly *= pi_t / _as(T, 180)

    eccentric_anomaly = mean_anomaly
    for _ in 1:3
        eccentric_anomaly += (
            mean_anomaly -
            (eccentric_anomaly - eccentricity * sin(eccentric_anomaly))
        ) / (one_t - eccentricity * cos(eccentric_anomaly))
    end
    true_anomaly = _as(T, 2) * atan(
        sqrt((one_t + eccentricity) / (one_t - eccentricity)) *
        tan(_as(T, 0.5) * eccentric_anomaly),
    )
    true_anomaly < zero(T) && (true_anomaly += two_pi)

    obliquity = (
        _as(T, 23.452294) -
        (
            _as(T, 1.30125e-2) +
            (_as(T, 1.64e-6) - _as(T, 5.03e-7) * time) * time
        ) * time
    ) * pi_t / _as(T, 180)
    perihelion = (
        _as(T, 281.22083) +
        (_as(T, 4.53e-4) + _as(T, 3.0e-6) * time) * time * time +
        _as(T, 4.70684e-5) * day
    ) * pi_t / _as(T, 180)
    lunar_longitude = (
        _as(T, 259.1833) +
        (_as(T, 2.078e-3) + _as(T, 2.0e-6) * time) * time * time -
        _as(T, 0.05295) * day
    ) * pi_t / _as(T, 180)
    nutation_obliquity = (
        _as(T, 2.5583e-3) + _as(T, 2.5e-7) * time
    ) * cos(lunar_longitude) * pi_t / _as(T, 180)
    obliquity += nutation_obliquity
    nutation_longitude = -(
        _as(T, 4.7872e-3) + _as(T, 4.7222e-6) * time
    ) * sin(lunar_longitude) * pi_t / _as(T, 180)

    declination = asin(sin(obliquity) * sin(true_anomaly + perihelion))
    mean_longitude = perihelion + mean_anomaly
    mean_longitude < zero(T) && (mean_longitude += two_pi)
    mean_longitude > two_pi &&
        (mean_longitude -= two_pi * trunc(mean_longitude / two_pi))

    y = tan(_as(T, 0.5) * obliquity)^2
    y = (one_t - y) / (one_t + y)
    solar_longitude = perihelion + nutation_longitude + true_anomaly
    solar_longitude < zero(T) && (solar_longitude += two_pi)
    solar_longitude > two_pi &&
        (solar_longitude -= two_pi * trunc(solar_longitude / two_pi))
    apparent_longitude = atan(y * tan(solar_longitude))
    equation_of_time = apparent_longitude - mean_longitude
    equation_of_time -= pi_t * trunc(equation_of_time / pi_t)
    if abs(equation_of_time) > _as(T, 0.9) * pi_t
        equation_of_time -= pi_t * equation_of_time / abs(equation_of_time)
    end
    return declination, equation_of_time
end

"""
    solar_day_geometry(model, astronomical_day)

Reproduce the historical daily `SUN` and whole-day `ZENAZ` calculations in the
model's parameter type. A configured reference day fixes geometry only. All
times are expressed in simulation steps, not clock hours.
"""
function solar_day_geometry(
    model::MAESPASolarGeometry{T},
    astronomical_day::Integer,
) where {T<:AbstractFloat}
    return _solar_day_geometry(model, astronomical_day, T)
end

function _solar_day_geometry(
    model::MAESPASolarGeometry,
    astronomical_day::Integer,
    ::Type{T},
) where {T<:AbstractFloat}
    # Direct helpers use parameter T; PSE supplies the status numeric type.
    # Convert the site before equations, rather than casting their results.
    latitude_rad = _as(T, model.latitude_rad)
    time_difference_steps = _as(T, model.time_difference_steps)
    scene_bearing_rad = _as(T, model.scene_bearing_rad)
    geometry_day = isnothing(model.reference_astronomical_day) ?
                   astronomical_day : model.reference_astronomical_day
    pi_t = _as(T, π)
    half_steps = _as(T, model.steps_per_day) / _as(T, 2)
    declination, equation_of_time_rad = _solar_orbit(geometry_day, T)

    maximum_cosine = cos(latitude_rad - declination)
    minimum_cosine = -cos(latitude_rad + declination)
    horizon_cosine = zero(T)
    refraction = zero(T)
    product = -maximum_cosine * minimum_cosine
    product > zero(T) && (refraction = _as(T, 0.05556) / sqrt(product))
    minimum_cosine > horizon_cosine && (horizon_cosine = minimum_cosine)
    maximum_cosine > horizon_cosine || throw(
        DomainError(latitude_rad, "historical SUN routine has no sunrise solution"),
    )

    daylight_fraction = sqrt(
        (horizon_cosine - minimum_cosine) /
        (maximum_cosine - horizon_cosine),
    )
    daylight_fraction = one(T) - _as(T, 2) * atan(daylight_fraction) / pi_t
    sunset = half_steps * daylight_fraction
    sunrise = sunset
    sunset += refraction + equation_of_time_rad * half_steps / pi_t
    sunrise += refraction - equation_of_time_rad * half_steps / pi_t
    sunset += half_steps + time_difference_steps
    sunrise = half_steps - sunrise + time_difference_steps
    equation_of_time_steps = equation_of_time_rad * half_steps / pi_t
    day_length = sunset - sunrise

    zenith = Vector{T}(undef, model.steps_per_day)
    azimuth = Vector{T}(undef, model.steps_per_day)
    for step in eachindex(zenith)
        midpoint = _as(T, step) - _as(T, 0.5)
        hour_angle = (
            midpoint - time_difference_steps - equation_of_time_steps - half_steps
        ) * pi_t / half_steps
        cosine_zenith =
            sin(latitude_rad) * sin(declination) +
            cos(latitude_rad) * cos(declination) * cos(hour_angle)
        zenith[step] = acos(clamp(cosine_zenith, -one(T), one(T)))
        sine_azimuth = cos(declination) * sin(hour_angle) / sin(zenith[step])
        azimuth[step] = asin(clamp(sine_azimuth, -one(T), one(T)))
    end

    # Keep the sequential quadrant correction used by ZENAZ. The final extra
    # value is never needed for ordinary non-polar days because the last step
    # is at night; reusing the final raw value avoids uninitialised memory.
    for step in eachindex(zenith)
        if abs(zenith[step]) <= _as(T, 1.57)
            current = azimuth[step]
            next_value = step < length(azimuth) ? azimuth[step + 1] : current
            if current >= zero(T)
                if next_value < current && step < length(azimuth)
                    azimuth[step + 1] = pi_t - next_value
                end
            elseif current >= next_value
                azimuth[step] = -pi_t - current
            end
            if latitude_rad < zero(T)
                azimuth[step] += pi_t + scene_bearing_rad
            else
                azimuth[step] = -azimuth[step] + scene_bearing_rad
            end
        end
    end

    return SolarDayGeometry(
        declination,
        equation_of_time_steps,
        day_length,
        sunrise,
        sunset,
        zenith,
        azimuth,
    )
end

"""Return selected-step solar outputs in the model's parameter type."""
function solar_geometry(
    model::MAESPASolarGeometry{T},
    astronomical_day::Integer,
    legacy_day_of_year::Integer,
    step_index::Integer,
) where {T<:AbstractFloat}
    return _solar_geometry(model, astronomical_day, legacy_day_of_year, step_index, T)
end

function _solar_geometry(
    model::MAESPASolarGeometry,
    astronomical_day::Integer,
    legacy_day_of_year::Integer,
    step_index::Integer,
    ::Type{T},
) where {T<:AbstractFloat}
    1 <= step_index <= model.steps_per_day || throw(
        BoundsError(1:model.steps_per_day, step_index),
    )
    daily = _solar_day_geometry(model, astronomical_day, T)
    zenith = daily.sun_zenith_rad[step_index]
    elevation = _as(T, π / 2) - zenith
    sine_elevation = max(sin(elevation), zero(T))
    # KEEPZEN fixes elevation, not ETRAD's current seasonal Earth-Sun term.
    extraterrestrial = _as(T, model.solar_constant) * (
        one(T) +
        _as(T, 0.033) * cos(
            _as(T, legacy_day_of_year) / _as(T, 365) * _as(T, 2π),
        )
    ) * sine_elevation
    return (
        solar_declination_rad=daily.solar_declination_rad,
        equation_of_time_steps=daily.equation_of_time_steps,
        day_length_steps=daily.day_length_steps,
        sunrise_step=daily.sunrise_step,
        sunset_step=daily.sunset_step,
        sun_zenith_rad=zenith,
        sun_elevation_rad=elevation,
        sun_azimuth_scene_rad=daily.sun_azimuth_scene_rad[step_index],
        extraterrestrial_irradiance=extraterrestrial,
        astronomical_daylight=abs(zenith) < _as(T, π / 2),
    )
end

function PlantSimEngine.run!(
    model::MAESPASolarGeometry,
    status,
    environment,
    constants,
    context,
)
    result = _solar_geometry(
        model,
        status.astronomical_day,
        status.legacy_day_of_year,
        status.step_index,
        typeof(status.sun_zenith_rad),
    )
    for name in keys(result)
        setproperty!(status, name, getproperty(result, name))
    end
    return nothing
end
