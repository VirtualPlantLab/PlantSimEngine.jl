"""
    SoilDrainageResult{T}

Fluxes diagnosed by [`soil_gravitational_drainage`](@ref), expressed as metres
of water per square metre of ground. Arrays are ordered by the canonical
one-based soil-layer index, independently of the input object order.

`vertical_transfer_m[i]` crosses the lower boundary of layer `i`, while
`lateral_drainage_m[i]` leaves the soil column from that layer. Internal
vertical transfers are also exposed as `represented_layer_gain_m` so the result
can be passed directly to [`apply_soil_water_fluxes`](@ref), together with
`layer_loss_m`.

`legacy_discharge_m` reproduces the historical MAESPA diagnostic: deep
vertical drainage without a water table, but only lateral drainage when a
water table is active. `total_boundary_outflow_m` is the complete outflow from
the active unsaturated domain and therefore also includes vertical transfer to
the water-table boundary.
"""
struct SoilDrainageResult{T<:AbstractFloat}
    vertical_transfer_m::Vector{T}
    lateral_drainage_m::Vector{T}
    represented_layer_gain_m::Vector{T}
    layer_loss_m::Vector{T}
    deep_drainage_m::T
    water_table_boundary_drainage_m::T
    lateral_discharge_m::T
    legacy_discharge_m::T
    total_boundary_outflow_m::T
    accepted_steps::Vector{Int}
    rejected_steps::Vector{Int}
    converged::Bool
end

"""Raised when the historical adaptive Cash--Karp integration cannot finish."""
struct SoilDrainageConvergenceError{T<:AbstractFloat} <: Exception
    layer_index::Int
    normalized_time::T
    water_content::T
    attempted_steps::Int
end

function _soil_drainage_primary_type(water_content::AbstractVector)
    T = eltype(water_content)
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "water_content must have a concrete AbstractFloat element type",
        ),
    )
    return T
end

function Base.showerror(io::IO, error::SoilDrainageConvergenceError)
    print(
        io,
        "soil drainage failed to converge for layer ",
        error.layer_index,
        " after ",
        error.attempted_steps,
        " attempted Cash-Karp steps (normalized_time=",
        error.normalized_time,
        ", water_content=",
        error.water_content,
        ")",
    )
end

function _soil_drainage_scalar(
    ::Type{T},
    value,
    name::AbstractString,
) where {T<:AbstractFloat}
    value isa Real && !(value isa Bool) || throw(
        ArgumentError("$name must be a real number, not Bool"),
    )
    converted = convert(T, value)
    isfinite(converted) || throw(ArgumentError("$name must be finite"))
    return converted
end

function _soil_drainage_vector(
    ::Type{T},
    values,
    layer_count::Int,
    name::AbstractString;
    default_zero::Bool=false,
) where {T<:AbstractFloat}
    if isnothing(values)
        default_zero || throw(ArgumentError("missing required $name"))
        return zeros(T, layer_count)
    end
    values isa AbstractVector || throw(
        ArgumentError("$name must be an AbstractVector"),
    )
    length(values) == layer_count || throw(
        DimensionMismatch("$name must contain $layer_count layer values"),
    )
    converted = Vector{T}(undef, layer_count)
    for position in eachindex(values)
        converted[position] = _soil_drainage_scalar(
            T,
            values[position],
            "$name[$position]",
        )
    end
    return converted
end

function _soil_drainage_ordered_vector(
    ::Type{T},
    layer_indices::AbstractVector,
    values,
    layer_count::Int,
    name::AbstractString,
) where {T<:AbstractFloat}
    length(layer_indices) == layer_count || throw(
        DimensionMismatch("layer_indices must contain $layer_count values"),
    )
    unordered = _soil_drainage_vector(T, values, layer_count, name)
    ordered = Vector{T}(undef, layer_count)
    seen = falses(layer_count)
    for position in eachindex(layer_indices, unordered)
        raw_index = layer_indices[position]
        raw_index isa Integer && !(raw_index isa Bool) || throw(
            ArgumentError("layer_indices[$position] must be an integer, not Bool"),
        )
        layer_index = try
            Int(raw_index)
        catch exception
            exception isa InexactError || rethrow()
            throw(
                ArgumentError(
                    "layer_indices[$position] must be representable as Int",
                ),
            )
        end
        1 <= layer_index <= layer_count || throw(
            ArgumentError(
                "layer_indices[$position] must lie in 1:$layer_count",
            ),
        )
        seen[layer_index] && throw(
            ArgumentError("layer index $layer_index occurs more than once"),
        )
        ordered[layer_index] = unordered[position]
        seen[layer_index] = true
    end
    all(seen) || throw(
        ArgumentError("layer_indices must contain every index in 1:$layer_count"),
    )
    return ordered
end

function _soil_drainage_layer_parameter(
    ::Type{T},
    layer_indices::AbstractVector,
    values,
    layer_count::Int,
    name::AbstractString,
) where {T<:AbstractFloat}
    values isa AbstractVector && return _soil_drainage_ordered_vector(
        T,
        layer_indices,
        values,
        layer_count,
        name,
    )
    return fill(_soil_drainage_scalar(T, values, name), layer_count)
end

function _soil_drainage_optional_model_vector(
    ::Type{T},
    values,
    layer_count::Int,
    name::AbstractString,
) where {T<:AbstractFloat}
    isnothing(values) && return nothing
    return _soil_drainage_vector(T, values, layer_count, name)
end

function _soil_drainage_model(
    ::Type{T},
    model::MAESPASoilHydraulicProperties,
) where {T<:AbstractFloat}
    layer_count = model.layer_count
    return MAESPASoilHydraulicProperties{T}(
        layer_count,
        _soil_drainage_vector(
            T,
            model.thickness_m,
            layer_count,
            "model thickness_m",
        ),
        _soil_drainage_vector(
            T,
            model.pore_fraction,
            layer_count,
            "model pore_fraction",
        ),
        model.method,
        _soil_drainage_optional_model_vector(
            T,
            model.b_parameter,
            layer_count,
            "model b_parameter",
        ),
        _soil_drainage_optional_model_vector(
            T,
            model.air_entry_water_potential_mpa,
            layer_count,
            "model air_entry_water_potential_mpa",
        ),
        _soil_drainage_vector(
            T,
            model.saturated_hydraulic_conductivity_m_s,
            layer_count,
            "model saturated_hydraulic_conductivity_m_s",
        ),
        _soil_drainage_optional_model_vector(
            T,
            model.alpha_mpa_inverse,
            layer_count,
            "model alpha_mpa_inverse",
        ),
        _soil_drainage_optional_model_vector(
            T,
            model.saturated_water_content,
            layer_count,
            "model saturated_water_content",
        ),
        _soil_drainage_optional_model_vector(
            T,
            model.residual_water_content,
            layer_count,
            "model residual_water_content",
        ),
        _soil_drainage_optional_model_vector(
            T,
            model.shape_parameter_n,
            layer_count,
            "model shape_parameter_n",
        ),
    )
end

function _soil_drainage_water_table_layer(value, layer_count::Int)
    isnothing(value) && return nothing
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError("water_table_layer must be an integer, not Bool"),
    )
    layer = try
        Int(value)
    catch exception
        exception isa InexactError || rethrow()
        throw(ArgumentError("water_table_layer must be representable as Int"))
    end
    2 <= layer <= layer_count + 1 || throw(
        ArgumentError("water_table_layer must lie in 2:$(layer_count + 1)"),
    )
    return layer
end

function _soil_drainage_positive_integer(value, name::AbstractString)
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError("$name must be an integer, not Bool"),
    )
    converted = try
        Int(value)
    catch exception
        exception isa InexactError || rethrow()
        throw(ArgumentError("$name must be representable as Int"))
    end
    converted > 0 || throw(ArgumentError("$name must be positive"))
    return converted
end

function _soil_drainage_conductivity(
    model::MAESPASoilHydraulicProperties{T},
    layer_index::Int,
    water_content::T,
) where {T<:AbstractFloat}
    return _soil_hydraulic_conductivity_result(
        water_content,
        model.method;
        saturated_hydraulic_conductivity_m_s=
            model.saturated_hydraulic_conductivity_m_s[layer_index],
        pore_fraction=model.pore_fraction[layer_index],
        b_parameter=isnothing(model.b_parameter) ?
                    nothing : model.b_parameter[layer_index],
        saturated_water_content=isnothing(model.saturated_water_content) ?
                                  nothing : model.saturated_water_content[layer_index],
        residual_water_content=isnothing(model.residual_water_content) ?
                                 nothing : model.residual_water_content[layer_index],
        shape_parameter_n=isnothing(model.shape_parameter_n) ?
                          nothing : model.shape_parameter_n[layer_index],
    ).value
end

function _soil_drainage_rate(
    water_content::T,
    model::MAESPASoilHydraulicProperties{T},
    layer_index::Int,
    timestep_seconds::T,
    drainage_threshold::T,
    initial_liquid_fraction::T,
    receiving_capacity_fraction::T,
    plateau_fraction::T,
) where {T<:AbstractFloat}
    water_content <= drainage_threshold && return zero(T)
    conductivity = _soil_drainage_conductivity(
        model,
        layer_index,
        water_content,
    )
    potential_drainage =
        conductivity * timestep_seconds * (one(T) - plateau_fraction)
    return -min(
        potential_drainage,
        initial_liquid_fraction,
        receiving_capacity_fraction,
    )
end

function _soil_drainage_cash_karp_step(
    rate,
    water_content::T,
    derivative::T,
    h::T,
) where {T<:AbstractFloat}
    b21 = T(1) / T(5)
    b31 = T(3) / T(40)
    b32 = T(9) / T(40)
    b41 = T(3) / T(10)
    b42 = -T(9) / T(10)
    b43 = T(6) / T(5)
    b51 = -T(11) / T(54)
    b52 = T(5) / T(2)
    b53 = -T(70) / T(27)
    b54 = T(35) / T(27)
    b61 = T(1631) / T(55296)
    b62 = T(175) / T(512)
    b63 = T(575) / T(13824)
    b64 = T(44275) / T(110592)
    b65 = T(253) / T(4096)
    c1 = T(37) / T(378)
    c3 = T(250) / T(621)
    c4 = T(125) / T(594)
    c6 = T(512) / T(1771)
    dc1 = c1 - T(2825) / T(27648)
    dc3 = c3 - T(18575) / T(48384)
    dc4 = c4 - T(13525) / T(55296)
    dc5 = -T(277) / T(14336)
    dc6 = c6 - T(1) / T(4)

    k2 = rate(water_content + h * b21 * derivative)
    k3 = rate(water_content + h * (b31 * derivative + b32 * k2))
    k4 = rate(
        water_content + h * (b41 * derivative + b42 * k2 + b43 * k3),
    )
    k5 = rate(
        water_content +
        h * (b51 * derivative + b52 * k2 + b53 * k3 + b54 * k4),
    )
    k6 = rate(
        water_content +
        h * (b61 * derivative + b62 * k2 + b63 * k3 + b64 * k4 + b65 * k5),
    )
    output = water_content +
             h * (c1 * derivative + c3 * k3 + c4 * k4 + c6 * k6)
    error = h *
            (dc1 * derivative + dc3 * k3 + dc4 * k4 + dc5 * k5 + dc6 * k6)
    return output, error
end

function _soil_drainage_integrate(
    rate,
    initial_water_content::T,
    layer_index::Int;
    relative_tolerance::T,
    initial_step::T,
    max_steps::Int,
) where {T<:AbstractFloat}
    normalized_time = one(T)
    end_time = T(2)
    step = initial_step
    accepted_steps = 0
    rejected_steps = 0
    attempted_steps = 0
    water_content = initial_water_content

    safety = T(9) / T(10)
    growth_power = -T(1) / T(5)
    shrink_power = -T(1) / T(4)
    error_control = T(189) / T(1_000_000)
    scaling_floor = T(5) / T(10_000_000)

    while normalized_time < end_time
        step = min(step, end_time - normalized_time)
        derivative = rate(water_content)
        scale = abs(water_content) + abs(step * derivative)
        trial_step = step

        while true
            attempted_steps < max_steps || throw(
                SoilDrainageConvergenceError{T}(
                    layer_index,
                    normalized_time,
                    water_content,
                    attempted_steps,
                ),
            )
            attempted_steps += 1
            trial_water, estimated_error = _soil_drainage_cash_karp_step(
                rate,
                water_content,
                derivative,
                trial_step,
            )
            isfinite(trial_water) && isfinite(estimated_error) || throw(
                SoilDrainageConvergenceError{T}(
                    layer_index,
                    normalized_time,
                    water_content,
                    attempted_steps,
                ),
            )
            relative_error = if scale < scaling_floor
                zero(T)
            else
                abs(estimated_error / scale) / relative_tolerance
            end

            if relative_error <= one(T)
                water_content = trial_water
                normalized_time += trial_step
                accepted_steps += 1
                step = relative_error > error_control ?
                       safety * trial_step * relative_error^growth_power :
                       T(5) * trial_step
                break
            end

            rejected_steps += 1
            proposed_step =
                safety * trial_step * relative_error^shrink_power
            trial_step = max(proposed_step, trial_step / T(10))
            normalized_time + trial_step > normalized_time || throw(
                SoilDrainageConvergenceError{T}(
                    layer_index,
                    normalized_time,
                    water_content,
                    attempted_steps,
                ),
            )
        end
    end
    return water_content, accepted_steps, rejected_steps
end

"""
    soil_gravitational_drainage(model, layer_indices, water_content,
                                ice_fraction; drainage_limit,
                                plateau_drainage, timestep_seconds,
                                water_table_layer=nothing,
                                capillary_gain_m=nothing,
                                bottom_water_content=nothing,
                                relative_tolerance=1e-4,
                                initial_step=1e-3,
                                max_steps=10_000)

Compute one MAESPA gravitational-drainage step without mutating soil state.
The scalar ODE for each active unsaturated layer is integrated with the
historical Cash--Karp coefficients. Conductivity comes from `model`, so the two
Campbell choices and the legacy van Genuchten conductivity remain available.
The concrete element type of `water_content` controls the whole calculation
and result. Model parameters are copied and converted to that type once before
integration, allowing PlantSimEngine-promoted statuses to set numeric precision
independently of the model's construction type.

The receiving layer limits vertical drainage by its initial empty pore volume.
`drainage_limit` may be one fraction shared by all layers or a vector aligned
with `layer_indices`, matching the per-layer values accepted by MAESPA input.
The plateau fraction diverts conductivity to lateral drainage only for layers
below layer 1 whose receiver is within `0.005` volumetric units of porosity.
At the drainage threshold, drainage is zero. A positive capillary gain for a
source layer suppresses its vertical drainage, as in MAESPA, but deliberately
does not suppress the separately diagnosed lateral loss. Unlike state vectors,
`capillary_gain_m` is always indexed in canonical layer order `1:n`; this is
the order published by `soil_capillary_fluxes`, independently of
`layer_indices` object order.

When `bottom_water_content` is omitted, the last represented water content is
copied to the unrepresented lower boundary, reproducing MAESPA's initialized
core-layer boundary for a single call. If the water table is exactly at
`NLAYER + 1`, the boundary instead uses the model's final saturated water
content, matching the forced `WS` assignment in `WATBALLAY`; that value or an
explicit boundary is therefore required. A caller that advances several steps
without a water table and needs exact legacy core behaviour should retain and
pass the boundary value explicitly on subsequent calls.
"""
function soil_gravitational_drainage(
    model::MAESPASoilHydraulicProperties,
    layer_indices::AbstractVector,
    water_content::AbstractVector,
    ice_fraction::AbstractVector;
    drainage_limit,
    plateau_drainage,
    timestep_seconds,
    water_table_layer=nothing,
    capillary_gain_m=nothing,
    bottom_water_content=nothing,
    relative_tolerance=nothing,
    initial_step=nothing,
    max_steps=10_000,
)
    T = _soil_drainage_primary_type(water_content)
    hydraulic_model = _soil_drainage_model(T, model)
    layer_count = hydraulic_model.layer_count
    layer_count > 0 || throw(
        ArgumentError("a soil profile must contain at least one layer"),
    )
    length(model.thickness_m) == layer_count || throw(
        DimensionMismatch("model thickness_m does not match layer_count"),
    )
    length(model.pore_fraction) == layer_count || throw(
        DimensionMismatch("model pore_fraction does not match layer_count"),
    )

    water = _soil_drainage_ordered_vector(
        T,
        layer_indices,
        water_content,
        layer_count,
        "water_content",
    )
    ice = _soil_drainage_ordered_vector(
        T,
        layer_indices,
        ice_fraction,
        layer_count,
        "ice_fraction",
    )
    capillary = _soil_drainage_vector(
        T,
        isnothing(capillary_gain_m) ? zeros(T, layer_count) : capillary_gain_m,
        layer_count,
        "capillary_gain_m",
    )
    for layer_index in 1:layer_count
        zero(T) <= water[layer_index] <= one(T) || throw(
            DomainError(
                water[layer_index],
                "water_content for layer $layer_index must lie in [0, 1]",
            ),
        )
        zero(T) <= ice[layer_index] <= one(T) || throw(
            DomainError(
                ice[layer_index],
                "ice_fraction for layer $layer_index must lie in [0, 1]",
            ),
        )
        capillary[layer_index] >= zero(T) || throw(
            DomainError(
                capillary[layer_index],
                "capillary_gain_m for layer $layer_index must be non-negative",
            ),
        )
    end

    limits = _soil_drainage_layer_parameter(
        T,
        layer_indices,
        drainage_limit,
        layer_count,
        "drainage_limit",
    )
    for layer_index in 1:layer_count
        zero(T) <= limits[layer_index] <= one(T) || throw(
            DomainError(
                limits[layer_index],
                "drainage_limit for layer $layer_index must lie in [0, 1]",
            ),
        )
    end
    plateau = _soil_drainage_scalar(T, plateau_drainage, "plateau_drainage")
    zero(T) <= plateau <= one(T) || throw(
        DomainError(plateau, "plateau_drainage must lie in [0, 1]"),
    )
    timestep = _soil_drainage_scalar(T, timestep_seconds, "timestep_seconds")
    timestep >= zero(T) || throw(
        DomainError(timestep, "timestep_seconds must be non-negative"),
    )
    tolerance = isnothing(relative_tolerance) ? T(1) / T(10_000) :
                _soil_drainage_scalar(
        T,
        relative_tolerance,
        "relative_tolerance",
    )
    tolerance > zero(T) || throw(
        DomainError(tolerance, "relative_tolerance must be positive"),
    )
    starting_step = isnothing(initial_step) ? T(1) / T(1_000) :
                    _soil_drainage_scalar(T, initial_step, "initial_step")
    starting_step > zero(T) || throw(
        DomainError(starting_step, "initial_step must be positive"),
    )
    step_limit = _soil_drainage_positive_integer(max_steps, "max_steps")
    table_layer =
        _soil_drainage_water_table_layer(water_table_layer, layer_count)
    bottom_water = if !isnothing(bottom_water_content)
        _soil_drainage_scalar(T, bottom_water_content, "bottom_water_content")
    elseif table_layer == layer_count + 1
        isnothing(hydraulic_model.saturated_water_content) && throw(
            ArgumentError(
                "saturated_water_content or bottom_water_content is required " *
                "when the water table is immediately below the represented profile",
            ),
        )
        hydraulic_model.saturated_water_content[end]
    else
        water[end]
    end
    zero(T) <= bottom_water <= one(T) || throw(
        DomainError(
            bottom_water,
            "bottom_water_content must lie in [0, 1]",
        ),
    )

    vertical = zeros(T, layer_count)
    lateral = zeros(T, layer_count)
    represented_gain = zeros(T, layer_count)
    losses = zeros(T, layer_count)
    accepted = zeros(Int, layer_count)
    rejected = zeros(Int, layer_count)
    active_last = isnothing(table_layer) ? layer_count : table_layer - 1

    if !iszero(timestep)
        for layer_index in 1:active_last
            source_water = water[layer_index]
            source_porosity = hydraulic_model.pore_fraction[layer_index]
            source_thickness = hydraulic_model.thickness_m[layer_index]
            receiver_water = layer_index < layer_count ?
                             water[layer_index + 1] : bottom_water
            receiver_porosity = layer_index < layer_count ?
                                hydraulic_model.pore_fraction[layer_index + 1] :
                                hydraulic_model.pore_fraction[end]
            receiver_thickness = layer_index < layer_count ?
                                 hydraulic_model.thickness_m[layer_index + 1] :
                                 hydraulic_model.thickness_m[end]
            liquid_fraction = source_water * (one(T) - ice[layer_index])
            receiving_capacity = max(
                zero(T),
                (receiver_porosity - receiver_water) *
                receiver_thickness / source_thickness,
            )
            plateau_fraction = if layer_index != 1 &&
                                  receiver_water >=
                                  receiver_porosity - T(5) / T(1_000)
                plateau
            else
                zero(T)
            end
            threshold = limits[layer_index] * source_porosity

            if liquid_fraction > zero(T) && source_water > threshold
                rate = candidate -> _soil_drainage_rate(
                    candidate,
                    hydraulic_model,
                    layer_index,
                    timestep,
                    threshold,
                    liquid_fraction,
                    receiving_capacity,
                    plateau_fraction,
                )
                final_water, accepted_count, rejected_count =
                    _soil_drainage_integrate(
                        rate,
                        source_water,
                        layer_index;
                        relative_tolerance=tolerance,
                        initial_step=starting_step,
                        max_steps=step_limit,
                    )
                accepted[layer_index] = accepted_count
                rejected[layer_index] = rejected_count
                vertical_change =
                    (source_water - final_water) * source_thickness
                vertical[layer_index] = capillary[layer_index] > zero(T) ?
                                        zero(T) : max(zero(T), vertical_change)
                lateral[layer_index] =
                    _soil_drainage_conductivity(
                        hydraulic_model,
                        layer_index,
                        source_water,
                    ) * timestep * plateau_fraction
            end
        end
    end

    for layer_index in 1:layer_count
        losses[layer_index] = vertical[layer_index] + lateral[layer_index]
        if layer_index < layer_count
            represented_gain[layer_index + 1] = vertical[layer_index]
        end
    end

    deep_drainage =
        isnothing(table_layer) ? vertical[end] : zero(T)
    water_table_boundary =
        isnothing(table_layer) ? zero(T) : vertical[active_last]
    lateral_discharge = sum(lateral)
    legacy_discharge = isnothing(table_layer) ?
                       deep_drainage : lateral_discharge
    total_boundary_outflow =
        deep_drainage + water_table_boundary + lateral_discharge
    all(isfinite, vertical) && all(isfinite, lateral) || throw(
        ArgumentError("soil drainage fluxes must be finite"),
    )
    return SoilDrainageResult{T}(
        vertical,
        lateral,
        represented_gain,
        losses,
        deep_drainage,
        water_table_boundary,
        lateral_discharge,
        legacy_discharge,
        total_boundary_outflow,
        accepted,
        rejected,
        true,
    )
end

function soil_gravitational_drainage(
    model::MAESPASoilHydraulicProperties,
    water_content::AbstractVector,
    ice_fraction::AbstractVector;
    kwargs...,
)
    return soil_gravitational_drainage(
        model,
        collect(1:model.layer_count),
        water_content,
        ice_fraction;
        kwargs...,
    )
end
