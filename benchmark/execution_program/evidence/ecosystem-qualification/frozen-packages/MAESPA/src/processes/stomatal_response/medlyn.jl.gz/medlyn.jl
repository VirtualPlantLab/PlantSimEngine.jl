"""Historical Medlyn response (`MODELGS=4`), parameterized by exponent `GK`."""
struct MAESPAMedlynResponse{T} <: AbstractStomatal_ResponseModel
    vpd_exponent::T

    function MAESPAMedlynResponse(vpd_exponent::Real)
        vpd_exponent isa Bool && throw(ArgumentError("vpd_exponent must be numeric"))
        exponent = float(vpd_exponent)
        isfinite(exponent) || throw(DomainError(exponent, "vpd_exponent must be finite"))
        return new{typeof(exponent)}(exponent)
    end
end

MAESPAMedlynResponse(; vpd_exponent) = MAESPAMedlynResponse(vpd_exponent)

PlantSimEngine.outputs_(model::MAESPAMedlynResponse) = (
    primary_stomatal_response_slope=zero(model.vpd_exponent),
    secondary_stomatal_response_slope=zero(model.vpd_exponent),
)

function PlantSimEngine.run!(model::MAESPAMedlynResponse, status, environment, constants, context)
    Cs = status.surface_co2_umol_mol
    D = max(environment.vapour_pressure_deficit_pa, status.minimum_vpd_pa)
    D_kPa = D / oftype(D, 1000)
    exponent = one(D) - oftype(D, model.vpd_exponent)
    status.primary_stomatal_response_slope = (one(Cs) + status.stomatal_g1 / D_kPa^exponent) / Cs
    status.secondary_stomatal_response_slope = status.second_stomatal_curve ?
        (one(Cs) + status.stomatal_g21 / D_kPa^exponent) / Cs : zero(Cs)
    return nothing
end

PlantSimEngine.Authoring.model_metadata(::MAESPAMedlynResponse) = (
    hypothesis="MAESPA Medlyn response using max(VPD, VPDMIN) and the historical GK exponent.",
    reference="MAESPA physiol.f90, PSTRANSP MODELGS=4",
    maturity=:legacy_reimplementation,
    validation=:legacy_checkpoints_and_structural_tests,
)
PlantSimEngine.Authoring.parameter_metadata(::MAESPAMedlynResponse) = (
    vpd_exponent=(description="Historical GK; the denominator uses VPD^(1-GK).", unit=:dimensionless),
)
