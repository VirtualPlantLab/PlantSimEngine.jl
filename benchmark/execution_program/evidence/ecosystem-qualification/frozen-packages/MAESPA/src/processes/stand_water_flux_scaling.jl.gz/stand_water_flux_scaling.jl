PlantSimEngine.@process "stand_water_flux_scaling" verbose = false

"""
Stand-scale dry transpiration and signed wet-canopy evaporation for one
timestep.

All three outputs are millimetres of water per square metre of ground for the
current timestep. `evapotranspiration_by_species_mm` always has the configured
species count, including zero entries for species absent from the target set.
"""
struct StandWaterFluxScalingResult{T<:AbstractFloat}
    canopy_transpiration_mm_timestep::T
    evapotranspiration_by_species_mm::Vector{T}
    wet_canopy_evaporation_mm_timestep::T
end

@noinline function _throw_stand_water_flux_scaling(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must not be Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :integer
        throw(ArgumentError("$label must be an integer, not Bool"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :species
        throw(DomainError(value, "$label must identify a configured species"))
    elseif reason === :mode
        throw(DomainError(value, "$label must be 0, 1, or 2"))
    elseif reason === :solution
        throw(DomainError(value, "stand water-flux scaling must remain finite"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _stand_water_flux_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real || _throw_stand_water_flux_scaling(name, value, :real)
    value isa Bool && _throw_stand_water_flux_scaling(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_stand_water_flux_scaling(name, converted, :finite)
    return converted
end

@inline function _stand_water_flux_positive(value::T, name::Symbol) where {T}
    value > zero(T) ||
        _throw_stand_water_flux_scaling(name, value, :positive)
    return value
end

@inline function _stand_water_flux_nonnegative(value::T, name::Symbol) where {T}
    value >= zero(T) ||
        _throw_stand_water_flux_scaling(name, value, :nonnegative)
    return value
end

@inline function _stand_water_flux_count(value, name::Symbol)
    value isa Integer && !(value isa Bool) ||
        _throw_stand_water_flux_scaling(name, value, :integer)
    converted = try
        Int(value)
    catch exception
        exception isa InexactError || exception isa OverflowError || rethrow()
        throw(ArgumentError("$(String(name)) must be representable as Int"))
    end
    converted > 0 ||
        _throw_stand_water_flux_scaling(name, converted, :positive)
    return converted
end

@inline function _stand_water_flux_mode(value)
    value isa Integer && !(value isa Bool) ||
        _throw_stand_water_flux_scaling(:use_stand, value, :integer)
    value in (0, 1, 2) ||
        _throw_stand_water_flux_scaling(:use_stand, value, :mode)
    return Int(value)
end

function _stand_water_flux_vector(values, name::Symbol)
    values isa AbstractVector || throw(
        ArgumentError("$(String(name)) must be an AbstractVector"),
    )
    Base.require_one_based_indexing(values)
    return values
end

function _stand_water_flux_target_count(
    target_leaf_area_m2,
    dry_transpiration_crown_umol_h2o_s,
    wet_evaporation_crown_umol_h2o_s,
    target_multiplicities,
    target_species_ids,
    validate_wet_evaporation::Bool,
)
    arrays = (
        (
            _stand_water_flux_vector(target_leaf_area_m2, :target_leaf_area_m2),
            :target_leaf_area_m2,
        ),
        (
            _stand_water_flux_vector(
                dry_transpiration_crown_umol_h2o_s,
                :dry_transpiration_crown_umol_h2o_s,
            ),
            :dry_transpiration_crown_umol_h2o_s,
        ),
        (
            _stand_water_flux_vector(
                target_multiplicities,
                :target_multiplicities,
            ),
            :target_multiplicities,
        ),
        (
            _stand_water_flux_vector(target_species_ids, :target_species_ids),
            :target_species_ids,
        ),
    )
    target_count = length(first(arrays)[1])
    target_count > 0 || throw(
        ArgumentError("at least one target Crown is required"),
    )
    for (values, name) in arrays
        length(values) == target_count || throw(
            DimensionMismatch(
                "$(String(name)) must contain $target_count values",
            ),
        )
    end
    if validate_wet_evaporation
        wet = _stand_water_flux_vector(
            wet_evaporation_crown_umol_h2o_s,
            :wet_evaporation_crown_umol_h2o_s,
        )
        length(wet) == target_count || throw(
            DimensionMismatch(
                "wet_evaporation_crown_umol_h2o_s must contain " *
                "$target_count values",
            ),
        )
    end
    return target_count
end

function _stand_water_flux_mode_one_vector(values, name::Symbol, target_count::Int)
    vector = _stand_water_flux_vector(values, name)
    length(vector) == target_count || throw(
        DimensionMismatch("$(String(name)) must contain $target_count values"),
    )
    return vector
end

function _stand_water_flux_target_daylight(
    values,
    target_count::Int,
    astronomical_daylight::Bool,
)
    isnothing(values) && return nothing, astronomical_daylight
    values isa AbstractVector || throw(
        ArgumentError("target_exchange_daylight must be an AbstractVector"),
    )
    Base.require_one_based_indexing(values)
    isempty(values) && return nothing, astronomical_daylight
    length(values) == target_count || throw(
        DimensionMismatch(
            "target_exchange_daylight must contain $target_count values",
        ),
    )
    any_daylight = false
    for flag in values
        flag isa Bool || throw(
            ArgumentError("target_exchange_daylight values must be Bool"),
        )
        any_daylight |= flag
    end
    return values, any_daylight
end

function _stand_water_flux_shortwave_availability(
    values,
    target_exchange_daylight,
    target_count::Int,
    astronomical_daylight::Bool,
)
    if isnothing(values) || (values isa AbstractVector && isempty(values))
        return isnothing(target_exchange_daylight) ?
               fill(astronomical_daylight, target_count) :
               target_exchange_daylight
    end
    vector = _stand_water_flux_mode_one_vector(
        values,
        :crown_radiation_aggregation_available,
        target_count,
    )
    for flag in vector
        flag isa Bool || throw(
            ArgumentError(
                "crown_radiation_aggregation_available values must be Bool",
            ),
        )
    end
    return vector
end

"""
    stand_water_flux_scaling(T, target_leaf_area_m2,
                             dry_transpiration_crown_umol_h2o_s,
                             wet_evaporation_crown_umol_h2o_s;
                             target_multiplicities, target_species_ids,
                             species_count, water_balance_area_m2,
                             stocking_trees_m2, total_tree_count, stand_lai,
                             timestep_seconds,
                             use_stand, water_molar_mass_g_mol=18)

Reproduce the water-flux part of legacy `SCALEUP` for `USESTAND=0`, `1`, and
`2`.

Mode 0 directly sums the Crown fluxes, including repetitions represented by
`target_multiplicities`, and divides them by `water_balance_area_m2`.

Mode 2 deliberately preserves the historical double leaf-area weighting:
each already Crown-integrated flux is multiplied by that Crown's leaf area,
averaged over the repeated target slots, corrected by the stand-to-target
mean-leaf-area ratio, and finally multiplied by stocking. Species proportions
come from the repeated but otherwise unweighted dry Crown fluxes, as in the
legacy `ETMMSPEC` calculation, and are normalized to the mode-2 total.

Mode 1 reproduces legacy `ETCAN`. Crown `GSCAN` values are in mol CO₂
tree⁻¹ s⁻¹. They are leaf-area averaged over repeated target slots, corrected
by the all-tree to target-tree mean-leaf-area ratio, converted to the stand
water-vapour conductance with `GSV = GSCANAV × 1.57 × stocking`, and combined
with the canopy-atmosphere `GBCANMS1` conductance. The latter is converted from
m s⁻¹ to mol m⁻² s⁻¹ using `pressure / (R × (TAIR + 273.15))`.

The PAR, NIR, and signed thermal Crown totals are expanded with the same target
factor and normalized by `water_balance_area_m2` using the legacy integer
quotient `div(total_tree_count, target_slot_count)`, then summed into net
radiation in W m⁻² ground before the existing thermodynamic and
Penman--Monteith kernels are called. `target_exchange_daylight` carries the
legacy per-target gate already computed by the upstream Crown daylight process
from zenith, incident PAR above 1 W m⁻², and positive target foliage. PAR and
NIR are summed whenever `crown_radiation_aggregation_available` is true; the
daylight gate only permits an unavailable source to be masked. Signed thermal
absorption remains required for every target. When the availability vector is
omitted, the per-target daylight vector, or `astronomical_daylight` when both
are omitted, remains a compatibility fallback. The signed molar water flux is
integrated over the timestep and converted with the water molar mass; negative
dew therefore
remains negative. Species shares use the raw repeated Crown `FH2O` proportions
and a residual correction makes their total equal the ETCAN result when that
raw total is positive. With one configured species, the complete ETCAN result
is assigned to that species. With several species and a zero raw `FH2O` total,
the legacy all-zero species vector is retained instead of inventing a share.
Wet-canopy evaporation uses the same leaf-area weighting as mode 2. This is
an explicit portable definition of the unassigned legacy `EVMM` branch; it
does not replace the ETCAN transpiration result.

Dry Crown transpiration must be non-negative. Wet-canopy evaporation is signed
so condensation remains negative. A target set with zero total leaf area is a
valid finite mode-2 case and returns zeros. Outputs are fresh and use `T`;
numeric type selection is therefore controlled by the caller rather than
hard-coded in the scientific calculation.
"""
function stand_water_flux_scaling(
    ::Type{T},
    target_leaf_area_m2,
    dry_transpiration_crown_umol_h2o_s,
    wet_evaporation_crown_umol_h2o_s;
    target_multiplicities,
    target_species_ids,
    species_count,
    water_balance_area_m2,
    stocking_trees_m2,
    total_tree_count=nothing,
    stand_lai,
    timestep_seconds,
    use_stand,
    water_molar_mass_g_mol=18,
    stomatal_conductance_co2_crown_mol_s=nothing,
    absorbed_par_crown_w=nothing,
    absorbed_nir_crown_w=nothing,
    absorbed_thermal_crown_w=nothing,
    canopy_atmosphere_aerodynamic_conductance_m_s=nothing,
    atmospheric_pressure_pa=nothing,
    air_temperature_c=nothing,
    vapour_pressure_deficit_pa=nothing,
    water_to_co2_conductance_ratio=1.57,
    gas_constant_j_mol_k=8.314,
    kelvin_offset_c=273.15,
    astronomical_daylight=true,
    target_exchange_daylight=nothing,
    crown_radiation_aggregation_available=nothing,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the stand water-flux numeric type must be concrete"),
    )
    mode = _stand_water_flux_mode(use_stand)
    species_number = _stand_water_flux_count(species_count, :species_count)
    target_count = _stand_water_flux_target_count(
        target_leaf_area_m2,
        dry_transpiration_crown_umol_h2o_s,
        wet_evaporation_crown_umol_h2o_s,
        target_multiplicities,
        target_species_ids,
        true,
    )
    area = _stand_water_flux_positive(
        _stand_water_flux_float(
            T,
            water_balance_area_m2,
            :water_balance_area_m2,
        ),
        :water_balance_area_m2,
    )
    stocking = _stand_water_flux_positive(
        _stand_water_flux_float(
            T,
            stocking_trees_m2,
            :stocking_trees_m2,
        ),
        :stocking_trees_m2,
    )
    all_tree_count = if mode == 1
        isnothing(total_tree_count) && throw(
            ArgumentError("total_tree_count is required for USESTAND=1"),
        )
        _stand_water_flux_count(total_tree_count, :total_tree_count)
    else
        0
    end
    astronomical_daylight isa Bool || throw(
        ArgumentError("astronomical_daylight must be Bool"),
    )
    duration = _stand_water_flux_nonnegative(
        _stand_water_flux_float(T, timestep_seconds, :timestep_seconds),
        :timestep_seconds,
    )
    molar_mass = _stand_water_flux_positive(
        _stand_water_flux_float(
            T,
            water_molar_mass_g_mol,
            :water_molar_mass_g_mol,
        ),
        :water_molar_mass_g_mol,
    )
    current_stand_lai = _stand_water_flux_nonnegative(
        _stand_water_flux_float(T, stand_lai, :stand_lai),
        :stand_lai,
    )

    mode_one_gscan = nothing
    mode_one_par = nothing
    mode_one_nir = nothing
    mode_one_thermal = nothing
    mode_one_target_daylight = nothing
    mode_one_shortwave_available = nothing
    if mode == 1
        mode_one_target_daylight, _ =
            _stand_water_flux_target_daylight(
                target_exchange_daylight,
                target_count,
                astronomical_daylight,
            )
        mode_one_shortwave_available =
            _stand_water_flux_shortwave_availability(
                crown_radiation_aggregation_available,
                mode_one_target_daylight,
                target_count,
                astronomical_daylight,
            )
        mode_one_gscan = _stand_water_flux_mode_one_vector(
            stomatal_conductance_co2_crown_mol_s,
            :stomatal_conductance_co2_crown_mol_s,
            target_count,
        )
        if any(mode_one_shortwave_available)
            mode_one_par = _stand_water_flux_mode_one_vector(
                absorbed_par_crown_w,
                :absorbed_par_crown_w,
                target_count,
            )
            mode_one_nir = _stand_water_flux_mode_one_vector(
                absorbed_nir_crown_w,
                :absorbed_nir_crown_w,
                target_count,
            )
        end
        mode_one_thermal = _stand_water_flux_mode_one_vector(
            absorbed_thermal_crown_w,
            :absorbed_thermal_crown_w,
            target_count,
        )
    end

    raw_dry_by_species = zeros(T, species_number)
    raw_dry_total = zero(T)
    raw_wet_total = zero(T)
    weighted_leaf_area = zero(T)
    leaf_weighted_dry_total = zero(T)
    leaf_weighted_wet_total = zero(T)
    leaf_weighted_gscan_total = zero(T)
    raw_absorbed_radiation_w = zero(T)
    target_slot_count = 0

    for target_index in 1:target_count
        multiplicity_value = _stand_water_flux_count(
            target_multiplicities[target_index],
            :target_multiplicities,
        )
        multiplicity = _stand_water_flux_float(
            T,
            multiplicity_value,
            :target_multiplicities,
        )

        species_value = target_species_ids[target_index]
        species_value isa Integer && !(species_value isa Bool) ||
            _throw_stand_water_flux_scaling(
                :target_species_ids,
                species_value,
                :integer,
            )
        species = try
            Int(species_value)
        catch exception
            exception isa InexactError || exception isa OverflowError || rethrow()
            _throw_stand_water_flux_scaling(
                :target_species_ids,
                species_value,
                :species,
            )
        end
        1 <= species <= species_number ||
            _throw_stand_water_flux_scaling(
                :target_species_ids,
                species,
                :species,
            )

        leaf_area = _stand_water_flux_nonnegative(
            _stand_water_flux_float(
                T,
                target_leaf_area_m2[target_index],
                :target_leaf_area_m2,
            ),
            :target_leaf_area_m2,
        )
        dry_flux = _stand_water_flux_nonnegative(
            _stand_water_flux_float(
                T,
                dry_transpiration_crown_umol_h2o_s[target_index],
                :dry_transpiration_crown_umol_h2o_s,
            ),
            :dry_transpiration_crown_umol_h2o_s,
        )
        wet_flux = _stand_water_flux_float(
            T,
            wet_evaporation_crown_umol_h2o_s[target_index],
            :wet_evaporation_crown_umol_h2o_s,
        )

        repeated_dry_flux = multiplicity * dry_flux
        repeated_wet_flux = multiplicity * wet_flux
        repeated_leaf_area = multiplicity * leaf_area
        raw_dry_total += repeated_dry_flux
        raw_wet_total += repeated_wet_flux
        raw_dry_by_species[species] += repeated_dry_flux
        weighted_leaf_area += repeated_leaf_area
        leaf_weighted_dry_total += repeated_leaf_area * dry_flux
        leaf_weighted_wet_total += repeated_leaf_area * wet_flux
        if mode == 1
            target_daylight = isnothing(mode_one_target_daylight) ?
                              astronomical_daylight :
                              mode_one_target_daylight[target_index]
            shortwave_available =
                mode_one_shortwave_available[target_index]
            crown_gscan = _stand_water_flux_nonnegative(
                _stand_water_flux_float(
                    T,
                    mode_one_gscan[target_index],
                    :stomatal_conductance_co2_crown_mol_s,
                ),
                :stomatal_conductance_co2_crown_mol_s,
            )
            crown_par = shortwave_available ? _stand_water_flux_nonnegative(
                _stand_water_flux_float(
                    T,
                    mode_one_par[target_index],
                    :absorbed_par_crown_w,
                ),
                :absorbed_par_crown_w,
            ) : zero(T)
            crown_nir = shortwave_available ? _stand_water_flux_nonnegative(
                _stand_water_flux_float(
                    T,
                    mode_one_nir[target_index],
                    :absorbed_nir_crown_w,
                ),
                :absorbed_nir_crown_w,
            ) : zero(T)
            target_daylight && !shortwave_available && throw(
                ArgumentError(
                    "daylight target Crown shortwave aggregation is unavailable",
                ),
            )
            crown_thermal = _stand_water_flux_float(
                T,
                mode_one_thermal[target_index],
                :absorbed_thermal_crown_w,
            )
            leaf_weighted_gscan_total += repeated_leaf_area * crown_gscan
            raw_absorbed_radiation_w +=
                multiplicity * (crown_par + crown_nir + crown_thermal)
        end
        target_slot_count = Base.checked_add(
            target_slot_count,
            multiplicity_value,
        )
    end

    conversion = duration * T(1.0e-6) * molar_mass * T(1.0e-3)
    canopy_transpiration = zero(T)
    wet_canopy_evaporation = zero(T)
    evapotranspiration_by_species = zeros(T, species_number)

    if mode == 0
        canopy_transpiration = raw_dry_total * conversion / area
        wet_canopy_evaporation = raw_wet_total * conversion / area
        for species in 1:species_number
            evapotranspiration_by_species[species] =
                raw_dry_by_species[species] * conversion / area
        end
    elseif mode == 1
        if !iszero(weighted_leaf_area) && !iszero(current_stand_lai)
            target_leaf_area_mean = weighted_leaf_area / T(target_slot_count)
            all_tree_leaf_area_mean = current_stand_lai / stocking
            correction = all_tree_leaf_area_mean / target_leaf_area_mean
            # The approved portable wet-canopy flux uses mode-2 SCALEUP
            # weighting. Dry transpiration below remains the ETCAN result.
            mean_wet_flux = leaf_weighted_wet_total / weighted_leaf_area
            wet_canopy_evaporation =
                mean_wet_flux * correction * conversion * stocking
            gscan_average =
                leaf_weighted_gscan_total / weighted_leaf_area * correction

            gas_constant = _stand_water_flux_positive(
                _stand_water_flux_float(
                    T,
                    gas_constant_j_mol_k,
                    :gas_constant_j_mol_k,
                ),
                :gas_constant_j_mol_k,
            )
            kelvin_offset = _stand_water_flux_positive(
                _stand_water_flux_float(
                    T,
                    kelvin_offset_c,
                    :kelvin_offset_c,
                ),
                :kelvin_offset_c,
            )
            conductance_ratio = _stand_water_flux_positive(
                _stand_water_flux_float(
                    T,
                    water_to_co2_conductance_ratio,
                    :water_to_co2_conductance_ratio,
                ),
                :water_to_co2_conductance_ratio,
            )
            pressure = _stand_water_flux_positive(
                _stand_water_flux_float(
                    T,
                    atmospheric_pressure_pa,
                    :atmospheric_pressure_pa,
                ),
                :atmospheric_pressure_pa,
            )
            air_temperature = _stand_water_flux_float(
                T,
                air_temperature_c,
                :air_temperature_c,
            )
            temperature_k = air_temperature + kelvin_offset
            temperature_k > zero(T) || _throw_stand_water_flux_scaling(
                :air_temperature_k,
                temperature_k,
                :positive,
            )
            vapour_pressure_deficit = _stand_water_flux_float(
                T,
                vapour_pressure_deficit_pa,
                :vapour_pressure_deficit_pa,
            )
            aerodynamic_conductance_m_s = _stand_water_flux_nonnegative(
                _stand_water_flux_float(
                    T,
                    canopy_atmosphere_aerodynamic_conductance_m_s,
                    :canopy_atmosphere_aerodynamic_conductance_m_s,
                ),
                :canopy_atmosphere_aerodynamic_conductance_m_s,
            )

            molar_air_density = pressure / (gas_constant * temperature_k)
            boundary_conductance =
                aerodynamic_conductance_m_s * molar_air_density
            stomatal_water_conductance =
                gscan_average * conductance_ratio * stocking
            ground_radiation_scale =
                correction * T(div(all_tree_count, target_slot_count)) / area
            net_radiation_ground =
                raw_absorbed_radiation_w * ground_radiation_scale

            water_flux_mol_m2_s = zero(T)
            if boundary_conductance * stomatal_water_conductance > zero(T)
                thermodynamic = _leaf_thermodynamic_forcing(
                    MAESPALeafThermodynamicForcing(T),
                    T,
                    air_temperature,
                )
                total_water_conductance = inv(
                    inv(stomatal_water_conductance) +
                    inv(boundary_conductance),
                )
                penman = _leaf_penman_monteith(
                    MAESPALeafPenmanMonteith(T),
                    T,
                    pressure,
                    thermodynamic.saturation_vapour_pressure_slope_pa_k,
                    thermodynamic.latent_heat_vaporization_j_mol,
                    net_radiation_ground,
                    vapour_pressure_deficit,
                    boundary_conductance,
                    total_water_conductance,
                )
                water_flux_mol_m2_s = penman.water_flux_mol_m2_s
            end
            canopy_transpiration =
                water_flux_mol_m2_s * duration * molar_mass * T(1.0e-3)

            if species_number == 1
                evapotranspiration_by_species[1] = canopy_transpiration
            elseif raw_dry_total > zero(T)
                last_species = findlast(>(zero(T)), raw_dry_by_species)
                remaining = canopy_transpiration
                for species in 1:species_number
                    species == last_species && continue
                    share = canopy_transpiration *
                            raw_dry_by_species[species] / raw_dry_total
                    evapotranspiration_by_species[species] = share
                    remaining -= share
                end
                evapotranspiration_by_species[last_species] = remaining
            end
        end
    elseif !iszero(weighted_leaf_area) && !iszero(current_stand_lai)
        target_leaf_area_mean = weighted_leaf_area / T(target_slot_count)
        all_tree_leaf_area_mean = current_stand_lai / stocking
        correction = all_tree_leaf_area_mean / target_leaf_area_mean
        mean_dry_flux = leaf_weighted_dry_total / weighted_leaf_area
        mean_wet_flux = leaf_weighted_wet_total / weighted_leaf_area
        canopy_transpiration =
            mean_dry_flux * correction * conversion * stocking
        wet_canopy_evaporation =
            mean_wet_flux * correction * conversion * stocking

        if raw_dry_total > zero(T)
            for species in 1:species_number
                evapotranspiration_by_species[species] =
                    raw_dry_by_species[species] * canopy_transpiration /
                    raw_dry_total
            end
        end
    end

    for value in (
        raw_dry_total,
        raw_wet_total,
        weighted_leaf_area,
        leaf_weighted_dry_total,
        leaf_weighted_wet_total,
        leaf_weighted_gscan_total,
        raw_absorbed_radiation_w,
        target_slot_count,
        all_tree_count,
        conversion,
        canopy_transpiration,
        wet_canopy_evaporation,
    )
        isfinite(value) ||
            _throw_stand_water_flux_scaling(:stand_water_flux, value, :solution)
    end
    all(isfinite, raw_dry_by_species) ||
        _throw_stand_water_flux_scaling(
            :evapotranspiration_by_species_mm,
            raw_dry_by_species,
            :solution,
        )
    all(isfinite, evapotranspiration_by_species) ||
        _throw_stand_water_flux_scaling(
            :evapotranspiration_by_species_mm,
            evapotranspiration_by_species,
            :solution,
        )

    return StandWaterFluxScalingResult{T}(
        canopy_transpiration,
        evapotranspiration_by_species,
        wet_canopy_evaporation,
    )
end

"""
PlantSimEngine adapter for the `USESTAND=0`, `1`, and `2` water-flux branches
of legacy `SCALEUP`.

`target_multiplicities` and `target_species_ids` accompany the `Many` Crown
inputs and keep duplicate legacy target slots without duplicating physical
Crown objects. The timestep is read from `environment.duration` through
`_maespa_timestep_seconds`. Successful and unavailable steps publish a fresh
species vector; an invalid active step leaves the last accepted snapshot
untouched.

The high-level scene builder mounts this model only as part of the explicit
non-Tuzet leaf-exchange chain. The Soil water-flux partition consumes its
species output, and the optional canopy-water store consumes its wet-canopy
output. For `USESTAND=1`, the wet-canopy flux uses mode-2 leaf-area weighting
as an explicit portable definition of the unassigned legacy `EVMM` branch;
ETCAN dry transpiration remains unchanged.

With `canopy_interception=config`, the adapter additionally limits positive
stand wet loss with [`conservative_wet_canopy_evaporation`](@ref), before
publishing the same existing wet output to storage and latent heat. The five
`wet_budget_*` inputs supply actual rainfall, full LAI and the previous accepted
storage/throughfall/dry states. `nothing` (the default) retains the raw SCALEUP
result and its original input schema. The pure `stand_water_flux_scaling`
calculation is unchanged.
"""
struct MAESPAStandWaterFluxScaling{T<:AbstractFloat,L} <:
       AbstractStand_Water_Flux_ScalingModel
    use_stand::Int
    species_count::Int
    water_balance_area_m2::T
    stocking_trees_m2::T
    total_tree_count::Int
    water_molar_mass_g_mol::T
    water_to_co2_conductance_ratio::T
    gas_constant_j_mol_k::T
    kelvin_offset_c::T
    wet_canopy_limiter::L
end

# Preserve the former explicit field constructor with the limiter disabled.
function MAESPAStandWaterFluxScaling{T}(
    mode, species_number, area, stocking, tree_count, molar_mass,
    conductance_ratio, gas_constant, kelvin_offset,
) where {T<:AbstractFloat}
    return MAESPAStandWaterFluxScaling{T,Nothing}(
        mode, species_number, area, stocking, tree_count, molar_mass,
        conductance_ratio, gas_constant, kelvin_offset, nothing,
    )
end

function MAESPAStandWaterFluxScaling(
    mode::Int, species_number::Int, area::T, stocking::T, tree_count::Int,
    molar_mass::T, conductance_ratio::T, gas_constant::T, kelvin_offset::T,
) where {T<:AbstractFloat}
    return MAESPAStandWaterFluxScaling{T}(
        mode, species_number, area, stocking, tree_count, molar_mass,
        conductance_ratio, gas_constant, kelvin_offset,
    )
end

function MAESPAStandWaterFluxScaling(
    ::Type{T}=Float64;
    use_stand,
    species_count,
    water_balance_area_m2,
    stocking_trees_m2,
    total_tree_count=nothing,
    water_molar_mass_g_mol=18,
    water_to_co2_conductance_ratio=1.57,
    gas_constant_j_mol_k=8.314,
    kelvin_offset_c=273.15,
    canopy_interception=nothing,
    initial_canopy_water_storage_mm=0,
    initial_dry_canopy_fraction=1,
    interception_relative_tolerance=1e-3,
    interception_initial_step=1e-5,
    interception_max_steps=10_000,
    interception_bracket_relative_tolerance=nothing,
    interception_max_bisections=128,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the stand water-flux numeric type must be concrete"),
    )
    mode = _stand_water_flux_mode(use_stand)
    species_number = _stand_water_flux_count(species_count, :species_count)
    area = _stand_water_flux_positive(
        _stand_water_flux_float(
            T,
            water_balance_area_m2,
            :water_balance_area_m2,
        ),
        :water_balance_area_m2,
    )
    stocking = _stand_water_flux_positive(
        _stand_water_flux_float(
            T,
            stocking_trees_m2,
            :stocking_trees_m2,
        ),
        :stocking_trees_m2,
    )
    tree_count = if isnothing(total_tree_count)
        mode == 1 && throw(
            ArgumentError("total_tree_count is required for USESTAND=1"),
        )
        0
    else
        _stand_water_flux_count(total_tree_count, :total_tree_count)
    end
    molar_mass = _stand_water_flux_positive(
        _stand_water_flux_float(
            T,
            water_molar_mass_g_mol,
            :water_molar_mass_g_mol,
        ),
        :water_molar_mass_g_mol,
    )
    conductance_ratio = _stand_water_flux_positive(
        _stand_water_flux_float(
            T,
            water_to_co2_conductance_ratio,
            :water_to_co2_conductance_ratio,
        ),
        :water_to_co2_conductance_ratio,
    )
    gas_constant = _stand_water_flux_positive(
        _stand_water_flux_float(
            T,
            gas_constant_j_mol_k,
            :gas_constant_j_mol_k,
        ),
        :gas_constant_j_mol_k,
    )
    kelvin_offset = _stand_water_flux_positive(
        _stand_water_flux_float(T, kelvin_offset_c, :kelvin_offset_c),
        :kelvin_offset_c,
    )
    limiter = if isnothing(canopy_interception)
        nothing
    else
        canopy_interception isa CanopyInterceptionConfig || throw(
            ArgumentError("canopy_interception must be a CanopyInterceptionConfig or nothing"),
        )
        # Reuse the accepted store's fixed-parameter validation, retaining only
        # immutable parameter data, not a second hidden process model.
        storage = MAESPACanopyWaterStorage(
            canopy_interception;
            initial_canopy_water_storage_mm,
            initial_dry_canopy_fraction,
            relative_tolerance=interception_relative_tolerance,
            initial_step=interception_initial_step,
            max_steps=interception_max_steps,
        )
        storage.initial_canopy_water_storage_mm >=
            zero(storage.initial_canopy_water_storage_mm) || throw(DomainError(
                storage.initial_canopy_water_storage_mm,
                "initial_canopy_water_storage_mm must be non-negative",
            ))
        bracket_tolerance = if isnothing(interception_bracket_relative_tolerance)
            nothing
        else
            value = _canopy_interception_scalar(
                typeof(storage.relative_tolerance),
                interception_bracket_relative_tolerance,
                "interception_bracket_relative_tolerance",
            )
            zero(value) < value < one(value) || throw(DomainError(
                value, "interception_bracket_relative_tolerance must lie in (0, 1)",
            ))
            value
        end
        interception_max_bisections isa Integer &&
            !(interception_max_bisections isa Bool) || throw(ArgumentError(
                "interception_max_bisections must be an integer, not Bool",
            ))
        interception_max_bisections > 0 || throw(DomainError(
            interception_max_bisections, "interception_max_bisections must be positive",
        ))
        bisection_limit = try
            Int(interception_max_bisections)
        catch exception
            exception isa InexactError || exception isa OverflowError || rethrow()
            throw(ArgumentError("interception_max_bisections must be representable as Int"))
        end
        (
            config=storage.config,
            initial_canopy_water_storage_mm=storage.initial_canopy_water_storage_mm,
            initial_dry_canopy_fraction=storage.initial_dry_canopy_fraction,
            relative_tolerance=storage.relative_tolerance,
            initial_step=storage.initial_step,
            max_steps=storage.max_steps,
            bracket_relative_tolerance=bracket_tolerance,
            max_bisections=bisection_limit,
        )
    end
    return MAESPAStandWaterFluxScaling{T,typeof(limiter)}(
        mode,
        species_number,
        area,
        stocking,
        tree_count,
        molar_mass,
        conductance_ratio,
        gas_constant,
        kelvin_offset,
        limiter,
    )
end

function PlantSimEngine.inputs_(
    model::MAESPAStandWaterFluxScaling{T},
) where {T}
    common_prefix = (
        target_leaf_area_m2=PlantSimEngine.Required(AbstractVector),
        target_multiplicities=PlantSimEngine.Required(AbstractVector),
        target_species_ids=PlantSimEngine.Required(AbstractVector),
        dry_transpiration_crown_umol_h2o_s=
            PlantSimEngine.Required(AbstractVector),
        wet_evaporation_crown_umol_h2o_s=
            PlantSimEngine.Required(AbstractVector),
    )
    common_suffix = (
        crown_leaf_exchange_aggregation_available=
            PlantSimEngine.Required(AbstractVector),
        stand_lai=PlantSimEngine.Required(Real),
        stand_water_flux_scaling_inputs_available=PlantSimEngine.Default(true),
    )
    wet_budget_inputs = if isnothing(model.wet_canopy_limiter)
        NamedTuple()
    else
        limiter = model.wet_canopy_limiter
        (
            wet_budget_precipitation_mm=PlantSimEngine.Required(Real),
            wet_budget_full_stand_lai=PlantSimEngine.Required(Real),
            wet_budget_previous_canopy_water_storage_mm=PlantSimEngine.Default(
                limiter.initial_canopy_water_storage_mm,
            ),
            wet_budget_previous_effective_throughfall_fraction=PlantSimEngine.Default(
                limiter.config.throughfall,
            ),
            wet_budget_previous_dry_canopy_fraction=PlantSimEngine.Default(
                limiter.initial_dry_canopy_fraction,
            ),
        )
    end
    model.use_stand == 1 || return (;
        common_prefix...,
        common_suffix...,
        wet_budget_inputs...,
    )
    return (
        common_prefix...,
        common_suffix...,
        wet_budget_inputs...,
        stomatal_conductance_co2_crown_mol_s=PlantSimEngine.Default(T[]),
        absorbed_par_crown_w=PlantSimEngine.Default(T[]),
        absorbed_nir_crown_w=PlantSimEngine.Default(T[]),
        absorbed_thermal_crown_w=PlantSimEngine.Default(T[]),
        crown_radiation_aggregation_available=PlantSimEngine.Default(Bool[]),
        crown_thermal_radiation_aggregation_available=
            PlantSimEngine.Default(Bool[]),
        canopy_atmosphere_aerodynamic_conductance_m_s=
            PlantSimEngine.Default(zero(T)),
        soil_surface_aerodynamics_available=PlantSimEngine.Default(false),
        astronomical_daylight=PlantSimEngine.Default(true),
        target_exchange_daylight=PlantSimEngine.Default(Bool[]),
    )
end

function PlantSimEngine.variable_contracts_(model::MAESPAStandWaterFluxScaling)
    common = (
        wet_canopy_evaporation_mm_timestep=GROUND_WATER_DEPTH_TIMESTEP_CONTRACT,
    )
    isnothing(model.wet_canopy_limiter) && return common
    return merge(common, (
        wet_budget_precipitation_mm=GROUND_WATER_DEPTH_TIMESTEP_CONTRACT,
        wet_budget_full_stand_lai=FULL_STAND_LAI_CONTRACT,
        wet_budget_previous_canopy_water_storage_mm=CANOPY_WATER_STORAGE_CONTRACT,
        wet_budget_previous_effective_throughfall_fraction=CANOPY_THROUGHFALL_CONTROL_CONTRACT,
        wet_budget_previous_dry_canopy_fraction=CANOPY_DRY_FRACTION_CONTRACT,
    ))
end

# Duration is consumed through the shared rate-to-depth conversion helper;
# declare it explicitly so compiled hard calls receive it as well.
function PlantSimEngine.environment_inputs_(model::MAESPAStandWaterFluxScaling{T}) where {T}
    duration = (duration=PlantSimEngine.Required(Union{Real,Dates.Period,Dates.CompoundPeriod}),)
    model.use_stand == 1 || return duration
    return merge(duration, (air_temperature_c=zero(T), air_pressure_pa=zero(T),
        vapour_pressure_deficit_pa=zero(T), canopy_atmosphere_available=false))
end

function PlantSimEngine.outputs_(
    model::MAESPAStandWaterFluxScaling{T},
) where {T}
    return (
        canopy_transpiration_mm_timestep=zero(T),
        evapotranspiration_by_species_mm=zeros(T, model.species_count),
        wet_canopy_evaporation_mm_timestep=zero(T),
        stand_water_flux_scaling_available=false,
    )
end

function _stand_water_flux_output_type(model, status)
    dry = status.canopy_transpiration_mm_timestep
    T = typeof(dry)
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "canopy_transpiration_mm_timestep must use a concrete AbstractFloat type",
        ),
    )
    typeof(status.wet_canopy_evaporation_mm_timestep) === T || throw(
        ArgumentError(
            "wet_canopy_evaporation_mm_timestep must use the output type $T",
        ),
    )
    species = status.evapotranspiration_by_species_mm
    species isa AbstractVector || throw(
        ArgumentError("evapotranspiration_by_species_mm must be an AbstractVector"),
    )
    Base.require_one_based_indexing(species)
    eltype(species) === T || throw(
        ArgumentError(
            "evapotranspiration_by_species_mm must have element type $T",
        ),
    )
    length(species) == model.species_count || throw(
        DimensionMismatch(
            "evapotranspiration_by_species_mm must contain " *
            "$(model.species_count) values",
        ),
    )
    status.stand_water_flux_scaling_available isa Bool || throw(
        ArgumentError("stand_water_flux_scaling_available must be Bool"),
    )
    return T
end

function _stand_water_flux_source_availability(status)
    available = status.crown_leaf_exchange_aggregation_available
    available isa AbstractVector || throw(
        ArgumentError(
            "crown_leaf_exchange_aggregation_available must be an AbstractVector",
        ),
    )
    Base.require_one_based_indexing(available)
    isempty(available) && throw(
        ArgumentError("at least one target Crown is required"),
    )
    all_available = true
    for flag in available
        flag isa Bool || throw(
            ArgumentError(
                "crown_leaf_exchange_aggregation_available values must be Bool",
            ),
        )
        all_available &= flag
    end
    return length(available), all_available
end

function _stand_water_flux_gate_vector_available(
    values,
    name::Symbol,
    target_count::Int,
)
    values isa AbstractVector || throw(
        ArgumentError("$(String(name)) must be an AbstractVector"),
    )
    Base.require_one_based_indexing(values)
    length(values) == target_count || throw(
        DimensionMismatch("$(String(name)) must contain $target_count values"),
    )
    all_available = true
    for flag in values
        flag isa Bool || throw(
            ArgumentError("$(String(name)) values must be Bool"),
        )
        all_available &= flag
    end
    return all_available
end

function _stand_water_flux_mode_one_sources_available(
    status,
    environment,
    target_count::Int,
    target_exchange_daylight,
    astronomical_daylight::Bool,
)
    meteorology_available = environment.canopy_atmosphere_available
    aerodynamics_available = status.soil_surface_aerodynamics_available
    meteorology_available isa Bool || throw(
        ArgumentError("meteorology_reconstruction_available must be Bool"),
    )
    aerodynamics_available isa Bool || throw(
        ArgumentError("soil_surface_aerodynamics_available must be Bool"),
    )
    meteorology_available && aerodynamics_available || return false

    shortwave_gates = status.crown_radiation_aggregation_available
    shortwave_gates isa AbstractVector || throw(
        ArgumentError(
            "crown_radiation_aggregation_available must be an AbstractVector",
        ),
    )
    Base.require_one_based_indexing(shortwave_gates)
    length(shortwave_gates) == target_count || throw(
        DimensionMismatch(
            "crown_radiation_aggregation_available must contain " *
            "$target_count values",
        ),
    )
    shortwave_available = true
    for target_index in 1:target_count
        flag = shortwave_gates[target_index]
        flag isa Bool || throw(
            ArgumentError(
                "crown_radiation_aggregation_available values must be Bool",
            ),
        )
        target_daylight = isnothing(target_exchange_daylight) ?
                          astronomical_daylight :
                          target_exchange_daylight[target_index]
        target_daylight && !flag && (shortwave_available = false)
    end
    thermal_available = _stand_water_flux_gate_vector_available(
        status.crown_thermal_radiation_aggregation_available,
        :crown_thermal_radiation_aggregation_available,
        target_count,
    )
    return shortwave_available && thermal_available
end

@inline function _stand_water_flux_require_vector_length(
    values,
    name::Symbol,
    target_count::Int,
)
    values isa AbstractVector || throw(
        ArgumentError("$(String(name)) must be an AbstractVector"),
    )
    length(values) == target_count || throw(
        DimensionMismatch("$(String(name)) must contain $target_count values"),
    )
    return nothing
end

function _publish_unavailable_stand_water_flux!(model, status, ::Type{T}) where {T}
    status.canopy_transpiration_mm_timestep = zero(T)
    status.evapotranspiration_by_species_mm = zeros(T, model.species_count)
    status.wet_canopy_evaporation_mm_timestep = zero(T)
    status.stand_water_flux_scaling_available = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPAStandWaterFluxScaling,
    status,
    environment,
    constants,
    context,
)
    T = try
        _stand_water_flux_output_type(model, status)
    catch
        status.stand_water_flux_scaling_available = false
        rethrow()
    end
    # An exception below leaves the last accepted numeric outputs intact, but
    # they no longer describe a valid result for the current attempted step.
    status.stand_water_flux_scaling_available = false
    inputs_available = status.stand_water_flux_scaling_inputs_available
    inputs_available isa Bool || throw(
        ArgumentError("stand_water_flux_scaling_inputs_available must be Bool"),
    )
    if !inputs_available
        _publish_unavailable_stand_water_flux!(model, status, T)
        return nothing
    end
    target_count, all_available = _stand_water_flux_source_availability(status)
    if !all_available
        _publish_unavailable_stand_water_flux!(model, status, T)
        return nothing
    end

    astronomical_daylight = true
    target_exchange_daylight = nothing
    if model.use_stand == 1
        astronomical_daylight = status.astronomical_daylight
        astronomical_daylight isa Bool || throw(
            ArgumentError("astronomical_daylight must be Bool"),
        )
        target_exchange_daylight, _ =
            _stand_water_flux_target_daylight(
                status.target_exchange_daylight,
                target_count,
                astronomical_daylight,
            )
        if !_stand_water_flux_mode_one_sources_available(
            status,
            environment,
            target_count,
            target_exchange_daylight,
            astronomical_daylight,
        )
            _publish_unavailable_stand_water_flux!(model, status, T)
            return nothing
        end
    end

    for (values, name) in (
        (status.target_leaf_area_m2, :target_leaf_area_m2),
        (status.target_multiplicities, :target_multiplicities),
        (status.target_species_ids, :target_species_ids),
        (
            status.dry_transpiration_crown_umol_h2o_s,
            :dry_transpiration_crown_umol_h2o_s,
        ),
        (
            status.wet_evaporation_crown_umol_h2o_s,
            :wet_evaporation_crown_umol_h2o_s,
        ),
    )
        _stand_water_flux_require_vector_length(
            values,
            name,
            target_count,
        )
    end
    if model.use_stand == 1
        mode_one_vectors = (
            (
                status.stomatal_conductance_co2_crown_mol_s,
                :stomatal_conductance_co2_crown_mol_s,
            ),
            (status.absorbed_thermal_crown_w, :absorbed_thermal_crown_w),
        )
        for (values, name) in mode_one_vectors
            _stand_water_flux_require_vector_length(values, name, target_count)
        end
        if any(status.crown_radiation_aggregation_available)
            for (values, name) in (
                (status.absorbed_par_crown_w, :absorbed_par_crown_w),
                (status.absorbed_nir_crown_w, :absorbed_nir_crown_w),
            )
                _stand_water_flux_require_vector_length(
                    values,
                    name,
                    target_count,
                )
            end
        end
    end

    # The pure kernel allocates the next species vector. Nothing is installed
    # until all active inputs and the timestep have been validated.
    mode_one_arguments = if model.use_stand == 1
        (
            stomatal_conductance_co2_crown_mol_s=
                status.stomatal_conductance_co2_crown_mol_s,
            absorbed_par_crown_w=status.absorbed_par_crown_w,
            absorbed_nir_crown_w=status.absorbed_nir_crown_w,
            absorbed_thermal_crown_w=status.absorbed_thermal_crown_w,
            canopy_atmosphere_aerodynamic_conductance_m_s=
                status.canopy_atmosphere_aerodynamic_conductance_m_s,
            atmospheric_pressure_pa=environment.air_pressure_pa,
            air_temperature_c=environment.air_temperature_c,
            vapour_pressure_deficit_pa=environment.vapour_pressure_deficit_pa,
            astronomical_daylight,
            target_exchange_daylight,
            crown_radiation_aggregation_available=
                status.crown_radiation_aggregation_available,
        )
    else
        NamedTuple()
    end
    duration = _maespa_timestep_seconds(T, environment)
    result = stand_water_flux_scaling(
        T,
        status.target_leaf_area_m2,
        status.dry_transpiration_crown_umol_h2o_s,
        status.wet_evaporation_crown_umol_h2o_s;
        target_multiplicities=status.target_multiplicities,
        target_species_ids=status.target_species_ids,
        species_count=model.species_count,
        water_balance_area_m2=convert(T, model.water_balance_area_m2),
        stocking_trees_m2=convert(T, model.stocking_trees_m2),
        total_tree_count=model.total_tree_count,
        stand_lai=status.stand_lai,
        timestep_seconds=duration,
        use_stand=model.use_stand,
        water_molar_mass_g_mol=convert(T, model.water_molar_mass_g_mol),
        mode_one_arguments...,
        water_to_co2_conductance_ratio=convert(
            T,
            model.water_to_co2_conductance_ratio,
        ),
        gas_constant_j_mol_k=convert(T, model.gas_constant_j_mol_k),
        kelvin_offset_c=convert(T, model.kelvin_offset_c),
    )
    wet_evaporation = result.wet_canopy_evaporation_mm_timestep
    limiter = model.wet_canopy_limiter
    if !isnothing(limiter) && wet_evaporation > zero(T) &&
       !iszero(convert(T, limiter.config.maximum_storage))
        previous_throughfall = _canopy_interception_scalar(
            T, status.wet_budget_previous_effective_throughfall_fraction,
            "wet_budget_previous_effective_throughfall_fraction",
        )
        if previous_throughfall != one(T)
            previous_storage = _canopy_interception_scalar(
                T, status.wet_budget_previous_canopy_water_storage_mm,
                "wet_budget_previous_canopy_water_storage_mm",
            )
            bracket_tolerance = isnothing(limiter.bracket_relative_tolerance) ?
                T(8) * eps(T) : convert(T, limiter.bracket_relative_tolerance)
            wet_evaporation = conservative_wet_canopy_evaporation(
                limiter.config,
                status.wet_budget_precipitation_mm,
                status.wet_budget_full_stand_lai,
                previous_storage,
                wet_evaporation;
                timestep_seconds=duration,
                previous_effective_throughfall_fraction=previous_throughfall,
                previous_dry_canopy_fraction=status.wet_budget_previous_dry_canopy_fraction,
                relative_tolerance=convert(T, limiter.relative_tolerance),
                initial_step=convert(T, limiter.initial_step),
                max_steps=limiter.max_steps,
                bracket_relative_tolerance=bracket_tolerance,
                max_bisections=limiter.max_bisections,
            )
        end
    end
    status.canopy_transpiration_mm_timestep =
        result.canopy_transpiration_mm_timestep
    status.evapotranspiration_by_species_mm =
        result.evapotranspiration_by_species_mm
    status.wet_canopy_evaporation_mm_timestep =
        wet_evaporation
    status.stand_water_flux_scaling_available = true
    return nothing
end
