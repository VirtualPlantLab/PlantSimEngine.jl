PlantSimEngine.@process "leaf_tuzet_hydraulic_closure" verbose = false

"""
One evaluation of MAESPA's Tuzet leaf-water-potential closure.

`stomatal_leaf_water_potential_mpa` is historical `PSILIN`: the trial value
used by `FPSIL` in daylight, or `WEIGHTEDSWP` in the historical night-time
fallback. `leaf_water_potential_mpa` is historical `PSIL`, calculated from the
potential dry-leaf transpiration before the dry/wet surface partition.

The residual and squared objective are the daylight quantities
`PSILIN - PSIL` and `(PSILIN - PSIL)^2`. They are zero and marked unavailable
at night because `PSTRANSPIF` does not call either `FPSIL` or `PSILFIND` then.
"""
struct LeafTuzetHydraulicClosureResult{T<:AbstractFloat}
    stomatal_leaf_water_potential_mpa::T
    hydraulic_stomatal_factor::T
    leaf_water_potential_mpa::T
    leaf_water_potential_residual_mpa::T
    legacy_squared_objective_mpa2::T
    hydraulic_closure_residual_within_tolerance::Bool
    hydraulic_root_search_active::Bool
    hydraulic_stomatal_factor_available::Bool
end

"""
    MAESPALeafTuzetHydraulicClosure(T=Float64; kwargs...)

Parameters for one stateless evaluation of the executable Tuzet hydraulic
closure in `PSTRANSPIF`/`PSILOBJFUN`.

This model deliberately is not the complete `PSILFIND` controller. The
historical objective calls the whole `PSTRANSP` leaf-temperature,
photosynthesis, boundary-layer, and Penman--Monteith loop for every trial
water potential. Moreover, the executable objective is squared while the
bracketing check in `ZBRENT` is disabled. Recreating a standalone root search
here would require inventing a transpiration response to water potential.
Instead, a future controller can call this process around the existing leaf
children and use the signed residual to choose the next trial.

`residual_tolerance_mpa` is only a deterministic residual diagnostic. Its
default shares the `1e-3 MPa` numerical scale of historical `PSILFIND.XACC`,
but it does not claim parity with the legacy iteration count or `ZBRENT`
termination rule. The fixed historical trial interval `[-100, 0] MPa` is
validated in daylight.

`NEWTUZET` is not a hydraulic branch: it selects the optional second stomatal
curve in `stomatal_photosynthesis_coupling`, where both curves use the same
factor calculated here.
"""
struct MAESPALeafTuzetHydraulicClosure{T<:AbstractFloat} <:
       AbstractLeaf_Tuzet_Hydraulic_ClosureModel
    sensitivity_factor_mpa_inverse::T
    reference_water_potential_mpa::T
    residual_tolerance_mpa::T
end

@noinline function _throw_leaf_tuzet_hydraulic_numeric(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :negative
        throw(DomainError(value, "$label must be negative"))
    elseif reason === :trial_interval
        throw(
            DomainError(
                value,
                "$label must lie in the historical PSILFIND interval [-100, 0] MPa",
            ),
        )
    elseif reason === :result
        throw(DomainError(value, "$label must be finite"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _leaf_tuzet_hydraulic_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real || _throw_leaf_tuzet_hydraulic_numeric(name, value, :real)
    value isa Bool && _throw_leaf_tuzet_hydraulic_numeric(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_leaf_tuzet_hydraulic_numeric(name, converted, :finite)
    return converted
end

@inline function _leaf_tuzet_hydraulic_positive(value::T, name::Symbol) where {T}
    value > zero(T) ||
        _throw_leaf_tuzet_hydraulic_numeric(name, value, :positive)
    return value
end

@inline function _leaf_tuzet_hydraulic_nonnegative(value::T, name::Symbol) where {T}
    value >= zero(T) ||
        _throw_leaf_tuzet_hydraulic_numeric(name, value, :nonnegative)
    return value
end

@inline function _leaf_tuzet_hydraulic_negative(value::T, name::Symbol) where {T}
    value < zero(T) ||
        _throw_leaf_tuzet_hydraulic_numeric(name, value, :negative)
    return value
end

function MAESPALeafTuzetHydraulicClosure(
    ::Type{T}=Float64;
    sensitivity_factor_mpa_inverse::Real,
    reference_water_potential_mpa::Real,
    residual_tolerance_mpa::Real=T(1e-3),
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the Tuzet hydraulic-closure numeric type must be concrete"),
    )
    sensitivity = _leaf_tuzet_hydraulic_positive(
        _leaf_tuzet_hydraulic_float(
            T,
            sensitivity_factor_mpa_inverse,
            :sensitivity_factor_mpa_inverse,
        ),
        :sensitivity_factor_mpa_inverse,
    )
    reference_potential = _leaf_tuzet_hydraulic_negative(
        _leaf_tuzet_hydraulic_float(
            T,
            reference_water_potential_mpa,
            :reference_water_potential_mpa,
        ),
        :reference_water_potential_mpa,
    )
    tolerance = _leaf_tuzet_hydraulic_positive(
        _leaf_tuzet_hydraulic_float(
            T,
            residual_tolerance_mpa,
            :residual_tolerance_mpa,
        ),
        :residual_tolerance_mpa,
    )
    return MAESPALeafTuzetHydraulicClosure{T}(
        sensitivity,
        reference_potential,
        tolerance,
    )
end

"""Construct the closure parameters from the already-typed Tuzet inputs."""
function MAESPALeafTuzetHydraulicClosure(
    parameters::TuzetStomatalParameters{T};
    residual_tolerance_mpa::Real=T(1e-3),
) where {T<:AbstractFloat}
    return MAESPALeafTuzetHydraulicClosure(
        T;
        sensitivity_factor_mpa_inverse=parameters.sensitivity_factor,
        reference_water_potential_mpa=parameters.reference_water_potential,
        residual_tolerance_mpa,
    )
end

# Stable log(1 + exp(x)). It preserves the FPSIL equation without overflowing
# at PSILFIND's -100 MPa lower trial bound in Float32.
@inline function _leaf_tuzet_log1pexp(value::T) where {T<:AbstractFloat}
    return value > zero(T) ? value + log1p(exp(-value)) : log1p(exp(value))
end

@inline function _leaf_tuzet_stomatal_factor(
    leaf_water_potential_mpa::T,
    sensitivity_factor_mpa_inverse::T,
    reference_water_potential_mpa::T,
) where {T<:AbstractFloat}
    numerator_argument =
        sensitivity_factor_mpa_inverse * reference_water_potential_mpa
    denominator_argument = sensitivity_factor_mpa_inverse *
                           (reference_water_potential_mpa - leaf_water_potential_mpa)
    factor = exp(
        _leaf_tuzet_log1pexp(numerator_argument) -
        _leaf_tuzet_log1pexp(denominator_argument),
    )
    isfinite(factor) || _throw_leaf_tuzet_hydraulic_numeric(
        :hydraulic_stomatal_factor,
        factor,
        :result,
    )
    return factor
end

@inline function _leaf_tuzet_hydraulic_closure(
    model::MAESPALeafTuzetHydraulicClosure,
    ::Type{T},
    candidate_leaf_water_potential_mpa::T,
    weighted_soil_water_potential_mpa::T,
    soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa::T,
    potential_dry_transpiration_umol_h2o_m2_s::T,
    astronomical_daylight::Bool,
) where {T<:AbstractFloat}
    weighted_potential = _leaf_tuzet_hydraulic_float(
        T,
        weighted_soil_water_potential_mpa,
        :weighted_soil_water_potential_mpa,
    )
    hydraulic_conductance = _leaf_tuzet_hydraulic_positive(
        _leaf_tuzet_hydraulic_float(
            T,
            soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
            :soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        ),
        :soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
    )
    dry_transpiration = _leaf_tuzet_hydraulic_nonnegative(
        _leaf_tuzet_hydraulic_float(
            T,
            potential_dry_transpiration_umol_h2o_m2_s,
            :potential_dry_transpiration_umol_h2o_m2_s,
        ),
        :potential_dry_transpiration_umol_h2o_m2_s,
    )
    sensitivity = _leaf_tuzet_hydraulic_positive(
        _leaf_tuzet_hydraulic_float(
            T,
            model.sensitivity_factor_mpa_inverse,
            :sensitivity_factor_mpa_inverse,
        ),
        :sensitivity_factor_mpa_inverse,
    )
    reference_potential = _leaf_tuzet_hydraulic_negative(
        _leaf_tuzet_hydraulic_float(
            T,
            model.reference_water_potential_mpa,
            :reference_water_potential_mpa,
        ),
        :reference_water_potential_mpa,
    )
    tolerance = _leaf_tuzet_hydraulic_positive(
        _leaf_tuzet_hydraulic_float(
            T,
            model.residual_tolerance_mpa,
            :residual_tolerance_mpa,
        ),
        :residual_tolerance_mpa,
    )

    # PSTRANSP converts ET to umol before applying this expression. ET/1000
    # therefore recovers mmol H2O m-2 leaf s-1 for division by KTOT.
    leaf_water_potential = weighted_potential -
                           (dry_transpiration / T(1_000)) /
                           hydraulic_conductance
    isfinite(leaf_water_potential) || _throw_leaf_tuzet_hydraulic_numeric(
        :leaf_water_potential_mpa,
        leaf_water_potential,
        :result,
    )

    if !astronomical_daylight
        # PSTRANSPIF assigns PSILIN=WEIGHTEDSWP and does not evaluate FPSIL or
        # PSILOBJFUN at night. Zero values are deterministic unavailable
        # sentinels, not fabricated night-time hydraulic effects on stomata.
        return LeafTuzetHydraulicClosureResult{T}(
            weighted_potential,
            zero(T),
            leaf_water_potential,
            zero(T),
            zero(T),
            false,
            false,
            false,
        )
    end

    candidate = _leaf_tuzet_hydraulic_float(
        T,
        candidate_leaf_water_potential_mpa,
        :candidate_leaf_water_potential_mpa,
    )
    T(-100) <= candidate <= zero(T) ||
        _throw_leaf_tuzet_hydraulic_numeric(
            :candidate_leaf_water_potential_mpa,
            candidate,
            :trial_interval,
        )
    factor = _leaf_tuzet_stomatal_factor(
        candidate,
        sensitivity,
        reference_potential,
    )
    residual = candidate - leaf_water_potential
    isfinite(residual) || _throw_leaf_tuzet_hydraulic_numeric(
        :leaf_water_potential_residual_mpa,
        residual,
        :result,
    )
    squared_objective = residual * residual
    isfinite(squared_objective) || _throw_leaf_tuzet_hydraulic_numeric(
        :legacy_squared_objective_mpa2,
        squared_objective,
        :result,
    )

    return LeafTuzetHydraulicClosureResult{T}(
        candidate,
        factor,
        leaf_water_potential,
        residual,
        squared_objective,
        abs(residual) <= tolerance,
        true,
        true,
    )
end

"""
    leaf_tuzet_hydraulic_closure(model; inputs...)

Evaluate one Tuzet closure trial. `potential_dry_transpiration_umol_h2o_m2_s`
must be the non-negative dry-leaf Penman--Monteith flux before multiplying by
the effective dry-canopy fraction. In daylight the candidate must be within
the historical `PSILFIND` bounds `[-100, 0] MPa`. At night the candidate is
not read, matching `PSTRANSPIF`; the final diagnostic leaf potential is still
computed from the supplied flux and hydraulic conductance.
"""
function leaf_tuzet_hydraulic_closure(
    model::MAESPALeafTuzetHydraulicClosure;
    candidate_leaf_water_potential_mpa::Real,
    weighted_soil_water_potential_mpa::Real,
    soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa::Real,
    potential_dry_transpiration_umol_h2o_m2_s::Real,
    astronomical_daylight=true,
)
    astronomical_daylight isa Bool || throw(
        ArgumentError("astronomical_daylight must be Bool"),
    )
    for (value, name) in (
        (
            weighted_soil_water_potential_mpa,
            :weighted_soil_water_potential_mpa,
        ),
        (
            soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
            :soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        ),
        (
            potential_dry_transpiration_umol_h2o_m2_s,
            :potential_dry_transpiration_umol_h2o_m2_s,
        ),
    )
        value isa Bool && _throw_leaf_tuzet_hydraulic_numeric(name, value, :bool)
    end
    astronomical_daylight && candidate_leaf_water_potential_mpa isa Bool &&
        _throw_leaf_tuzet_hydraulic_numeric(
            :candidate_leaf_water_potential_mpa,
            candidate_leaf_water_potential_mpa,
            :bool,
        )
    effective_candidate = if astronomical_daylight
        float(candidate_leaf_water_potential_mpa)
    else
        float(weighted_soil_water_potential_mpa)
    end
    promoted = promote(
        model.sensitivity_factor_mpa_inverse,
        model.reference_water_potential_mpa,
        model.residual_tolerance_mpa,
        effective_candidate,
        float(weighted_soil_water_potential_mpa),
        float(soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa),
        float(potential_dry_transpiration_umol_h2o_m2_s),
    )
    T = typeof(first(promoted))
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "Tuzet hydraulic-closure inputs must promote to a concrete AbstractFloat",
        ),
    )
    return _leaf_tuzet_hydraulic_closure(
        model,
        T,
        promoted[4],
        promoted[5],
        promoted[6],
        promoted[7],
        astronomical_daylight,
    )
end

PlantSimEngine.variable_contracts_(::MAESPALeafTuzetHydraulicClosure) = (
    weighted_soil_water_potential_mpa=EFFECTIVE_SOIL_WATER_POTENTIAL_CONTRACT,
    soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa=LEAF_HYDRAULIC_CONDUCTANCE_CONTRACT,
    soil_to_leaf_hydraulic_supply_available=LEAF_HYDRAULIC_SUPPLY_AVAILABLE_CONTRACT,
)

PlantSimEngine.inputs_(::MAESPALeafTuzetHydraulicClosure) = (
    candidate_leaf_water_potential_mpa=PlantSimEngine.Required(Real),
    weighted_soil_water_potential_mpa=PlantSimEngine.Required(Real),
    soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa=
        PlantSimEngine.Required(Real),
    potential_dry_transpiration_umol_h2o_m2_s=PlantSimEngine.Required(Real),
    astronomical_daylight=PlantSimEngine.Required(Bool),
    tuzet_stomatal_model_active=PlantSimEngine.Required(Bool),
    soil_to_leaf_hydraulic_supply_available=PlantSimEngine.Required(Bool),
    potential_dry_transpiration_available=PlantSimEngine.Required(Bool),
)

PlantSimEngine.outputs_(::MAESPALeafTuzetHydraulicClosure{T}) where {T} = (
    stomatal_leaf_water_potential_mpa=zero(T),
    hydraulic_stomatal_factor=zero(T),
    leaf_water_potential_mpa=zero(T),
    leaf_water_potential_residual_mpa=zero(T),
    legacy_squared_objective_mpa2=zero(T),
    hydraulic_closure_residual_within_tolerance=false,
    hydraulic_root_search_active=false,
    hydraulic_stomatal_factor_available=false,
    leaf_tuzet_hydraulic_closure_available=false,
)

@inline function _reset_leaf_tuzet_hydraulic_closure!(status, ::Type{T}) where {T}
    status.stomatal_leaf_water_potential_mpa = zero(T)
    status.hydraulic_stomatal_factor = zero(T)
    status.leaf_water_potential_mpa = zero(T)
    status.leaf_water_potential_residual_mpa = zero(T)
    status.legacy_squared_objective_mpa2 = zero(T)
    status.hydraulic_closure_residual_within_tolerance = false
    status.hydraulic_root_search_active = false
    status.hydraulic_stomatal_factor_available = false
    status.leaf_tuzet_hydraulic_closure_available = false
    return nothing
end

@noinline function _throw_leaf_tuzet_hydraulic_output_type(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and Tuzet hydraulic-closure output carriers " *
            "must share a floating-point type",
        ),
    )
end

@inline function _validate_leaf_tuzet_hydraulic_output_type(
    value,
    ::Type{T},
    name::Symbol,
) where {T<:AbstractFloat}
    typeof(value) === T || _throw_leaf_tuzet_hydraulic_output_type(name)
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPALeafTuzetHydraulicClosure,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.stomatal_leaf_water_potential_mpa)
    T <: AbstractFloat || _throw_leaf_tuzet_hydraulic_output_type(
        :stomatal_leaf_water_potential_mpa,
    )
    _reset_leaf_tuzet_hydraulic_closure!(status, T)
    for name in (
        :hydraulic_stomatal_factor,
        :leaf_water_potential_mpa,
        :leaf_water_potential_residual_mpa,
        :legacy_squared_objective_mpa2,
    )
        _validate_leaf_tuzet_hydraulic_output_type(
            getproperty(status, name),
            T,
            name,
        )
    end

    active = status.tuzet_stomatal_model_active
    hydraulic_available = status.soil_to_leaf_hydraulic_supply_available
    transpiration_available = status.potential_dry_transpiration_available
    daylight = status.astronomical_daylight
    active isa Bool || throw(
        ArgumentError("tuzet_stomatal_model_active must be Bool"),
    )
    hydraulic_available isa Bool || throw(
        ArgumentError("soil_to_leaf_hydraulic_supply_available must be Bool"),
    )
    transpiration_available isa Bool || throw(
        ArgumentError("potential_dry_transpiration_available must be Bool"),
    )
    daylight isa Bool || throw(ArgumentError("astronomical_daylight must be Bool"))
    active && hydraulic_available && transpiration_available || return nothing

    weighted_potential = _leaf_tuzet_hydraulic_float(
        T,
        status.weighted_soil_water_potential_mpa,
        :weighted_soil_water_potential_mpa,
    )
    candidate = if daylight
        _leaf_tuzet_hydraulic_float(
            T,
            status.candidate_leaf_water_potential_mpa,
            :candidate_leaf_water_potential_mpa,
        )
    else
        weighted_potential
    end
    result = _leaf_tuzet_hydraulic_closure(
        model,
        T,
        candidate,
        weighted_potential,
        _leaf_tuzet_hydraulic_float(
            T,
            status.soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
            :soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        ),
        _leaf_tuzet_hydraulic_float(
            T,
            status.potential_dry_transpiration_umol_h2o_m2_s,
            :potential_dry_transpiration_umol_h2o_m2_s,
        ),
        daylight,
    )

    status.stomatal_leaf_water_potential_mpa =
        result.stomatal_leaf_water_potential_mpa
    status.hydraulic_stomatal_factor = result.hydraulic_stomatal_factor
    status.leaf_water_potential_mpa = result.leaf_water_potential_mpa
    status.leaf_water_potential_residual_mpa =
        result.leaf_water_potential_residual_mpa
    status.legacy_squared_objective_mpa2 = result.legacy_squared_objective_mpa2
    status.hydraulic_closure_residual_within_tolerance =
        result.hydraulic_closure_residual_within_tolerance
    status.hydraulic_root_search_active = result.hydraulic_root_search_active
    status.hydraulic_stomatal_factor_available =
        result.hydraulic_stomatal_factor_available
    status.leaf_tuzet_hydraulic_closure_available = true
    return nothing
end
