PlantSimEngine.@process "root_hydraulic_trajectory" verbose = false

"""
    MAESPARootHydraulicTrajectory(root_parameters, plant_hydraulics,
                                  soil_layer_thickness_m)

Publish the dated root and plant-hydraulic parameters used immediately before
MAESPA's soil-water calculations. The model is the deterministic Julia
counterpart of the root part of `INTERPOLATEDIST`, followed by `INTERPOLATEW`
and `WATINTERP`; it does not withdraw water.

`date50` selects the dated root and `PLANTK` tables. `simulation_day` is the
zero-based `IDAY` used by the historical root-front equation and must be kept
separate from the calendar date. `species_index` selects one resolved species
column from `RootParametersConfig.root_layer_fractions` and one minimum leaf
water potential from `PlantHydraulicConfig`.

The legacy executable gives every species the complete `ROOTMASSTOT`; it does
not divide that mass among species. Within the selected species, the current
root fractions are normalised and converted to layer densities as

```text
root mass density   = layer fraction * ROOTMASSTOT / layer thickness
root length density = root mass density * ROOTSRL
```

The root front is a step limiter, not a partial-layer calculation. The layer
containing the front remains entirely rooted, at least the first layer is
kept, and the surviving fractions are then renormalised. When the parser has
expanded fewer input profiles to more scene species, the already-resolved
fraction column is used and root-front coefficients follow the same source
profile mapping (profile one for every expanded species). This is a
deterministic repair of the legacy multi-date branch, which otherwise leaves
the extra `FRACROOTSPEC` columns undefined.

Only the first `rooted_layer_count` thicknesses are used, matching the
Fortran loops. Non-finite trajectories, an invalid root-front power base, or
a front leaving zero surviving root fraction are rejected instead of
propagating undefined values.
"""
struct MAESPARootHydraulicTrajectory{T<:AbstractFloat} <:
       AbstractRoot_Hydraulic_TrajectoryModel
    root_parameters::RootParametersConfig{T}
    plant_hydraulics::PlantHydraulicConfig{T}
    soil_layer_thickness_m::Vector{T}
    legacy_pi::T
end

function _validate_root_hydraulic_dates(dates, label::AbstractString)
    isempty(dates) && throw(ArgumentError("$label requires at least one date"))
    for index in 2:length(dates)
        dates[index].days_since_1950 > dates[index - 1].days_since_1950 ||
            throw(ArgumentError("$label dates must be strictly increasing"))
    end
    return nothing
end

function _validate_root_hydraulic_values(
    values,
    label::AbstractString;
    positive::Bool=false,
    nonnegative::Bool=false,
)
    for value in values
        isfinite(value) || throw(ArgumentError("$label values must be finite"))
        positive && value <= zero(value) &&
            throw(ArgumentError("$label values must be positive"))
        nonnegative && value < zero(value) &&
            throw(ArgumentError("$label values must be non-negative"))
    end
    return nothing
end

function MAESPARootHydraulicTrajectory(
    root_parameters::RootParametersConfig{T},
    plant_hydraulics::PlantHydraulicConfig{T},
    soil_layer_thickness_m::AbstractVector{T},
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the root-hydraulic trajectory numeric type must be concrete"),
    )
    layer_count = root_parameters.rooted_layer_count
    layer_count > 0 || throw(ArgumentError("rooted_layer_count must be positive"))
    length(soil_layer_thickness_m) >= layer_count || throw(
        DimensionMismatch(
            "soil_layer_thickness_m must contain at least $layer_count rooted layers",
        ),
    )

    _validate_root_hydraulic_dates(root_parameters.dates, "ROOTPARS")
    _validate_root_hydraulic_dates(plant_hydraulics.dates, "PLANTPARS")
    root_date_count = length(root_parameters.dates)
    plant_date_count = length(plant_hydraulics.dates)
    length(root_parameters.root_radius_m) == root_date_count || throw(
        DimensionMismatch("ROOTRAD length must equal the ROOTPARS date count"),
    )
    length(root_parameters.specific_root_length_m_g) == root_date_count ||
        throw(DimensionMismatch("ROOTSRL length must equal the ROOTPARS date count"))
    length(root_parameters.total_root_mass_g_m2) == root_date_count || throw(
        DimensionMismatch("ROOTMASSTOT length must equal the ROOTPARS date count"),
    )
    length(
        plant_hydraulics.plant_hydraulic_conductance_mmol_m2_leaf_s_mpa,
    ) == plant_date_count || throw(
        DimensionMismatch("PLANTK length must equal the PLANTPARS date count"),
    )

    species_count = root_parameters.species_count
    profile_count = root_parameters.input_profile_count
    species_count > 0 || throw(ArgumentError("species_count must be positive"))
    1 <= profile_count <= species_count || throw(
        ArgumentError("input_profile_count must lie in 1:species_count"),
    )
    size(root_parameters.root_layer_fractions) ==
    (layer_count, root_date_count, species_count) || throw(
        DimensionMismatch(
            "root_layer_fractions must have dimensions rooted layer × date × species",
        ),
    )
    length(plant_hydraulics.minimum_leaf_water_potential_mpa) == species_count ||
        throw(
            DimensionMismatch(
                "MINLEAFWP length must equal the resolved root species count",
            ),
        )
    for values in (
        root_parameters.root_front_age_offset_days,
        root_parameters.root_front_asymptotic_depth_m,
        root_parameters.root_front_rate_per_day,
        root_parameters.root_front_shape,
    )
        length(values) == profile_count || throw(
            DimensionMismatch(
                "root-front arrays must have input_profile_count entries",
            ),
        )
    end

    thickness = Vector{T}(undef, layer_count)
    for layer in 1:layer_count
        value = soil_layer_thickness_m[layer]
        isfinite(value) && value > zero(T) || throw(
            ArgumentError("rooted soil-layer thicknesses must be positive and finite"),
        )
        thickness[layer] = value
    end
    _validate_root_hydraulic_values(
        root_parameters.root_radius_m,
        "ROOTRAD";
        positive=true,
    )
    _validate_root_hydraulic_values(
        root_parameters.specific_root_length_m_g,
        "ROOTSRL";
        nonnegative=true,
    )
    _validate_root_hydraulic_values(
        root_parameters.total_root_mass_g_m2,
        "ROOTMASSTOT";
        nonnegative=true,
    )
    _validate_root_hydraulic_values(
        root_parameters.root_layer_fractions,
        "FRACROOT";
        nonnegative=true,
    )
    for species in 1:species_count, date in 1:root_date_count
        fraction_sum = zero(T)
        for layer in 1:layer_count
            fraction_sum += root_parameters.root_layer_fractions[layer, date, species]
        end
        isfinite(fraction_sum) && fraction_sum > zero(T) || throw(
            ArgumentError("every dated species root profile must have a positive sum"),
        )
    end

    resistance_fraction = root_parameters.root_resistance_fraction
    isfinite(resistance_fraction) &&
        zero(T) <= resistance_fraction <= one(T) || throw(
        ArgumentError("ROOTRESFRAC must be finite and lie in [0, 1]"),
    )
    _validate_root_hydraulic_values(
        plant_hydraulics.plant_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        "PLANTK";
        positive=true,
    )
    minimum_root = plant_hydraulics.minimum_root_water_potential_mpa
    isfinite(minimum_root) && T(-900) < minimum_root < zero(T) || throw(
        ArgumentError("MINROOTWP must be an available negative water potential"),
    )
    for minimum_leaf in plant_hydraulics.minimum_leaf_water_potential_mpa
        isfinite(minimum_leaf) && T(-900) < minimum_leaf < zero(T) || throw(
            ArgumentError("MINLEAFWP must contain available negative water potentials"),
        )
    end
    isfinite(plant_hydraulics.conductance_scaling_exponent) || throw(
        ArgumentError("KSCALING must be finite"),
    )

    if root_parameters.root_front_enabled
        _validate_root_hydraulic_values(
            root_parameters.root_front_asymptotic_depth_m,
            "RFPAR1";
            nonnegative=true,
        )
        _validate_root_hydraulic_values(
            root_parameters.root_front_rate_per_day,
            "RFPAR2";
            nonnegative=true,
        )
        _validate_root_hydraulic_values(
            root_parameters.root_front_shape,
            "RFPAR3";
            nonnegative=true,
        )
    end

    return MAESPARootHydraulicTrajectory{T}(
        root_parameters,
        plant_hydraulics,
        thickness,
        T(3.1415927),
    )
end

PlantSimEngine.variable_contracts_(::MAESPARootHydraulicTrajectory) = (
    plant_hydraulic_conductance_mmol_m2_leaf_s_mpa=LEAF_HYDRAULIC_CONDUCTANCE_CONTRACT,
    minimum_leaf_water_potential_mpa=LEAF_WATER_POTENTIAL_CONTRACT,
)

PlantSimEngine.inputs_(::MAESPARootHydraulicTrajectory) = (
    date50=PlantSimEngine.Required(Integer),
    simulation_day=PlantSimEngine.Required(Integer),
    species_index=PlantSimEngine.Required(Integer),
    root_hydraulic_trajectory_active=PlantSimEngine.Default(true),
    root_hydraulic_trajectory_inputs_available=PlantSimEngine.Default(true),
)

function PlantSimEngine.outputs_(model::MAESPARootHydraulicTrajectory{T}) where {T}
    layer_count = length(model.soil_layer_thickness_m)
    return (
        root_layer_fraction=zeros(T, layer_count),
        root_mass_density_g_m3=zeros(T, layer_count),
        root_length_density_m_m3=zeros(T, layer_count),
        fine_root_radius_m=zero(T),
        specific_root_length_m_g=zero(T),
        total_root_mass_g_m2=zero(T),
        root_cross_sectional_area_m2=zero(T),
        plant_hydraulic_conductance_mmol_m2_leaf_s_mpa=zero(T),
        root_hydraulic_resistance_mpa_m2_leaf_s_per_mmol=zero(T),
        minimum_root_water_potential_mpa=zero(T),
        minimum_leaf_water_potential_mpa=zero(T),
        plant_hydraulic_conductance_scaling_exponent=zero(T),
        root_front_depth_m=zero(T),
        root_front_limit_layer=0,
        root_front_limitation_active=false,
        root_hydraulic_trajectory_available=false,
    )
end

struct RootHydraulicTrajectoryScalars{T<:AbstractFloat}
    fine_root_radius_m::T
    specific_root_length_m_g::T
    total_root_mass_g_m2::T
    root_cross_sectional_area_m2::T
    plant_hydraulic_conductance_mmol_m2_leaf_s_mpa::T
    root_hydraulic_resistance_mpa_m2_leaf_s_per_mmol::T
    minimum_root_water_potential_mpa::T
    minimum_leaf_water_potential_mpa::T
    plant_hydraulic_conductance_scaling_exponent::T
    root_front_depth_m::T
    root_front_limit_layer::Int
    root_front_limitation_active::Bool
end

@inline function _root_hydraulic_interval(dates, requested_day::Int, ::Type{T}) where {T}
    first_day = first(dates).days_since_1950
    requested_day <= first_day && return (1, 1, zero(T))

    final_index = length(dates)
    final_day = last(dates).days_since_1950
    requested_day >= final_day && return (final_index, final_index, zero(T))

    upper_index = 2
    while requested_day > dates[upper_index].days_since_1950
        upper_index += 1
    end
    requested_day == dates[upper_index].days_since_1950 &&
        return (upper_index, upper_index, zero(T))

    lower_index = upper_index - 1
    lower_day = dates[lower_index].days_since_1950
    upper_day = dates[upper_index].days_since_1950
    fraction = T(requested_day - lower_day) / T(upper_day - lower_day)
    return (lower_index, upper_index, fraction)
end

@inline function _root_hydraulic_interpolate(
    values,
    lower_index::Int,
    upper_index::Int,
    fraction::T,
) where {T<:AbstractFloat}
    lower_value = T(@inbounds values[lower_index])
    lower_index == upper_index && return lower_value
    upper_value = T(@inbounds values[upper_index])
    return lower_value + fraction * (upper_value - lower_value)
end

@inline function _root_hydraulic_layer_fraction(
    root_parameters::RootParametersConfig,
    layer::Int,
    lower_index::Int,
    upper_index::Int,
    fraction::T,
    species_index::Int,
) where {T<:AbstractFloat}
    lower_value = T(
        @inbounds(
            root_parameters.root_layer_fractions[
                layer,
                lower_index,
                species_index,
            ]
        ),
    )
    lower_index == upper_index && return lower_value
    upper_value = T(
        @inbounds(
            root_parameters.root_layer_fractions[
                layer,
                upper_index,
                species_index,
            ]
        ),
    )
    return lower_value + fraction * (upper_value - lower_value)
end

@inline function _root_hydraulic_front_profile(
    root_parameters::RootParametersConfig,
    species_index::Int,
)
    root_parameters.species_count == root_parameters.input_profile_count &&
        return species_index
    return 1
end

@noinline function _throw_root_hydraulic_trajectory(
    name::Symbol,
    value,
    message::AbstractString,
)
    throw(DomainError(value, "$(String(name)) $message"))
end

@inline function _root_hydraulic_front(
    model::MAESPARootHydraulicTrajectory,
    simulation_day::Int,
    species_index::Int,
    ::Type{T},
) where {T<:AbstractFloat}
    root_parameters = model.root_parameters
    layer_count = length(model.soil_layer_thickness_m)
    root_parameters.root_front_enabled || return (zero(T), layer_count, false)

    profile = _root_hydraulic_front_profile(root_parameters, species_index)
    asymptote = T(@inbounds root_parameters.root_front_asymptotic_depth_m[profile])
    rate = T(@inbounds root_parameters.root_front_rate_per_day[profile])
    shape = T(@inbounds root_parameters.root_front_shape[profile])
    age_offset = T(@inbounds root_parameters.root_front_age_offset_days[profile])
    exponent = -rate * (T(simulation_day) + age_offset)
    exponential = exp(exponent)
    power_base = one(T) - exponential
    isfinite(power_base) && power_base >= zero(T) ||
        _throw_root_hydraulic_trajectory(
            :root_front_power_base,
            power_base,
            "must be finite and non-negative",
        )
    depth = asymptote * power_base^shape
    isfinite(depth) && depth >= zero(T) || _throw_root_hydraulic_trajectory(
        :root_front_depth_m,
        depth,
        "must be finite and non-negative",
    )

    total_depth = zero(T)
    for layer in 1:layer_count
        total_depth += T(@inbounds model.soil_layer_thickness_m[layer])
    end
    depth >= total_depth && return (depth, layer_count, true)

    limit_layer = 1
    cumulative_depth = T(@inbounds model.soil_layer_thickness_m[1])
    for layer in 1:(layer_count - 1)
        next_depth = cumulative_depth +
                     T(@inbounds model.soil_layer_thickness_m[layer + 1])
        if cumulative_depth < depth && next_depth >= depth
            limit_layer = layer + 1
            break
        end
        cumulative_depth = next_depth
    end
    return (depth, limit_layer, true)
end

@inline function _root_hydraulic_trajectory!(
    root_layer_fraction::AbstractVector{T},
    root_mass_density_g_m3::AbstractVector{T},
    root_length_density_m_m3::AbstractVector{T},
    model::MAESPARootHydraulicTrajectory,
    date50::Int,
    simulation_day::Int,
    species_index::Int,
) where {T<:AbstractFloat}
    root_parameters = model.root_parameters
    plant_hydraulics = model.plant_hydraulics
    layer_count = length(model.soil_layer_thickness_m)

    root_lower, root_upper, root_fraction = _root_hydraulic_interval(
        root_parameters.dates,
        date50,
        T,
    )
    fine_root_radius = _root_hydraulic_interpolate(
        root_parameters.root_radius_m,
        root_lower,
        root_upper,
        root_fraction,
    )
    specific_root_length = _root_hydraulic_interpolate(
        root_parameters.specific_root_length_m_g,
        root_lower,
        root_upper,
        root_fraction,
    )
    total_root_mass = _root_hydraulic_interpolate(
        root_parameters.total_root_mass_g_m2,
        root_lower,
        root_upper,
        root_fraction,
    )
    plant_lower, plant_upper, plant_fraction = _root_hydraulic_interval(
        plant_hydraulics.dates,
        date50,
        T,
    )
    plant_conductance = _root_hydraulic_interpolate(
        plant_hydraulics.plant_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        plant_lower,
        plant_upper,
        plant_fraction,
    )
    isfinite(plant_conductance) && plant_conductance > zero(T) ||
        _throw_root_hydraulic_trajectory(
            :plant_hydraulic_conductance_mmol_m2_leaf_s_mpa,
            plant_conductance,
            "must be finite and positive",
        )
    root_cross_sectional_area = T(model.legacy_pi) * fine_root_radius^2
    root_resistance =
        T(root_parameters.root_resistance_fraction) / plant_conductance
    minimum_root = T(plant_hydraulics.minimum_root_water_potential_mpa)
    minimum_leaf =
        T(@inbounds plant_hydraulics.minimum_leaf_water_potential_mpa[species_index])
    conductance_scaling = T(plant_hydraulics.conductance_scaling_exponent)

    isfinite(fine_root_radius) && fine_root_radius > zero(T) ||
        _throw_root_hydraulic_trajectory(
            :fine_root_radius_m,
            fine_root_radius,
            "must be finite and positive",
        )
    isfinite(specific_root_length) && specific_root_length >= zero(T) ||
        _throw_root_hydraulic_trajectory(
            :specific_root_length_m_g,
            specific_root_length,
            "must be finite and non-negative",
        )
    isfinite(total_root_mass) && total_root_mass >= zero(T) ||
        _throw_root_hydraulic_trajectory(
            :total_root_mass_g_m2,
            total_root_mass,
            "must be finite and non-negative",
        )
    isfinite(root_cross_sectional_area) && root_cross_sectional_area > zero(T) ||
        _throw_root_hydraulic_trajectory(
            :root_cross_sectional_area_m2,
            root_cross_sectional_area,
            "must be finite and positive",
        )
    isfinite(root_resistance) && root_resistance >= zero(T) ||
        _throw_root_hydraulic_trajectory(
            :root_hydraulic_resistance_mpa_m2_leaf_s_per_mmol,
            root_resistance,
            "must be finite and non-negative",
        )
    for (name, value) in (
        (:minimum_root_water_potential_mpa, minimum_root),
        (:minimum_leaf_water_potential_mpa, minimum_leaf),
        (:plant_hydraulic_conductance_scaling_exponent, conductance_scaling),
    )
        isfinite(value) || _throw_root_hydraulic_trajectory(
            name,
            value,
            "must be finite",
        )
    end

    root_front_depth, root_front_limit_layer, root_front_active =
        _root_hydraulic_front(model, simulation_day, species_index, T)

    # Validate every possible failure before mutating the output buffers. This
    # keeps the hot wrapper allocation-free while preserving atomic reset on
    # invalid legacy branches.
    fraction_sum = zero(T)
    for layer in 1:layer_count
        value = _root_hydraulic_layer_fraction(
            root_parameters,
            layer,
            root_lower,
            root_upper,
            root_fraction,
            species_index,
        )
        root_front_active && layer > root_front_limit_layer && (value = zero(T))
        isfinite(value) && value >= zero(T) || _throw_root_hydraulic_trajectory(
            :root_layer_fraction,
            value,
            "must remain finite and non-negative after interpolation",
        )
        fraction_sum += value
    end
    isfinite(fraction_sum) && fraction_sum > zero(T) ||
        _throw_root_hydraulic_trajectory(
            :root_layer_fraction_sum,
            fraction_sum,
            "must be positive after root-front limitation",
        )
    inverse_fraction_sum = inv(fraction_sum)
    for layer in 1:layer_count
        value = _root_hydraulic_layer_fraction(
            root_parameters,
            layer,
            root_lower,
            root_upper,
            root_fraction,
            species_index,
        )
        root_front_active && layer > root_front_limit_layer && (value = zero(T))
        normalised_fraction = value * inverse_fraction_sum
        thickness = T(@inbounds model.soil_layer_thickness_m[layer])
        mass_density = normalised_fraction * total_root_mass / thickness
        length_density = mass_density * specific_root_length
        isfinite(mass_density) && isfinite(length_density) ||
            _throw_root_hydraulic_trajectory(
                :root_density,
                length_density,
                "must remain finite",
            )
    end

    for layer in 1:layer_count
        value = _root_hydraulic_layer_fraction(
            root_parameters,
            layer,
            root_lower,
            root_upper,
            root_fraction,
            species_index,
        )
        root_front_active && layer > root_front_limit_layer && (value = zero(T))
        normalised_fraction = value * inverse_fraction_sum
        thickness = T(@inbounds model.soil_layer_thickness_m[layer])
        mass_density = normalised_fraction * total_root_mass / thickness
        @inbounds root_layer_fraction[layer] = normalised_fraction
        @inbounds root_mass_density_g_m3[layer] = mass_density
        @inbounds root_length_density_m_m3[layer] =
            mass_density * specific_root_length
    end

    return RootHydraulicTrajectoryScalars{T}(
        fine_root_radius,
        specific_root_length,
        total_root_mass,
        root_cross_sectional_area,
        plant_conductance,
        root_resistance,
        minimum_root,
        minimum_leaf,
        conductance_scaling,
        root_front_depth,
        root_front_limit_layer,
        root_front_active,
    )
end

@inline function _reset_root_hydraulic_trajectory!(status, ::Type{T}) where {T}
    fill!(status.root_layer_fraction, zero(T))
    fill!(status.root_mass_density_g_m3, zero(T))
    fill!(status.root_length_density_m_m3, zero(T))
    status.fine_root_radius_m = zero(T)
    status.specific_root_length_m_g = zero(T)
    status.total_root_mass_g_m2 = zero(T)
    status.root_cross_sectional_area_m2 = zero(T)
    status.plant_hydraulic_conductance_mmol_m2_leaf_s_mpa = zero(T)
    status.root_hydraulic_resistance_mpa_m2_leaf_s_per_mmol = zero(T)
    status.minimum_root_water_potential_mpa = zero(T)
    status.minimum_leaf_water_potential_mpa = zero(T)
    status.plant_hydraulic_conductance_scaling_exponent = zero(T)
    status.root_front_depth_m = zero(T)
    status.root_front_limit_layer = 0
    status.root_front_limitation_active = false
    status.root_hydraulic_trajectory_available = false
    return nothing
end

@noinline function _throw_root_hydraulic_output_type(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and root-hydraulic trajectory outputs must share " *
            "one floating-point type",
        ),
    )
end

@inline function _validate_root_hydraulic_output_vector(
    values,
    ::Type{T},
    layer_count::Int,
    name::Symbol,
) where {T<:AbstractFloat}
    values isa AbstractVector || _throw_root_hydraulic_output_type(name)
    eltype(values) === T || _throw_root_hydraulic_output_type(name)
    length(values) == layer_count || throw(
        DimensionMismatch("$(String(name)) must contain $layer_count values"),
    )
    return nothing
end

@inline function _validate_root_hydraulic_output_scalar(
    value,
    ::Type{T},
    name::Symbol,
) where {T<:AbstractFloat}
    typeof(value) === T || _throw_root_hydraulic_output_type(name)
    return nothing
end

@noinline function _throw_root_hydraulic_integer(name::Symbol, value, reason::Symbol)
    if reason === :bool
        throw(ArgumentError("$(String(name)) must be an integer, not Bool"))
    elseif reason === :negative
        throw(DomainError(value, "$(String(name)) must be non-negative"))
    end
    throw(ArgumentError("invalid $(String(name))"))
end

@inline function _root_hydraulic_integer(value::Integer, name::Symbol)
    value isa Bool && _throw_root_hydraulic_integer(name, value, :bool)
    return Int(value)
end

@noinline function _publish_root_hydraulic_trajectory!(
    model::MAESPARootHydraulicTrajectory,
    status,
    date50::Int,
    simulation_day::Int,
    species_index::Int,
)
    scalars = _root_hydraulic_trajectory!(
        status.root_layer_fraction,
        status.root_mass_density_g_m3,
        status.root_length_density_m_m3,
        model,
        date50,
        simulation_day,
        species_index,
    )
    status.fine_root_radius_m = scalars.fine_root_radius_m
    status.specific_root_length_m_g = scalars.specific_root_length_m_g
    status.total_root_mass_g_m2 = scalars.total_root_mass_g_m2
    status.root_cross_sectional_area_m2 = scalars.root_cross_sectional_area_m2
    status.plant_hydraulic_conductance_mmol_m2_leaf_s_mpa =
        scalars.plant_hydraulic_conductance_mmol_m2_leaf_s_mpa
    status.root_hydraulic_resistance_mpa_m2_leaf_s_per_mmol =
        scalars.root_hydraulic_resistance_mpa_m2_leaf_s_per_mmol
    status.minimum_root_water_potential_mpa =
        scalars.minimum_root_water_potential_mpa
    status.minimum_leaf_water_potential_mpa =
        scalars.minimum_leaf_water_potential_mpa
    status.plant_hydraulic_conductance_scaling_exponent =
        scalars.plant_hydraulic_conductance_scaling_exponent
    status.root_front_depth_m = scalars.root_front_depth_m
    status.root_front_limit_layer = scalars.root_front_limit_layer
    status.root_front_limitation_active = scalars.root_front_limitation_active
    status.root_hydraulic_trajectory_available = true
    return nothing
end

@noinline function _validate_root_hydraulic_outputs(
    model::MAESPARootHydraulicTrajectory,
    status,
    ::Type{T},
) where {T<:AbstractFloat}
    layer_count = length(model.soil_layer_thickness_m)
    _validate_root_hydraulic_output_vector(
        status.root_layer_fraction,
        T,
        layer_count,
        :root_layer_fraction,
    )
    _validate_root_hydraulic_output_vector(
        status.root_mass_density_g_m3,
        T,
        layer_count,
        :root_mass_density_g_m3,
    )
    _validate_root_hydraulic_output_vector(
        status.root_length_density_m_m3,
        T,
        layer_count,
        :root_length_density_m_m3,
    )
    _validate_root_hydraulic_output_scalar(
        status.specific_root_length_m_g,
        T,
        :specific_root_length_m_g,
    )
    _validate_root_hydraulic_output_scalar(
        status.total_root_mass_g_m2,
        T,
        :total_root_mass_g_m2,
    )
    _validate_root_hydraulic_output_scalar(
        status.root_cross_sectional_area_m2,
        T,
        :root_cross_sectional_area_m2,
    )
    _validate_root_hydraulic_output_scalar(
        status.plant_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        T,
        :plant_hydraulic_conductance_mmol_m2_leaf_s_mpa,
    )
    _validate_root_hydraulic_output_scalar(
        status.root_hydraulic_resistance_mpa_m2_leaf_s_per_mmol,
        T,
        :root_hydraulic_resistance_mpa_m2_leaf_s_per_mmol,
    )
    _validate_root_hydraulic_output_scalar(
        status.minimum_root_water_potential_mpa,
        T,
        :minimum_root_water_potential_mpa,
    )
    _validate_root_hydraulic_output_scalar(
        status.minimum_leaf_water_potential_mpa,
        T,
        :minimum_leaf_water_potential_mpa,
    )
    _validate_root_hydraulic_output_scalar(
        status.plant_hydraulic_conductance_scaling_exponent,
        T,
        :plant_hydraulic_conductance_scaling_exponent,
    )
    _validate_root_hydraulic_output_scalar(
        status.root_front_depth_m,
        T,
        :root_front_depth_m,
    )
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPARootHydraulicTrajectory,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.fine_root_radius_m)
    T <: AbstractFloat || _throw_root_hydraulic_output_type(:fine_root_radius_m)
    _reset_root_hydraulic_trajectory!(status, T)
    _validate_root_hydraulic_outputs(model, status, T)

    active = status.root_hydraulic_trajectory_active
    available = status.root_hydraulic_trajectory_inputs_available
    active isa Bool || throw(
        ArgumentError("root_hydraulic_trajectory_active must be Bool"),
    )
    available isa Bool || throw(
        ArgumentError("root_hydraulic_trajectory_inputs_available must be Bool"),
    )
    active && available || return nothing

    date50 = _root_hydraulic_integer(status.date50, :date50)
    simulation_day = _root_hydraulic_integer(status.simulation_day, :simulation_day)
    simulation_day >= 0 || _throw_root_hydraulic_integer(
        :simulation_day,
        simulation_day,
        :negative,
    )
    species_index = _root_hydraulic_integer(status.species_index, :species_index)
    1 <= species_index <= model.root_parameters.species_count || throw(
        BoundsError(model.root_parameters.root_layer_fractions, species_index),
    )

    _publish_root_hydraulic_trajectory!(
        model,
        status,
        date50,
        simulation_day,
        species_index,
    )
    return nothing
end
