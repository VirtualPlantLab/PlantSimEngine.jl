PlantSimEngine.@process "leaf_hydraulic_stomatal_constraint" verbose = false

"""
Result of MAESPA's daylight Emax constraint for a non-Tuzet leaf.

Flux and conductance units follow the executable `PSTRANSP` branch:

- assimilation: µmol CO₂ m⁻² leaf s⁻¹;
- stomatal conductance: mol CO₂ or H₂O m⁻² leaf s⁻¹;
- transpiration demand and maximum supply: mmol H₂O m⁻² leaf s⁻¹;
- water potential: MPa.

`potential_transpiration_demand_mmol_h2o_m2_s` is historical `ETEST`. It is
computed from the conductance after the `GSMIN` floor but before the Emax
reduction, and is deliberately not recomputed afterward. Likewise,
`soil_water_stomatal_modifier` is the historical output diagnostic `FSOIL`:
one when supply does not bind, otherwise `EMAXLEAF / ETEST` evaluated before
the conductance reduction.

The two limiting-assimilation fields retain an executable asymmetry in the
legacy code. Under hydraulic limitation the Rubisco solution uses coefficients
from which `RD` was removed by immediately following assignments, whereas the
electron-transport solution still includes `RD`. They are therefore not both
described as gross assimilation.
"""
struct LeafHydraulicStomatalConstraintResult{T<:AbstractFloat}
    potential_transpiration_demand_mmol_h2o_m2_s::T
    pre_penman_leaf_water_potential_mpa::T
    soil_water_stomatal_modifier::T
    stomatal_conductance_co2_mol_m2_s::T
    stomatal_conductance_h2o_mol_m2_s::T
    net_assimilation_umol_co2_m2_s::T
    intercellular_co2_umol_mol::T
    rubisco_limited_assimilation_umol_co2_m2_s::T
    electron_transport_limited_assimilation_umol_co2_m2_s::T
    hydraulic_limitation_applied::Bool
    minimum_conductance_floor_applied::Bool
end

"""
    MAESPALeafHydraulicStomatalConstraint(T=Float64; kwargs...)

PlantSimEngine model for the branch executed only when all of the following
legacy conditions hold: MAESPA water balance is active (`ISMAESPA`),
`WSOILMETHOD == 1`, and the stomatal model is not Tuzet (`MODELGS != 6`). The
composition layer must expose that conjunction through
`emax_non_tuzet_constraint_active`; this process does not solve `PSILFIND`,
leaf temperature, or Penman--Monteith evapotranspiration.

`standard_atmospheric_pressure_pa=101250` preserves the branch's use of the
hard-coded `PATM`, even though `PSTRANSP` also receives a measured pressure.
`water_to_co2_conductance_ratio=1.57` is legacy `GSVGSC`.
"""
struct MAESPALeafHydraulicStomatalConstraint{T<:AbstractFloat} <:
       AbstractLeaf_Hydraulic_Stomatal_ConstraintModel
    standard_atmospheric_pressure_pa::T
    water_to_co2_conductance_ratio::T
end

@noinline function _throw_leaf_hydraulic_constraint_numeric(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :solution
        throw(DomainError(value, "the hydraulic stomatal solution must be finite"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _leaf_hydraulic_constraint_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real ||
        _throw_leaf_hydraulic_constraint_numeric(name, value, :real)
    value isa Bool &&
        _throw_leaf_hydraulic_constraint_numeric(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_leaf_hydraulic_constraint_numeric(name, converted, :finite)
    return converted
end

@inline function _leaf_hydraulic_constraint_nonnegative(
    value::T,
    name::Symbol,
) where {T}
    value >= zero(T) ||
        _throw_leaf_hydraulic_constraint_numeric(name, value, :nonnegative)
    return value
end

@inline function _leaf_hydraulic_constraint_positive(
    value::T,
    name::Symbol,
) where {T}
    value > zero(T) ||
        _throw_leaf_hydraulic_constraint_numeric(name, value, :positive)
    return value
end

function MAESPALeafHydraulicStomatalConstraint(
    ::Type{T}=Float64;
    standard_atmospheric_pressure_pa=101250,
    water_to_co2_conductance_ratio=1.57,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the hydraulic-constraint numeric type must be concrete"),
    )
    pressure = _leaf_hydraulic_constraint_positive(
        _leaf_hydraulic_constraint_float(
            T,
            standard_atmospheric_pressure_pa,
            :standard_atmospheric_pressure_pa,
        ),
        :standard_atmospheric_pressure_pa,
    )
    ratio = _leaf_hydraulic_constraint_positive(
        _leaf_hydraulic_constraint_float(
            T,
            water_to_co2_conductance_ratio,
            :water_to_co2_conductance_ratio,
        ),
        :water_to_co2_conductance_ratio,
    )
    return MAESPALeafHydraulicStomatalConstraint{T}(pressure, ratio)
end

# Literal QUADM behavior: return the smaller root; imaginary and completely
# degenerate equations return zero. This intentionally uses the same naive
# quadratic expression as the REAL(4) oracle rather than a stabilized rewrite.
@inline function _leaf_hydraulic_constraint_smaller_root(
    a::T,
    b::T,
    c::T,
) where {T<:AbstractFloat}
    discriminant = b * b - T(4) * a * c
    discriminant < zero(T) && return zero(T)
    if iszero(a)
        return iszero(b) ? zero(T) : -c / b
    end
    return (-b - sqrt(discriminant)) / (T(2) * a)
end

@inline function _validate_leaf_hydraulic_constraint_inputs(
    preconstraint_net_assimilation_umol_co2_m2_s::T,
    preconstraint_stomatal_conductance_co2_mol_m2_s::T,
    preconstraint_rubisco_limited_assimilation_umol_co2_m2_s::T,
    preconstraint_electron_transport_limited_assimilation_umol_co2_m2_s::T,
    vapour_pressure_deficit_pa::T,
    surface_co2_umol_mol::T,
    gamma_star_umol_mol::T,
    rubisco_michaelis_menten_umol_mol::T,
    vcmax_umol_m2_s::T,
    electron_transport_limited_capacity_umol_m2_s::T,
    rd_umol_m2_s::T,
    minimum_stomatal_conductance_mol_co2_m2_s::T,
    weighted_soil_water_potential_mpa::T,
    soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa::T,
    maximum_leaf_transpiration_mmol_m2_leaf_s::T,
) where {T<:AbstractFloat}
    # Assimilation can be negative below compensation; it only needs to be
    # finite, which conversion has already established.
    preconstraint_net_assimilation_umol_co2_m2_s
    preconstraint_rubisco_limited_assimilation_umol_co2_m2_s
    preconstraint_electron_transport_limited_assimilation_umol_co2_m2_s
    weighted_soil_water_potential_mpa

    _leaf_hydraulic_constraint_nonnegative(
        preconstraint_stomatal_conductance_co2_mol_m2_s,
        :preconstraint_stomatal_conductance_co2_mol_m2_s,
    )
    _leaf_hydraulic_constraint_nonnegative(
        vapour_pressure_deficit_pa,
        :vapour_pressure_deficit_pa,
    )
    _leaf_hydraulic_constraint_positive(surface_co2_umol_mol, :surface_co2_umol_mol)
    _leaf_hydraulic_constraint_nonnegative(
        gamma_star_umol_mol,
        :gamma_star_umol_mol,
    )
    _leaf_hydraulic_constraint_positive(
        rubisco_michaelis_menten_umol_mol,
        :rubisco_michaelis_menten_umol_mol,
    )
    _leaf_hydraulic_constraint_nonnegative(vcmax_umol_m2_s, :vcmax_umol_m2_s)
    _leaf_hydraulic_constraint_nonnegative(
        electron_transport_limited_capacity_umol_m2_s,
        :electron_transport_limited_capacity_umol_m2_s,
    )
    _leaf_hydraulic_constraint_nonnegative(rd_umol_m2_s, :rd_umol_m2_s)
    _leaf_hydraulic_constraint_nonnegative(
        minimum_stomatal_conductance_mol_co2_m2_s,
        :minimum_stomatal_conductance_mol_co2_m2_s,
    )
    _leaf_hydraulic_constraint_positive(
        soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        :soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
    )
    _leaf_hydraulic_constraint_nonnegative(
        maximum_leaf_transpiration_mmol_m2_leaf_s,
        :maximum_leaf_transpiration_mmol_m2_leaf_s,
    )
    return nothing
end

@inline function _leaf_hydraulic_stomatal_constraint(
    model::MAESPALeafHydraulicStomatalConstraint,
    ::Type{T},
    preconstraint_net_assimilation_umol_co2_m2_s::T,
    preconstraint_stomatal_conductance_co2_mol_m2_s::T,
    preconstraint_rubisco_limited_assimilation_umol_co2_m2_s::T,
    preconstraint_electron_transport_limited_assimilation_umol_co2_m2_s::T,
    vapour_pressure_deficit_pa::T,
    surface_co2_umol_mol::T,
    gamma_star_umol_mol::T,
    rubisco_michaelis_menten_umol_mol::T,
    vcmax_umol_m2_s::T,
    electron_transport_limited_capacity_umol_m2_s::T,
    rd_umol_m2_s::T,
    minimum_stomatal_conductance_mol_co2_m2_s::T,
    weighted_soil_water_potential_mpa::T,
    soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa::T,
    maximum_leaf_transpiration_mmol_m2_leaf_s::T,
) where {T<:AbstractFloat}
    _validate_leaf_hydraulic_constraint_inputs(
        preconstraint_net_assimilation_umol_co2_m2_s,
        preconstraint_stomatal_conductance_co2_mol_m2_s,
        preconstraint_rubisco_limited_assimilation_umol_co2_m2_s,
        preconstraint_electron_transport_limited_assimilation_umol_co2_m2_s,
        vapour_pressure_deficit_pa,
        surface_co2_umol_mol,
        gamma_star_umol_mol,
        rubisco_michaelis_menten_umol_mol,
        vcmax_umol_m2_s,
        electron_transport_limited_capacity_umol_m2_s,
        rd_umol_m2_s,
        minimum_stomatal_conductance_mol_co2_m2_s,
        weighted_soil_water_potential_mpa,
        soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        maximum_leaf_transpiration_mmol_m2_leaf_s,
    )

    pressure = _leaf_hydraulic_constraint_positive(
        _leaf_hydraulic_constraint_float(
            T,
            model.standard_atmospheric_pressure_pa,
            :standard_atmospheric_pressure_pa,
        ),
        :standard_atmospheric_pressure_pa,
    )
    conductance_ratio = _leaf_hydraulic_constraint_positive(
        _leaf_hydraulic_constraint_float(
            T,
            model.water_to_co2_conductance_ratio,
            :water_to_co2_conductance_ratio,
        ),
        :water_to_co2_conductance_ratio,
    )

    conductance_co2 = max(
        preconstraint_stomatal_conductance_co2_mol_m2_s,
        minimum_stomatal_conductance_mol_co2_m2_s,
    )
    floor_applied =
        preconstraint_stomatal_conductance_co2_mol_m2_s <
        minimum_stomatal_conductance_mol_co2_m2_s
    demand =
        T(1000) * (vapour_pressure_deficit_pa / pressure) * conductance_co2 *
        conductance_ratio
    leaf_water_potential =
        weighted_soil_water_potential_mpa -
        demand / soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa

    soil_modifier = one(T)
    net_assimilation = preconstraint_net_assimilation_umol_co2_m2_s
    rubisco_limited =
        preconstraint_rubisco_limited_assimilation_umol_co2_m2_s
    electron_limited =
        preconstraint_electron_transport_limited_assimilation_umol_co2_m2_s
    limited = demand > maximum_leaf_transpiration_mmol_m2_leaf_s

    if limited
        soil_modifier = maximum_leaf_transpiration_mmol_m2_leaf_s / demand

        # GSV is first computed from EMAX and VPD, then converted back to GSC.
        # The strict demand test proves VPD > 0 here. If GSMIN binds afterward,
        # legacy FSOIL and ETEST remain based on the pre-reduction demand.
        conductance_h2o =
            T(1e-3) * maximum_leaf_transpiration_mmol_m2_leaf_s /
            (vapour_pressure_deficit_pa / pressure)
        unconstrained_floor_conductance_co2 = conductance_h2o / conductance_ratio
        floor_applied |=
            unconstrained_floor_conductance_co2 <
            minimum_stomatal_conductance_mol_co2_m2_s
        conductance_co2 = max(
            unconstrained_floor_conductance_co2,
            minimum_stomatal_conductance_mol_co2_m2_s,
        )
        # GSMIN may legitimately be zero when no hydraulic reduction occurs.
        # A binding zero EMAX with a zero floor would make the legacy 1/GSC
        # quadratics undefined, so reject only that actually singular state.
        _leaf_hydraulic_constraint_positive(
            conductance_co2,
            :constrained_stomatal_conductance_co2_mol_m2_s,
        )

        inverse_conductance = one(T) / conductance_co2

        # PSTRANSP first assigns RD-aware Rubisco coefficients, then overwrites
        # all three before QUADM. Only these effective, respiration-free lines
        # can affect AC and are therefore the ones evaluated here.
        a = inverse_conductance
        b = (zero(T) - vcmax_umol_m2_s) / conductance_co2 -
            surface_co2_umol_mol - rubisco_michaelis_menten_umol_mol
        c = vcmax_umol_m2_s *
            (surface_co2_umol_mol - gamma_star_umol_mol)
        rubisco_limited = _leaf_hydraulic_constraint_smaller_root(a, b, c)

        # By contrast the executable AJ coefficients retain RD. ALEAF is the
        # minimum of these two unlike the unconstrained branch, where RD was
        # subtracted after choosing between gross AC and AJ.
        twice_gamma = T(2) * gamma_star_umol_mol
        a = inverse_conductance
        b = (rd_umol_m2_s - electron_transport_limited_capacity_umol_m2_s) /
            conductance_co2 - surface_co2_umol_mol - twice_gamma
        c = electron_transport_limited_capacity_umol_m2_s *
            (surface_co2_umol_mol - gamma_star_umol_mol) -
            rd_umol_m2_s * (surface_co2_umol_mol + twice_gamma)
        electron_limited = _leaf_hydraulic_constraint_smaller_root(a, b, c)
        net_assimilation = min(rubisco_limited, electron_limited)
    end

    intercellular_co2 = if conductance_co2 > zero(T) && net_assimilation > zero(T)
        surface_co2_umol_mol - net_assimilation / conductance_co2
    else
        surface_co2_umol_mol
    end
    conductance_h2o = conductance_ratio * conductance_co2

    values = (
        demand,
        leaf_water_potential,
        soil_modifier,
        conductance_co2,
        conductance_h2o,
        net_assimilation,
        intercellular_co2,
        rubisco_limited,
        electron_limited,
    )
    all(isfinite, values) || _throw_leaf_hydraulic_constraint_numeric(
        :leaf_hydraulic_stomatal_constraint,
        values,
        :solution,
    )
    return LeafHydraulicStomatalConstraintResult{T}(
        values...,
        limited,
        floor_applied,
    )
end

"""
    leaf_hydraulic_stomatal_constraint(model; inputs...)

Apply the isolated daytime `PSTRANSP` Emax branch after fixed-temperature
photosynthesis and stomatal coupling have supplied the unconstrained
conductance and assimilation. `electron_transport_limited_capacity_umol_m2_s`
is legacy `VJ = J / 4`, not `JMAX`.

Calling this function means the exact legacy activation condition
`ISMAESPA && WSOILMETHOD == 1 && MODELGS != 6` is true. The PlantSimEngine
wrapper additionally carries `emax_non_tuzet_constraint_active` so a composed
scenario can gate the process without publishing misleading zero diagnostics.
"""
function leaf_hydraulic_stomatal_constraint(
    model::MAESPALeafHydraulicStomatalConstraint;
    preconstraint_net_assimilation_umol_co2_m2_s,
    preconstraint_stomatal_conductance_co2_mol_m2_s,
    preconstraint_rubisco_limited_assimilation_umol_co2_m2_s,
    preconstraint_electron_transport_limited_assimilation_umol_co2_m2_s,
    vapour_pressure_deficit_pa,
    surface_co2_umol_mol,
    gamma_star_umol_mol,
    rubisco_michaelis_menten_umol_mol,
    vcmax_umol_m2_s,
    electron_transport_limited_capacity_umol_m2_s,
    rd_umol_m2_s,
    minimum_stomatal_conductance_mol_co2_m2_s,
    weighted_soil_water_potential_mpa,
    soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
    maximum_leaf_transpiration_mmol_m2_leaf_s,
)
    raw_values = (
        preconstraint_net_assimilation_umol_co2_m2_s,
        preconstraint_stomatal_conductance_co2_mol_m2_s,
        preconstraint_rubisco_limited_assimilation_umol_co2_m2_s,
        preconstraint_electron_transport_limited_assimilation_umol_co2_m2_s,
        vapour_pressure_deficit_pa,
        surface_co2_umol_mol,
        gamma_star_umol_mol,
        rubisco_michaelis_menten_umol_mol,
        vcmax_umol_m2_s,
        electron_transport_limited_capacity_umol_m2_s,
        rd_umol_m2_s,
        minimum_stomatal_conductance_mol_co2_m2_s,
        weighted_soil_water_potential_mpa,
        soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        maximum_leaf_transpiration_mmol_m2_leaf_s,
    )
    names = (
        :preconstraint_net_assimilation_umol_co2_m2_s,
        :preconstraint_stomatal_conductance_co2_mol_m2_s,
        :preconstraint_rubisco_limited_assimilation_umol_co2_m2_s,
        :preconstraint_electron_transport_limited_assimilation_umol_co2_m2_s,
        :vapour_pressure_deficit_pa,
        :surface_co2_umol_mol,
        :gamma_star_umol_mol,
        :rubisco_michaelis_menten_umol_mol,
        :vcmax_umol_m2_s,
        :electron_transport_limited_capacity_umol_m2_s,
        :rd_umol_m2_s,
        :minimum_stomatal_conductance_mol_co2_m2_s,
        :weighted_soil_water_potential_mpa,
        :soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        :maximum_leaf_transpiration_mmol_m2_leaf_s,
    )
    for index in eachindex(raw_values)
        value = raw_values[index]
        value isa Real || _throw_leaf_hydraulic_constraint_numeric(
            names[index],
            value,
            :real,
        )
        value isa Bool && _throw_leaf_hydraulic_constraint_numeric(
            names[index],
            value,
            :bool,
        )
        isfinite(value) || _throw_leaf_hydraulic_constraint_numeric(
            names[index],
            value,
            :finite,
        )
    end
    promoted = promote(
        model.standard_atmospheric_pressure_pa,
        model.water_to_co2_conductance_ratio,
        map(float, raw_values)...,
    )
    T = typeof(first(promoted))
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "hydraulic-stomatal-constraint inputs must promote to an AbstractFloat",
        ),
    )
    return _leaf_hydraulic_stomatal_constraint(
        model,
        T,
        promoted[3:end]...,
    )
end

PlantSimEngine.variable_contracts_(::MAESPALeafHydraulicStomatalConstraint) = (
    weighted_soil_water_potential_mpa=EFFECTIVE_SOIL_WATER_POTENTIAL_CONTRACT,
    soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa=LEAF_HYDRAULIC_CONDUCTANCE_CONTRACT,
    maximum_leaf_transpiration_mmol_m2_leaf_s=LEAF_WATER_SUPPLY_CAPACITY_CONTRACT,
    soil_to_leaf_hydraulic_supply_available=LEAF_HYDRAULIC_SUPPLY_AVAILABLE_CONTRACT,
)

PlantSimEngine.inputs_(::MAESPALeafHydraulicStomatalConstraint) = (
    preconstraint_net_assimilation_umol_co2_m2_s=PlantSimEngine.Required(Real),
    preconstraint_stomatal_conductance_co2_mol_m2_s=PlantSimEngine.Required(Real),
    preconstraint_rubisco_limited_assimilation_umol_co2_m2_s=
        PlantSimEngine.Required(Real),
    preconstraint_electron_transport_limited_assimilation_umol_co2_m2_s=
        PlantSimEngine.Required(Real),
    vapour_pressure_deficit_pa=PlantSimEngine.Required(Real),
    surface_co2_umol_mol=PlantSimEngine.Required(Real),
    gamma_star_umol_mol=PlantSimEngine.Required(Real),
    rubisco_michaelis_menten_umol_mol=PlantSimEngine.Required(Real),
    vcmax_umol_m2_s=PlantSimEngine.Required(Real),
    electron_transport_limited_capacity_umol_m2_s=PlantSimEngine.Required(Real),
    rd_umol_m2_s=PlantSimEngine.Required(Real),
    minimum_stomatal_conductance_mol_co2_m2_s=PlantSimEngine.Required(Real),
    weighted_soil_water_potential_mpa=PlantSimEngine.Required(Real),
    soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa=
        PlantSimEngine.Required(Real),
    maximum_leaf_transpiration_mmol_m2_leaf_s=PlantSimEngine.Required(Real),
    emax_non_tuzet_constraint_active=PlantSimEngine.Required(Bool),
    stomatal_photosynthesis_coupling_available=PlantSimEngine.Required(Bool),
    soil_to_leaf_hydraulic_supply_available=PlantSimEngine.Required(Bool),
)

PlantSimEngine.outputs_(
    ::MAESPALeafHydraulicStomatalConstraint{T},
) where {T} = (
    potential_transpiration_demand_mmol_h2o_m2_s=zero(T),
    pre_penman_leaf_water_potential_mpa=zero(T),
    soil_water_stomatal_modifier=zero(T),
    stomatal_conductance_co2_mol_m2_s=zero(T),
    stomatal_conductance_h2o_mol_m2_s=zero(T),
    net_assimilation_umol_co2_m2_s=zero(T),
    intercellular_co2_umol_mol=zero(T),
    rubisco_limited_assimilation_umol_co2_m2_s=zero(T),
    electron_transport_limited_assimilation_umol_co2_m2_s=zero(T),
    hydraulic_limitation_applied=false,
    minimum_conductance_floor_applied=false,
    leaf_hydraulic_stomatal_constraint_available=false,
)

@inline function _reset_leaf_hydraulic_stomatal_constraint!(
    status,
    ::Type{T},
) where {T}
    status.potential_transpiration_demand_mmol_h2o_m2_s = zero(T)
    status.pre_penman_leaf_water_potential_mpa = zero(T)
    status.soil_water_stomatal_modifier = zero(T)
    status.stomatal_conductance_co2_mol_m2_s = zero(T)
    status.stomatal_conductance_h2o_mol_m2_s = zero(T)
    status.net_assimilation_umol_co2_m2_s = zero(T)
    status.intercellular_co2_umol_mol = zero(T)
    status.rubisco_limited_assimilation_umol_co2_m2_s = zero(T)
    status.electron_transport_limited_assimilation_umol_co2_m2_s = zero(T)
    status.hydraulic_limitation_applied = false
    status.minimum_conductance_floor_applied = false
    status.leaf_hydraulic_stomatal_constraint_available = false
    return nothing
end

@noinline function _throw_leaf_hydraulic_constraint_output_type(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and hydraulic-constraint output carriers must " *
            "share a floating-point type",
        ),
    )
end

@inline function _validate_leaf_hydraulic_constraint_output_type(
    value,
    ::Type{T},
    name::Symbol,
) where {T}
    typeof(value) === T || _throw_leaf_hydraulic_constraint_output_type(name)
    return nothing
end


function PlantSimEngine.run!(
    model::MAESPALeafHydraulicStomatalConstraint,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.potential_transpiration_demand_mmol_h2o_m2_s)
    T <: AbstractFloat || _throw_leaf_hydraulic_constraint_output_type(
        :potential_transpiration_demand_mmol_h2o_m2_s,
    )
    _reset_leaf_hydraulic_stomatal_constraint!(status, T)
    _validate_leaf_hydraulic_constraint_output_type(
        status.pre_penman_leaf_water_potential_mpa,
        T,
        :pre_penman_leaf_water_potential_mpa,
    )
    _validate_leaf_hydraulic_constraint_output_type(
        status.soil_water_stomatal_modifier,
        T,
        :soil_water_stomatal_modifier,
    )
    _validate_leaf_hydraulic_constraint_output_type(
        status.stomatal_conductance_co2_mol_m2_s,
        T,
        :stomatal_conductance_co2_mol_m2_s,
    )
    _validate_leaf_hydraulic_constraint_output_type(
        status.stomatal_conductance_h2o_mol_m2_s,
        T,
        :stomatal_conductance_h2o_mol_m2_s,
    )
    _validate_leaf_hydraulic_constraint_output_type(
        status.net_assimilation_umol_co2_m2_s,
        T,
        :net_assimilation_umol_co2_m2_s,
    )
    _validate_leaf_hydraulic_constraint_output_type(
        status.intercellular_co2_umol_mol,
        T,
        :intercellular_co2_umol_mol,
    )
    _validate_leaf_hydraulic_constraint_output_type(
        status.rubisco_limited_assimilation_umol_co2_m2_s,
        T,
        :rubisco_limited_assimilation_umol_co2_m2_s,
    )
    _validate_leaf_hydraulic_constraint_output_type(
        status.electron_transport_limited_assimilation_umol_co2_m2_s,
        T,
        :electron_transport_limited_assimilation_umol_co2_m2_s,
    )

    active = status.emax_non_tuzet_constraint_active
    stomatal_available = status.stomatal_photosynthesis_coupling_available
    hydraulic_available = status.soil_to_leaf_hydraulic_supply_available
    active isa Bool || throw(
        ArgumentError("emax_non_tuzet_constraint_active must be Bool"),
    )
    stomatal_available isa Bool || throw(
        ArgumentError("stomatal_photosynthesis_coupling_available must be Bool"),
    )
    hydraulic_available isa Bool || throw(
        ArgumentError("soil_to_leaf_hydraulic_supply_available must be Bool"),
    )
    active && stomatal_available && hydraulic_available || return nothing

    result = _leaf_hydraulic_stomatal_constraint(
        model,
        T,
        _leaf_hydraulic_constraint_float(
            T,
            status.preconstraint_net_assimilation_umol_co2_m2_s,
            :preconstraint_net_assimilation_umol_co2_m2_s,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.preconstraint_stomatal_conductance_co2_mol_m2_s,
            :preconstraint_stomatal_conductance_co2_mol_m2_s,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.preconstraint_rubisco_limited_assimilation_umol_co2_m2_s,
            :preconstraint_rubisco_limited_assimilation_umol_co2_m2_s,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.preconstraint_electron_transport_limited_assimilation_umol_co2_m2_s,
            :preconstraint_electron_transport_limited_assimilation_umol_co2_m2_s,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.vapour_pressure_deficit_pa,
            :vapour_pressure_deficit_pa,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.surface_co2_umol_mol,
            :surface_co2_umol_mol,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.gamma_star_umol_mol,
            :gamma_star_umol_mol,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.rubisco_michaelis_menten_umol_mol,
            :rubisco_michaelis_menten_umol_mol,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.vcmax_umol_m2_s,
            :vcmax_umol_m2_s,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.electron_transport_limited_capacity_umol_m2_s,
            :electron_transport_limited_capacity_umol_m2_s,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.rd_umol_m2_s,
            :rd_umol_m2_s,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.minimum_stomatal_conductance_mol_co2_m2_s,
            :minimum_stomatal_conductance_mol_co2_m2_s,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.weighted_soil_water_potential_mpa,
            :weighted_soil_water_potential_mpa,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
            :soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        ),
        _leaf_hydraulic_constraint_float(
            T,
            status.maximum_leaf_transpiration_mmol_m2_leaf_s,
            :maximum_leaf_transpiration_mmol_m2_leaf_s,
        ),
    )

    status.potential_transpiration_demand_mmol_h2o_m2_s =
        result.potential_transpiration_demand_mmol_h2o_m2_s
    status.pre_penman_leaf_water_potential_mpa =
        result.pre_penman_leaf_water_potential_mpa
    status.soil_water_stomatal_modifier = result.soil_water_stomatal_modifier
    status.stomatal_conductance_co2_mol_m2_s =
        result.stomatal_conductance_co2_mol_m2_s
    status.stomatal_conductance_h2o_mol_m2_s =
        result.stomatal_conductance_h2o_mol_m2_s
    status.net_assimilation_umol_co2_m2_s =
        result.net_assimilation_umol_co2_m2_s
    status.intercellular_co2_umol_mol = result.intercellular_co2_umol_mol
    status.rubisco_limited_assimilation_umol_co2_m2_s =
        result.rubisco_limited_assimilation_umol_co2_m2_s
    status.electron_transport_limited_assimilation_umol_co2_m2_s =
        result.electron_transport_limited_assimilation_umol_co2_m2_s
    status.hydraulic_limitation_applied = result.hydraulic_limitation_applied
    status.minimum_conductance_floor_applied =
        result.minimum_conductance_floor_applied
    status.leaf_hydraulic_stomatal_constraint_available = true
    return nothing
end
