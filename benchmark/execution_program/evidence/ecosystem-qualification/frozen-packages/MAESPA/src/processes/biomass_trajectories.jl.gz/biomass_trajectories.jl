PlantSimEngine.@process "woody_biomass_trajectory" verbose = false
PlantSimEngine.@process "foliage_biomass_trajectory" verbose = false

"""Current biomass and its change since the preceding simulation day."""
struct BiomassTrajectoryResult{T<:AbstractFloat}
    biomass_kg_dry_matter_tree::T
    biomass_increment_g_dry_matter_tree_day::T
end

@noinline function _throw_biomass_trajectory_numeric(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :result
        throw(DomainError(value, "$label must be finite and non-negative"))
    elseif reason === :increment
        throw(DomainError(value, "$label must be finite"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _biomass_trajectory_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real || _throw_biomass_trajectory_numeric(name, value, :real)
    value isa Bool && _throw_biomass_trajectory_numeric(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_biomass_trajectory_numeric(name, converted, :finite)
    return converted
end

@inline function _biomass_simulation_day(simulation_day)
    simulation_day isa Integer ||
        throw(ArgumentError("simulation_day must be an integer"))
    simulation_day isa Bool &&
        throw(ArgumentError("simulation_day must be an integer, not Bool"))
    simulation_day >= 0 ||
        throw(DomainError(simulation_day, "simulation_day must be non-negative"))
    return Int(simulation_day)
end

@inline function _biomass_trajectory_result(
    ::Type{T},
    biomass_kg_dry_matter_tree::T,
    previous_biomass_kg_dry_matter_tree,
    simulation_day::Int,
) where {T<:AbstractFloat}
    previous_biomass = if simulation_day == 0
        # CALCWBIOM/CALCFBIOM overwrite PREV*BIOM on IDAY=0. In particular,
        # the caller does not need a meaningful pre-simulation biomass value.
        biomass_kg_dry_matter_tree
    else
        value = _biomass_trajectory_float(
            T,
            previous_biomass_kg_dry_matter_tree,
            :previous_biomass_kg_dry_matter_tree,
        )
        value >= zero(T) || _throw_biomass_trajectory_numeric(
            :previous_biomass_kg_dry_matter_tree,
            value,
            :nonnegative,
        )
        value
    end
    increment = (biomass_kg_dry_matter_tree - previous_biomass) * T(1000)
    isfinite(increment) || _throw_biomass_trajectory_numeric(
        :biomass_increment_g_dry_matter_tree_day,
        increment,
        :increment,
    )
    return BiomassTrajectoryResult(biomass_kg_dry_matter_tree, increment)
end

"""
    MAESPAWoodyBiomassTrajectory(equation)

PlantSimEngine implementation of MAESPA's historical `CALCWBIOM` routine.
The allometric equation is fixed for one structural component (stem, branches,
or coarse roots); height, diameter, simulation day, and preceding biomass are
runtime status values.

`previous_woody_biomass_kg_dry_matter_tree` is deliberately an input. In a
multi-step `CompositeModel`, bind it to
`woody_biomass_kg_dry_matter_tree` from the same application with
`PreviousTimeStep`. Its typed zero default only bootstraps the temporal
carrier; `simulation_day == 0` replaces it with the newly calculated biomass,
so the first increment is zero exactly as in `IDAY=0`.
"""
struct MAESPAWoodyBiomassTrajectory{T<:AbstractFloat} <:
       AbstractWoody_Biomass_TrajectoryModel
    equation::AllometricEquation{T}

    function MAESPAWoodyBiomassTrajectory(
        equation::AllometricEquation{T},
    ) where {T<:AbstractFloat}
        isconcretetype(T) || throw(
            ArgumentError("the woody-biomass numeric type must be concrete"),
        )
        for (name, value) in (
            (:allometric_coefficient, equation.coefficient),
            (:allometric_diameter_exponent, equation.diameter_exponent),
            (:allometric_intercept, equation.intercept),
        )
            isfinite(value) ||
                _throw_biomass_trajectory_numeric(name, value, :finite)
        end
        return new{T}(equation)
    end
end

@inline function _woody_biomass_trajectory(
    equation::AllometricEquation,
    ::Type{T},
    tree_height,
    stem_diameter,
    previous_biomass_kg_dry_matter_tree,
    simulation_day,
) where {T<:AbstractFloat}
    isconcretetype(T) ||
        throw(ArgumentError("the woody-biomass numeric type must be concrete"))
    day = _biomass_simulation_day(simulation_day)
    height = _biomass_trajectory_float(T, tree_height, :tree_height)
    diameter =
        _biomass_trajectory_float(T, stem_diameter, :stem_diameter)
    height >= zero(T) ||
        _throw_biomass_trajectory_numeric(:tree_height, height, :nonnegative)
    diameter >= zero(T) || _throw_biomass_trajectory_numeric(
        :stem_diameter,
        diameter,
        :nonnegative,
    )

    typed_equation = AllometricEquation{T}(
        _biomass_trajectory_float(
            T,
            equation.coefficient,
            :allometric_coefficient,
        ),
        _biomass_trajectory_float(
            T,
            equation.diameter_exponent,
            :allometric_diameter_exponent,
        ),
        _biomass_trajectory_float(
            T,
            equation.intercept,
            :allometric_intercept,
        ),
    )
    biomass = allometric_biomass(typed_equation, height, diameter)
    isfinite(biomass) && biomass >= zero(T) ||
        _throw_biomass_trajectory_numeric(
            :woody_biomass_kg_dry_matter_tree,
            biomass,
            :result,
        )
    return _biomass_trajectory_result(
        T,
        biomass,
        previous_biomass_kg_dry_matter_tree,
        day,
    )
end

"""
    woody_biomass_trajectory(equation, height, diameter, previous_biomass;
                             simulation_day=1)

Reproduce `CALCWBIOM`: evaluate
`coefficient * height * diameter^exponent + intercept` in the equation's
numeric type, return biomass in kg dry matter tree⁻¹, and convert its daily
change to g dry matter tree⁻¹ day⁻¹. On simulation day zero the increment is
zero independently of `previous_biomass`.
"""
function woody_biomass_trajectory(
    equation::AllometricEquation{T},
    tree_height::Real,
    stem_diameter::Real,
    previous_biomass_kg_dry_matter_tree::Real;
    simulation_day::Integer=1,
) where {T<:AbstractFloat}
    return _woody_biomass_trajectory(
        equation,
        T,
        tree_height,
        stem_diameter,
        previous_biomass_kg_dry_matter_tree,
        simulation_day,
    )
end

PlantSimEngine.inputs_(::MAESPAWoodyBiomassTrajectory{T}) where {T} = (
    simulation_day=PlantSimEngine.Required(Integer),
    tree_height=PlantSimEngine.Required(Real),
    stem_diameter=PlantSimEngine.Required(Real),
    previous_woody_biomass_kg_dry_matter_tree=PlantSimEngine.Default(zero(T)),
    woody_biomass_trajectory_active=PlantSimEngine.Default(true),
    woody_biomass_trajectory_inputs_available=PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(::MAESPAWoodyBiomassTrajectory{T}) where {T} = (
    woody_biomass_kg_dry_matter_tree=zero(T),
    woody_biomass_increment_g_dry_matter_tree_day=zero(T),
    woody_biomass_trajectory_available=false,
)

@inline function _reset_woody_biomass_trajectory!(status, ::Type{T}) where {T}
    status.woody_biomass_kg_dry_matter_tree = zero(T)
    status.woody_biomass_increment_g_dry_matter_tree_day = zero(T)
    status.woody_biomass_trajectory_available = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPAWoodyBiomassTrajectory,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.woody_biomass_kg_dry_matter_tree)
    T <: AbstractFloat || throw(
        ArgumentError(
            "woody_biomass_kg_dry_matter_tree must use an AbstractFloat type",
        ),
    )
    _reset_woody_biomass_trajectory!(status, T)

    active = status.woody_biomass_trajectory_active
    available = status.woody_biomass_trajectory_inputs_available
    active isa Bool ||
        throw(ArgumentError("woody_biomass_trajectory_active must be Bool"))
    available isa Bool || throw(
        ArgumentError(
            "woody_biomass_trajectory_inputs_available must be Bool",
        ),
    )
    active && available || return nothing

    result = _woody_biomass_trajectory(
        model.equation,
        T,
        status.tree_height,
        status.stem_diameter,
        status.previous_woody_biomass_kg_dry_matter_tree,
        status.simulation_day,
    )
    status.woody_biomass_kg_dry_matter_tree =
        result.biomass_kg_dry_matter_tree
    status.woody_biomass_increment_g_dry_matter_tree_day =
        result.biomass_increment_g_dry_matter_tree_day
    status.woody_biomass_trajectory_available = true
    return nothing
end

"""
    MAESPAFoliageBiomassTrajectory(T=Float64, layer_count, age_class_count)

PlantSimEngine implementation of MAESPA's historical `CALCFBIOM` routine.
The process consumes the current layer leaf areas (`FOLLAY`), a layer ×
physiological-age SLA matrix, and the physiological age proportions (`PROP`).

`specific_leaf_area_available=false` is the explicit Julia equivalent of
`NOSLADATES <= 0`: biomass and increment are both zero and the SLA value may be
`nothing`. Otherwise every active layer × age entry is accumulated in the same
loop order as the Fortran. The preceding biomass can be supplied as controlled
status or connected to this process's biomass output with `PreviousTimeStep`.

At runtime the two floating output carriers select the effective calculation
type, including after PlantSimEngine status promotion. An active-input error
leaves the preceding output snapshot untouched; a valid disabled or unavailable
generic gate instead publishes typed zeros with availability `false`.
"""
struct MAESPAFoliageBiomassTrajectory{T<:AbstractFloat} <:
       AbstractFoliage_Biomass_TrajectoryModel
    layer_count::Int
    age_class_count::Int
end

function MAESPAFoliageBiomassTrajectory(
    ::Type{T},
    layer_count::Integer,
    age_class_count::Integer,
) where {T<:AbstractFloat}
    isconcretetype(T) ||
        throw(ArgumentError("the foliage-biomass numeric type must be concrete"))
    layer_count isa Bool &&
        throw(ArgumentError("layer_count must be an integer, not Bool"))
    age_class_count isa Bool &&
        throw(ArgumentError("age_class_count must be an integer, not Bool"))
    layer_count > 0 || throw(DomainError(layer_count, "layer_count must be positive"))
    age_class_count > 0 ||
        throw(DomainError(age_class_count, "age_class_count must be positive"))
    return MAESPAFoliageBiomassTrajectory{T}(
        Int(layer_count),
        Int(age_class_count),
    )
end

MAESPAFoliageBiomassTrajectory(
    layer_count::Integer,
    age_class_count::Integer,
) = MAESPAFoliageBiomassTrajectory(Float64, layer_count, age_class_count)

@noinline function _throw_foliage_biomass_dimensions(
    name::Symbol,
    actual,
    expected,
)
    throw(
        DimensionMismatch(
            "$(String(name)) dimensions $actual must equal $expected",
        ),
    )
end

@inline function _foliage_biomass_trajectory(
    ::Type{T},
    layer_count::Int,
    age_class_count::Int,
    leaf_area_by_layer,
    specific_leaf_area_m2_kg,
    physiological_foliage_age_proportions,
    previous_biomass_kg_dry_matter_tree,
    simulation_day,
    specific_leaf_area_available,
) where {T<:AbstractFloat}
    day = _biomass_simulation_day(simulation_day)
    specific_leaf_area_available isa Bool || throw(
        ArgumentError("specific_leaf_area_available must be Bool"),
    )
    if !specific_leaf_area_available
        return BiomassTrajectoryResult(zero(T), zero(T))
    end

    leaf_area_by_layer isa AbstractVector || throw(
        ArgumentError("leaf_area_by_layer must be an AbstractVector"),
    )
    specific_leaf_area_m2_kg isa AbstractMatrix || throw(
        ArgumentError(
            "specific_leaf_area_m2_kg must be an AbstractMatrix when available",
        ),
    )
    physiological_foliage_age_proportions isa AbstractVector || throw(
        ArgumentError(
            "physiological_foliage_age_proportions must be an AbstractVector",
        ),
    )
    length(leaf_area_by_layer) == layer_count ||
        _throw_foliage_biomass_dimensions(
            :leaf_area_by_layer,
            (length(leaf_area_by_layer),),
            (layer_count,),
        )
    length(physiological_foliage_age_proportions) == age_class_count ||
        _throw_foliage_biomass_dimensions(
            :physiological_foliage_age_proportions,
            (length(physiological_foliage_age_proportions),),
            (age_class_count,),
        )
    size(specific_leaf_area_m2_kg) == (layer_count, age_class_count) ||
        _throw_foliage_biomass_dimensions(
            :specific_leaf_area_m2_kg,
            size(specific_leaf_area_m2_kg),
            (layer_count, age_class_count),
        )

    for layer in 1:layer_count
        area = _biomass_trajectory_float(
            T,
            @inbounds(leaf_area_by_layer[layer]),
            :leaf_area_by_layer,
        )
        area >= zero(T) || _throw_biomass_trajectory_numeric(
            :leaf_area_by_layer,
            area,
            :nonnegative,
        )
    end
    for age in 1:age_class_count
        proportion = _biomass_trajectory_float(
            T,
            @inbounds(physiological_foliage_age_proportions[age]),
            :physiological_foliage_age_proportions,
        )
        proportion >= zero(T) || _throw_biomass_trajectory_numeric(
            :physiological_foliage_age_proportions,
            proportion,
            :nonnegative,
        )
    end

    biomass = zero(T)
    for layer in 1:layer_count
        area = convert(T, @inbounds(leaf_area_by_layer[layer]))
        for age in 1:age_class_count
            sla = _biomass_trajectory_float(
                T,
                @inbounds(specific_leaf_area_m2_kg[layer, age]),
                :specific_leaf_area_m2_kg,
            )
            sla > zero(T) || _throw_biomass_trajectory_numeric(
                :specific_leaf_area_m2_kg,
                sla,
                :positive,
            )
            proportion = convert(
                T,
                @inbounds(physiological_foliage_age_proportions[age]),
            )
            # Preserve CALCFBIOM's FOLLAY(I)*PROP(J)/SLA(I,J) operation order.
            biomass = biomass + area * proportion / sla
        end
    end
    isfinite(biomass) && biomass >= zero(T) ||
        _throw_biomass_trajectory_numeric(
            :foliage_biomass_kg_dry_matter_tree,
            biomass,
            :result,
        )
    return _biomass_trajectory_result(
        T,
        biomass,
        previous_biomass_kg_dry_matter_tree,
        day,
    )
end

"""
    foliage_biomass_trajectory(foliage_area_by_layer, specific_leaf_area,
                               age_proportions, previous_biomass;
                               simulation_day=1,
                               specific_leaf_area_available=true)

Reproduce `CALCFBIOM` in the promoted input type. SLA is in m² kg⁻¹, biomass
is returned in kg dry matter tree⁻¹, and the increment is returned in g dry
matter tree⁻¹ day⁻¹. Setting `specific_leaf_area_available=false` reproduces
the `NOSLADATES <= 0` zero branch and permits `specific_leaf_area=nothing`.
"""
function foliage_biomass_trajectory(
    leaf_area_by_layer::AbstractVector,
    specific_leaf_area_m2_kg::Union{Nothing,AbstractMatrix},
    physiological_foliage_age_proportions::AbstractVector,
    previous_biomass_kg_dry_matter_tree::Real;
    simulation_day::Integer=1,
    specific_leaf_area_available::Bool=!isnothing(specific_leaf_area_m2_kg),
)
    element_types = if isnothing(specific_leaf_area_m2_kg)
        (
            eltype(leaf_area_by_layer),
            eltype(physiological_foliage_age_proportions),
            typeof(previous_biomass_kg_dry_matter_tree),
        )
    else
        (
            eltype(leaf_area_by_layer),
            eltype(specific_leaf_area_m2_kg),
            eltype(physiological_foliage_age_proportions),
            typeof(previous_biomass_kg_dry_matter_tree),
        )
    end
    T = float(promote_type(element_types...))
    T <: AbstractFloat || throw(
        ArgumentError("foliage biomass inputs must promote to an AbstractFloat"),
    )
    isconcretetype(T) || throw(
        ArgumentError("the foliage-biomass numeric type must be concrete"),
    )
    return _foliage_biomass_trajectory(
        T,
        length(leaf_area_by_layer),
        length(physiological_foliage_age_proportions),
        leaf_area_by_layer,
        specific_leaf_area_m2_kg,
        physiological_foliage_age_proportions,
        previous_biomass_kg_dry_matter_tree,
        simulation_day,
        specific_leaf_area_available,
    )
end

PlantSimEngine.inputs_(::MAESPAFoliageBiomassTrajectory{T}) where {T} = (
    simulation_day=PlantSimEngine.Required(Integer),
    leaf_area_by_layer=PlantSimEngine.Required(AbstractVector),
    specific_leaf_area_m2_kg=PlantSimEngine.Default(nothing),
    physiological_foliage_age_proportions=
        PlantSimEngine.Required(AbstractVector),
    previous_foliage_biomass_kg_dry_matter_tree=PlantSimEngine.Default(zero(T)),
    specific_leaf_area_available=PlantSimEngine.Default(false),
    foliage_biomass_trajectory_active=PlantSimEngine.Default(true),
    foliage_biomass_trajectory_inputs_available=PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(::MAESPAFoliageBiomassTrajectory{T}) where {T} = (
    foliage_biomass_kg_dry_matter_tree=zero(T),
    foliage_biomass_increment_g_dry_matter_tree_day=zero(T),
    foliage_biomass_trajectory_available=false,
)

@inline function _reset_foliage_biomass_trajectory!(status, ::Type{T}) where {T}
    status.foliage_biomass_kg_dry_matter_tree = zero(T)
    status.foliage_biomass_increment_g_dry_matter_tree_day = zero(T)
    status.foliage_biomass_trajectory_available = false
    return nothing
end

@inline function _foliage_biomass_trajectory_output_type(status)
    biomass = status.foliage_biomass_kg_dry_matter_tree
    T = typeof(biomass)
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "foliage_biomass_kg_dry_matter_tree must use one concrete " *
            "AbstractFloat output carrier",
        ),
    )
    increment =
        status.foliage_biomass_increment_g_dry_matter_tree_day
    typeof(increment) === T || throw(
        ArgumentError(
            "foliage_biomass_increment_g_dry_matter_tree_day must use " *
            "the same $T output carrier as foliage biomass",
        ),
    )
    status.foliage_biomass_trajectory_available isa Bool || throw(
        ArgumentError(
            "foliage_biomass_trajectory_available must use a Bool " *
            "output carrier",
        ),
    )
    return T
end

function PlantSimEngine.run!(
    model::MAESPAFoliageBiomassTrajectory,
    status,
    environment,
    constants,
    context,
)
    T = _foliage_biomass_trajectory_output_type(status)

    active = status.foliage_biomass_trajectory_active
    available = status.foliage_biomass_trajectory_inputs_available
    active isa Bool ||
        throw(ArgumentError("foliage_biomass_trajectory_active must be Bool"))
    available isa Bool || throw(
        ArgumentError(
            "foliage_biomass_trajectory_inputs_available must be Bool",
        ),
    )
    if !(active && available)
        _reset_foliage_biomass_trajectory!(status, T)
        return nothing
    end

    # The allocated result is the transaction boundary: every active input,
    # including the SLA-availability branch, is validated before any accepted
    # output carrier is changed. Under global status promotion, `T` comes from
    # the runtime output carriers rather than from the model parameter.
    result = _foliage_biomass_trajectory(
        T,
        model.layer_count,
        model.age_class_count,
        status.leaf_area_by_layer,
        status.specific_leaf_area_m2_kg,
        status.physiological_foliage_age_proportions,
        status.previous_foliage_biomass_kg_dry_matter_tree,
        status.simulation_day,
        status.specific_leaf_area_available,
    )
    status.foliage_biomass_kg_dry_matter_tree =
        result.biomass_kg_dry_matter_tree
    status.foliage_biomass_increment_g_dry_matter_tree_day =
        result.biomass_increment_g_dry_matter_tree_day
    # The NOSLADATES<=0 branch is a defined historical zero result, not a
    # missing execution. Generic active/input gates above still publish false.
    status.foliage_biomass_trajectory_available = true
    return nothing
end
