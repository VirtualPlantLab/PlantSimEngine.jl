"""
    MAESPAMeasuredPotentialRootWaterUptake(T, layer_count;
        saturated_conductivity_m_s, campbell_exponent,
        air_entry_potential_mpa, equal_uptake=false)

Historical USEMEASSW=1 / SOILDATA=POTENTIAL root hypothesis. The measured
potential (MPa, finite and negative) is sampled from the environment. Campbell's
SOILCONDFUN2 replaces top-layer conductivity; SOILRESCALC combines all fine
roots into the first radial resistance. SPA or uniform layer fractions are
retained, while leaf supply uses measured potential and that first resistance.

Conductivities are m/s; radial resistances are MPa m² ground s/mmol, and the
total resistance is multiplied by LAI to obtain MPa m² leaf s/mmol. Layer
capacities are mmol/m² ground/s. Zero LAI or no roots produces an unavailable
zeroed result instead of the undefined historical resistance.

The scenario must keep the water balance active but skip profile heat
advancement. Fixed Campbell coefficients are required even with a different
profile retention law; this is not a measured-content/deficit hypothesis.
Structured contracts for the whole root supply chain remain under migration.
"""
struct MAESPAMeasuredPotentialRootWaterUptake{T<:AbstractFloat} <: AbstractRoot_Water_UptakeModel
    layer_count::Int
    equal_uptake::Bool
    saturated_conductivity_m_s::T
    campbell_exponent::T
    air_entry_potential_mpa::T
    minimum_soil_conductivity_m_s::T
    water_partial_molar_volume_m3_mol::T
    gravitational_acceleration_m_s2::T
    legacy_pi::T
    mol_to_mmol_resistance_scale::T
    minimum_converted_soil_conductivity_mol_m_s_mpa::T
end

function MAESPAMeasuredPotentialRootWaterUptake(::Type{T}, n;
    saturated_conductivity_m_s, campbell_exponent, air_entry_potential_mpa,
    equal_uptake::Bool=false, minimum_soil_conductivity_m_s=1e-30, kwargs...) where {T<:AbstractFloat}
    p = MAESPARootWaterUptake(T, n; kwargs...)
    k, b, psi, floor = T.((saturated_conductivity_m_s, campbell_exponent,
        air_entry_potential_mpa, minimum_soil_conductivity_m_s))
    all(isfinite, (k, b, psi, floor)) || throw(ArgumentError("Campbell parameters must be finite"))
    k > 0 && b > 0 && psi < 0 && floor > 0 ||
        throw(ArgumentError("require KSAT>0, BPAR>0, PSIE<0 and conductivity floor>0"))
    return MAESPAMeasuredPotentialRootWaterUptake{T}(p.layer_count, equal_uptake,
        k, b, psi, floor, p.water_partial_molar_volume_m3_mol,
        p.gravitational_acceleration_m_s2, p.legacy_pi,
        p.mol_to_mmol_resistance_scale,
        p.minimum_converted_soil_conductivity_mol_m_s_mpa)
end

function PlantSimEngine.variable_contracts_(model::MAESPAMeasuredPotentialRootWaterUptake)
    model.equal_uptake && return ROOT_WATER_UPTAKE_OUTPUT_CONTRACTS
    return merge(ROOT_WATER_UPTAKE_OUTPUT_CONTRACTS,
        (soil_water_potential_mpa=SOIL_LAYER_WATER_POTENTIAL_CONTRACT,))
end

function PlantSimEngine.inputs_(model::MAESPAMeasuredPotentialRootWaterUptake)
    common = (
        rooted_soil_layer_indices=Required(AbstractVector),
        soil_hydraulic_conductivity_m_s=Required(AbstractVector),
        root_length_density_m_m3=Required(AbstractVector),
        soil_layer_thickness_m=Required(AbstractVector),
        fine_root_radius_m=Required(Real), total_leaf_area_index=Required(Real),
        root_water_uptake_active=Required(Bool), root_water_uptake_inputs_available=Default(true),
    )
    model.equal_uptake && return common
    return merge(common, (soil_water_potential_mpa=Required(AbstractVector),
        soil_ice_fraction=Required(AbstractVector), minimum_root_water_potential_mpa=Required(Real),
        tree_height_m=Required(Real)))
end
PlantSimEngine.environment_inputs_(::MAESPAMeasuredPotentialRootWaterUptake{T}) where {T} =
    (measured_soil_water_potential_mpa=T(NaN),)
PlantSimEngine.outputs_(model::MAESPAMeasuredPotentialRootWaterUptake{T}) where {T} = (
    soil_to_root_hydraulic_resistance_mpa_m2_ground_s_per_mmol=zeros(T, model.layer_count),
    maximum_root_water_uptake_mmol_m2_ground_s=zeros(T, model.layer_count),
    root_water_uptake_fraction=zeros(T, model.layer_count),
    weighted_soil_water_potential_mpa=zero(T),
    total_maximum_root_water_uptake_mmol_m2_ground_s=zero(T),
    total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol=zero(T),
    root_water_uptake_available=false,
)

function PlantSimEngine.run!(model::MAESPAMeasuredPotentialRootWaterUptake, status, environment, constants, context)
    T = eltype(status.root_water_uptake_fraction)
    _reset_root_water_uptake!(status, T)
    status.root_water_uptake_active && status.root_water_uptake_inputs_available || return nothing
    lai = status.total_leaf_area_index
    iszero(lai) && return nothing
    isfinite(lai) && lai > zero(lai) || throw(DomainError(lai, "LAI must be finite and nonnegative"))
    measured = T(environment.measured_soil_water_potential_mpa)
    isfinite(measured) && measured < zero(T) ||
        throw(DomainError(measured, "Campbell measured potential must be finite and negative"))
    conductivity = max(T(model.minimum_soil_conductivity_m_s),
        T(model.saturated_conductivity_m_s) * (T(model.air_entry_potential_mpa) / measured)^
        (T(2) + T(3) / T(model.campbell_exponent)))
    scale = T(model.mol_to_mmol_resistance_scale)
    conversion = T(model.water_partial_molar_volume_m3_mol) *
        T(model.gravitational_acceleration_m_s2) * scale
    resistance = status.soil_to_root_hydraulic_resistance_mpa_m2_ground_s_per_mmol
    for (position, layer) in enumerate(status.rooted_soil_layer_indices)
        density = T(status.root_length_density_m_m3[position])
        thickness = T(status.soil_layer_thickness_m[position])
        if density > zero(T)
            k = (layer == 1 ? conductivity : T(status.soil_hydraulic_conductivity_m_s[position])) / conversion
            k >= model.minimum_converted_soil_conductivity_mol_m_s_mpa ||
                throw(DomainError(k, "undefined Fortran low-conductivity branch"))
            resistance[layer] = _soil_to_root_radial_resistance(density,
                thickness, k, T(status.fine_root_radius_m), T(model.legacy_pi), scale)
        end
    end
    # No roots is an unavailable path, consistent with the other Julia models.
    surface_resistance = _all_root_surface_resistance(status.root_length_density_m_m3,
        status.soil_layer_thickness_m, conductivity / conversion,
        T(status.fine_root_radius_m), T(model.legacy_pi), scale)
    isnothing(surface_resistance) && return nothing
    resistance[1] = surface_resistance
    if model.equal_uptake
        fill!(status.root_water_uptake_fraction, one(T) / model.layer_count)
    else
        _, capacity = _spa_root_water_allocation!(
            status.maximum_root_water_uptake_mmol_m2_ground_s,
            status.root_water_uptake_fraction, resistance, status.rooted_soil_layer_indices,
            status.soil_water_potential_mpa, status.soil_layer_thickness_m,
            status.soil_ice_fraction, T(status.minimum_root_water_potential_mpa),
            T(status.tree_height_m), T(model.gravitational_acceleration_m_s2) * scale)
        status.total_maximum_root_water_uptake_mmol_m2_ground_s = capacity
    end
    status.weighted_soil_water_potential_mpa = measured
    status.total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol = resistance[1] * lai
    status.root_water_uptake_available = true
    return nothing
end

PlantSimEngine.Authoring.model_metadata(::MAESPAMeasuredPotentialRootWaterUptake) = (
    hypothesis="Measured potential with all-root radial resistance and SPA or uniform allocation.",
    reference="SOILCONDFUN2, SOILRESCALC and WATERUPTAKELAYER; USEMEASSW=1 and SOILDATA=POTENTIAL.",
    maturity=:experimental,
    validation=:bounded_fortran_reference,
)
