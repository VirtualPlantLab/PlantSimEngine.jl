PlantSimEngine.@process "daily_whole_plant_respiration_scene_aggregation" verbose = false

"""
Daily whole-plant respiration totals grouped by species and across the Scene.

This result keeps maintenance, whole-plant growth, and their explicit sum as
separate channels. Every input row represents one distinct physical tree;
`target_weight` is applied only to the `weighted_target_*` outputs. No output
is normalized by plot, crown, leaf, or soil area.
"""
struct DailyWholePlantRespirationSceneAggregationResult{T<:AbstractFloat}
    physical_tree_maintenance_respiration_by_species_mol_co2_day::Vector{T}
    weighted_target_maintenance_respiration_by_species_mol_co2_day::Vector{T}
    physical_tree_whole_plant_growth_respiration_by_species_mol_co2_day::Vector{T}
    weighted_target_whole_plant_growth_respiration_by_species_mol_co2_day::Vector{T}
    physical_tree_total_respiration_by_species_mol_co2_day::Vector{T}
    weighted_target_total_respiration_by_species_mol_co2_day::Vector{T}
    physical_tree_maintenance_respiration_scene_mol_co2_day::T
    weighted_target_maintenance_respiration_scene_mol_co2_day::T
    physical_tree_whole_plant_growth_respiration_scene_mol_co2_day::T
    weighted_target_whole_plant_growth_respiration_scene_mol_co2_day::T
    physical_tree_total_respiration_scene_mol_co2_day::T
    weighted_target_total_respiration_scene_mol_co2_day::T
    daily_respiration_date50_by_species::Vector{Int}
    daily_respiration_scene_date50::Int
    daily_maintenance_respiration_available_by_species::Vector{Bool}
    whole_plant_growth_respiration_available_by_species::Vector{Bool}
    daily_total_respiration_available_by_species::Vector{Bool}
    daily_maintenance_respiration_scene_available::Bool
    whole_plant_growth_respiration_scene_available::Bool
    daily_total_respiration_scene_available::Bool
    daily_respiration_dates_consistent::Bool
    physical_tree_count_by_species::Vector{Int}
    weighted_target_count_by_species::Vector{Int}
    physical_tree_count::Int
    weighted_target_count::Int
    daily_whole_plant_respiration_scene_aggregation_available::Bool
end

"""
    daily_whole_plant_respiration_scene_aggregation(
        T,
        tree_ids,
        species_ids,
        target_weights,
        daily_maintenance_respiration_mol_co2_tree_day,
        daily_maintenance_respiration_available,
        daily_maintenance_respiration_date50,
        whole_plant_growth_respiration_mol_co2_tree_day,
        whole_plant_growth_respiration_available,
        whole_plant_growth_respiration_date50;
        species_count,
    )

Aggregate daily maintenance and whole-plant growth respiration for distinct
physical trees. Rows are joined by `tree_id`, summed in deterministic tree-id
order, and exposed both as physical-tree and legacy target-weighted totals.

The maintenance availability flag is the end-of-day publication pulse. A held
growth status is ignored while that pulse is false, which prevents a subdaily
consumer from counting the same daily amount repeatedly. Within each species,
all active rows must describe one civil day. Scene totals require every present
species to be available on the same day.

Both numeric channels are already daily amounts in mol CO2 tree-1 day-1. The
function performs no area normalization. `T` is normally inferred from
PlantSimEngine output carriers, so global `type_promotion` controls every
floating conversion and sum.

The validated two-channel summation kernel is shared internally with
[`daily_respiration_scene_aggregation`](@ref). Its historical "structural"
field names are only an internal transport detail here; this public result uses
the correct whole-plant-growth contract.
"""
function daily_whole_plant_respiration_scene_aggregation(
    ::Type{T},
    tree_ids,
    species_ids,
    target_weights,
    daily_maintenance_respiration_mol_co2_tree_day,
    daily_maintenance_respiration_available,
    daily_maintenance_respiration_date50,
    whole_plant_growth_respiration_mol_co2_tree_day,
    whole_plant_growth_respiration_available,
    whole_plant_growth_respiration_date50;
    species_count,
) where {T<:AbstractFloat}
    result = daily_respiration_scene_aggregation(
        T,
        tree_ids,
        species_ids,
        target_weights,
        daily_maintenance_respiration_mol_co2_tree_day,
        daily_maintenance_respiration_available,
        daily_maintenance_respiration_date50,
        whole_plant_growth_respiration_mol_co2_tree_day,
        whole_plant_growth_respiration_available,
        whole_plant_growth_respiration_date50;
        species_count=species_count,
        _growth_channel=:whole_plant,
    )

    return DailyWholePlantRespirationSceneAggregationResult{T}(
        result.physical_tree_maintenance_respiration_by_species_mol_co2_day,
        result.weighted_target_maintenance_respiration_by_species_mol_co2_day,
        result.physical_tree_structural_growth_respiration_by_species_mol_co2_day,
        result.weighted_target_structural_growth_respiration_by_species_mol_co2_day,
        result.physical_tree_total_respiration_by_species_mol_co2_day,
        result.weighted_target_total_respiration_by_species_mol_co2_day,
        result.physical_tree_maintenance_respiration_scene_mol_co2_day,
        result.weighted_target_maintenance_respiration_scene_mol_co2_day,
        result.physical_tree_structural_growth_respiration_scene_mol_co2_day,
        result.weighted_target_structural_growth_respiration_scene_mol_co2_day,
        result.physical_tree_total_respiration_scene_mol_co2_day,
        result.weighted_target_total_respiration_scene_mol_co2_day,
        result.daily_respiration_date50_by_species,
        result.daily_respiration_scene_date50,
        result.daily_maintenance_respiration_available_by_species,
        result.structural_growth_respiration_available_by_species,
        result.daily_total_respiration_available_by_species,
        result.daily_maintenance_respiration_scene_available,
        result.structural_growth_respiration_scene_available,
        result.daily_total_respiration_scene_available,
        result.daily_respiration_dates_consistent,
        result.physical_tree_count_by_species,
        result.weighted_target_count_by_species,
        result.physical_tree_count,
        result.weighted_target_count,
        result.daily_respiration_scene_aggregation_available,
    )
end

"""
    MAESPADailyWholePlantRespirationSceneAggregation(T=Float64; species_count)

PlantSimEngine adapter for
[`daily_whole_plant_respiration_scene_aggregation`](@ref). The nine collection
inputs must use matching `Many(...)` selectors over distinct physical Plants.
The output carrier element type selects the calculation type, including after a
global `type_promotion` mapping.

Turning the availability gate off publishes a fresh zero, unavailable
snapshot without reading any collection. An invalid active call leaves the
last accepted output snapshot unchanged.
"""
struct MAESPADailyWholePlantRespirationSceneAggregation{T<:AbstractFloat} <:
       AbstractDaily_Whole_Plant_Respiration_Scene_AggregationModel
    species_count::Int
    zero_value::T
end

function MAESPADailyWholePlantRespirationSceneAggregation(
    ::Type{T}=Float64;
    species_count,
) where {T<:AbstractFloat}
    isconcretetype(T) ||
        _throw_daily_respiration_scene_aggregation(:numeric_type, T, :type)
    return MAESPADailyWholePlantRespirationSceneAggregation{T}(
        _daily_respiration_scene_positive_int(
            species_count,
            :species_count,
        ),
        zero(T),
    )
end

PlantSimEngine.inputs_(::MAESPADailyWholePlantRespirationSceneAggregation) = (
    tree_ids=PlantSimEngine.Required(AbstractVector),
    species_ids=PlantSimEngine.Required(AbstractVector),
    target_weights=PlantSimEngine.Required(AbstractVector),
    daily_maintenance_respiration_mol_co2_tree_day=
        PlantSimEngine.Required(AbstractVector),
    daily_maintenance_respiration_available=
        PlantSimEngine.Required(AbstractVector),
    daily_maintenance_respiration_date50=
        PlantSimEngine.Required(AbstractVector),
    whole_plant_growth_respiration_mol_co2_tree_day=
        PlantSimEngine.Required(AbstractVector),
    whole_plant_growth_respiration_available=
        PlantSimEngine.Required(AbstractVector),
    whole_plant_growth_respiration_date50=
        PlantSimEngine.Required(AbstractVector),
    daily_whole_plant_respiration_scene_aggregation_inputs_available=
        PlantSimEngine.Default(true),
)

function PlantSimEngine.outputs_(
    model::MAESPADailyWholePlantRespirationSceneAggregation{T},
) where {T}
    n = model.species_count
    return (
        physical_tree_maintenance_respiration_by_species_mol_co2_day=zeros(T, n),
        weighted_target_maintenance_respiration_by_species_mol_co2_day=zeros(T, n),
        physical_tree_whole_plant_growth_respiration_by_species_mol_co2_day=zeros(T, n),
        weighted_target_whole_plant_growth_respiration_by_species_mol_co2_day=zeros(T, n),
        physical_tree_total_respiration_by_species_mol_co2_day=zeros(T, n),
        weighted_target_total_respiration_by_species_mol_co2_day=zeros(T, n),
        physical_tree_maintenance_respiration_scene_mol_co2_day=zero(T),
        weighted_target_maintenance_respiration_scene_mol_co2_day=zero(T),
        physical_tree_whole_plant_growth_respiration_scene_mol_co2_day=zero(T),
        weighted_target_whole_plant_growth_respiration_scene_mol_co2_day=zero(T),
        physical_tree_total_respiration_scene_mol_co2_day=zero(T),
        weighted_target_total_respiration_scene_mol_co2_day=zero(T),
        daily_respiration_date50_by_species=zeros(Int, n),
        daily_respiration_scene_date50=0,
        daily_maintenance_respiration_available_by_species=fill(false, n),
        whole_plant_growth_respiration_available_by_species=fill(false, n),
        daily_total_respiration_available_by_species=fill(false, n),
        daily_maintenance_respiration_scene_available=false,
        whole_plant_growth_respiration_scene_available=false,
        daily_total_respiration_scene_available=false,
        daily_respiration_dates_consistent=false,
        physical_tree_count_by_species=zeros(Int, n),
        weighted_target_count_by_species=zeros(Int, n),
        physical_tree_count=0,
        weighted_target_count=0,
        daily_whole_plant_respiration_scene_aggregation_available=false,
    )
end

const _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_FLOAT_VECTOR_OUTPUTS = (
    :physical_tree_maintenance_respiration_by_species_mol_co2_day,
    :weighted_target_maintenance_respiration_by_species_mol_co2_day,
    :physical_tree_whole_plant_growth_respiration_by_species_mol_co2_day,
    :weighted_target_whole_plant_growth_respiration_by_species_mol_co2_day,
    :physical_tree_total_respiration_by_species_mol_co2_day,
    :weighted_target_total_respiration_by_species_mol_co2_day,
)

const _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_FLOAT_SCALAR_OUTPUTS = (
    :physical_tree_maintenance_respiration_scene_mol_co2_day,
    :weighted_target_maintenance_respiration_scene_mol_co2_day,
    :physical_tree_whole_plant_growth_respiration_scene_mol_co2_day,
    :weighted_target_whole_plant_growth_respiration_scene_mol_co2_day,
    :physical_tree_total_respiration_scene_mol_co2_day,
    :weighted_target_total_respiration_scene_mol_co2_day,
)

const _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_BOOL_VECTOR_OUTPUTS = (
    :daily_maintenance_respiration_available_by_species,
    :whole_plant_growth_respiration_available_by_species,
    :daily_total_respiration_available_by_species,
)

const _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_BOOL_SCALAR_OUTPUTS = (
    :daily_maintenance_respiration_scene_available,
    :whole_plant_growth_respiration_scene_available,
    :daily_total_respiration_scene_available,
    :daily_respiration_dates_consistent,
    :daily_whole_plant_respiration_scene_aggregation_available,
)

const _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_INT_VECTOR_OUTPUTS = (
    :daily_respiration_date50_by_species,
    :physical_tree_count_by_species,
    :weighted_target_count_by_species,
)

const _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_INT_SCALAR_OUTPUTS = (
    :daily_respiration_scene_date50,
    :physical_tree_count,
    :weighted_target_count,
)

function _daily_whole_plant_respiration_scene_output_type(model, status)
    first_name = first(
        _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_FLOAT_VECTOR_OUTPUTS,
    )
    first_values = getproperty(status, first_name)
    first_values isa AbstractVector ||
        _throw_daily_respiration_scene_aggregation(
            first_name,
            first_values,
            :float_output,
        )
    Base.require_one_based_indexing(first_values)
    T = eltype(first_values)
    T <: AbstractFloat && isconcretetype(T) ||
        _throw_daily_respiration_scene_aggregation(
            first_name,
            first_values,
            :float_output,
        )

    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_FLOAT_VECTOR_OUTPUTS
        values = getproperty(status, name)
        values isa AbstractVector ||
            _throw_daily_respiration_scene_aggregation(
                name,
                values,
                :float_output,
            )
        Base.require_one_based_indexing(values)
        eltype(values) === T ||
            _throw_daily_respiration_scene_aggregation(
                name,
                values,
                :float_output,
            )
        length(values) == model.species_count || throw(
            DimensionMismatch(
                "$(String(name)) must contain $(model.species_count) values",
            ),
        )
    end
    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_FLOAT_SCALAR_OUTPUTS
        value = getproperty(status, name)
        typeof(value) === T ||
            _throw_daily_respiration_scene_aggregation(
                name,
                value,
                :float_output,
            )
    end
    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_INT_VECTOR_OUTPUTS
        values = getproperty(status, name)
        values isa AbstractVector ||
            _throw_daily_respiration_scene_aggregation(
                name,
                values,
                :int_output,
            )
        Base.require_one_based_indexing(values)
        eltype(values) === Int ||
            _throw_daily_respiration_scene_aggregation(
                name,
                values,
                :int_output,
            )
        length(values) == model.species_count || throw(
            DimensionMismatch(
                "$(String(name)) must contain $(model.species_count) values",
            ),
        )
    end
    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_INT_SCALAR_OUTPUTS
        value = getproperty(status, name)
        typeof(value) === Int ||
            _throw_daily_respiration_scene_aggregation(
                name,
                value,
                :int_output,
            )
    end
    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_BOOL_VECTOR_OUTPUTS
        values = getproperty(status, name)
        values isa AbstractVector ||
            _throw_daily_respiration_scene_aggregation(
                name,
                values,
                :bool_output,
            )
        Base.require_one_based_indexing(values)
        eltype(values) === Bool ||
            _throw_daily_respiration_scene_aggregation(
                name,
                values,
                :bool_output,
            )
        length(values) == model.species_count || throw(
            DimensionMismatch(
                "$(String(name)) must contain $(model.species_count) values",
            ),
        )
    end
    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_BOOL_SCALAR_OUTPUTS
        value = getproperty(status, name)
        value isa Bool ||
            _throw_daily_respiration_scene_aggregation(
                name,
                value,
                :bool_output,
            )
    end
    return T
end

function _reset_daily_whole_plant_respiration_scene_aggregation!(
    model,
    status,
    ::Type{T},
) where {T}
    n = model.species_count
    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_FLOAT_VECTOR_OUTPUTS
        setproperty!(status, name, zeros(T, n))
    end
    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_FLOAT_SCALAR_OUTPUTS
        setproperty!(status, name, zero(T))
    end
    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_INT_VECTOR_OUTPUTS
        setproperty!(status, name, zeros(Int, n))
    end
    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_INT_SCALAR_OUTPUTS
        setproperty!(status, name, 0)
    end
    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_BOOL_VECTOR_OUTPUTS
        setproperty!(status, name, fill(false, n))
    end
    for name in _DAILY_WHOLE_PLANT_RESPIRATION_SCENE_BOOL_SCALAR_OUTPUTS
        setproperty!(status, name, false)
    end
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPADailyWholePlantRespirationSceneAggregation,
    status,
    environment,
    constants,
    context,
)
    T = _daily_whole_plant_respiration_scene_output_type(model, status)
    inputs_available =
        status.daily_whole_plant_respiration_scene_aggregation_inputs_available
    inputs_available isa Bool || throw(
        ArgumentError(
            "daily_whole_plant_respiration_scene_aggregation_inputs_available " *
            "must be Bool",
        ),
    )
    if !inputs_available
        _reset_daily_whole_plant_respiration_scene_aggregation!(
            model,
            status,
            T,
        )
        return nothing
    end

    result = daily_whole_plant_respiration_scene_aggregation(
        T,
        status.tree_ids,
        status.species_ids,
        status.target_weights,
        status.daily_maintenance_respiration_mol_co2_tree_day,
        status.daily_maintenance_respiration_available,
        status.daily_maintenance_respiration_date50,
        status.whole_plant_growth_respiration_mol_co2_tree_day,
        status.whole_plant_growth_respiration_available,
        status.whole_plant_growth_respiration_date50;
        species_count=model.species_count,
    )
    for name in fieldnames(typeof(result))
        setproperty!(status, name, getproperty(result, name))
    end
    return nothing
end
