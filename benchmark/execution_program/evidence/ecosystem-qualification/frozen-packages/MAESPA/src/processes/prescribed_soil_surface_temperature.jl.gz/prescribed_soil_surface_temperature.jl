PlantSimEngine.@process "prescribed_soil_surface_temperature" verbose = false

@noinline function _throw_prescribed_soil_surface_temperature(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :type
        throw(
            ArgumentError(
                "the prescribed-soil-temperature numeric type must be " *
                "concrete",
            ),
        )
    elseif reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :offset
        throw(DomainError(value, "$label must be strictly positive"))
    elseif reason === :temperature
        throw(DomainError(value, "$label must be above absolute zero"))
    elseif reason === :output
        throw(
            ArgumentError(
                "prescribed_soil_surface_temperature_k must use one " *
                "concrete AbstractFloat output carrier",
            ),
        )
    elseif reason === :availability
        throw(ArgumentError("$label must be Bool"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _prescribed_soil_surface_temperature_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real ||
        _throw_prescribed_soil_surface_temperature(name, value, :real)
    value isa Bool &&
        _throw_prescribed_soil_surface_temperature(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_prescribed_soil_surface_temperature(
            name,
            converted,
            :finite,
        )
    return converted
end

"""
    prescribed_soil_surface_temperature(
        T,
        source_soil_temperature_c;
        kelvin_offset=273.15,
    )

Convert one reconstructed prescribed Soil temperature from degrees Celsius to
kelvins using `T`. The resulting thermodynamic temperature must be finite and
strictly positive, matching the canopy-atmosphere trial-state contract.

`T` is explicit so a PlantSimEngine wrapper can select it from its live output
carrier after applying a global `type_promotion` mapping.
"""
function prescribed_soil_surface_temperature(
    ::Type{T},
    source_soil_temperature_c;
    kelvin_offset=273.15,
) where {T<:AbstractFloat}
    isconcretetype(T) || _throw_prescribed_soil_surface_temperature(
        :numeric_type,
        T,
        :type,
    )
    offset = _prescribed_soil_surface_temperature_float(
        T,
        kelvin_offset,
        :kelvin_offset,
    )
    offset > zero(T) || _throw_prescribed_soil_surface_temperature(
        :kelvin_offset,
        offset,
        :offset,
    )
    temperature_c = _prescribed_soil_surface_temperature_float(
        T,
        source_soil_temperature_c,
        :source_soil_temperature_c,
    )
    temperature_k = temperature_c + offset
    isfinite(temperature_k) || _throw_prescribed_soil_surface_temperature(
        :prescribed_soil_surface_temperature_k,
        temperature_k,
        :finite,
    )
    temperature_k > zero(T) || _throw_prescribed_soil_surface_temperature(
        :source_soil_temperature_c,
        temperature_c,
        :temperature,
    )
    return temperature_k
end

"""
    MAESPAPrescribedSoilSurfaceTemperature(T=Float64; kelvin_offset=273.15)

Root-scheduled adapter for the `SIMTSOIL=0` canopy-air trial. It converts the
current reconstructed Soil temperature to kelvins before the manual trial
stack starts.

An unavailable meteorological snapshot resets the numeric output to zero and
publishes `prescribed_soil_surface_temperature_available=false` without
inspecting its masked numeric input. The live output carrier selects the
runtime calculation type, including after PlantSimEngine type promotion.
"""
struct MAESPAPrescribedSoilSurfaceTemperature{T<:AbstractFloat} <:
       AbstractPrescribed_Soil_Surface_TemperatureModel
    kelvin_offset::T
end

function MAESPAPrescribedSoilSurfaceTemperature(
    ::Type{T}=Float64;
    kelvin_offset=273.15,
) where {T<:AbstractFloat}
    isconcretetype(T) || _throw_prescribed_soil_surface_temperature(
        :numeric_type,
        T,
        :type,
    )
    offset = _prescribed_soil_surface_temperature_float(
        T,
        kelvin_offset,
        :kelvin_offset,
    )
    offset > zero(T) || _throw_prescribed_soil_surface_temperature(
        :kelvin_offset,
        offset,
        :offset,
    )
    return MAESPAPrescribedSoilSurfaceTemperature{T}(offset)
end

PlantSimEngine.inputs_(::MAESPAPrescribedSoilSurfaceTemperature) = (
    source_soil_temperature_c=PlantSimEngine.Required(Real),
    source_meteorology_available=PlantSimEngine.Required(Bool),
)

PlantSimEngine.outputs_(
    model::MAESPAPrescribedSoilSurfaceTemperature{T},
) where {T} = (
    prescribed_soil_surface_temperature_k=zero(T),
    prescribed_soil_surface_temperature_available=false,
)

function _prescribed_soil_surface_temperature_output_type(status)
    output = status.prescribed_soil_surface_temperature_k
    T = typeof(output)
    T <: AbstractFloat && isconcretetype(T) ||
        _throw_prescribed_soil_surface_temperature(
            :prescribed_soil_surface_temperature_k,
            output,
            :output,
        )
    status.prescribed_soil_surface_temperature_available isa Bool ||
        _throw_prescribed_soil_surface_temperature(
            :prescribed_soil_surface_temperature_available,
            status.prescribed_soil_surface_temperature_available,
            :availability,
        )
    return T
end

function PlantSimEngine.run!(
    model::MAESPAPrescribedSoilSurfaceTemperature,
    status,
    environment,
    constants,
    context,
)
    T = _prescribed_soil_surface_temperature_output_type(status)
    status.prescribed_soil_surface_temperature_k = zero(T)
    status.prescribed_soil_surface_temperature_available = false

    available = status.source_meteorology_available
    available isa Bool || _throw_prescribed_soil_surface_temperature(
        :source_meteorology_available,
        available,
        :availability,
    )
    available || return nothing

    status.prescribed_soil_surface_temperature_k =
        prescribed_soil_surface_temperature(
            T,
            status.source_soil_temperature_c;
            kelvin_offset=model.kelvin_offset,
        )
    status.prescribed_soil_surface_temperature_available = true
    return nothing
end
