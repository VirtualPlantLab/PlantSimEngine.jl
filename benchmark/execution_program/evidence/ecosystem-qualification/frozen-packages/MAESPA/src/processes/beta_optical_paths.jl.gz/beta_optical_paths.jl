"""
    BetaCrownRayState{T}

Validated geometry and optical parameters for a crown whose leaf-area density
uses MAESPA's vertical (`JLEAF=1`) or vertical-and-horizontal (`JLEAF=2`)
beta distributions. Coefficients follow the historical `8 × NOAGEC` layout.
"""
struct BetaCrownRayState{T<:AbstractFloat} <: AbstractCrownRayState{T}
    id::Int
    crown_shape_code::Int
    position::NTuple{3,T}
    crown_base::T
    radius_x::T
    radius_y::T
    crown_depth::T
    leaf_area::T
    leaf_density_legacy_mode::Int
    leaf_density_coefficients::Matrix{T}
    structural_age_proportions::Vector{T}
    extinction::T
    extinction_by_angle::Vector{T}

    function BetaCrownRayState{T}(
        id::Integer,
        crown_shape_code::Integer,
        position::Union{NTuple{3,T},AbstractVector{T}},
        crown_base::T,
        radius_x::T,
        radius_y::T,
        crown_depth::T,
        leaf_area::T,
        leaf_density_legacy_mode::Integer,
        leaf_density_coefficients::AbstractMatrix{T},
        structural_age_proportions::AbstractVector{T},
        extinction::T,
        extinction_by_angle::AbstractVector{T},
    ) where {T<:AbstractFloat}
        return BetaCrownRayState{T}(
            id,
            crown_shape_code,
            position,
            crown_base,
            radius_x,
            radius_y,
            crown_depth,
            leaf_area,
            leaf_density_legacy_mode,
            leaf_density_coefficients,
            structural_age_proportions,
            extinction,
            extinction_by_angle,
            Val(:copy),
        )
    end

    function BetaCrownRayState{T}(
        id::Integer,
        crown_shape_code::Integer,
        position::Union{NTuple{3,T},AbstractVector{T}},
        crown_base::T,
        radius_x::T,
        radius_y::T,
        crown_depth::T,
        leaf_area::T,
        leaf_density_legacy_mode::Integer,
        leaf_density_coefficients::AbstractMatrix{T},
        structural_age_proportions::AbstractVector{T},
        extinction::T,
        extinction_by_angle::AbstractVector{T},
        ::Val{ownership},
    ) where {T<:AbstractFloat,ownership}
        ownership in (:copy, :borrow) || throw(
            ArgumentError("unsupported beta-state buffer ownership $ownership"),
        )
        validated_id = _optical_path_positive_integer(id, "id")
        validated_shape = _optical_path_shape_code(crown_shape_code)
        validated_position = _optical_path_position(position)
        _optical_path_nonnegative(crown_base, "crown_base")
        _optical_path_positive(radius_x, "radius_x")
        _optical_path_positive(radius_y, "radius_y")
        _optical_path_positive(crown_depth, "crown_depth")
        _optical_path_nonnegative(leaf_area, "leaf_area")
        leaf_density_legacy_mode isa Bool && throw(
            ArgumentError("leaf_density_legacy_mode must be an integer, not Bool"),
        )
        leaf_density_legacy_mode in (1, 2) || throw(
            ArgumentError(
                "BetaCrownRayState requires leaf_density_legacy_mode 1 or 2",
            ),
        )
        size(leaf_density_coefficients, 1) == 8 || throw(
            DimensionMismatch(
                "leaf_density_coefficients must have eight rows",
            ),
        )
        age_count = size(leaf_density_coefficients, 2)
        age_count > 0 || throw(
            ArgumentError("at least one structural age class is required"),
        )
        length(structural_age_proportions) == age_count || throw(
            DimensionMismatch(
                "structural_age_proportions must contain $age_count values",
            ),
        )
        all(isfinite, leaf_density_coefficients) || throw(
            ArgumentError("leaf-density beta coefficients must be finite"),
        )
        for proportion in structural_age_proportions
            _optical_path_nonnegative(
                proportion,
                "structural age proportion",
            )
        end
        _optical_path_nonnegative(extinction, "extinction")
        isempty(extinction_by_angle) && throw(
            ArgumentError("extinction_by_angle must contain at least one value"),
        )
        for coefficient in extinction_by_angle
            _optical_path_nonnegative(coefficient, "angle-specific extinction")
        end
        coefficients, proportions, angle_coefficients = if ownership === :borrow
            leaf_density_coefficients isa Matrix{T} || throw(
                ArgumentError("borrowed beta coefficients must be Matrix{$T}"),
            )
            structural_age_proportions isa Vector{T} || throw(
                ArgumentError("borrowed structural proportions must be Vector{$T}"),
            )
            extinction_by_angle isa Vector{T} || throw(
                ArgumentError("borrowed extinction coefficients must be Vector{$T}"),
            )
            (
                leaf_density_coefficients,
                structural_age_proportions,
                extinction_by_angle,
            )
        else
            (
                Matrix{T}(leaf_density_coefficients),
                Vector{T}(structural_age_proportions),
                Vector{T}(extinction_by_angle),
            )
        end
        return new{T}(
            validated_id,
            validated_shape,
            validated_position,
            crown_base,
            radius_x,
            radius_y,
            crown_depth,
            leaf_area,
            Int(leaf_density_legacy_mode),
            coefficients,
            proportions,
            extinction,
            angle_coefficients,
        )
    end

    # Geometry, age layout and DEXT belong to the retained checked snapshot.
    # A current beam changes only BEXT, never those owned arrays.
    function BetaCrownRayState{T}(
        snapshot::BetaCrownRayState{T},
        extinction::T,
    ) where {T<:AbstractFloat}
        _optical_path_nonnegative(extinction, "extinction")
        return new{T}(
            snapshot.id, snapshot.crown_shape_code, snapshot.position,
            snapshot.crown_base, snapshot.radius_x, snapshot.radius_y,
            snapshot.crown_depth, snapshot.leaf_area,
            snapshot.leaf_density_legacy_mode,
            snapshot.leaf_density_coefficients,
            snapshot.structural_age_proportions,
            extinction, snapshot.extinction_by_angle,
        )
    end
end

"""Concrete union used for type-stable mixed uniform/beta crown vectors."""
const CrownRayState{T} = Union{UniformCrownRayState{T},BetaCrownRayState{T}}

"""Construct a copied, typed beta-distributed crown ray state."""
function BetaCrownRayState(
    id::Integer,
    crown_shape_code::Integer;
    position::Union{NTuple{3,T},AbstractVector{T}},
    crown_base::T,
    radius_x::T,
    radius_y::T,
    crown_depth::T,
    leaf_area::T,
    leaf_density_legacy_mode::Integer,
    leaf_density_coefficients::AbstractMatrix{T},
    structural_age_proportions::AbstractVector{T},
    extinction::T,
    extinction_by_angle::AbstractVector{T},
) where {T<:AbstractFloat}
    return BetaCrownRayState{T}(
        id,
        crown_shape_code,
        position,
        crown_base,
        radius_x,
        radius_y,
        crown_depth,
        leaf_area,
        leaf_density_legacy_mode,
        leaf_density_coefficients,
        structural_age_proportions,
        extinction,
        extinction_by_angle,
    )
end

function _borrowed_beta_crown_ray_state(
    id::Integer,
    crown_shape_code::Integer;
    position::NTuple{3,T},
    crown_base::T,
    radius_x::T,
    radius_y::T,
    crown_depth::T,
    leaf_area::T,
    leaf_density_legacy_mode::Integer,
    leaf_density_coefficients::Matrix{T},
    structural_age_proportions::Vector{T},
    extinction::T,
    extinction_by_angle::Vector{T},
) where {T<:AbstractFloat}
    return BetaCrownRayState{T}(
        id,
        crown_shape_code,
        position,
        crown_base,
        radius_x,
        radius_y,
        crown_depth,
        leaf_area,
        leaf_density_legacy_mode,
        leaf_density_coefficients,
        structural_age_proportions,
        extinction,
        extinction_by_angle,
        Val(:borrow),
    )
end

@inline function _beta_path_surface_factor(
    relative_height::T,
    crown_shape_code::Int,
) where {T<:AbstractFloat}
    if one(T) < relative_height < T(1.01)
        relative_height = one(T)
    end
    return relative_height, _crown_surface_factor(
        relative_height,
        crown_shape_code,
    )
end

"""
    beta_leaf_path(crown, intersection)

Reproduce MAESPA's `WPATH` integral for one non-uniform crown. Twenty midpoint
samples are used along the analytic intersection chord. Vertical and
horizontal mixtures deliberately remain separate: `JLEAF=2` multiplies the
two age-weighted sums and therefore retains the historical cross terms.
"""
function beta_leaf_path(
    crown::BetaCrownRayState{T},
    intersection::CrownRayIntersection{T},
) where {T<:AbstractFloat}
    intersection.hit || return zero(T)
    _optical_path_nonnegative(intersection.path_length, "intersection path_length")
    iszero(intersection.path_length) && return zero(T)
    all(isfinite, intersection.entry) || throw(
        ArgumentError("intersection entry must be finite"),
    )
    all(isfinite, intersection.exit) || throw(
        ArgumentError("intersection exit must be finite"),
    )

    sample_count = 20
    sample_count_t = T(sample_count)
    total = zero(T)
    delta_x = intersection.exit[1] - intersection.entry[1]
    delta_y = intersection.exit[2] - intersection.entry[2]
    delta_z = intersection.exit[3] - intersection.entry[3]
    geometric_mean_radius = sqrt(crown.radius_x * crown.radius_y)

    for sample_index in 1:sample_count
        fraction = (T(sample_index) - one(T) / T(2)) / sample_count_t
        relative_z = (
            intersection.entry[3] + fraction * delta_z -
            crown.crown_base - crown.position[3]
        ) / crown.crown_depth
        relative_z, surface_factor = _beta_path_surface_factor(
            relative_z,
            crown.crown_shape_code,
        )
        transverse_radius = surface_factor * geometric_mean_radius
        if iszero(transverse_radius)
            transverse_radius = T(0.0001)
        end

        vertical_density = zero(T)
        for age_index in eachindex(crown.structural_age_proportions)
            vertical_density += crown.structural_age_proportions[age_index] *
                                _typed_beta_leaf_density(
                crown.leaf_density_coefficients[1, age_index],
                crown.leaf_density_coefficients[2, age_index],
                crown.leaf_density_coefficients[3, age_index],
                crown.leaf_density_coefficients[4, age_index],
                relative_z,
            )
        end
        density = vertical_density * crown.leaf_area / (
            transverse_radius * transverse_radius * crown.crown_depth
        )

        if crown.leaf_density_legacy_mode == 1
            density /= T(π)
        else
            relative_x = intersection.entry[1] + fraction * delta_x -
                         crown.position[1]
            relative_y = intersection.entry[2] + fraction * delta_y -
                         crown.position[2]
            radial_distance = hypot(relative_x, relative_y)
            relative_radius = if crown.radius_x == crown.radius_y
                radial_distance / transverse_radius
            else
                angle = if iszero(relative_x)
                    relative_y >= zero(T) ? T(π) / T(2) : -T(π) / T(2)
                else
                    atan(relative_y / relative_x)
                end
                elliptical_radius = surface_factor * sqrt(
                    (crown.radius_x * cos(angle))^2 +
                    (crown.radius_y * sin(angle))^2,
                )
                radial_distance / elliptical_radius
            end
            if one(T) < relative_radius <= T(1.10)
                relative_radius = one(T)
            end
            horizontal_density = zero(T)
            for age_index in eachindex(crown.structural_age_proportions)
                horizontal_density += crown.structural_age_proportions[age_index] *
                                      _typed_beta_leaf_density(
                    crown.leaf_density_coefficients[5, age_index],
                    crown.leaf_density_coefficients[6, age_index],
                    crown.leaf_density_coefficients[7, age_index],
                    crown.leaf_density_coefficients[8, age_index],
                    relative_radius,
                )
            end
            density *= horizontal_density
        end
        contribution = density * intersection.path_length / sample_count_t
        isfinite(contribution) || throw(
            ArgumentError("beta leaf-path contribution must be finite"),
        )
        total += contribution
    end
    isfinite(total) || throw(ArgumentError("beta leaf path must be finite"))
    total >= zero(T) || throw(ArgumentError("beta leaf path must be non-negative"))
    return total
end

@inline _crown_leaf_path(
    crown::BetaCrownRayState{T},
    intersection::CrownRayIntersection{T},
) where {T<:AbstractFloat} = beta_leaf_path(crown, intersection)
