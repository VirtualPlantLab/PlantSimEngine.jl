"""
    CrownRayIntersection{T}

Result of intersecting a forward half-ray with one analytic MAESPA crown.
`entry` and `exit` are three-dimensional points, and `path_length` is the
distance between them. A miss uses the ray origin for both points and a zero
path length. A tangency is a hit with identical, finite entry and exit points.
"""
struct CrownRayIntersection{T<:AbstractFloat}
    hit::Bool
    entry::NTuple{3,T}
    exit::NTuple{3,T}
    path_length::T
end

@inline function _ray_path_finite(value::T, name::AbstractString) where {T<:AbstractFloat}
    isfinite(value) || throw(ArgumentError("$name must be finite"))
    return value
end

@inline function _ray_path_positive(value::T, name::AbstractString) where {T<:AbstractFloat}
    _ray_path_finite(value, name)
    value > zero(T) || throw(ArgumentError("$name must be positive"))
    return value
end

function _radiation_path_shape_code(shape_code::Integer)
    shape_code isa Bool && throw(
        ArgumentError("crown_shape_code must be an integer, not Bool"),
    )
    1 <= shape_code <= 6 || throw(
        ArgumentError("crown_shape_code must be in 1:6, got $shape_code"),
    )
    return Int(shape_code)
end

@inline function _ray_path_axis_tolerance(::Type{T}) where {T<:AbstractFloat}
    return T(16) * eps(T)
end

function _normalise_ray_direction(
    direction::NTuple{3,T},
) where {T<:AbstractFloat}
    for component in direction
        isfinite(component) || throw(
            ArgumentError("ray direction must contain only finite values"),
        )
    end

    scale = max(abs(direction[1]), abs(direction[2]), abs(direction[3]))
    scale > zero(T) || throw(ArgumentError("ray direction must be non-zero"))
    scaled = (
        direction[1] / scale,
        direction[2] / scale,
        direction[3] / scale,
    )
    scaled_norm = sqrt(
        scaled[1] * scaled[1] +
        scaled[2] * scaled[2] +
        scaled[3] * scaled[3],
    )
    unit = (
        scaled[1] / scaled_norm,
        scaled[2] / scaled_norm,
        scaled[3] / scaled_norm,
    )

    # Trigonometric evaluation of exact cardinal angles leaves components of
    # order eps(T). Snapping only those round-off-sized values prevents an
    # almost-parallel slab division from manufacturing enormous distances.
    tolerance = _ray_path_axis_tolerance(T)
    snapped = ntuple(
        index -> abs(unit[index]) <= tolerance ? zero(T) : unit[index],
        3,
    )
    snapped_norm = sqrt(
        snapped[1] * snapped[1] +
        snapped[2] * snapped[2] +
        snapped[3] * snapped[3],
    )
    return (
        snapped[1] / snapped_norm,
        snapped[2] / snapped_norm,
        snapped[3] / snapped_norm,
    )
end

"""
    ray_direction(zenith_rad, azimuth_rad)

Return the unit direction `(x, y, z)` for a zenith angle measured from the
positive vertical axis and an azimuth measured from positive `x` towards
positive `y`. Zenith must lie in `[0, π]`; azimuth may be any finite angle.
Cardinal components within round-off of zero are returned as exact zeros.
"""
function ray_direction(
    zenith_rad::T,
    azimuth_rad::T,
) where {T<:AbstractFloat}
    _ray_path_finite(zenith_rad, "zenith_rad")
    _ray_path_finite(azimuth_rad, "azimuth_rad")
    zero(T) <= zenith_rad <= T(π) || throw(
        DomainError(zenith_rad, "zenith_rad must lie in [0, π]"),
    )
    return _normalise_ray_direction(
        (
            sin(zenith_rad) * cos(azimuth_rad),
            sin(zenith_rad) * sin(azimuth_rad),
            cos(zenith_rad),
        ),
    )
end

@inline _ray_path_interval(::Type{T}, lower::T, upper::T) where {T<:AbstractFloat} =
    (lower=lower, upper=upper, valid=true)

@inline _ray_path_no_interval(::Type{T}) where {T<:AbstractFloat} =
    (lower=zero(T), upper=zero(T), valid=false)

@inline function _ray_path_interval_tolerance(
    ::Type{T},
    values::T...,
) where {T<:AbstractFloat}
    scale = one(T)
    for value in values
        isfinite(value) && (scale = max(scale, abs(value)))
    end
    return T(64) * eps(T) * scale
end

function _ray_path_intersect_intervals(first, second, ::Type{T}) where {T<:AbstractFloat}
    first.valid && second.valid || return _ray_path_no_interval(T)
    lower = max(first.lower, second.lower)
    upper = min(first.upper, second.upper)
    tolerance = _ray_path_interval_tolerance(T, lower, upper)
    lower <= upper + tolerance || return _ray_path_no_interval(T)
    if upper < lower
        contact = (lower + upper) / T(2)
        return _ray_path_interval(T, contact, contact)
    end
    return _ray_path_interval(T, lower, upper)
end

function _ray_path_translate_interval(interval, offset::T) where {T<:AbstractFloat}
    interval.valid || return interval
    lower = isfinite(interval.lower) ? interval.lower + offset : interval.lower
    upper = isfinite(interval.upper) ? interval.upper + offset : interval.upper
    return _ray_path_interval(T, lower, upper)
end

function _ray_path_slab_interval(
    origin::T,
    direction::T,
    lower_bound::T,
    upper_bound::T,
) where {T<:AbstractFloat}
    if iszero(direction)
        lower_bound <= origin <= upper_bound || return _ray_path_no_interval(T)
        return _ray_path_interval(T, zero(T), T(Inf))
    end

    first = (lower_bound - origin) / direction
    second = (upper_bound - origin) / direction
    lower = max(zero(T), min(first, second))
    upper = max(first, second)
    tolerance = _ray_path_interval_tolerance(T, lower, upper)
    lower <= upper + tolerance || return _ray_path_no_interval(T)
    if upper < lower
        contact = (lower + upper) / T(2)
        return _ray_path_interval(T, contact, contact)
    end
    return _ray_path_interval(T, lower, upper)
end

function _ray_path_quadratic_intervals(
    coefficient_a::T,
    coefficient_b::T,
    coefficient_c::T,
) where {T<:AbstractFloat}
    no_interval = _ray_path_no_interval(T)
    whole_line = _ray_path_interval(T, T(-Inf), T(Inf))

    if iszero(coefficient_a)
        if iszero(coefficient_b)
            tolerance = T(64) * eps(T) * max(one(T), abs(coefficient_c))
            return coefficient_c <= tolerance ?
                   (whole_line, no_interval) :
                   (no_interval, no_interval)
        end
        root = -coefficient_c / coefficient_b
        if coefficient_b > zero(T)
            return (
                _ray_path_interval(T, T(-Inf), root),
                no_interval,
            )
        end
        return (
            _ray_path_interval(T, root, T(Inf)),
            no_interval,
        )
    end

    four_ac = T(4) * coefficient_a * coefficient_c
    squared_b = coefficient_b * coefficient_b
    discriminant = squared_b - four_ac
    discriminant_scale = max(abs(squared_b), abs(four_ac))
    discriminant_tolerance = T(64) * eps(T) * discriminant_scale

    if discriminant < -discriminant_tolerance
        return coefficient_a < zero(T) ?
               (whole_line, no_interval) :
               (no_interval, no_interval)
    elseif abs(discriminant) <= discriminant_tolerance
        root = -coefficient_b / (T(2) * coefficient_a)
        return coefficient_a > zero(T) ?
               (_ray_path_interval(T, root, root), no_interval) :
               (whole_line, no_interval)
    end

    square_root = sqrt(discriminant)
    q = -(
        coefficient_b + copysign(square_root, coefficient_b)
    ) / T(2)
    first_root, second_root = if iszero(q)
        root = -coefficient_b / (T(2) * coefficient_a)
        (root, root)
    else
        (q / coefficient_a, coefficient_c / q)
    end
    lower_root = min(first_root, second_root)
    upper_root = max(first_root, second_root)

    if coefficient_a > zero(T)
        return (
            _ray_path_interval(T, lower_root, upper_root),
            no_interval,
        )
    end
    return (
        _ray_path_interval(T, T(-Inf), lower_root),
        _ray_path_interval(T, upper_root, T(Inf)),
    )
end

function _ray_path_clip_quadratic(
    slab,
    coefficient_a::T,
    coefficient_b::T,
    coefficient_c::T,
) where {T<:AbstractFloat}
    slab.valid || return slab
    quadratic_intervals = _ray_path_quadratic_intervals(
        coefficient_a,
        coefficient_b,
        coefficient_c,
    )
    first = _ray_path_intersect_intervals(slab, quadratic_intervals[1], T)
    second = _ray_path_intersect_intervals(slab, quadratic_intervals[2], T)
    first.valid || return second
    second.valid || return first

    tolerance = _ray_path_interval_tolerance(
        T,
        first.lower,
        first.upper,
        second.lower,
        second.upper,
    )
    second.lower <= first.upper + tolerance || throw(
        ErrorException("internal error: one convex crown produced two ray intervals"),
    )
    return _ray_path_interval(
        T,
        min(first.lower, second.lower),
        max(first.upper, second.upper),
    )
end

@inline function _ray_path_point(
    origin::NTuple{3,T},
    direction::NTuple{3,T},
    distance::T,
) where {T<:AbstractFloat}
    return (
        origin[1] + distance * direction[1],
        origin[2] + distance * direction[2],
        origin[3] + distance * direction[3],
    )
end

function _ray_path_miss(origin::NTuple{3,T}) where {T<:AbstractFloat}
    return CrownRayIntersection{T}(false, origin, origin, zero(T))
end

function _ray_path_result(
    interval,
    origin::NTuple{3,T},
    direction::NTuple{3,T},
    distance_offset::T=zero(T),
) where {T<:AbstractFloat}
    interval.valid || return _ray_path_miss(origin)
    isfinite(interval.lower) && isfinite(interval.upper) || throw(
        ErrorException("internal error: bounded crown produced an unbounded ray interval"),
    )
    lower_distance = interval.lower + distance_offset
    upper_distance = interval.upper + distance_offset
    tolerance = _ray_path_interval_tolerance(T, lower_distance, upper_distance)
    lower_distance >= -tolerance || throw(
        ErrorException("internal error: crown interval lies behind the ray origin"),
    )
    lower_distance = max(zero(T), lower_distance)
    upper_distance = max(lower_distance, upper_distance)
    entry = _ray_path_point(origin, direction, lower_distance)
    exit = _ray_path_point(origin, direction, upper_distance)
    path_length = max(zero(T), interval.upper - interval.lower)
    return CrownRayIntersection{T}(true, entry, exit, path_length)
end

function _ray_path_box_interval(
    origin::NTuple{3,T},
    direction::NTuple{3,T},
    tree_x::T,
    tree_y::T,
    crown_bottom::T,
    radius_x::T,
    radius_y::T,
    crown_depth::T,
) where {T<:AbstractFloat}
    interval = _ray_path_interval(T, zero(T), T(Inf))
    for (coordinate, component, lower, upper) in (
        (origin[1], direction[1], tree_x - radius_x, tree_x + radius_x),
        (origin[2], direction[2], tree_y - radius_y, tree_y + radius_y),
        (
            origin[3],
            direction[3],
            crown_bottom,
            crown_bottom + crown_depth,
        ),
    )
        interval = _ray_path_intersect_intervals(
            interval,
            _ray_path_slab_interval(coordinate, component, lower, upper),
            T,
        )
        interval.valid || return interval
    end
    return interval
end

"""
    crown_ray_intersection(origin, direction, crown_shape_code;
                           tree_x, tree_y, tree_z, crown_base,
                           radius_x, radius_y, crown_depth)

Intersect the forward half-ray `origin + t * direction`, `t ≥ 0`, with one
MAESPA crown. Shape codes `1:6` mean `CONE`, `ELIP` (upper half ellipsoid),
`PARA`, `ROUND`, `CYL`, and `BOX`. `tree_z + crown_base` is the crown bottom;
all dimensions use the same length unit. The direction is normalised, so
`path_length` is a physical distance.

The kernel deliberately handles one analytic crown only: stems, plot clipping,
periodic copies, and multi-tree ordering are separate concerns. Axis-parallel
rays avoid division by zero. Tangencies return a finite zero-length hit rather
than the undefined coordinates produced by some historical branches.

The geometry is translation invariant: adding the same vector to `origin` and
`(tree_x, tree_y, tree_z)` translates `entry` and `exit` by that vector and
leaves `path_length` unchanged, up to floating-point rounding.
"""
function crown_ray_intersection(
    origin::NTuple{3,T},
    direction::NTuple{3,T},
    crown_shape_code::Integer;
    tree_x::T,
    tree_y::T,
    tree_z::T,
    crown_base::T,
    radius_x::T,
    radius_y::T,
    crown_depth::T,
) where {T<:AbstractFloat}
    shape_code = _radiation_path_shape_code(crown_shape_code)
    for (value, name) in (
        (origin[1], "origin x"),
        (origin[2], "origin y"),
        (origin[3], "origin z"),
        (tree_x, "tree_x"),
        (tree_y, "tree_y"),
        (tree_z, "tree_z"),
        (crown_base, "crown_base"),
    )
        _ray_path_finite(value, name)
    end
    crown_base >= zero(T) || throw(ArgumentError("crown_base must be non-negative"))
    _ray_path_positive(radius_x, "radius_x")
    _ray_path_positive(radius_y, "radius_y")
    _ray_path_positive(crown_depth, "crown_depth")

    unit_direction = _normalise_ray_direction(direction)
    crown_bottom = tree_z + crown_base
    isfinite(crown_bottom) || throw(ArgumentError("tree_z + crown_base must be finite"))
    crown_top = crown_bottom + crown_depth
    isfinite(crown_top) || throw(
        ArgumentError("tree_z + crown_base + crown_depth must be finite"),
    )

    if shape_code == 6
        return _ray_path_result(
            _ray_path_box_interval(
                origin,
                unit_direction,
                tree_x,
                tree_y,
                crown_bottom,
                radius_x,
                radius_y,
                crown_depth,
            ),
            origin,
            unit_direction,
        )
    end

    vertical_interval = _ray_path_slab_interval(
        origin[3],
        unit_direction[3],
        crown_bottom,
        crown_top,
    )
    vertical_interval.valid || return _ray_path_miss(origin)

    crown_centre_z = crown_bottom + crown_depth / T(2)
    reference_distance =
        (tree_x - origin[1]) * unit_direction[1] +
        (tree_y - origin[2]) * unit_direction[2] +
        (crown_centre_z - origin[3]) * unit_direction[3]
    isfinite(reference_distance) || throw(
        ArgumentError("ray and crown positions must produce a finite projection"),
    )
    reference_origin = _ray_path_point(
        origin,
        unit_direction,
        reference_distance,
    )
    shifted_vertical_interval = _ray_path_translate_interval(
        vertical_interval,
        -reference_distance,
    )

    x = (reference_origin[1] - tree_x) / radius_x
    y = (reference_origin[2] - tree_y) / radius_y
    dx = unit_direction[1] / radius_x
    dy = unit_direction[2] / radius_y
    for value in (x, y, dx, dy)
        isfinite(value) || throw(
            ArgumentError("ray and crown scales must produce finite normalised coordinates"),
        )
    end

    coefficient_a, coefficient_b, coefficient_c = if shape_code == 1
        relative_z = (reference_origin[3] - crown_bottom) / crown_depth
        dz = unit_direction[3] / crown_depth
        distance_to_tip = one(T) - relative_z
        (
            dx * dx + dy * dy - dz * dz,
            T(2) * (x * dx + y * dy + distance_to_tip * dz),
            x * x + y * y - distance_to_tip * distance_to_tip,
        )
    elseif shape_code == 2
        relative_z = (reference_origin[3] - crown_bottom) / crown_depth
        dz = unit_direction[3] / crown_depth
        (
            dx * dx + dy * dy + dz * dz,
            T(2) * (x * dx + y * dy + relative_z * dz),
            x * x + y * y + relative_z * relative_z - one(T),
        )
    elseif shape_code == 3
        relative_z = (reference_origin[3] - crown_bottom) / crown_depth
        dz = unit_direction[3] / crown_depth
        (
            dx * dx + dy * dy,
            T(2) * (x * dx + y * dy) + dz,
            x * x + y * y + relative_z - one(T),
        )
    elseif shape_code == 4
        half_depth = crown_depth / T(2)
        relative_z = (
            reference_origin[3] - (crown_bottom + half_depth)
        ) / half_depth
        dz = unit_direction[3] / half_depth
        (
            dx * dx + dy * dy + dz * dz,
            T(2) * (x * dx + y * dy + relative_z * dz),
            x * x + y * y + relative_z * relative_z - one(T),
        )
    else
        (
            dx * dx + dy * dy,
            T(2) * (x * dx + y * dy),
            x * x + y * y - one(T),
        )
    end
    for coefficient in (coefficient_a, coefficient_b, coefficient_c)
        isfinite(coefficient) || throw(
            ArgumentError("ray and crown scales must produce finite intersection coefficients"),
        )
    end

    return _ray_path_result(
        _ray_path_clip_quadratic(
            shifted_vertical_interval,
            coefficient_a,
            coefficient_b,
            coefficient_c,
        ),
        origin,
        unit_direction,
        reference_distance,
    )
end

"""
    uniform_leaf_path(leaf_area_density, intersection)

Return the uniform-leaf-area path integral, `leaf_area_density * path_length`,
for one crown intersection. A miss or tangency contributes zero.
"""
function uniform_leaf_path(
    leaf_area_density::T,
    intersection::CrownRayIntersection{T},
) where {T<:AbstractFloat}
    _ray_path_finite(leaf_area_density, "leaf_area_density")
    leaf_area_density >= zero(T) || throw(
        ArgumentError("leaf_area_density must be non-negative"),
    )
    intersection.hit || return zero(T)
    isfinite(intersection.path_length) || throw(
        ArgumentError("intersection path_length must be finite"),
    )
    intersection.path_length >= zero(T) || throw(
        ArgumentError("intersection path_length must be non-negative"),
    )
    return leaf_area_density * intersection.path_length
end
