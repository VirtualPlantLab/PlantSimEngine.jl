PlantSimEngine.@process "stand_radiation_scaling" verbose = false

"""Accepted `GETRGLOB` Crown-interception scaling for one stand timestep."""
struct StandRadiationScalingResult{T<:AbstractFloat}
    canopy_absorbed_par_w_m2_ground::T
    canopy_absorbed_nir_w_m2_ground::T
    canopy_absorbed_thermal_w_m2_ground::T
    canopy_net_radiation_w_m2::T
    stand_radiation_target_expansion_factor::T
    stand_radiation_target_slot_count::Int
    stand_radiation_target_mean_leaf_area_m2::T
    stand_radiation_all_tree_mean_leaf_area_m2::T
end

@noinline function _throw_stand_radiation_scaling(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :integer
        throw(ArgumentError("$label values must be integers, not Bool"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :mode
        throw(DomainError(value, "$label must be 0, 1, or 2"))
    elseif reason === :vector
        throw(ArgumentError("$label must be an AbstractVector"))
    elseif reason === :output_type
        throw(
            ArgumentError(
                "$label and stand-radiation outputs must share a concrete floating-point type",
            ),
        )
    elseif reason === :solution
        throw(DomainError(value, "$label must remain finite"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _stand_radiation_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real || _throw_stand_radiation_scaling(name, value, :real)
    value isa Bool && _throw_stand_radiation_scaling(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_stand_radiation_scaling(name, converted, :finite)
    return converted
end

@inline function _stand_radiation_positive(value::T, name::Symbol) where {T}
    value > zero(T) ||
        _throw_stand_radiation_scaling(name, value, :positive)
    return value
end

@inline function _stand_radiation_nonnegative(value::T, name::Symbol) where {T}
    value >= zero(T) ||
        _throw_stand_radiation_scaling(name, value, :nonnegative)
    return value
end

@inline function _stand_radiation_mode(value)
    value isa Integer && !(value isa Bool) ||
        _throw_stand_radiation_scaling(:use_stand, value, :integer)
    value in 0:2 || _throw_stand_radiation_scaling(:use_stand, value, :mode)
    return Int(value)
end

@inline function _stand_radiation_count(value, name::Symbol)
    value isa Integer && !(value isa Bool) ||
        _throw_stand_radiation_scaling(name, value, :integer)
    converted = try
        Int(value)
    catch exception
        exception isa InexactError || exception isa OverflowError || rethrow()
        throw(ArgumentError("$(String(name)) must be representable as Int"))
    end
    converted > 0 ||
        _throw_stand_radiation_scaling(name, converted, :positive)
    return converted
end

@inline function _stand_radiation_vector(values, name::Symbol)
    values isa AbstractVector ||
        _throw_stand_radiation_scaling(name, values, :vector)
    Base.require_one_based_indexing(values)
    return values
end

function _stand_radiation_target_count(arrays)
    first_values, first_name = first(arrays)
    first_vector = _stand_radiation_vector(first_values, first_name)
    target_count = length(first_vector)
    target_count > 0 || throw(ArgumentError("at least one target Crown is required"))
    for (values, name) in Base.tail(arrays)
        vector = _stand_radiation_vector(values, name)
        length(vector) == target_count || throw(
            DimensionMismatch("$(String(name)) must contain $target_count values"),
        )
    end
    return target_count
end

"""
    stand_radiation_scaling(T, target_leaf_area_m2,
                            target_multiplicities,
                            absorbed_par_crown_w,
                            absorbed_nir_crown_w,
                            absorbed_thermal_crown_w;
                            target_exchange_daylight,
                            crown_radiation_aggregation_available,
                            use_stand,
                            water_balance_area_m2,
                            stocking_trees_m2,
                            total_tree_count=nothing,
                            stand_lai)

Scale the per-Crown absorbed radiation emitted by
`crown_radiation_aggregation` to the water-balance ground area. This is the
`RADINTERC1/2/3` part of historical `SCALEUP -> GETRGLOB`.

`target_multiplicities` restores repeated `ITARGETS` slots after Julia has
deduplicated physical Crowns. With `USESTAND=0`, every slot has expansion one.
With `USESTAND=1` or `2`, every slot receives the historical common factor

`(all-tree mean leaf area / target mean leaf area) *
 div(number of all trees, number of target slots)`.

The second ratio deliberately uses integer division. `NOALLTREES` and
`NOTARGETS` are both `INTEGER` in the legacy `SCALEUP` routine, so preserving
that quotient is part of the V1 compatibility contract even when the two
counts are not divisible.

PAR and NIR are summed whenever their Crown aggregation is available, exactly
as `GETRGLOB` sums `THRAB`. `target_exchange_daylight` only permits an
unavailable shortwave source to be treated as zero; it is not a numerical
filter. This makes the all-false nighttime state a valid thermal-only
calculation without discarding an available source. Thermal absorption is
signed and always required. Understorey interception is deliberately outside
this kernel until the understorey process is ported.
"""
function stand_radiation_scaling(
    ::Type{T},
    target_leaf_area_m2,
    target_multiplicities,
    absorbed_par_crown_w,
    absorbed_nir_crown_w,
    absorbed_thermal_crown_w;
    target_exchange_daylight,
    crown_radiation_aggregation_available,
    use_stand,
    water_balance_area_m2,
    stocking_trees_m2,
    total_tree_count=nothing,
    stand_lai,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the stand-radiation numeric type must be concrete"),
    )
    mode = _stand_radiation_mode(use_stand)
    target_count = _stand_radiation_target_count((
        (target_leaf_area_m2, :target_leaf_area_m2),
        (target_multiplicities, :target_multiplicities),
        (absorbed_par_crown_w, :absorbed_par_crown_w),
        (absorbed_nir_crown_w, :absorbed_nir_crown_w),
        (absorbed_thermal_crown_w, :absorbed_thermal_crown_w),
        (target_exchange_daylight, :target_exchange_daylight),
        (
            crown_radiation_aggregation_available,
            :crown_radiation_aggregation_available,
        ),
    ))
    area = _stand_radiation_positive(
        _stand_radiation_float(T, water_balance_area_m2, :water_balance_area_m2),
        :water_balance_area_m2,
    )
    stocking = _stand_radiation_positive(
        _stand_radiation_float(T, stocking_trees_m2, :stocking_trees_m2),
        :stocking_trees_m2,
    )
    current_stand_lai = _stand_radiation_nonnegative(
        _stand_radiation_float(T, stand_lai, :stand_lai),
        :stand_lai,
    )
    all_tree_count = if isnothing(total_tree_count)
        mode == 0 || throw(
            ArgumentError("total_tree_count is required when USESTAND > 0"),
        )
        0
    else
        _stand_radiation_count(total_tree_count, :total_tree_count)
    end

    target_slot_count = 0
    repeated_target_leaf_area = zero(T)
    for target_index in 1:target_count
        multiplicity = _stand_radiation_count(
            target_multiplicities[target_index],
            :target_multiplicities,
        )
        leaf_area = _stand_radiation_nonnegative(
            _stand_radiation_float(
                T,
                target_leaf_area_m2[target_index],
                :target_leaf_area_m2,
            ),
            :target_leaf_area_m2,
        )
        target_slot_count = Base.checked_add(target_slot_count, multiplicity)
        repeated_target_leaf_area += T(multiplicity) * leaf_area
    end

    target_mean_leaf_area = repeated_target_leaf_area / T(target_slot_count)
    all_tree_mean_leaf_area = current_stand_lai / stocking
    expansion = if mode == 0
        one(T)
    elseif target_mean_leaf_area > zero(T)
        all_tree_mean_leaf_area / target_mean_leaf_area *
        T(div(all_tree_count, target_slot_count))
    else
        zero(T)
    end
    isfinite(expansion) && expansion >= zero(T) ||
        _throw_stand_radiation_scaling(
            :stand_radiation_target_expansion_factor,
            expansion,
            :solution,
        )

    par_total_w = zero(T)
    nir_total_w = zero(T)
    thermal_total_w = zero(T)
    for target_index in 1:target_count
        multiplicity = T(target_multiplicities[target_index])
        daylight = target_exchange_daylight[target_index]
        shortwave_available =
            crown_radiation_aggregation_available[target_index]
        daylight isa Bool || throw(
            ArgumentError("target_exchange_daylight values must be Bool"),
        )
        shortwave_available isa Bool || throw(
            ArgumentError(
                "crown_radiation_aggregation_available values must be Bool",
            ),
        )
        if shortwave_available
            par = _stand_radiation_nonnegative(
                _stand_radiation_float(
                    T,
                    absorbed_par_crown_w[target_index],
                    :absorbed_par_crown_w,
                ),
                :absorbed_par_crown_w,
            )
            nir = _stand_radiation_nonnegative(
                _stand_radiation_float(
                    T,
                    absorbed_nir_crown_w[target_index],
                    :absorbed_nir_crown_w,
                ),
                :absorbed_nir_crown_w,
            )
            par_total_w = muladd(multiplicity, par, par_total_w)
            nir_total_w = muladd(multiplicity, nir, nir_total_w)
        elseif daylight
            throw(
                ArgumentError(
                    "daylight target Crown shortwave aggregation is unavailable",
                ),
            )
        end
        thermal = _stand_radiation_float(
            T,
            absorbed_thermal_crown_w[target_index],
            :absorbed_thermal_crown_w,
        )
        thermal_total_w = muladd(multiplicity, thermal, thermal_total_w)
    end

    scale = expansion / area
    par_ground = par_total_w * scale
    nir_ground = nir_total_w * scale
    thermal_ground = thermal_total_w * scale
    net_ground = par_ground + nir_ground + thermal_ground
    for (value, name) in (
        (par_ground, :canopy_absorbed_par_w_m2_ground),
        (nir_ground, :canopy_absorbed_nir_w_m2_ground),
        (thermal_ground, :canopy_absorbed_thermal_w_m2_ground),
        (net_ground, :canopy_net_radiation_w_m2),
        (target_mean_leaf_area, :stand_radiation_target_mean_leaf_area_m2),
        (all_tree_mean_leaf_area, :stand_radiation_all_tree_mean_leaf_area_m2),
    )
        isfinite(value) ||
            _throw_stand_radiation_scaling(name, value, :solution)
    end

    return StandRadiationScalingResult{T}(
        par_ground,
        nir_ground,
        thermal_ground,
        net_ground,
        expansion,
        target_slot_count,
        target_mean_leaf_area,
        all_tree_mean_leaf_area,
    )
end

"""Typed `SCALEUP -> GETRGLOB` Crown-interception model."""
struct MAESPAStandRadiationScaling{T<:AbstractFloat} <:
       AbstractStand_Radiation_ScalingModel
    use_stand::Int
    water_balance_area_m2::T
    stocking_trees_m2::T
    total_tree_count::Int
end

function MAESPAStandRadiationScaling(
    ::Type{T}=Float64;
    use_stand,
    water_balance_area_m2,
    stocking_trees_m2,
    total_tree_count=nothing,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the stand-radiation numeric type must be concrete"),
    )
    mode = _stand_radiation_mode(use_stand)
    area = _stand_radiation_positive(
        _stand_radiation_float(T, water_balance_area_m2, :water_balance_area_m2),
        :water_balance_area_m2,
    )
    stocking = _stand_radiation_positive(
        _stand_radiation_float(T, stocking_trees_m2, :stocking_trees_m2),
        :stocking_trees_m2,
    )
    tree_count = if isnothing(total_tree_count)
        mode == 0 || throw(
            ArgumentError("total_tree_count is required when USESTAND > 0"),
        )
        0
    else
        _stand_radiation_count(total_tree_count, :total_tree_count)
    end
    return MAESPAStandRadiationScaling{T}(mode, area, stocking, tree_count)
end

PlantSimEngine.inputs_(::MAESPAStandRadiationScaling) = (
    target_leaf_area_m2=PlantSimEngine.Required(AbstractVector),
    target_multiplicities=PlantSimEngine.Required(AbstractVector),
    absorbed_par_crown_w=PlantSimEngine.Required(AbstractVector),
    absorbed_nir_crown_w=PlantSimEngine.Required(AbstractVector),
    absorbed_thermal_crown_w=PlantSimEngine.Required(AbstractVector),
    target_exchange_daylight=PlantSimEngine.Required(AbstractVector),
    crown_radiation_aggregation_available=
        PlantSimEngine.Required(AbstractVector),
    crown_thermal_radiation_aggregation_available=
        PlantSimEngine.Required(AbstractVector),
    stand_lai=PlantSimEngine.Required(Real),
    stand_radiation_scaling_inputs_available=PlantSimEngine.Default(true),
)

function PlantSimEngine.outputs_(::MAESPAStandRadiationScaling{T}) where {T}
    return (
        canopy_absorbed_par_w_m2_ground=zero(T),
        canopy_absorbed_nir_w_m2_ground=zero(T),
        canopy_absorbed_thermal_w_m2_ground=zero(T),
        canopy_net_radiation_w_m2=zero(T),
        stand_radiation_target_expansion_factor=zero(T),
        stand_radiation_target_slot_count=0,
        stand_radiation_target_mean_leaf_area_m2=zero(T),
        stand_radiation_all_tree_mean_leaf_area_m2=zero(T),
        stand_radiation_scaling_available=false,
    )
end

function _stand_radiation_output_type(status)
    T = typeof(status.canopy_net_radiation_w_m2)
    T <: AbstractFloat && isconcretetype(T) ||
        _throw_stand_radiation_scaling(
            :canopy_net_radiation_w_m2,
            status.canopy_net_radiation_w_m2,
            :output_type,
        )
    for name in (
        :canopy_absorbed_par_w_m2_ground,
        :canopy_absorbed_nir_w_m2_ground,
        :canopy_absorbed_thermal_w_m2_ground,
        :stand_radiation_target_expansion_factor,
        :stand_radiation_target_mean_leaf_area_m2,
        :stand_radiation_all_tree_mean_leaf_area_m2,
    )
        typeof(getproperty(status, name)) === T ||
            _throw_stand_radiation_scaling(name, getproperty(status, name), :output_type)
    end
    status.stand_radiation_target_slot_count isa Int || throw(
        ArgumentError("stand_radiation_target_slot_count must be Int"),
    )
    status.stand_radiation_scaling_available isa Bool || throw(
        ArgumentError("stand_radiation_scaling_available must be Bool"),
    )
    return T
end

function _reset_stand_radiation_scaling!(status, ::Type{T}) where {T}
    status.canopy_absorbed_par_w_m2_ground = zero(T)
    status.canopy_absorbed_nir_w_m2_ground = zero(T)
    status.canopy_absorbed_thermal_w_m2_ground = zero(T)
    status.canopy_net_radiation_w_m2 = zero(T)
    status.stand_radiation_target_expansion_factor = zero(T)
    status.stand_radiation_target_slot_count = 0
    status.stand_radiation_target_mean_leaf_area_m2 = zero(T)
    status.stand_radiation_all_tree_mean_leaf_area_m2 = zero(T)
    status.stand_radiation_scaling_available = false
    return nothing
end

function _stand_radiation_sources_available(status)
    arrays = (
        (
            status.crown_radiation_aggregation_available,
            :crown_radiation_aggregation_available,
        ),
        (
            status.crown_thermal_radiation_aggregation_available,
            :crown_thermal_radiation_aggregation_available,
        ),
        (status.target_exchange_daylight, :target_exchange_daylight),
    )
    target_count = _stand_radiation_target_count(arrays)
    for target_index in 1:target_count
        shortwave = status.crown_radiation_aggregation_available[target_index]
        thermal =
            status.crown_thermal_radiation_aggregation_available[target_index]
        daylight = status.target_exchange_daylight[target_index]
        shortwave isa Bool || throw(
            ArgumentError(
                "crown_radiation_aggregation_available values must be Bool",
            ),
        )
        thermal isa Bool || throw(
            ArgumentError(
                "crown_thermal_radiation_aggregation_available values must be Bool",
            ),
        )
        daylight isa Bool || throw(
            ArgumentError("target_exchange_daylight values must be Bool"),
        )
        thermal || return target_count, false
        daylight && !shortwave && return target_count, false
    end
    return target_count, true
end

function PlantSimEngine.run!(
    model::MAESPAStandRadiationScaling,
    status,
    environment,
    constants,
    context,
)
    T = try
        _stand_radiation_output_type(status)
    catch
        status.stand_radiation_scaling_available = false
        rethrow()
    end
    status.stand_radiation_scaling_available = false
    inputs_available = status.stand_radiation_scaling_inputs_available
    inputs_available isa Bool || throw(
        ArgumentError("stand_radiation_scaling_inputs_available must be Bool"),
    )
    if !inputs_available
        _reset_stand_radiation_scaling!(status, T)
        return nothing
    end
    target_count, sources_available = _stand_radiation_sources_available(status)
    if !sources_available
        _reset_stand_radiation_scaling!(status, T)
        return nothing
    end
    for (values, name) in (
        (status.target_leaf_area_m2, :target_leaf_area_m2),
        (status.target_multiplicities, :target_multiplicities),
        (status.absorbed_par_crown_w, :absorbed_par_crown_w),
        (status.absorbed_nir_crown_w, :absorbed_nir_crown_w),
        (status.absorbed_thermal_crown_w, :absorbed_thermal_crown_w),
    )
        vector = _stand_radiation_vector(values, name)
        length(vector) == target_count || throw(
            DimensionMismatch("$(String(name)) must contain $target_count values"),
        )
    end

    result = try
        stand_radiation_scaling(
            T,
            status.target_leaf_area_m2,
            status.target_multiplicities,
            status.absorbed_par_crown_w,
            status.absorbed_nir_crown_w,
            status.absorbed_thermal_crown_w;
            target_exchange_daylight=status.target_exchange_daylight,
            crown_radiation_aggregation_available=
                status.crown_radiation_aggregation_available,
            use_stand=model.use_stand,
            water_balance_area_m2=convert(T, model.water_balance_area_m2),
            stocking_trees_m2=convert(T, model.stocking_trees_m2),
            total_tree_count=model.use_stand == 0 ? nothing :
                             model.total_tree_count,
            stand_lai=status.stand_lai,
        )
    catch
        status.stand_radiation_scaling_available = false
        rethrow()
    end
    status.canopy_absorbed_par_w_m2_ground =
        result.canopy_absorbed_par_w_m2_ground
    status.canopy_absorbed_nir_w_m2_ground =
        result.canopy_absorbed_nir_w_m2_ground
    status.canopy_absorbed_thermal_w_m2_ground =
        result.canopy_absorbed_thermal_w_m2_ground
    status.canopy_net_radiation_w_m2 = result.canopy_net_radiation_w_m2
    status.stand_radiation_target_expansion_factor =
        result.stand_radiation_target_expansion_factor
    status.stand_radiation_target_slot_count =
        result.stand_radiation_target_slot_count
    status.stand_radiation_target_mean_leaf_area_m2 =
        result.stand_radiation_target_mean_leaf_area_m2
    status.stand_radiation_all_tree_mean_leaf_area_m2 =
        result.stand_radiation_all_tree_mean_leaf_area_m2
    status.stand_radiation_scaling_available = true
    return nothing
end
