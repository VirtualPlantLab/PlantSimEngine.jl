PlantSimEngine.@process "soil_shortwave_radiation" verbose = false

"""
Canopy and soil PAR/NIR shortwave fluxes expressed per unit ground area.

`canopy_absorbed_par_w_m2_ground` and
`canopy_absorbed_nir_w_m2_ground` are the target-crown absorptions after the
legacy stand expansion and before subtracting multiple-scattering losses from
the radiation reaching the soil. All four fields are in W m⁻² of ground.
"""
struct SoilShortwaveRadiationResult{T<:AbstractFloat}
    soil_absorbed_par_w_m2::T
    soil_absorbed_nir_w_m2::T
    canopy_absorbed_par_w_m2_ground::T
    canopy_absorbed_nir_w_m2_ground::T
end

@noinline function _throw_soil_shortwave_value(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :integer
        throw(ArgumentError("$label must be an integer, not Bool"))
    elseif reason === :selection
        throw(DomainError(value, "$label must be one of 0, 1, or 2"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _soil_shortwave_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real || _throw_soil_shortwave_value(name, value, :real)
    value isa Bool && _throw_soil_shortwave_value(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_soil_shortwave_value(name, converted, :finite)
    return converted
end

@inline function _soil_shortwave_nonnegative(
    value::T,
    name::Symbol,
) where {T<:AbstractFloat}
    value >= zero(T) ||
        _throw_soil_shortwave_value(name, value, :nonnegative)
    return value
end

@inline function _soil_shortwave_positive(
    value::T,
    name::Symbol,
) where {T<:AbstractFloat}
    value > zero(T) || _throw_soil_shortwave_value(name, value, :positive)
    return value
end

function _soil_shortwave_target_weights(target_weights)
    weights = Int[]
    for weight in target_weights
        weight isa Integer && !(weight isa Bool) ||
            _throw_soil_shortwave_value(:target_weights, weight, :integer)
        weight > 0 ||
            _throw_soil_shortwave_value(:target_weights, weight, :positive)
        weight <= typemax(Int) || throw(
            ArgumentError("target_weights values must be representable as Int"),
        )
        push!(weights, Int(weight))
    end
    isempty(weights) && throw(
        ArgumentError("at least one target Crown is required"),
    )
    return Tuple(weights)
end

function _soil_shortwave_target_count(target_weights)
    count = 0
    for weight in target_weights
        count = Base.checked_add(count, weight)
    end
    return count
end

function _validate_soil_shortwave_arrays(
    target_leaf_area_contributions_m2::AbstractVector{T},
    absorbed_par_crown_w::AbstractVector{T},
    absorbed_nir_crown_w::AbstractVector{T},
    scattered_lost_by_target_w_m2::AbstractMatrix{T},
    active_targets::AbstractVector{Bool},
    target_weights,
) where {T<:AbstractFloat}
    Base.require_one_based_indexing(
        target_leaf_area_contributions_m2,
        absorbed_par_crown_w,
        absorbed_nir_crown_w,
        scattered_lost_by_target_w_m2,
        active_targets,
    )
    target_count = length(target_weights)
    length(target_leaf_area_contributions_m2) == target_count || throw(
        DimensionMismatch(
            "target_leaf_area_contributions_m2 must contain $target_count values",
        ),
    )
    length(absorbed_par_crown_w) == target_count || throw(
        DimensionMismatch("absorbed_par_crown_w must contain $target_count values"),
    )
    length(absorbed_nir_crown_w) == target_count || throw(
        DimensionMismatch("absorbed_nir_crown_w must contain $target_count values"),
    )
    size(scattered_lost_by_target_w_m2) == (target_count, 2) || throw(
        DimensionMismatch(
            "scattered_lost_by_target_w_m2 must have size ($target_count, 2)",
        ),
    )
    length(active_targets) == target_count || throw(
        DimensionMismatch("active_targets must contain $target_count values"),
    )
    return nothing
end

"""
    soil_shortwave_radiation(target_leaf_area_contributions_m2,
                             absorbed_par_crown_w,
                             absorbed_nir_crown_w,
                             scattered_lost_by_target_w_m2;
                             target_weights=ones(Int, length(...)),
                             active_targets=trues(length(...)),
                             incident_par_w_m2,
                             incident_nir_w_m2,
                             stand_lai,
                             stocking,
                             total_tree_count,
                             water_balance_area,
                             use_stand)

Reproduce the PAR/NIR part of MAESPA's `SCALEUP → GETRGLOB` path. Crown
absorption is expanded to W m⁻² of water-balance area, and the mean radiation
lost by multiple scattering is subtracted from the incident flux. The result
is clamped at zero independently for PAR and NIR. The expanded crown
absorption is also returned independently for each waveband, before the
multiple-scattering loss is applied, as the overstorey-canopy absorption per
unit ground area.

This kernel is deliberately canopy-only: it implements neither the legacy
understorey (`ISIMUS`) `THRABUS`/`PARUSMEAN` correction nor any thermal term.
Its explicit overstorey outputs let a separate PlantSimEngine process apply
the understorey correction without changing this Crown aggregation.

`target_leaf_area_contributions_m2` contains the already multiplicity-weighted
leaf-area contribution of every distinct target Crown. `target_weights`
retains those multiplicities for Crown absorption and the across-target mean.
This is equivalent to repeating duplicate target identifiers in the Fortran
arrays while keeping a single physical Crown object in PlantSimEngine.
The stand expansion deliberately retains the legacy integer quotient
`div(total_tree_count, sum(target_weights))` because both source counts are
Fortran `INTEGER` values.

`active_targets=false` makes the corresponding Crown absorption and lost
radiation zero without reading those entries. This represents the historical
night, low-PAR, and leafless branches, whose upstream radiation buffers are
deliberately unavailable.
"""
function soil_shortwave_radiation(
    target_leaf_area_contributions_m2::AbstractVector{T},
    absorbed_par_crown_w::AbstractVector{T},
    absorbed_nir_crown_w::AbstractVector{T},
    scattered_lost_by_target_w_m2::AbstractMatrix{T};
    target_weights=ntuple(_ -> 1, length(target_leaf_area_contributions_m2)),
    active_targets=trues(length(target_leaf_area_contributions_m2)),
    incident_par_w_m2,
    incident_nir_w_m2,
    stand_lai,
    stocking,
    total_tree_count,
    water_balance_area,
    use_stand,
) where {T<:AbstractFloat}
    weights = _soil_shortwave_target_weights(target_weights)
    _validate_soil_shortwave_arrays(
        target_leaf_area_contributions_m2,
        absorbed_par_crown_w,
        absorbed_nir_crown_w,
        scattered_lost_by_target_w_m2,
        active_targets,
        weights,
    )

    total_tree_count isa Integer && !(total_tree_count isa Bool) ||
        _throw_soil_shortwave_value(
            :total_tree_count,
            total_tree_count,
            :integer,
        )
    total_tree_count > 0 ||
        _throw_soil_shortwave_value(
            :total_tree_count,
            total_tree_count,
            :positive,
        )
    use_stand isa Integer && !(use_stand isa Bool) ||
        _throw_soil_shortwave_value(:use_stand, use_stand, :integer)
    use_stand in 0:2 ||
        _throw_soil_shortwave_value(:use_stand, use_stand, :selection)

    incident_par = _soil_shortwave_nonnegative(
        _soil_shortwave_float(T, incident_par_w_m2, :incident_par_w_m2),
        :incident_par_w_m2,
    )
    incident_nir = _soil_shortwave_nonnegative(
        _soil_shortwave_float(T, incident_nir_w_m2, :incident_nir_w_m2),
        :incident_nir_w_m2,
    )
    current_stand_lai = _soil_shortwave_nonnegative(
        _soil_shortwave_float(T, stand_lai, :stand_lai),
        :stand_lai,
    )
    current_stocking = _soil_shortwave_positive(
        _soil_shortwave_float(T, stocking, :stocking),
        :stocking,
    )
    plot_area = _soil_shortwave_positive(
        _soil_shortwave_float(
            T,
            water_balance_area,
            :water_balance_area,
        ),
        :water_balance_area,
    )

    target_slot_count = _soil_shortwave_target_count(weights)
    weighted_leaf_area = zero(T)
    intercepted_par_w = zero(T)
    intercepted_nir_w = zero(T)
    mean_lost_par_numerator = zero(T)
    mean_lost_nir_numerator = zero(T)

    for target_index in eachindex(target_leaf_area_contributions_m2)
        target_leaf_area = target_leaf_area_contributions_m2[target_index]
        isfinite(target_leaf_area) || _throw_soil_shortwave_value(
            :target_leaf_area_contributions_m2,
            target_leaf_area,
            :finite,
        )
        target_leaf_area >= zero(T) || _throw_soil_shortwave_value(
            :target_leaf_area_contributions_m2,
            target_leaf_area,
            :nonnegative,
        )
        weighted_leaf_area += target_leaf_area

        active_targets[target_index] || continue
        absorbed_par = absorbed_par_crown_w[target_index]
        absorbed_nir = absorbed_nir_crown_w[target_index]
        lost_par = scattered_lost_by_target_w_m2[target_index, 1]
        lost_nir = scattered_lost_by_target_w_m2[target_index, 2]
        for (value, name) in (
            (absorbed_par, :absorbed_par_crown_w),
            (absorbed_nir, :absorbed_nir_crown_w),
            (lost_par, :scattered_lost_par_w_m2),
            (lost_nir, :scattered_lost_nir_w_m2),
        )
            isfinite(value) ||
                _throw_soil_shortwave_value(name, value, :finite)
            value >= zero(T) ||
                _throw_soil_shortwave_value(name, value, :nonnegative)
        end
        weight = T(weights[target_index])
        intercepted_par_w += weight * absorbed_par
        intercepted_nir_w += weight * absorbed_nir
        mean_lost_par_numerator += weight * lost_par
        mean_lost_nir_numerator += weight * lost_nir
    end

    target_slot_count_t = T(target_slot_count)
    mean_target_leaf_area = weighted_leaf_area / target_slot_count_t
    expansion_factor = if use_stand > 0
        iszero(mean_target_leaf_area) ? zero(T) :
        (current_stand_lai / current_stocking / mean_target_leaf_area) *
        T(div(total_tree_count, target_slot_count))
    else
        one(T)
    end

    intercepted_par_w_m2 =
        expansion_factor * intercepted_par_w / plot_area
    intercepted_nir_w_m2 =
        expansion_factor * intercepted_nir_w / plot_area
    mean_lost_par_w_m2 = mean_lost_par_numerator / target_slot_count_t
    mean_lost_nir_w_m2 = mean_lost_nir_numerator / target_slot_count_t

    return SoilShortwaveRadiationResult(
        max(
            incident_par - intercepted_par_w_m2 - mean_lost_par_w_m2,
            zero(T),
        ),
        max(
            incident_nir - intercepted_nir_w_m2 - mean_lost_nir_w_m2,
            zero(T),
        ),
        intercepted_par_w_m2,
        intercepted_nir_w_m2,
    )
end

"""
PlantSimEngine wrapper for the shortwave-only `SCALEUP → GETRGLOB` slice.

The model stores legacy plot and target-selection parameters, but converts all
floating-point parameters to the runtime output type. Consequently
`CompositeModel(...; type_promotion=Dict(Float64 => Float32))` controls this
calculation without hard-coding `Float32` in the scientific kernel.

An active target with either upstream availability flag false leaves the
public outputs reset and unavailable. At night, below the historical PAR
threshold, or for a leafless target, the upstream branch is intentionally
inactive and its zero contribution can still produce a valid soil flux. In
addition to the soil fluxes, the wrapper publishes the expanded overstorey
canopy absorption for PAR and NIR in W m⁻² of ground.
"""
struct MAESPASoilShortwaveRadiation{T<:AbstractFloat,W<:Tuple} <:
       AbstractSoil_Shortwave_RadiationModel
    target_weights::W
    total_tree_count::Int
    stocking::T
    water_balance_area::T
    use_stand::Int
end

function MAESPASoilShortwaveRadiation(
    ::Type{T}=Float64;
    target_weights,
    total_tree_count,
    stocking,
    water_balance_area,
    use_stand,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the soil-shortwave numeric type must be concrete"),
    )
    weights = _soil_shortwave_target_weights(target_weights)
    total_tree_count isa Integer && !(total_tree_count isa Bool) ||
        _throw_soil_shortwave_value(
            :total_tree_count,
            total_tree_count,
            :integer,
        )
    total_tree_count > 0 ||
        _throw_soil_shortwave_value(
            :total_tree_count,
            total_tree_count,
            :positive,
        )
    use_stand isa Integer && !(use_stand isa Bool) ||
        _throw_soil_shortwave_value(:use_stand, use_stand, :integer)
    use_stand in 0:2 ||
        _throw_soil_shortwave_value(:use_stand, use_stand, :selection)
    converted_stocking = _soil_shortwave_positive(
        _soil_shortwave_float(T, stocking, :stocking),
        :stocking,
    )
    converted_area = _soil_shortwave_positive(
        _soil_shortwave_float(
            T,
            water_balance_area,
            :water_balance_area,
        ),
        :water_balance_area,
    )
    return MAESPASoilShortwaveRadiation{T,typeof(weights)}(
        weights,
        Int(total_tree_count),
        converted_stocking,
        converted_area,
        Int(use_stand),
    )
end

PlantSimEngine.inputs_(::MAESPASoilShortwaveRadiation) = (
    target_leaf_area_contributions_m2=PlantSimEngine.Required(AbstractVector),
    absorbed_par_crown_w=PlantSimEngine.Required(AbstractVector),
    absorbed_nir_crown_w=PlantSimEngine.Required(AbstractVector),
    scattered_lost_shortwave_w_m2=PlantSimEngine.Required(AbstractVector),
    crown_radiation_aggregation_available=PlantSimEngine.Required(AbstractVector),
    shortwave_scattering_available=PlantSimEngine.Required(AbstractVector),
    incident_par_w_m2=PlantSimEngine.Required(Real),
    incident_nir_w_m2=PlantSimEngine.Required(Real),
    stand_lai=PlantSimEngine.Required(Real),
    astronomical_daylight=PlantSimEngine.Required(Bool),
)

PlantSimEngine.variable_contracts_(::MAESPASoilShortwaveRadiation) = (
    incident_par_w_m2=HORIZONTAL_PAR_IRRADIANCE_CONTRACT,
    scattered_lost_shortwave_w_m2=SCATTERED_LOST_SHORTWAVE_CONTRACT,
    shortwave_scattering_available=SHORTWAVE_SCATTERING_AVAILABLE_CONTRACT,
)

function PlantSimEngine.outputs_(
    model::MAESPASoilShortwaveRadiation{T},
) where {T}
    target_count = length(model.target_weights)
    return (
        soil_absorbed_par_w_m2=zero(T),
        soil_absorbed_nir_w_m2=zero(T),
        canopy_absorbed_par_w_m2_ground=zero(T),
        canopy_absorbed_nir_w_m2_ground=zero(T),
        soil_shortwave_radiation_available=false,
        soil_shortwave_scattered_lost_by_target_buffer_w_m2=
            zeros(T, target_count, 2),
        soil_shortwave_active_target_buffer=fill(false, target_count),
    )
end

@inline function _reset_soil_shortwave_radiation!(status, ::Type{T}) where {T}
    status.soil_absorbed_par_w_m2 = zero(T)
    status.soil_absorbed_nir_w_m2 = zero(T)
    status.canopy_absorbed_par_w_m2_ground = zero(T)
    status.canopy_absorbed_nir_w_m2_ground = zero(T)
    status.soil_shortwave_radiation_available = false
    fill!(
        status.soil_shortwave_scattered_lost_by_target_buffer_w_m2,
        zero(T),
    )
    fill!(status.soil_shortwave_active_target_buffer, false)
    return nothing
end

@noinline function _throw_soil_shortwave_eltype(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and soil-shortwave output buffers must share a numeric type",
        ),
    )
end

@inline function _require_soil_shortwave_eltype(
    values,
    ::Type{T},
    name::Symbol,
) where {T<:AbstractFloat}
    eltype(values) === T || _throw_soil_shortwave_eltype(name)
    return nothing
end

@inline function _require_soil_shortwave_target_length(
    values,
    target_count::Int,
    name::Symbol,
)
    length(values) == target_count || throw(
        DimensionMismatch("$(String(name)) must contain $target_count values"),
    )
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPASoilShortwaveRadiation,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.soil_absorbed_par_w_m2)
    T <: AbstractFloat || throw(
        ArgumentError("soil_absorbed_par_w_m2 must use an AbstractFloat type"),
    )
    _reset_soil_shortwave_radiation!(status, T)
    typeof(status.soil_absorbed_nir_w_m2) === T ||
        _throw_soil_shortwave_eltype(:soil_absorbed_nir_w_m2)
    typeof(status.canopy_absorbed_par_w_m2_ground) === T ||
        _throw_soil_shortwave_eltype(:canopy_absorbed_par_w_m2_ground)
    typeof(status.canopy_absorbed_nir_w_m2_ground) === T ||
        _throw_soil_shortwave_eltype(:canopy_absorbed_nir_w_m2_ground)

    lost_buffer =
        status.soil_shortwave_scattered_lost_by_target_buffer_w_m2
    active_buffer = status.soil_shortwave_active_target_buffer
    _require_soil_shortwave_eltype(
        lost_buffer,
        T,
        :soil_shortwave_scattered_lost_by_target_buffer_w_m2,
    )
    active_buffer isa AbstractVector{Bool} || throw(
        ArgumentError("soil_shortwave_active_target_buffer must contain Bool values"),
    )

    target_count = length(model.target_weights)
    size(lost_buffer) == (target_count, 2) || throw(
        DimensionMismatch(
            "soil-shortwave lost-radiation buffer must have size ($target_count, 2)",
        ),
    )
    _require_soil_shortwave_target_length(
        active_buffer,
        target_count,
        :soil_shortwave_active_target_buffer,
    )
    for (values, name) in (
        (
            status.target_leaf_area_contributions_m2,
            :target_leaf_area_contributions_m2,
        ),
        (status.absorbed_par_crown_w, :absorbed_par_crown_w),
        (status.absorbed_nir_crown_w, :absorbed_nir_crown_w),
    )
        _require_soil_shortwave_eltype(values, T, name)
        _require_soil_shortwave_target_length(values, target_count, name)
    end
    for (values, name) in (
        (
            status.scattered_lost_shortwave_w_m2,
            :scattered_lost_shortwave_w_m2,
        ),
        (
            status.crown_radiation_aggregation_available,
            :crown_radiation_aggregation_available,
        ),
        (
            status.shortwave_scattering_available,
            :shortwave_scattering_available,
        ),
    )
        _require_soil_shortwave_target_length(values, target_count, name)
    end

    daylight = status.astronomical_daylight
    daylight isa Bool || throw(
        ArgumentError("astronomical_daylight must be Bool"),
    )
    incident_par = _soil_shortwave_nonnegative(
        _soil_shortwave_float(T, status.incident_par_w_m2, :incident_par_w_m2),
        :incident_par_w_m2,
    )
    incident_nir = _soil_shortwave_nonnegative(
        _soil_shortwave_float(T, status.incident_nir_w_m2, :incident_nir_w_m2),
        :incident_nir_w_m2,
    )
    daytime_radiation = daylight && incident_par > one(T)

    for target_index in 1:target_count
        leaf_area = status.target_leaf_area_contributions_m2[target_index]
        isfinite(leaf_area) || _throw_soil_shortwave_value(
            :target_leaf_area_contributions_m2,
            leaf_area,
            :finite,
        )
        leaf_area >= zero(T) || _throw_soil_shortwave_value(
            :target_leaf_area_contributions_m2,
            leaf_area,
            :nonnegative,
        )
        active = daytime_radiation && leaf_area > zero(T)
        active_buffer[target_index] = active
        active || continue

        aggregation_available =
            status.crown_radiation_aggregation_available[target_index]
        scattering_available =
            status.shortwave_scattering_available[target_index]
        aggregation_available isa Bool || throw(
            ArgumentError(
                "crown_radiation_aggregation_available values must be Bool",
            ),
        )
        scattering_available isa Bool || throw(
            ArgumentError("shortwave_scattering_available values must be Bool"),
        )
        aggregation_available && scattering_available || return nothing

        lost = status.scattered_lost_shortwave_w_m2[target_index]
        lost isa AbstractMatrix || throw(
            ArgumentError(
                "scattered_lost_shortwave_w_m2 values must be matrices",
            ),
        )
        size(lost, 1) > 0 || throw(
            DimensionMismatch(
                "each scattered_lost_shortwave_w_m2 matrix needs at least one point row",
            ),
        )
        size(lost, 2) == 2 || throw(
            DimensionMismatch(
                "each scattered_lost_shortwave_w_m2 matrix must have two spectral columns",
            ),
        )
        _require_soil_shortwave_eltype(
            lost,
            T,
            :scattered_lost_shortwave_w_m2,
        )
        lost_par = zero(T)
        lost_nir = zero(T)
        for point_index in axes(lost, 1)
            point_lost_par = lost[point_index, 1]
            point_lost_nir = lost[point_index, 2]
            for (value, name) in (
                (point_lost_par, :scattered_lost_par_w_m2),
                (point_lost_nir, :scattered_lost_nir_w_m2),
            )
                isfinite(value) ||
                    _throw_soil_shortwave_value(name, value, :finite)
                value >= zero(T) ||
                    _throw_soil_shortwave_value(name, value, :nonnegative)
            end
            lost_par += point_lost_par
            lost_nir += point_lost_nir
        end
        point_count = T(size(lost, 1))
        lost_buffer[target_index, 1] = lost_par / point_count
        lost_buffer[target_index, 2] = lost_nir / point_count
    end

    result = soil_shortwave_radiation(
        status.target_leaf_area_contributions_m2,
        status.absorbed_par_crown_w,
        status.absorbed_nir_crown_w,
        lost_buffer;
        target_weights=model.target_weights,
        active_targets=active_buffer,
        incident_par_w_m2=incident_par,
        incident_nir_w_m2=incident_nir,
        stand_lai=_soil_shortwave_float(T, status.stand_lai, :stand_lai),
        stocking=convert(T, model.stocking),
        total_tree_count=model.total_tree_count,
        water_balance_area=convert(T, model.water_balance_area),
        use_stand=model.use_stand,
    )
    status.soil_absorbed_par_w_m2 = result.soil_absorbed_par_w_m2
    status.soil_absorbed_nir_w_m2 = result.soil_absorbed_nir_w_m2
    status.canopy_absorbed_par_w_m2_ground =
        result.canopy_absorbed_par_w_m2_ground
    status.canopy_absorbed_nir_w_m2_ground =
        result.canopy_absorbed_nir_w_m2_ground
    status.soil_shortwave_radiation_available = true
    return nothing
end
