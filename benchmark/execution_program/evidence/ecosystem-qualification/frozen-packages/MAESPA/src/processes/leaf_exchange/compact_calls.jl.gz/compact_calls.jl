# Crown coordination of independent scalar energy models. Each accepted input
# snapshot can be replayed without exposing the energy solver's temporaries.
struct LeafEnergyCalls{C}
    targets::C
end

function _leaf_energy_calls(context)
    targets = collect(PlantSimEngine.call_targets(context, :energy_balance))
    sort!(targets; by=target -> target.status.logical_leaf_unit_index)
    return LeafEnergyCalls(targets)
end

function _leaf_biochemistry_inputs(unit, temperature, surface_co2, forcing, vectors, factor;
                                  emax_active=false)
    return (
        leaf_temperature_c=temperature,
        jmax25_umol_m2_s=vectors.logical_leaf_jmax25_umol_m2_s[unit],
        vcmax25_umol_m2_s=vectors.logical_leaf_vcmax25_umol_m2_s[unit],
        rd0_umol_m2_s=vectors.logical_leaf_rd0_umol_m2_s[unit],
        leaf_respiration_temperature_coefficient_c_inverse=forcing.leaf_respiration_temperature_coefficient_c_inverse,
        weighted_soil_water_potential_mpa=forcing.weighted_soil_water_potential_mpa,
        absorbed_par_umol_m2_s=vectors.logical_leaf_absorbed_par_umol_m2_s[unit],
        surface_co2_umol_mol=surface_co2,
        quantum_yield=vectors.logical_leaf_quantum_yield[unit],
        stomatal_g0=forcing.stomatal_g0, stomatal_g1=forcing.stomatal_g1,
        stomatal_g20=forcing.stomatal_g20, stomatal_g21=forcing.stomatal_g21,
        minimum_stomatal_conductance_mol_co2_m2_s=forcing.minimum_stomatal_conductance_mol_co2_m2_s,
        stomatal_co2_compensation_point_umol_mol=forcing.co2_compensation_point_umol_mol,
        minimum_vpd_pa=forcing.minimum_vpd_pa,
        soil_water_stomatal_modifier=one(temperature),
        hydraulic_stomatal_factor=factor,
        emax_non_tuzet_constraint_active=emax_active,
        soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa=forcing.soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
        maximum_leaf_transpiration_mmol_m2_leaf_s=forcing.maximum_leaf_transpiration_mmol_m2_leaf_s,
        second_stomatal_curve=forcing.second_stomatal_curve,
        astronomical_daylight=true,
        leaf_radiative_forcing_available=true,
        photosynthetic_capacity_inputs_available=true,
    )
end

_project_leaf_trial_inputs(::Nothing, inputs::NamedTuple) = inputs
function _project_leaf_trial_inputs(::Val{names}, inputs::NamedTuple) where {names}
    return NamedTuple{names}(ntuple(index -> getproperty(inputs, names[index]), length(names)))
end

# The optional candidate is a Crown-owned trial value, not a reconstructed
# soil potential or an extra field in the historical 39-input payload.
_project_leaf_trial_inputs(::Nothing, inputs::NamedTuple, candidate) = inputs
function _project_leaf_trial_inputs(::Val{names}, inputs::NamedTuple, candidate) where {names}
    return NamedTuple{names}(ntuple(length(names)) do index
        name = names[index]
        name === :candidate_leaf_water_potential_mpa ? candidate : getproperty(inputs, name)
    end)
end

function _leaf_energy_inputs(model, ::Type{T}, unit, candidate, forcing, vectors) where {T}
    tuzet = model isa MAESPATuzetCrownLeafExchangeController
    factor = tuzet && forcing.leaf_exchange_daylight ?
        _leaf_tuzet_stomatal_factor(candidate,
            T(model.hydraulic_closure_model.sensitivity_factor_mpa_inverse),
            T(model.hydraulic_closure_model.reference_water_potential_mpa)) : one(T)
    physiology = _leaf_biochemistry_inputs(unit, forcing.air_temperature_c,
        forcing.co2_umol_mol, forcing, vectors, factor;
        emax_active=!tuzet && forcing.emax_non_tuzet_constraint_active)
    inputs = merge(physiology, (
        characteristic_leaf_width_m=forcing.characteristic_leaf_width_m,
        stomatal_sides=forcing.stomatal_sides,
        saturation_vapour_pressure_slope_pa_k=forcing.saturation_vapour_pressure_slope_pa_k,
        latent_heat_vaporization_j_mol=forcing.latent_heat_vaporization_j_mol,
        dry_canopy_fraction=forcing.dry_canopy_fraction,
        canopy_surface_water_storage_mm=forcing.canopy_surface_water_storage_mm,
        leaf_net_radiation_w_m2=vectors.logical_leaf_net_radiation_w_m2[unit],
        relative_wind_speed=vectors.logical_leaf_relative_wind_speed[unit],
        relative_diffuse_penetration=vectors.logical_leaf_relative_diffuse_penetration[unit],
        diffuse_transmittance_up=vectors.logical_leaf_diffuse_transmittance_up[unit],
        diffuse_transmittance_down=vectors.logical_leaf_diffuse_transmittance_down[unit],
        night_stomatal_conductance_mol_co2_m2_s=forcing.night_stomatal_conductance_mol_co2_m2_s,
        astronomical_daylight=forcing.leaf_exchange_daylight,
        leaf_energy_balance_controller_active=true,
        leaf_energy_balance_controller_inputs_available=true,
    ))
    # The selected graph fixes this projection at construction. Trials and
    # accepted replay carry the same snapshot; no status/schema probing occurs.
    return _project_leaf_trial_inputs(model.trial_input_projection, inputs, candidate)
end

function _publish_leaf_solution!(calls::LeafEnergyCalls, unit::Int, solution, daylight::Bool)
    target = calls.targets[unit]
    _set_leaf_trial_inputs!(target.status, solution.replay)
    PlantSimEngine.run_call!(target; publish=true)
    return nothing
end

# Public scalar energy outputs become area-based Crown vectors. Mol-to-µmol
# conversions are explicit here; hydraulic quantities are supplied by the
# outer closure rather than recomputed in the scalar energy model.
function _coupled_crown_values(solution)
    e = solution.exchange
    micromoles = oftype(e.accepted_potential_dry_transpiration_mol_h2o_m2_s, 1e6)
    return (
        net_assimilation_umol_co2_m2_s=e.accepted_net_assimilation_umol_co2_m2_s,
        rd_umol_m2_s=e.accepted_rd_umol_m2_s,
        actual_transpiration_umol_h2o_m2_s=e.accepted_actual_transpiration_umol_h2o_m2_s,
        actual_wet_surface_evaporation_umol_h2o_m2_s=e.accepted_actual_wet_surface_evaporation_umol_h2o_m2_s,
        sensible_heat_flux_w_m2=e.accepted_sensible_heat_flux_w_m2,
        stomatal_conductance_co2_mol_m2_s=e.accepted_stomatal_conductance_co2_mol_m2_s,
        boundary_layer_heat_conductance_mol_m2_s=e.accepted_boundary_layer_heat_conductance_mol_m2_s,
        temperature_c=e.accepted_leaf_temperature_c,
        intercellular_co2_umol_mol=e.accepted_intercellular_co2_umol_mol,
        water_potential_mpa=solution.leaf_water_potential,
        potential_dry_transpiration_umol_h2o_m2_s=e.accepted_potential_dry_transpiration_mol_h2o_m2_s * micromoles,
        potential_wet_surface_evaporation_umol_h2o_m2_s=e.accepted_potential_wet_surface_evaporation_mol_h2o_m2_s * micromoles,
        transpiration_deficit_mmol_h2o_m2_s=solution.transpiration_deficit,
    )
end

function _store_coupled_leaf_solution!(result::NonTuzetCrownLeafExchangeControllerResult, unit, solution)
    for (name, value) in pairs(_coupled_crown_values(solution))
        getproperty(result, Symbol("non_tuzet_accepted_logical_leaf_", name))[unit] = value
    end
    result.non_tuzet_logical_leaf_temperature_trial_count[unit] = solution.temperature_trial_count
    result.non_tuzet_logical_leaf_temperature_converged[unit] = solution.temperature_converged
    result.non_tuzet_logical_leaf_temperature_iteration_limit_reached[unit] = solution.temperature_iteration_limit_reached
    result.non_tuzet_logical_leaf_hydraulic_limitation_applied[unit] = solution.exchange.accepted_hydraulic_limitation_applied
    result.non_tuzet_logical_leaf_exchange_available[unit] = true
    return nothing
end

function _store_coupled_leaf_solution!(result::TuzetCrownLeafExchangeControllerResult, unit, solution, root, daylight)
    for (name, value) in pairs(_coupled_crown_values(solution))
        getproperty(result, Symbol("accepted_logical_leaf_", name))[unit] = value
    end
    _store_tuzet_hydraulic_diagnostics!(result, unit, solution, root, daylight)
    return nothing
end
