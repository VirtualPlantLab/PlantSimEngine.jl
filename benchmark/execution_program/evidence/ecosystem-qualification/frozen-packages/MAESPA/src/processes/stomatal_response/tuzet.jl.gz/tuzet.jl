"""
Historical Tuzet response (`MODELGS=6`) using the supplied `FPSIF` hydraulic
multiplier. Leaf-water-potential root finding belongs to the enclosing solver.
"""
struct MAESPATuzetResponse{T} <: AbstractStomatal_ResponseModel end

MAESPATuzetResponse(::Type{T}=Float64) where {T} = MAESPATuzetResponse{T}()

PlantSimEngine.outputs_(::MAESPATuzetResponse{T}) where {T} = (
    primary_stomatal_response_slope=zero(T),
    secondary_stomatal_response_slope=zero(T),
)

function PlantSimEngine.run!(::MAESPATuzetResponse, status, environment, constants, context)
    Cs = status.surface_co2_umol_mol
    Γ = status.stomatal_co2_compensation_point_umol_mol
    fψ = status.hydraulic_stomatal_factor
    status.primary_stomatal_response_slope = status.stomatal_g1 / (Cs - Γ) * fψ
    status.secondary_stomatal_response_slope = status.second_stomatal_curve ?
        status.stomatal_g21 / (Cs - Γ) * fψ : zero(Cs)
    return nothing
end

PlantSimEngine.Authoring.model_metadata(::MAESPATuzetResponse) = (
    hypothesis="Tuzet response to an externally resolved leaf-hydraulic multiplier.",
    reference="MAESPA physiol.f90, PSTRANSP MODELGS=6",
    maturity=:legacy_reimplementation,
    validation=:legacy_checkpoints_and_structural_tests,
)
