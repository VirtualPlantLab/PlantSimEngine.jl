PlantSimEngine.@process "maintenance_respiration" verbose = false

"""
One evaluation of MAESPA's historical maintenance-respiration equation.

`specific_respiration_umol_per_unit_s` uses the denominator of
`base_respiration_rate_umol_per_unit_s`: leaf area for foliage and dry mass
for woody or root tissues. `maintenance_respiration_umol_s` multiplies this
rate by the matching `respiring_quantity`.
"""
struct MaintenanceRespirationResult{T<:AbstractFloat}
    acclimated_base_respiration_umol_per_unit_s::T
    specific_respiration_umol_per_unit_s::T
    maintenance_respiration_umol_s::T
    temperature_response_active::Bool
end

@noinline function _throw_maintenance_respiration_numeric(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :result
        throw(DomainError(value, "maintenance respiration must be finite"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _maintenance_respiration_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real ||
        _throw_maintenance_respiration_numeric(name, value, :real)
    value isa Bool &&
        _throw_maintenance_respiration_numeric(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_maintenance_respiration_numeric(name, converted, :finite)
    return converted
end

@inline function _maintenance_respiration_nonnegative(
    value::T,
    name::Symbol,
) where {T}
    value >= zero(T) ||
        _throw_maintenance_respiration_numeric(name, value, :nonnegative)
    return value
end

"""
    MAESPAMaintenanceRespiration(T=Float64; kwargs...)

Typed constants for the historical Fortran `RESP` function.

Despite its name, `temperature_response_coefficient_c_inverse` is the legacy
`Q10F`, `Q10W`, `Q10B`, or `Q10R` value already expressed as an exponential
coefficient in °C⁻¹. The executable equation is

```text
RD0ACC = RD0 * exp(K10 * (TMOVE - RTEMP))
RESP   = RD0ACC * exp(Q10 * (TTISSUE - RTEMP)) * multiplier
```

when `TTISSUE >= TBELOW`, and zero otherwise. The multiplier is
`daytime_respiration_multiplier` by day and one at night, matching the MAESPA
call sites. Use a multiplier of one for stem, branch, and root respiration.

The model deliberately stops before `CALCRMW`, biomass trajectories, growth
respiration (`GRESP`), or daily aggregation. It can therefore be mounted on a
leaf, stem, branch, or root object, provided the base-rate denominator and
`respiring_quantity` are consistent.
"""
struct MAESPAMaintenanceRespiration{T<:AbstractFloat} <:
       AbstractMaintenance_RespirationModel
    acclimation_coefficient_c_inverse::T
    reference_temperature_c::T
    minimum_temperature_c::T
    daytime_respiration_multiplier::T
end

function MAESPAMaintenanceRespiration(
    ::Type{T}=Float64;
    acclimation_coefficient_c_inverse=0,
    reference_temperature_c=0,
    minimum_temperature_c=-100,
    daytime_respiration_multiplier=1,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the maintenance-respiration numeric type must be concrete"),
    )
    acclimation = _maintenance_respiration_float(
        T,
        acclimation_coefficient_c_inverse,
        :acclimation_coefficient_c_inverse,
    )
    reference_temperature = _maintenance_respiration_float(
        T,
        reference_temperature_c,
        :reference_temperature_c,
    )
    minimum_temperature = _maintenance_respiration_float(
        T,
        minimum_temperature_c,
        :minimum_temperature_c,
    )
    daytime_multiplier = _maintenance_respiration_nonnegative(
        _maintenance_respiration_float(
            T,
            daytime_respiration_multiplier,
            :daytime_respiration_multiplier,
        ),
        :daytime_respiration_multiplier,
    )
    return MAESPAMaintenanceRespiration{T}(
        acclimation,
        reference_temperature,
        minimum_temperature,
        daytime_multiplier,
    )
end

@inline function _maintenance_respiration(
    model::MAESPAMaintenanceRespiration,
    ::Type{T},
    base_respiration_rate_umol_per_unit_s::T,
    temperature_response_coefficient_c_inverse::T,
    tissue_temperature_c::T,
    moving_average_temperature_c::T,
    respiring_quantity::T,
    is_daylight::Bool,
) where {T<:AbstractFloat}
    base_rate = _maintenance_respiration_nonnegative(
        base_respiration_rate_umol_per_unit_s,
        :base_respiration_rate_umol_per_unit_s,
    )
    quantity = _maintenance_respiration_nonnegative(
        respiring_quantity,
        :respiring_quantity,
    )
    temperature_coefficient = _maintenance_respiration_float(
        T,
        temperature_response_coefficient_c_inverse,
        :temperature_response_coefficient_c_inverse,
    )
    tissue_temperature = _maintenance_respiration_float(
        T,
        tissue_temperature_c,
        :tissue_temperature_c,
    )
    moving_temperature = _maintenance_respiration_float(
        T,
        moving_average_temperature_c,
        :moving_average_temperature_c,
    )
    acclimation_coefficient = _maintenance_respiration_float(
        T,
        model.acclimation_coefficient_c_inverse,
        :acclimation_coefficient_c_inverse,
    )
    reference_temperature = _maintenance_respiration_float(
        T,
        model.reference_temperature_c,
        :reference_temperature_c,
    )
    minimum_temperature = _maintenance_respiration_float(
        T,
        model.minimum_temperature_c,
        :minimum_temperature_c,
    )
    daytime_multiplier = _maintenance_respiration_nonnegative(
        _maintenance_respiration_float(
            T,
            model.daytime_respiration_multiplier,
            :daytime_respiration_multiplier,
        ),
        :daytime_respiration_multiplier,
    )

    # The comparison is inclusive in the Fortran (`.GE.`). The legacy
    # RD0ACC argument is left stale below TBELOW; this stateless process
    # publishes zero instead of exposing that undefined side effect.
    if tissue_temperature < minimum_temperature
        return MaintenanceRespirationResult{T}(
            zero(T),
            zero(T),
            zero(T),
            false,
        )
    end

    acclimated_base_rate =
        base_rate * exp(
            acclimation_coefficient *
            (moving_temperature - reference_temperature),
        )
    multiplier = is_daylight ? daytime_multiplier : one(T)
    specific_rate =
        acclimated_base_rate *
        exp(
            temperature_coefficient *
            (tissue_temperature - reference_temperature),
        ) *
        multiplier
    total_respiration = specific_rate * quantity
    values = (acclimated_base_rate, specific_rate, total_respiration)
    all(isfinite, values) || _throw_maintenance_respiration_numeric(
        :maintenance_respiration,
        values,
        :result,
    )
    return MaintenanceRespirationResult{T}(
        values...,
        true,
    )
end

"""
    maintenance_respiration(
        base_respiration_rate_umol_per_unit_s,
        temperature_response_coefficient_c_inverse,
        tissue_temperature_c,
        moving_average_temperature_c,
        respiring_quantity;
        is_daylight=true,
        kwargs...,
    )

Evaluate the isolated MAESPA `RESP` equation and scale it by a matching leaf
area or dry biomass. Dynamic numeric arguments are promoted together; model
constants are then constructed in that type.
"""
function maintenance_respiration(
    base_respiration_rate_umol_per_unit_s,
    temperature_response_coefficient_c_inverse,
    tissue_temperature_c,
    moving_average_temperature_c,
    respiring_quantity;
    is_daylight=true,
    kwargs...,
)
    raw_values = (
        base_respiration_rate_umol_per_unit_s,
        temperature_response_coefficient_c_inverse,
        tissue_temperature_c,
        moving_average_temperature_c,
        respiring_quantity,
    )
    names = (
        :base_respiration_rate_umol_per_unit_s,
        :temperature_response_coefficient_c_inverse,
        :tissue_temperature_c,
        :moving_average_temperature_c,
        :respiring_quantity,
    )
    for (value, name) in zip(raw_values, names)
        value isa Real ||
            _throw_maintenance_respiration_numeric(name, value, :real)
        value isa Bool &&
            _throw_maintenance_respiration_numeric(name, value, :bool)
    end
    is_daylight isa Bool || throw(ArgumentError("is_daylight must be Bool"))
    promoted = promote(map(float, raw_values)...)
    T = typeof(first(promoted))
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "maintenance-respiration inputs must promote to a concrete AbstractFloat",
        ),
    )
    converted = map(
        (value, name) -> _maintenance_respiration_float(T, value, name),
        promoted,
        names,
    )
    return _maintenance_respiration(
        MAESPAMaintenanceRespiration(T; kwargs...),
        T,
        converted...,
        is_daylight,
    )
end

PlantSimEngine.inputs_(::MAESPAMaintenanceRespiration) = (
    base_respiration_rate_umol_per_unit_s=PlantSimEngine.Required(Real),
    temperature_response_coefficient_c_inverse=PlantSimEngine.Required(Real),
    tissue_temperature_c=PlantSimEngine.Required(Real),
    moving_average_temperature_c=PlantSimEngine.Required(Real),
    respiring_quantity=PlantSimEngine.Default(1.0),
    is_daylight=PlantSimEngine.Default(true),
    maintenance_respiration_inputs_available=PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(::MAESPAMaintenanceRespiration{T}) where {T} = (
    acclimated_base_respiration_umol_per_unit_s=zero(T),
    specific_respiration_umol_per_unit_s=zero(T),
    maintenance_respiration_umol_s=zero(T),
    maintenance_respiration_temperature_active=false,
    maintenance_respiration_available=false,
)

@inline function _reset_maintenance_respiration!(status, ::Type{T}) where {T}
    status.acclimated_base_respiration_umol_per_unit_s = zero(T)
    status.specific_respiration_umol_per_unit_s = zero(T)
    status.maintenance_respiration_umol_s = zero(T)
    status.maintenance_respiration_temperature_active = false
    status.maintenance_respiration_available = false
    return nothing
end

@noinline function _throw_maintenance_respiration_output_type(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and maintenance-respiration output carriers " *
            "must share a floating-point type",
        ),
    )
end

function PlantSimEngine.run!(
    model::MAESPAMaintenanceRespiration,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.maintenance_respiration_umol_s)
    T <: AbstractFloat || _throw_maintenance_respiration_output_type(
        :maintenance_respiration_umol_s,
    )
    _reset_maintenance_respiration!(status, T)
    for name in (
        :acclimated_base_respiration_umol_per_unit_s,
        :specific_respiration_umol_per_unit_s,
    )
        typeof(getproperty(status, name)) === T ||
            _throw_maintenance_respiration_output_type(name)
    end

    available = status.maintenance_respiration_inputs_available
    available isa Bool || throw(
        ArgumentError("maintenance_respiration_inputs_available must be Bool"),
    )
    available || return nothing
    is_daylight = status.is_daylight
    is_daylight isa Bool || throw(ArgumentError("is_daylight must be Bool"))

    result = _maintenance_respiration(
        model,
        T,
        _maintenance_respiration_float(
            T,
            status.base_respiration_rate_umol_per_unit_s,
            :base_respiration_rate_umol_per_unit_s,
        ),
        _maintenance_respiration_float(
            T,
            status.temperature_response_coefficient_c_inverse,
            :temperature_response_coefficient_c_inverse,
        ),
        _maintenance_respiration_float(
            T,
            status.tissue_temperature_c,
            :tissue_temperature_c,
        ),
        _maintenance_respiration_float(
            T,
            status.moving_average_temperature_c,
            :moving_average_temperature_c,
        ),
        _maintenance_respiration_float(
            T,
            status.respiring_quantity,
            :respiring_quantity,
        ),
        is_daylight,
    )
    status.acclimated_base_respiration_umol_per_unit_s =
        result.acclimated_base_respiration_umol_per_unit_s
    status.specific_respiration_umol_per_unit_s =
        result.specific_respiration_umol_per_unit_s
    status.maintenance_respiration_umol_s =
        result.maintenance_respiration_umol_s
    status.maintenance_respiration_temperature_active =
        result.temperature_response_active
    status.maintenance_respiration_available = true
    return nothing
end
