# Shared horizontal-reference PAR contracts. W m^-2 is represented as
# joule_par per horizontal area per second; these are incident irradiances,
# not absorbed leaf fluxes, sunlit-area quantities or point-area totals.
const HORIZONTAL_PAR_IRRADIANCE_CONTRACT = PlantSimEngine.VariableContract(
    unit=:joule_par,
    basis=:horizontal_area,
    temporal=:second,
    aggregation=:local,
    extent=:intensive,
)

# Ratio of direct-beam PAR to total incident PAR on the same horizontal
# radiative reference. This is a local instantaneous fraction, not a sunlit
# leaf-area fraction or a canopy transmission coefficient.
const HORIZONTAL_PAR_BEAM_FRACTION_CONTRACT = PlantSimEngine.VariableContract(
    unit=:fraction,
    basis=:horizontal_area,
    temporal=:instantaneous,
    aggregation=:local,
    extent=:intensive,
)

const HORIZONTAL_PAR_FORCING_CONTRACTS = (
    incident_par_w_m2=HORIZONTAL_PAR_IRRADIANCE_CONTRACT,
    beam_fraction_par=HORIZONTAL_PAR_BEAM_FRACTION_CONTRACT,
)
