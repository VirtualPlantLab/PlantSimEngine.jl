"""
    SoilProfileStorageResult{T}

Storage totals for one ordered MAESPA soil profile, in millimetres of water
per square metre of ground. `rooted_profile_storage_mm` is zero when no rooted
layer count is available; `rooted_profile_storage_available` distinguishes
that case from a known profile with zero rooted layers.
"""
struct SoilProfileStorageResult{T<:AbstractFloat}
    total_profile_storage_mm::T
    rooted_profile_storage_mm::T
    active_unsaturated_storage_mm::T
    rooted_profile_storage_available::Bool
end

function _soil_profile_integer(value, name::AbstractString)
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError("$name must be an integer, not Bool"),
    )
    try
        return Int(value)
    catch exception
        exception isa InexactError || rethrow()
        throw(ArgumentError("$name must be representable as Int"))
    end
end

function _soil_profile_rooted_layer_count(value, layer_count::Int)
    isnothing(value) && return nothing
    rooted_layer_count = _soil_profile_integer(value, "rooted_layer_count")
    0 <= rooted_layer_count <= layer_count || throw(
        ArgumentError("rooted_layer_count must lie in 0:$layer_count"),
    )
    return rooted_layer_count
end

function _soil_profile_water_table_layer(value, layer_count::Int)
    isnothing(value) && return nothing
    water_table_layer = _soil_profile_integer(value, "water_table_layer")
    2 <= water_table_layer <= layer_count + 1 || throw(
        ArgumentError("water_table_layer must lie in 2:$(layer_count + 1)"),
    )
    return water_table_layer
end

function _soil_profile_storage_type(layer_storages_mm::AbstractVector)
    storage_type = eltype(layer_storages_mm)
    storage_type === Bool && throw(
        ArgumentError("layer_storages_mm must contain real numbers, not Bool"),
    )
    storage_type <: AbstractFloat && isconcretetype(storage_type) || throw(
        ArgumentError(
            "layer_storages_mm must have a concrete AbstractFloat element type",
        ),
    )
    return storage_type
end

"""
    soil_profile_storage(layer_indices, layer_storages_mm;
                         rooted_layer_count=nothing,
                         water_table_layer=nothing)

Aggregate per-layer storage without using the incidental order in which
PlantSimEngine selected the `SoilLayer` objects. `layer_indices` must contain
each one-based index in `1:n` exactly once, where `n` is the number of storage
values. Values are reordered by that index before summation, so object-id
ordering cannot change either the layer masks or floating-point summation
order.

Without a water table, every layer is active and unsaturated. With a water
table at layer `i`, only layers `1:(i - 1)` contribute to
`active_unsaturated_storage_mm`; the water-table layer and all deeper layers
are excluded. A water-table index of `n + 1` therefore denotes a table below
the represented profile and leaves every layer active.

The rooted mask is independent of the water-table mask. An unknown
`rooted_layer_count` publishes zero rooted storage with availability set to
`false`; known counts from zero through `n` are accepted.
"""
function soil_profile_storage(
    layer_indices::AbstractVector,
    layer_storages_mm::AbstractVector;
    rooted_layer_count=nothing,
    water_table_layer=nothing,
)
    layer_count = length(layer_indices)
    layer_count > 0 || throw(
        ArgumentError("a soil profile must contain at least one layer"),
    )
    length(layer_storages_mm) == layer_count || throw(
        DimensionMismatch(
            "layer_indices and layer_storages_mm must have the same length",
        ),
    )

    T = _soil_profile_storage_type(layer_storages_mm)
    rooted_count = _soil_profile_rooted_layer_count(
        rooted_layer_count,
        layer_count,
    )
    water_table = _soil_profile_water_table_layer(
        water_table_layer,
        layer_count,
    )

    ordered_storages = Vector{T}(undef, layer_count)
    seen = falses(layer_count)
    for position in eachindex(layer_indices, layer_storages_mm)
        layer_index = _soil_profile_integer(
            layer_indices[position],
            "layer_indices[$position]",
        )
        1 <= layer_index <= layer_count || throw(
            ArgumentError(
                "layer_indices[$position] must lie in 1:$layer_count",
            ),
        )
        seen[layer_index] && throw(
            ArgumentError("layer index $layer_index occurs more than once"),
        )

        storage = layer_storages_mm[position]
        storage isa Bool && throw(
            ArgumentError("layer_storages_mm[$position] must not be Bool"),
        )
        isfinite(storage) || throw(
            ArgumentError("layer_storages_mm[$position] must be finite"),
        )
        storage >= zero(T) || throw(
            DomainError(storage, "layer_storages_mm[$position] must be non-negative"),
        )
        ordered_storages[layer_index] = storage
        seen[layer_index] = true
    end
    all(seen) || throw(
        ArgumentError("layer_indices must contain every index in 1:$layer_count"),
    )

    total = zero(T)
    rooted = zero(T)
    active_unsaturated = zero(T)
    active_last = isnothing(water_table) ? layer_count : water_table - 1
    for layer_index in 1:layer_count
        storage = ordered_storages[layer_index]
        total += storage
        !isnothing(rooted_count) && layer_index <= rooted_count &&
            (rooted += storage)
        layer_index <= active_last && (active_unsaturated += storage)
    end
    isfinite(total) || throw(ArgumentError("total profile storage must be finite"))
    isfinite(rooted) || throw(ArgumentError("rooted profile storage must be finite"))
    isfinite(active_unsaturated) || throw(
        ArgumentError("active unsaturated profile storage must be finite"),
    )

    return SoilProfileStorageResult{T}(
        total,
        rooted,
        active_unsaturated,
        !isnothing(rooted_count),
    )
end

PlantSimEngine.@process "soil_profile_storage" verbose = false

"""
    MAESPASoilProfileStorage(T, layer_count;
                             rooted_layer_count=nothing,
                             water_table_layer=nothing)
    MAESPASoilProfileStorage(config; rooted_layer_count=nothing)

Shared, stateless PlantSimEngine model applied to a `Soil` object. Its two
vector inputs are intended to be bound with `Many` selectors over descendant
`SoilLayer` objects: the stable `layer_index` status and each layer hydraulic
model's `soil_layer_storage_mm` output.
"""
struct MAESPASoilProfileStorage{T<:AbstractFloat} <:
       AbstractSoil_Profile_StorageModel
    layer_count::Int
    rooted_layer_count::Union{Nothing,Int}
    water_table_layer::Union{Nothing,Int}
    zero_value::T
end

function MAESPASoilProfileStorage(
    ::Type{T},
    layer_count;
    rooted_layer_count=nothing,
    water_table_layer=nothing,
) where {T<:AbstractFloat}
    count = _soil_profile_integer(layer_count, "layer_count")
    count > 0 || throw(ArgumentError("layer_count must be positive"))
    rooted_count = _soil_profile_rooted_layer_count(rooted_layer_count, count)
    water_table = _soil_profile_water_table_layer(water_table_layer, count)
    return MAESPASoilProfileStorage{T}(
        count,
        rooted_count,
        water_table,
        zero(T),
    )
end

function MAESPASoilProfileStorage(
    config::SoilConfig{T};
    rooted_layer_count=nothing,
) where {T<:AbstractFloat}
    simulate_water_table = config.options.simulate_water_table
    simulate_water_table in (0, 1) || throw(
        ArgumentError("simulate_water_table must be either 0 or 1"),
    )
    water_table_layer = if simulate_water_table == 1
        isnothing(config.layers.water_table_layer) && throw(
            ArgumentError(
                "water_table_layer is required when the water table is active",
            ),
        )
        config.layers.water_table_layer
    else
        nothing
    end
    return MAESPASoilProfileStorage(
        T,
        config.layers.layer_count;
        rooted_layer_count,
        water_table_layer,
    )
end

PlantSimEngine.inputs_(::MAESPASoilProfileStorage) = (
    layer_indices=PlantSimEngine.Required(AbstractVector),
    soil_layer_storages_mm=PlantSimEngine.Required(AbstractVector),
)

PlantSimEngine.outputs_(model::MAESPASoilProfileStorage) = (
    total_profile_storage_mm=zero(model.zero_value),
    rooted_profile_storage_mm=zero(model.zero_value),
    active_unsaturated_storage_mm=zero(model.zero_value),
    rooted_profile_storage_available=!isnothing(model.rooted_layer_count),
)

function PlantSimEngine.run!(
    model::MAESPASoilProfileStorage,
    status,
    environment,
    constants,
    context,
)
    length(status.layer_indices) == model.layer_count || throw(
        DimensionMismatch(
            "layer_indices must contain $(model.layer_count) layer values",
        ),
    )
    result = soil_profile_storage(
        status.layer_indices,
        status.soil_layer_storages_mm;
        rooted_layer_count=model.rooted_layer_count,
        water_table_layer=model.water_table_layer,
    )
    status.total_profile_storage_mm = result.total_profile_storage_mm
    status.rooted_profile_storage_mm = result.rooted_profile_storage_mm
    status.active_unsaturated_storage_mm =
        result.active_unsaturated_storage_mm
    status.rooted_profile_storage_available =
        result.rooted_profile_storage_available
    return nothing
end
