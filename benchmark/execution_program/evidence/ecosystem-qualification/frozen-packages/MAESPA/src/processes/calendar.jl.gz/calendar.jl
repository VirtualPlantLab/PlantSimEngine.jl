const _LEGACY_MONTH_OFFSETS = (0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)

"""
A parsed MAESPA date together with its historical ordinal representation.

`days_since_1950` is one-based, matching the Fortran `IDATE50` convention.
`is_civil_valid` records whether the raw date is also a valid Gregorian date.
"""
struct LegacyDate
    raw::String
    day::Int
    month::Int
    year::Int
    day_of_year::Int
    days_since_1950::Int
    is_civil_valid::Bool
end

function _date_parts(text::AbstractString)
    matched = match(r"^(\d{2})/(\d{2})/(\d{2}|\d{4})$", strip(text))
    isnothing(matched) && throw(
        ArgumentError("expected a MAESPA date in DD/MM/YY or DD/MM/YYYY form, got $(repr(text))"),
    )
    return (
        parse(Int, matched.captures[1]),
        parse(Int, matched.captures[2]),
        String(matched.captures[3]),
    )
end

function _civil_date_valid(year::Int, month::Int, day::Int)
    try
        Date(year, month, day)
        return true
    catch exception
        exception isa ArgumentError || exception isa DomainError || rethrow()
        return false
    end
end

"""
    legacy_date(text; mode=:legacy)

Parse a historical MAESPA date. `mode=:legacy` reproduces the fixed-position
two-digit year pivot and ordinal arithmetic of `IDATEYR`/`IDATE50`, including
acceptance of dates such as `31/09/10`. `mode=:strict` validates a Gregorian
date and interprets a four-digit year in full.
"""
function legacy_date(text::AbstractString; mode::Symbol=:legacy)
    _check_input_mode(mode)
    day, month, year_text = _date_parts(text)

    if mode === :strict
        year = length(year_text) == 2 ? begin
            short_year = parse(Int, year_text)
            short_year < 50 ? 2000 + short_year : 1900 + short_year
        end : parse(Int, year_text)
        date = try
            Date(year, month, day)
        catch
            throw(ArgumentError("invalid civil date $(repr(text))"))
        end
        day_of_year = Dates.dayofyear(date)
        days_since_1950 = Dates.value(date - Date(1950, 1, 1)) + 1
        return LegacyDate(String(text), day, month, year, day_of_year, days_since_1950, true)
    end

    1 <= month <= 12 || throw(ArgumentError("month must be between 1 and 12 in $(repr(text))"))
    # The Fortran FORMAT(T1,I2,T4,I2,T7,I2) reads only the first two year
    # digits, even when a longer string is supplied.
    short_year = parse(Int, first(year_text, 2))
    internal_year = short_year < 50 ? short_year + 100 : short_year
    year = 1900 + internal_year
    leap_year = 4 * div(internal_year, 4) == internal_year
    day_of_year = _LEGACY_MONTH_OFFSETS[month] + day
    leap_year && month >= 3 && (day_of_year += 1)
    full_year_days = 365 * (internal_year - 50) + div(internal_year - 49, 4)
    days_since_1950 = full_year_days + day_of_year
    return LegacyDate(
        String(text),
        day,
        month,
        year,
        day_of_year,
        days_since_1950,
        _civil_date_valid(year, month, day),
    )
end

"""Historical MAESPA day-of-year calculation from a one-based `IDATE50`."""
function legacy_julian_day(days_since_1950::Integer)
    year_index = div(days_since_1950, 365)
    full_year_days = 365 * year_index + div(year_index - 1, 4)
    return days_since_1950 - full_year_days + 1
end

"""Historical astronomical day used by the MAESPA `SUN` routine."""
function legacy_dayjul(days_since_1950::Integer)
    julian_day = legacy_julian_day(days_since_1950)
    year = div((days_since_1950 - julian_day) * 100, 36525) + 1951
    day = float(julian_day)
    astronomical_year = year + 4712
    leap_days = div(astronomical_year - 1, 4)
    result = 365 * astronomical_year + leap_days + day
    if year >= 1583
        result -= 10
        result -= div(year - 1501, 100)
        result += div(year - 1201, 400)
    end
    year == 1582 && day >= 319 && (result -= 10)
    4 * div(year, 4) == year && julian_day >= 60 && (result += 1)
    return Int(result - 2415020)
end

PlantSimEngine.@process "legacy_calendar" verbose = false

function _checked_source_day_stride(value)
    value isa Integer && !(value isa Bool) || throw(ArgumentError(
        "DATES.NSTEP/source_day_stride must be a positive integer"))
    value > 0 || throw(ArgumentError(
        "DATES.NSTEP/source_day_stride must be positive, got $value"))
    return Int(value)
end

"""Validate a requested date on the configured source-day lattice."""
function _source_day_offset(start_date50::Integer, date50::Integer, source_day_stride)
    stride = _checked_source_day_stride(source_day_stride)
    offset = Int(date50) - Int(start_date50)
    offset >= 0 || throw(ArgumentError("requested date precedes the configured simulation start"))
    iszero(mod(offset, stride)) || throw(ArgumentError(
        "requested date50=$date50 is not visited by DATES.NSTEP=$stride " *
        "from configured start_date50=$start_date50"))
    return offset
end

"""
MAESPA's historical ordinal calendar as a stateful PlantSimEngine process.

`source_day_stride=1` visits consecutive days. A larger stride executes only
`start_date50 + k * source_day_stride`, using ordinary subdaily durations.
`simulation_step` starts at the zero-based source offset and publishes the
accepted one-based source position after each call. It jumps over omitted
days, unlike PlantSimEngine's dense execution counter. `simulation_day` is
actual elapsed source days, not the number of visited days. Keeping this
clock explicit preserves dated parameters, root age and IOTUTD refreshes.
"""
struct MAESPALegacyCalendar <: AbstractLegacy_CalendarModel
    start_date50::Int
    end_date50::Int
    steps_per_day::Int
    source_day_stride::Int

    function MAESPALegacyCalendar(
        start_date50::Integer,
        end_date50::Integer,
        steps_per_day::Integer,
        ;
        source_day_stride=1,
    )
        end_date50 >= start_date50 || throw(
            ArgumentError("end_date50 must be greater than or equal to start_date50"),
        )
        steps_per_day > 0 || throw(ArgumentError("steps_per_day must be positive"))
        stride = _checked_source_day_stride(source_day_stride)
        return new(Int(start_date50), Int(end_date50), Int(steps_per_day), stride)
    end
end

PlantSimEngine.inputs_(::MAESPALegacyCalendar) = NamedTuple()
PlantSimEngine.outputs_(model::MAESPALegacyCalendar) = (
    simulation_step=0,
    simulation_day=0,
    date50=model.start_date50,
    step_index=1,
    legacy_day_of_year=0,
    astronomical_day=0,
)

function _legacy_clock_position(model::MAESPALegacyCalendar, simulation_step::Integer)
    simulation_step >= 0 || throw(
        DomainError(simulation_step, "simulation_step must be non-negative"),
    )
    day_offset, step_offset = divrem(simulation_step, model.steps_per_day)
    final_day_offset = model.end_date50 - model.start_date50
    day_offset <= final_day_offset || throw(
        DomainError(
            simulation_step,
            "simulation step lies after the configured MAESPA end date",
        ),
    )
    omitted_offset = mod(day_offset, model.source_day_stride)
    if !iszero(omitted_offset)
        iszero(step_offset) || throw(DomainError(simulation_step,
            "simulation step lies within an omitted MAESPA source day"))
        # The preceding accepted day's last source position is also the
        # zero-based next position. Advance only that day boundary to the
        # next configured visit, never through the skipped day's physics.
        gap = model.source_day_stride - omitted_offset
        gap <= final_day_offset - day_offset || throw(DomainError(simulation_step,
            "simulation step lies after the final configured MAESPA visit"))
        day_offset += gap
    end
    date50 = model.start_date50 + day_offset
    return (
        date50=date50,
        simulation_day=day_offset,
        step_index=step_offset + 1,
    )
end

function PlantSimEngine.run!(
    model::MAESPALegacyCalendar,
    status,
    environment,
    constants,
    context,
)
    position = _legacy_clock_position(model, status.simulation_step)
    status.date50 = position.date50
    status.simulation_day = position.simulation_day
    status.step_index = position.step_index
    status.legacy_day_of_year = legacy_julian_day(status.date50)
    status.astronomical_day = legacy_dayjul(status.date50)
    status.simulation_step = position.simulation_day * model.steps_per_day +
                             position.step_index
    return nothing
end
