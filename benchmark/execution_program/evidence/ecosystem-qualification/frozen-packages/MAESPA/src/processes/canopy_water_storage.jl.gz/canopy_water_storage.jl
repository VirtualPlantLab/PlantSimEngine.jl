PlantSimEngine.@process "canopy_water_storage" verbose = false

"""Result of one historical MAESPA canopy-interception step."""
struct CanopyInterceptionResult{T<:AbstractFloat}
    canopy_water_storage_before_mm::T
    canopy_water_storage_mm::T
    canopy_water_storage_change_mm::T
    canopy_water_storage_correction_mm::T
    effective_throughfall_fraction::T
    direct_throughfall_mm::T
    canopy_drainage_mm::T
    canopy_evaporation_mm::T
    surface_water_mm::T
    dry_canopy_fraction::T
    mass_balance_residual_mm::T
    evaporation_residual_mm::T
    accepted_steps::Int
    rejected_steps::Int
    short_circuited::Bool
end

"""Raised when the adaptive canopy-storage integration cannot make progress."""
struct CanopyInterceptionConvergenceError{T<:AbstractFloat} <: Exception
    normalized_time::T
    canopy_water_storage_mm::T
    attempted_steps::Int
end

function Base.showerror(io::IO, exception::CanopyInterceptionConvergenceError)
    print(
        io,
        "canopy interception did not converge after ",
        exception.attempted_steps,
        " attempted steps at normalized time ",
        exception.normalized_time,
        " with canopy storage ",
        exception.canopy_water_storage_mm,
        " mm",
    )
end

function _canopy_interception_scalar(
    ::Type{T},
    value,
    name::AbstractString,
) where {T<:AbstractFloat}
    value isa Real && !(value isa Bool) || throw(
        ArgumentError("$name must be a real number, not Bool"),
    )
    converted = convert(T, value)
    isfinite(converted) || throw(ArgumentError("$name must be finite"))
    return converted
end

function _canopy_interception_parameters(
    ::Type{T},
    config::CanopyInterceptionConfig,
) where {T<:AbstractFloat}
    rutter_b = _canopy_interception_scalar(T, config.rutter_b, "rutter_b")
    rutter_d = _canopy_interception_scalar(T, config.rutter_d, "rutter_d")
    maximum_storage = _canopy_interception_scalar(
        T,
        config.maximum_storage,
        "maximum_storage",
    )
    throughfall = _canopy_interception_scalar(
        T,
        config.throughfall,
        "throughfall",
    )
    rutter_d > zero(T) || throw(
        DomainError(rutter_d, "rutter_d must be positive"),
    )
    maximum_storage >= zero(T) || throw(
        DomainError(maximum_storage, "maximum_storage must be non-negative"),
    )
    throughfall <= one(T) || throw(
        DomainError(throughfall, "throughfall must be at most one"),
    )
    return rutter_b, rutter_d, maximum_storage, throughfall
end

@inline function _canopy_interception_derivatives(
    storage::T,
    intercepted_precipitation::T,
    direct_throughfall::T,
    wet_canopy_evaporation::T,
    maximum_storage::T,
    total_leaf_area_index::T,
    rutter_b::T,
    rutter_d::T,
    timestep_minutes::T,
) where {T<:AbstractFloat}
    drainage = if storage > maximum_storage
        rutter_a = log(rutter_d) -
                   rutter_b * maximum_storage * total_leaf_area_index
        exp(rutter_a + rutter_b * storage) * timestep_minutes
    else
        zero(T)
    end
    return (
        intercepted_precipitation - drainage - wet_canopy_evaporation,
        direct_throughfall + drainage,
    )
end

function _canopy_interception_cash_karp_step(
    rate,
    storage::T,
    surface_water::T,
    storage_derivative::T,
    surface_derivative::T,
    step::T,
) where {T<:AbstractFloat}
    b21 = T(1) / T(5)
    b31 = T(3) / T(40)
    b32 = T(9) / T(40)
    b41 = T(3) / T(10)
    b42 = -T(9) / T(10)
    b43 = T(6) / T(5)
    b51 = -T(11) / T(54)
    b52 = T(5) / T(2)
    b53 = -T(70) / T(27)
    b54 = T(35) / T(27)
    b61 = T(1631) / T(55296)
    b62 = T(175) / T(512)
    b63 = T(575) / T(13824)
    b64 = T(44275) / T(110592)
    b65 = T(253) / T(4096)
    c1 = T(37) / T(378)
    c3 = T(250) / T(621)
    c4 = T(125) / T(594)
    c6 = T(512) / T(1771)
    dc1 = c1 - T(2825) / T(27648)
    dc3 = c3 - T(18575) / T(48384)
    dc4 = c4 - T(13525) / T(55296)
    dc5 = -T(277) / T(14336)
    dc6 = c6 - T(1) / T(4)

    k2s, k2g = rate(storage + step * b21 * storage_derivative)
    k3s, k3g = rate(
        storage + step * (b31 * storage_derivative + b32 * k2s),
    )
    k4s, k4g = rate(
        storage +
        step * (b41 * storage_derivative + b42 * k2s + b43 * k3s),
    )
    k5s, k5g = rate(
        storage +
        step *
        (b51 * storage_derivative + b52 * k2s + b53 * k3s + b54 * k4s),
    )
    k6s, k6g = rate(
        storage +
        step *
        (b61 * storage_derivative + b62 * k2s + b63 * k3s +
         b64 * k4s + b65 * k5s),
    )

    trial_storage = storage +
                    step *
                    (c1 * storage_derivative + c3 * k3s + c4 * k4s +
                     c6 * k6s)
    trial_surface = surface_water +
                    step *
                    (c1 * surface_derivative + c3 * k3g + c4 * k4g +
                     c6 * k6g)
    storage_error = step *
                    (dc1 * storage_derivative + dc3 * k3s + dc4 * k4s +
                     dc5 * k5s + dc6 * k6s)
    surface_error = step *
                    (dc1 * surface_derivative + dc3 * k3g + dc4 * k4g +
                     dc5 * k5g + dc6 * k6g)
    return trial_storage, trial_surface, storage_error, surface_error
end

function _canopy_interception_integrate(
    rate,
    initial_storage::T;
    relative_tolerance::T,
    initial_step::T,
    max_steps::Int,
) where {T<:AbstractFloat}
    normalized_time = one(T)
    end_time = T(2)
    step = initial_step
    storage = initial_storage
    surface_water = zero(T)
    accepted_steps = 0
    rejected_steps = 0
    attempted_steps = 0

    safety = T(9) / T(10)
    growth_power = -T(1) / T(5)
    shrink_power = -T(1) / T(4)
    error_control = T(189) / T(1_000_000)
    scale_floor = T(5) / T(10_000_000)
    scale_tiny = T(1) / T(10)^30

    while normalized_time < end_time
        step = min(step, end_time - normalized_time)
        storage_derivative, surface_derivative = rate(storage)
        storage_scale =
            abs(storage) + abs(step * storage_derivative) + scale_tiny
        surface_scale =
            abs(surface_water) + abs(step * surface_derivative) + scale_tiny
        trial_step = step

        while true
            attempted_steps < max_steps || throw(
                CanopyInterceptionConvergenceError{T}(
                    normalized_time,
                    storage,
                    attempted_steps,
                ),
            )
            attempted_steps += 1
            trial_storage, trial_surface, storage_error, surface_error =
                _canopy_interception_cash_karp_step(
                    rate,
                    storage,
                    surface_water,
                    storage_derivative,
                    surface_derivative,
                    trial_step,
                )
            all(isfinite, (trial_storage, trial_surface, storage_error,
                           surface_error)) || throw(
                CanopyInterceptionConvergenceError{T}(
                    normalized_time,
                    storage,
                    attempted_steps,
                ),
            )
            storage_relative_error = storage_scale < scale_floor ? zero(T) :
                                     abs(storage_error / storage_scale)
            surface_relative_error = surface_scale < scale_floor ? zero(T) :
                                     abs(surface_error / surface_scale)
            relative_error = max(
                storage_relative_error,
                surface_relative_error,
            ) / relative_tolerance

            if relative_error <= one(T)
                storage = trial_storage
                surface_water = trial_surface
                normalized_time += trial_step
                accepted_steps += 1
                step = relative_error > error_control ?
                       safety * trial_step * relative_error^growth_power :
                       T(5) * trial_step
                break
            end

            rejected_steps += 1
            proposed_step =
                safety * trial_step * relative_error^shrink_power
            trial_step = max(proposed_step, trial_step / T(10))
            normalized_time + trial_step > normalized_time || throw(
                CanopyInterceptionConvergenceError{T}(
                    normalized_time,
                    storage,
                    attempted_steps,
                ),
            )
        end
    end
    return storage, surface_water, accepted_steps, rejected_steps
end

"""
    canopy_interception(config, precipitation_mm, total_leaf_area_index,
                        previous_canopy_water_storage_mm;
                        timestep_seconds,
                        wet_canopy_evaporation_mm=0,
                        previous_effective_throughfall_fraction=config.throughfall,
                        previous_dry_canopy_fraction=1,
                        relative_tolerance=1e-3,
                        initial_step=1e-5,
                        max_steps=10_000)

Compute one MAESPA `CANOPY_BALANCE`/`CANSTOR` step. Rainfall, storage,
drainage, and evaporation are millimetres per square metre of ground for the
current timestep. `wet_canopy_evaporation_mm` is supplied by the upstream leaf
energy-balance process; the obsolete internal `WETEVAP` path is not used. A
negative value represents condensation or canopy dew and therefore adds to
storage, as in the active Fortran equation.

The concrete type of `previous_canopy_water_storage_mm` controls every
calculation. Model parameters and other inputs are converted to that type, so
PlantSimEngine status promotion can select `Float32`, `Float64`, or another
`AbstractFloat` without putting precision choices in the equations.

Historical state semantics are explicit. A negative throughfall sentinel is
resolved only when the active path first runs, and callers must pass the
returned `effective_throughfall_fraction` into the next step. Exactly one, or
zero maximum storage, bypasses interception while retaining storage,
throughfall state, and dry-canopy state. The active path deliberately retains
the legacy direct `storage > maximum_storage` drainage threshold, even though
other expressions multiply maximum storage by LAI.

`accepted_steps` and `rejected_steps` are Julia solver diagnostics. In
particular, `rejected_steps` counts every rejected trial; these fields do not
reproduce the historical Fortran `NOK`/`NBAD` counters.
"""
function canopy_interception(
    config::CanopyInterceptionConfig,
    precipitation_mm,
    total_leaf_area_index,
    previous_canopy_water_storage_mm::T;
    timestep_seconds,
    wet_canopy_evaporation_mm=zero(T),
    previous_effective_throughfall_fraction=config.throughfall,
    previous_dry_canopy_fraction=one(T),
    relative_tolerance=T(1e-3),
    initial_step=T(1e-5),
    max_steps::Integer=10_000,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError(
            "previous_canopy_water_storage_mm must have a concrete AbstractFloat type",
        ),
    )
    rutter_b, rutter_d, maximum_storage, _ =
        _canopy_interception_parameters(T, config)
    precipitation = _canopy_interception_scalar(
        T,
        precipitation_mm,
        "precipitation_mm",
    )
    precipitation >= zero(T) || throw(
        DomainError(precipitation, "precipitation_mm must be non-negative"),
    )
    leaf_area_index = _canopy_interception_scalar(
        T,
        total_leaf_area_index,
        "total_leaf_area_index",
    )
    leaf_area_index >= zero(T) || throw(
        DomainError(
            leaf_area_index,
            "total_leaf_area_index must be non-negative",
        ),
    )
    previous_storage = _canopy_interception_scalar(
        T,
        previous_canopy_water_storage_mm,
        "previous_canopy_water_storage_mm",
    )
    wet_evaporation = _canopy_interception_scalar(
        T,
        wet_canopy_evaporation_mm,
        "wet_canopy_evaporation_mm",
    )
    throughfall_state = _canopy_interception_scalar(
        T,
        previous_effective_throughfall_fraction,
        "previous_effective_throughfall_fraction",
    )
    throughfall_state <= one(T) || throw(
        DomainError(
            throughfall_state,
            "previous_effective_throughfall_fraction must be at most one",
        ),
    )
    dry_canopy_state = _canopy_interception_scalar(
        T,
        previous_dry_canopy_fraction,
        "previous_dry_canopy_fraction",
    )
    zero(T) <= dry_canopy_state <= one(T) || throw(
        DomainError(
            dry_canopy_state,
            "previous_dry_canopy_fraction must lie in [0, 1]",
        ),
    )
    seconds = _canopy_interception_scalar(
        T,
        timestep_seconds,
        "timestep_seconds",
    )
    seconds >= zero(T) || throw(
        DomainError(seconds, "timestep_seconds must be non-negative"),
    )
    tolerance = _canopy_interception_scalar(
        T,
        relative_tolerance,
        "relative_tolerance",
    )
    tolerance > zero(T) || throw(
        DomainError(tolerance, "relative_tolerance must be positive"),
    )
    first_step = _canopy_interception_scalar(T, initial_step, "initial_step")
    first_step > zero(T) || throw(
        DomainError(first_step, "initial_step must be positive"),
    )
    max_steps isa Bool && throw(ArgumentError("max_steps must be an integer, not Bool"))
    max_steps > 0 || throw(DomainError(max_steps, "max_steps must be positive"))
    step_limit = try
        Int(max_steps)
    catch exception
        exception isa InexactError || exception isa OverflowError || rethrow()
        throw(ArgumentError("max_steps must be representable as Int"))
    end

    if throughfall_state == one(T) || iszero(maximum_storage)
        residual = previous_storage + precipitation -
                   previous_storage - precipitation
        return CanopyInterceptionResult{T}(
            previous_storage,
            previous_storage,
            zero(T),
            zero(T),
            throughfall_state,
            precipitation,
            zero(T),
            zero(T),
            precipitation,
            dry_canopy_state,
            residual,
            -wet_evaporation,
            0,
            0,
            true,
        )
    end

    leaf_area_index > zero(T) || throw(
        DomainError(
            leaf_area_index,
            "total_leaf_area_index must be positive when interception is active",
        ),
    )
    effective_throughfall = throughfall_state < zero(T) ?
                            one(T) - clamp(
        leaf_area_index / T(2.5),
        zero(T),
        one(T),
    ) : throughfall_state

    cleaned_storage = previous_storage < T(1e-6) * maximum_storage ?
                      zero(T) : previous_storage
    storage_correction = cleaned_storage - previous_storage
    intercepted_precipitation =
        (one(T) - effective_throughfall) * precipitation
    direct_throughfall = effective_throughfall * precipitation
    timestep_minutes = seconds / T(60)
    rate = storage -> _canopy_interception_derivatives(
        storage,
        intercepted_precipitation,
        direct_throughfall,
        wet_evaporation,
        maximum_storage,
        leaf_area_index,
        rutter_b,
        rutter_d,
        timestep_minutes,
    )
    storage, surface_water, accepted_steps, rejected_steps =
        _canopy_interception_integrate(
            rate,
            cleaned_storage;
            relative_tolerance=tolerance,
            initial_step=first_step,
            max_steps=step_limit,
        )
    all(isfinite, (storage, surface_water)) || throw(
        CanopyInterceptionConvergenceError{T}(
            T(2),
            storage,
            accepted_steps + rejected_steps,
        ),
    )

    storage_change = storage - cleaned_storage
    drainage = surface_water - direct_throughfall
    evaporation =
        intercepted_precipitation - storage_change - drainage
    dry_canopy = clamp(
        one(T) - storage / (maximum_storage * leaf_area_index),
        zero(T),
        one(T),
    )
    mass_balance_residual = cleaned_storage + precipitation - storage -
                            surface_water - evaporation
    evaporation_residual = evaporation - wet_evaporation
    return CanopyInterceptionResult{T}(
        cleaned_storage,
        storage,
        storage_change,
        storage_correction,
        effective_throughfall,
        direct_throughfall,
        drainage,
        evaporation,
        surface_water,
        dry_canopy,
        mass_balance_residual,
        evaporation_residual,
        accepted_steps,
        rejected_steps,
        false,
    )
end

"""
Stateful PlantSimEngine wrapper for MAESPA canopy interception.

Its `interception_stand_lai` input is distinct from a selected-target
`stand_lai` producer; the native builder binds the full stand LAI here.
"""
struct MAESPACanopyWaterStorage{C,T<:AbstractFloat} <:
       AbstractCanopy_Water_StorageModel
    config::C
    initial_canopy_water_storage_mm::T
    initial_dry_canopy_fraction::T
    relative_tolerance::T
    initial_step::T
    max_steps::Int
end

function MAESPACanopyWaterStorage(
    config::CanopyInterceptionConfig{T};
    initial_canopy_water_storage_mm=zero(T),
    initial_dry_canopy_fraction=one(T),
    relative_tolerance=T(1e-3),
    initial_step=T(1e-5),
    max_steps::Integer=10_000,
) where {T<:AbstractFloat}
    storage = _canopy_interception_scalar(
        T,
        initial_canopy_water_storage_mm,
        "initial_canopy_water_storage_mm",
    )
    dry_fraction = _canopy_interception_scalar(
        T,
        initial_dry_canopy_fraction,
        "initial_dry_canopy_fraction",
    )
    zero(T) <= dry_fraction <= one(T) || throw(
        DomainError(
            dry_fraction,
            "initial_dry_canopy_fraction must lie in [0, 1]",
        ),
    )
    tolerance = _canopy_interception_scalar(
        T,
        relative_tolerance,
        "relative_tolerance",
    )
    tolerance > zero(T) || throw(
        DomainError(tolerance, "relative_tolerance must be positive"),
    )
    first_step = _canopy_interception_scalar(T, initial_step, "initial_step")
    first_step > zero(T) || throw(
        DomainError(first_step, "initial_step must be positive"),
    )
    max_steps isa Bool && throw(ArgumentError("max_steps must be an integer, not Bool"))
    max_steps > 0 || throw(DomainError(max_steps, "max_steps must be positive"))
    step_limit = try
        Int(max_steps)
    catch exception
        exception isa InexactError || exception isa OverflowError || rethrow()
        throw(ArgumentError("max_steps must be representable as Int"))
    end
    _canopy_interception_parameters(T, config)
    return MAESPACanopyWaterStorage(
        config,
        storage,
        dry_fraction,
        tolerance,
        first_step,
        step_limit,
    )
end

PlantSimEngine.environment_inputs_(::MAESPACanopyWaterStorage) =
    (duration=PlantSimEngine.Required(Union{Real,Dates.Period,Dates.CompoundPeriod}),)

function PlantSimEngine.inputs_(model::MAESPACanopyWaterStorage{C,T}) where {C,T}
    return (
        precipitation_mm=PlantSimEngine.Required(Real),
        interception_stand_lai=PlantSimEngine.Required(Real),
        wet_canopy_evaporation_mm=PlantSimEngine.Default(zero(T)),
        previous_canopy_water_storage_mm=PlantSimEngine.Default(
            model.initial_canopy_water_storage_mm,
        ),
        previous_effective_throughfall_fraction=PlantSimEngine.Default(
            convert(T, model.config.throughfall),
        ),
        previous_dry_canopy_fraction=PlantSimEngine.Default(
            model.initial_dry_canopy_fraction,
        ),
        canopy_water_storage_inputs_available=PlantSimEngine.Default(true),
    )
end

PlantSimEngine.variable_contracts_(::MAESPACanopyWaterStorage) = (
    precipitation_mm=GROUND_WATER_DEPTH_TIMESTEP_CONTRACT,
    interception_stand_lai=FULL_STAND_LAI_CONTRACT,
    wet_canopy_evaporation_mm=GROUND_WATER_DEPTH_TIMESTEP_CONTRACT,
    previous_canopy_water_storage_mm=CANOPY_WATER_STORAGE_CONTRACT,
    previous_effective_throughfall_fraction=CANOPY_THROUGHFALL_CONTROL_CONTRACT,
    previous_dry_canopy_fraction=CANOPY_DRY_FRACTION_CONTRACT,
    canopy_water_storage_mm=CANOPY_WATER_STORAGE_CONTRACT,
    effective_throughfall_fraction=CANOPY_THROUGHFALL_CONTROL_CONTRACT,
    dry_canopy_fraction=CANOPY_DRY_FRACTION_CONTRACT,
    surface_water_mm=GROUND_WATER_DEPTH_TIMESTEP_CONTRACT,
)

function PlantSimEngine.outputs_(model::MAESPACanopyWaterStorage{C,T}) where {C,T}
    return (
        canopy_water_storage_mm=model.initial_canopy_water_storage_mm,
        effective_throughfall_fraction=convert(T, model.config.throughfall),
        dry_canopy_fraction=model.initial_dry_canopy_fraction,
        direct_throughfall_mm=zero(T),
        canopy_drainage_mm=zero(T),
        canopy_evaporation_mm=zero(T),
        surface_water_mm=zero(T),
        canopy_water_storage_change_mm=zero(T),
        canopy_water_storage_correction_mm=zero(T),
        canopy_water_mass_balance_residual_mm=zero(T),
        canopy_evaporation_residual_mm=zero(T),
        canopy_interception_accepted_steps=0,
        canopy_interception_rejected_steps=0,
        canopy_interception_short_circuited=false,
        canopy_water_storage_available=false,
    )
end

@inline function _canopy_water_storage_gate(value)
    value isa Bool || throw(
        ArgumentError("canopy_water_storage_inputs_available must be Bool"),
    )
    return value
end

function _publish_unavailable_canopy_water_storage!(status, ::Type{T}) where {T}
    # The three historical outputs are state carriers. On an unavailable
    # source step they repeat the last accepted values supplied through the
    # PreviousTimeStep bindings, while all fluxes describe this step and must
    # therefore be zero.
    storage = convert(T, status.previous_canopy_water_storage_mm)
    throughfall = convert(T, status.previous_effective_throughfall_fraction)
    dry_fraction = convert(T, status.previous_dry_canopy_fraction)
    status.canopy_water_storage_mm = storage
    status.effective_throughfall_fraction = throughfall
    status.dry_canopy_fraction = dry_fraction
    status.direct_throughfall_mm = zero(T)
    status.canopy_drainage_mm = zero(T)
    status.canopy_evaporation_mm = zero(T)
    status.surface_water_mm = zero(T)
    status.canopy_water_storage_change_mm = zero(T)
    status.canopy_water_storage_correction_mm = zero(T)
    status.canopy_water_mass_balance_residual_mm = zero(T)
    status.canopy_evaporation_residual_mm = zero(T)
    status.canopy_interception_accepted_steps = 0
    status.canopy_interception_rejected_steps = 0
    status.canopy_interception_short_circuited = false
    status.canopy_water_storage_available = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPACanopyWaterStorage,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.canopy_water_storage_mm)
    T <: AbstractFloat || throw(
        ArgumentError("canopy_water_storage_mm must have an AbstractFloat type"),
    )
    status.canopy_water_storage_available isa Bool || throw(
        ArgumentError("canopy_water_storage_available must be Bool"),
    )
    inputs_available = _canopy_water_storage_gate(
        status.canopy_water_storage_inputs_available,
    )
    if !inputs_available
        try
            _publish_unavailable_canopy_water_storage!(status, T)
        catch
            status.canopy_water_storage_available = false
            rethrow()
        end
        return nothing
    end

    # Compute the complete accepted snapshot before installing any numeric
    # output. Invalid active inputs therefore cannot partially advance the
    # three state carriers or this step's fluxes.
    result = canopy_interception(
        model.config,
        status.precipitation_mm,
        status.interception_stand_lai,
        convert(T, status.previous_canopy_water_storage_mm);
        timestep_seconds=_maespa_timestep_seconds(T, environment),
        wet_canopy_evaporation_mm=status.wet_canopy_evaporation_mm,
        previous_effective_throughfall_fraction=
            status.previous_effective_throughfall_fraction,
        previous_dry_canopy_fraction=status.previous_dry_canopy_fraction,
        relative_tolerance=model.relative_tolerance,
        initial_step=model.initial_step,
        max_steps=model.max_steps,
    )
    status.canopy_water_storage_mm = result.canopy_water_storage_mm
    status.effective_throughfall_fraction =
        result.effective_throughfall_fraction
    status.dry_canopy_fraction = result.dry_canopy_fraction
    status.direct_throughfall_mm = result.direct_throughfall_mm
    status.canopy_drainage_mm = result.canopy_drainage_mm
    status.canopy_evaporation_mm = result.canopy_evaporation_mm
    status.surface_water_mm = result.surface_water_mm
    status.canopy_water_storage_change_mm =
        result.canopy_water_storage_change_mm
    status.canopy_water_storage_correction_mm =
        result.canopy_water_storage_correction_mm
    status.canopy_water_mass_balance_residual_mm =
        result.mass_balance_residual_mm
    status.canopy_evaporation_residual_mm = result.evaporation_residual_mm
    status.canopy_interception_accepted_steps = result.accepted_steps
    status.canopy_interception_rejected_steps = result.rejected_steps
    status.canopy_interception_short_circuited = result.short_circuited
    status.canopy_water_storage_available = true
    return nothing
end

"""
    maespa_canopy_water_storage_modelspec(config; inputs=NamedTuple(), kwargs...)

Build the stateful scene-level `canopy_water_storage` application. The three
historical states are wired to their own previous-timestep outputs. Bind
`precipitation_mm`, `interception_stand_lai`, and optionally
`wet_canopy_evaporation_mm` and `canopy_water_storage_inputs_available`
through `inputs`. Its `surface_water_mm` output can then be selected by the
soil-water-balance application.
"""
function maespa_canopy_water_storage_modelspec(
    config::CanopyInterceptionConfig;
    inputs=NamedTuple(),
    kwargs...,
)
    inputs isa NamedTuple || throw(
        ArgumentError("inputs must be a NamedTuple of PlantSimEngine selectors"),
    )
    allowed_inputs = (
        :precipitation_mm,
        :interception_stand_lai,
        :wet_canopy_evaporation_mm,
        :canopy_water_storage_inputs_available,
    )
    for name in keys(inputs)
        name in allowed_inputs || throw(
            ArgumentError("unsupported canopy-water-storage input `$name`"),
        )
    end
    application_name = :canopy_water_storage
    temporal_inputs = (
        PlantSimEngine.PreviousTimeStep(:previous_canopy_water_storage_mm) =>
        PlantSimEngine.One(
            within=PlantSimEngine.Self(),
            application=application_name,
            var=:canopy_water_storage_mm,
        ),
        PlantSimEngine.PreviousTimeStep(
            :previous_effective_throughfall_fraction,
        ) => PlantSimEngine.One(
            within=PlantSimEngine.Self(),
            application=application_name,
            var=:effective_throughfall_fraction,
        ),
        PlantSimEngine.PreviousTimeStep(:previous_dry_canopy_fraction) =>
        PlantSimEngine.One(
            within=PlantSimEngine.Self(),
            application=application_name,
            var=:dry_canopy_fraction,
        ),
    )
    return PlantSimEngine.ModelSpec(
        MAESPACanopyWaterStorage(config; kwargs...);
        name=application_name,
        on=PlantSimEngine.One(scale=:Scene, kind=:scene),
        inputs=(temporal_inputs..., pairs(inputs)...),
    )
end
