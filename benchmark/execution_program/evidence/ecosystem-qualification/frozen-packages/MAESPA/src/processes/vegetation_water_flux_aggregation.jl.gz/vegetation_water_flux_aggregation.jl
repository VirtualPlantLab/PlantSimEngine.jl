PlantSimEngine.@process "vegetation_water_flux_aggregation" verbose = false

"""Understorey and total vegetation water fluxes for one simulation step."""
struct VegetationWaterFluxAggregationResult{T<:AbstractFloat}
    understorey_transpiration_mm_timestep::T
    vegetation_evapotranspiration_mm_timestep::T
end

"""
Convert the mean understorey water flux and add it to the signed canopy flux.

`fh2ous_mmol_h2o_m2_ground_s` is the equal-area mean produced by historical
`SUMHRUS`. Multiplication by the timestep, the molar mass of water, and
`1e-6` converts mmol H2O m-2 ground s-1 to mm water per timestep. The canopy
term is intentionally signed and is not clamped before aggregation.
"""
struct MAESPAVegetationWaterFluxAggregation{T<:AbstractFloat} <:
       AbstractVegetation_Water_Flux_AggregationModel
    water_molar_mass_g_mol::T
end

@inline function _vegetation_water_flux_value(
    ::Type{T},
    value,
    name::Symbol;
    nonnegative::Bool=false,
    positive::Bool=false,
) where {T<:AbstractFloat}
    value isa Real && !(value isa Bool) || throw(
        ArgumentError("$(String(name)) must be numeric, not Bool"),
    )
    converted = convert(T, value)
    isfinite(converted) || throw(
        ArgumentError("$(String(name)) must be finite"),
    )
    if positive
        converted > zero(T) || throw(
            DomainError(value, "$(String(name)) must be positive"),
        )
    elseif nonnegative
        converted >= zero(T) || throw(
            DomainError(value, "$(String(name)) must be non-negative"),
        )
    end
    return converted
end

function MAESPAVegetationWaterFluxAggregation(
    ::Type{T}=Float64;
    water_molar_mass_g_mol=18,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the vegetation water-flux aggregation type must be concrete"),
    )
    molar_mass = _vegetation_water_flux_value(
        T,
        water_molar_mass_g_mol,
        :water_molar_mass_g_mol;
        positive=true,
    )
    return MAESPAVegetationWaterFluxAggregation{T}(molar_mass)
end

"""
    vegetation_water_flux_aggregation(
        T,
        canopy_transpiration_mm_timestep,
        fh2ous_mmol_h2o_m2_ground_s;
        timestep_seconds,
        water_molar_mass_g_mol=18,
    )

Reproduce the legacy `ETUSMM` conversion and its addition to `ETCAN`:

    ETUSMM = FH2OUS * timestep_seconds * water_molar_mass_g_mol * 1e-6
    vegetation_evapotranspiration = canopy_transpiration + ETUSMM

The returned values use `T`. A negative canopy contribution is valid, whereas
the understorey transpiration rate and all conversion factors must be
non-negative (with a strictly positive molar mass).
"""
function vegetation_water_flux_aggregation(
    ::Type{T},
    canopy_transpiration_mm_timestep,
    fh2ous_mmol_h2o_m2_ground_s;
    timestep_seconds,
    water_molar_mass_g_mol=18,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the vegetation water-flux calculation type must be concrete"),
    )
    canopy = _vegetation_water_flux_value(
        T,
        canopy_transpiration_mm_timestep,
        :canopy_transpiration_mm_timestep,
    )
    understorey_flux = _vegetation_water_flux_value(
        T,
        fh2ous_mmol_h2o_m2_ground_s,
        :fh2ous_mmol_h2o_m2_ground_s;
        nonnegative=true,
    )
    duration = _vegetation_water_flux_value(
        T,
        timestep_seconds,
        :timestep_seconds;
        nonnegative=true,
    )
    molar_mass = _vegetation_water_flux_value(
        T,
        water_molar_mass_g_mol,
        :water_molar_mass_g_mol;
        positive=true,
    )

    understorey = understorey_flux * duration * molar_mass * T(1e-6)
    isfinite(understorey) || throw(
        ArgumentError("understorey_transpiration_mm_timestep must be finite"),
    )
    total = canopy + understorey
    isfinite(total) || throw(
        ArgumentError("vegetation_evapotranspiration_mm_timestep must be finite"),
    )
    return VegetationWaterFluxAggregationResult{T}(understorey, total)
end

PlantSimEngine.environment_inputs_(::MAESPAVegetationWaterFluxAggregation) =
    (duration=PlantSimEngine.Required(Union{Real,Dates.Period,Dates.CompoundPeriod}),)

PlantSimEngine.inputs_(::MAESPAVegetationWaterFluxAggregation) = (
    canopy_transpiration_mm_timestep=PlantSimEngine.Required(Real),
    fh2ous_mmol_h2o_m2_ground_s=PlantSimEngine.Required(Real),
    stand_water_flux_scaling_available=PlantSimEngine.Required(Bool),
    understorey_flux_aggregation_available=PlantSimEngine.Required(Bool),
)

PlantSimEngine.outputs_(
    ::MAESPAVegetationWaterFluxAggregation{T},
) where {T} = (
    understorey_transpiration_mm_timestep=zero(T),
    vegetation_evapotranspiration_mm_timestep=zero(T),
    vegetation_water_flux_aggregation_available=false,
)

PlantSimEngine.variable_contracts_(::MAESPAVegetationWaterFluxAggregation) = (
    fh2ous_mmol_h2o_m2_ground_s=UNDERSTOREY_MEAN_H2O_FLUX_CONTRACT,
)

function _reset_vegetation_water_flux_aggregation!(
    status,
    ::Type{T},
) where {T<:AbstractFloat}
    status.understorey_transpiration_mm_timestep = zero(T)
    status.vegetation_evapotranspiration_mm_timestep = zero(T)
    status.vegetation_water_flux_aggregation_available = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPAVegetationWaterFluxAggregation,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.understorey_transpiration_mm_timestep)
    T <: AbstractFloat || throw(
        ArgumentError("vegetation water-flux outputs must be floating-point values"),
    )
    _reset_vegetation_water_flux_aggregation!(status, T)
    typeof(status.vegetation_evapotranspiration_mm_timestep) === T || throw(
        ArgumentError("vegetation water-flux outputs must share one floating-point type"),
    )

    stand_available = status.stand_water_flux_scaling_available
    understorey_available = status.understorey_flux_aggregation_available
    stand_available isa Bool || throw(
        ArgumentError("stand_water_flux_scaling_available must be Bool"),
    )
    understorey_available isa Bool || throw(
        ArgumentError("understorey_flux_aggregation_available must be Bool"),
    )
    stand_available && understorey_available || return nothing

    result = vegetation_water_flux_aggregation(
        T,
        status.canopy_transpiration_mm_timestep,
        status.fh2ous_mmol_h2o_m2_ground_s;
        timestep_seconds=_maespa_timestep_seconds(T, environment),
        water_molar_mass_g_mol=convert(T, model.water_molar_mass_g_mol),
    )
    status.understorey_transpiration_mm_timestep =
        result.understorey_transpiration_mm_timestep
    status.vegetation_evapotranspiration_mm_timestep =
        result.vegetation_evapotranspiration_mm_timestep
    status.vegetation_water_flux_aggregation_available = true
    return nothing
end
