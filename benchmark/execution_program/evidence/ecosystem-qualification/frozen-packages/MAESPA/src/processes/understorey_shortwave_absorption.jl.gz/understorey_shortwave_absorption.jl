PlantSimEngine.@process "understorey_shortwave_absorption" verbose = false

"""Patch-scale PAR interception and absorption, independent of physiology."""
struct UnderstoreyShortwaveAbsorptionResult{T<:AbstractFloat}
    sunlit_leaf_area_index::T
    canopy_interception_fraction::T
    incident_par_w_m2::T
    absorbed_par_w_m2::T
    transmitted_par_w_m2::T
end

struct MAESPAUnderstoreyShortwaveAbsorption{T<:AbstractFloat} <:
       AbstractUnderstorey_Shortwave_AbsorptionModel
    vertical_extinction_coefficient::T
    par_absorptance::T

    function MAESPAUnderstoreyShortwaveAbsorption{T}(
        vertical_extinction_coefficient::T,
        par_absorptance::T,
    ) where {T<:AbstractFloat}
        isfinite(vertical_extinction_coefficient) &&
            vertical_extinction_coefficient > zero(T) || throw(
            DomainError(
                vertical_extinction_coefficient,
                "understorey extinction coefficient must be finite and positive",
            ),
        )
        isfinite(par_absorptance) && zero(T) <= par_absorptance <= one(T) || throw(
            DomainError(
                par_absorptance,
                "understorey PAR absorptance must lie between zero and one",
            ),
        )
        return new{T}(vertical_extinction_coefficient, par_absorptance)
    end
end

function MAESPAUnderstoreyShortwaveAbsorption(
    vertical_extinction_coefficient::Real,
    par_absorptance::Real,
)
    values = (vertical_extinction_coefficient, par_absorptance)
    any(value -> value isa Bool, values) && throw(
        ArgumentError("understorey absorption parameters must be numeric, not Bool"),
    )
    T = promote_type(map(value -> typeof(float(value)), values)...)
    isconcretetype(T) && T <: AbstractFloat || throw(
        ArgumentError("understorey absorption parameters must promote to a concrete float"),
    )
    return MAESPAUnderstoreyShortwaveAbsorption{T}(
        convert(T, vertical_extinction_coefficient),
        convert(T, par_absorptance),
    )
end

function MAESPAUnderstoreyShortwaveAbsorption(
    config::UnderstoreyConfig{T},
) where {T<:AbstractFloat}
    return MAESPAUnderstoreyShortwaveAbsorption{T}(
        config.structure.vertical_extinction_coefficient,
        config.physiology.c3.par_absorptance,
    )
end

function understorey_shortwave_absorption(
    model::MAESPAUnderstoreyShortwaveAbsorption,
    direct_par_w_m2::Real,
    diffuse_par_w_m2::Real,
    leaf_area_index::Real;
    astronomical_daylight::Bool=true,
)
    values = (direct_par_w_m2, diffuse_par_w_m2, leaf_area_index)
    any(value -> value isa Bool, values) && throw(
        ArgumentError("understorey absorption inputs must be numeric, not Bool"),
    )
    T = promote_type(
        typeof(model.vertical_extinction_coefficient),
        map(value -> typeof(float(value)), values)...,
    )
    return understorey_shortwave_absorption(
        T,
        model,
        direct_par_w_m2,
        diffuse_par_w_m2,
        leaf_area_index;
        astronomical_daylight,
    )
end

function understorey_shortwave_absorption(
    ::Type{T},
    model::MAESPAUnderstoreyShortwaveAbsorption,
    direct_par_w_m2::Real,
    diffuse_par_w_m2::Real,
    leaf_area_index::Real;
    astronomical_daylight::Bool=true,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("understorey absorption calculation type must be concrete"),
    )
    values = (direct_par_w_m2, diffuse_par_w_m2, leaf_area_index)
    any(value -> value isa Bool, values) && throw(
        ArgumentError("understorey absorption inputs must be numeric, not Bool"),
    )
    direct = convert(T, direct_par_w_m2)
    diffuse = convert(T, diffuse_par_w_m2)
    lai = convert(T, leaf_area_index)
    all(isfinite, (direct, diffuse, lai)) || throw(
        ArgumentError("understorey absorption inputs must be finite"),
    )
    direct >= zero(T) && diffuse >= zero(T) || throw(
        DomainError((direct, diffuse), "understorey PAR must be non-negative"),
    )
    lai >= zero(T) || throw(
        DomainError(lai, "understorey LAI must be non-negative"),
    )
    if !astronomical_daylight
        return UnderstoreyShortwaveAbsorptionResult{T}(
            zero(T),
            zero(T),
            zero(T),
            zero(T),
            zero(T),
        )
    end

    extinction = convert(T, model.vertical_extinction_coefficient)
    absorptance = convert(T, model.par_absorptance)
    interception = -expm1(-extinction * lai)
    sunlit_leaf_area = interception / extinction
    incident = diffuse + sunlit_leaf_area * direct
    absorbed = incident * absorptance * interception
    transmitted = incident - absorbed
    all(
        isfinite,
        (sunlit_leaf_area, interception, incident, absorbed, transmitted),
    ) || throw(ArgumentError("understorey PAR balance must remain finite"))
    return UnderstoreyShortwaveAbsorptionResult{T}(
        sunlit_leaf_area,
        interception,
        incident,
        absorbed,
        transmitted,
    )
end

PlantSimEngine.inputs_(::MAESPAUnderstoreyShortwaveAbsorption) = (
    understorey_direct_par_w_m2=PlantSimEngine.Required(Real),
    understorey_diffuse_par_w_m2=PlantSimEngine.Required(Real),
    understorey_leaf_area_index=PlantSimEngine.Required(Real),
    astronomical_daylight=PlantSimEngine.Required(Bool),
    understorey_structure_available=PlantSimEngine.Default(true),
    understorey_radiation_available=PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(
    ::MAESPAUnderstoreyShortwaveAbsorption{T},
) where {T} = (
    understorey_sunlit_leaf_area_index=zero(T),
    understorey_canopy_interception_fraction=zero(T),
    understorey_incident_par_w_m2=zero(T),
    understorey_absorbed_par_w_m2=zero(T),
    understorey_transmitted_par_w_m2=zero(T),
    understorey_shortwave_absorption_available=false,
)

PlantSimEngine.variable_contracts_(::MAESPAUnderstoreyShortwaveAbsorption) = (
    understorey_direct_par_w_m2=UNDERSTOREY_DIRECT_BEAM_PAR_CONTRACT,
    understorey_diffuse_par_w_m2=UNDERSTOREY_PATCH_PAR_CONTRACT,
    understorey_leaf_area_index=UNDERSTOREY_LOCAL_LAI_CONTRACT,
    understorey_sunlit_leaf_area_index=UNDERSTOREY_LOCAL_LAI_CONTRACT,
    understorey_canopy_interception_fraction=
        UNDERSTOREY_LOCAL_FRACTION_CONTRACT,
    understorey_incident_par_w_m2=UNDERSTOREY_PATCH_PAR_CONTRACT,
    understorey_absorbed_par_w_m2=UNDERSTOREY_PATCH_PAR_CONTRACT,
    understorey_transmitted_par_w_m2=UNDERSTOREY_PATCH_PAR_CONTRACT,
)

function _reset_understorey_shortwave_absorption!(status, ::Type{T}) where {T}
    status.understorey_sunlit_leaf_area_index = zero(T)
    status.understorey_canopy_interception_fraction = zero(T)
    status.understorey_incident_par_w_m2 = zero(T)
    status.understorey_absorbed_par_w_m2 = zero(T)
    status.understorey_transmitted_par_w_m2 = zero(T)
    status.understorey_shortwave_absorption_available = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPAUnderstoreyShortwaveAbsorption,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.understorey_incident_par_w_m2)
    T <: AbstractFloat || throw(
        ArgumentError("understorey absorption outputs must be floating-point values"),
    )
    _reset_understorey_shortwave_absorption!(status, T)
    flags = (
        status.understorey_structure_available,
        status.understorey_radiation_available,
    )
    all(flag -> flag isa Bool, flags) || throw(
        ArgumentError("understorey absorption availability flags must be Bool"),
    )
    all(flags) || return nothing
    daylight = status.astronomical_daylight
    daylight isa Bool || throw(ArgumentError("astronomical_daylight must be Bool"))
    result = understorey_shortwave_absorption(
        T,
        model,
        status.understorey_direct_par_w_m2,
        status.understorey_diffuse_par_w_m2,
        status.understorey_leaf_area_index;
        astronomical_daylight=daylight,
    )
    status.understorey_sunlit_leaf_area_index = result.sunlit_leaf_area_index
    status.understorey_canopy_interception_fraction =
        result.canopy_interception_fraction
    status.understorey_incident_par_w_m2 = result.incident_par_w_m2
    status.understorey_absorbed_par_w_m2 = result.absorbed_par_w_m2
    status.understorey_transmitted_par_w_m2 = result.transmitted_par_w_m2
    status.understorey_shortwave_absorption_available = true
    return nothing
end
