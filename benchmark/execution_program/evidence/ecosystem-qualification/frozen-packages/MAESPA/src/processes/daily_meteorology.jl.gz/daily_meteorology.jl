# GETMETDAY equations used once during forcing preparation. These are not
# separately scheduled processes: the reconstructed weather still passes
# through the ordinary meteorology model, CCSCEN and OTC applications.

"""`BRISTO`: daily PAR in MJ m⁻², preserving historical MONTH and rainy-day correction."""
function _bristow_daily_par(
    parameters::BristowParameters{T}, date50::Integer,
    tmin::T, tmax::T, precipitation::T,
    latitude::T, declination::T, day_length::T, steps::Integer, solar_constant::T,
) where {T}
    # MONTH in utils.f90 is not the Gregorian month: it uses JDATE/30 + 1.
    month_index = min(div(legacy_julian_day(date50), 30) + 1, 12)
    1 <= month_index <= 12 || throw(DomainError(date50, "historical MONTH does not select a valid DELTAT entry"))
    amplitude = tmax - tmin
    precipitation > T(10) && (amplitude *= T(0.75))
    coefficient = T(0.036) * exp(-T(0.154) * parameters.monthly_temperature_amplitude_c[month_index])
    transmission = one(T) - exp(-coefficient * amplitude^T(2.4))
    angular_day_length = day_length * T(π) / T(steps)
    clear_sky_radiation = T(0.0864) * solar_constant / T(π) * T(0.76) * (
        angular_day_length * sin(latitude) * sin(declination) +
        cos(latitude) * cos(declination) * sin(angular_day_length)
    )
    return clear_sky_radiation * transmission * T(0.5)
end

"""Daily extraterrestrial radiation (MJ m⁻²) from the historical ETRAD timestep sum."""
function _daily_extraterrestrial_radiation(solar::MAESPASolarGeometry{T}, date50, geometry, seconds::T) where {T}
    day_of_year = legacy_julian_day(date50)
    irradiance = solar.solar_constant * (one(T) + T(0.033) * cos(T(day_of_year) / T(365) * T(2π)))
    return sum(max(sin(T(π) / T(2) - zenith), zero(T)) for zenith in geometry.sun_zenith_rad) *
        irradiance * seconds / T(1e6)
end

"""`CALCTHRLY`: daily air temperatures (°C); day length is in simulation steps."""
function _daily_air_temperatures(tmin::T, tmax::T, day_length::T, steps::Int) where {T}
    average = (tmax + tmin) / T(2)
    amplitude = (tmax - tmin) / T(2)
    temperatures = Vector{T}(undef, steps)
    for step in 1:steps
        midpoint = T(step) - T(0.5)
        time_since_sunrise = midpoint + day_length / T(2) - T(steps) / T(2)
        if time_since_sunrise < zero(T) || time_since_sunrise > day_length
            time_since_sunrise < zero(T) && (midpoint += T(steps))
            temperatures[step] = average - amplitude *
                (midpoint - day_length / T(2) - T(steps) / T(2)) /
                (T(steps) - day_length)
        else
            temperatures[step] = average - amplitude *
                cos(T(1.5) * T(π) * time_since_sunrise / day_length)
        end
    end
    return temperatures
end

"""`CALCFBMD`: Spitters daily beam fraction from PAR and extraterrestrial MJ m⁻² d⁻¹."""
function _daily_beam_fraction(par::T, extraterrestrial::T) where {T}
    # No extraterrestrial energy: a dark day has no beam component.
    iszero(extraterrestrial) && return zero(T)
    transmission = (par / T(0.5)) / extraterrestrial
    diffuse = if transmission < T(0.07)
        one(T)
    elseif transmission < T(0.35)
        one(T) - T(2.3) * (transmission - T(0.07))^2
    elseif transmission < T(0.75)
        T(1.33) - T(1.46) * transmission
    else
        T(0.23)
    end
    return one(T) - diffuse
end

"""`CALCPARHRLY`: distribute daily PAR (MJ m⁻²) into step-mean W m⁻² and beam fractions."""
function _daily_par_distribution(par::T, beam_fraction::T, zenith::AbstractVector{T}, seconds::T) where {T}
    beam_weights = zeros(T, length(zenith))
    diffuse_weights = similar(beam_weights)
    for step in eachindex(zenith)
        cosine = max(cos(zenith[step]), zero(T))
        diffuse_weights[step] = cosine
        if zenith[step] < T(80) * T(π) / T(180)
            beam_weights[step] = cosine * T(0.76)^(one(T) / cosine)
        end
    end
    sum_beam = sum(beam_weights)
    sum_diffuse = sum(diffuse_weights)
    # Fortran silently loses requested energy when its distribution has no
    # support. Reject that numerical domain instead of reporting a false total.
    par * beam_fraction > zero(T) && iszero(sum_beam) && throw(
        DomainError(par, "daily beam PAR has no sun position below 80 degrees zenith"),
    )
    par * (one(T) - beam_fraction) > zero(T) && iszero(sum_diffuse) && throw(
        DomainError(par, "daily diffuse PAR has no daylight timestep"),
    )
    radiation = similar(beam_weights)
    fractions = similar(beam_weights)
    for step in eachindex(zenith)
        beam = iszero(sum_beam) ? zero(T) : par * beam_fraction * beam_weights[step] / sum_beam
        diffuse = iszero(sum_diffuse) ? zero(T) :
            par * (one(T) - beam_fraction) * diffuse_weights[step] / sum_diffuse
        total = beam + diffuse
        radiation[step] = total * T(1e6) / seconds
        fractions[step] = iszero(total) ? zero(T) : beam / total
    end
    return radiation, fractions
end

"""`ASSIGNRAIN`: step totals in mm, sampled with replacement from an explicit RNG."""
function _daily_rainfall(total::T, steps::Int, rng::Random.AbstractRNG) where {T}
    rain = zeros(T, steps)
    if total <= T(2)
        rain[rand(rng, 1:steps)] = total
    elseif total > T(46)
        fill!(rain, total / T(steps))
    else
        # At coarse resolution Fortran can request zero wet steps and divide
        # by zero. One wet step is the conservative portable extension.
        wet_steps = clamp(trunc(Int, (total / T(2)) * T(steps) / T(24)), 1, steps)
        rate = total / T(wet_steps)
        for _ in 1:wet_steps
            rain[rand(rng, 1:steps)] += rate
        end
    end
    return rain
end
