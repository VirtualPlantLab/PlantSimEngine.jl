const UNDERSTOREY_DIRECT_BEAM_PAR_CONTRACT = PlantSimEngine.VariableContract(
    unit=:joule_par,
    basis=:sunlit_leaf_area,
    temporal=:second,
    aggregation=:local,
    extent=:intensive,
)

const UNDERSTOREY_PATCH_PAR_CONTRACT = PlantSimEngine.VariableContract(
    unit=:joule_par,
    basis=:ground_area,
    temporal=:second,
    aggregation=:local,
    extent=:intensive,
)

const UNDERSTOREY_MEAN_PAR_CONTRACT = PlantSimEngine.VariableContract(
    unit=:joule_par,
    basis=:ground_area,
    temporal=:second,
    aggregation=:equal_area_mean,
    extent=:intensive,
)

const UNDERSTOREY_PAR_SD_CONTRACT = PlantSimEngine.VariableContract(
    unit=:joule_par,
    basis=:ground_area,
    temporal=:second,
    aggregation=:population_standard_deviation,
    extent=:intensive,
)

const UNDERSTOREY_LOCAL_LAI_CONTRACT = PlantSimEngine.VariableContract(
    unit=:square_metre_leaf,
    basis=:ground_area,
    temporal=:instantaneous,
    aggregation=:local,
    extent=:intensive,
)

const UNDERSTOREY_LOCAL_FRACTION_CONTRACT = PlantSimEngine.VariableContract(
    unit=:fraction,
    basis=:ground_area,
    temporal=:instantaneous,
    aggregation=:local,
    extent=:intensive,
)

const UNDERSTOREY_RATIO_OF_MEANS_CONTRACT = PlantSimEngine.VariableContract(
    unit=:fraction,
    basis=:ground_area,
    temporal=:instantaneous,
    aggregation=:ratio_of_equal_area_means,
    extent=:intensive,
)

const UNDERSTOREY_LOCAL_CO2_FLUX_CONTRACT = PlantSimEngine.VariableContract(
    unit=:micromole_co2,
    basis=:ground_area,
    temporal=:second,
    aggregation=:local,
    extent=:intensive,
)

const UNDERSTOREY_MEAN_CO2_FLUX_CONTRACT = PlantSimEngine.VariableContract(
    unit=:micromole_co2,
    basis=:ground_area,
    temporal=:second,
    aggregation=:equal_area_mean,
    extent=:intensive,
)

const UNDERSTOREY_LOCAL_CO2_CONDUCTANCE_CONTRACT =
    PlantSimEngine.VariableContract(
        unit=:mole_co2,
        basis=:ground_area,
        temporal=:second,
        aggregation=:local,
        extent=:intensive,
    )

const UNDERSTOREY_MEAN_CO2_CONDUCTANCE_CONTRACT =
    PlantSimEngine.VariableContract(
        unit=:mole_co2,
        basis=:ground_area,
        temporal=:second,
        aggregation=:equal_area_mean,
        extent=:intensive,
    )

const UNDERSTOREY_LOCAL_H2O_CONDUCTANCE_CONTRACT =
    PlantSimEngine.VariableContract(
        unit=:mole_h2o,
        basis=:ground_area,
        temporal=:second,
        aggregation=:local,
        extent=:intensive,
    )

const UNDERSTOREY_LOCAL_H2O_FLUX_CONTRACT = PlantSimEngine.VariableContract(
    unit=:millimole_h2o,
    basis=:ground_area,
    temporal=:second,
    aggregation=:local,
    extent=:intensive,
)

const UNDERSTOREY_MEAN_H2O_FLUX_CONTRACT = PlantSimEngine.VariableContract(
    unit=:millimole_h2o,
    basis=:ground_area,
    temporal=:second,
    aggregation=:equal_area_mean,
    extent=:intensive,
)
