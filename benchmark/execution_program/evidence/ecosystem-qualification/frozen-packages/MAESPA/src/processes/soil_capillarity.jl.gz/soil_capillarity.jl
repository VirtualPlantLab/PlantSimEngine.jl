"""
    SoilCapillaryBoundary{T}

Explicit hydraulic state of the virtual layer below the represented soil
profile. MAESPA historically stored this state at index `NLAYER + 1`; keeping
it explicit avoids hidden padding and makes a water table below the profile
(`water_table_layer == NLAYER + 1`) unambiguous.

The boundary only carries parameters needed to evaluate its water potential.
Hydraulic conductivity at the lower side of an interface was calculated by the
Fortran routine but never used.
"""
struct SoilCapillaryBoundary{T<:AbstractFloat}
    water_content::T
    thickness_m::T
    pore_fraction::T
    b_parameter::Union{Nothing,T}
    air_entry_water_potential_mpa::Union{Nothing,T}
    alpha_mpa_inverse::Union{Nothing,T}
    saturated_water_content::Union{Nothing,T}
    residual_water_content::Union{Nothing,T}
    shape_parameter_n::Union{Nothing,T}
end

"""
    SoilCapillaryFluxResult{T}

Diagnostics and upward interface fluxes from one MAESPA capillary step.

All fluxes and capacities are metres of water per square metre of ground for
the supplied timestep. Entry `i` describes the interface between represented
layer `i` and the layer below it; the final entry therefore uses the explicit
[`SoilCapillaryBoundary`](@ref). `trial_water_content[i]` is the uncommitted
Euler state of the upper layer at that interface.

`capacity_limited[i]` is also true when a negative historical capacity or a
negative raw Euler flux had to be replaced by zero. This is the deliberate
safety boundary around the dimensionally inconsistent legacy expression; this
kernel never publishes a negative upward flux.
"""
struct SoilCapillaryFluxResult{T<:AbstractFloat}
    upward_interface_flux_m::Vector{T}
    initial_head_gradient::Vector{T}
    trial_water_content::Vector{T}
    capacity_m::Vector{T}
    active::Vector{Bool}
    capacity_limited::Vector{Bool}
    water_table_capillary_rise_m::T
    substep_count::Int
end

function _soil_capillary_primary_type(values::AbstractVector)
    T = eltype(values)
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError(
            "water_content must have a concrete AbstractFloat element type",
        ),
    )
    return T
end

function _soil_capillary_scalar(
    ::Type{T},
    value,
    name::AbstractString,
) where {T<:AbstractFloat}
    value isa Real && !(value isa Bool) || throw(
        ArgumentError("$name must be a real number, not Bool"),
    )
    converted = convert(T, value)
    isfinite(converted) || throw(ArgumentError("$name must be finite"))
    return converted
end

function _soil_capillary_optional_scalar(
    ::Type{T},
    value,
    name::AbstractString,
) where {T<:AbstractFloat}
    isnothing(value) && return nothing
    return _soil_capillary_scalar(T, value, name)
end

function _soil_capillary_vector(
    ::Type{T},
    values,
    layer_count::Int,
    name::AbstractString;
    default_zero::Bool=false,
) where {T<:AbstractFloat}
    if isnothing(values)
        default_zero || throw(ArgumentError("missing required $name"))
        return zeros(T, layer_count)
    end
    values isa AbstractVector || throw(
        ArgumentError("$name must be an AbstractVector"),
    )
    length(values) == layer_count || throw(
        DimensionMismatch("$name must contain $layer_count layer values"),
    )
    converted = Vector{T}(undef, layer_count)
    for index in eachindex(values)
        converted[index] =
            _soil_capillary_scalar(T, values[index], "$name[$index]")
    end
    return converted
end

function _soil_capillary_optional_vector(
    ::Type{T},
    values,
    layer_count::Int,
    name::AbstractString;
    required::Bool,
) where {T<:AbstractFloat}
    if isnothing(values)
        required && throw(ArgumentError("missing required $name"))
        return nothing
    end
    return _soil_capillary_vector(T, values, layer_count, name)
end

function _soil_capillary_fraction(value, name::AbstractString; positive=false)
    lower_valid = positive ? value > zero(value) : value >= zero(value)
    lower_valid && value <= one(value) || throw(
        DomainError(value, "$name must lie in $(positive ? "(0, 1]" : "[0, 1]")"),
    )
    return value
end

function SoilCapillaryBoundary(
    water_content,
    thickness_m,
    pore_fraction;
    b_parameter=nothing,
    air_entry_water_potential_mpa=nothing,
    alpha_mpa_inverse=nothing,
    saturated_water_content=nothing,
    residual_water_content=nothing,
    shape_parameter_n=nothing,
)
    T = typeof(water_content)
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError("water_content must be a concrete AbstractFloat"),
    )
    water = _soil_capillary_scalar(T, water_content, "boundary water_content")
    thickness =
        _soil_capillary_scalar(T, thickness_m, "boundary thickness_m")
    pore = _soil_capillary_scalar(T, pore_fraction, "boundary pore_fraction")
    _soil_capillary_fraction(water, "boundary water_content")
    thickness > zero(T) || throw(
        DomainError(thickness, "boundary thickness_m must be positive"),
    )
    _soil_capillary_fraction(pore, "boundary pore_fraction"; positive=true)

    return SoilCapillaryBoundary{T}(
        water,
        thickness,
        pore,
        _soil_capillary_optional_scalar(
            T,
            b_parameter,
            "boundary b_parameter",
        ),
        _soil_capillary_optional_scalar(
            T,
            air_entry_water_potential_mpa,
            "boundary air_entry_water_potential_mpa",
        ),
        _soil_capillary_optional_scalar(
            T,
            alpha_mpa_inverse,
            "boundary alpha_mpa_inverse",
        ),
        _soil_capillary_optional_scalar(
            T,
            saturated_water_content,
            "boundary saturated_water_content",
        ),
        _soil_capillary_optional_scalar(
            T,
            residual_water_content,
            "boundary residual_water_content",
        ),
        _soil_capillary_optional_scalar(
            T,
            shape_parameter_n,
            "boundary shape_parameter_n",
        ),
    )
end

function _soil_capillary_method(value)
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError("retention method must be an integer, not Bool"),
    )
    method = Int(value)
    method in (1, 2, 3) || throw(
        ArgumentError("retention method must be one of 1, 2, or 3"),
    )
    return method
end

function _soil_capillary_water_table_layer(value, layer_count::Int)
    isnothing(value) && return nothing
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError("water_table_layer must be an integer, not Bool"),
    )
    layer = try
        Int(value)
    catch exception
        exception isa InexactError || rethrow()
        throw(ArgumentError("water_table_layer must be representable as Int"))
    end
    2 <= layer <= layer_count + 1 || throw(
        ArgumentError(
            "water_table_layer must lie in 2:$(layer_count + 1)",
        ),
    )
    return layer
end

function _soil_capillary_substeps(::Type{T}, value) where {T<:AbstractFloat}
    timestep = _soil_capillary_scalar(T, value, "timestep_seconds")
    timestep >= zero(T) || throw(
        DomainError(timestep, "timestep_seconds must be non-negative"),
    )
    return try
        floor(Int, timestep)
    catch exception
        exception isa InexactError || exception isa OverflowError || rethrow()
        throw(
            ArgumentError(
                "floor(timestep_seconds) must be representable as Int",
            ),
        )
    end
end

function _soil_capillary_retention(
    ::Type{T},
    retention::SoilRetentionConfig,
    layer_count::Int,
) where {T<:AbstractFloat}
    method = _soil_capillary_method(retention.method)
    campbell = method in (1, 2)
    van_genuchten = method == 3
    b_parameter = _soil_capillary_optional_vector(
        T,
        retention.b_parameter,
        layer_count,
        "b_parameter";
        required=campbell,
    )
    air_entry = _soil_capillary_optional_vector(
        T,
        retention.air_entry_water_potential_mpa,
        layer_count,
        "air_entry_water_potential_mpa";
        required=campbell,
    )
    conductivity = _soil_capillary_vector(
        T,
        retention.saturated_hydraulic_conductivity_m_s,
        layer_count,
        "saturated_hydraulic_conductivity_m_s",
    )
    alpha = _soil_capillary_optional_vector(
        T,
        retention.alpha_mpa_inverse,
        layer_count,
        "alpha_mpa_inverse";
        required=van_genuchten,
    )
    saturated = _soil_capillary_optional_vector(
        T,
        retention.saturated_water_content,
        layer_count,
        "saturated_water_content";
        required=van_genuchten,
    )
    residual = _soil_capillary_optional_vector(
        T,
        retention.residual_water_content,
        layer_count,
        "residual_water_content";
        required=van_genuchten,
    )
    shape = _soil_capillary_optional_vector(
        T,
        retention.shape_parameter_n,
        layer_count,
        "shape_parameter_n";
        required=van_genuchten,
    )

    isnothing(b_parameter) || all(>(zero(T)), b_parameter) || throw(
        DomainError(b_parameter, "b_parameter values must be positive"),
    )
    isnothing(air_entry) || all(<(zero(T)), air_entry) || throw(
        DomainError(
            air_entry,
            "air_entry_water_potential_mpa values must be negative",
        ),
    )
    all(>=(zero(T)), conductivity) || throw(
        DomainError(
            conductivity,
            "saturated_hydraulic_conductivity_m_s values must be non-negative",
        ),
    )
    isnothing(alpha) || all(>(zero(T)), alpha) || throw(
        DomainError(alpha, "alpha_mpa_inverse values must be positive"),
    )
    if !isnothing(saturated)
        for index in eachindex(saturated)
            _soil_capillary_fraction(
                saturated[index],
                "saturated_water_content[$index]";
                positive=true,
            )
        end
    end
    if !isnothing(residual)
        for index in eachindex(residual)
            _soil_capillary_fraction(
                residual[index],
                "residual_water_content[$index]",
            )
        end
    end
    if !isnothing(saturated) && !isnothing(residual)
        all(residual .< saturated) || throw(
            DomainError(
                residual,
                "residual water content must be below saturation in every layer",
            ),
        )
    end
    isnothing(shape) || all(>(one(T)), shape) || throw(
        DomainError(shape, "shape_parameter_n values must exceed one"),
    )

    return (;
        method,
        b_parameter,
        air_entry,
        conductivity,
        alpha,
        saturated,
        residual,
        shape,
    )
end

function _soil_capillary_boundary(
    ::Type{T},
    boundary::SoilCapillaryBoundary,
    method::Int,
) where {T<:AbstractFloat}
    water = _soil_capillary_scalar(
        T,
        boundary.water_content,
        "boundary water_content",
    )
    thickness = _soil_capillary_scalar(
        T,
        boundary.thickness_m,
        "boundary thickness_m",
    )
    pore = _soil_capillary_scalar(
        T,
        boundary.pore_fraction,
        "boundary pore_fraction",
    )
    _soil_capillary_fraction(water, "boundary water_content")
    thickness > zero(T) || throw(
        DomainError(thickness, "boundary thickness_m must be positive"),
    )
    _soil_capillary_fraction(pore, "boundary pore_fraction"; positive=true)

    b = _soil_capillary_optional_scalar(
        T,
        boundary.b_parameter,
        "boundary b_parameter",
    )
    air_entry = _soil_capillary_optional_scalar(
        T,
        boundary.air_entry_water_potential_mpa,
        "boundary air_entry_water_potential_mpa",
    )
    alpha = _soil_capillary_optional_scalar(
        T,
        boundary.alpha_mpa_inverse,
        "boundary alpha_mpa_inverse",
    )
    saturated = _soil_capillary_optional_scalar(
        T,
        boundary.saturated_water_content,
        "boundary saturated_water_content",
    )
    residual = _soil_capillary_optional_scalar(
        T,
        boundary.residual_water_content,
        "boundary residual_water_content",
    )
    shape = _soil_capillary_optional_scalar(
        T,
        boundary.shape_parameter_n,
        "boundary shape_parameter_n",
    )

    if method in (1, 2)
        isnothing(b) && throw(ArgumentError("missing required boundary b_parameter"))
        isnothing(air_entry) && throw(
            ArgumentError(
                "missing required boundary air_entry_water_potential_mpa",
            ),
        )
        b > zero(T) || throw(
            DomainError(b, "boundary b_parameter must be positive"),
        )
        air_entry < zero(T) || throw(
            DomainError(
                air_entry,
                "boundary air_entry_water_potential_mpa must be negative",
            ),
        )
    else
        isnothing(alpha) && throw(
            ArgumentError("missing required boundary alpha_mpa_inverse"),
        )
        isnothing(saturated) && throw(
            ArgumentError("missing required boundary saturated_water_content"),
        )
        isnothing(residual) && throw(
            ArgumentError("missing required boundary residual_water_content"),
        )
        isnothing(shape) && throw(
            ArgumentError("missing required boundary shape_parameter_n"),
        )
        alpha > zero(T) || throw(
            DomainError(alpha, "boundary alpha_mpa_inverse must be positive"),
        )
        _soil_capillary_fraction(
            saturated,
            "boundary saturated_water_content";
            positive=true,
        )
        _soil_capillary_fraction(
            residual,
            "boundary residual_water_content",
        )
        residual < saturated || throw(
            DomainError(
                residual,
                "boundary residual water content must be below saturation",
            ),
        )
        shape > one(T) || throw(
            DomainError(shape, "boundary shape_parameter_n must exceed one"),
        )
    end

    return (;
        water,
        thickness,
        pore,
        b,
        air_entry,
        alpha,
        saturated,
        residual,
        shape,
    )
end

function _soil_capillary_potential(
    water::T,
    method::Int,
    pore::T,
    b,
    air_entry,
    alpha,
    saturated,
    residual,
    shape,
) where {T<:AbstractFloat}
    potential = if iszero(water)
        -T(999)
    elseif method == 1
        air_entry * (water / pore)^(-b)
    elseif method == 2
        air_entry * water^(-b)
    elseif water <= residual
        -T(999)
    elseif water > saturated
        -T(0.0001)
    else
        -inv(alpha) *
        (((saturated - residual) / (water - residual))^(
            shape / (shape - one(T))
        ) - one(T))^inv(shape)
    end
    potential = potential > zero(T) ? zero(T) : potential
    potential = potential < -T(999) ? -T(999) : potential
    isfinite(potential) || throw(
        DomainError(potential, "capillary water potential must remain finite"),
    )
    return potential
end

function _soil_capillary_conductivity(
    water::T,
    method::Int,
    saturated_conductivity::T,
    pore::T,
    b,
    saturated,
    residual,
    shape,
) where {T<:AbstractFloat}
    raw = if method in (1, 2)
        saturated_conductivity *
        (water / pore)^(T(2) * b + T(3))
    elseif water <= residual
        zero(T)
    elseif water >= saturated
        saturated_conductivity
    else
        alpha_potential = (((saturated - residual) / (water - residual))^(
            shape / (shape - one(T))
        ) - one(T))^inv(shape)
        numerator = one(T) -
                    alpha_potential^(shape - one(T)) *
                    (one(T) + alpha_potential^shape)^(-one(T) + inv(shape))
        legacy_exponent = -inv(T(2) * shape)
        saturated_conductivity * numerator^T(2) /
        (one(T) + alpha_potential^shape)^legacy_exponent
    end
    floor_value = _soil_conductivity_floor(T)
    conductivity = raw < floor_value ? floor_value : raw
    isfinite(conductivity) || throw(
        DomainError(
            conductivity,
            "capillary hydraulic conductivity must remain finite",
        ),
    )
    return conductivity
end

"""
    soil_capillary_fluxes(water_content, layer_thickness_m, pore_fraction,
                           retention, lower_boundary;
                           timestep_seconds, water_table_layer,
                           water_gain_m=nothing, water_loss_m=nothing)

Reproduce the legacy `SOIL_CAPILARY` profile calculation from one common
snapshot. A timestep is split into `floor(timestep_seconds)` explicit one-second
Euler substeps. At interface `i`, the lower-layer potential is fixed throughout
the loop, only the upper-layer conductivity is used, and flow is activated only
for an initial pressure-head gradient strictly greater than one and `i > 5`.

`lower_boundary` is the explicit historical `NLAYER + 1` state. The water-table
index is one-based and must lie in `2:NLAYER+1`; it selects the diagnostic
`water_table_capillary_rise_m = upward_interface_flux_m[water_table_layer-1]`
but, as in the source routine, does not otherwise restrict which interfaces are
evaluated. Passing `nothing` disables the calculation and returns zero fluxes.

The Fortran capacity was
`(pore - water + gain - loss) * thickness`, despite mixing metres with a
volumetric fraction and using counter-intuitive gain/loss signs. This expression
is retained for parity when it is positive. A negative capacity, or a negative
raw Euler displacement, is replaced explicitly by zero and reported through
`capacity_limited`; negative upward fluxes are never returned.

The result type follows the concrete floating-point element type of
`water_content`; all other numeric inputs and parameters are converted to that
type before calculation.
"""
function soil_capillary_fluxes(
    water_content::AbstractVector,
    layer_thickness_m::AbstractVector,
    pore_fraction::AbstractVector,
    retention::SoilRetentionConfig,
    lower_boundary::SoilCapillaryBoundary;
    timestep_seconds,
    water_table_layer,
    water_gain_m=nothing,
    water_loss_m=nothing,
)
    T = _soil_capillary_primary_type(water_content)
    layer_count = length(water_content)
    layer_count > 0 || throw(
        ArgumentError("a soil profile must contain at least one layer"),
    )
    water = _soil_capillary_vector(
        T,
        water_content,
        layer_count,
        "water_content",
    )
    thickness = _soil_capillary_vector(
        T,
        layer_thickness_m,
        layer_count,
        "layer_thickness_m",
    )
    pores = _soil_capillary_vector(
        T,
        pore_fraction,
        layer_count,
        "pore_fraction",
    )
    gains = _soil_capillary_vector(
        T,
        water_gain_m,
        layer_count,
        "water_gain_m";
        default_zero=true,
    )
    losses = _soil_capillary_vector(
        T,
        water_loss_m,
        layer_count,
        "water_loss_m";
        default_zero=true,
    )
    for index in 1:layer_count
        _soil_capillary_fraction(water[index], "water_content[$index]")
        thickness[index] > zero(T) || throw(
            DomainError(
                thickness[index],
                "layer_thickness_m[$index] must be positive",
            ),
        )
        _soil_capillary_fraction(
            pores[index],
            "pore_fraction[$index]";
            positive=true,
        )
        gains[index] >= zero(T) || throw(
            DomainError(gains[index], "water_gain_m[$index] must be non-negative"),
        )
        losses[index] >= zero(T) || throw(
            DomainError(
                losses[index],
                "water_loss_m[$index] must be non-negative",
            ),
        )
    end

    table_layer =
        _soil_capillary_water_table_layer(water_table_layer, layer_count)
    substeps = _soil_capillary_substeps(T, timestep_seconds)
    fluxes = zeros(T, layer_count)
    gradients = zeros(T, layer_count)
    trial_water = copy(water)
    capacities = Vector{T}(undef, layer_count)
    active = falses(layer_count)
    limited = falses(layer_count)
    regularization = T(1e-5)
    residual_margin = T(0.005)
    gradient_threshold = one(T)
    minimum_interface_index = 6
    pressure_conversion = T(1_000_000)
    water_density = T(1000)
    legacy_gravity = T(9.81)
    half = inv(T(2))

    for index in 1:layer_count
        historical_capacity =
            (pores[index] - water[index] + gains[index] - losses[index]) *
            thickness[index]
        capacity = max(zero(T), historical_capacity)
        capacities[index] = capacity
        historical_capacity < zero(T) && (limited[index] = true)
    end

    if isnothing(table_layer)
        return SoilCapillaryFluxResult{T}(
            fluxes,
            gradients,
            trial_water,
            capacities,
            active,
            limited,
            zero(T),
            substeps,
        )
    end

    # The disabled branch above deliberately needs neither a usable retention
    # curve nor a complete lower boundary. Once capillarity is active, reject
    # numeric types that cannot represent MAESPA's positive conductivity floor
    # before evaluating any interface (notably Float16).
    _soil_conductivity_floor(T)
    parameters = _soil_capillary_retention(T, retention, layer_count)
    boundary =
        _soil_capillary_boundary(T, lower_boundary, parameters.method)

    for index in 1:layer_count
        lower_water = index == layer_count ? boundary.water : water[index + 1]
        lower_thickness =
            index == layer_count ? boundary.thickness : thickness[index + 1]
        lower_pore = index == layer_count ? boundary.pore : pores[index + 1]
        lower_b = index == layer_count ? boundary.b :
                  isnothing(parameters.b_parameter) ? nothing :
                  parameters.b_parameter[index + 1]
        lower_air_entry = index == layer_count ? boundary.air_entry :
                          isnothing(parameters.air_entry) ? nothing :
                          parameters.air_entry[index + 1]
        lower_alpha = index == layer_count ? boundary.alpha :
                      isnothing(parameters.alpha) ? nothing :
                      parameters.alpha[index + 1]
        lower_saturated = index == layer_count ? boundary.saturated :
                          isnothing(parameters.saturated) ? nothing :
                          parameters.saturated[index + 1]
        lower_residual = index == layer_count ? boundary.residual :
                         isnothing(parameters.residual) ? nothing :
                         parameters.residual[index + 1]
        lower_shape = index == layer_count ? boundary.shape :
                      isnothing(parameters.shape) ? nothing :
                      parameters.shape[index + 1]

        upper_b = isnothing(parameters.b_parameter) ? nothing :
                  parameters.b_parameter[index]
        upper_air_entry = isnothing(parameters.air_entry) ? nothing :
                          parameters.air_entry[index]
        upper_alpha = isnothing(parameters.alpha) ? nothing :
                      parameters.alpha[index]
        upper_saturated = isnothing(parameters.saturated) ? nothing :
                          parameters.saturated[index]
        upper_residual = isnothing(parameters.residual) ? nothing :
                         parameters.residual[index]
        upper_shape = isnothing(parameters.shape) ? nothing :
                      parameters.shape[index]

        lower_potential = _soil_capillary_potential(
            lower_water,
            parameters.method,
            lower_pore + regularization,
            lower_b,
            lower_air_entry,
            lower_alpha,
            isnothing(lower_saturated) ? nothing :
            lower_saturated + regularization,
            isnothing(lower_residual) ? nothing :
            lower_residual - regularization,
            lower_shape,
        )
        upper_potential = _soil_capillary_potential(
            water[index],
            parameters.method,
            pores[index] + regularization,
            upper_b,
            upper_air_entry,
            upper_alpha,
            isnothing(upper_saturated) ? nothing :
            upper_saturated + regularization,
            isnothing(upper_residual) ? nothing :
            upper_residual - regularization,
            upper_shape,
        )
        centre_distance = half * (thickness[index] + lower_thickness)
        gradient = (lower_potential - upper_potential) * pressure_conversion /
                   (water_density * legacy_gravity * centre_distance)
        isfinite(gradient) || throw(
            DomainError(
                gradient,
                "initial head gradient at interface $index must be finite",
            ),
        )
        gradients[index] = gradient

        if gradient > gradient_threshold && index >= minimum_interface_index
            active[index] = true
            trial = water[index]
            fixed_lower_potential = lower_potential
            for _ in 1:substeps
                # SOIL_CAPILARY applies max(WR + 0.005, SWCLAY) for every
                # retention function. WR is initialized to zero by INPUTWATBAL
                # when Campbell input omits it.
                residual_floor =
                    (isnothing(upper_residual) ? zero(T) : upper_residual) +
                    residual_margin
                conductivity_water = max(residual_floor, trial)
                conductivity = _soil_capillary_conductivity(
                    conductivity_water,
                    parameters.method,
                    parameters.conductivity[index],
                    pores[index] + regularization,
                    upper_b,
                    isnothing(upper_saturated) ? nothing :
                    upper_saturated + regularization,
                    upper_residual,
                    upper_shape,
                )
                trial_potential = _soil_capillary_potential(
                    trial,
                    parameters.method,
                    pores[index] + regularization,
                    upper_b,
                    upper_air_entry,
                    upper_alpha,
                    isnothing(upper_saturated) ? nothing :
                    upper_saturated + regularization,
                    isnothing(upper_residual) ? nothing :
                    upper_residual - regularization,
                    upper_shape,
                )
                current_gradient =
                    (fixed_lower_potential - trial_potential) *
                    pressure_conversion /
                    (water_density * legacy_gravity * centre_distance)
                trial -= conductivity * (one(T) - current_gradient)
                isfinite(trial) || throw(
                    DomainError(
                        trial,
                        "Euler water content at interface $index became non-finite",
                    ),
                )
            end
            trial_water[index] = trial
            raw_flux = (trial - water[index]) * thickness[index]
            nonnegative_raw_flux = max(zero(T), raw_flux)
            fluxes[index] = min(nonnegative_raw_flux, capacities[index])
            if raw_flux < zero(T) || fluxes[index] < nonnegative_raw_flux
                limited[index] = true
            end
        end
    end

    water_table_rise = fluxes[table_layer - 1]
    return SoilCapillaryFluxResult{T}(
        fluxes,
        gradients,
        trial_water,
        capacities,
        active,
        limited,
        water_table_rise,
        substeps,
    )
end
