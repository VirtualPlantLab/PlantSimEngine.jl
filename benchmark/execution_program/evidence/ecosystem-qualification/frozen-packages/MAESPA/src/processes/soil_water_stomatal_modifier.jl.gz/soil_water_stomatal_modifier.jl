PlantSimEngine.@process "soil_water_stomatal_modifier" verbose = false

"""
Result of the historical `CALCFSOIL` stomatal soil-water response.

`soil_water_stomatal_modifier` is the dimensionless `FSOIL` multiplier passed
to the Ball--Berry and Leuning branches of `PSTRANSP`.
"""
struct SoilWaterStomatalModifierResult{T<:AbstractFloat}
    soil_water_stomatal_modifier::T
end

"""
    MAESPASoilWaterStomatalModifier(T; kwargs...)
    MAESPASoilWaterStomatalModifier(stomatal_parameters)
    MAESPASoilWaterStomatalModifier(species_config)

Parameters retained by MAESPA's historical `CALCFSOIL` function. The model
does not choose `WSOILMETHOD`, `SOILDATA`, or the source of `SOILMOISTURE`;
those remain explicit runtime inputs until their high-level coupling contract
is known.

The five coefficients come directly from `BBGS` or `BBLGS`. Adapters reuse the
typed stomatal structures instead of copying parameter ownership. Medlyn and
Tuzet configurations deliberately have no adapter: their READGS groups do not
carry the complete coefficient set, and their `PSTRANSP` branches ignore
`FSOIL`.
"""
struct MAESPASoilWaterStomatalModifier{T<:AbstractFloat} <:
       AbstractSoil_Water_Stomatal_ModifierModel
    soil_moisture_deficit_amplitude::T
    soil_moisture_deficit_rate::T
    water_content_lower_fraction::T
    water_content_upper_fraction::T
    soil_water_potential_exponent_mpa_inverse::T
end

@noinline function _throw_soil_water_modifier(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :bool
        throw(ArgumentError("$label must not be Bool"))
    elseif reason === :integer
        throw(ArgumentError("$label must be an integer"))
    elseif reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :soil_data_kind
        throw(ArgumentError("soil_data_kind (SOILDATA) must be 0, 1, 2, 3, or 4"))
    elseif reason === :undefined_linear_deficit
        throw(
            ArgumentError(
                "the legacy SMD1 <= 0 and SMD2 > 0 CALCFSOIL branch reads " *
                "SOILMOIST, a local REAL that is never initialized; no " *
                "portable reference value can be reproduced",
            ),
        )
    elseif reason === :unresolved
        throw(
            ArgumentError(
                "CALCFSOIL cannot determine FSOIL for soil_water_method=" *
                "$(value[1]) and soil_data_kind=$(value[2]) with the supplied " *
                "parameters",
            ),
        )
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _soil_water_modifier_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real || _throw_soil_water_modifier(name, value, :real)
    value isa Bool && _throw_soil_water_modifier(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) || _throw_soil_water_modifier(name, converted, :finite)
    return converted
end

@inline function _soil_water_modifier_integer(value, name::Symbol)
    value isa Bool && _throw_soil_water_modifier(name, value, :bool)
    value isa Integer || _throw_soil_water_modifier(name, value, :integer)
    return Int(value)
end

function MAESPASoilWaterStomatalModifier(
    ::Type{T};
    soil_moisture_deficit_amplitude::Real=zero(T),
    soil_moisture_deficit_rate::Real=zero(T),
    water_content_lower_fraction::Real=zero(T),
    water_content_upper_fraction::Real=zero(T),
    soil_water_potential_exponent_mpa_inverse::Real=zero(T),
) where {T<:AbstractFloat}
    return MAESPASoilWaterStomatalModifier{T}(
        _soil_water_modifier_float(
            T,
            soil_moisture_deficit_amplitude,
            :soil_moisture_deficit_amplitude,
        ),
        _soil_water_modifier_float(
            T,
            soil_moisture_deficit_rate,
            :soil_moisture_deficit_rate,
        ),
        _soil_water_modifier_float(
            T,
            water_content_lower_fraction,
            :water_content_lower_fraction,
        ),
        _soil_water_modifier_float(
            T,
            water_content_upper_fraction,
            :water_content_upper_fraction,
        ),
        _soil_water_modifier_float(
            T,
            soil_water_potential_exponent_mpa_inverse,
            :soil_water_potential_exponent_mpa_inverse,
        ),
    )
end

function MAESPASoilWaterStomatalModifier(
    parameters::Union{
        BallBerryStomatalParameters{T},
        LeuningStomatalParameters{T},
    },
) where {T<:AbstractFloat}
    return MAESPASoilWaterStomatalModifier(
        T;
        soil_moisture_deficit_amplitude=parameters.soil_moisture_deficit_amplitude,
        soil_moisture_deficit_rate=parameters.soil_moisture_deficit_rate,
        water_content_lower_fraction=parameters.water_content_lower_fraction,
        water_content_upper_fraction=parameters.water_content_upper_fraction,
        soil_water_potential_exponent_mpa_inverse=
            parameters.soil_water_potential_exponent_mpa_inverse,
    )
end

function MAESPASoilWaterStomatalModifier(config::SpeciesPhysiologyConfig)
    parameters = config.stomatal
    parameters isa Union{
        BallBerryStomatalParameters,
        LeuningStomatalParameters,
    } || throw(
        ArgumentError(
            "CALCFSOIL parameters are available only for BBGS and BBLGS configurations",
        ),
    )
    return MAESPASoilWaterStomatalModifier(parameters)
end

@inline function _soil_water_stomatal_modifier(
    ::Type{T},
    soil_moisture::T,
    soil_water_method::Int,
    soil_data_kind::Int,
    smd_amplitude::T,
    smd_rate::T,
    water_content_lower::T,
    water_content_upper::T,
    potential_exponent::T,
) where {T<:AbstractFloat}
    soil_data_kind in 0:4 || _throw_soil_water_modifier(
        :soil_data_kind,
        soil_data_kind,
        :soil_data_kind,
    )

    modifier = one(T)
    was_set = false

    # The historical IF blocks are independent, not mutually exclusive. A
    # later potential or deficit response can therefore override Emax or the
    # volumetric-content threshold; this precedence is retained deliberately.
    if soil_water_method == 1
        modifier = one(T)
        was_set = true
    end

    if soil_water_method == 2 && soil_data_kind in (3, 4)
        water_content_lower < water_content_upper || throw(
            ArgumentError("WC1 must be smaller than WC2 for WSOILMETHOD=2"),
        )
        modifier = clamp(
            (soil_moisture - water_content_lower) /
            (water_content_upper - water_content_lower),
            zero(T),
            one(T),
        )
        was_set = true
    end

    if soil_data_kind == 1 && potential_exponent > zero(T)
        modifier = exp(potential_exponent * soil_moisture)
        was_set = true
    end

    if soil_water_method == 4 || soil_data_kind == 2
        if smd_amplitude > zero(T)
            modifier = one(T) - smd_amplitude * exp(smd_rate * soil_moisture)
            was_set = true
        elseif smd_rate > zero(T)
            _throw_soil_water_modifier(
                :soil_moisture_deficit_rate,
                smd_rate,
                :undefined_linear_deficit,
            )
        end
    end

    modifier = max(modifier, zero(T))
    was_set || _throw_soil_water_modifier(
        :soil_water_stomatal_modifier,
        (soil_water_method, soil_data_kind),
        :unresolved,
    )
    isfinite(modifier) || _throw_soil_water_modifier(
        :soil_water_stomatal_modifier,
        modifier,
        :finite,
    )
    return modifier
end

"""
    soil_water_stomatal_modifier(model; soil_moisture,
                                 soil_water_method, soil_data_kind)

Evaluate the historical `CALCFSOIL` equations. `soil_data_kind` uses the
legacy codes `0=NONE`, `1=POTENTIAL` (MPa), `2=DEFICIT` (dimensionless),
`3=CONTENT` (m³ m⁻³), and `4=SIMULATED` content. `soil_water_method=1` is
the Emax case, `2` the volumetric threshold, and `4` the deficit response.

The legacy linear-deficit branch (`SMD1 <= 0 && SMD2 > 0`) is intentionally
an explicit error because it reads the uninitialized local `SOILMOIST` rather
than the `SOILMOISTURE` argument. Substituting the argument would be a model
correction, not a portable reimplementation.
"""
function soil_water_stomatal_modifier(
    model::MAESPASoilWaterStomatalModifier;
    soil_moisture::Real,
    soil_water_method,
    soil_data_kind,
)
    soil_moisture isa Bool && _throw_soil_water_modifier(
        :soil_moisture,
        soil_moisture,
        :bool,
    )
    primary = float(soil_moisture)
    primary isa AbstractFloat || _throw_soil_water_modifier(
        :soil_moisture,
        soil_moisture,
        :real,
    )
    T = typeof(primary)
    moisture = _soil_water_modifier_float(T, primary, :soil_moisture)
    method = _soil_water_modifier_integer(soil_water_method, :soil_water_method)
    data_kind = _soil_water_modifier_integer(soil_data_kind, :soil_data_kind)
    modifier = _soil_water_stomatal_modifier(
        T,
        moisture,
        method,
        data_kind,
        _soil_water_modifier_float(
            T,
            model.soil_moisture_deficit_amplitude,
            :soil_moisture_deficit_amplitude,
        ),
        _soil_water_modifier_float(
            T,
            model.soil_moisture_deficit_rate,
            :soil_moisture_deficit_rate,
        ),
        _soil_water_modifier_float(
            T,
            model.water_content_lower_fraction,
            :water_content_lower_fraction,
        ),
        _soil_water_modifier_float(
            T,
            model.water_content_upper_fraction,
            :water_content_upper_fraction,
        ),
        _soil_water_modifier_float(
            T,
            model.soil_water_potential_exponent_mpa_inverse,
            :soil_water_potential_exponent_mpa_inverse,
        ),
    )
    return SoilWaterStomatalModifierResult{T}(modifier)
end

PlantSimEngine.inputs_(::MAESPASoilWaterStomatalModifier) = (
    soil_moisture=PlantSimEngine.Required(Real),
    soil_water_method=PlantSimEngine.Required(Integer),
    soil_data_kind=PlantSimEngine.Required(Integer),
)

function PlantSimEngine.outputs_(model::MAESPASoilWaterStomatalModifier{T}) where {T}
    return (
        soil_water_stomatal_modifier=one(T),
        soil_water_stomatal_modifier_available=false,
    )
end

function PlantSimEngine.run!(
    model::MAESPASoilWaterStomatalModifier,
    status,
    environment,
    constants,
    context,
)
    status.soil_water_stomatal_modifier_available = false
    result = soil_water_stomatal_modifier(
        model;
        soil_moisture=status.soil_moisture,
        soil_water_method=status.soil_water_method,
        soil_data_kind=status.soil_data_kind,
    )
    status.soil_water_stomatal_modifier = result.soil_water_stomatal_modifier
    status.soil_water_stomatal_modifier_available = true
    return nothing
end
