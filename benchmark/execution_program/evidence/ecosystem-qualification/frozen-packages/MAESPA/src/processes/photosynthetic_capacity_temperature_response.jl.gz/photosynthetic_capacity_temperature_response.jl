PlantSimEngine.@process "photosynthetic_capacity_temperature_response" verbose = false

"""
Scalar result of MAESPA's historical photosynthetic-capacity temperature laws.

All rates are expressed per unit leaf area. `rubisco_michaelis_menten_umol_mol`
is the effective Rubisco Michaelis--Menten coefficient `Km`, including the
legacy fixed oxygen partial pressure of 205 000 μmol mol⁻¹.
"""
struct PhotosyntheticCapacityTemperatureResponseResult{T<:AbstractFloat}
    gamma_star_umol_mol::T
    rubisco_michaelis_menten_umol_mol::T
    jmax_umol_m2_s::T
    vcmax_umol_m2_s::T
    rd_umol_m2_s::T
    water_stress_modifier::T
end

"""
    MAESPAPhotosyntheticCapacityTemperatureResponse(respiration; kwargs...)

Parameters for the temperature-dependent capacity block in `PSTRANSP`.

The names in parentheses are the historical namelist arguments:

- `ieco`: `IECO`, either the ECOCRAFT (`1`) or Bernacchi (`0`) laws for Γ* and
  Km;
- `jmax_*`: `EAVJ`, `EDVJ`, and `DELSJ`;
- `vcmax_*`: `EAVC`, `EDVC`, and `DELSC`; `EDVC <= 0` selects the historical
  non-peaked Vcmax response;
- `low_temperature_ramp_*`: `TVJDN` and `TVJUP`;
- `water_stress_*`: `VFUN` and `VPARA/B/C`.

`VPARC` is retained for an auditable legacy interface but is deliberately not
used: the Fortran `VJMAXWFN` accepts it and never references it. `MODELJM` and
`MODELRD` are also deliberately absent. They only decide whether the reference
tables JMAX25/VCMAX25/RD0 are read directly or derived from leaf nitrogen before
this process is called. The process consumes those already-materialised values.

`PhotosyntheticCapacityParameters` retains these fixed PHY values separately
from the dated JMAX25/VCMAX25/RD0 tables. Constructors accepting either that
parameter structure or a complete `SpeciesPhysiologyConfig` keep parser and
model field mappings in one place.
"""
struct MAESPAPhotosyntheticCapacityTemperatureResponse{T<:AbstractFloat} <:
       AbstractPhotosynthetic_Capacity_Temperature_ResponseModel
    ieco::Int
    jmax_activation_energy_j_mol::T
    jmax_deactivation_energy_j_mol::T
    jmax_entropy_j_mol_k::T
    vcmax_activation_energy_j_mol::T
    vcmax_deactivation_energy_j_mol::T
    vcmax_entropy_j_mol_k::T
    low_temperature_ramp_upper_c::T
    low_temperature_ramp_lower_c::T
    respiration_acclimation_coefficient_c_inverse::T
    respiration_reference_temperature_c::T
    respiration_minimum_temperature_c::T
    respiration_day_multiplier::T
    water_stress_model::Int
    water_stress_parameter_a::T
    water_stress_parameter_b::T
    water_stress_parameter_c::T
    gas_constant_j_mol_k::T
    kelvin_offset_c::T
end

@noinline function _throw_capacity_numeric(name::Symbol, value, reason::Symbol)
    label = String(name)
    if reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :absolute_zero
        throw(DomainError(value, "$label must be above absolute zero"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _capacity_float(
    ::Type{T},
    value::Real,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Bool && _throw_capacity_numeric(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) || _throw_capacity_numeric(name, converted, :finite)
    return converted
end

@inline function _capacity_nonnegative(value::T, name::Symbol) where {T}
    value >= zero(T) || _throw_capacity_numeric(name, value, :nonnegative)
    return value
end

@inline function _capacity_option(value::Integer, name::Symbol)
    value isa Bool && throw(ArgumentError("$(String(name)) must be an integer, not Bool"))
    option = Int(value)
    option in (0, 1) || throw(
        ArgumentError("$(String(name)) must be 0 or 1"),
    )
    return option
end

@inline function _water_stress_option(value::Integer)
    value isa Bool && throw(
        ArgumentError("water_stress_model (VFUN) must be an integer, not Bool"),
    )
    option = Int(value)
    option in (0, 1, 2) || throw(
        ArgumentError("water_stress_model (VFUN) must be 0, 1, or 2"),
    )
    return option
end

function MAESPAPhotosyntheticCapacityTemperatureResponse(
    ::Type{T},
    respiration::LeafRespirationParameters;
    ieco::Integer=1,
    jmax_activation_energy_j_mol::Real,
    jmax_deactivation_energy_j_mol::Real,
    jmax_entropy_j_mol_k::Real,
    vcmax_activation_energy_j_mol::Real,
    vcmax_deactivation_energy_j_mol::Real=zero(T),
    vcmax_entropy_j_mol_k::Real=zero(T),
    low_temperature_ramp_upper_c::Real=T(-100),
    low_temperature_ramp_lower_c::Real=T(-100),
    water_stress_model::Integer=0,
    water_stress_parameter_a::Real=T(-200),
    water_stress_parameter_b::Real=T(-199),
    water_stress_parameter_c::Real=one(T),
    gas_constant_j_mol_k::Real=T(8.314),
    kelvin_offset_c::Real=T(273.15),
) where {T<:AbstractFloat}
    ecocraft_option = _capacity_option(ieco, :ieco)
    stress_option = _water_stress_option(water_stress_model)

    eavj = _capacity_float(
        T,
        jmax_activation_energy_j_mol,
        :jmax_activation_energy_j_mol,
    )
    edvj = _capacity_float(
        T,
        jmax_deactivation_energy_j_mol,
        :jmax_deactivation_energy_j_mol,
    )
    delsj = _capacity_float(T, jmax_entropy_j_mol_k, :jmax_entropy_j_mol_k)
    eavc = _capacity_float(
        T,
        vcmax_activation_energy_j_mol,
        :vcmax_activation_energy_j_mol,
    )
    edvc = _capacity_float(
        T,
        vcmax_deactivation_energy_j_mol,
        :vcmax_deactivation_energy_j_mol,
    )
    delsc = _capacity_float(T, vcmax_entropy_j_mol_k, :vcmax_entropy_j_mol_k)
    ramp_upper = _capacity_float(
        T,
        low_temperature_ramp_upper_c,
        :low_temperature_ramp_upper_c,
    )
    ramp_lower = _capacity_float(
        T,
        low_temperature_ramp_lower_c,
        :low_temperature_ramp_lower_c,
    )
    ramp_upper >= ramp_lower || throw(
        ArgumentError(
            "low_temperature_ramp_upper_c (TVJUP) must be at least " *
            "low_temperature_ramp_lower_c (TVJDN)",
        ),
    )

    acclimation = _capacity_float(
        T,
        respiration.acclimation_coefficient_c_inverse,
        :respiration_acclimation_coefficient_c_inverse,
    )
    reference_temperature = _capacity_float(
        T,
        respiration.reference_temperature_c,
        :respiration_reference_temperature_c,
    )
    minimum_temperature = _capacity_float(
        T,
        respiration.minimum_temperature_c,
        :respiration_minimum_temperature_c,
    )
    day_multiplier = _capacity_float(
        T,
        respiration.day_respiration_multiplier,
        :respiration_day_multiplier,
    )
    _capacity_nonnegative(day_multiplier, :respiration_day_multiplier)

    stress_a = _capacity_float(
        T,
        water_stress_parameter_a,
        :water_stress_parameter_a,
    )
    stress_b = _capacity_float(
        T,
        water_stress_parameter_b,
        :water_stress_parameter_b,
    )
    stress_c = _capacity_float(
        T,
        water_stress_parameter_c,
        :water_stress_parameter_c,
    )
    stress_option == 1 && stress_b <= stress_a && throw(
        ArgumentError(
            "VFUN=1 requires water_stress_parameter_b to exceed " *
            "water_stress_parameter_a",
        ),
    )

    gas_constant = _capacity_float(
        T,
        gas_constant_j_mol_k,
        :gas_constant_j_mol_k,
    )
    gas_constant > zero(T) || throw(
        DomainError(gas_constant, "gas_constant_j_mol_k must be positive"),
    )
    kelvin_offset = _capacity_float(T, kelvin_offset_c, :kelvin_offset_c)
    kelvin_offset > zero(T) || throw(
        DomainError(kelvin_offset, "kelvin_offset_c must be positive"),
    )

    return MAESPAPhotosyntheticCapacityTemperatureResponse{T}(
        ecocraft_option,
        eavj,
        edvj,
        delsj,
        eavc,
        edvc,
        delsc,
        ramp_upper,
        ramp_lower,
        acclimation,
        reference_temperature,
        minimum_temperature,
        day_multiplier,
        stress_option,
        stress_a,
        stress_b,
        stress_c,
        gas_constant,
        kelvin_offset,
    )
end

function MAESPAPhotosyntheticCapacityTemperatureResponse(
    respiration::LeafRespirationParameters{T};
    kwargs...,
) where {T<:AbstractFloat}
    return MAESPAPhotosyntheticCapacityTemperatureResponse(
        T,
        respiration;
        kwargs...,
    )
end

function MAESPAPhotosyntheticCapacityTemperatureResponse(
    parameters::PhotosyntheticCapacityParameters{T},
    respiration::LeafRespirationParameters{T},
) where {T<:AbstractFloat}
    return MAESPAPhotosyntheticCapacityTemperatureResponse(
        T,
        respiration;
        ieco=parameters.ieco,
        jmax_activation_energy_j_mol=parameters.jmax_activation_energy_j_mol,
        jmax_deactivation_energy_j_mol=parameters.jmax_deactivation_energy_j_mol,
        jmax_entropy_j_mol_k=parameters.jmax_entropy_j_mol_k,
        vcmax_activation_energy_j_mol=parameters.vcmax_activation_energy_j_mol,
        vcmax_deactivation_energy_j_mol=parameters.vcmax_deactivation_energy_j_mol,
        vcmax_entropy_j_mol_k=parameters.vcmax_entropy_j_mol_k,
        low_temperature_ramp_upper_c=parameters.low_temperature_ramp_upper_c,
        low_temperature_ramp_lower_c=parameters.low_temperature_ramp_lower_c,
        water_stress_model=parameters.water_stress_model,
        water_stress_parameter_a=parameters.water_stress_parameter_a,
        water_stress_parameter_b=parameters.water_stress_parameter_b,
        water_stress_parameter_c=parameters.water_stress_parameter_c,
    )
end

function MAESPAPhotosyntheticCapacityTemperatureResponse(
    config::SpeciesPhysiologyConfig{T},
) where {T<:AbstractFloat}
    parameters = _required_photosynthetic_capacity_parameters(config)
    return MAESPAPhotosyntheticCapacityTemperatureResponse(
        parameters,
        config.leaf_respiration,
    )
end

@inline function _capacity_arrhenius(
    reference_value::T,
    activation_energy_j_mol::T,
    temperature_c::T,
    reference_temperature_c::T,
    gas_constant_j_mol_k::T,
    kelvin_offset_c::T,
) where {T<:AbstractFloat}
    temperature_k = temperature_c + kelvin_offset_c
    reference_temperature_k = reference_temperature_c + kelvin_offset_c
    exponent = activation_energy_j_mol *
               (temperature_c - reference_temperature_c) /
               (gas_constant_j_mol_k * temperature_k * reference_temperature_k)
    return reference_value * exp(exponent)
end

@inline function _capacity_gamma_star(
    temperature_c::T,
    ieco::Int,
    gas_constant_j_mol_k::T,
    kelvin_offset_c::T,
) where {T<:AbstractFloat}
    if ieco == 1
        delta_temperature = temperature_c < -one(T) ? T(-26) : temperature_c - T(25)
        return T(36.9) + T(1.88) * delta_temperature +
               T(0.036) * delta_temperature * delta_temperature
    end
    return _capacity_arrhenius(
        T(42.75),
        T(37_830),
        temperature_c,
        T(25),
        gas_constant_j_mol_k,
        kelvin_offset_c,
    )
end

@inline function _capacity_rubisco_michaelis_menten(
    temperature_c::T,
    ieco::Int,
    gas_constant_j_mol_k::T,
    kelvin_offset_c::T,
) where {T<:AbstractFloat}
    oxygen_umol_mol = T(205_000)
    if ieco == 1
        kc25 = T(404)
        ko25 = T(248_000)
        kc_activation = T(59_400)
        ko_activation = T(36_000)
    else
        kc25 = T(404.9)
        ko25 = T(278_400)
        kc_activation = T(79_430)
        ko_activation = T(36_380)
    end
    kc = _capacity_arrhenius(
        kc25,
        kc_activation,
        temperature_c,
        T(25),
        gas_constant_j_mol_k,
        kelvin_offset_c,
    )
    ko = _capacity_arrhenius(
        ko25,
        ko_activation,
        temperature_c,
        T(25),
        gas_constant_j_mol_k,
        kelvin_offset_c,
    )
    return kc * (one(T) + oxygen_umol_mol / ko)
end

@inline function _capacity_peaked_arrhenius(
    reference_value::T,
    temperature_c::T,
    activation_energy_j_mol::T,
    deactivation_energy_j_mol::T,
    entropy_j_mol_k::T,
    gas_constant_j_mol_k::T,
    kelvin_offset_c::T,
) where {T<:AbstractFloat}
    reference_temperature_c = T(25)
    temperature_k = temperature_c + kelvin_offset_c
    reference_temperature_k = reference_temperature_c + kelvin_offset_c
    activation = exp(
        (temperature_c - reference_temperature_c) * activation_energy_j_mol /
        (gas_constant_j_mol_k * temperature_k * reference_temperature_k),
    )
    reference_deactivation = one(T) + exp(
        (entropy_j_mol_k * reference_temperature_k -
         deactivation_energy_j_mol) /
        (gas_constant_j_mol_k * reference_temperature_k),
    )
    temperature_deactivation = one(T) + exp(
        (entropy_j_mol_k * temperature_k - deactivation_energy_j_mol) /
        (gas_constant_j_mol_k * temperature_k),
    )
    return reference_value * activation *
           reference_deactivation / temperature_deactivation
end

@inline function _capacity_cold_ramp(
    value::T,
    temperature_c::T,
    ramp_upper_c::T,
    ramp_lower_c::T,
) where {T<:AbstractFloat}
    temperature_c < ramp_lower_c && return zero(T)
    temperature_c < ramp_upper_c || return value
    return (temperature_c - ramp_lower_c) /
           (ramp_upper_c - ramp_lower_c) * value
end

@inline function _capacity_jmax(
    jmax25_umol_m2_s::T,
    temperature_c::T,
    activation_energy_j_mol::T,
    deactivation_energy_j_mol::T,
    entropy_j_mol_k::T,
    ramp_upper_c::T,
    ramp_lower_c::T,
    gas_constant_j_mol_k::T,
    kelvin_offset_c::T,
) where {T<:AbstractFloat}
    response = _capacity_peaked_arrhenius(
        jmax25_umol_m2_s,
        temperature_c,
        activation_energy_j_mol,
        deactivation_energy_j_mol,
        entropy_j_mol_k,
        gas_constant_j_mol_k,
        kelvin_offset_c,
    )
    return _capacity_cold_ramp(
        response,
        temperature_c,
        ramp_upper_c,
        ramp_lower_c,
    )
end

@inline function _capacity_vcmax(
    vcmax25_umol_m2_s::T,
    temperature_c::T,
    activation_energy_j_mol::T,
    deactivation_energy_j_mol::T,
    entropy_j_mol_k::T,
    ramp_upper_c::T,
    ramp_lower_c::T,
    gas_constant_j_mol_k::T,
    kelvin_offset_c::T,
) where {T<:AbstractFloat}
    response = if deactivation_energy_j_mol <= zero(T)
        _capacity_arrhenius(
            vcmax25_umol_m2_s,
            activation_energy_j_mol,
            temperature_c,
            T(25),
            gas_constant_j_mol_k,
            kelvin_offset_c,
        )
    else
        _capacity_peaked_arrhenius(
            vcmax25_umol_m2_s,
            temperature_c,
            activation_energy_j_mol,
            deactivation_energy_j_mol,
            entropy_j_mol_k,
            gas_constant_j_mol_k,
            kelvin_offset_c,
        )
    end
    return _capacity_cold_ramp(
        response,
        temperature_c,
        ramp_upper_c,
        ramp_lower_c,
    )
end

@inline function _capacity_water_stress_modifier(
    soil_water_potential_mpa::T,
    water_stress_model::Int,
    parameter_a::T,
    parameter_b::T,
) where {T<:AbstractFloat}
    water_stress_model == 0 && return one(T)
    if water_stress_model == 1
        soil_water_potential_mpa < parameter_a && return zero(T)
        soil_water_potential_mpa > parameter_b && return one(T)
        return (soil_water_potential_mpa - parameter_a) /
               (parameter_b - parameter_a)
    end
    return (one(T) + exp(parameter_a * parameter_b)) /
           (one(T) + exp(parameter_a * (parameter_b - soil_water_potential_mpa)))
end

@inline function _capacity_leaf_respiration(
    rd0_umol_m2_s::T,
    leaf_temperature_c::T,
    moving_average_air_temperature_c::T,
    temperature_coefficient_c_inverse::T,
    acclimation_coefficient_c_inverse::T,
    reference_temperature_c::T,
    minimum_temperature_c::T,
    day_multiplier::T,
    astronomical_daylight::Bool,
) where {T<:AbstractFloat}
    leaf_temperature_c >= minimum_temperature_c || return zero(T)
    acclimated_rd0 = rd0_umol_m2_s * exp(
        acclimation_coefficient_c_inverse *
        (moving_average_air_temperature_c - reference_temperature_c),
    )
    light_multiplier = astronomical_daylight ? day_multiplier : one(T)
    return acclimated_rd0 * exp(
        temperature_coefficient_c_inverse *
        (leaf_temperature_c - reference_temperature_c),
    ) * light_multiplier
end

@inline function _validate_capacity_runtime_inputs(
    model::MAESPAPhotosyntheticCapacityTemperatureResponse{M},
    leaf_temperature_c::T,
    moving_average_air_temperature_c::T,
    jmax25_umol_m2_s::T,
    vcmax25_umol_m2_s::T,
    rd0_umol_m2_s::T,
    respiration_temperature_coefficient_c_inverse::T,
    weighted_soil_water_potential_mpa::T,
) where {M<:AbstractFloat,T<:AbstractFloat}
    leaf_temperature_c > -convert(T, model.kelvin_offset_c) ||
        _throw_capacity_numeric(:leaf_temperature_c, leaf_temperature_c, :absolute_zero)
    _capacity_nonnegative(jmax25_umol_m2_s, :jmax25_umol_m2_s)
    _capacity_nonnegative(vcmax25_umol_m2_s, :vcmax25_umol_m2_s)
    _capacity_nonnegative(rd0_umol_m2_s, :rd0_umol_m2_s)
    # The remaining values have already passed `_capacity_float`.
    model.water_stress_model == 0 || isfinite(weighted_soil_water_potential_mpa) ||
        _throw_capacity_numeric(
            :weighted_soil_water_potential_mpa,
            weighted_soil_water_potential_mpa,
            :finite,
        )
    return nothing
end

@noinline function _throw_capacity_nonfinite_output(name::Symbol, value)
    throw(ArgumentError("$(String(name)) is non-finite for the supplied parameters: $value"))
end

@inline function _capacity_finite_output(value::T, name::Symbol) where {T}
    isfinite(value) || _throw_capacity_nonfinite_output(name, value)
    return value
end

@inline function _photosynthetic_capacity_temperature_response(
    model::MAESPAPhotosyntheticCapacityTemperatureResponse,
    ::Type{T},
    leaf_temperature_c::T,
    moving_average_air_temperature_c::T,
    jmax25_umol_m2_s::T,
    vcmax25_umol_m2_s::T,
    rd0_umol_m2_s::T,
    respiration_temperature_coefficient_c_inverse::T,
    weighted_soil_water_potential_mpa::T,
    astronomical_daylight::Bool,
) where {T<:AbstractFloat}
    gas_constant = convert(T, model.gas_constant_j_mol_k)
    kelvin_offset = convert(T, model.kelvin_offset_c)
    # Arrhenius responses require a positive absolute temperature at each trial.
    leaf_temperature_c > -kelvin_offset ||
        _throw_capacity_numeric(:leaf_temperature_c, leaf_temperature_c, :absolute_zero)
    gamma_star = _capacity_gamma_star(
        leaf_temperature_c,
        model.ieco,
        gas_constant,
        kelvin_offset,
    )
    km = _capacity_rubisco_michaelis_menten(
        leaf_temperature_c,
        model.ieco,
        gas_constant,
        kelvin_offset,
    )
    stress_modifier = _capacity_water_stress_modifier(
        weighted_soil_water_potential_mpa,
        model.water_stress_model,
        convert(T, model.water_stress_parameter_a),
        convert(T, model.water_stress_parameter_b),
    )
    jmax = _capacity_jmax(
        jmax25_umol_m2_s,
        leaf_temperature_c,
        convert(T, model.jmax_activation_energy_j_mol),
        convert(T, model.jmax_deactivation_energy_j_mol),
        convert(T, model.jmax_entropy_j_mol_k),
        convert(T, model.low_temperature_ramp_upper_c),
        convert(T, model.low_temperature_ramp_lower_c),
        gas_constant,
        kelvin_offset,
    ) * stress_modifier
    vcmax = _capacity_vcmax(
        vcmax25_umol_m2_s,
        leaf_temperature_c,
        convert(T, model.vcmax_activation_energy_j_mol),
        convert(T, model.vcmax_deactivation_energy_j_mol),
        convert(T, model.vcmax_entropy_j_mol_k),
        convert(T, model.low_temperature_ramp_upper_c),
        convert(T, model.low_temperature_ramp_lower_c),
        gas_constant,
        kelvin_offset,
    ) * stress_modifier
    rd = _capacity_leaf_respiration(
        rd0_umol_m2_s,
        leaf_temperature_c,
        moving_average_air_temperature_c,
        respiration_temperature_coefficient_c_inverse,
        convert(T, model.respiration_acclimation_coefficient_c_inverse),
        convert(T, model.respiration_reference_temperature_c),
        convert(T, model.respiration_minimum_temperature_c),
        convert(T, model.respiration_day_multiplier),
        astronomical_daylight,
    )

    return PhotosyntheticCapacityTemperatureResponseResult{T}(
        _capacity_finite_output(gamma_star, :gamma_star_umol_mol),
        _capacity_finite_output(km, :rubisco_michaelis_menten_umol_mol),
        _capacity_finite_output(jmax, :jmax_umol_m2_s),
        _capacity_finite_output(vcmax, :vcmax_umol_m2_s),
        _capacity_finite_output(rd, :rd_umol_m2_s),
        _capacity_finite_output(stress_modifier, :water_stress_modifier),
    )
end

"""
    photosynthetic_capacity_temperature_response(model, leaf_temperature_c,
        moving_average_air_temperature_c, jmax25, vcmax25, rd0,
        respiration_temperature_coefficient, weighted_soil_water_potential;
        astronomical_daylight)

Evaluate the `GAMMAFN`, `KMFN`, `JMAXTFN`, `VCMAXTFN`, `RESP`, and
`VJMAXWFN` equations used inline by the historical `PSTRANSP` routine.

`astronomical_daylight` only selects the configured `DAYRESP` multiplier.
At night the multiplier is exactly one, matching the separate night-time call
in `maespa.f90`. Water stress modifies Jmax and Vcmax only; Γ*, Km, and Rd are
unchanged. No `4.57 μmol J⁻¹` PAR conversion is performed here.
"""
function photosynthetic_capacity_temperature_response(
    model::MAESPAPhotosyntheticCapacityTemperatureResponse,
    leaf_temperature_c::Real,
    moving_average_air_temperature_c::Real,
    jmax25_umol_m2_s::Real,
    vcmax25_umol_m2_s::Real,
    rd0_umol_m2_s::Real,
    respiration_temperature_coefficient_c_inverse::Real,
    weighted_soil_water_potential_mpa::Real;
    astronomical_daylight=true,
)
    astronomical_daylight isa Bool || throw(
        ArgumentError("astronomical_daylight must be Bool"),
    )
    for (value, name) in (
        (leaf_temperature_c, :leaf_temperature_c),
        (moving_average_air_temperature_c, :moving_average_air_temperature_c),
        (jmax25_umol_m2_s, :jmax25_umol_m2_s),
        (vcmax25_umol_m2_s, :vcmax25_umol_m2_s),
        (rd0_umol_m2_s, :rd0_umol_m2_s),
        (
            respiration_temperature_coefficient_c_inverse,
            :respiration_temperature_coefficient_c_inverse,
        ),
        (weighted_soil_water_potential_mpa, :weighted_soil_water_potential_mpa),
    )
        value isa Bool && _throw_capacity_numeric(name, value, :bool)
    end
    promoted = promote(
        model.gas_constant_j_mol_k,
        float(leaf_temperature_c),
        float(moving_average_air_temperature_c),
        float(jmax25_umol_m2_s),
        float(vcmax25_umol_m2_s),
        float(rd0_umol_m2_s),
        float(respiration_temperature_coefficient_c_inverse),
        float(weighted_soil_water_potential_mpa),
    )
    T = typeof(promoted[1])
    leaf_temperature = _capacity_float(T, promoted[2], :leaf_temperature_c)
    moving_temperature = _capacity_float(
        T,
        promoted[3],
        :moving_average_air_temperature_c,
    )
    jmax25 = _capacity_float(T, promoted[4], :jmax25_umol_m2_s)
    vcmax25 = _capacity_float(T, promoted[5], :vcmax25_umol_m2_s)
    rd0 = _capacity_float(T, promoted[6], :rd0_umol_m2_s)
    temperature_coefficient = _capacity_float(
        T,
        promoted[7],
        :respiration_temperature_coefficient_c_inverse,
    )
    soil_water_potential = model.water_stress_model == 0 ?
                           convert(T, promoted[8]) :
                           _capacity_float(
        T,
        promoted[8],
        :weighted_soil_water_potential_mpa,
    )
    _validate_capacity_runtime_inputs(
        model, leaf_temperature, moving_temperature, jmax25, vcmax25, rd0,
        temperature_coefficient, soil_water_potential,
    )
    return _photosynthetic_capacity_temperature_response(
        model,
        T,
        leaf_temperature,
        moving_temperature,
        jmax25,
        vcmax25,
        rd0,
        temperature_coefficient,
        soil_water_potential,
        astronomical_daylight,
    )
end

PlantSimEngine.variable_contracts_(::MAESPAPhotosyntheticCapacityTemperatureResponse) = (
    weighted_soil_water_potential_mpa=EFFECTIVE_SOIL_WATER_POTENTIAL_CONTRACT,
)

function PlantSimEngine.inputs_(
    model::MAESPAPhotosyntheticCapacityTemperatureResponse{T},
) where {T}
    soil_water_potential = model.water_stress_model == 0 ?
                           PlantSimEngine.Default(zero(T)) :
                           PlantSimEngine.Required(Real)
    return (
        leaf_temperature_c=PlantSimEngine.Required(Real),
        moving_average_air_temperature_c=PlantSimEngine.Required(Real),
        jmax25_umol_m2_s=PlantSimEngine.Required(Real),
        vcmax25_umol_m2_s=PlantSimEngine.Required(Real),
        rd0_umol_m2_s=PlantSimEngine.Required(Real),
        leaf_respiration_temperature_coefficient_c_inverse=PlantSimEngine.Required(
            Real,
        ),
        weighted_soil_water_potential_mpa=soil_water_potential,
        astronomical_daylight=PlantSimEngine.Required(Bool),
        photosynthetic_capacity_inputs_available=PlantSimEngine.Default(true),
    )
end

PlantSimEngine.outputs_(
    model::MAESPAPhotosyntheticCapacityTemperatureResponse{T},
) where {T} = (
    gamma_star_umol_mol=zero(T),
    rubisco_michaelis_menten_umol_mol=zero(T),
    jmax_umol_m2_s=zero(T),
    vcmax_umol_m2_s=zero(T),
    rd_umol_m2_s=zero(T),
    water_stress_modifier=zero(T),
    photosynthetic_capacity_temperature_response_available=false,
)

@inline function _reset_photosynthetic_capacity_temperature_response!(
    status,
    ::Type{T},
) where {T<:AbstractFloat}
    status.gamma_star_umol_mol = zero(T)
    status.rubisco_michaelis_menten_umol_mol = zero(T)
    status.jmax_umol_m2_s = zero(T)
    status.vcmax_umol_m2_s = zero(T)
    status.rd_umol_m2_s = zero(T)
    status.water_stress_modifier = zero(T)
    status.photosynthetic_capacity_temperature_response_available = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPAPhotosyntheticCapacityTemperatureResponse,
    status, environment, constants, context,
)
    T = typeof(status.gamma_star_umol_mol)
    _reset_photosynthetic_capacity_temperature_response!(status, T)
    status.photosynthetic_capacity_inputs_available || return nothing

    # GAMMAFN/KMFN, temperature and water responses of Jmax/Vcmax, then RESP.
    capacity = _photosynthetic_capacity_temperature_response(
        model, T,
        T(status.leaf_temperature_c),
        T(status.moving_average_air_temperature_c),
        T(status.jmax25_umol_m2_s), T(status.vcmax25_umol_m2_s),
        T(status.rd0_umol_m2_s),
        T(status.leaf_respiration_temperature_coefficient_c_inverse),
        T(status.weighted_soil_water_potential_mpa),
        status.astronomical_daylight,
    )
    status.gamma_star_umol_mol = capacity.gamma_star_umol_mol
    status.rubisco_michaelis_menten_umol_mol = capacity.rubisco_michaelis_menten_umol_mol
    status.jmax_umol_m2_s = capacity.jmax_umol_m2_s
    status.vcmax_umol_m2_s = capacity.vcmax_umol_m2_s
    status.rd_umol_m2_s = capacity.rd_umol_m2_s
    status.water_stress_modifier = capacity.water_stress_modifier
    status.photosynthetic_capacity_temperature_response_available = true
    return nothing
end
