PlantSimEngine.@process "leaf_penman_monteith" verbose = false

"""
Scalar result of MAESPA's historical `PENMON` leaf-water-flux equation.

`water_flux_mol_m2_s` is deliberately signed: a negative value represents
dew deposition. `latent_heat_flux_w_m2` is the corresponding signed energy
flux, and `psychrometric_constant_pa_k` is the `GAMMA` value used in the
denominator.
"""
struct LeafPenmanMonteithResult{T<:AbstractFloat}
    water_flux_mol_m2_s::T
    latent_heat_flux_w_m2::T
    psychrometric_constant_pa_k::T
end

@noinline function _throw_leaf_penman_numeric(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :denominator
        throw(
            DomainError(
                value,
                "the Penman--Monteith denominator must be finite and positive",
            ),
        )
    elseif reason === :result
        throw(DomainError(value, "the Penman--Monteith result must be finite"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _leaf_penman_float(
    ::Type{T},
    value::Real,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Bool && _throw_leaf_penman_numeric(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_leaf_penman_numeric(name, converted, :finite)
    return converted
end

@inline function _leaf_penman_positive(value::T, name::Symbol) where {T}
    isfinite(value) || _throw_leaf_penman_numeric(name, value, :finite)
    value > zero(T) || _throw_leaf_penman_numeric(name, value, :positive)
    return value
end

@inline function _leaf_penman_nonnegative(value::T, name::Symbol) where {T}
    isfinite(value) || _throw_leaf_penman_numeric(name, value, :finite)
    value >= zero(T) ||
        _throw_leaf_penman_numeric(name, value, :nonnegative)
    return value
end

"""
    MAESPALeafPenmanMonteith(T=Float64; kwargs...)

Parameters for the historical MAESPA `PENMON` equation. The defaults are the
single-precision constants from `maestcom.f90`: air specific heat
`CPAIR = 1010 J kg⁻¹ K⁻¹` and air molar mass `AIRMA = 0.029 kg mol⁻¹`.

The model is intentionally stateless and suitable as a manual hard-call target
of the future iterative leaf-energy controller. That controller will invoke
the same kernel separately for the dry-canopy and wet-surface conductances.
"""
struct MAESPALeafPenmanMonteith{T<:AbstractFloat} <:
       AbstractLeaf_Penman_MonteithModel
    air_specific_heat_j_kg_k::T
    air_molar_mass_kg_mol::T
end

function MAESPALeafPenmanMonteith(
    ::Type{T}=Float64;
    air_specific_heat_j_kg_k::Real=T(1010),
    air_molar_mass_kg_mol::Real=T(29e-3),
) where {T<:AbstractFloat}
    specific_heat = _leaf_penman_positive(
        _leaf_penman_float(
            T,
            air_specific_heat_j_kg_k,
            :air_specific_heat_j_kg_k,
        ),
        :air_specific_heat_j_kg_k,
    )
    molar_mass = _leaf_penman_positive(
        _leaf_penman_float(T, air_molar_mass_kg_mol, :air_molar_mass_kg_mol),
        :air_molar_mass_kg_mol,
    )
    return MAESPALeafPenmanMonteith{T}(specific_heat, molar_mass)
end

@inline function _validate_leaf_penman_inputs(
    atmospheric_pressure_pa::T,
    saturation_vapour_pressure_slope_pa_k::T,
    latent_heat_vaporization_j_mol::T,
    leaf_net_radiation_w_m2::T,
    vapour_pressure_deficit_pa::T,
    total_heat_conductance_mol_m2_s::T,
    total_water_vapour_conductance_mol_m2_s::T,
) where {T<:AbstractFloat}
    _leaf_penman_positive(atmospheric_pressure_pa, :atmospheric_pressure_pa)
    _leaf_penman_nonnegative(
        saturation_vapour_pressure_slope_pa_k,
        :saturation_vapour_pressure_slope_pa_k,
    )
    _leaf_penman_positive(
        latent_heat_vaporization_j_mol,
        :latent_heat_vaporization_j_mol,
    )
    # Net radiation and VPD are signed finite drivers. Negative RNET and/or
    # supersaturation can therefore yield the historical dew flux.
    isfinite(leaf_net_radiation_w_m2) || _throw_leaf_penman_numeric(
        :leaf_net_radiation_w_m2,
        leaf_net_radiation_w_m2,
        :finite,
    )
    isfinite(vapour_pressure_deficit_pa) || _throw_leaf_penman_numeric(
        :vapour_pressure_deficit_pa,
        vapour_pressure_deficit_pa,
        :finite,
    )
    _leaf_penman_nonnegative(
        total_heat_conductance_mol_m2_s,
        :total_heat_conductance_mol_m2_s,
    )
    # Preserve PENMON exactly here: every GV <= 0 value takes the zero-flux
    # branch instead of evaluating GH/GV. Finiteness is still required.
    isfinite(total_water_vapour_conductance_mol_m2_s) ||
        _throw_leaf_penman_numeric(
            :total_water_vapour_conductance_mol_m2_s,
            total_water_vapour_conductance_mol_m2_s,
            :finite,
        )
    return nothing
end

@inline function _leaf_penman_monteith(
    model::MAESPALeafPenmanMonteith,
    ::Type{T},
    atmospheric_pressure_pa::T,
    saturation_vapour_pressure_slope_pa_k::T,
    latent_heat_vaporization_j_mol::T,
    leaf_net_radiation_w_m2::T,
    vapour_pressure_deficit_pa::T,
    total_heat_conductance_mol_m2_s::T,
    total_water_vapour_conductance_mol_m2_s::T,
) where {T<:AbstractFloat}
    specific_heat = T(model.air_specific_heat_j_kg_k)
    molar_mass = T(model.air_molar_mass_kg_mol)

    molar_heat_capacity = specific_heat * molar_mass
    isfinite(molar_heat_capacity) || _throw_leaf_penman_numeric(
        :molar_air_heat_capacity_j_mol_k,
        molar_heat_capacity,
        :result,
    )
    psychrometric_constant =
        molar_heat_capacity * atmospheric_pressure_pa /
        latent_heat_vaporization_j_mol
    isfinite(psychrometric_constant) || _throw_leaf_penman_numeric(
        :psychrometric_constant_pa_k,
        psychrometric_constant,
        :result,
    )

    if total_water_vapour_conductance_mol_m2_s <= zero(T)
        return LeafPenmanMonteithResult{T}(
            zero(T),
            zero(T),
            psychrometric_constant,
        )
    end

    denominator = saturation_vapour_pressure_slope_pa_k +
                  psychrometric_constant *
                  total_heat_conductance_mol_m2_s /
                  total_water_vapour_conductance_mol_m2_s
    isfinite(denominator) && denominator > zero(T) ||
        _throw_leaf_penman_numeric(:penman_monteith_denominator, denominator, :denominator)

    latent_heat_flux = (
        saturation_vapour_pressure_slope_pa_k * leaf_net_radiation_w_m2 +
        vapour_pressure_deficit_pa *
        total_heat_conductance_mol_m2_s *
        specific_heat *
        molar_mass
    ) / denominator
    isfinite(latent_heat_flux) || _throw_leaf_penman_numeric(
        :latent_heat_flux_w_m2,
        latent_heat_flux,
        :result,
    )
    water_flux = latent_heat_flux / latent_heat_vaporization_j_mol
    isfinite(water_flux) || _throw_leaf_penman_numeric(
        :water_flux_mol_m2_s,
        water_flux,
        :result,
    )

    return LeafPenmanMonteithResult{T}(
        water_flux,
        latent_heat_flux,
        psychrometric_constant,
    )
end

"""
    leaf_penman_monteith(
        atmospheric_pressure_pa,
        saturation_vapour_pressure_slope_pa_k,
        latent_heat_vaporization_j_mol,
        leaf_net_radiation_w_m2,
        vapour_pressure_deficit_pa,
        total_heat_conductance_mol_m2_s,
        total_water_vapour_conductance_mol_m2_s;
        kwargs...,
    )

Evaluate MAESPA's historical `PENMON` equation for one leaf radiation class.

Inputs use Pa, Pa K⁻¹, J mol⁻¹, W m⁻², Pa, mol m⁻² s⁻¹, and mol m⁻² s⁻¹,
respectively. For positive water-vapour conductance, the energy flux is

```text
(slope * RNET + VPD * GH * cp_air * molar_mass_air) /
(slope + gamma * GH / GV)
```

with `gamma = cp_air * molar_mass_air * pressure / latent_heat`. For
`GV <= 0`, the historical equation returns zero water and energy flux while
still reporting `gamma`. Negative fluxes are retained as dew deposition.
Legacy `PSTRANSP` clamps its dry-canopy `ET` result only after calling
`PENMON`, while leaving wet-surface `EV` signed; that caller-specific decision
does not belong in this reusable kernel.
"""
function leaf_penman_monteith(
    atmospheric_pressure_pa::Real,
    saturation_vapour_pressure_slope_pa_k::Real,
    latent_heat_vaporization_j_mol::Real,
    leaf_net_radiation_w_m2::Real,
    vapour_pressure_deficit_pa::Real,
    total_heat_conductance_mol_m2_s::Real,
    total_water_vapour_conductance_mol_m2_s::Real;
    kwargs...,
)
    for (value, name) in (
        (atmospheric_pressure_pa, :atmospheric_pressure_pa),
        (
            saturation_vapour_pressure_slope_pa_k,
            :saturation_vapour_pressure_slope_pa_k,
        ),
        (latent_heat_vaporization_j_mol, :latent_heat_vaporization_j_mol),
        (leaf_net_radiation_w_m2, :leaf_net_radiation_w_m2),
        (vapour_pressure_deficit_pa, :vapour_pressure_deficit_pa),
        (
            total_heat_conductance_mol_m2_s,
            :total_heat_conductance_mol_m2_s,
        ),
        (
            total_water_vapour_conductance_mol_m2_s,
            :total_water_vapour_conductance_mol_m2_s,
        ),
    )
        value isa Bool && _throw_leaf_penman_numeric(name, value, :bool)
    end
    promoted = promote(
        float(atmospheric_pressure_pa),
        float(saturation_vapour_pressure_slope_pa_k),
        float(latent_heat_vaporization_j_mol),
        float(leaf_net_radiation_w_m2),
        float(vapour_pressure_deficit_pa),
        float(total_heat_conductance_mol_m2_s),
        float(total_water_vapour_conductance_mol_m2_s),
    )
    T = typeof(first(promoted))
    T <: AbstractFloat || throw(
        ArgumentError("leaf Penman--Monteith inputs must promote to an AbstractFloat"),
    )
    model = MAESPALeafPenmanMonteith(T; kwargs...)
    _validate_leaf_penman_inputs(promoted...)
    return _leaf_penman_monteith(model, T, promoted...)
end

PlantSimEngine.inputs_(::MAESPALeafPenmanMonteith) = (
    atmospheric_pressure_pa=PlantSimEngine.Required(Real),
    saturation_vapour_pressure_slope_pa_k=PlantSimEngine.Required(Real),
    latent_heat_vaporization_j_mol=PlantSimEngine.Required(Real),
    leaf_net_radiation_w_m2=PlantSimEngine.Required(Real),
    vapour_pressure_deficit_pa=PlantSimEngine.Required(Real),
    total_heat_conductance_mol_m2_s=PlantSimEngine.Required(Real),
    total_water_vapour_conductance_mol_m2_s=PlantSimEngine.Required(Real),
    leaf_penman_monteith_inputs_available=PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(::MAESPALeafPenmanMonteith{T}) where {T} = (
    water_flux_mol_m2_s=zero(T),
    latent_heat_flux_w_m2=zero(T),
    psychrometric_constant_pa_k=zero(T),
    leaf_penman_monteith_available=false,
)

@inline function _reset_leaf_penman_monteith!(status, ::Type{T}) where {T}
    status.water_flux_mol_m2_s = zero(T)
    status.latent_heat_flux_w_m2 = zero(T)
    status.psychrometric_constant_pa_k = zero(T)
    status.leaf_penman_monteith_available = false
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPALeafPenmanMonteith, status, environment, constants, context,
)
    T = typeof(status.water_flux_mol_m2_s)
    _reset_leaf_penman_monteith!(status, T)
    status.leaf_penman_monteith_inputs_available || return nothing

    # PENMON retains signed latent heat: a negative water flux is dew.
    exchange = _leaf_penman_monteith(
        model, T,
        T(status.atmospheric_pressure_pa),
        T(status.saturation_vapour_pressure_slope_pa_k),
        T(status.latent_heat_vaporization_j_mol),
        T(status.leaf_net_radiation_w_m2), T(status.vapour_pressure_deficit_pa),
        T(status.total_heat_conductance_mol_m2_s),
        T(status.total_water_vapour_conductance_mol_m2_s),
    )
    status.water_flux_mol_m2_s = exchange.water_flux_mol_m2_s
    status.latent_heat_flux_w_m2 = exchange.latent_heat_flux_w_m2
    status.psychrometric_constant_pa_k = exchange.psychrometric_constant_pa_k
    status.leaf_penman_monteith_available = true
    return nothing
end
