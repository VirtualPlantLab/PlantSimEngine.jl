"""
    MAESPALeafPhotosynthesis(capacity, analytical[, hydraulics])

Historical MAESPA daylight photosynthesis, including temperature-dependent
capacities and respiration. Only the stomatal response is a separate hard call.
Inputs retain the legacy leaf-area basis and units encoded in their names.
This is not a drop-in PlantBiophysics Fvcb model: its stomatal closure and
historical equations differ. `capacity` and `analytical` hold fixed parameters,
not separately scheduled applications. The optional `hydraulics` parameters
control the historical non-Tuzet Emax constraint inside this kernel. Only
exchange, respiration, hydraulic limitation and availability are published;
temperature-adjusted capacities and biochemical limitations remain local.
"""
struct MAESPALeafPhotosynthesis{C,A,H} <: AbstractStomatal_Photosynthesis_CouplingModel
    capacity::C
    analytical::A
    hydraulics::H
    function MAESPALeafPhotosynthesis(capacity::MAESPAPhotosyntheticCapacityTemperatureResponse,
                                     analytical::MAESPAAnalyticalPhotosynthesis,
                                     hydraulics::MAESPALeafHydraulicStomatalConstraint=
                                         MAESPALeafHydraulicStomatalConstraint(typeof(analytical.electron_transport_curvature)))
        new{typeof(capacity),typeof(analytical),typeof(hydraulics)}(capacity, analytical, hydraulics)
    end
end

PlantSimEngine.variable_contracts_(::MAESPALeafPhotosynthesis) = (
    weighted_soil_water_potential_mpa=EFFECTIVE_SOIL_WATER_POTENTIAL_CONTRACT,
    soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa=LEAF_HYDRAULIC_CONDUCTANCE_CONTRACT,
    maximum_leaf_transpiration_mmol_m2_leaf_s=LEAF_WATER_SUPPLY_CAPACITY_CONTRACT,
)

function PlantSimEngine.inputs_(model::MAESPALeafPhotosynthesis)
    # Capacities are internal results, not links to separately scheduled models.
    external = Base.structdiff(PlantSimEngine.inputs_(model.analytical),
        PlantSimEngine.outputs_(model.capacity))
    T = typeof(model.analytical.electron_transport_curvature)
    return merge(external, Base.structdiff(PlantSimEngine.inputs_(model.capacity),
        (moving_average_air_temperature_c=nothing,)), (
        emax_non_tuzet_constraint_active=PlantSimEngine.Default(false),
        soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa=PlantSimEngine.Default(zero(T)),
        maximum_leaf_transpiration_mmol_m2_leaf_s=PlantSimEngine.Default(zero(T)),
    ))
end
function PlantSimEngine.outputs_(model::MAESPALeafPhotosynthesis)
    z = zero(model.analytical.electron_transport_curvature)
    return (
        net_assimilation_umol_co2_m2_s=z,
        intercellular_co2_umol_mol=z,
        stomatal_conductance_co2_mol_m2_s=z,
        stomatal_conductance_h2o_mol_m2_s=z,
        rd_umol_m2_s=z,
        hydraulic_limitation_applied=false,
        stomatal_photosynthesis_coupling_available=false,
    )
end
PlantSimEngine.environment_inputs_(model::MAESPALeafPhotosynthesis) = merge(
    PlantSimEngine.environment_inputs_(model.analytical),
    (moving_average_air_temperature_c=zero(model.analytical.electron_transport_curvature),))
PlantSimEngine.environment_outputs_(::MAESPALeafPhotosynthesis) = NamedTuple()
PlantSimEngine.dep(model::MAESPALeafPhotosynthesis) = PlantSimEngine.dep(model.analytical)

function PlantSimEngine.run!(model::MAESPALeafPhotosynthesis, status, environment, constants, context)
    T = typeof(status.rd_umol_m2_s)
    status.net_assimilation_umol_co2_m2_s = zero(T)
    status.intercellular_co2_umol_mol = zero(T)
    status.stomatal_conductance_co2_mol_m2_s = zero(T)
    status.stomatal_conductance_h2o_mol_m2_s = zero(T)
    status.rd_umol_m2_s = zero(T)
    status.hydraulic_limitation_applied = false
    status.stomatal_photosynthesis_coupling_available = false
    status.photosynthetic_capacity_inputs_available &&
        status.leaf_radiative_forcing_available && status.astronomical_daylight || return nothing

    # GAMMAFN, KMFN, JMAXTFN, VCMAXTFN, VJMAXWFN and daytime RESP.
    capacity = _photosynthetic_capacity_temperature_response(model.capacity, T,
        T(status.leaf_temperature_c), T(environment.moving_average_air_temperature_c),
        T(status.jmax25_umol_m2_s), T(status.vcmax25_umol_m2_s),
        T(status.rd0_umol_m2_s), T(status.leaf_respiration_temperature_coefficient_c_inverse),
        T(status.weighted_soil_water_potential_mpa), true)
    stomata = _selected_stomatal_response!(status, environment, context)
    result = _stomatal_photosynthesis_from_slopes(
        T, model.analytical.electron_transport_curvature, model.analytical.water_to_co2_conductance_ratio,
        T(status.absorbed_par_umol_m2_s), T(status.surface_co2_umol_mol),
        capacity.gamma_star_umol_mol, capacity.rubisco_michaelis_menten_umol_mol,
        capacity.jmax_umol_m2_s, capacity.vcmax_umol_m2_s, capacity.rd_umol_m2_s,
        T(status.quantum_yield), T(status.stomatal_g0),
        status.second_stomatal_curve ? T(status.stomatal_g20) : zero(T),
        T(status.minimum_stomatal_conductance_mol_co2_m2_s),
        T(stomata.primary_stomatal_response_slope), T(stomata.secondary_stomatal_response_slope),
        status.second_stomatal_curve,
    )
    # Emax uses biochemical intermediates, so it belongs inside this boundary.
    # The scalar energy solver receives the constrained fluxes, not Vcmax or J.
    exchange = if status.emax_non_tuzet_constraint_active
        constrained = _leaf_hydraulic_stomatal_constraint(model.hydraulics, T,
            result.net_assimilation_umol_co2_m2_s, result.stomatal_conductance_co2_mol_m2_s,
            result.rubisco_limited_gross_assimilation_umol_co2_m2_s,
            result.electron_transport_limited_gross_assimilation_umol_co2_m2_s,
            T(environment.vapour_pressure_deficit_pa), T(status.surface_co2_umol_mol),
            capacity.gamma_star_umol_mol, capacity.rubisco_michaelis_menten_umol_mol,
            capacity.vcmax_umol_m2_s, result.electron_transport_rate_umol_electrons_m2_s / T(4),
            capacity.rd_umol_m2_s, T(status.minimum_stomatal_conductance_mol_co2_m2_s),
            T(status.weighted_soil_water_potential_mpa),
            T(status.soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa),
            T(status.maximum_leaf_transpiration_mmol_m2_leaf_s))
        status.hydraulic_limitation_applied = constrained.hydraulic_limitation_applied
        constrained
    else
        result
    end
    status.net_assimilation_umol_co2_m2_s = exchange.net_assimilation_umol_co2_m2_s
    status.intercellular_co2_umol_mol = exchange.intercellular_co2_umol_mol
    status.stomatal_conductance_co2_mol_m2_s = exchange.stomatal_conductance_co2_mol_m2_s
    status.stomatal_conductance_h2o_mol_m2_s = exchange.stomatal_conductance_h2o_mol_m2_s
    status.rd_umol_m2_s = capacity.rd_umol_m2_s
    status.stomatal_photosynthesis_coupling_available = true
    return nothing
end

PlantSimEngine.Authoring.model_metadata(::MAESPALeafPhotosynthesis) = (
    hypothesis="Historical MAESPA temperature responses and analytical FvCB with selectable stomata.",
    reference="MAESPA physiol.f90, PSTRANSP daylight branch",
    maturity=:legacy_reimplementation,
    validation=:legacy_kernel_regressions,
)
