PlantSimEngine.@process "daily_respiration_scene_aggregation" verbose = false

"""
Daily respiration totals grouped by species and across the Scene.

Every row supplied to [`daily_respiration_scene_aggregation`](@ref) represents
one physical target tree. `target_weight` is the number of legacy target slots
represented by that row; it is applied only to the explicitly named
`weighted_target_*` outputs. The `physical_tree_*` outputs count every physical
tree once. The maintenance input must be the single already-assembled
whole-plant daily amount; leaf and structural maintenance must not be supplied
as separate rows. No output is divided by plot, crown, leaf, or soil area.

Maintenance and structural-growth respiration remain separate daily amounts.
The `*_total_*` outputs are their explicit sum and are available only when both
channels are available for the same civil day. Structural growth is exposed
only on the maintenance accumulator's end-of-day publication pulse; a held
daily growth status can therefore never be counted once per subdaily step.
"""
struct DailyRespirationSceneAggregationResult{T<:AbstractFloat}
    physical_tree_maintenance_respiration_by_species_mol_co2_day::Vector{T}
    weighted_target_maintenance_respiration_by_species_mol_co2_day::Vector{T}
    physical_tree_structural_growth_respiration_by_species_mol_co2_day::Vector{T}
    weighted_target_structural_growth_respiration_by_species_mol_co2_day::Vector{T}
    physical_tree_total_respiration_by_species_mol_co2_day::Vector{T}
    weighted_target_total_respiration_by_species_mol_co2_day::Vector{T}
    physical_tree_maintenance_respiration_scene_mol_co2_day::T
    weighted_target_maintenance_respiration_scene_mol_co2_day::T
    physical_tree_structural_growth_respiration_scene_mol_co2_day::T
    weighted_target_structural_growth_respiration_scene_mol_co2_day::T
    physical_tree_total_respiration_scene_mol_co2_day::T
    weighted_target_total_respiration_scene_mol_co2_day::T
    daily_respiration_date50_by_species::Vector{Int}
    daily_respiration_scene_date50::Int
    daily_maintenance_respiration_available_by_species::Vector{Bool}
    structural_growth_respiration_available_by_species::Vector{Bool}
    daily_total_respiration_available_by_species::Vector{Bool}
    daily_maintenance_respiration_scene_available::Bool
    structural_growth_respiration_scene_available::Bool
    daily_total_respiration_scene_available::Bool
    daily_respiration_dates_consistent::Bool
    physical_tree_count_by_species::Vector{Int}
    weighted_target_count_by_species::Vector{Int}
    physical_tree_count::Int
    weighted_target_count::Int
    daily_respiration_scene_aggregation_available::Bool
end

@noinline function _throw_daily_respiration_scene_aggregation(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :type
        throw(
            ArgumentError(
                "the daily-respiration aggregation numeric type must be concrete",
            ),
        )
    elseif reason === :vector
        throw(ArgumentError("$label must be an AbstractVector"))
    elseif reason === :integer
        throw(ArgumentError("$label values must be integers, not Bool"))
    elseif reason === :int_range
        throw(ArgumentError("$label values must be representable as Int"))
    elseif reason === :positive
        throw(DomainError(value, "$label values must be positive"))
    elseif reason === :species
        throw(DomainError(value, "$label values must identify a configured species"))
    elseif reason === :duplicate_tree
        throw(ArgumentError("physical tree_id $value occurs more than once"))
    elseif reason === :bool
        throw(ArgumentError("$label values must be Bool"))
    elseif reason === :real
        throw(ArgumentError("$label values must be real numbers, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label values and derived sums must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label values must be non-negative"))
    elseif reason === :float_output
        throw(
            ArgumentError(
                "$label and all daily-respiration floating outputs must " *
                "share one concrete AbstractFloat type",
            ),
        )
    elseif reason === :int_output
        throw(ArgumentError("$label must use Int output carriers"))
    elseif reason === :bool_output
        throw(ArgumentError("$label must use Bool output carriers"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _daily_respiration_scene_vector(values, name::Symbol)
    values isa AbstractVector ||
        _throw_daily_respiration_scene_aggregation(name, values, :vector)
    Base.require_one_based_indexing(values)
    return values
end

function _daily_respiration_scene_matching_lengths(reference, arrays)
    count = length(reference)
    for (values, name) in arrays
        length(values) == count || throw(
            DimensionMismatch("$(String(name)) must contain $count values"),
        )
    end
    return count
end

@inline function _daily_respiration_scene_int(value, name::Symbol)
    value isa Integer && !(value isa Bool) ||
        _throw_daily_respiration_scene_aggregation(name, value, :integer)
    converted = try
        Int(value)
    catch exception
        exception isa InexactError || exception isa OverflowError || rethrow()
        _throw_daily_respiration_scene_aggregation(name, value, :int_range)
    end
    return converted
end

@inline function _daily_respiration_scene_positive_int(value, name::Symbol)
    converted = _daily_respiration_scene_int(value, name)
    converted > 0 ||
        _throw_daily_respiration_scene_aggregation(name, converted, :positive)
    return converted
end

@inline function _daily_respiration_scene_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real && !(value isa Bool) ||
        _throw_daily_respiration_scene_aggregation(name, value, :real)
    converted = try
        convert(T, value)
    catch exception
        exception isa InexactError || exception isa OverflowError || rethrow()
        _throw_daily_respiration_scene_aggregation(name, value, :finite)
    end
    isfinite(converted) ||
        _throw_daily_respiration_scene_aggregation(name, converted, :finite)
    converted >= zero(T) ||
        _throw_daily_respiration_scene_aggregation(name, converted, :nonnegative)
    return converted
end

@inline function _daily_respiration_scene_bool(value, name::Symbol)
    value isa Bool ||
        _throw_daily_respiration_scene_aggregation(name, value, :bool)
    return value
end

@inline function _daily_respiration_scene_add(
    left::T,
    right::T,
    name::Symbol,
) where {T<:AbstractFloat}
    total = left + right
    isfinite(total) ||
        _throw_daily_respiration_scene_aggregation(name, total, :finite)
    return total
end

@inline function _daily_respiration_scene_weighted_value(
    ::Type{T},
    value::T,
    weight::Int,
    name::Symbol,
) where {T<:AbstractFloat}
    converted_weight = convert(T, weight)
    isfinite(converted_weight) ||
        _throw_daily_respiration_scene_aggregation(
            :target_weights,
            converted_weight,
            :finite,
        )
    weighted = value * converted_weight
    isfinite(weighted) ||
        _throw_daily_respiration_scene_aggregation(name, weighted, :finite)
    return weighted
end

@inline function _daily_respiration_scene_checked_count_add(
    left::Int,
    right::Int,
    name::Symbol,
)
    return try
        Base.Checked.checked_add(left, right)
    catch exception
        exception isa OverflowError || rethrow()
        throw(ArgumentError("$(String(name)) exceeds the Int range"))
    end
end

function _daily_respiration_scene_sum_species(
    values::Vector{T},
    name::Symbol,
) where {T<:AbstractFloat}
    total = zero(T)
    for species in eachindex(values)
        total = _daily_respiration_scene_add(total, values[species], name)
    end
    return total
end

"""
    daily_respiration_scene_aggregation(
        T,
        tree_ids,
        species_ids,
        target_weights,
        daily_maintenance_respiration_mol_co2_tree_day,
        daily_maintenance_respiration_available,
        daily_maintenance_respiration_date50,
        structural_growth_respiration_mol_co2_tree_day,
        structural_growth_respiration_available,
        structural_growth_respiration_date50;
        species_count,
    )

Aggregate one row per distinct physical target tree. Rows are validated and
then summed in ascending `tree_id` order, so collection order cannot change
floating-point addition order. A duplicate `tree_id` is a configuration error:
legacy duplicate target slots belong in the strictly positive integer
`target_weights` vector instead of duplicated rows.

Each channel is atomic by species. If any tree of a species has an unavailable
maintenance value, the end-of-day publication pulse is absent and both growth
and total stay unavailable without inspecting their masked carriers. If the
pulse is present, maintenance and growth dates must be positive, identical
within the species, and equal across channels. Species with no target trees are
valid zero columns. Scene sums are published only when every present species is
available, with one common civil date. Thus a Scene output is never a silent
partial or stale sum.

Maintenance and structural growth are both already daily amounts in mol CO2
tree-1 day-1. They are added only in the explicitly named total channel. This
function performs no area normalization.

`T` is normally obtained from the PlantSimEngine floating output carriers, so
global `type_promotion` controls all conversions and sums.
"""
function daily_respiration_scene_aggregation(
    ::Type{T},
    tree_ids,
    species_ids,
    target_weights,
    daily_maintenance_respiration_mol_co2_tree_day,
    daily_maintenance_respiration_available,
    daily_maintenance_respiration_date50,
    structural_growth_respiration_mol_co2_tree_day,
    structural_growth_respiration_available,
    structural_growth_respiration_date50;
    species_count,
    _growth_channel::Symbol=:structural,
) where {T<:AbstractFloat}
    isconcretetype(T) ||
        _throw_daily_respiration_scene_aggregation(:numeric_type, T, :type)
    species_number = _daily_respiration_scene_positive_int(
        species_count,
        :species_count,
    )
    # The whole-plant adapter reuses this neutral two-channel summation kernel.
    # Keep diagnostics in the public vocabulary of the calling adapter while
    # retaining the historical structural result schema here.
    _growth_channel in (:structural, :whole_plant) || throw(
        ArgumentError(
            "internal growth channel must be :structural or :whole_plant",
        ),
    )
    if _growth_channel === :structural
        growth_amount_name =
            :structural_growth_respiration_mol_co2_tree_day
        growth_available_name = :structural_growth_respiration_available
        growth_date_name = :structural_growth_respiration_date50
        physical_growth_species_name =
            :physical_tree_structural_growth_respiration_by_species_mol_co2_day
        weighted_growth_species_name =
            :weighted_target_structural_growth_respiration_by_species_mol_co2_day
        physical_growth_scene_name =
            :physical_tree_structural_growth_respiration_scene_mol_co2_day
        weighted_growth_scene_name =
            :weighted_target_structural_growth_respiration_scene_mol_co2_day
    else
        growth_amount_name =
            :whole_plant_growth_respiration_mol_co2_tree_day
        growth_available_name = :whole_plant_growth_respiration_available
        growth_date_name = :whole_plant_growth_respiration_date50
        physical_growth_species_name =
            :physical_tree_whole_plant_growth_respiration_by_species_mol_co2_day
        weighted_growth_species_name =
            :weighted_target_whole_plant_growth_respiration_by_species_mol_co2_day
        physical_growth_scene_name =
            :physical_tree_whole_plant_growth_respiration_scene_mol_co2_day
        weighted_growth_scene_name =
            :weighted_target_whole_plant_growth_respiration_scene_mol_co2_day
    end

    ids = _daily_respiration_scene_vector(tree_ids, :tree_ids)
    species_values =
        _daily_respiration_scene_vector(species_ids, :species_ids)
    weights = _daily_respiration_scene_vector(target_weights, :target_weights)
    maintenance_amounts = _daily_respiration_scene_vector(
        daily_maintenance_respiration_mol_co2_tree_day,
        :daily_maintenance_respiration_mol_co2_tree_day,
    )
    maintenance_flags = _daily_respiration_scene_vector(
        daily_maintenance_respiration_available,
        :daily_maintenance_respiration_available,
    )
    maintenance_dates = _daily_respiration_scene_vector(
        daily_maintenance_respiration_date50,
        :daily_maintenance_respiration_date50,
    )
    growth_amounts = _daily_respiration_scene_vector(
        structural_growth_respiration_mol_co2_tree_day,
        growth_amount_name,
    )
    growth_flags = _daily_respiration_scene_vector(
        structural_growth_respiration_available,
        growth_available_name,
    )
    growth_dates = _daily_respiration_scene_vector(
        structural_growth_respiration_date50,
        growth_date_name,
    )
    tree_count = _daily_respiration_scene_matching_lengths(
        ids,
        (
            (species_values, :species_ids),
            (weights, :target_weights),
            (
                maintenance_amounts,
                :daily_maintenance_respiration_mol_co2_tree_day,
            ),
            (
                maintenance_flags,
                :daily_maintenance_respiration_available,
            ),
            (maintenance_dates, :daily_maintenance_respiration_date50),
            (
                growth_amounts,
                growth_amount_name,
            ),
            (
                growth_flags,
                growth_available_name,
            ),
            (
                growth_dates,
                growth_date_name,
            ),
        ),
    )

    canonical_tree_ids = Vector{Int}(undef, tree_count)
    canonical_species_ids = Vector{Int}(undef, tree_count)
    canonical_target_weights = Vector{Int}(undef, tree_count)
    canonical_maintenance_flags = Vector{Bool}(undef, tree_count)
    canonical_growth_flags = Vector{Bool}(undef, tree_count)
    seen_tree_ids = Set{Int}()
    for position in eachindex(ids)
        tree_id = _daily_respiration_scene_positive_int(
            ids[position],
            :tree_ids,
        )
        tree_id in seen_tree_ids &&
            _throw_daily_respiration_scene_aggregation(
                :tree_ids,
                tree_id,
                :duplicate_tree,
            )
        push!(seen_tree_ids, tree_id)
        species_id = _daily_respiration_scene_int(
            species_values[position],
            :species_ids,
        )
        1 <= species_id <= species_number ||
            _throw_daily_respiration_scene_aggregation(
                :species_ids,
                species_id,
                :species,
            )
        canonical_tree_ids[position] = tree_id
        canonical_species_ids[position] = species_id
        canonical_target_weights[position] =
            _daily_respiration_scene_positive_int(
                weights[position],
                :target_weights,
            )
        canonical_maintenance_flags[position] =
            _daily_respiration_scene_bool(
                maintenance_flags[position],
                :daily_maintenance_respiration_available,
            )
        canonical_growth_flags[position] = _daily_respiration_scene_bool(
            growth_flags[position],
            growth_available_name,
        )
    end

    physical_maintenance = zeros(T, species_number)
    weighted_maintenance = zeros(T, species_number)
    physical_growth = zeros(T, species_number)
    weighted_growth = zeros(T, species_number)
    physical_total = zeros(T, species_number)
    weighted_total = zeros(T, species_number)
    physical_counts = zeros(Int, species_number)
    weighted_counts = zeros(Int, species_number)
    maintenance_dates_by_species = zeros(Int, species_number)
    growth_dates_by_species = zeros(Int, species_number)
    maintenance_available_by_species = fill(true, species_number)
    growth_available_by_species = fill(true, species_number)
    maintenance_dates_consistent_by_species = fill(true, species_number)
    growth_dates_consistent_by_species = fill(true, species_number)

    canonical_order = sortperm(canonical_tree_ids)
    for position in canonical_order
        species = canonical_species_ids[position]
        weight = canonical_target_weights[position]
        physical_counts[species] = _daily_respiration_scene_checked_count_add(
            physical_counts[species],
            1,
            :physical_tree_count_by_species,
        )
        weighted_counts[species] = _daily_respiration_scene_checked_count_add(
            weighted_counts[species],
            weight,
            :weighted_target_count_by_species,
        )

        if canonical_maintenance_flags[position]
            amount = _daily_respiration_scene_float(
                T,
                maintenance_amounts[position],
                :daily_maintenance_respiration_mol_co2_tree_day,
            )
            date50 = _daily_respiration_scene_positive_int(
                maintenance_dates[position],
                :daily_maintenance_respiration_date50,
            )
            current_date = maintenance_dates_by_species[species]
            if iszero(current_date)
                maintenance_dates_by_species[species] = date50
            elseif current_date != date50
                maintenance_dates_consistent_by_species[species] = false
            end
            physical_maintenance[species] =
                _daily_respiration_scene_add(
                    physical_maintenance[species],
                    amount,
                    :physical_tree_maintenance_respiration_by_species_mol_co2_day,
                )
            weighted_amount = _daily_respiration_scene_weighted_value(
                T,
                amount,
                weight,
                :weighted_target_maintenance_respiration_by_species_mol_co2_day,
            )
            weighted_maintenance[species] =
                _daily_respiration_scene_add(
                    weighted_maintenance[species],
                    weighted_amount,
                    :weighted_target_maintenance_respiration_by_species_mol_co2_day,
                )
        else
            maintenance_available_by_species[species] = false
        end

        # The maintenance flag is the end-of-day publication pulse. A held
        # growth status behind a false pulse is intentionally not inspected.
        if canonical_maintenance_flags[position] &&
           canonical_growth_flags[position]
            amount = _daily_respiration_scene_float(
                T,
                growth_amounts[position],
                growth_amount_name,
            )
            date50 = _daily_respiration_scene_positive_int(
                growth_dates[position],
                growth_date_name,
            )
            current_date = growth_dates_by_species[species]
            if iszero(current_date)
                growth_dates_by_species[species] = date50
            elseif current_date != date50
                growth_dates_consistent_by_species[species] = false
            end
            physical_growth[species] = _daily_respiration_scene_add(
                physical_growth[species],
                amount,
                physical_growth_species_name,
            )
            weighted_amount = _daily_respiration_scene_weighted_value(
                T,
                amount,
                weight,
                weighted_growth_species_name,
            )
            weighted_growth[species] = _daily_respiration_scene_add(
                    weighted_growth[species],
                    weighted_amount,
                    weighted_growth_species_name,
            )
        else
            growth_available_by_species[species] = false
        end
    end

    total_available_by_species = fill(true, species_number)
    for species in 1:species_number
        present = physical_counts[species] > 0
        maintenance_available =
            maintenance_available_by_species[species] &&
            maintenance_dates_consistent_by_species[species]
        growth_available = maintenance_available &&
                           growth_available_by_species[species] &&
                           growth_dates_consistent_by_species[species] &&
                           growth_dates_by_species[species] ==
                           maintenance_dates_by_species[species]
        maintenance_available_by_species[species] = maintenance_available
        growth_available_by_species[species] = growth_available
        if present && !maintenance_available
            physical_maintenance[species] = zero(T)
            weighted_maintenance[species] = zero(T)
            maintenance_dates_by_species[species] = 0
        end
        if present && !growth_available
            physical_growth[species] = zero(T)
            weighted_growth[species] = zero(T)
            growth_dates_by_species[species] = 0
        end
        total_available = maintenance_available && growth_available
        total_available_by_species[species] = total_available
        if present && total_available
            physical_total[species] = _daily_respiration_scene_add(
                physical_maintenance[species],
                physical_growth[species],
                :physical_tree_total_respiration_by_species_mol_co2_day,
            )
            weighted_total[species] = _daily_respiration_scene_add(
                weighted_maintenance[species],
                weighted_growth[species],
                :weighted_target_total_respiration_by_species_mol_co2_day,
            )
        end
    end

    weighted_target_count = 0
    for species in 1:species_number
        weighted_target_count = _daily_respiration_scene_checked_count_add(
            weighted_target_count,
            weighted_counts[species],
            :weighted_target_count,
        )
    end

    present_species = findall(>(0), physical_counts)
    maintenance_scene_available = !isempty(present_species) && all(
        species -> maintenance_available_by_species[species],
        present_species,
    )
    scene_date = 0
    maintenance_dates_consistent = maintenance_scene_available
    if maintenance_scene_available
        scene_date = maintenance_dates_by_species[first(present_species)]
        for species in Iterators.drop(present_species, 1)
            if maintenance_dates_by_species[species] != scene_date
                maintenance_dates_consistent = false
                break
            end
        end
    end
    maintenance_scene_available &= maintenance_dates_consistent
    maintenance_scene_available || (scene_date = 0)
    growth_scene_available = maintenance_scene_available && all(
        species -> growth_available_by_species[species],
        present_species,
    )
    dates_consistent = maintenance_scene_available && growth_scene_available
    total_scene_available =
        maintenance_scene_available && growth_scene_available

    physical_maintenance_scene = if maintenance_scene_available
        _daily_respiration_scene_sum_species(
            physical_maintenance,
            :physical_tree_maintenance_respiration_scene_mol_co2_day,
        )
    else
        zero(T)
    end
    weighted_maintenance_scene = if maintenance_scene_available
        _daily_respiration_scene_sum_species(
            weighted_maintenance,
            :weighted_target_maintenance_respiration_scene_mol_co2_day,
        )
    else
        zero(T)
    end
    physical_growth_scene = if growth_scene_available
        _daily_respiration_scene_sum_species(
            physical_growth,
            physical_growth_scene_name,
        )
    else
        zero(T)
    end
    weighted_growth_scene = if growth_scene_available
        _daily_respiration_scene_sum_species(
            weighted_growth,
            weighted_growth_scene_name,
        )
    else
        zero(T)
    end
    physical_total_scene = if total_scene_available
        _daily_respiration_scene_sum_species(
            physical_total,
            :physical_tree_total_respiration_scene_mol_co2_day,
        )
    else
        zero(T)
    end
    weighted_total_scene = if total_scene_available
        _daily_respiration_scene_sum_species(
            weighted_total,
            :weighted_target_total_respiration_scene_mol_co2_day,
        )
    else
        zero(T)
    end

    return DailyRespirationSceneAggregationResult{T}(
        physical_maintenance,
        weighted_maintenance,
        physical_growth,
        weighted_growth,
        physical_total,
        weighted_total,
        physical_maintenance_scene,
        weighted_maintenance_scene,
        physical_growth_scene,
        weighted_growth_scene,
        physical_total_scene,
        weighted_total_scene,
        maintenance_dates_by_species,
        scene_date,
        maintenance_available_by_species,
        growth_available_by_species,
        total_available_by_species,
        maintenance_scene_available,
        growth_scene_available,
        total_scene_available,
        dates_consistent,
        physical_counts,
        weighted_counts,
        tree_count,
        weighted_target_count,
        total_scene_available,
    )
end

"""
    MAESPADailyRespirationSceneAggregation(T=Float64; species_count)

PlantSimEngine adapter for [`daily_respiration_scene_aggregation`](@ref).

The nine collection inputs must use matching `Many(...)` selectors over the
distinct physical target Plants. The explicit `tree_ids` join key makes their
incidental selector order irrelevant. The output carrier element type selects
the calculation type, including after a global `type_promotion` mapping.

Disabling `daily_respiration_scene_aggregation_inputs_available` publishes a
fresh all-zero unavailable snapshot without inspecting the collections. An
invalid active call leaves the last accepted output snapshot unchanged.
"""
struct MAESPADailyRespirationSceneAggregation{T<:AbstractFloat} <:
       AbstractDaily_Respiration_Scene_AggregationModel
    species_count::Int
    zero_value::T
end

function MAESPADailyRespirationSceneAggregation(
    ::Type{T}=Float64;
    species_count,
) where {T<:AbstractFloat}
    isconcretetype(T) ||
        _throw_daily_respiration_scene_aggregation(:numeric_type, T, :type)
    return MAESPADailyRespirationSceneAggregation{T}(
        _daily_respiration_scene_positive_int(
            species_count,
            :species_count,
        ),
        zero(T),
    )
end

PlantSimEngine.inputs_(::MAESPADailyRespirationSceneAggregation) = (
    tree_ids=PlantSimEngine.Required(AbstractVector),
    species_ids=PlantSimEngine.Required(AbstractVector),
    target_weights=PlantSimEngine.Required(AbstractVector),
    daily_maintenance_respiration_mol_co2_tree_day=
        PlantSimEngine.Required(AbstractVector),
    daily_maintenance_respiration_available=
        PlantSimEngine.Required(AbstractVector),
    daily_maintenance_respiration_date50=
        PlantSimEngine.Required(AbstractVector),
    structural_growth_respiration_mol_co2_tree_day=
        PlantSimEngine.Required(AbstractVector),
    structural_growth_respiration_available=
        PlantSimEngine.Required(AbstractVector),
    structural_growth_respiration_date50=
        PlantSimEngine.Required(AbstractVector),
    daily_respiration_scene_aggregation_inputs_available=
        PlantSimEngine.Default(true),
)

function PlantSimEngine.outputs_(
    model::MAESPADailyRespirationSceneAggregation{T},
) where {T}
    n = model.species_count
    return (
        physical_tree_maintenance_respiration_by_species_mol_co2_day=zeros(T, n),
        weighted_target_maintenance_respiration_by_species_mol_co2_day=zeros(T, n),
        physical_tree_structural_growth_respiration_by_species_mol_co2_day=zeros(T, n),
        weighted_target_structural_growth_respiration_by_species_mol_co2_day=zeros(T, n),
        physical_tree_total_respiration_by_species_mol_co2_day=zeros(T, n),
        weighted_target_total_respiration_by_species_mol_co2_day=zeros(T, n),
        physical_tree_maintenance_respiration_scene_mol_co2_day=zero(T),
        weighted_target_maintenance_respiration_scene_mol_co2_day=zero(T),
        physical_tree_structural_growth_respiration_scene_mol_co2_day=zero(T),
        weighted_target_structural_growth_respiration_scene_mol_co2_day=zero(T),
        physical_tree_total_respiration_scene_mol_co2_day=zero(T),
        weighted_target_total_respiration_scene_mol_co2_day=zero(T),
        daily_respiration_date50_by_species=zeros(Int, n),
        daily_respiration_scene_date50=0,
        daily_maintenance_respiration_available_by_species=fill(false, n),
        structural_growth_respiration_available_by_species=fill(false, n),
        daily_total_respiration_available_by_species=fill(false, n),
        daily_maintenance_respiration_scene_available=false,
        structural_growth_respiration_scene_available=false,
        daily_total_respiration_scene_available=false,
        daily_respiration_dates_consistent=false,
        physical_tree_count_by_species=zeros(Int, n),
        weighted_target_count_by_species=zeros(Int, n),
        physical_tree_count=0,
        weighted_target_count=0,
        daily_respiration_scene_aggregation_available=false,
    )
end

const _DAILY_RESPIRATION_SCENE_FLOAT_VECTOR_OUTPUTS = (
    :physical_tree_maintenance_respiration_by_species_mol_co2_day,
    :weighted_target_maintenance_respiration_by_species_mol_co2_day,
    :physical_tree_structural_growth_respiration_by_species_mol_co2_day,
    :weighted_target_structural_growth_respiration_by_species_mol_co2_day,
    :physical_tree_total_respiration_by_species_mol_co2_day,
    :weighted_target_total_respiration_by_species_mol_co2_day,
)

const _DAILY_RESPIRATION_SCENE_FLOAT_SCALAR_OUTPUTS = (
    :physical_tree_maintenance_respiration_scene_mol_co2_day,
    :weighted_target_maintenance_respiration_scene_mol_co2_day,
    :physical_tree_structural_growth_respiration_scene_mol_co2_day,
    :weighted_target_structural_growth_respiration_scene_mol_co2_day,
    :physical_tree_total_respiration_scene_mol_co2_day,
    :weighted_target_total_respiration_scene_mol_co2_day,
)

const _DAILY_RESPIRATION_SCENE_BOOL_VECTOR_OUTPUTS = (
    :daily_maintenance_respiration_available_by_species,
    :structural_growth_respiration_available_by_species,
    :daily_total_respiration_available_by_species,
)

const _DAILY_RESPIRATION_SCENE_BOOL_SCALAR_OUTPUTS = (
    :daily_maintenance_respiration_scene_available,
    :structural_growth_respiration_scene_available,
    :daily_total_respiration_scene_available,
    :daily_respiration_dates_consistent,
    :daily_respiration_scene_aggregation_available,
)

const _DAILY_RESPIRATION_SCENE_INT_VECTOR_OUTPUTS = (
    :daily_respiration_date50_by_species,
    :physical_tree_count_by_species,
    :weighted_target_count_by_species,
)

const _DAILY_RESPIRATION_SCENE_INT_SCALAR_OUTPUTS = (
    :daily_respiration_scene_date50,
    :physical_tree_count,
    :weighted_target_count,
)

function _daily_respiration_scene_output_type(model, status)
    first_name = first(_DAILY_RESPIRATION_SCENE_FLOAT_VECTOR_OUTPUTS)
    first_values = getproperty(status, first_name)
    first_values isa AbstractVector ||
        _throw_daily_respiration_scene_aggregation(
            first_name,
            first_values,
            :float_output,
        )
    Base.require_one_based_indexing(first_values)
    T = eltype(first_values)
    T <: AbstractFloat && isconcretetype(T) ||
        _throw_daily_respiration_scene_aggregation(
            first_name,
            first_values,
            :float_output,
        )
    for name in _DAILY_RESPIRATION_SCENE_FLOAT_VECTOR_OUTPUTS
        values = getproperty(status, name)
        values isa AbstractVector ||
            _throw_daily_respiration_scene_aggregation(name, values, :float_output)
        Base.require_one_based_indexing(values)
        eltype(values) === T ||
            _throw_daily_respiration_scene_aggregation(name, values, :float_output)
        length(values) == model.species_count || throw(
            DimensionMismatch(
                "$(String(name)) must contain $(model.species_count) values",
            ),
        )
    end
    for name in _DAILY_RESPIRATION_SCENE_FLOAT_SCALAR_OUTPUTS
        value = getproperty(status, name)
        typeof(value) === T ||
            _throw_daily_respiration_scene_aggregation(name, value, :float_output)
    end
    for name in _DAILY_RESPIRATION_SCENE_INT_VECTOR_OUTPUTS
        values = getproperty(status, name)
        values isa AbstractVector ||
            _throw_daily_respiration_scene_aggregation(name, values, :int_output)
        Base.require_one_based_indexing(values)
        eltype(values) === Int ||
            _throw_daily_respiration_scene_aggregation(name, values, :int_output)
        length(values) == model.species_count || throw(
            DimensionMismatch(
                "$(String(name)) must contain $(model.species_count) values",
            ),
        )
    end
    for name in _DAILY_RESPIRATION_SCENE_INT_SCALAR_OUTPUTS
        value = getproperty(status, name)
        typeof(value) === Int ||
            _throw_daily_respiration_scene_aggregation(name, value, :int_output)
    end
    for name in _DAILY_RESPIRATION_SCENE_BOOL_VECTOR_OUTPUTS
        values = getproperty(status, name)
        values isa AbstractVector ||
            _throw_daily_respiration_scene_aggregation(name, values, :bool_output)
        Base.require_one_based_indexing(values)
        eltype(values) === Bool ||
            _throw_daily_respiration_scene_aggregation(name, values, :bool_output)
        length(values) == model.species_count || throw(
            DimensionMismatch(
                "$(String(name)) must contain $(model.species_count) values",
            ),
        )
    end
    for name in _DAILY_RESPIRATION_SCENE_BOOL_SCALAR_OUTPUTS
        value = getproperty(status, name)
        value isa Bool ||
            _throw_daily_respiration_scene_aggregation(name, value, :bool_output)
    end
    return T
end

function _reset_daily_respiration_scene_aggregation!(
    model,
    status,
    ::Type{T},
) where {T}
    n = model.species_count
    for name in _DAILY_RESPIRATION_SCENE_FLOAT_VECTOR_OUTPUTS
        setproperty!(status, name, zeros(T, n))
    end
    for name in _DAILY_RESPIRATION_SCENE_FLOAT_SCALAR_OUTPUTS
        setproperty!(status, name, zero(T))
    end
    for name in _DAILY_RESPIRATION_SCENE_INT_VECTOR_OUTPUTS
        setproperty!(status, name, zeros(Int, n))
    end
    for name in _DAILY_RESPIRATION_SCENE_INT_SCALAR_OUTPUTS
        setproperty!(status, name, 0)
    end
    for name in _DAILY_RESPIRATION_SCENE_BOOL_VECTOR_OUTPUTS
        setproperty!(status, name, fill(false, n))
    end
    for name in _DAILY_RESPIRATION_SCENE_BOOL_SCALAR_OUTPUTS
        setproperty!(status, name, false)
    end
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPADailyRespirationSceneAggregation,
    status,
    environment,
    constants,
    context,
)
    T = _daily_respiration_scene_output_type(model, status)
    inputs_available =
        status.daily_respiration_scene_aggregation_inputs_available
    inputs_available isa Bool || throw(
        ArgumentError(
            "daily_respiration_scene_aggregation_inputs_available must be Bool",
        ),
    )
    if !inputs_available
        _reset_daily_respiration_scene_aggregation!(model, status, T)
        return nothing
    end

    result = daily_respiration_scene_aggregation(
        T,
        status.tree_ids,
        status.species_ids,
        status.target_weights,
        status.daily_maintenance_respiration_mol_co2_tree_day,
        status.daily_maintenance_respiration_available,
        status.daily_maintenance_respiration_date50,
        status.structural_growth_respiration_mol_co2_tree_day,
        status.structural_growth_respiration_available,
        status.structural_growth_respiration_date50;
        species_count=model.species_count,
    )
    for name in fieldnames(typeof(result))
        setproperty!(status, name, getproperty(result, name))
    end
    return nothing
end
