PlantSimEngine.@process "simulated_soil_longwave_forcing" verbose = false

"""
    simulated_soil_longwave_forcing(T, point_count, air_temperature_c,
                                    previous_soil_surface_temperature_k,
                                    incident_thermal_w_m2, soil_reflectance;
                                    kwargs...)

Prepare the longwave carriers for the `SIMTSOIL=1` mono-pass branch. The soil
temperature is the already accepted historical `TSOILSURFACE` state in kelvins.
The implementation converts it once to the Celsius boundary expected by
[`mono_pass_longwave_forcing`](@ref), which performs the shared validation and
carrier construction before converting it back exactly once.
"""
function simulated_soil_longwave_forcing(
    ::Type{T},
    point_count::Integer,
    air_temperature_c,
    previous_soil_surface_temperature_k,
    incident_thermal_w_m2,
    soil_reflectance;
    thermal_waveband_index::Integer=3,
    kelvin_offset=273.15,
) where {T<:AbstractFloat}
    offset = _mono_pass_longwave_nonnegative(
        _mono_pass_longwave_float(T, kelvin_offset, :kelvin_offset),
        :kelvin_offset,
    )
    offset > zero(T) || throw(
        DomainError(offset, "kelvin_offset must be positive"),
    )
    temperature_k = _mono_pass_longwave_nonnegative(
        _mono_pass_longwave_float(
            T,
            previous_soil_surface_temperature_k,
            :previous_soil_surface_temperature_k,
        ),
        :previous_soil_surface_temperature_k,
    )
    return mono_pass_longwave_forcing(
        T,
        point_count,
        air_temperature_c,
        temperature_k - offset,
        incident_thermal_w_m2,
        soil_reflectance;
        thermal_waveband_index,
        kelvin_offset=offset,
    )
end

"""
PlantSimEngine adapter for one simulated-soil longwave pass.

`source_previous_soil_surface_temperature_k` is intended to be bound with
`PreviousTimeStep` to [`MAESPASoilSurfaceTemperatureState`](@ref). When any
availability gate is false, accepted numeric carriers are preserved and only
`simulated_soil_longwave_forcing_available` is cleared. Numeric inputs are not
inspected on that path.
"""
struct MAESPASimulatedSoilLongwaveForcing{T<:AbstractFloat} <:
       AbstractSimulated_Soil_Longwave_ForcingModel
    point_count::Int
    thermal_waveband_index::Int
    kelvin_offset::T
end

function MAESPASimulatedSoilLongwaveForcing(
    ::Type{T}=Float64,
    point_count::Integer=1;
    thermal_waveband_index::Integer=3,
    kelvin_offset=273.15,
) where {T<:AbstractFloat}
    shared = MAESPAMonoPassLongwaveForcing(
        T,
        point_count;
        thermal_waveband_index,
        kelvin_offset,
    )
    return MAESPASimulatedSoilLongwaveForcing{T}(
        shared.point_count,
        shared.thermal_waveband_index,
        shared.kelvin_offset,
    )
end

PlantSimEngine.inputs_(::MAESPASimulatedSoilLongwaveForcing) = (
    source_meteorology_available=PlantSimEngine.Required(Bool),
    source_equivalent_canopy_available=PlantSimEngine.Required(Bool),
    source_previous_soil_surface_temperature_available=PlantSimEngine.Required(Bool),
    source_air_temperature_c=PlantSimEngine.Required(Real),
    source_previous_soil_surface_temperature_k=PlantSimEngine.Required(Real),
    source_incident_thermal_w_m2=PlantSimEngine.Required(Real),
    source_soil_reflectance=PlantSimEngine.Required(AbstractVector),
)

PlantSimEngine.variable_contracts_(::MAESPASimulatedSoilLongwaveForcing) = (
    source_equivalent_canopy_available=EQUIVALENT_CANOPY_AVAILABLE_CONTRACT,
    simulated_soil_longwave_forcing_available=LONGWAVE_FORCING_AVAILABLE_CONTRACT,
)

PlantSimEngine.outputs_(
    model::MAESPASimulatedSoilLongwaveForcing{T},
) where {T} = (
    incident_thermal_w_m2=zero(T),
    canopy_temperature_c=zero(T),
    leaf_temperature_c=zeros(T, model.point_count),
    soil_surface_temperature_k=zero(T),
    soil_reflectance_thermal=zero(T),
    simulated_soil_longwave_forcing_available=false,
)

function PlantSimEngine.run!(
    model::MAESPASimulatedSoilLongwaveForcing,
    status,
    environment,
    constants,
    context,
)
    for name in (
        :source_meteorology_available,
        :source_equivalent_canopy_available,
        :source_previous_soil_surface_temperature_available,
    )
        getproperty(status, name) isa Bool || throw(
            ArgumentError("$(String(name)) must be Bool"),
        )
    end
    if !status.source_meteorology_available ||
       !status.source_equivalent_canopy_available ||
       !status.source_previous_soil_surface_temperature_available
        status.simulated_soil_longwave_forcing_available = false
        return nothing
    end

    T = typeof(status.canopy_temperature_c)
    T <: AbstractFloat && isconcretetype(T) ||
        _throw_mono_pass_longwave_forcing_value(
            :canopy_temperature_c,
            T,
            :output_type,
        )
    for name in (
        :incident_thermal_w_m2,
        :soil_surface_temperature_k,
        :soil_reflectance_thermal,
    )
        typeof(getproperty(status, name)) === T ||
            _throw_mono_pass_longwave_forcing_value(
                name,
                typeof(getproperty(status, name)),
                :output_type,
            )
    end
    eltype(status.leaf_temperature_c) === T ||
        _throw_mono_pass_longwave_forcing_value(
            :leaf_temperature_c,
            eltype(status.leaf_temperature_c),
            :output_type,
        )

    # The shared kernel returns a fresh leaf vector. Install every carrier only
    # after it has succeeded so an invalid candidate cannot partially publish.
    result = simulated_soil_longwave_forcing(
        T,
        model.point_count,
        status.source_air_temperature_c,
        status.source_previous_soil_surface_temperature_k,
        status.source_incident_thermal_w_m2,
        status.source_soil_reflectance;
        thermal_waveband_index=model.thermal_waveband_index,
        kelvin_offset=convert(T, model.kelvin_offset),
    )
    status.incident_thermal_w_m2 = result.incident_thermal_w_m2
    status.canopy_temperature_c = result.canopy_temperature_c
    status.leaf_temperature_c = result.leaf_temperature_c
    status.soil_surface_temperature_k = result.soil_surface_temperature_k
    status.soil_reflectance_thermal = result.soil_reflectance_thermal
    status.simulated_soil_longwave_forcing_available = true
    return nothing
end
