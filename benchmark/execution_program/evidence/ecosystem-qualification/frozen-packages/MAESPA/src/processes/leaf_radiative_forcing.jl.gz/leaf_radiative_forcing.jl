PlantSimEngine.@process "leaf_radiative_forcing" verbose = false

"""
Allocated point-by-radiation-slot forcing consumed by leaf physiology.

The three matrices have `point × slot` layout. Only the leading
`active_leaf_radiation_class_count` slots are populated by
[`leaf_radiative_forcing!`](@ref); inactive slots are deterministically zero.
`point_absorbed_thermal_w_m2_leaf` is the corresponding point snapshot before
slot replication. It is intended for crown-scale radiation aggregation, which
must weight this common thermal value once by each point's leaf area. There is
deliberately no foliage-age or organ dimension in this result.
"""
struct LeafRadiativeForcingResult{T<:AbstractFloat}
    leaf_radiation_absorbed_par_umol_m2_s::Matrix{T}
    leaf_radiation_absorbed_thermal_w_m2_leaf::Matrix{T}
    point_absorbed_thermal_w_m2_leaf::Vector{T}
    leaf_radiation_net_w_m2_leaf::Matrix{T}
end

@inline function _leaf_forcing_float(
    ::Type{T},
    value::Real,
    name::AbstractString,
) where {T<:AbstractFloat}
    value isa Bool && throw(ArgumentError("$name must be numeric, not Bool"))
    converted = convert(T, value)
    isfinite(converted) || throw(ArgumentError("$name must be finite"))
    return converted
end

@inline function _leaf_forcing_nonnegative_count(
    value::Integer,
    name::AbstractString,
)
    value isa Bool && throw(ArgumentError("$name must be an integer, not Bool"))
    value >= 0 || throw(ArgumentError("$name must be non-negative"))
    return Int(value)
end

@inline function _leaf_forcing_positive_count(
    value::Integer,
    name::AbstractString,
)
    converted = _leaf_forcing_nonnegative_count(value, name)
    converted > 0 || throw(ArgumentError("$name must be positive"))
    return converted
end

function _validate_leaf_radiative_forcing_inputs(
    leaf_radiation_absorbed_par_umol_m2_s::AbstractMatrix{T},
    leaf_radiation_absorbed_thermal_w_m2_leaf::AbstractMatrix{T},
    point_absorbed_thermal_w_m2_leaf::AbstractVector{T},
    leaf_radiation_net_w_m2_leaf::AbstractMatrix{T},
    leaf_radiation_absorbed_par_w_m2_leaf::AbstractMatrix{T},
    leaf_radiation_absorbed_nir_w_m2_leaf::AbstractMatrix{T},
    active_leaf_radiation_class_count::Int,
    target_diffuse_extinction_coefficients::AbstractVector{T},
    net_downward_longwave_w_m2::AbstractVector{T},
    net_upward_longwave_w_m2::AbstractVector{T},
    umol_per_joule::T,
    astronomical_daylight::Bool,
) where {T<:AbstractFloat}
    Base.require_one_based_indexing(
        leaf_radiation_absorbed_par_umol_m2_s,
        leaf_radiation_absorbed_thermal_w_m2_leaf,
        point_absorbed_thermal_w_m2_leaf,
        leaf_radiation_net_w_m2_leaf,
        leaf_radiation_absorbed_par_w_m2_leaf,
        leaf_radiation_absorbed_nir_w_m2_leaf,
        target_diffuse_extinction_coefficients,
        net_downward_longwave_w_m2,
        net_upward_longwave_w_m2,
    )

    point_count, slot_count = size(leaf_radiation_absorbed_par_w_m2_leaf)
    point_count > 0 || throw(ArgumentError("at least one point is required"))
    slot_count > 0 || throw(ArgumentError("at least one radiation slot is required"))
    expected_size = (point_count, slot_count)
    for (values, name) in (
        (
            leaf_radiation_absorbed_par_umol_m2_s,
            "leaf_radiation_absorbed_par_umol_m2_s",
        ),
        (
            leaf_radiation_absorbed_thermal_w_m2_leaf,
            "leaf_radiation_absorbed_thermal_w_m2_leaf",
        ),
        (
            leaf_radiation_net_w_m2_leaf,
            "leaf_radiation_net_w_m2_leaf",
        ),
        (
            leaf_radiation_absorbed_nir_w_m2_leaf,
            "leaf_radiation_absorbed_nir_w_m2_leaf",
        ),
    )
        size(values) == expected_size || throw(
            DimensionMismatch("$name must have size $expected_size"),
        )
    end
    length(point_absorbed_thermal_w_m2_leaf) == point_count || throw(
        DimensionMismatch(
            "point_absorbed_thermal_w_m2_leaf must contain $point_count values",
        ),
    )
    active_leaf_radiation_class_count <= slot_count || throw(
        DomainError(
            active_leaf_radiation_class_count,
            "active_leaf_radiation_class_count must not exceed $slot_count",
        ),
    )
    isempty(target_diffuse_extinction_coefficients) && throw(
        ArgumentError("target_diffuse_extinction_coefficients must not be empty"),
    )
    length(net_downward_longwave_w_m2) == point_count || throw(
        DimensionMismatch(
            "net_downward_longwave_w_m2 must contain $point_count values",
        ),
    )
    length(net_upward_longwave_w_m2) == point_count || throw(
        DimensionMismatch(
            "net_upward_longwave_w_m2 must contain $point_count values",
        ),
    )
    umol_per_joule > zero(T) || throw(
        DomainError(umol_per_joule, "umol_per_joule must be positive"),
    )

    for (zenith_index, coefficient) in pairs(target_diffuse_extinction_coefficients)
        isfinite(coefficient) || throw(
            ArgumentError(
                "target_diffuse_extinction_coefficients[$zenith_index] must be finite",
            ),
        )
        coefficient >= zero(T) || throw(
            DomainError(
                coefficient,
                "target diffuse extinction coefficients must be non-negative",
            ),
        )
    end
    for point_index in 1:point_count
        downward = net_downward_longwave_w_m2[point_index]
        upward = net_upward_longwave_w_m2[point_index]
        isfinite(downward) || throw(
            ArgumentError("net_downward_longwave_w_m2[$point_index] must be finite"),
        )
        isfinite(upward) || throw(
            ArgumentError("net_upward_longwave_w_m2[$point_index] must be finite"),
        )
        astronomical_daylight || continue
        for slot_index in 1:active_leaf_radiation_class_count
            absorbed_par =
                leaf_radiation_absorbed_par_w_m2_leaf[point_index, slot_index]
            absorbed_nir =
                leaf_radiation_absorbed_nir_w_m2_leaf[point_index, slot_index]
            isfinite(absorbed_par) || throw(
                ArgumentError(
                    "leaf_radiation_absorbed_par_w_m2_leaf" *
                    "[$point_index,$slot_index] must be finite",
                ),
            )
            isfinite(absorbed_nir) || throw(
                ArgumentError(
                    "leaf_radiation_absorbed_nir_w_m2_leaf" *
                    "[$point_index,$slot_index] must be finite",
                ),
            )
            absorbed_par >= zero(T) || throw(
                DomainError(absorbed_par, "absorbed PAR must be non-negative"),
            )
            absorbed_nir >= zero(T) || throw(
                DomainError(absorbed_nir, "absorbed NIR must be non-negative"),
            )
        end
    end
    return nothing
end

"""
    leaf_radiative_forcing!(
        leaf_radiation_absorbed_par_umol_m2_s,
        leaf_radiation_absorbed_thermal_w_m2_leaf,
        point_absorbed_thermal_w_m2_leaf,
        leaf_radiation_net_w_m2_leaf,
        leaf_radiation_absorbed_par_w_m2_leaf,
        leaf_radiation_absorbed_nir_w_m2_leaf,
        active_leaf_radiation_class_count,
        target_diffuse_extinction_coefficients,
        net_downward_longwave_w_m2,
        net_upward_longwave_w_m2;
        umol_per_joule=4.57,
        astronomical_daylight=true,
    )

Prepare MAESPA's radiative inputs for leaf physiology without allocating.

All matrices use `point × radiation-slot` ordering. The shortwave matrices are
the W m⁻² leaf outputs of `MODELSS`. PAR is converted to µmol m⁻² s⁻¹ exactly
once as `PAR_µmol = PAR_W × UMOLPERJ`. Net radiation deliberately uses the
unconverted energy value:

```text
RNET = PAR_W + NIR_W + ATHR
```

The historical thermal contract spans `ABSTHERM` and `ABSRAD`. `ABSTHERM`
returns signed net downward and upward longwave fluxes (`DIFDN`, `DIFUP`) after
subtracting leaf emission. `ABSRAD` then computes, for thermal waveband 3,

```text
ATHR = (DIFDN + DIFUP) × mean(DEXTT(1, :))
```

The legacy routine literally uses row 1 of `DEXTT`, even though it also receives
`ITAR`; it does not index `DEXTT(ITAR, :)`. That is an order-dependent
multi-species leak. This kernel therefore receives the extinction vector
explicitly: the MAESPA Julia composition supplies the current target species,
while a dedicated compatibility adapter could deliberately supply row 1. No
leaf absorptance or 4.57 conversion is applied to `ATHR`. The point-level
`ATHR` is published once in `point_absorbed_thermal_w_m2_leaf`, then copied to
every active radiation slot, and its sign is preserved. The vector is the
slot-independent thermal snapshot required by crown radiation aggregation; it
must not be summed over slots before geometric leaf-area weighting.
Every inactive output slot is reset to zero. Inactive input slots are ignored,
so stale values outside the declared active range cannot enter physiology.
At night, MAESPA keeps one logical radiation class per point, sets PAR and NIR
to zero, and retains only the signed thermal term. The shortwave buffers are
therefore ignored entirely in that branch, including stale or non-finite
values from the unavailable shortwave process. There is no foliage-age or
synthetic-organ dimension in this kernel.
"""
function leaf_radiative_forcing!(
    leaf_radiation_absorbed_par_umol_m2_s::AbstractMatrix{T},
    leaf_radiation_absorbed_thermal_w_m2_leaf::AbstractMatrix{T},
    point_absorbed_thermal_w_m2_leaf::AbstractVector{T},
    leaf_radiation_net_w_m2_leaf::AbstractMatrix{T},
    leaf_radiation_absorbed_par_w_m2_leaf::AbstractMatrix{T},
    leaf_radiation_absorbed_nir_w_m2_leaf::AbstractMatrix{T},
    active_leaf_radiation_class_count::Integer,
    target_diffuse_extinction_coefficients::AbstractVector{T},
    net_downward_longwave_w_m2::AbstractVector{T},
    net_upward_longwave_w_m2::AbstractVector{T};
    umol_per_joule::Real=T(4.57),
    astronomical_daylight::Bool=true,
) where {T<:AbstractFloat}
    active_count = _leaf_forcing_nonnegative_count(
        active_leaf_radiation_class_count,
        "active_leaf_radiation_class_count",
    )
    slot_count = size(leaf_radiation_absorbed_par_w_m2_leaf, 2)
    active_count <= slot_count || throw(
        DomainError(
            active_count,
            "active_leaf_radiation_class_count must not exceed $slot_count",
        ),
    )
    effective_active_count = astronomical_daylight ? active_count : 1
    conversion = _leaf_forcing_float(T, umol_per_joule, "umol_per_joule")
    _validate_leaf_radiative_forcing_inputs(
        leaf_radiation_absorbed_par_umol_m2_s,
        leaf_radiation_absorbed_thermal_w_m2_leaf,
        point_absorbed_thermal_w_m2_leaf,
        leaf_radiation_net_w_m2_leaf,
        leaf_radiation_absorbed_par_w_m2_leaf,
        leaf_radiation_absorbed_nir_w_m2_leaf,
        effective_active_count,
        target_diffuse_extinction_coefficients,
        net_downward_longwave_w_m2,
        net_upward_longwave_w_m2,
        conversion,
        astronomical_daylight,
    )

    fill!(leaf_radiation_absorbed_par_umol_m2_s, zero(T))
    fill!(leaf_radiation_absorbed_thermal_w_m2_leaf, zero(T))
    fill!(point_absorbed_thermal_w_m2_leaf, zero(T))
    fill!(leaf_radiation_net_w_m2_leaf, zero(T))
    iszero(effective_active_count) && return nothing

    mean_diffuse_extinction = zero(T)
    for coefficient in target_diffuse_extinction_coefficients
        mean_diffuse_extinction += coefficient
    end
    mean_diffuse_extinction /= T(length(target_diffuse_extinction_coefficients))

    point_count = size(leaf_radiation_absorbed_par_w_m2_leaf, 1)
    for point_index in 1:point_count
        point_absorbed_thermal_w_m2_leaf[point_index] = (
            net_downward_longwave_w_m2[point_index] +
            net_upward_longwave_w_m2[point_index]
        ) * mean_diffuse_extinction
    end
    for slot_index in 1:effective_active_count, point_index in 1:point_count
        if astronomical_daylight
            absorbed_par_w_m2 =
                leaf_radiation_absorbed_par_w_m2_leaf[point_index, slot_index]
            absorbed_nir_w_m2 =
                leaf_radiation_absorbed_nir_w_m2_leaf[point_index, slot_index]
        else
            absorbed_par_w_m2 = zero(T)
            absorbed_nir_w_m2 = zero(T)
        end
        absorbed_thermal_w_m2 = point_absorbed_thermal_w_m2_leaf[point_index]
        leaf_radiation_absorbed_par_umol_m2_s[point_index, slot_index] =
            absorbed_par_w_m2 * conversion
        leaf_radiation_absorbed_thermal_w_m2_leaf[point_index, slot_index] =
            absorbed_thermal_w_m2
        leaf_radiation_net_w_m2_leaf[point_index, slot_index] =
            absorbed_par_w_m2 +
            absorbed_nir_w_m2 +
            absorbed_thermal_w_m2
    end
    return nothing
end

"""Allocate and return MAESPA's point-by-slot leaf-radiative forcing."""
function leaf_radiative_forcing(
    leaf_radiation_absorbed_par_w_m2_leaf::AbstractMatrix{T},
    leaf_radiation_absorbed_nir_w_m2_leaf::AbstractMatrix{T},
    active_leaf_radiation_class_count::Integer,
    target_diffuse_extinction_coefficients::AbstractVector{T},
    net_downward_longwave_w_m2::AbstractVector{T},
    net_upward_longwave_w_m2::AbstractVector{T};
    umol_per_joule::Real=T(4.57),
    astronomical_daylight::Bool=true,
) where {T<:AbstractFloat}
    output_size = size(leaf_radiation_absorbed_par_w_m2_leaf)
    result = LeafRadiativeForcingResult(
        zeros(T, output_size),
        zeros(T, output_size),
        zeros(T, output_size[1]),
        zeros(T, output_size),
    )
    leaf_radiative_forcing!(
        result.leaf_radiation_absorbed_par_umol_m2_s,
        result.leaf_radiation_absorbed_thermal_w_m2_leaf,
        result.point_absorbed_thermal_w_m2_leaf,
        result.leaf_radiation_net_w_m2_leaf,
        leaf_radiation_absorbed_par_w_m2_leaf,
        leaf_radiation_absorbed_nir_w_m2_leaf,
        active_leaf_radiation_class_count,
        target_diffuse_extinction_coefficients,
        net_downward_longwave_w_m2,
        net_upward_longwave_w_m2;
        umol_per_joule=umol_per_joule,
        astronomical_daylight=astronomical_daylight,
    )
    return result
end

"""Call-only-compatible PlantSimEngine wrapper for leaf-radiative forcing."""
struct MAESPALeafRadiativeForcing{T<:AbstractFloat} <:
       AbstractLeaf_Radiative_ForcingModel
    point_count::Int
    slot_count::Int
    umol_per_joule::T
end

function MAESPALeafRadiativeForcing(
    ::Type{T},
    point_count::Integer,
    slot_count::Integer;
    umol_per_joule::Real=T(4.57),
) where {T<:AbstractFloat}
    points = _leaf_forcing_positive_count(point_count, "point_count")
    slots = _leaf_forcing_positive_count(slot_count, "slot_count")
    conversion = _leaf_forcing_float(T, umol_per_joule, "umol_per_joule")
    conversion > zero(T) || throw(
        DomainError(conversion, "umol_per_joule must be positive"),
    )
    return MAESPALeafRadiativeForcing{T}(points, slots, conversion)
end

PlantSimEngine.inputs_(::MAESPALeafRadiativeForcing) = (
    leaf_radiation_absorbed_par_w_m2_leaf=PlantSimEngine.Required(AbstractMatrix),
    leaf_radiation_absorbed_nir_w_m2_leaf=PlantSimEngine.Required(AbstractMatrix),
    active_leaf_radiation_class_count=PlantSimEngine.Required(Integer),
    leaf_radiation_partitioning_available=PlantSimEngine.Required(Bool),
    astronomical_daylight=PlantSimEngine.Required(Bool),
    target_diffuse_extinction_coefficients=PlantSimEngine.Required(AbstractVector),
    net_downward_longwave_w_m2=PlantSimEngine.Required(AbstractVector),
    net_upward_longwave_w_m2=PlantSimEngine.Required(AbstractVector),
    longwave_canopy_exchange_available=PlantSimEngine.Required(Bool),
    leaf_radiative_forcing_inputs_available=PlantSimEngine.Default(true),
)

PlantSimEngine.variable_contracts_(::MAESPALeafRadiativeForcing) = (
    leaf_radiation_absorbed_par_w_m2_leaf=ABSORBED_LEAF_PAR_IRRADIANCE_CONTRACT,
    leaf_radiation_absorbed_nir_w_m2_leaf=ABSORBED_LEAF_NIR_IRRADIANCE_CONTRACT,
    active_leaf_radiation_class_count=LEAF_RADIATION_CLASS_COUNT_CONTRACT,
    leaf_radiation_partitioning_available=LEAF_RADIATION_PARTITION_AVAILABLE_CONTRACT,
)

function PlantSimEngine.outputs_(model::MAESPALeafRadiativeForcing{T}) where {T}
    output_size = (model.point_count, model.slot_count)
    return (
        leaf_radiation_absorbed_par_umol_m2_s=zeros(T, output_size),
        leaf_radiation_absorbed_thermal_w_m2_leaf=zeros(T, output_size),
        point_absorbed_thermal_w_m2_leaf=zeros(T, model.point_count),
        leaf_radiation_net_w_m2_leaf=zeros(T, output_size),
        leaf_radiative_forcing_available=false,
    )
end

function _reset_leaf_radiative_forcing_outputs!(status, ::Type{T}) where {T}
    fill!(status.leaf_radiation_absorbed_par_umol_m2_s, zero(T))
    fill!(status.leaf_radiation_absorbed_thermal_w_m2_leaf, zero(T))
    fill!(status.point_absorbed_thermal_w_m2_leaf, zero(T))
    fill!(status.leaf_radiation_net_w_m2_leaf, zero(T))
    status.leaf_radiative_forcing_available = false
    return nothing
end

@noinline function _throw_leaf_forcing_eltype(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and leaf-radiative-forcing output buffers " *
            "must share a numeric type",
        ),
    )
end

@inline function _require_leaf_forcing_eltype(
    values,
    ::Type{T},
    name::Symbol,
) where {T<:AbstractFloat}
    eltype(values) === T || _throw_leaf_forcing_eltype(name)
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPALeafRadiativeForcing,
    status,
    environment,
    constants,
    context,
)
    T = eltype(status.leaf_radiation_absorbed_par_umol_m2_s)
    _reset_leaf_radiative_forcing_outputs!(status, T)
    _require_leaf_forcing_eltype(
        status.leaf_radiation_absorbed_thermal_w_m2_leaf,
        T,
        :leaf_radiation_absorbed_thermal_w_m2_leaf,
    )
    _require_leaf_forcing_eltype(
        status.point_absorbed_thermal_w_m2_leaf,
        T,
        :point_absorbed_thermal_w_m2_leaf,
    )
    _require_leaf_forcing_eltype(
        status.leaf_radiation_net_w_m2_leaf,
        T,
        :leaf_radiation_net_w_m2_leaf,
    )
    _require_leaf_forcing_eltype(
        status.leaf_radiation_absorbed_par_w_m2_leaf,
        T,
        :leaf_radiation_absorbed_par_w_m2_leaf,
    )
    _require_leaf_forcing_eltype(
        status.leaf_radiation_absorbed_nir_w_m2_leaf,
        T,
        :leaf_radiation_absorbed_nir_w_m2_leaf,
    )
    _require_leaf_forcing_eltype(
        status.target_diffuse_extinction_coefficients,
        T,
        :target_diffuse_extinction_coefficients,
    )
    _require_leaf_forcing_eltype(
        status.net_downward_longwave_w_m2,
        T,
        :net_downward_longwave_w_m2,
    )
    _require_leaf_forcing_eltype(
        status.net_upward_longwave_w_m2,
        T,
        :net_upward_longwave_w_m2,
    )

    partition_available = status.leaf_radiation_partitioning_available
    longwave_available = status.longwave_canopy_exchange_available
    inputs_available = status.leaf_radiative_forcing_inputs_available
    daylight = status.astronomical_daylight
    partition_available isa Bool || throw(
        ArgumentError("leaf_radiation_partitioning_available must be Bool"),
    )
    longwave_available isa Bool || throw(
        ArgumentError("longwave_canopy_exchange_available must be Bool"),
    )
    inputs_available isa Bool || throw(
        ArgumentError("leaf_radiative_forcing_inputs_available must be Bool"),
    )
    daylight isa Bool || throw(ArgumentError("astronomical_daylight must be Bool"))
    active_count = _leaf_forcing_nonnegative_count(
        status.active_leaf_radiation_class_count,
        "active_leaf_radiation_class_count",
    )
    if !inputs_available ||
       !longwave_available ||
       (daylight && (!partition_available || iszero(active_count)))
        return nothing
    end

    leaf_radiative_forcing!(
        status.leaf_radiation_absorbed_par_umol_m2_s,
        status.leaf_radiation_absorbed_thermal_w_m2_leaf,
        status.point_absorbed_thermal_w_m2_leaf,
        status.leaf_radiation_net_w_m2_leaf,
        status.leaf_radiation_absorbed_par_w_m2_leaf,
        status.leaf_radiation_absorbed_nir_w_m2_leaf,
        active_count,
        status.target_diffuse_extinction_coefficients,
        status.net_downward_longwave_w_m2,
        status.net_upward_longwave_w_m2;
        umol_per_joule=_leaf_forcing_float(
            T,
            model.umol_per_joule,
            "umol_per_joule",
        ),
        astronomical_daylight=daylight,
    )
    status.leaf_radiative_forcing_available = true
    return nothing
end
