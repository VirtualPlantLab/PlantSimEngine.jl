@inline function _optical_path_finite(
    value::T,
    name::AbstractString,
) where {T<:AbstractFloat}
    isfinite(value) || throw(ArgumentError("$name must be finite"))
    return value
end

@inline function _optical_path_nonnegative(
    value::T,
    name::AbstractString,
) where {T<:AbstractFloat}
    _optical_path_finite(value, name)
    value >= zero(T) || throw(ArgumentError("$name must be non-negative"))
    return value
end

@inline function _optical_path_positive(
    value::T,
    name::AbstractString,
) where {T<:AbstractFloat}
    _optical_path_finite(value, name)
    value > zero(T) || throw(ArgumentError("$name must be positive"))
    return value
end

function _optical_path_positive_integer(value::Integer, name::AbstractString)
    value isa Bool && throw(ArgumentError("$name must be an integer, not Bool"))
    value > 0 || throw(ArgumentError("$name must be positive"))
    try
        return Int(value)
    catch error
        error isa InexactError || rethrow()
        throw(ArgumentError("$name must fit in Int"))
    end
end

function _optical_path_shape_code(value::Integer)
    value isa Bool && throw(
        ArgumentError("crown_shape_code must be an integer, not Bool"),
    )
    1 <= value <= 6 || throw(
        ArgumentError("crown_shape_code must be in 1:6, got $value"),
    )
    return Int(value)
end

function _optical_path_position(
    position::Union{NTuple{3,T},AbstractVector{T}},
) where {T<:AbstractFloat}
    length(position) == 3 || throw(
        DimensionMismatch("position must contain exactly three coordinates"),
    )
    coordinates = Tuple(position)
    for coordinate in coordinates
        _optical_path_finite(coordinate, "position coordinate")
    end
    return coordinates
end

"""Common interface for the geometric and optical state of one MAESPA crown."""
abstract type AbstractCrownRayState{T<:AbstractFloat} end

"""
    UniformCrownRayState{T}

Validated geometry and optical parameters for one uniform-leaf-area-density
MAESPA crown (`JLEAF = 0`). Shape codes `1:6` follow `CONE`, `ELIP`, `PARA`,
`ROUND`, `CYL`, and `BOX`. The supplied angle-specific extinction vector is
copied so subsequent mutation of the constructor input cannot alter the state.
"""
struct UniformCrownRayState{T<:AbstractFloat} <: AbstractCrownRayState{T}
    id::Int
    crown_shape_code::Int
    position::NTuple{3,T}
    crown_base::T
    radius_x::T
    radius_y::T
    crown_depth::T
    leaf_area_density::T
    extinction::T
    extinction_by_angle::Vector{T}

    function UniformCrownRayState{T}(
        id::Integer,
        crown_shape_code::Integer,
        position::Union{NTuple{3,T},AbstractVector{T}},
        crown_base::T,
        radius_x::T,
        radius_y::T,
        crown_depth::T,
        leaf_area_density::T,
        extinction::T,
        extinction_by_angle::AbstractVector{T},
    ) where {T<:AbstractFloat}
        return UniformCrownRayState{T}(
            id,
            crown_shape_code,
            position,
            crown_base,
            radius_x,
            radius_y,
            crown_depth,
            leaf_area_density,
            extinction,
            extinction_by_angle,
            Val(:copy),
        )
    end

    function UniformCrownRayState{T}(
        id::Integer,
        crown_shape_code::Integer,
        position::Union{NTuple{3,T},AbstractVector{T}},
        crown_base::T,
        radius_x::T,
        radius_y::T,
        crown_depth::T,
        leaf_area_density::T,
        extinction::T,
        extinction_by_angle::AbstractVector{T},
        ::Val{ownership},
    ) where {T<:AbstractFloat,ownership}
        ownership in (:copy, :borrow) || throw(
            ArgumentError("unsupported extinction-vector ownership $ownership"),
        )
        validated_id = _optical_path_positive_integer(id, "id")
        validated_shape = _optical_path_shape_code(crown_shape_code)
        validated_position = _optical_path_position(position)
        _optical_path_nonnegative(crown_base, "crown_base")
        _optical_path_positive(radius_x, "radius_x")
        _optical_path_positive(radius_y, "radius_y")
        _optical_path_positive(crown_depth, "crown_depth")
        _optical_path_nonnegative(leaf_area_density, "leaf_area_density")
        _optical_path_nonnegative(extinction, "extinction")
        isempty(extinction_by_angle) && throw(
            ArgumentError("extinction_by_angle must contain at least one value"),
        )
        for coefficient in extinction_by_angle
            _optical_path_nonnegative(coefficient, "angle-specific extinction")
        end
        coefficients = if ownership === :borrow
            extinction_by_angle isa Vector{T} || throw(
                ArgumentError("a borrowed extinction vector must be Vector{$T}"),
            )
            extinction_by_angle
        else
            Vector{T}(extinction_by_angle)
        end
        return new{T}(
            validated_id,
            validated_shape,
            validated_position,
            crown_base,
            radius_x,
            radius_y,
            crown_depth,
            leaf_area_density,
            extinction,
            coefficients,
        )
    end

    # Reuse an owned, validated structural snapshot with current beam optics.
    # Only the changing scalar needs validation; retained arrays are borrowed.
    function UniformCrownRayState{T}(
        snapshot::UniformCrownRayState{T},
        extinction::T,
    ) where {T<:AbstractFloat}
        _optical_path_nonnegative(extinction, "extinction")
        return new{T}(
            snapshot.id, snapshot.crown_shape_code, snapshot.position,
            snapshot.crown_base, snapshot.radius_x, snapshot.radius_y,
            snapshot.crown_depth, snapshot.leaf_area_density,
            extinction, snapshot.extinction_by_angle,
        )
    end
end

function _borrowed_uniform_crown_ray_state(
    id::Integer,
    crown_shape_code::Integer;
    position::NTuple{3,T},
    crown_base::T,
    radius_x::T,
    radius_y::T,
    crown_depth::T,
    leaf_area_density::T,
    extinction::T,
    extinction_by_angle::Vector{T},
) where {T<:AbstractFloat}
    return UniformCrownRayState{T}(
        id,
        crown_shape_code,
        position,
        crown_base,
        radius_x,
        radius_y,
        crown_depth,
        leaf_area_density,
        extinction,
        extinction_by_angle,
        Val(:borrow),
    )
end

"""
    UniformCrownRayState(id, crown_shape_code; position, crown_base,
                         radius_x, radius_y, crown_depth,
                         leaf_area_density, extinction,
                         extinction_by_angle)

Construct a typed uniform-crown ray state. All floating-point arguments and
the angle-specific vector must share the same element type `T`.
"""
function UniformCrownRayState(
    id::Integer,
    crown_shape_code::Integer;
    position::Union{NTuple{3,T},AbstractVector{T}},
    crown_base::T,
    radius_x::T,
    radius_y::T,
    crown_depth::T,
    leaf_area_density::T,
    extinction::T,
    extinction_by_angle::AbstractVector{T},
) where {T<:AbstractFloat}
    return UniformCrownRayState{T}(
        id,
        crown_shape_code,
        position,
        crown_base,
        radius_x,
        radius_y,
        crown_depth,
        leaf_area_density,
        extinction,
        extinction_by_angle,
    )
end

"""
    OpticalPathResult{T}

Aggregate crown leaf paths and optical depths for one ray. The target is
selected by its position in the crown vector, not by its public tree id.
`available` reports whether the effective extinction coefficients have a
strictly positive leaf-path denominator.
"""
struct OpticalPathResult{T<:AbstractFloat}
    target_leaf_path::T
    other_leaf_path::T
    total_leaf_path::T
    target_optical_depth::T
    other_optical_depth::T
    total_optical_depth::T
    effective_extinction::T
    effective_extinction_by_angle::Vector{T}
    transmittance::T
    available::Bool

    function OpticalPathResult{T}(
        target_leaf_path::T,
        other_leaf_path::T,
        total_leaf_path::T,
        target_optical_depth::T,
        other_optical_depth::T,
        total_optical_depth::T,
        effective_extinction::T,
        effective_extinction_by_angle::AbstractVector{T},
        transmittance::T,
        available::Bool,
    ) where {T<:AbstractFloat}
        return new{T}(
            target_leaf_path,
            other_leaf_path,
            total_leaf_path,
            target_optical_depth,
            other_optical_depth,
            total_optical_depth,
            effective_extinction,
            Vector{T}(effective_extinction_by_angle),
            transmittance,
            available,
        )
    end
end

function _validate_optical_ray(
    origin::NTuple{3,T},
    direction::NTuple{3,T},
) where {T<:AbstractFloat}
    for coordinate in origin
        _optical_path_finite(coordinate, "ray origin coordinate")
    end
    for component in direction
        _optical_path_finite(component, "ray direction component")
    end
    scale = max(abs(direction[1]), abs(direction[2]), abs(direction[3]))
    scale > zero(T) || throw(ArgumentError("ray direction must be non-zero"))
    return nothing
end

@inline function _possible_crown_tolerance(
    ::Type{T},
    values::T...,
) where {T<:AbstractFloat}
    scale = one(T)
    for value in values
        isfinite(value) || return T(Inf)
        scale = max(scale, abs(value))
    end
    return T(128) * eps(T) * scale
end

function _possible_crown_intersection(
    origin::NTuple{3,T},
    unit_direction::NTuple{3,T},
    crown::AbstractCrownRayState{T},
) where {T<:AbstractFloat}
    relative_x = crown.position[1] - origin[1]
    relative_y = crown.position[2] - origin[2]
    isfinite(relative_x) && isfinite(relative_y) || return true

    horizontal_norm = hypot(unit_direction[1], unit_direction[2])
    isfinite(horizontal_norm) || return true
    if iszero(horizontal_norm)
        tolerance = _possible_crown_tolerance(
            T,
            relative_x,
            relative_y,
            crown.radius_x,
            crown.radius_y,
        )
        return abs(relative_x) <= crown.radius_x + tolerance &&
               abs(relative_y) <= crown.radius_y + tolerance
    end

    direction_x = unit_direction[1] / horizontal_norm
    direction_y = unit_direction[2] / horizontal_norm
    cross_first = relative_x * direction_y
    cross_second = relative_y * direction_x
    perpendicular_offset = abs(cross_first - cross_second)
    parallel_offset = relative_x * direction_x + relative_y * direction_y

    perpendicular_support, parallel_support = if crown.crown_shape_code == 6
        (
            crown.radius_x * abs(direction_y) +
            crown.radius_y * abs(direction_x),
            crown.radius_x * abs(direction_x) +
            crown.radius_y * abs(direction_y),
        )
    else
        (
            hypot(
                crown.radius_x * direction_y,
                crown.radius_y * direction_x,
            ),
            hypot(
                crown.radius_x * direction_x,
                crown.radius_y * direction_y,
            ),
        )
    end
    values = (
        direction_x,
        direction_y,
        cross_first,
        cross_second,
        perpendicular_offset,
        parallel_offset,
        perpendicular_support,
        parallel_support,
    )
    all(isfinite, values) || return true
    tolerance = _possible_crown_tolerance(T, values...)
    return perpendicular_offset <= perpendicular_support + tolerance &&
           parallel_offset >= -parallel_support - tolerance
end

"""
    possible_crown_intersection(origin, direction, crown)

Conservative horizontal broad-phase for a forward crown ray. A `false` result
guarantees that the full three-dimensional analytic intersection is empty;
`true` means only that an intersection remains possible. Shapes `1:5` use the
support of their elliptical horizontal projection, while `BOX` uses the exact
rectangular support so its corners cannot be rejected as they could be by the
historical Fortran `POSSIBLE` circle test. Numerically ambiguous cases fail
open and are left to `crown_ray_intersection`.
"""
function possible_crown_intersection(
    origin::NTuple{3,T},
    direction::NTuple{3,T},
    crown::AbstractCrownRayState{T},
) where {T<:AbstractFloat}
    _validate_optical_ray(origin, direction)
    return _possible_crown_intersection(
        origin,
        _normalise_ray_direction(direction),
        crown,
    )
end

"""
    uniform_leaf_paths!(output, origin, direction, crowns)

Fill `output` with `leaf_area_density * path_length` for each analytic crown.
Each crown is intersected independently with `crown_ray_intersection`.
Consequently overlapping crowns add later during aggregation; their geometric
segments are not sorted or merged. Stems, periodic copies, and plot clipping
are outside this kernel.
"""
function uniform_leaf_paths!(
    output::AbstractVector{T},
    origin::NTuple{3,T},
    direction::NTuple{3,T},
    crowns::AbstractVector{<:UniformCrownRayState{T}},
) where {T<:AbstractFloat}
    length(output) == length(crowns) || throw(
        DimensionMismatch(
            "output length $(length(output)) does not match crown count $(length(crowns))",
        ),
    )
    _validate_optical_ray(origin, direction)
    unit_direction = _normalise_ray_direction(direction)

    for (output_index, crown_index) in zip(eachindex(output), eachindex(crowns))
        crown = crowns[crown_index]
        if !_possible_crown_intersection(origin, unit_direction, crown)
            output[output_index] = zero(T)
            continue
        end
        intersection = crown_ray_intersection(
            origin,
            unit_direction,
            crown.crown_shape_code;
            tree_x=crown.position[1],
            tree_y=crown.position[2],
            tree_z=crown.position[3],
            crown_base=crown.crown_base,
            radius_x=crown.radius_x,
            radius_y=crown.radius_y,
            crown_depth=crown.crown_depth,
        )
        output[output_index] = uniform_leaf_path(
            crown.leaf_area_density,
            intersection,
        )
    end
    return output
end

"""Allocate and return the typed uniform-LAD leaf path for every crown."""
function uniform_leaf_paths(
    origin::NTuple{3,T},
    direction::NTuple{3,T},
    crowns::AbstractVector{<:UniformCrownRayState{T}},
) where {T<:AbstractFloat}
    return uniform_leaf_paths!(
        Vector{T}(undef, length(crowns)),
        origin,
        direction,
        crowns,
    )
end

@inline _crown_leaf_path(
    crown::UniformCrownRayState{T},
    intersection::CrownRayIntersection{T},
) where {T<:AbstractFloat} = uniform_leaf_path(crown.leaf_area_density, intersection)

"""
    crown_leaf_paths!(output, origin, direction, crowns)

Fill `output` with the leaf-area path integral of every crown intersected by a
ray. Uniform and beta-distributed crowns may coexist in the same vector; each
state dispatches to its own density kernel while sharing the analytic crown
intersection.
"""
function crown_leaf_paths!(
    output::AbstractVector{T},
    origin::NTuple{3,T},
    direction::NTuple{3,T},
    crowns::AbstractVector{<:AbstractCrownRayState{T}},
) where {T<:AbstractFloat}
    length(output) == length(crowns) || throw(
        DimensionMismatch(
            "output length $(length(output)) does not match crown count $(length(crowns))",
        ),
    )
    _validate_optical_ray(origin, direction)
    unit_direction = _normalise_ray_direction(direction)

    for (output_index, crown_index) in zip(eachindex(output), eachindex(crowns))
        crown = crowns[crown_index]
        if !_possible_crown_intersection(origin, unit_direction, crown)
            output[output_index] = zero(T)
            continue
        end
        intersection = crown_ray_intersection(
            origin,
            unit_direction,
            crown.crown_shape_code;
            tree_x=crown.position[1],
            tree_y=crown.position[2],
            tree_z=crown.position[3],
            crown_base=crown.crown_base,
            radius_x=crown.radius_x,
            radius_y=crown.radius_y,
            crown_depth=crown.crown_depth,
        )
        output[output_index] = _crown_leaf_path(crown, intersection)
    end
    return output
end

crown_leaf_paths!(
    output::AbstractVector{T},
    origin::NTuple{3,T},
    direction::NTuple{3,T},
    crowns::AbstractVector{<:UniformCrownRayState{T}},
) where {T<:AbstractFloat} = uniform_leaf_paths!(output, origin, direction, crowns)

"""Allocate the typed leaf-area path vector for a possibly mixed crown set."""
function crown_leaf_paths(
    origin::NTuple{3,T},
    direction::NTuple{3,T},
    crowns::AbstractVector{<:AbstractCrownRayState{T}},
) where {T<:AbstractFloat}
    return crown_leaf_paths!(
        Vector{T}(undef, length(crowns)),
        origin,
        direction,
        crowns,
    )
end

function _optical_path_angle_count(
    crowns::AbstractVector{<:AbstractCrownRayState{T}},
) where {T<:AbstractFloat}
    isempty(crowns) && return 0
    first_index = firstindex(crowns)
    count = length(crowns[first_index].extinction_by_angle)
    for crown_index in eachindex(crowns)
        coefficients = crowns[crown_index].extinction_by_angle
        length(coefficients) == count || throw(
            DimensionMismatch(
                "all crowns must have the same extinction_by_angle length",
            ),
        )
        for coefficient in coefficients
            _optical_path_nonnegative(coefficient, "angle-specific extinction")
        end
    end
    return count
end

function _optical_path_target_index(target_index, crown_count::Int)
    target_index === nothing && return 0
    target_index isa Bool && throw(
        ArgumentError("target_index must be an integer, not Bool"),
    )
    target_index isa Integer || throw(
        ArgumentError("target_index must be an integer or nothing"),
    )
    1 <= target_index <= crown_count || throw(
        BoundsError(Base.OneTo(crown_count), target_index),
    )
    return Int(target_index)
end

@inline function _checked_optical_sum(
    accumulator::T,
    increment::T,
    name::AbstractString,
) where {T<:AbstractFloat}
    isfinite(increment) || throw(ArgumentError("$name contribution must be finite"))
    updated = accumulator + increment
    isfinite(updated) || throw(ArgumentError("$name sum must be finite"))
    return updated
end

"""
    summarize_optical_path(crowns, leaf_paths; target_index=nothing)

Aggregate per-crown leaf paths using the MAESPA `TREDST` weighting:
optical depths are `leaf_path * extinction`, while effective extinction is
weighted by leaf path. `target_index` is an explicit one-based vector index;
with `nothing`, every crown contributes to the `other` totals.

Overlapping crown contributions are added independently. When the total leaf
path is zero, the result has unit transmittance, zero numerical effective
coefficients, and `available == false`; no historical scalar fallback is used.
"""
function summarize_optical_path(
    crowns::AbstractVector{<:AbstractCrownRayState{T}},
    leaf_paths::AbstractVector{T};
    target_index=nothing,
) where {T<:AbstractFloat}
    length(leaf_paths) == length(crowns) || throw(
        DimensionMismatch(
            "leaf path count $(length(leaf_paths)) does not match crown count $(length(crowns))",
        ),
    )
    angle_count = _optical_path_angle_count(crowns)
    target = _optical_path_target_index(target_index, length(crowns))

    target_leaf_path = zero(T)
    other_leaf_path = zero(T)
    target_optical_depth = zero(T)
    other_optical_depth = zero(T)
    angle_weighted_extinction = zeros(T, angle_count)

    for (ordinal, (crown_index, path_index)) in enumerate(
        zip(eachindex(crowns), eachindex(leaf_paths)),
    )
        crown = crowns[crown_index]
        leaf_path = leaf_paths[path_index]
        _optical_path_nonnegative(leaf_path, "leaf path")
        _optical_path_nonnegative(crown.extinction, "extinction")
        optical_depth = leaf_path * crown.extinction

        if ordinal == target
            target_leaf_path = _checked_optical_sum(
                target_leaf_path,
                leaf_path,
                "target leaf path",
            )
            target_optical_depth = _checked_optical_sum(
                target_optical_depth,
                optical_depth,
                "target optical depth",
            )
        else
            other_leaf_path = _checked_optical_sum(
                other_leaf_path,
                leaf_path,
                "other leaf path",
            )
            other_optical_depth = _checked_optical_sum(
                other_optical_depth,
                optical_depth,
                "other optical depth",
            )
        end

        for angle_index in eachindex(angle_weighted_extinction)
            contribution = leaf_path * crown.extinction_by_angle[angle_index]
            angle_weighted_extinction[angle_index] = _checked_optical_sum(
                angle_weighted_extinction[angle_index],
                contribution,
                "angle-specific weighted extinction",
            )
        end
    end

    total_leaf_path = _checked_optical_sum(
        target_leaf_path,
        other_leaf_path,
        "total leaf path",
    )
    total_optical_depth = _checked_optical_sum(
        target_optical_depth,
        other_optical_depth,
        "total optical depth",
    )
    available = total_leaf_path > zero(T)
    effective_extinction = available ?
                             total_optical_depth / total_leaf_path :
                             zero(T)
    if available
        for angle_index in eachindex(angle_weighted_extinction)
            angle_weighted_extinction[angle_index] /= total_leaf_path
        end
    else
        fill!(angle_weighted_extinction, zero(T))
    end
    transmittance = available ? exp(-total_optical_depth) : one(T)

    return OpticalPathResult{T}(
        target_leaf_path,
        other_leaf_path,
        total_leaf_path,
        target_optical_depth,
        other_optical_depth,
        total_optical_depth,
        effective_extinction,
        angle_weighted_extinction,
        transmittance,
        available,
    )
end
