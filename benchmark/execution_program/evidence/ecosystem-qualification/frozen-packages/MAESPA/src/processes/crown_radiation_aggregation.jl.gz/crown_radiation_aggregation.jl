PlantSimEngine.@process "crown_radiation_aggregation" verbose = false

"""
Scalar totals returned by [`crown_radiation_aggregation!`](@ref).

PAR and NIR energy totals are in W per Crown. The PAR photon total is the
legacy-compatible conversion using `UMOLPERJ = 4.57` µmol J⁻¹.
"""
struct CrownRadiationAggregationTotals{T<:AbstractFloat}
    absorbed_par_crown_w::T
    absorbed_nir_crown_w::T
    absorbed_par_crown_umol_s::T
end

"""Allocated result of the shortwave Crown radiation aggregation."""
struct CrownRadiationAggregationResult{T<:AbstractFloat}
    layer_leaf_area_m2::Vector{T}
    absorbed_par_by_layer_w::Vector{T}
    absorbed_nir_by_layer_w::Vector{T}
    absorbed_par_by_layer_umol_s::Vector{T}
    mean_absorbed_par_by_layer_w_m2_leaf::Vector{T}
    mean_absorbed_nir_by_layer_w_m2_leaf::Vector{T}
    mean_absorbed_par_by_layer_umol_m2_leaf_s::Vector{T}
    layer_shortwave_mean_available::Vector{Bool}
    absorbed_par_crown_w::T
    absorbed_nir_crown_w::T
    absorbed_par_crown_umol_s::T
end

@inline function _crown_radiation_positive_count(
    value::Integer,
    name::AbstractString,
)
    value isa Bool && throw(ArgumentError("$name must be an integer, not Bool"))
    value > 0 || throw(ArgumentError("$name must be positive"))
    return Int(value)
end

@inline function _crown_radiation_float(
    ::Type{T},
    value::Real,
    name::AbstractString,
) where {T<:AbstractFloat}
    value isa Bool && throw(ArgumentError("$name must be numeric, not Bool"))
    converted = convert(T, value)
    isfinite(converted) || throw(ArgumentError("$name must be finite"))
    return converted
end

function _crown_radiation_maximum_layer(
    physiological_layers::AbstractVector{<:Integer},
)
    isempty(physiological_layers) && throw(
        ArgumentError("at least one representative point is required"),
    )
    maximum_layer = 0
    for source_layer in physiological_layers
        source_layer isa Bool && throw(
            ArgumentError("physiological_layers values must not be Bool"),
        )
        layer = Int(source_layer)
        layer > 0 || throw(
            DomainError(layer, "physiological_layers values must be positive"),
        )
        maximum_layer = max(maximum_layer, layer)
    end
    return maximum_layer
end

function _validate_crown_radiation_geometry(
    layer_leaf_area_m2::AbstractVector{T},
    leaf_area_density::AbstractVector{T},
    representative_volumes::AbstractVector{T},
    physiological_layers::AbstractVector{<:Integer},
) where {T<:AbstractFloat}
    Base.require_one_based_indexing(
        layer_leaf_area_m2,
        leaf_area_density,
        representative_volumes,
        physiological_layers,
    )
    point_count = length(leaf_area_density)
    point_count > 0 || throw(
        ArgumentError("at least one representative point is required"),
    )
    layer_count = length(layer_leaf_area_m2)
    layer_count > 0 || throw(
        ArgumentError("at least one physiological layer is required"),
    )
    length(representative_volumes) == point_count || throw(
        DimensionMismatch(
            "representative_volumes must contain $point_count values",
        ),
    )
    length(physiological_layers) == point_count || throw(
        DimensionMismatch(
            "physiological_layers must contain $point_count values",
        ),
    )

    for point_index in 1:point_count
        leaf_area_density_value = leaf_area_density[point_index]
        representative_volume = representative_volumes[point_index]
        source_layer = physiological_layers[point_index]
        isfinite(leaf_area_density_value) || throw(
            ArgumentError("leaf_area_density values must be finite"),
        )
        leaf_area_density_value >= zero(T) || throw(
            DomainError(
                leaf_area_density_value,
                "leaf_area_density values must be non-negative",
            ),
        )
        isfinite(representative_volume) || throw(
            ArgumentError("representative_volumes values must be finite"),
        )
        representative_volume >= zero(T) || throw(
            DomainError(
                representative_volume,
                "representative_volumes values must be non-negative",
            ),
        )
        source_layer isa Bool && throw(
            ArgumentError("physiological_layers values must not be Bool"),
        )
        layer = Int(source_layer)
        1 <= layer <= layer_count || throw(
            DomainError(
                layer,
                "physiological_layers values must lie within the output layers",
            ),
        )
    end
    return nothing
end

function _fill_crown_layer_leaf_area!(
    layer_leaf_area_m2::AbstractVector{T},
    leaf_area_density::AbstractVector{T},
    representative_volumes::AbstractVector{T},
    physiological_layers::AbstractVector{<:Integer},
) where {T<:AbstractFloat}
    fill!(layer_leaf_area_m2, zero(T))
    for point_index in eachindex(leaf_area_density)
        layer = Int(physiological_layers[point_index])
        point_leaf_area =
            leaf_area_density[point_index] * representative_volumes[point_index]
        layer_leaf_area_m2[layer] += point_leaf_area
    end
    return nothing
end

function _validate_crown_shortwave_buffers(
    layer_leaf_area_m2::AbstractVector{T},
    absorbed_par_by_layer_w::AbstractVector{T},
    absorbed_nir_by_layer_w::AbstractVector{T},
    absorbed_par_by_layer_umol_s::AbstractVector{T},
    mean_absorbed_par_by_layer_w_m2_leaf::AbstractVector{T},
    mean_absorbed_nir_by_layer_w_m2_leaf::AbstractVector{T},
    mean_absorbed_par_by_layer_umol_m2_leaf_s::AbstractVector{T},
    layer_shortwave_mean_available::AbstractVector{Bool},
) where {T<:AbstractFloat}
    Base.require_one_based_indexing(
        absorbed_par_by_layer_w,
        absorbed_nir_by_layer_w,
        absorbed_par_by_layer_umol_s,
        mean_absorbed_par_by_layer_w_m2_leaf,
        mean_absorbed_nir_by_layer_w_m2_leaf,
        mean_absorbed_par_by_layer_umol_m2_leaf_s,
        layer_shortwave_mean_available,
    )
    layer_count = length(layer_leaf_area_m2)
    length(absorbed_par_by_layer_w) == layer_count || throw(
        DimensionMismatch("absorbed_par_by_layer_w has the wrong length"),
    )
    length(absorbed_nir_by_layer_w) == layer_count || throw(
        DimensionMismatch("absorbed_nir_by_layer_w has the wrong length"),
    )
    length(absorbed_par_by_layer_umol_s) == layer_count || throw(
        DimensionMismatch(
            "absorbed_par_by_layer_umol_s has the wrong length",
        ),
    )
    length(mean_absorbed_par_by_layer_w_m2_leaf) == layer_count || throw(
        DimensionMismatch(
            "mean_absorbed_par_by_layer_w_m2_leaf has the wrong length",
        ),
    )
    length(mean_absorbed_nir_by_layer_w_m2_leaf) == layer_count || throw(
        DimensionMismatch(
            "mean_absorbed_nir_by_layer_w_m2_leaf has the wrong length",
        ),
    )
    length(mean_absorbed_par_by_layer_umol_m2_leaf_s) == layer_count || throw(
        DimensionMismatch(
            "mean_absorbed_par_by_layer_umol_m2_leaf_s has the wrong length",
        ),
    )
    length(layer_shortwave_mean_available) == layer_count || throw(
        DimensionMismatch(
            "layer_shortwave_mean_available has the wrong length",
        ),
    )
    return nothing
end

function _validate_crown_shortwave_inputs(
    leaf_radiation_area_fraction::AbstractMatrix{T},
    leaf_radiation_absorbed_par_w_m2_leaf::AbstractMatrix{T},
    leaf_radiation_absorbed_nir_w_m2_leaf::AbstractMatrix{T},
    point_count::Int,
    active_leaf_radiation_class_count::Integer,
) where {T<:AbstractFloat}
    Base.require_one_based_indexing(
        leaf_radiation_area_fraction,
        leaf_radiation_absorbed_par_w_m2_leaf,
        leaf_radiation_absorbed_nir_w_m2_leaf,
    )
    matrix_size = size(leaf_radiation_area_fraction)
    size(leaf_radiation_absorbed_par_w_m2_leaf) == matrix_size || throw(
        DimensionMismatch(
            "leaf PAR radiation and class-fraction matrices must have the same size",
        ),
    )
    size(leaf_radiation_absorbed_nir_w_m2_leaf) == matrix_size || throw(
        DimensionMismatch(
            "leaf NIR radiation and class-fraction matrices must have the same size",
        ),
    )
    size(leaf_radiation_area_fraction, 1) == point_count || throw(
        DimensionMismatch(
            "leaf-radiation matrices must contain $point_count point rows",
        ),
    )
    active_leaf_radiation_class_count isa Bool && throw(
        ArgumentError(
            "active_leaf_radiation_class_count must be an integer, not Bool",
        ),
    )
    active_count = Int(active_leaf_radiation_class_count)
    1 <= active_count <= size(leaf_radiation_area_fraction, 2) || throw(
        DomainError(
            active_count,
            "active_leaf_radiation_class_count must lie within the class slots",
        ),
    )

    fraction_tolerance = max(T(1.0e-4), T(20) * eps(T))
    for point_index in 1:point_count
        fraction_sum = zero(T)
        for class_index in 1:active_count
            fraction = leaf_radiation_area_fraction[point_index, class_index]
            absorbed_par = leaf_radiation_absorbed_par_w_m2_leaf[
                point_index,
                class_index,
            ]
            absorbed_nir = leaf_radiation_absorbed_nir_w_m2_leaf[
                point_index,
                class_index,
            ]
            isfinite(fraction) || throw(
                ArgumentError("active leaf-radiation fractions must be finite"),
            )
            zero(T) <= fraction <= one(T) || throw(
                DomainError(
                    fraction,
                    "active leaf-radiation fractions must lie in [0, 1]",
                ),
            )
            isfinite(absorbed_par) || throw(
                ArgumentError("absorbed PAR values must be finite"),
            )
            absorbed_par >= zero(T) || throw(
                DomainError(
                    absorbed_par,
                    "absorbed PAR values must be non-negative",
                ),
            )
            isfinite(absorbed_nir) || throw(
                ArgumentError("absorbed NIR values must be finite"),
            )
            absorbed_nir >= zero(T) || throw(
                DomainError(
                    absorbed_nir,
                    "absorbed NIR values must be non-negative",
                ),
            )
            fraction_sum += fraction
        end
        isapprox(
            fraction_sum,
            one(T);
            atol=fraction_tolerance,
            rtol=fraction_tolerance,
        ) || throw(
            ArgumentError(
                "active leaf-radiation fractions must sum to one at every point",
            ),
        )
    end
    return active_count
end

"""
    crown_radiation_aggregation!(...; umol_per_joule=4.57)

Aggregate the shortwave leaf classes emitted by `MODELSS` first into
physiological layers and then into a Crown. For point `i` and class `c`, the
represented leaf area is

`class_fraction[i,c] * leaf_area_density[i] * representative_volume[i]`.

PAR and NIR inputs are W m⁻² of leaf; layer and Crown totals are W. Layer means
return to W m⁻² of leaf. Both total and mean PAR are also exposed in the
historical photon units using the configurable, typed `4.57` µmol J⁻¹ factor.
An empty physiological layer has zero means and a false availability entry.

Only active class columns are read. This is deliberate because `MODELSS` uses
fixed-size buffers whose inactive columns are not part of the current state.
"""
function crown_radiation_aggregation!(
    layer_leaf_area_m2::AbstractVector{T},
    absorbed_par_by_layer_w::AbstractVector{T},
    absorbed_nir_by_layer_w::AbstractVector{T},
    absorbed_par_by_layer_umol_s::AbstractVector{T},
    mean_absorbed_par_by_layer_w_m2_leaf::AbstractVector{T},
    mean_absorbed_nir_by_layer_w_m2_leaf::AbstractVector{T},
    mean_absorbed_par_by_layer_umol_m2_leaf_s::AbstractVector{T},
    layer_shortwave_mean_available::AbstractVector{Bool},
    leaf_radiation_area_fraction::AbstractMatrix{T},
    leaf_radiation_absorbed_par_w_m2_leaf::AbstractMatrix{T},
    leaf_radiation_absorbed_nir_w_m2_leaf::AbstractMatrix{T},
    leaf_area_density::AbstractVector{T},
    representative_volumes::AbstractVector{T},
    physiological_layers::AbstractVector{<:Integer},
    active_leaf_radiation_class_count::Integer;
    umol_per_joule::Real=T(4.57),
) where {T<:AbstractFloat}
    fill!(layer_leaf_area_m2, zero(T))
    fill!(absorbed_par_by_layer_w, zero(T))
    fill!(absorbed_nir_by_layer_w, zero(T))
    fill!(absorbed_par_by_layer_umol_s, zero(T))
    fill!(mean_absorbed_par_by_layer_w_m2_leaf, zero(T))
    fill!(mean_absorbed_nir_by_layer_w_m2_leaf, zero(T))
    fill!(mean_absorbed_par_by_layer_umol_m2_leaf_s, zero(T))
    fill!(layer_shortwave_mean_available, false)

    _validate_crown_radiation_geometry(
        layer_leaf_area_m2,
        leaf_area_density,
        representative_volumes,
        physiological_layers,
    )
    _validate_crown_shortwave_buffers(
        layer_leaf_area_m2,
        absorbed_par_by_layer_w,
        absorbed_nir_by_layer_w,
        absorbed_par_by_layer_umol_s,
        mean_absorbed_par_by_layer_w_m2_leaf,
        mean_absorbed_nir_by_layer_w_m2_leaf,
        mean_absorbed_par_by_layer_umol_m2_leaf_s,
        layer_shortwave_mean_available,
    )
    active_count = _validate_crown_shortwave_inputs(
        leaf_radiation_area_fraction,
        leaf_radiation_absorbed_par_w_m2_leaf,
        leaf_radiation_absorbed_nir_w_m2_leaf,
        length(leaf_area_density),
        active_leaf_radiation_class_count,
    )
    conversion = _crown_radiation_float(
        T,
        umol_per_joule,
        "umol_per_joule",
    )
    conversion > zero(T) || throw(
        DomainError(conversion, "umol_per_joule must be positive"),
    )

    for point_index in eachindex(leaf_area_density)
        layer = Int(physiological_layers[point_index])
        point_leaf_area =
            leaf_area_density[point_index] * representative_volumes[point_index]
        layer_leaf_area_m2[layer] += point_leaf_area
        point_par_w_m2_leaf = zero(T)
        point_nir_w_m2_leaf = zero(T)
        for class_index in 1:active_count
            class_fraction =
                leaf_radiation_area_fraction[point_index, class_index]
            point_par_w_m2_leaf = muladd(
                class_fraction,
                leaf_radiation_absorbed_par_w_m2_leaf[
                    point_index,
                    class_index,
                ],
                point_par_w_m2_leaf,
            )
            point_nir_w_m2_leaf = muladd(
                class_fraction,
                leaf_radiation_absorbed_nir_w_m2_leaf[
                    point_index,
                    class_index,
                ],
                point_nir_w_m2_leaf,
            )
        end
        absorbed_par_by_layer_w[layer] = muladd(
            point_par_w_m2_leaf,
            point_leaf_area,
            absorbed_par_by_layer_w[layer],
        )
        absorbed_nir_by_layer_w[layer] = muladd(
            point_nir_w_m2_leaf,
            point_leaf_area,
            absorbed_nir_by_layer_w[layer],
        )
    end

    absorbed_par_crown_w = zero(T)
    absorbed_nir_crown_w = zero(T)
    for layer in eachindex(layer_leaf_area_m2)
        layer_area = layer_leaf_area_m2[layer]
        layer_par_w = absorbed_par_by_layer_w[layer]
        layer_nir_w = absorbed_nir_by_layer_w[layer]
        absorbed_par_by_layer_umol_s[layer] = layer_par_w * conversion
        if layer_area > zero(T)
            mean_par_w_m2_leaf = layer_par_w / layer_area
            mean_absorbed_par_by_layer_w_m2_leaf[layer] = mean_par_w_m2_leaf
            mean_absorbed_nir_by_layer_w_m2_leaf[layer] = layer_nir_w / layer_area
            mean_absorbed_par_by_layer_umol_m2_leaf_s[layer] =
                mean_par_w_m2_leaf * conversion
            layer_shortwave_mean_available[layer] = true
        end
        absorbed_par_crown_w += layer_par_w
        absorbed_nir_crown_w += layer_nir_w
    end
    return CrownRadiationAggregationTotals(
        absorbed_par_crown_w,
        absorbed_nir_crown_w,
        absorbed_par_crown_w * conversion,
    )
end

"""Allocate and evaluate the shortwave Crown radiation aggregation."""
function crown_radiation_aggregation(
    leaf_radiation_area_fraction::AbstractMatrix{T},
    leaf_radiation_absorbed_par_w_m2_leaf::AbstractMatrix{T},
    leaf_radiation_absorbed_nir_w_m2_leaf::AbstractMatrix{T},
    leaf_area_density::AbstractVector{T},
    representative_volumes::AbstractVector{T},
    physiological_layers::AbstractVector{<:Integer},
    active_leaf_radiation_class_count::Integer;
    layer_count::Integer=_crown_radiation_maximum_layer(physiological_layers),
    umol_per_joule::Real=T(4.57),
) where {T<:AbstractFloat}
    layers = _crown_radiation_positive_count(layer_count, "layer_count")
    layer_leaf_area_m2 = zeros(T, layers)
    absorbed_par_by_layer_w = zeros(T, layers)
    absorbed_nir_by_layer_w = zeros(T, layers)
    absorbed_par_by_layer_umol_s = zeros(T, layers)
    mean_absorbed_par_by_layer_w_m2_leaf = zeros(T, layers)
    mean_absorbed_nir_by_layer_w_m2_leaf = zeros(T, layers)
    mean_absorbed_par_by_layer_umol_m2_leaf_s = zeros(T, layers)
    layer_shortwave_mean_available = fill(false, layers)
    totals = crown_radiation_aggregation!(
        layer_leaf_area_m2,
        absorbed_par_by_layer_w,
        absorbed_nir_by_layer_w,
        absorbed_par_by_layer_umol_s,
        mean_absorbed_par_by_layer_w_m2_leaf,
        mean_absorbed_nir_by_layer_w_m2_leaf,
        mean_absorbed_par_by_layer_umol_m2_leaf_s,
        layer_shortwave_mean_available,
        leaf_radiation_area_fraction,
        leaf_radiation_absorbed_par_w_m2_leaf,
        leaf_radiation_absorbed_nir_w_m2_leaf,
        leaf_area_density,
        representative_volumes,
        physiological_layers,
        active_leaf_radiation_class_count;
        umol_per_joule,
    )
    return CrownRadiationAggregationResult(
        layer_leaf_area_m2,
        absorbed_par_by_layer_w,
        absorbed_nir_by_layer_w,
        absorbed_par_by_layer_umol_s,
        mean_absorbed_par_by_layer_w_m2_leaf,
        mean_absorbed_nir_by_layer_w_m2_leaf,
        mean_absorbed_par_by_layer_umol_m2_leaf_s,
        layer_shortwave_mean_available,
        totals.absorbed_par_crown_w,
        totals.absorbed_nir_crown_w,
        totals.absorbed_par_crown_umol_s,
    )
end

function _validate_crown_thermal_inputs(
    absorbed_thermal_by_layer_w::AbstractVector{T},
    mean_absorbed_thermal_by_layer_w_m2_leaf::AbstractVector{T},
    layer_thermal_mean_available::AbstractVector{Bool},
    absorbed_thermal_w_m2_leaf::AbstractVector{T},
    point_count::Int,
    layer_count::Int,
) where {T<:AbstractFloat}
    Base.require_one_based_indexing(
        absorbed_thermal_by_layer_w,
        mean_absorbed_thermal_by_layer_w_m2_leaf,
        layer_thermal_mean_available,
        absorbed_thermal_w_m2_leaf,
    )
    length(absorbed_thermal_by_layer_w) == layer_count || throw(
        DimensionMismatch("absorbed_thermal_by_layer_w has the wrong length"),
    )
    length(mean_absorbed_thermal_by_layer_w_m2_leaf) == layer_count || throw(
        DimensionMismatch(
            "mean_absorbed_thermal_by_layer_w_m2_leaf has the wrong length",
        ),
    )
    length(layer_thermal_mean_available) == layer_count || throw(
        DimensionMismatch("layer_thermal_mean_available has the wrong length"),
    )
    length(absorbed_thermal_w_m2_leaf) == point_count || throw(
        DimensionMismatch(
            "absorbed_thermal_w_m2_leaf must contain $point_count values",
        ),
    )
    for thermal_flux in absorbed_thermal_w_m2_leaf
        isfinite(thermal_flux) || throw(
            ArgumentError("absorbed thermal radiation values must be finite"),
        )
    end
    return nothing
end

function _crown_thermal_radiation_aggregation!(
    absorbed_thermal_by_layer_w::AbstractVector{T},
    mean_absorbed_thermal_by_layer_w_m2_leaf::AbstractVector{T},
    layer_thermal_mean_available::AbstractVector{Bool},
    absorbed_thermal_w_m2_leaf::AbstractVector{T},
    leaf_area_density::AbstractVector{T},
    representative_volumes::AbstractVector{T},
    physiological_layers::AbstractVector{<:Integer},
    layer_leaf_area_m2::AbstractVector{T},
) where {T<:AbstractFloat}
    fill!(absorbed_thermal_by_layer_w, zero(T))
    fill!(mean_absorbed_thermal_by_layer_w_m2_leaf, zero(T))
    fill!(layer_thermal_mean_available, false)
    for point_index in eachindex(absorbed_thermal_w_m2_leaf)
        layer = Int(physiological_layers[point_index])
        point_leaf_area =
            leaf_area_density[point_index] * representative_volumes[point_index]
        absorbed_thermal_by_layer_w[layer] = muladd(
            absorbed_thermal_w_m2_leaf[point_index],
            point_leaf_area,
            absorbed_thermal_by_layer_w[layer],
        )
    end
    absorbed_thermal_crown_w = zero(T)
    for layer in eachindex(layer_leaf_area_m2)
        layer_area = layer_leaf_area_m2[layer]
        layer_thermal_w = absorbed_thermal_by_layer_w[layer]
        if layer_area > zero(T)
            mean_absorbed_thermal_by_layer_w_m2_leaf[layer] =
                layer_thermal_w / layer_area
            layer_thermal_mean_available[layer] = true
        end
        absorbed_thermal_crown_w += layer_thermal_w
    end
    return absorbed_thermal_crown_w
end

"""
PlantSimEngine application of the Crown radiation aggregation.

The shortwave channel consumes the fixed `MODELSS` buffers. A future ABSRAD
thermal producer can provide `absorbed_thermal_w_m2_leaf` together with
`thermal_absorption_available=true`. Thermal fluxes are signed and are never
clamped. Their outputs have a distinct availability gate; the default zeros
are therefore only storage, never a claimed physical flux.
"""
struct MAESPACrownRadiationAggregation{T<:AbstractFloat} <:
       AbstractCrown_Radiation_AggregationModel
    point_count::Int
    layer_count::Int
    umol_per_joule::T
end

function MAESPACrownRadiationAggregation(
    ::Type{T},
    point_count::Integer,
    layer_count::Integer;
    umol_per_joule::Real=T(4.57),
) where {T<:AbstractFloat}
    points = _crown_radiation_positive_count(point_count, "point_count")
    layers = _crown_radiation_positive_count(layer_count, "layer_count")
    conversion = _crown_radiation_float(T, umol_per_joule, "umol_per_joule")
    conversion > zero(T) || throw(
        DomainError(conversion, "umol_per_joule must be positive"),
    )
    return MAESPACrownRadiationAggregation{T}(points, layers, conversion)
end

function PlantSimEngine.inputs_(
    model::MAESPACrownRadiationAggregation{T},
) where {T}
    return (
        leaf_radiation_area_fraction=PlantSimEngine.Required(AbstractMatrix),
        leaf_radiation_absorbed_par_w_m2_leaf=PlantSimEngine.Required(
            AbstractMatrix,
        ),
        leaf_radiation_absorbed_nir_w_m2_leaf=PlantSimEngine.Required(
            AbstractMatrix,
        ),
        active_leaf_radiation_class_count=PlantSimEngine.Required(Integer),
        leaf_radiation_partitioning_available=PlantSimEngine.Required(Bool),
        leaf_area_density=PlantSimEngine.Required(AbstractVector),
        representative_volumes=PlantSimEngine.Required(AbstractVector),
        physiological_layers=PlantSimEngine.Required(AbstractVector),
        absorbed_thermal_w_m2_leaf=PlantSimEngine.Default(
            zeros(T, model.point_count),
        ),
        thermal_absorption_available=PlantSimEngine.Default(false),
    )
end

PlantSimEngine.variable_contracts_(::MAESPACrownRadiationAggregation) =
    LEAF_RADIATION_PARTITION_CONTRACTS

function PlantSimEngine.outputs_(
    model::MAESPACrownRadiationAggregation{T},
) where {T}
    layers = model.layer_count
    return (
        layer_leaf_area_m2=zeros(T, layers),
        absorbed_par_by_layer_w=zeros(T, layers),
        absorbed_nir_by_layer_w=zeros(T, layers),
        absorbed_par_by_layer_umol_s=zeros(T, layers),
        mean_absorbed_par_by_layer_w_m2_leaf=zeros(T, layers),
        mean_absorbed_nir_by_layer_w_m2_leaf=zeros(T, layers),
        mean_absorbed_par_by_layer_umol_m2_leaf_s=zeros(T, layers),
        layer_shortwave_mean_available=fill(false, layers),
        absorbed_par_crown_w=zero(T),
        absorbed_nir_crown_w=zero(T),
        absorbed_par_crown_umol_s=zero(T),
        crown_radiation_aggregation_available=false,
        absorbed_thermal_by_layer_w=zeros(T, layers),
        mean_absorbed_thermal_by_layer_w_m2_leaf=zeros(T, layers),
        layer_thermal_mean_available=fill(false, layers),
        absorbed_thermal_crown_w=zero(T),
        crown_thermal_radiation_aggregation_available=false,
    )
end

function _reset_crown_radiation_aggregation_outputs!(
    status,
    ::Type{T},
) where {T<:AbstractFloat}
    fill!(status.layer_leaf_area_m2, zero(T))
    fill!(status.absorbed_par_by_layer_w, zero(T))
    fill!(status.absorbed_nir_by_layer_w, zero(T))
    fill!(status.absorbed_par_by_layer_umol_s, zero(T))
    fill!(status.mean_absorbed_par_by_layer_w_m2_leaf, zero(T))
    fill!(status.mean_absorbed_nir_by_layer_w_m2_leaf, zero(T))
    fill!(status.mean_absorbed_par_by_layer_umol_m2_leaf_s, zero(T))
    fill!(status.layer_shortwave_mean_available, false)
    status.absorbed_par_crown_w = zero(T)
    status.absorbed_nir_crown_w = zero(T)
    status.absorbed_par_crown_umol_s = zero(T)
    status.crown_radiation_aggregation_available = false
    fill!(status.absorbed_thermal_by_layer_w, zero(T))
    fill!(status.mean_absorbed_thermal_by_layer_w_m2_leaf, zero(T))
    fill!(status.layer_thermal_mean_available, false)
    status.absorbed_thermal_crown_w = zero(T)
    status.crown_thermal_radiation_aggregation_available = false
    return nothing
end

@noinline function _throw_crown_radiation_eltype(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and Crown radiation output buffers must share a numeric type",
        ),
    )
end

@inline function _require_crown_radiation_eltype(
    values,
    ::Type{T},
    name::Symbol,
) where {T<:AbstractFloat}
    eltype(values) === T || _throw_crown_radiation_eltype(name)
    return nothing
end

@noinline function _throw_crown_radiation_point_count(
    name::Symbol,
    point_count::Int,
)
    throw(
        DimensionMismatch(
            "$(String(name)) must contain $point_count representative points",
        ),
    )
end

@inline function _require_crown_radiation_point_count(
    values,
    point_count::Int,
    name::Symbol,
)
    length(values) == point_count ||
        _throw_crown_radiation_point_count(name, point_count)
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPACrownRadiationAggregation,
    status,
    environment,
    constants,
    context,
)
    T = eltype(status.layer_leaf_area_m2)
    _reset_crown_radiation_aggregation_outputs!(status, T)

    _require_crown_radiation_eltype(
        status.absorbed_par_by_layer_w,
        T,
        :absorbed_par_by_layer_w,
    )
    _require_crown_radiation_eltype(
        status.absorbed_nir_by_layer_w,
        T,
        :absorbed_nir_by_layer_w,
    )
    _require_crown_radiation_eltype(
        status.absorbed_par_by_layer_umol_s,
        T,
        :absorbed_par_by_layer_umol_s,
    )
    _require_crown_radiation_eltype(
        status.mean_absorbed_par_by_layer_w_m2_leaf,
        T,
        :mean_absorbed_par_by_layer_w_m2_leaf,
    )
    _require_crown_radiation_eltype(
        status.mean_absorbed_nir_by_layer_w_m2_leaf,
        T,
        :mean_absorbed_nir_by_layer_w_m2_leaf,
    )
    _require_crown_radiation_eltype(
        status.mean_absorbed_par_by_layer_umol_m2_leaf_s,
        T,
        :mean_absorbed_par_by_layer_umol_m2_leaf_s,
    )
    _require_crown_radiation_eltype(
        status.absorbed_thermal_by_layer_w,
        T,
        :absorbed_thermal_by_layer_w,
    )
    _require_crown_radiation_eltype(
        status.mean_absorbed_thermal_by_layer_w_m2_leaf,
        T,
        :mean_absorbed_thermal_by_layer_w_m2_leaf,
    )
    status.layer_shortwave_mean_available isa AbstractVector{Bool} || throw(
        ArgumentError("layer_shortwave_mean_available must contain Bool values"),
    )
    status.layer_thermal_mean_available isa AbstractVector{Bool} || throw(
        ArgumentError("layer_thermal_mean_available must contain Bool values"),
    )

    shortwave_available = status.leaf_radiation_partitioning_available
    thermal_available = status.thermal_absorption_available
    shortwave_available isa Bool || throw(
        ArgumentError("leaf_radiation_partitioning_available must be Bool"),
    )
    thermal_available isa Bool || throw(
        ArgumentError("thermal_absorption_available must be Bool"),
    )
    if !shortwave_available && !thermal_available
        return nothing
    end

    _require_crown_radiation_eltype(
        status.leaf_area_density,
        T,
        :leaf_area_density,
    )
    _require_crown_radiation_eltype(
        status.representative_volumes,
        T,
        :representative_volumes,
    )
    _require_crown_radiation_point_count(
        status.leaf_area_density,
        model.point_count,
        :leaf_area_density,
    )
    _require_crown_radiation_point_count(
        status.representative_volumes,
        model.point_count,
        :representative_volumes,
    )
    _require_crown_radiation_point_count(
        status.physiological_layers,
        model.point_count,
        :physiological_layers,
    )

    if shortwave_available
        _require_crown_radiation_eltype(
            status.leaf_radiation_area_fraction,
            T,
            :leaf_radiation_area_fraction,
        )
        _require_crown_radiation_eltype(
            status.leaf_radiation_absorbed_par_w_m2_leaf,
            T,
            :leaf_radiation_absorbed_par_w_m2_leaf,
        )
        _require_crown_radiation_eltype(
            status.leaf_radiation_absorbed_nir_w_m2_leaf,
            T,
            :leaf_radiation_absorbed_nir_w_m2_leaf,
        )
        size(status.leaf_radiation_area_fraction, 1) == model.point_count ||
            _throw_crown_radiation_point_count(
                :leaf_radiation_area_fraction,
                model.point_count,
            )
    end
    if thermal_available
        _require_crown_radiation_eltype(
            status.absorbed_thermal_w_m2_leaf,
            T,
            :absorbed_thermal_w_m2_leaf,
        )
        _require_crown_radiation_point_count(
            status.absorbed_thermal_w_m2_leaf,
            model.point_count,
            :absorbed_thermal_w_m2_leaf,
        )
    end

    _validate_crown_radiation_geometry(
        status.layer_leaf_area_m2,
        status.leaf_area_density,
        status.representative_volumes,
        status.physiological_layers,
    )
    if thermal_available
        _validate_crown_thermal_inputs(
            status.absorbed_thermal_by_layer_w,
            status.mean_absorbed_thermal_by_layer_w_m2_leaf,
            status.layer_thermal_mean_available,
            status.absorbed_thermal_w_m2_leaf,
            model.point_count,
            model.layer_count,
        )
    end

    if shortwave_available
        active_count = status.active_leaf_radiation_class_count
        active_count isa Integer || throw(
            ArgumentError(
                "active_leaf_radiation_class_count must be an integer",
            ),
        )
        totals = crown_radiation_aggregation!(
            status.layer_leaf_area_m2,
            status.absorbed_par_by_layer_w,
            status.absorbed_nir_by_layer_w,
            status.absorbed_par_by_layer_umol_s,
            status.mean_absorbed_par_by_layer_w_m2_leaf,
            status.mean_absorbed_nir_by_layer_w_m2_leaf,
            status.mean_absorbed_par_by_layer_umol_m2_leaf_s,
            status.layer_shortwave_mean_available,
            status.leaf_radiation_area_fraction,
            status.leaf_radiation_absorbed_par_w_m2_leaf,
            status.leaf_radiation_absorbed_nir_w_m2_leaf,
            status.leaf_area_density,
            status.representative_volumes,
            status.physiological_layers,
            active_count;
            umol_per_joule=_crown_radiation_float(
                T,
                model.umol_per_joule,
                "umol_per_joule",
            ),
        )
        status.absorbed_par_crown_w = totals.absorbed_par_crown_w
        status.absorbed_nir_crown_w = totals.absorbed_nir_crown_w
        status.absorbed_par_crown_umol_s = totals.absorbed_par_crown_umol_s
        status.crown_radiation_aggregation_available = true
    else
        _fill_crown_layer_leaf_area!(
            status.layer_leaf_area_m2,
            status.leaf_area_density,
            status.representative_volumes,
            status.physiological_layers,
        )
    end

    if thermal_available
        status.absorbed_thermal_crown_w =
            _crown_thermal_radiation_aggregation!(
                status.absorbed_thermal_by_layer_w,
                status.mean_absorbed_thermal_by_layer_w_m2_leaf,
                status.layer_thermal_mean_available,
                status.absorbed_thermal_w_m2_leaf,
                status.leaf_area_density,
                status.representative_volumes,
                status.physiological_layers,
                status.layer_leaf_area_m2,
            )
        status.crown_thermal_radiation_aggregation_available = true
    end
    return nothing
end
