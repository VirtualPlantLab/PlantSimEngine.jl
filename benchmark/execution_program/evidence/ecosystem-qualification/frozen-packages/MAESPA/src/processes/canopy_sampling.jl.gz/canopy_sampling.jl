PlantSimEngine.@process "canopy_sampling" verbose = false
PlantSimEngine.@process "leaf_area_distribution" verbose = false

function _positive_canopy_count(value::Integer, name::AbstractString)
    value isa Bool && throw(ArgumentError("$name must be an integer, not Bool"))
    value > 0 || throw(ArgumentError("$name must be positive"))
    return Int(value)
end

function _canopy_discretisation(nolay::Integer, pplay::Integer)
    layer_count = _positive_canopy_count(nolay, "nolay")
    points_per_layer = _positive_canopy_count(pplay, "pplay")
    points_per_layer % 4 == 0 || throw(
        ArgumentError("pplay must be divisible by four to reproduce POINTSNEW"),
    )
    return (
        nolay=layer_count,
        pplay=points_per_layer,
        ppq=points_per_layer ÷ 4,
        point_count=Base.checked_mul(layer_count, points_per_layer),
    )
end

function _crown_shape_code(shape_code::Integer)
    shape_code isa Bool && throw(
        ArgumentError("crown_shape_code must be an integer, not Bool"),
    )
    1 <= shape_code <= 6 || throw(
        ArgumentError("crown_shape_code must be in 1:6, got $shape_code"),
    )
    return Int(shape_code)
end

function _finite_canopy_value(value::T, name::AbstractString) where {T<:AbstractFloat}
    isfinite(value) || throw(ArgumentError("$name must be finite"))
    return value
end

function _canopy_float(
    ::Type{T},
    value::Real,
    name::AbstractString,
) where {T<:AbstractFloat}
    value isa Bool && throw(ArgumentError("$name must be numeric, not Bool"))
    return _finite_canopy_value(convert(T, value), name)
end

function _positive_canopy_value(value::T, name::AbstractString) where {T<:AbstractFloat}
    _finite_canopy_value(value, name)
    value > zero(T) || throw(ArgumentError("$name must be positive"))
    return value
end

"""
    radial_midpoints!(output, count)

Fill `output` with the radial positions used by MAESPA's `AXVOL`. The points
are the midpoints between successive radii delimiting equal-area annuli in one
quadrant.
"""
function radial_midpoints!(
    output::AbstractVector{T},
    count::Integer,
) where {T<:AbstractFloat}
    radial_count = _positive_canopy_count(count, "count")
    length(output) == radial_count || throw(
        DimensionMismatch(
            "output length $(length(output)) does not match count=$radial_count",
        ),
    )

    half = one(T) / T(2)
    previous_radius = zero(T)
    for (radial_index, output_index) in enumerate(eachindex(output))
        radius = sqrt(T(radial_index) / T(radial_count))
        output[output_index] = radial_index == 1 ?
                               half * radius :
                               radius - half * (radius - previous_radius)
        previous_radius = radius
    end
    return output
end

"""Allocate the typed radial midpoint vector used by MAESPA's `AXVOL`."""
function radial_midpoints(
    ::Type{T},
    count::Integer,
) where {T<:AbstractFloat}
    radial_count = _positive_canopy_count(count, "count")
    return radial_midpoints!(Vector{T}(undef, radial_count), radial_count)
end

@inline function _crown_surface_factor(
    relative_height::T,
    shape_code::Int,
) where {T<:AbstractFloat}
    if shape_code == 1
        return one(T) - relative_height
    elseif shape_code == 2
        return sqrt(one(T) - relative_height * relative_height)
    elseif shape_code == 3
        return sqrt(one(T) - relative_height)
    elseif shape_code == 4
        centred = relative_height - one(T) / T(2)
        half = one(T) / T(2)
        return sqrt(one(T) - (centred * centred) / (half * half))
    end
    return one(T)
end

"""
    crown_surface_factor(relative_height, crown_shape_code)

Return MAESPA's `SURFACE` radius factor at a relative crown height in `[0, 1]`.
Shape codes `1:6` respectively mean cone, half ellipsoid, paraboloid, full
ellipsoid, cylinder, and box.
"""
function crown_surface_factor(
    relative_height::T,
    crown_shape_code::Integer,
) where {T<:AbstractFloat}
    _finite_canopy_value(relative_height, "relative_height")
    zero(T) <= relative_height <= one(T) || throw(
        DomainError(relative_height, "relative_height must lie in [0, 1]"),
    )
    return _crown_surface_factor(
        relative_height,
        _crown_shape_code(crown_shape_code),
    )
end

@inline function _crown_cumulative_volume(
    height::T,
    radius_x::T,
    radius_y::T,
    crown_depth::T,
    shape_code::Int,
) where {T<:AbstractFloat}
    pi_value = T(π)
    if shape_code == 1
        return pi_value * radius_x * radius_y * (
            height - height * height / crown_depth +
            height * height * height / (T(3) * crown_depth * crown_depth)
        )
    elseif shape_code == 2
        return pi_value * radius_x * radius_y * (
            height - height * height * height /
                     (T(3) * crown_depth * crown_depth)
        )
    elseif shape_code == 3
        return pi_value * radius_x * radius_y * (
            height - height * height / (T(2) * crown_depth)
        )
    elseif shape_code == 4
        half_depth = crown_depth / T(2)
        centred = height - half_depth
        return pi_value * radius_x * radius_y * (
            height - centred * centred * centred /
                     (T(3) * half_depth * half_depth)
        )
    elseif shape_code == 5
        return pi_value * radius_x * radius_y * height
    end
    return T(4) * radius_x * radius_y * height
end

"""
    crown_segment_volume(crown_shape_code, upper_height, lower_height,
                         radius_x, radius_y, crown_depth)

Return the crown volume between two heights measured from the crown base. This
is the generic Julia form of MAESPA's `SEGMT` for all six historical shapes.
"""
function crown_segment_volume(
    crown_shape_code::Integer,
    upper_height::T,
    lower_height::T,
    radius_x::T,
    radius_y::T,
    crown_depth::T,
) where {T<:AbstractFloat}
    shape_code = _crown_shape_code(crown_shape_code)
    _finite_canopy_value(upper_height, "upper_height")
    _finite_canopy_value(lower_height, "lower_height")
    _positive_canopy_value(radius_x, "radius_x")
    _positive_canopy_value(radius_y, "radius_y")
    _positive_canopy_value(crown_depth, "crown_depth")
    zero(T) <= lower_height <= upper_height <= crown_depth || throw(
        DomainError(
            (lower_height, upper_height),
            "segment heights must satisfy 0 ≤ lower ≤ upper ≤ crown_depth",
        ),
    )
    upper_volume = _crown_cumulative_volume(
        upper_height,
        radius_x,
        radius_y,
        crown_depth,
        shape_code,
    )
    lower_volume = _crown_cumulative_volume(
        lower_height,
        radius_x,
        radius_y,
        crown_depth,
        shape_code,
    )
    return upper_volume - lower_volume
end

function _validate_quadrature_output_lengths(
    point_count::Int,
    representative_x,
    representative_y,
    representative_z,
    representative_relative_heights,
    representative_volumes,
    physiological_layers,
)
    for (name, output) in (
        ("representative_x", representative_x),
        ("representative_y", representative_y),
        ("representative_z", representative_z),
        ("representative_relative_heights", representative_relative_heights),
        ("representative_volumes", representative_volumes),
        ("physiological_layers", physiological_layers),
    )
        length(output) == point_count || throw(
            DimensionMismatch(
                "$name length $(length(output)) does not match $point_count canopy points",
            ),
        )
    end
    return nothing
end

function _crown_quadrature!(
    representative_x::AbstractVector{T},
    representative_y::AbstractVector{T},
    representative_z::AbstractVector{T},
    representative_relative_heights::AbstractVector{T},
    representative_volumes::AbstractVector{T},
    physiological_layers::AbstractVector{<:Integer},
    tree_x_m::T,
    tree_y_m::T,
    tree_z_m::T,
    radius_x::T,
    radius_y::T,
    crown_depth::T,
    crown_base_height::T,
    crown_shape_code::Integer,
    nolay::Integer,
    pplay::Integer,
) where {T<:AbstractFloat}
    grid = _canopy_discretisation(nolay, pplay)
    _validate_quadrature_output_lengths(
        grid.point_count,
        representative_x,
        representative_y,
        representative_z,
        representative_relative_heights,
        representative_volumes,
        physiological_layers,
    )
    _finite_canopy_value(tree_x_m, "tree_x_m")
    _finite_canopy_value(tree_y_m, "tree_y_m")
    _finite_canopy_value(tree_z_m, "tree_z_m")
    _positive_canopy_value(radius_x, "radius_x")
    _positive_canopy_value(radius_y, "radius_y")
    _positive_canopy_value(crown_depth, "crown_depth")
    _finite_canopy_value(crown_base_height, "crown_base_height")
    shape_code = _crown_shape_code(crown_shape_code)

    radius_x_squared = radius_x * radius_x
    radius_y_squared = radius_y * radius_y
    diagonal_radius = if shape_code == 6
        sqrt(radius_x_squared + radius_y_squared)
    else
        sqrt(
            T(2) * (radius_x_squared * radius_y_squared) /
            (radius_x_squared + radius_y_squared),
        )
    end
    quadrant_count = grid.point_count ÷ 4
    half = one(T) / T(2)

    for layer in 1:grid.nolay
        relative_height = (T(layer) - half) / T(grid.nolay)
        surface_factor = _crown_surface_factor(relative_height, shape_code)
        odd_layer = isodd(layer)
        radial_correction = if odd_layer
            surface_factor
        elseif shape_code == 6
            radius_x / diagonal_radius * surface_factor
        else
            half * sqrt(T(2)) * surface_factor
        end
        diagonal_y_correction = shape_code == 6 ? radius_y / radius_x : one(T)
        lower_height = T(layer - 1) / T(grid.nolay) * crown_depth
        upper_height = T(layer) / T(grid.nolay) * crown_depth
        point_volume = crown_segment_volume(
            shape_code,
            upper_height,
            lower_height,
            radius_x,
            radius_y,
            crown_depth,
        ) / T(grid.pplay)
        physiological_layer = grid.nolay - layer + 1
        absolute_z = relative_height * crown_depth + crown_base_height + tree_z_m

        previous_radius = zero(T)
        for radial_index in 1:grid.ppq
            radius = sqrt(T(radial_index) / T(grid.ppq))
            radial_midpoint = radial_index == 1 ?
                              half * radius :
                              radius - half * (radius - previous_radius)
            previous_radius = radius
            axial_distance = radial_midpoint * radial_correction

            quadrant_one = (layer - 1) * grid.ppq + radial_index
            quadrant_two = quadrant_one + quadrant_count
            quadrant_three = quadrant_two + quadrant_count
            quadrant_four = quadrant_three + quadrant_count

            if odd_layer
                x_distance = axial_distance * radius_x
                y_distance = axial_distance * radius_y
                representative_x[quadrant_one] = tree_x_m + x_distance
                representative_y[quadrant_one] = tree_y_m
                representative_x[quadrant_two] = tree_x_m
                representative_y[quadrant_two] = tree_y_m + y_distance
                representative_x[quadrant_three] = tree_x_m - x_distance
                representative_y[quadrant_three] = tree_y_m
                representative_x[quadrant_four] = tree_x_m
                representative_y[quadrant_four] = tree_y_m - y_distance
            else
                x_distance = axial_distance * diagonal_radius
                y_distance = x_distance * diagonal_y_correction
                representative_x[quadrant_one] = tree_x_m + x_distance
                representative_y[quadrant_one] = tree_y_m + y_distance
                representative_x[quadrant_two] = tree_x_m - x_distance
                representative_y[quadrant_two] = tree_y_m + y_distance
                representative_x[quadrant_three] = tree_x_m - x_distance
                representative_y[quadrant_three] = tree_y_m - y_distance
                representative_x[quadrant_four] = tree_x_m + x_distance
                representative_y[quadrant_four] = tree_y_m - y_distance
            end

            for point_index in
                (quadrant_one, quadrant_two, quadrant_three, quadrant_four)
                representative_z[point_index] = absolute_z
                representative_relative_heights[point_index] = relative_height
                representative_volumes[point_index] = point_volume
                physiological_layers[point_index] = physiological_layer
            end
        end
    end

    return (
        representative_x=representative_x,
        representative_y=representative_y,
        representative_z=representative_z,
        representative_relative_heights=representative_relative_heights,
        representative_volumes=representative_volumes,
        physiological_layers=physiological_layers,
    )
end

"""
    crown_quadrature(tree_x_m, tree_y_m, tree_z_m, radius_x, radius_y, crown_depth,
                     crown_base_height, crown_shape_code, nolay, pplay)

Allocate the structure-of-arrays representation of MAESPA's `POINTSNEW`
canopy points. Point order is the historical order: all first-quadrant layers,
then the corresponding second-, third-, and fourth-quadrant blocks.
"""
function crown_quadrature(
    tree_x_m::T,
    tree_y_m::T,
    tree_z_m::T,
    radius_x::T,
    radius_y::T,
    crown_depth::T,
    crown_base_height::T,
    crown_shape_code::Integer,
    nolay::Integer,
    pplay::Integer,
) where {T<:AbstractFloat}
    grid = _canopy_discretisation(nolay, pplay)
    representative_x = Vector{T}(undef, grid.point_count)
    representative_y = similar(representative_x)
    representative_z = similar(representative_x)
    representative_relative_heights = similar(representative_x)
    representative_volumes = similar(representative_x)
    physiological_layers = Vector{Int}(undef, grid.point_count)
    return _crown_quadrature!(
        representative_x,
        representative_y,
        representative_z,
        representative_relative_heights,
        representative_volumes,
        physiological_layers,
        tree_x_m,
        tree_y_m,
        tree_z_m,
        radius_x,
        radius_y,
        crown_depth,
        crown_base_height,
        crown_shape_code,
        grid.nolay,
        grid.pplay,
    )
end

function _validate_uniform_lad_outputs(
    point_count::Int,
    physiological_age_count::Int,
    nolay::Int,
    leaf_area_density,
    leaf_area_density_by_age,
    leaf_area_by_layer,
)
    length(leaf_area_density) == point_count || throw(
        DimensionMismatch("leaf_area_density must contain $point_count values"),
    )
    size(leaf_area_density_by_age) == (physiological_age_count, point_count) || throw(
        DimensionMismatch(
            "leaf_area_density_by_age must have size " *
            "($physiological_age_count, $point_count)",
        ),
    )
    length(leaf_area_by_layer) == nolay || throw(
        DimensionMismatch("leaf_area_by_layer must contain $nolay values"),
    )
    return nothing
end

"""
    uniform_leaf_area_distribution!(leaf_area_density,
        leaf_area_density_by_age, leaf_area_by_layer, representative_volumes,
        physiological_layers, leaf_area, physiological_age_proportions,
        leaf_density_legacy_mode)

Fill the Julia equivalents of `DLT`, `DLI`, and `FOLLAY` for MAESPA's
`JLEAF=0` branch. `physiological_layers` is the corresponding `LGP` vector.
Age proportions are applied as supplied and are never silently normalized.
"""
function uniform_leaf_area_distribution!(
    leaf_area_density::AbstractVector{T},
    leaf_area_density_by_age::AbstractMatrix{T},
    leaf_area_by_layer::AbstractVector{T},
    representative_volumes::AbstractVector{<:Real},
    physiological_layers::AbstractVector{<:Integer},
    leaf_area::Real,
    physiological_age_proportions::AbstractVector{<:Real},
    leaf_density_legacy_mode::Integer,
) where {T<:AbstractFloat}
    leaf_density_legacy_mode isa Bool && throw(
        ArgumentError("leaf_density_legacy_mode must be an integer, not Bool"),
    )
    leaf_density_legacy_mode == 0 || throw(
        ArgumentError(
            "MAESPAUniformLeafAreaDistribution V1 supports only JLEAF=0; " *
            "got leaf_density_legacy_mode=$leaf_density_legacy_mode",
        ),
    )
    point_count = length(representative_volumes)
    point_count > 0 || throw(ArgumentError("representative_volumes must not be empty"))
    length(physiological_layers) == point_count || throw(
        DimensionMismatch(
            "physiological_layers and representative_volumes must have matching lengths",
        ),
    )
    physiological_age_count = length(physiological_age_proportions)
    physiological_age_count > 0 || throw(
        ArgumentError("at least one physiological age proportion is required"),
    )
    nolay = length(leaf_area_by_layer)
    nolay > 0 || throw(ArgumentError("leaf_area_by_layer must not be empty"))
    _validate_uniform_lad_outputs(
        point_count,
        physiological_age_count,
        nolay,
        leaf_area_density,
        leaf_area_density_by_age,
        leaf_area_by_layer,
    )
    leaf_area_value = _canopy_float(T, leaf_area, "leaf_area")
    leaf_area_value >= zero(T) || throw(
        ArgumentError("leaf_area must be non-negative"),
    )

    total_volume = zero(T)
    for point_index in eachindex(representative_volumes)
        volume = _canopy_float(
            T,
            representative_volumes[point_index],
            "representative volume",
        )
        _positive_canopy_value(volume, "representative volume")
        total_volume += volume
        layer = physiological_layers[point_index]
        layer isa Bool && throw(
            ArgumentError("physiological layer indices must not be Bool"),
        )
        1 <= layer <= nolay || throw(
            ArgumentError("physiological layer index $layer is outside 1:$nolay"),
        )
    end
    isfinite(total_volume) || throw(ArgumentError("total representative volume must be finite"))
    total_volume > zero(T) || throw(
        ArgumentError("total representative volume must be positive"),
    )
    for proportion in physiological_age_proportions
        typed_proportion = _canopy_float(
            T,
            proportion,
            "physiological age proportion",
        )
        typed_proportion >= zero(T) || throw(
            ArgumentError("physiological age proportions must be non-negative"),
        )
    end

    density = leaf_area_value / total_volume
    fill!(leaf_area_by_layer, zero(T))
    for point_index in eachindex(representative_volumes)
        leaf_area_density[point_index] = density
        for age_index in eachindex(physiological_age_proportions)
            leaf_area_density_by_age[age_index, point_index] =
                density * convert(T, physiological_age_proportions[age_index])
        end
        layer = physiological_layers[point_index]
        leaf_area_by_layer[layer] +=
            density * convert(T, representative_volumes[point_index])
    end
    return (
        uniform_leaf_area_density=density,
        leaf_area_density=leaf_area_density,
        leaf_area_density_by_age=leaf_area_density_by_age,
        leaf_area_by_layer=leaf_area_by_layer,
    )
end

"""Allocate the typed `JLEAF=0` leaf-area-density arrays for one crown."""
function uniform_leaf_area_distribution(
    representative_volumes::AbstractVector{T},
    physiological_layers::AbstractVector{<:Integer},
    leaf_area::T,
    physiological_age_proportions::AbstractVector{T},
    leaf_density_legacy_mode::Integer,
    nolay::Integer,
) where {T<:AbstractFloat}
    layer_count = _positive_canopy_count(nolay, "nolay")
    point_count = length(representative_volumes)
    physiological_age_count = length(physiological_age_proportions)
    return uniform_leaf_area_distribution!(
        Vector{T}(undef, point_count),
        Matrix{T}(undef, physiological_age_count, point_count),
        Vector{T}(undef, layer_count),
        representative_volumes,
        physiological_layers,
        leaf_area,
        physiological_age_proportions,
        leaf_density_legacy_mode,
    )
end


"""
    MAESPACanopySampling(T, nolay, pplay)

PlantSimEngine implementation of MAESPA's deterministic `POINTSNEW` canopy
sampling grid. The model can be shared while every crown owns its SoA buffers.
"""
struct MAESPACanopySampling{T<:AbstractFloat} <: AbstractCanopy_SamplingModel
    nolay::Int
    pplay::Int
    zero_value::T

    function MAESPACanopySampling(
        ::Type{T},
        nolay::Integer,
        pplay::Integer,
    ) where {T<:AbstractFloat}
        grid = _canopy_discretisation(nolay, pplay)
        return new{T}(grid.nolay, grid.pplay, zero(T))
    end
end

MAESPACanopySampling(
    nolay::Integer,
    pplay::Integer,
    ::Type{T},
) where {T<:AbstractFloat} = MAESPACanopySampling(T, nolay, pplay)

PlantSimEngine.inputs_(::MAESPACanopySampling) = (
    tree_x_m=PlantSimEngine.Required(Real),
    tree_y_m=PlantSimEngine.Required(Real),
    tree_z_m=PlantSimEngine.Required(Real),
    radius_x=PlantSimEngine.Required(Real),
    radius_y=PlantSimEngine.Required(Real),
    crown_depth=PlantSimEngine.Required(Real),
    crown_base_height=PlantSimEngine.Required(Real),
    crown_shape_code=PlantSimEngine.Required(Integer),
)

function PlantSimEngine.outputs_(model::MAESPACanopySampling{T}) where {T}
    point_count = model.nolay * model.pplay
    return (
        representative_x=zeros(T, point_count),
        representative_y=zeros(T, point_count),
        representative_z=zeros(T, point_count),
        representative_relative_heights=zeros(T, point_count),
        representative_volumes=zeros(T, point_count),
        physiological_layers=zeros(Int, point_count),
    )
end

function PlantSimEngine.run!(
    model::MAESPACanopySampling,
    status,
    environment,
    constants,
    context,
)
    T = eltype(status.representative_x)
    _crown_quadrature!(
        status.representative_x,
        status.representative_y,
        status.representative_z,
        status.representative_relative_heights,
        status.representative_volumes,
        status.physiological_layers,
        _canopy_float(T, status.tree_x_m, "tree_x_m"),
        _canopy_float(T, status.tree_y_m, "tree_y_m"),
        _canopy_float(T, status.tree_z_m, "tree_z_m"),
        _canopy_float(T, status.radius_x, "radius_x"),
        _canopy_float(T, status.radius_y, "radius_y"),
        _canopy_float(T, status.crown_depth, "crown_depth"),
        _canopy_float(T, status.crown_base_height, "crown_base_height"),
        status.crown_shape_code,
        model.nolay,
        model.pplay,
    )
    return nothing
end

"""
    MAESPAUniformLeafAreaDistribution(T, nolay, pplay, phys_age_count)

PlantSimEngine implementation of the uniform (`JLEAF=0`) branch of
`POINTSNEW`. Non-uniform legacy modes are implemented separately by
`MAESPABetaLeafAreaDistribution`, so this model continues to reject them.
"""
struct MAESPAUniformLeafAreaDistribution{T<:AbstractFloat} <:
       AbstractLeaf_Area_DistributionModel
    nolay::Int
    pplay::Int
    physiological_age_count::Int
    zero_value::T

    function MAESPAUniformLeafAreaDistribution(
        ::Type{T},
        nolay::Integer,
        pplay::Integer,
        physiological_age_count::Integer,
    ) where {T<:AbstractFloat}
        grid = _canopy_discretisation(nolay, pplay)
        age_count = _positive_canopy_count(
            physiological_age_count,
            "physiological_age_count",
        )
        return new{T}(grid.nolay, grid.pplay, age_count, zero(T))
    end
end

MAESPAUniformLeafAreaDistribution(
    nolay::Integer,
    pplay::Integer,
    physiological_age_count::Integer,
    ::Type{T},
) where {T<:AbstractFloat} =
    MAESPAUniformLeafAreaDistribution(T, nolay, pplay, physiological_age_count)

PlantSimEngine.inputs_(::MAESPAUniformLeafAreaDistribution) = (
    representative_volumes=PlantSimEngine.Required(AbstractVector),
    physiological_layers=PlantSimEngine.Required(AbstractVector),
    leaf_area=PlantSimEngine.Required(Real),
    physiological_age_proportions=PlantSimEngine.Required(AbstractVector),
    leaf_density_legacy_mode=PlantSimEngine.Required(Integer),
)

function PlantSimEngine.outputs_(
    model::MAESPAUniformLeafAreaDistribution{T},
) where {T}
    point_count = model.nolay * model.pplay
    return (
        uniform_leaf_area_density=zero(T),
        leaf_area_density=zeros(T, point_count),
        leaf_area_density_by_age=zeros(
            T,
            model.physiological_age_count,
            point_count,
        ),
        leaf_area_by_layer=zeros(T, model.nolay),
    )
end

function PlantSimEngine.run!(
    model::MAESPAUniformLeafAreaDistribution,
    status,
    environment,
    constants,
    context,
)
    length(status.representative_volumes) == model.nolay * model.pplay || throw(
        DimensionMismatch(
            "representative_volumes does not match the configured nolay*pplay",
        ),
    )
    length(status.physiological_age_proportions) == model.physiological_age_count || throw(
        DimensionMismatch(
            "physiological_age_proportions does not match phys_age_count",
        ),
    )
    result = uniform_leaf_area_distribution!(
        status.leaf_area_density,
        status.leaf_area_density_by_age,
        status.leaf_area_by_layer,
        status.representative_volumes,
        status.physiological_layers,
        status.leaf_area,
        status.physiological_age_proportions,
        status.leaf_density_legacy_mode,
    )
    status.uniform_leaf_area_density = result.uniform_leaf_area_density
    return nothing
end
