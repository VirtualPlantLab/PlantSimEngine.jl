PlantSimEngine.@process "leaf_thermodynamic_forcing" verbose = false

"""Temperature-only quantities prepared once before a MAESPA leaf iteration."""
struct LeafThermodynamicForcingResult{T<:AbstractFloat}
    latent_heat_vaporization_j_mol::T
    saturation_vapour_pressure_slope_pa_k::T
end

@noinline function _throw_leaf_thermodynamic_numeric(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :temperature
        throw(
            DomainError(
                value,
                "$label lies outside the historical saturation-pressure domain",
            ),
        )
    elseif reason === :result
        throw(DomainError(value, "$label must be finite and positive"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _leaf_thermodynamic_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real || _throw_leaf_thermodynamic_numeric(name, value, :real)
    value isa Bool && _throw_leaf_thermodynamic_numeric(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_leaf_thermodynamic_numeric(name, converted, :finite)
    return converted
end

@inline function _leaf_thermodynamic_positive(value::T, name::Symbol) where {T}
    value > zero(T) ||
        _throw_leaf_thermodynamic_numeric(name, value, :positive)
    return value
end

"""
    MAESPALeafThermodynamicForcing(T=Float64; kwargs...)

Typed constants used by the two temperature-only expressions at the start of
historical `PSTRANSP`. Defaults reproduce `H2OLV0`, the linear temperature
coefficient in `HEATEVAP`, `H2OMW`, the inlined `SATUR` coefficients, and the
literal finite-difference interval of `0.1 °C`.
"""
struct MAESPALeafThermodynamicForcing{T<:AbstractFloat} <:
       AbstractLeaf_Thermodynamic_ForcingModel
    latent_heat_at_zero_j_kg::T
    latent_heat_temperature_coefficient_j_kg_k::T
    water_molar_mass_kg_mol::T
    saturation_reference_pressure_pa::T
    saturation_exponent_coefficient::T
    saturation_temperature_offset_c::T
    slope_temperature_interval_c::T
end

function MAESPALeafThermodynamicForcing(
    ::Type{T}=Float64;
    latent_heat_at_zero_j_kg=2.501e6,
    latent_heat_temperature_coefficient_j_kg_k=2.365e3,
    water_molar_mass_kg_mol=18e-3,
    saturation_reference_pressure_pa=613.75,
    saturation_exponent_coefficient=17.502,
    saturation_temperature_offset_c=240.97,
    slope_temperature_interval_c=0.1,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the leaf-thermodynamic numeric type must be concrete"),
    )
    values = map(
        ((value, name),) -> _leaf_thermodynamic_positive(
            _leaf_thermodynamic_float(T, value, name),
            name,
        ),
        (
            (latent_heat_at_zero_j_kg, :latent_heat_at_zero_j_kg),
            (
                latent_heat_temperature_coefficient_j_kg_k,
                :latent_heat_temperature_coefficient_j_kg_k,
            ),
            (water_molar_mass_kg_mol, :water_molar_mass_kg_mol),
            (
                saturation_reference_pressure_pa,
                :saturation_reference_pressure_pa,
            ),
            (
                saturation_exponent_coefficient,
                :saturation_exponent_coefficient,
            ),
            (
                saturation_temperature_offset_c,
                :saturation_temperature_offset_c,
            ),
            (slope_temperature_interval_c, :slope_temperature_interval_c),
        ),
    )
    return MAESPALeafThermodynamicForcing{T}(values...)
end

@inline function _leaf_saturation_vapour_pressure(
    temperature_c::T,
    reference_pressure_pa::T,
    exponent_coefficient::T,
    temperature_offset_c::T,
) where {T<:AbstractFloat}
    denominator = temperature_offset_c + temperature_c
    denominator > zero(T) || _throw_leaf_thermodynamic_numeric(
        :air_temperature_c,
        temperature_c,
        :temperature,
    )
    pressure = reference_pressure_pa *
               exp(exponent_coefficient * temperature_c / denominator)
    isfinite(pressure) && pressure > zero(T) ||
        _throw_leaf_thermodynamic_numeric(
            :saturation_vapour_pressure_pa,
            pressure,
            :result,
        )
    return pressure
end

@inline function _leaf_thermodynamic_forcing(
    model::MAESPALeafThermodynamicForcing,
    ::Type{T},
    air_temperature_c::T,
) where {T<:AbstractFloat}
    latent_heat_at_zero = _leaf_thermodynamic_positive(
        _leaf_thermodynamic_float(
            T,
            model.latent_heat_at_zero_j_kg,
            :latent_heat_at_zero_j_kg,
        ),
        :latent_heat_at_zero_j_kg,
    )
    latent_heat_coefficient = _leaf_thermodynamic_positive(
        _leaf_thermodynamic_float(
            T,
            model.latent_heat_temperature_coefficient_j_kg_k,
            :latent_heat_temperature_coefficient_j_kg_k,
        ),
        :latent_heat_temperature_coefficient_j_kg_k,
    )
    water_molar_mass = _leaf_thermodynamic_positive(
        _leaf_thermodynamic_float(
            T,
            model.water_molar_mass_kg_mol,
            :water_molar_mass_kg_mol,
        ),
        :water_molar_mass_kg_mol,
    )
    reference_pressure = _leaf_thermodynamic_positive(
        _leaf_thermodynamic_float(
            T,
            model.saturation_reference_pressure_pa,
            :saturation_reference_pressure_pa,
        ),
        :saturation_reference_pressure_pa,
    )
    exponent_coefficient = _leaf_thermodynamic_positive(
        _leaf_thermodynamic_float(
            T,
            model.saturation_exponent_coefficient,
            :saturation_exponent_coefficient,
        ),
        :saturation_exponent_coefficient,
    )
    temperature_offset = _leaf_thermodynamic_positive(
        _leaf_thermodynamic_float(
            T,
            model.saturation_temperature_offset_c,
            :saturation_temperature_offset_c,
        ),
        :saturation_temperature_offset_c,
    )
    interval = _leaf_thermodynamic_positive(
        _leaf_thermodynamic_float(
            T,
            model.slope_temperature_interval_c,
            :slope_temperature_interval_c,
        ),
        :slope_temperature_interval_c,
    )

    air_temperature_c + temperature_offset > zero(T) &&
        air_temperature_c + interval + temperature_offset > zero(T) ||
        _throw_leaf_thermodynamic_numeric(
            :air_temperature_c,
            air_temperature_c,
            :temperature,
        )

    latent_heat =
        (latent_heat_at_zero - latent_heat_coefficient * air_temperature_c) *
        water_molar_mass
    isfinite(latent_heat) && latent_heat > zero(T) ||
        _throw_leaf_thermodynamic_numeric(
            :latent_heat_vaporization_j_mol,
            latent_heat,
            :result,
        )

    saturation = _leaf_saturation_vapour_pressure(
        air_temperature_c,
        reference_pressure,
        exponent_coefficient,
        temperature_offset,
    )
    saturation_plus = _leaf_saturation_vapour_pressure(
        air_temperature_c + interval,
        reference_pressure,
        exponent_coefficient,
        temperature_offset,
    )
    slope = (saturation_plus - saturation) / interval
    isfinite(slope) && slope > zero(T) || _throw_leaf_thermodynamic_numeric(
        :saturation_vapour_pressure_slope_pa_k,
        slope,
        :result,
    )
    return LeafThermodynamicForcingResult{T}(latent_heat, slope)
end

"""
    leaf_thermodynamic_forcing(air_temperature_c; kwargs...)

Compute the molar latent heat of vaporization and MAESPA's forward-difference
slope of saturation vapour pressure at air temperature. The slope deliberately
uses the executable `0.1 °C` interval rather than an analytic derivative.
"""
function leaf_thermodynamic_forcing(air_temperature_c; kwargs...)
    air_temperature_c isa Real || _throw_leaf_thermodynamic_numeric(
        :air_temperature_c,
        air_temperature_c,
        :real,
    )
    air_temperature_c isa Bool && _throw_leaf_thermodynamic_numeric(
        :air_temperature_c,
        air_temperature_c,
        :bool,
    )
    temperature = float(air_temperature_c)
    T = typeof(temperature)
    T <: AbstractFloat && isconcretetype(T) || throw(
        ArgumentError("air_temperature_c must convert to a concrete AbstractFloat"),
    )
    temperature = _leaf_thermodynamic_float(T, temperature, :air_temperature_c)
    return _leaf_thermodynamic_forcing(
        MAESPALeafThermodynamicForcing(T; kwargs...),
        T,
        temperature,
    )
end

PlantSimEngine.inputs_(::MAESPALeafThermodynamicForcing) = (
    leaf_thermodynamic_forcing_inputs_available=PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(::MAESPALeafThermodynamicForcing{T}) where {T} = (
    latent_heat_vaporization_j_mol=zero(T),
    saturation_vapour_pressure_slope_pa_k=zero(T),
    leaf_thermodynamic_forcing_available=false,
)

@inline function _reset_leaf_thermodynamic_forcing!(status, ::Type{T}) where {T}
    status.latent_heat_vaporization_j_mol = zero(T)
    status.saturation_vapour_pressure_slope_pa_k = zero(T)
    status.leaf_thermodynamic_forcing_available = false
    return nothing
end

@noinline function _throw_leaf_thermodynamic_output_type(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and leaf-thermodynamic output carriers must " *
            "share a floating-point type",
        ),
    )
end

function PlantSimEngine.run!(
    model::MAESPALeafThermodynamicForcing,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.latent_heat_vaporization_j_mol)
    T <: AbstractFloat ||
        _throw_leaf_thermodynamic_output_type(:latent_heat_vaporization_j_mol)
    _reset_leaf_thermodynamic_forcing!(status, T)
    typeof(status.saturation_vapour_pressure_slope_pa_k) === T ||
        _throw_leaf_thermodynamic_output_type(
            :saturation_vapour_pressure_slope_pa_k,
        )
    available = status.leaf_thermodynamic_forcing_inputs_available
    available isa Bool || throw(
        ArgumentError("leaf_thermodynamic_forcing_inputs_available must be Bool"),
    )
    available || return nothing

    result = _leaf_thermodynamic_forcing(
        model,
        T,
        _leaf_thermodynamic_float(
            T,
            environment.air_temperature_c,
            :air_temperature_c,
        ),
    )
    status.latent_heat_vaporization_j_mol =
        result.latent_heat_vaporization_j_mol
    status.saturation_vapour_pressure_slope_pa_k =
        result.saturation_vapour_pressure_slope_pa_k
    status.leaf_thermodynamic_forcing_available = true
    return nothing
end

PlantSimEngine.environment_inputs_(::MAESPALeafThermodynamicForcing{T}) where {T} = (
    air_temperature_c=zero(T),
)
