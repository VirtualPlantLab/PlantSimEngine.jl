PlantSimEngine.@process "growth_respiration" verbose = false

"""Result of MAESPA's historical `GRESP` growth-respiration calculation."""
struct GrowthRespirationResult{T<:AbstractFloat}
    growth_respiration_mol_co2_tree_day::T
    positive_biomass_increment::Bool
end

"""
    MAESPAGrowthRespiration(T=Float64; kwargs...)

Typed constants used by the historical `GRESP` function. MAESPA converts a
daily dry-matter increment to mol CO₂ tree⁻¹ day⁻¹ using `CPERDW = 0.5` g C
per g dry matter and `GCPERMOL = 12` g C per mol. The efficiency `EFFY` and
the biomass increment remain runtime inputs so the same process can be used
for foliage, woody biomass, coarse roots, and fine roots.

The PlantSimEngine adapter also requires the one-based MAESPA `date50` of the
daily increment. A successful run publishes it as
`growth_respiration_date50`; a disabled or unavailable run publishes the
sentinel date `0` together with `growth_respiration_available=false`. The pure
[`growth_respiration`](@ref) kernel remains independent of calendar handling.
"""
struct MAESPAGrowthRespiration{T<:AbstractFloat} <:
       AbstractGrowth_RespirationModel
    carbon_molar_mass_g_mol::T
    carbon_fraction_dry_matter::T
end

@noinline function _throw_growth_respiration_numeric(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :positive
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :result
        throw(DomainError(value, "$label must be finite and non-negative"))
    elseif reason === :integer
        throw(ArgumentError("$label must be an integer, not Bool"))
    elseif reason === :int_range
        throw(ArgumentError("$label must be representable as Int"))
    elseif reason === :positive_date
        throw(DomainError(value, "$label must be positive"))
    elseif reason === :float_output
        throw(
            ArgumentError(
                "growth_respiration_mol_co2_tree_day must use one concrete " *
                "AbstractFloat output carrier",
            ),
        )
    elseif reason === :int_output
        throw(ArgumentError("$label must use Int as its output carrier"))
    elseif reason === :bool_output
        throw(ArgumentError("$label must use Bool as its output carrier"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _growth_respiration_date50(value)
    value isa Integer && !(value isa Bool) ||
        _throw_growth_respiration_numeric(:date50, value, :integer)
    converted = try
        Int(value)
    catch exception
        exception isa InexactError || exception isa OverflowError || rethrow()
        _throw_growth_respiration_numeric(:date50, value, :int_range)
    end
    converted > 0 ||
        _throw_growth_respiration_numeric(:date50, converted, :positive_date)
    return converted
end

@inline function _growth_respiration_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real || _throw_growth_respiration_numeric(name, value, :real)
    value isa Bool && _throw_growth_respiration_numeric(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_growth_respiration_numeric(name, converted, :finite)
    return converted
end

function MAESPAGrowthRespiration(
    ::Type{T}=Float64;
    carbon_molar_mass_g_mol=12,
    carbon_fraction_dry_matter=0.5,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the growth-respiration numeric type must be concrete"),
    )
    molar_mass = _growth_respiration_float(
        T,
        carbon_molar_mass_g_mol,
        :carbon_molar_mass_g_mol,
    )
    molar_mass > zero(T) || _throw_growth_respiration_numeric(
        :carbon_molar_mass_g_mol,
        molar_mass,
        :positive,
    )
    carbon_fraction = _growth_respiration_float(
        T,
        carbon_fraction_dry_matter,
        :carbon_fraction_dry_matter,
    )
    carbon_fraction >= zero(T) || _throw_growth_respiration_numeric(
        :carbon_fraction_dry_matter,
        carbon_fraction,
        :nonnegative,
    )
    return MAESPAGrowthRespiration{T}(molar_mass, carbon_fraction)
end

@inline function _growth_respiration(
    model::MAESPAGrowthRespiration,
    ::Type{T},
    biomass_increment_g_dry_matter_tree_day::T,
    growth_respiration_efficiency::T,
) where {T<:AbstractFloat}
    efficiency = growth_respiration_efficiency
    efficiency >= zero(T) || _throw_growth_respiration_numeric(
        :growth_respiration_efficiency,
        efficiency,
        :nonnegative,
    )
    positive_increment = biomass_increment_g_dry_matter_tree_day > zero(T)
    positive_increment || return GrowthRespirationResult(zero(T), false)

    molar_mass = _growth_respiration_float(
        T,
        model.carbon_molar_mass_g_mol,
        :carbon_molar_mass_g_mol,
    )
    carbon_fraction = _growth_respiration_float(
        T,
        model.carbon_fraction_dry_matter,
        :carbon_fraction_dry_matter,
    )
    respiration = biomass_increment_g_dry_matter_tree_day * efficiency /
                  molar_mass * carbon_fraction
    isfinite(respiration) && respiration >= zero(T) ||
        _throw_growth_respiration_numeric(
            :growth_respiration_mol_co2_tree_day,
            respiration,
            :result,
        )
    return GrowthRespirationResult(respiration, true)
end

"""
    growth_respiration(biomass_increment, efficiency; kwargs...)

Reproduce `GRESP`. A zero or negative biomass increment gives zero growth
respiration exactly as in the Fortran. Positive increments are converted to
mol CO₂ tree⁻¹ day⁻¹ without altering the historical operation order.
"""
function growth_respiration(
    biomass_increment_g_dry_matter_tree_day::T,
    growth_respiration_efficiency::T;
    carbon_molar_mass_g_mol::Real=T(12),
    carbon_fraction_dry_matter::Real=T(0.5),
) where {T<:AbstractFloat}
    model = MAESPAGrowthRespiration(
        T;
        carbon_molar_mass_g_mol,
        carbon_fraction_dry_matter,
    )
    increment = _growth_respiration_float(
        T,
        biomass_increment_g_dry_matter_tree_day,
        :biomass_increment_g_dry_matter_tree_day,
    )
    efficiency = _growth_respiration_float(
        T,
        growth_respiration_efficiency,
        :growth_respiration_efficiency,
    )
    return _growth_respiration(model, T, increment, efficiency)
end

function growth_respiration(
    biomass_increment_g_dry_matter_tree_day::Real,
    growth_respiration_efficiency::Real;
    carbon_molar_mass_g_mol::Real=12.0,
    carbon_fraction_dry_matter::Real=0.5,
)
    biomass_increment_g_dry_matter_tree_day isa Bool &&
        _throw_growth_respiration_numeric(
            :biomass_increment_g_dry_matter_tree_day,
            biomass_increment_g_dry_matter_tree_day,
            :bool,
        )
    growth_respiration_efficiency isa Bool &&
        _throw_growth_respiration_numeric(
            :growth_respiration_efficiency,
            growth_respiration_efficiency,
            :bool,
        )
    carbon_molar_mass_g_mol isa Bool && _throw_growth_respiration_numeric(
        :carbon_molar_mass_g_mol,
        carbon_molar_mass_g_mol,
        :bool,
    )
    carbon_fraction_dry_matter isa Bool && _throw_growth_respiration_numeric(
        :carbon_fraction_dry_matter,
        carbon_fraction_dry_matter,
        :bool,
    )
    T = float(
        promote_type(
            typeof(biomass_increment_g_dry_matter_tree_day),
            typeof(growth_respiration_efficiency),
            typeof(carbon_molar_mass_g_mol),
            typeof(carbon_fraction_dry_matter),
        ),
    )
    model = MAESPAGrowthRespiration(
        T;
        carbon_molar_mass_g_mol,
        carbon_fraction_dry_matter,
    )
    increment = _growth_respiration_float(
        T,
        biomass_increment_g_dry_matter_tree_day,
        :biomass_increment_g_dry_matter_tree_day,
    )
    efficiency = _growth_respiration_float(
        T,
        growth_respiration_efficiency,
        :growth_respiration_efficiency,
    )
    return _growth_respiration(model, T, increment, efficiency)
end

PlantSimEngine.inputs_(::MAESPAGrowthRespiration) = (
    biomass_increment_g_dry_matter_tree_day=PlantSimEngine.Required(Real),
    growth_respiration_efficiency=PlantSimEngine.Required(Real),
    date50=PlantSimEngine.Required(Integer),
    growth_respiration_active=PlantSimEngine.Default(true),
    growth_respiration_inputs_available=PlantSimEngine.Default(true),
)

PlantSimEngine.outputs_(model::MAESPAGrowthRespiration{T}) where {T} = (
    growth_respiration_mol_co2_tree_day=zero(T),
    positive_biomass_increment=false,
    growth_respiration_date50=0,
    growth_respiration_available=false,
)

@inline function _reset_growth_respiration!(status, ::Type{T}) where {T}
    status.growth_respiration_mol_co2_tree_day = zero(T)
    status.positive_biomass_increment = false
    status.growth_respiration_date50 = 0
    status.growth_respiration_available = false
    return nothing
end

@inline function _growth_respiration_output_type(status)
    amount = status.growth_respiration_mol_co2_tree_day
    T = typeof(amount)
    T <: AbstractFloat && isconcretetype(T) ||
        _throw_growth_respiration_numeric(
            :growth_respiration_mol_co2_tree_day,
            amount,
            :float_output,
        )
    status.positive_biomass_increment isa Bool ||
        _throw_growth_respiration_numeric(
            :positive_biomass_increment,
            status.positive_biomass_increment,
            :bool_output,
        )
    status.growth_respiration_available isa Bool ||
        _throw_growth_respiration_numeric(
            :growth_respiration_available,
            status.growth_respiration_available,
            :bool_output,
        )
    typeof(status.growth_respiration_date50) === Int ||
        _throw_growth_respiration_numeric(
            :growth_respiration_date50,
            status.growth_respiration_date50,
            :int_output,
        )
    return T
end

function PlantSimEngine.run!(
    model::MAESPAGrowthRespiration,
    status,
    environment,
    constants,
    context,
)
    T = _growth_respiration_output_type(status)

    active = status.growth_respiration_active
    available = status.growth_respiration_inputs_available
    active isa Bool ||
        throw(ArgumentError("growth_respiration_active must be Bool"))
    available isa Bool || throw(
        ArgumentError("growth_respiration_inputs_available must be Bool"),
    )
    if !(active && available)
        _reset_growth_respiration!(status, T)
        return nothing
    end

    increment = _growth_respiration_float(
        T,
        status.biomass_increment_g_dry_matter_tree_day,
        :biomass_increment_g_dry_matter_tree_day,
    )
    efficiency = _growth_respiration_float(
        T,
        status.growth_respiration_efficiency,
        :growth_respiration_efficiency,
    )
    date50 = _growth_respiration_date50(status.date50)
    result = _growth_respiration(model, T, increment, efficiency)
    status.growth_respiration_mol_co2_tree_day =
        result.growth_respiration_mol_co2_tree_day
    status.positive_biomass_increment = result.positive_biomass_increment
    status.growth_respiration_date50 = date50
    status.growth_respiration_available = true
    return nothing
end
