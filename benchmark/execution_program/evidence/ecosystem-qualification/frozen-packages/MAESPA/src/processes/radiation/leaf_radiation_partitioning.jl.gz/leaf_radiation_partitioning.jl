PlantSimEngine.@process "leaf_radiation_partitioning" verbose = false

"""
Dense per-Crown result of MAESPA's `MODELSS` leaf-radiation partition.

Rows are representative canopy points. Columns are fixed radiation-class
slots. Only the first `active_leaf_radiation_class_count` columns are active;
all remaining slots are zero. The area fractions are relative to the leaf
area represented by each point and therefore sum to one over the active
columns.

PAR and NIR remain absorbed energy flux densities in W m⁻² of leaf. The
historical `UMOLPERJ = 4.57` conversion belongs to the downstream physiology
process, not to this radiation partition.
"""
struct LeafRadiationPartitioningResult{T<:AbstractFloat}
    leaf_radiation_area_fraction::Matrix{T}
    leaf_radiation_absorbed_par_w_m2_leaf::Matrix{T}
    leaf_radiation_absorbed_nir_w_m2_leaf::Matrix{T}
    effective_sun_shade_model::Int
    active_leaf_radiation_class_count::Int
    leaf_radiation_shaded_class_index::Int
end

@inline function _leaf_partition_positive_count(
    value::Integer,
    name::AbstractString,
)
    value isa Bool && throw(ArgumentError("$name must be an integer, not Bool"))
    value > 0 || throw(ArgumentError("$name must be positive"))
    return Int(value)
end

@inline function _leaf_partition_model(value::Integer)
    value isa Bool && throw(
        ArgumentError("sun_shade_model must be an integer, not Bool"),
    )
    value in (0, 1, 2) || throw(
        ArgumentError("sun_shade_model (MODELSS) must be 0, 1, or 2"),
    )
    return Int(value)
end

@inline function _leaf_partition_float(
    ::Type{T},
    value::Real,
    name::AbstractString,
) where {T<:AbstractFloat}
    value isa Bool && throw(ArgumentError("$name must be numeric, not Bool"))
    converted = convert(T, value)
    isfinite(converted) || throw(ArgumentError("$name must be finite"))
    return converted
end

@inline _leaf_partition_slot_count(leaf_angle_count::Int) =
    max(2, leaf_angle_count + 1)

@inline function _leaf_partition_metadata(
    sun_shade_model::Int,
    beam_fraction_par::T,
    leaf_angle_count::Int,
) where {T<:AbstractFloat}
    effective_model = iszero(beam_fraction_par) ? 1 : sun_shade_model
    if effective_model == 0
        return (
            effective_sun_shade_model=0,
            active_leaf_radiation_class_count=2,
            leaf_radiation_shaded_class_index=2,
        )
    elseif effective_model == 1
        return (
            effective_sun_shade_model=1,
            active_leaf_radiation_class_count=1,
            leaf_radiation_shaded_class_index=0,
        )
    end
    return (
        effective_sun_shade_model=2,
        active_leaf_radiation_class_count=leaf_angle_count + 1,
        leaf_radiation_shaded_class_index=leaf_angle_count + 1,
    )
end

function _validate_leaf_radiation_partitioning_inputs(
    leaf_radiation_area_fraction::AbstractMatrix{T},
    leaf_radiation_absorbed_par_w_m2_leaf::AbstractMatrix{T},
    leaf_radiation_absorbed_nir_w_m2_leaf::AbstractMatrix{T},
    absorbed_direct_beam_normal_w_m2::AbstractMatrix{T},
    absorbed_diffuse_shortwave_w_m2_leaf::AbstractMatrix{T},
    sunlit_leaf_fraction::AbstractVector{T},
    direct_effective_extinction_by_leaf_angle::AbstractMatrix{T},
    direct_transmission_available::AbstractVector{Bool},
    beam_extinction_coefficient::T,
    leaf_angle_fractions::AbstractVector{T},
    beam_fraction_par::T,
    sun_shade_model::Int,
) where {T<:AbstractFloat}
    Base.require_one_based_indexing(
        leaf_radiation_area_fraction,
        leaf_radiation_absorbed_par_w_m2_leaf,
        leaf_radiation_absorbed_nir_w_m2_leaf,
        absorbed_direct_beam_normal_w_m2,
        absorbed_diffuse_shortwave_w_m2_leaf,
        sunlit_leaf_fraction,
        direct_effective_extinction_by_leaf_angle,
        direct_transmission_available,
        leaf_angle_fractions,
    )

    point_count = length(sunlit_leaf_fraction)
    point_count > 0 || throw(ArgumentError("at least one point is required"))
    leaf_angle_count = length(leaf_angle_fractions)
    leaf_angle_count > 0 || throw(
        ArgumentError("at least one leaf-angle class is required"),
    )
    slot_count = _leaf_partition_slot_count(leaf_angle_count)
    output_size = (point_count, slot_count)
    for (values, name) in (
        (leaf_radiation_area_fraction, "leaf_radiation_area_fraction"),
        (
            leaf_radiation_absorbed_par_w_m2_leaf,
            "leaf_radiation_absorbed_par_w_m2_leaf",
        ),
        (
            leaf_radiation_absorbed_nir_w_m2_leaf,
            "leaf_radiation_absorbed_nir_w_m2_leaf",
        ),
    )
        size(values) == output_size || throw(
            DimensionMismatch("$name must have size $output_size"),
        )
    end
    shortwave_size = (point_count, 2)
    for (values, name) in (
        (
            absorbed_direct_beam_normal_w_m2,
            "absorbed_direct_beam_normal_w_m2",
        ),
        (
            absorbed_diffuse_shortwave_w_m2_leaf,
            "absorbed_diffuse_shortwave_w_m2_leaf",
        ),
    )
        size(values) == shortwave_size || throw(
            DimensionMismatch("$name must have size $shortwave_size"),
        )
    end
    size(direct_effective_extinction_by_leaf_angle) ==
    (leaf_angle_count, point_count) || throw(
        DimensionMismatch(
            "direct_effective_extinction_by_leaf_angle must have size " *
            "($leaf_angle_count, $point_count)",
        ),
    )
    length(direct_transmission_available) == point_count || throw(
        DimensionMismatch(
            "direct_transmission_available must contain $point_count values",
        ),
    )

    _leaf_partition_model(sun_shade_model)
    isfinite(beam_extinction_coefficient) || throw(
        ArgumentError("beam_extinction_coefficient must be finite"),
    )
    beam_extinction_coefficient >= zero(T) || throw(
        DomainError(
            beam_extinction_coefficient,
            "beam_extinction_coefficient must be non-negative",
        ),
    )
    isfinite(beam_fraction_par) || throw(
        ArgumentError("beam_fraction_par must be finite"),
    )
    zero(T) <= beam_fraction_par <= one(T) || throw(
        DomainError(beam_fraction_par, "beam_fraction_par must lie in [0, 1]"),
    )

    fraction_sum = zero(T)
    for (angle_index, fraction) in pairs(leaf_angle_fractions)
        isfinite(fraction) || throw(
            ArgumentError("leaf_angle_fractions[$angle_index] must be finite"),
        )
        zero(T) <= fraction <= one(T) || throw(
            DomainError(
                fraction,
                "leaf_angle_fractions values must lie in [0, 1]",
            ),
        )
        fraction_sum += fraction
    end
    fraction_tolerance = max(T(1.0e-4), T(20) * eps(T))
    isapprox(
        fraction_sum,
        one(T);
        atol=fraction_tolerance,
        rtol=fraction_tolerance,
    ) || throw(ArgumentError("leaf_angle_fractions must sum to one"))

    for point_index in eachindex(sunlit_leaf_fraction)
        sunlit = sunlit_leaf_fraction[point_index]
        isfinite(sunlit) || throw(
            ArgumentError("sunlit_leaf_fraction[$point_index] must be finite"),
        )
        zero(T) <= sunlit <= one(T) || throw(
            DomainError(
                sunlit,
                "sunlit_leaf_fraction values must lie in [0, 1]",
            ),
        )
        for waveband_index in 1:2
            direct = absorbed_direct_beam_normal_w_m2[
                point_index,
                waveband_index,
            ]
            diffuse = absorbed_diffuse_shortwave_w_m2_leaf[
                point_index,
                waveband_index,
            ]
            isfinite(direct) || throw(
                ArgumentError("absorbed direct shortwave radiation must be finite"),
            )
            isfinite(diffuse) || throw(
                ArgumentError("absorbed diffuse shortwave radiation must be finite"),
            )
            direct >= zero(T) || throw(
                DomainError(
                    direct,
                    "absorbed direct shortwave radiation must be non-negative",
                ),
            )
            diffuse >= zero(T) || throw(
                DomainError(
                    diffuse,
                    "absorbed diffuse shortwave radiation must be non-negative",
                ),
            )
        end
    end
    for point_index in axes(direct_effective_extinction_by_leaf_angle, 2),
        angle_index in axes(direct_effective_extinction_by_leaf_angle, 1)
        coefficient = direct_effective_extinction_by_leaf_angle[
            angle_index,
            point_index,
        ]
        isfinite(coefficient) || throw(
            ArgumentError(
                "direct_effective_extinction_by_leaf_angle must be finite",
            ),
        )
        coefficient >= zero(T) || throw(
            DomainError(
                coefficient,
                "angle-specific beam extinction must be non-negative",
            ),
        )
    end
    return (; point_count, leaf_angle_count)
end

"""
    leaf_radiation_partitioning!(...; sun_shade_model)

Fill fixed point-by-slot buffers using the three historical `MODELSS` branches:

- `0`: one sunlit and one shaded class;
- `1`: one mean class over all leaf area;
- `2`: one sunlit class per leaf-angle class, followed by one shaded class.

When the PAR beam fraction is exactly zero, the effective mode is `1` for all
configured modes, matching the order of the Fortran branches. `BEXTT(1)` is
represented by the target `beam_extinction_coefficient`; the angle-specific
mode uses the path-weighted `direct_effective_extinction_by_leaf_angle` emitted
by `TRANSB`.
"""
function leaf_radiation_partitioning!(
    leaf_radiation_area_fraction::AbstractMatrix{T},
    leaf_radiation_absorbed_par_w_m2_leaf::AbstractMatrix{T},
    leaf_radiation_absorbed_nir_w_m2_leaf::AbstractMatrix{T},
    absorbed_direct_beam_normal_w_m2::AbstractMatrix{T},
    absorbed_diffuse_shortwave_w_m2_leaf::AbstractMatrix{T},
    sunlit_leaf_fraction::AbstractVector{T},
    direct_effective_extinction_by_leaf_angle::AbstractMatrix{T},
    direct_transmission_available::AbstractVector{Bool},
    beam_extinction_coefficient::T,
    leaf_angle_fractions::AbstractVector{T},
    beam_fraction_par::T;
    sun_shade_model::Integer,
) where {T<:AbstractFloat}
    fill!(leaf_radiation_area_fraction, zero(T))
    fill!(leaf_radiation_absorbed_par_w_m2_leaf, zero(T))
    fill!(leaf_radiation_absorbed_nir_w_m2_leaf, zero(T))
    model = _leaf_partition_model(sun_shade_model)
    dimensions = _validate_leaf_radiation_partitioning_inputs(
        leaf_radiation_area_fraction,
        leaf_radiation_absorbed_par_w_m2_leaf,
        leaf_radiation_absorbed_nir_w_m2_leaf,
        absorbed_direct_beam_normal_w_m2,
        absorbed_diffuse_shortwave_w_m2_leaf,
        sunlit_leaf_fraction,
        direct_effective_extinction_by_leaf_angle,
        direct_transmission_available,
        beam_extinction_coefficient,
        leaf_angle_fractions,
        beam_fraction_par,
        model,
    )
    return _leaf_radiation_partitioning_kernel!(
        leaf_radiation_area_fraction, leaf_radiation_absorbed_par_w_m2_leaf,
        leaf_radiation_absorbed_nir_w_m2_leaf, absorbed_direct_beam_normal_w_m2,
        absorbed_diffuse_shortwave_w_m2_leaf, sunlit_leaf_fraction,
        direct_effective_extinction_by_leaf_angle, direct_transmission_available,
        beam_extinction_coefficient, leaf_angle_fractions, beam_fraction_par;
        sun_shade_model,
    )
end

# Internal calculation: fixed layout and parameter validation belong to its caller.
function _leaf_radiation_partitioning_kernel!(
    leaf_radiation_area_fraction::AbstractMatrix{T},
    leaf_radiation_absorbed_par_w_m2_leaf::AbstractMatrix{T},
    leaf_radiation_absorbed_nir_w_m2_leaf::AbstractMatrix{T},
    absorbed_direct_beam_normal_w_m2::AbstractMatrix{T},
    absorbed_diffuse_shortwave_w_m2_leaf::AbstractMatrix{T},
    sunlit_leaf_fraction::AbstractVector{T},
    direct_effective_extinction_by_leaf_angle::AbstractMatrix{T},
    direct_transmission_available::AbstractVector{Bool},
    beam_extinction_coefficient::T,
    leaf_angle_fractions::AbstractVector{T},
    beam_fraction_par::T;
    sun_shade_model::Integer,
) where {T<:AbstractFloat}
    fill!(leaf_radiation_area_fraction, zero(T))
    fill!(leaf_radiation_absorbed_par_w_m2_leaf, zero(T))
    fill!(leaf_radiation_absorbed_nir_w_m2_leaf, zero(T))
    model = Int(sun_shade_model)
    dimensions = (point_count=length(sunlit_leaf_fraction),
        leaf_angle_count=length(leaf_angle_fractions))
    metadata = _leaf_partition_metadata(
        model,
        beam_fraction_par,
        dimensions.leaf_angle_count,
    )

    for point_index in 1:dimensions.point_count
        sunlit = direct_transmission_available[point_index] ?
                 sunlit_leaf_fraction[point_index] : zero(T)
        shaded = one(T) - sunlit
        direct_par = absorbed_direct_beam_normal_w_m2[point_index, 1]
        direct_nir = absorbed_direct_beam_normal_w_m2[point_index, 2]
        diffuse_par = absorbed_diffuse_shortwave_w_m2_leaf[point_index, 1]
        diffuse_nir = absorbed_diffuse_shortwave_w_m2_leaf[point_index, 2]

        if metadata.effective_sun_shade_model == 0
            leaf_radiation_area_fraction[point_index, 1] = sunlit
            leaf_radiation_area_fraction[point_index, 2] = shaded
            leaf_radiation_absorbed_par_w_m2_leaf[point_index, 1] =
                direct_par * beam_extinction_coefficient + diffuse_par
            leaf_radiation_absorbed_nir_w_m2_leaf[point_index, 1] =
                direct_nir * beam_extinction_coefficient + diffuse_nir
            leaf_radiation_absorbed_par_w_m2_leaf[point_index, 2] = diffuse_par
            leaf_radiation_absorbed_nir_w_m2_leaf[point_index, 2] = diffuse_nir
        elseif metadata.effective_sun_shade_model == 1
            leaf_radiation_area_fraction[point_index, 1] = one(T)
            leaf_radiation_absorbed_par_w_m2_leaf[point_index, 1] =
                direct_par * beam_extinction_coefficient * sunlit + diffuse_par
            leaf_radiation_absorbed_nir_w_m2_leaf[point_index, 1] =
                direct_nir * beam_extinction_coefficient * sunlit + diffuse_nir
        else
            for angle_index in 1:dimensions.leaf_angle_count
                leaf_radiation_area_fraction[point_index, angle_index] =
                    sunlit * leaf_angle_fractions[angle_index]
                coefficient = direct_effective_extinction_by_leaf_angle[
                    angle_index,
                    point_index,
                ]
                leaf_radiation_absorbed_par_w_m2_leaf[
                    point_index,
                    angle_index,
                ] = direct_par * coefficient + diffuse_par
                leaf_radiation_absorbed_nir_w_m2_leaf[
                    point_index,
                    angle_index,
                ] = direct_nir * coefficient + diffuse_nir
            end
            shaded_index = dimensions.leaf_angle_count + 1
            leaf_radiation_area_fraction[point_index, shaded_index] = shaded
            leaf_radiation_absorbed_par_w_m2_leaf[point_index, shaded_index] =
                diffuse_par
            leaf_radiation_absorbed_nir_w_m2_leaf[point_index, shaded_index] =
                diffuse_nir
        end
    end
    return nothing
end

"""Allocate and return a typed result for MAESPA's `MODELSS` partition."""
function leaf_radiation_partitioning(
    absorbed_direct_beam_normal_w_m2::AbstractMatrix{T},
    absorbed_diffuse_shortwave_w_m2_leaf::AbstractMatrix{T},
    sunlit_leaf_fraction::AbstractVector{T},
    direct_effective_extinction_by_leaf_angle::AbstractMatrix{T},
    direct_transmission_available::AbstractVector{Bool},
    beam_extinction_coefficient::T,
    leaf_angle_fractions::AbstractVector{T},
    beam_fraction_par::T;
    sun_shade_model::Integer,
) where {T<:AbstractFloat}
    point_count = length(sunlit_leaf_fraction)
    leaf_angle_count = length(leaf_angle_fractions)
    slot_count = _leaf_partition_slot_count(leaf_angle_count)
    model = _leaf_partition_model(sun_shade_model)
    metadata = _leaf_partition_metadata(model, beam_fraction_par, leaf_angle_count)
    result = LeafRadiationPartitioningResult(
        zeros(T, point_count, slot_count),
        zeros(T, point_count, slot_count),
        zeros(T, point_count, slot_count),
        metadata.effective_sun_shade_model,
        metadata.active_leaf_radiation_class_count,
        metadata.leaf_radiation_shaded_class_index,
    )
    leaf_radiation_partitioning!(
        result.leaf_radiation_area_fraction,
        result.leaf_radiation_absorbed_par_w_m2_leaf,
        result.leaf_radiation_absorbed_nir_w_m2_leaf,
        absorbed_direct_beam_normal_w_m2,
        absorbed_diffuse_shortwave_w_m2_leaf,
        sunlit_leaf_fraction,
        direct_effective_extinction_by_leaf_angle,
        direct_transmission_available,
        beam_extinction_coefficient,
        leaf_angle_fractions,
        beam_fraction_par;
        sun_shade_model=model,
    )
    return result
end

"""Per-target PlantSimEngine wrapper for the historical `MODELSS` branches."""
struct MAESPALeafRadiationPartitioning{T<:AbstractFloat} <:
       AbstractLeaf_Radiation_PartitioningModel
    point_count::Int
    leaf_angle_count::Int
    sun_shade_model::Int
    slot_count::Int
    zero_value::T
end

function MAESPALeafRadiationPartitioning(
    ::Type{T},
    point_count::Integer,
    leaf_angle_count::Integer,
    sun_shade_model::Integer,
) where {T<:AbstractFloat}
    points = _leaf_partition_positive_count(point_count, "point_count")
    angles = _leaf_partition_positive_count(leaf_angle_count, "leaf_angle_count")
    model = _leaf_partition_model(sun_shade_model)
    return MAESPALeafRadiationPartitioning{T}(
        points,
        angles,
        model,
        _leaf_partition_slot_count(angles),
        zero(T),
    )
end

PlantSimEngine.inputs_(::MAESPALeafRadiationPartitioning) = (
    absorbed_direct_beam_normal_w_m2=PlantSimEngine.Required(AbstractMatrix),
    absorbed_diffuse_shortwave_w_m2_leaf=PlantSimEngine.Required(AbstractMatrix),
    shortwave_absorption_available=PlantSimEngine.Required(Bool),
    sunlit_leaf_fraction=PlantSimEngine.Required(AbstractVector),
    direct_effective_extinction_by_leaf_angle=PlantSimEngine.Required(AbstractMatrix),
    direct_transmission_available=PlantSimEngine.Required(AbstractVector),
    beam_extinction_coefficient=PlantSimEngine.Required(Real),
    beam_extinction_available=PlantSimEngine.Required(Bool),
    leaf_angle_fractions=PlantSimEngine.Required(AbstractVector),
    beam_fraction_par=PlantSimEngine.Required(Real),
    astronomical_daylight=PlantSimEngine.Required(Bool),
)

PlantSimEngine.variable_contracts_(::MAESPALeafRadiationPartitioning) = merge(
    (beam_fraction_par=HORIZONTAL_PAR_BEAM_FRACTION_CONTRACT,),
    LEAF_RADIATION_PARTITION_CONTRACTS,
)

function PlantSimEngine.outputs_(
    model::MAESPALeafRadiationPartitioning{T},
) where {T}
    output_size = (model.point_count, model.slot_count)
    return (
        leaf_radiation_area_fraction=zeros(T, output_size),
        leaf_radiation_absorbed_par_w_m2_leaf=zeros(T, output_size),
        leaf_radiation_absorbed_nir_w_m2_leaf=zeros(T, output_size),
        effective_sun_shade_model=model.sun_shade_model,
        active_leaf_radiation_class_count=0,
        leaf_radiation_shaded_class_index=0,
        leaf_radiation_partitioning_available=false,
    )
end

function _reset_leaf_radiation_partitioning_outputs!(
    model::MAESPALeafRadiationPartitioning,
    status,
    ::Type{T},
) where {T<:AbstractFloat}
    fill!(status.leaf_radiation_area_fraction, zero(T))
    fill!(status.leaf_radiation_absorbed_par_w_m2_leaf, zero(T))
    fill!(status.leaf_radiation_absorbed_nir_w_m2_leaf, zero(T))
    status.effective_sun_shade_model = model.sun_shade_model
    status.active_leaf_radiation_class_count = 0
    status.leaf_radiation_shaded_class_index = 0
    status.leaf_radiation_partitioning_available = false
    return nothing
end

@noinline function _throw_leaf_partition_eltype(name::Symbol)
    throw(
        ArgumentError(
            "$(String(name)) and leaf-radiation output buffers must share a numeric type",
        ),
    )
end

@inline function _require_leaf_partition_eltype(
    values,
    ::Type{T},
    name::Symbol,
) where {T<:AbstractFloat}
    eltype(values) === T || _throw_leaf_partition_eltype(name)
    return nothing
end

function PlantSimEngine.run!(
    model::MAESPALeafRadiationPartitioning,
    status,
    environment,
    constants,
    context,
)
    T = eltype(status.leaf_radiation_area_fraction)
    _reset_leaf_radiation_partitioning_outputs!(model, status, T)
    _require_leaf_partition_eltype(
        status.leaf_radiation_absorbed_par_w_m2_leaf,
        T,
        :leaf_radiation_absorbed_par_w_m2_leaf,
    )
    _require_leaf_partition_eltype(
        status.leaf_radiation_absorbed_nir_w_m2_leaf,
        T,
        :leaf_radiation_absorbed_nir_w_m2_leaf,
    )
    _require_leaf_partition_eltype(
        status.absorbed_direct_beam_normal_w_m2,
        T,
        :absorbed_direct_beam_normal_w_m2,
    )
    _require_leaf_partition_eltype(
        status.absorbed_diffuse_shortwave_w_m2_leaf,
        T,
        :absorbed_diffuse_shortwave_w_m2_leaf,
    )
    _require_leaf_partition_eltype(
        status.sunlit_leaf_fraction,
        T,
        :sunlit_leaf_fraction,
    )
    _require_leaf_partition_eltype(
        status.direct_effective_extinction_by_leaf_angle,
        T,
        :direct_effective_extinction_by_leaf_angle,
    )
    _require_leaf_partition_eltype(
        status.leaf_angle_fractions,
        T,
        :leaf_angle_fractions,
    )

    daylight = status.astronomical_daylight
    absorption_available = status.shortwave_absorption_available
    extinction_available = status.beam_extinction_available
    daylight isa Bool || throw(ArgumentError("astronomical_daylight must be Bool"))
    absorption_available isa Bool || throw(
        ArgumentError("shortwave_absorption_available must be Bool"),
    )
    extinction_available isa Bool || throw(
        ArgumentError("beam_extinction_available must be Bool"),
    )
    beam_fraction_par = _leaf_partition_float(
        T,
        status.beam_fraction_par,
        "beam_fraction_par",
    )
    beam_extinction_coefficient = _leaf_partition_float(
        T,
        status.beam_extinction_coefficient,
        "beam_extinction_coefficient",
    )
    if !daylight || !absorption_available || !extinction_available
        return nothing
    end

    direct_available = status.direct_transmission_available
    direct_available isa AbstractVector{Bool} || throw(
        ArgumentError("direct_transmission_available must contain Bool values"),
    )
    leaf_radiation_partitioning!(
        status.leaf_radiation_area_fraction,
        status.leaf_radiation_absorbed_par_w_m2_leaf,
        status.leaf_radiation_absorbed_nir_w_m2_leaf,
        status.absorbed_direct_beam_normal_w_m2,
        status.absorbed_diffuse_shortwave_w_m2_leaf,
        status.sunlit_leaf_fraction,
        status.direct_effective_extinction_by_leaf_angle,
        direct_available,
        beam_extinction_coefficient,
        status.leaf_angle_fractions,
        beam_fraction_par;
        sun_shade_model=model.sun_shade_model,
    )
    metadata = _leaf_partition_metadata(
        model.sun_shade_model,
        beam_fraction_par,
        model.leaf_angle_count,
    )
    status.effective_sun_shade_model = metadata.effective_sun_shade_model
    status.active_leaf_radiation_class_count =
        metadata.active_leaf_radiation_class_count
    status.leaf_radiation_shaded_class_index =
        metadata.leaf_radiation_shaded_class_index
    status.leaf_radiation_partitioning_available = true
    return nothing
end
