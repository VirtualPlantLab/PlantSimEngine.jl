PlantSimEngine.@process "plant_water_storage" verbose = false

"""One accepted-step update of the legacy per-tree plant water store."""
struct PlantWaterStorageResult{T<:AbstractFloat}
    plant_water_storage_before_l::T
    plant_water_storage_withdrawal_l::T
    plant_water_storage_change_l::T
    plant_water_storage_l::T
    plant_water_storage_empty::Bool
    plant_water_storage_stop_requested::Bool
end

@noinline function _throw_plant_water_storage_numeric(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :nonnegative
        throw(DomainError(value, "$label must be non-negative"))
    elseif reason === :result
        throw(DomainError(value, "$label produced a non-finite plant water store"))
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _plant_water_storage_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real || _throw_plant_water_storage_numeric(name, value, :real)
    value isa Bool && _throw_plant_water_storage_numeric(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_plant_water_storage_numeric(name, converted, :finite)
    return converted
end

@inline function _validate_plant_storage_config(
    ::Type{T},
    config::PlantStorageConfig,
) where {T<:AbstractFloat}
    coefficient = _plant_water_storage_float(
        T,
        config.storage_coefficient,
        :storage_coefficient,
    )
    exponent = _plant_water_storage_float(
        T,
        config.storage_exponent,
        :storage_exponent,
    )
    stop_switch = config.stop_simulation_when_empty
    stop_switch in (0, 1) || throw(
        ArgumentError("stop_simulation_when_empty must be either zero or one"),
    )
    return coefficient, exponent, stop_switch
end

@inline function _initial_plant_water_storage(
    ::Type{T},
    config::PlantStorageConfig,
    initial_leaf_area_m2,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the plant-water-storage numeric type must be concrete"),
    )
    coefficient, exponent, _ = _validate_plant_storage_config(T, config)
    leaf_area = _plant_water_storage_float(
        T,
        initial_leaf_area_m2,
        :initial_leaf_area_m2,
    )
    leaf_area >= zero(T) || _throw_plant_water_storage_numeric(
        :initial_leaf_area_m2,
        leaf_area,
        :nonnegative,
    )
    storage = coefficient * leaf_area^(exponent + one(T))
    isfinite(storage) || _throw_plant_water_storage_numeric(
        :initial_plant_water_storage_l,
        storage,
        :result,
    )
    return storage
end

"""
    initial_plant_water_storage(config, initial_leaf_area_m2)

Initialize one target tree's historical plant water store, in the legacy
litre unit, from the first leaf-area table entry:

```text
store = storage_coefficient * initial_leaf_area_m2^(storage_exponent + 1)
```

The result uses the numeric type of `config`. The coefficient and exponent
may have any finite sign, as in the Fortran input contract. Leaf area must be
finite and non-negative, and the resulting power expression must be finite.
"""
function initial_plant_water_storage(
    config::PlantStorageConfig{T},
    initial_leaf_area_m2,
) where {T<:AbstractFloat}
    return _initial_plant_water_storage(T, config, initial_leaf_area_m2)
end

@inline function _plant_water_storage_step(
    ::Type{T},
    config::PlantStorageConfig,
    previous_plant_water_storage_l,
    transpiration_supply_deficit_mmol_h2o_tree_s;
    timestep_seconds,
) where {T<:AbstractFloat}
    isconcretetype(T) || throw(
        ArgumentError("the plant-water-storage numeric type must be concrete"),
    )
    _, _, stop_switch = _validate_plant_storage_config(T, config)
    previous_storage = _plant_water_storage_float(
        T,
        previous_plant_water_storage_l,
        :previous_plant_water_storage_l,
    )
    deficit = _plant_water_storage_float(
        T,
        transpiration_supply_deficit_mmol_h2o_tree_s,
        :transpiration_supply_deficit_mmol_h2o_tree_s,
    )
    deficit >= zero(T) || _throw_plant_water_storage_numeric(
        :transpiration_supply_deficit_mmol_h2o_tree_s,
        deficit,
        :nonnegative,
    )
    duration = _plant_water_storage_float(
        T,
        timestep_seconds,
        :timestep_seconds,
    )
    duration >= zero(T) || _throw_plant_water_storage_numeric(
        :timestep_seconds,
        duration,
        :nonnegative,
    )
    litres_per_mmol_h2o = T(18) / T(1_000_000)
    withdrawal = deficit * duration * litres_per_mmol_h2o
    storage = previous_storage - withdrawal
    isfinite(withdrawal) || _throw_plant_water_storage_numeric(
        :plant_water_storage_withdrawal_l,
        withdrawal,
        :result,
    )
    isfinite(storage) || _throw_plant_water_storage_numeric(
        :plant_water_storage_l,
        storage,
        :result,
    )
    empty = storage <= zero(T)
    return PlantWaterStorageResult{T}(
        previous_storage,
        withdrawal,
        -withdrawal,
        storage,
        empty,
        stop_switch == 1 && empty,
    )
end

"""
    plant_water_storage_step(config, previous_plant_water_storage_l,
                             transpiration_supply_deficit_mmol_h2o_tree_s;
                             timestep_seconds)

Apply the historical one-way storage diagnostic for one accepted simulation
step:

```text
withdrawal (L tree-1) = deficit (mmol H2O tree-1 s-1) * seconds * 18e-6
new store              = previous store - withdrawal
```

The previous store owns the result type. No recharge or lower clamp is added:
the store may become negative. `plant_water_storage_stop_requested` reports
the `STOPSIMONEMPTY` decision without throwing or stopping PlantSimEngine.
"""
function plant_water_storage_step(
    config::PlantStorageConfig,
    previous_plant_water_storage_l::T,
    transpiration_supply_deficit_mmol_h2o_tree_s;
    timestep_seconds,
) where {T<:AbstractFloat}
    return _plant_water_storage_step(
        T,
        config,
        previous_plant_water_storage_l,
        transpiration_supply_deficit_mmol_h2o_tree_s;
        timestep_seconds,
    )
end

"""
    MAESPAPlantWaterStorage(config)

PlantSimEngine wrapper for MAESPA's diagnostic per-tree water store. The two
external inputs are deliberately required: the initial leaf area must come
from the first structural leaf-area table row, and the transpiration deficit
must come from a real soil-supply coupling or an explicit controlled input.
The optional `transpiration_supply_deficit_available` gate defaults to `true`
for backward compatibility. When false, the wrapper does not read the deficit
or initialize/debit the store; it republishes the accepted temporal state with
`plant_water_storage_available=false`.

Use `maespa_plant_water_storage_modelspec` to bind the store and its
initialization flag through `PreviousTimeStep`. Consequently, repeated calls
within one base step recompute from the same accepted state rather than
accumulating trial-iteration withdrawals.
"""
struct MAESPAPlantWaterStorage{T<:AbstractFloat} <:
       AbstractPlant_Water_StorageModel
    config::PlantStorageConfig{T}

    function MAESPAPlantWaterStorage(
        config::PlantStorageConfig{T},
    ) where {T<:AbstractFloat}
        isconcretetype(T) || throw(
            ArgumentError("the plant-water-storage numeric type must be concrete"),
        )
        _validate_plant_storage_config(T, config)
        return new{T}(config)
    end
end

PlantSimEngine.variable_contracts_(::MAESPAPlantWaterStorage) = (
    transpiration_supply_deficit_mmol_h2o_tree_s=
        PLANT_TRANSPIRATION_SUPPLY_DEFICIT_CONTRACT,
)

PlantSimEngine.environment_inputs_(::MAESPAPlantWaterStorage) =
    (duration=PlantSimEngine.Required(Union{Real,Dates.Period,Dates.CompoundPeriod}),)

function PlantSimEngine.inputs_(::MAESPAPlantWaterStorage{T}) where {T}
    return (
        initial_leaf_area_m2=PlantSimEngine.Required(Real),
        transpiration_supply_deficit_mmol_h2o_tree_s=
            PlantSimEngine.Required(Real),
        transpiration_supply_deficit_available=PlantSimEngine.Default(true),
        previous_plant_water_storage_l=PlantSimEngine.Default(zero(T)),
        previous_plant_water_storage_initialized=
            PlantSimEngine.Default(false),
    )
end

function PlantSimEngine.outputs_(::MAESPAPlantWaterStorage{T}) where {T}
    return (
        plant_water_storage_before_l=zero(T),
        plant_water_storage_withdrawal_l=zero(T),
        plant_water_storage_change_l=zero(T),
        plant_water_storage_l=zero(T),
        plant_water_storage_empty=false,
        plant_water_storage_stop_requested=false,
        plant_water_storage_initialized=false,
        plant_water_storage_available=false,
    )
end

function PlantSimEngine.run!(
    model::MAESPAPlantWaterStorage,
    status,
    environment,
    constants,
    context,
)
    T = typeof(status.plant_water_storage_l)
    T <: AbstractFloat || throw(
        ArgumentError("plant_water_storage_l must have an AbstractFloat type"),
    )
    initialized = status.previous_plant_water_storage_initialized
    initialized isa Bool || throw(
        ArgumentError("previous_plant_water_storage_initialized must be Bool"),
    )
    deficit_available = status.transpiration_supply_deficit_available
    deficit_available isa Bool || throw(
        ArgumentError("transpiration_supply_deficit_available must be Bool"),
    )
    if !deficit_available
        previous_storage = _plant_water_storage_float(
            T,
            status.previous_plant_water_storage_l,
            :previous_plant_water_storage_l,
        )
        status.plant_water_storage_before_l = previous_storage
        status.plant_water_storage_withdrawal_l = zero(T)
        status.plant_water_storage_change_l = zero(T)
        status.plant_water_storage_l = previous_storage
        status.plant_water_storage_empty = previous_storage <= zero(T)
        status.plant_water_storage_stop_requested = false
        status.plant_water_storage_initialized = initialized
        status.plant_water_storage_available = false
        return nothing
    end
    previous_storage = if initialized
        _plant_water_storage_float(
            T,
            status.previous_plant_water_storage_l,
            :previous_plant_water_storage_l,
        )
    else
        _initial_plant_water_storage(
            T,
            model.config,
            status.initial_leaf_area_m2,
        )
    end
    result = _plant_water_storage_step(
        T,
        model.config,
        previous_storage,
        status.transpiration_supply_deficit_mmol_h2o_tree_s;
        timestep_seconds=_maespa_timestep_seconds(T, environment),
    )
    status.plant_water_storage_before_l =
        result.plant_water_storage_before_l
    status.plant_water_storage_withdrawal_l =
        result.plant_water_storage_withdrawal_l
    status.plant_water_storage_change_l = result.plant_water_storage_change_l
    status.plant_water_storage_l = result.plant_water_storage_l
    status.plant_water_storage_empty = result.plant_water_storage_empty
    status.plant_water_storage_stop_requested =
        result.plant_water_storage_stop_requested
    status.plant_water_storage_initialized = true
    status.plant_water_storage_available = true
    return nothing
end

"""
    maespa_plant_water_storage_modelspec(config;
                                         name=:plant_water_storage,
                                         on=PlantSimEngine.Many(scale=:Plant,
                                                                kind=:plant),
                                         inputs=NamedTuple())

Build the opt-in, per-plant `plant_water_storage` application at base cadence.
The previous store and initialization flag are temporal bindings owned by
`name`. Set a distinct name when mounting separate storage applications; both
self-history bindings follow it. Callers must
bind `initial_leaf_area_m2` and
`transpiration_supply_deficit_mmol_h2o_tree_s`. They may additionally bind
`transpiration_supply_deficit_available`; its model default is `true`.
Override `on` with an explicit
Plant selector when only MAESPA target trees own a store. The high-level
builder mounts `plant_water_storage_N` on each distinct selected Plant only
with `mount_non_tuzet_leaf_exchange=true`
and `SIMSTORE=1`, after the per-Crown `SUMHR` aggregation has published a
real transpiration-supply deficit.
"""
function maespa_plant_water_storage_modelspec(
    config::PlantStorageConfig;
    name=:plant_water_storage,
    on=PlantSimEngine.Many(scale=:Plant, kind=:plant),
    inputs=NamedTuple(),
)
    inputs isa NamedTuple || throw(
        ArgumentError("inputs must be a NamedTuple of PlantSimEngine selectors"),
    )
    allowed_inputs = (
        :initial_leaf_area_m2,
        :transpiration_supply_deficit_mmol_h2o_tree_s,
        :transpiration_supply_deficit_available,
    )
    for input_name in keys(inputs)
        input_name in allowed_inputs || throw(
            ArgumentError("unsupported plant-water-storage input `$input_name`"),
        )
    end
    name isa Union{Symbol,AbstractString} || throw(
        ArgumentError("the plant-water-storage application name must be a Symbol or string"),
    )
    application_name = Symbol(name)
    temporal_inputs = (
        PlantSimEngine.PreviousTimeStep(:previous_plant_water_storage_l) =>
        PlantSimEngine.One(
            within=PlantSimEngine.Self(),
            application=application_name,
            var=:plant_water_storage_l,
        ),
        PlantSimEngine.PreviousTimeStep(
            :previous_plant_water_storage_initialized,
        ) => PlantSimEngine.One(
            within=PlantSimEngine.Self(),
            application=application_name,
            var=:plant_water_storage_initialized,
        ),
    )
    return PlantSimEngine.ModelSpec(
        MAESPAPlantWaterStorage(config);
        name=application_name,
        on=on,
        every=PlantSimEngine.ClockSpec(1, 1),
        inputs=(temporal_inputs..., pairs(inputs)...),
    )
end
