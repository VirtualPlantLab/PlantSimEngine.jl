PlantSimEngine.@process "leaf_exchange_daylight" verbose = false

@noinline function _throw_leaf_exchange_daylight_value(
    name::Symbol,
    value,
    reason::Symbol,
)
    label = String(name)
    if reason === :real
        throw(ArgumentError("$label must be a real number"))
    elseif reason === :bool
        throw(ArgumentError("$label must be numeric, not Bool"))
    elseif reason === :finite
        throw(ArgumentError("$label must be finite"))
    elseif reason === :type
        throw(
            ArgumentError(
                "the leaf-exchange-daylight numeric type must be a concrete " *
                "AbstractFloat",
            ),
        )
    end
    throw(ArgumentError("invalid $label"))
end

@inline function _leaf_exchange_daylight_float(
    ::Type{T},
    value,
    name::Symbol,
) where {T<:AbstractFloat}
    value isa Real ||
        _throw_leaf_exchange_daylight_value(name, value, :real)
    value isa Bool &&
        _throw_leaf_exchange_daylight_value(name, value, :bool)
    converted = convert(T, value)
    isfinite(converted) ||
        _throw_leaf_exchange_daylight_value(name, converted, :finite)
    return converted
end

@inline function _leaf_exchange_daylight(
    ::Type{T},
    sun_zenith_rad::T,
    incident_par_w_m2::T,
    target_leaf_area_m2::T,
) where {T<:AbstractFloat}
    return abs(sun_zenith_rad) < T(pi) / T(2) &&
           incident_par_w_m2 > one(T) &&
           target_leaf_area_m2 > zero(T)
end

"""
    leaf_exchange_daylight(
        sun_zenith_rad,
        incident_par_w_m2,
        target_leaf_area_m2,
    )

Evaluate the historical MAESPA leaf-exchange day/night gate. The result is
`true` exactly when

```julia
abs(sun_zenith_rad) < pi / 2 &&
incident_par_w_m2 > 1 &&
target_leaf_area_m2 > 0
```

All three comparisons are deliberately strict, matching the executable gate
in `maespa.f90`. Inputs are promoted to one floating-point type before the
thresholds are constructed, so an all-`Float32` call remains `Float32` while
mixed floating-point inputs follow Julia's ordinary promotion rules.
"""
function leaf_exchange_daylight(
    sun_zenith_rad,
    incident_par_w_m2,
    target_leaf_area_m2,
)
    raw_values = (
        (sun_zenith_rad, :sun_zenith_rad),
        (incident_par_w_m2, :incident_par_w_m2),
        (target_leaf_area_m2, :target_leaf_area_m2),
    )
    for (value, name) in raw_values
        value isa Real ||
            _throw_leaf_exchange_daylight_value(name, value, :real)
        value isa Bool &&
            _throw_leaf_exchange_daylight_value(name, value, :bool)
    end
    promoted = promote(float.(first.(raw_values))...)
    T = typeof(first(promoted))
    T <: AbstractFloat && isconcretetype(T) ||
        _throw_leaf_exchange_daylight_value(:numeric_type, T, :type)
    values = ntuple(
        index -> _leaf_exchange_daylight_float(
            T,
            promoted[index],
            raw_values[index][2],
        ),
        Val(3),
    )
    return _leaf_exchange_daylight(T, values...)
end

"""
    MAESPACrownLeafExchangeDaylight([T=Float64])

PlantSimEngine adapter for the historical leaf-exchange day/night gate,
intended to be mounted on each target Crown.

`leaf_exchange_daylight_inputs_available=false` publishes an unavailable,
false decision without inspecting the three numeric carriers. This lets an
upstream unavailable meteorological snapshot carry non-finite placeholders
without accidentally selecting the night branch as a valid result.

The adapter derives the effective calculation type from its status inputs at
run time. Consequently `CompositeModel(...;
type_promotion=Dict(Float64 => Float32))` applies to the calculation without
hard-coding `Float32` in the scientific gate.
"""
struct MAESPACrownLeafExchangeDaylight <:
       AbstractLeaf_Exchange_DaylightModel end

function MAESPACrownLeafExchangeDaylight(
    ::Type{T},
) where {T<:AbstractFloat}
    isconcretetype(T) ||
        _throw_leaf_exchange_daylight_value(:numeric_type, T, :type)
    return MAESPACrownLeafExchangeDaylight()
end

PlantSimEngine.inputs_(::MAESPACrownLeafExchangeDaylight) = (
    sun_zenith_rad=PlantSimEngine.Required(Real),
    incident_par_w_m2=PlantSimEngine.Required(Real),
    target_leaf_area_m2=PlantSimEngine.Required(Real),
    leaf_exchange_daylight_inputs_available=PlantSimEngine.Default(true),
)

PlantSimEngine.variable_contracts_(::MAESPACrownLeafExchangeDaylight) = (
    incident_par_w_m2=HORIZONTAL_PAR_IRRADIANCE_CONTRACT,
)

PlantSimEngine.outputs_(::MAESPACrownLeafExchangeDaylight) = (
    leaf_exchange_daylight=false,
    leaf_exchange_daylight_available=false,
)

function PlantSimEngine.run!(
    ::MAESPACrownLeafExchangeDaylight,
    status,
    environment,
    constants,
    context,
)
    available = status.leaf_exchange_daylight_inputs_available
    available isa Bool || throw(
        ArgumentError("leaf_exchange_daylight_inputs_available must be Bool"),
    )

    status.leaf_exchange_daylight = false
    status.leaf_exchange_daylight_available = false
    available || return nothing

    daylight = leaf_exchange_daylight(
        status.sun_zenith_rad,
        status.incident_par_w_m2,
        status.target_leaf_area_m2,
    )
    status.leaf_exchange_daylight = daylight
    status.leaf_exchange_daylight_available = true
    return nothing
end
