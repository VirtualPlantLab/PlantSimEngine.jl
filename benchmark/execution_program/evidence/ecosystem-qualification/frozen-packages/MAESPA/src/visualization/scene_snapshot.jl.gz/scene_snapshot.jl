"""
One tree's prescribed geometry at a snapshot date, in metres (leaf area in m²).

`position` is the ground anchor in the translated MAESPA scene frame.
`crown_base_height` is measured above this anchor, not above the plot origin.
`stem_diameter === nothing` means that no DIAM trajectory was supplied; it
does not mean a zero-width stem. Crown-shaped objects representing historical
trunks are retained as ordinary crowns, without changing their radiative role.
"""
struct TreeSnapshot{T<:AbstractFloat}
    id::Int
    species_id::Int
    species_name::String
    position::NTuple{3,T}
    crown_shape::CrownShape{T}
    radius_x::T
    radius_y::T
    crown_depth::T
    crown_base_height::T
    leaf_area::T
    stem_diameter::Union{Nothing,T}
end

"""
A dated copy of prescribed scene geometry, independent of Makie and simulation.

`date50` follows MAESPA's one-based calendar. `plot` retains the source origin,
bearing and dimensions; `ground_corners` and tree positions are already in the
translated simulation frame. The four ground corners run counterclockwise
from (0, 0). The snapshot owns its tree vector and stores no trajectory arrays.
It is not a snapshot of simulated water, temperature, or growth states.
"""
struct SceneSnapshot{T<:AbstractFloat}
    date50::Int
    plot::LegacyPlotConfig{T}
    ground_corners::NTuple{4,NTuple{3,T}}
    trees::Vector{TreeSnapshot{T}}
end

"""
    scene_snapshot(scene::LegacyTreeScene, species::SpeciesSet; date)
    scene_snapshot(input::LegacyInputSet; date=input.config.start_date)

Copy the prescribed geometry at `date`, using the same interpolation as the
tree-dimensions model. `date` is a `LegacyDate` or integer `days_since_1950`;
dates outside trajectory ranges clamp to their endpoints. No simulation or
plotting backend is started.

All trees are retained once, including non-target neighbours outside the plot.
Tree IDs select identities, while `trajectory_index` selects dimension columns.
All six historical crown shapes and the input numeric type are preserved.
Coordinates are not rotated by BEARING or translated a second time. Ground
corners use READXYZ's historical `z = (x*sin(XSLOPE) + y*sin(YSLOPE))/2`.
Native tree ground elevations are preserved even if they differ from that plane.
"""
function scene_snapshot(
    scene::LegacyTreeScene{T},
    species::SpeciesSet{T};
    date::Union{LegacyDate,Integer},
) where {T<:AbstractFloat}
    date50 = _tree_dimension_day(date)
    _tree_indices_by_id(scene)
    dimensions_model = MAESPATreeDimensions(scene.trajectories)
    plot = scene.plot
    plot.plot_shape == 0 || throw(ArgumentError("MAESPA snapshots require a rectangular plot"))
    all(isfinite, (plot.origin..., plot.upper_corner..., plot.slope_rad..., plot.bearing_rad)) ||
        throw(ArgumentError("snapshot plot coordinates, slopes and bearing must be finite"))
    width, depth = plot_dimensions(plot)
    all(x -> isfinite(x) && x > zero(T), (width, depth)) ||
        throw(ArgumentError("snapshot plot dimensions must be finite and positive"))
    all(pair -> pair[1] == pair[2].id, enumerate(species)) ||
        throw(ArgumentError("snapshot species must be ordered by IDs 1:length(species)"))

    # Preserve the historical ground convention; do not replace sin/2 by tan
    # or rotate the input coordinates for display.
    ground_corners = map(((zero(T), zero(T)), (width, zero(T)),
                          (width, depth), (zero(T), depth))) do (x, y)
        (x, y, (x * sin(plot.slope_rad[1]) + y * sin(plot.slope_rad[2])) / T(2))
    end
    trees = TreeSnapshot{T}[]
    sizehint!(trees, length(scene.trees))
    for tree in scene.trees
        1 <= tree.species_id <= length(species) || throw(BoundsError(species, tree.species_id))
        all(isfinite, tree.position) || throw(ArgumentError("tree $(tree.id) position must be finite"))
        parameters = species[tree.species_id]
        _crown_shape_code(parameters.structure.crown.legacy_code)
        dimensions = _tree_dimensions_at(dimensions_model, date50, tree.trajectory_index)
        all(x -> isnothing(x) || (isfinite(x) && x >= zero(T)), values(dimensions)) ||
            throw(ArgumentError("tree $(tree.id) snapshot dimensions must be finite and non-negative"))
        push!(trees, TreeSnapshot{T}(
            tree.id, tree.species_id, parameters.name, tree.position,
            parameters.structure.crown, dimensions.radius_x, dimensions.radius_y,
            dimensions.crown_depth, dimensions.crown_base_height,
            dimensions.leaf_area, dimensions.stem_diameter,
        ))
    end
    return SceneSnapshot{T}(date50, plot, ground_corners, trees)
end

function scene_snapshot(input::LegacyInputSet; date=input.config.start_date)
    isnothing(input.tree_scene) && throw(ArgumentError("scene_snapshot requires tree trajectories"))
    input.species isa SpeciesSet || throw(ArgumentError("scene_snapshot requires species crown shapes"))
    return scene_snapshot(input.tree_scene, input.species; date)
end

"""
    plot_scene(snapshot::SceneSnapshot; figure=(;), axis=(;), legend=true, kwargs...)

Render a prescribed scene after loading a Makie backend, for example
`using Makie; using CairoMakie`. Return `(figure, axis, plots)`; save with
`save("scene.png", result.figure)`. The new Axis3 uses metre labels and equal
data aspect. `figure` and `axis` are named tuples of Makie attributes.

The optional extension draws the plot ground and boundary, each crown, and
stems whose positive diameter and height are known. It does not simulate light
or invent roots, leaves or missing stem dimensions. See [`plot_scene!`](@ref)
for rendering keywords. Makie is not loaded by MAESPA itself.
"""
function plot_scene end

"""
    plot_scene!(axis, snapshot::SceneSnapshot;
        resolution=(32, 16), species_colors=nothing, crown_alpha=0.75,
        show_stems=true, show_ids=false, ground_color=:wheat,
        boundary_color=:gray35, stem_color=:sienna4)

Add scene geometry to an existing Makie Axis3 without changing its camera or
aspect. Returns named plot handles: `ground`, `boundary`, `crowns`, `stems`,
and `labels`; tree plots are keyed by stable tree ID. Existing plots are kept.

`resolution` gives azimuthal (at least 4) and vertical (at least 2) rendering
segments, unrelated to scientific canopy discretisation. Colours are stable
by species ID, or may be supplied with `species_colors=Dict(id => color, ...)`.
Zero-volume crowns are not drawn, but their records remain in the snapshot.
Missing/zero stem dimensions do not produce fictitious stems. `show_ids`
labels the crown tops, including zero-sized trees. No input data are mutated.

Load a Makie backend before calling this optional extension method.
"""
function plot_scene! end
