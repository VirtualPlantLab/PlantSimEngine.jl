function _quadrature_cell_tree(tree::TreeSnapshot{T}) where {T}
    all(isfinite, tree.position) ||
        throw(ArgumentError("quadrature cells require a finite tree position"))
    for (name, value) in ((:radius_x, tree.radius_x), (:radius_y, tree.radius_y),
                          (:crown_depth, tree.crown_depth))
        isfinite(value) && value > zero(T) ||
            throw(ArgumentError("quadrature cells require finite positive $name"))
    end
    isfinite(tree.crown_base_height) ||
        throw(ArgumentError("quadrature cells require a finite crown_base_height"))
    return _crown_shape_code(tree.crown_shape.legacy_code)
end

function _rotate_quadrature_section(point::NTuple{2,T}, quadrant::Int) where {T}
    x, y = point
    quadrant == 1 && return (x, y)
    quadrant == 2 && return (-y, x)
    quadrant == 3 && return (-x, -y)
    return (y, -x)
end

function _quadrature_box_section(a::T, b::T, odd_layer::Bool, quadrant::Int) where {T}
    # Odd layers sample the four axis-centred wedges of a square annulus.
    # Even layers sample its four Cartesian quadrants; for a > 0 these are
    # concave L-polygons, not their (larger) convex hulls.
    vertices = odd_layer ? ((a, -a), (b, -b), (b, b), (a, a)) :
                          ((a, zero(T)), (b, zero(T)), (b, b),
                           (zero(T), b), (zero(T), a), (a, a))
    section = NTuple{2,T}[]
    for vertex in vertices
        rotated = _rotate_quadrature_section(vertex, quadrant)
        (isempty(section) || last(section) != rotated) && push!(section, rotated)
    end
    length(section) > 1 && first(section) == last(section) && pop!(section)
    return Tuple(section)
end

"""
    quadrature_cells(tree::TreeSnapshot, nolay::Integer, pplay::Integer)

Describe the within-layer equal-volume partition associated with historical
`POINTSNEW` sampling of one positive-volume crown, without loading any plotting
package. Cells in different-height layers need not have the same volume.
The returned vector follows the original point order and has exactly
`nolay * pplay` records. `nolay` and `pplay` are scientific discretisation
parameters, not rendering resolutions.

Each record contains `point_index`, `geometric_layer` (bottom upwards),
`physiological_layer` (top downwards), `quadrant`, `radial_index`,
`normalized_height_bounds`, `radial_bounds`, `angular_bounds`, `cross_section`,
and `volume_m3`. Height bounds are fractions of crown depth; add the tree's
ground elevation and crown-base height to obtain absolute coordinates. Radial
bounds are `sqrt((i-1)/PPQ)` and `sqrt(i/PPQ)`, where `PPQ = pplay ÷ 4`.

For crown shapes 1:5, `angular_bounds` delimit a quarter of an annulus in the
normalised ellipse and `cross_section` is `nothing`. At each relative height
`h`, map `(ρ, θ)` to `(rx * SURFACE(h) * ρ * cos(θ),
ry * SURFACE(h) * ρ * sin(θ))`. Odd-layer sectors are centred on the four
normalised axes; even layers use the Cartesian quadrants. In an anisotropic
crown, an even-layer representative point need not be the angular midpoint.

For BOX (shape 6), `angular_bounds` is `nothing` and `cross_section` is a
counterclockwise tuple of normalised `(x/rx, y/ry)` vertices. Odd layers use
axis-centred trapezoids; even layers use Cartesian square-annulus quadrants
(concave L-polygons when the inner radius is positive). Extrude these sections
between the layer's heights. All six shapes give exactly the original
`crown_segment_volume(...) / pplay` per record.

`POINTSNEW` specifies locations and associated volumes, not unique voxel
boundaries. These cells are an explicit, quadrature-consistent display
partition, not additional simulated voxels or interpolated predictions.
Their sample is a radial midpoint, not generally a volume centroid. A renderer
may tessellate the curved boundaries more finely without changing the cells,
their scientific volumes, their locations, or their computed values. For a
replaced/custom sampler, first recognise its actual retained layout rather
than assuming this partition applies.
"""
function quadrature_cells(tree::TreeSnapshot{T}, nolay::Integer, pplay::Integer) where {T}
    grid = _canopy_discretisation(nolay, pplay)
    shape_code = _quadrature_cell_tree(tree)
    quadrant_count = grid.nolay * grid.ppq
    return map(1:grid.point_count) do point_index
        quadrant = div(point_index - 1, quadrant_count) + 1
        local_index = mod(point_index - 1, quadrant_count)
        layer = div(local_index, grid.ppq) + 1
        radial_index = mod(local_index, grid.ppq) + 1
        height_bounds = (T(layer - 1) / T(grid.nolay), T(layer) / T(grid.nolay))
        radial_bounds = (sqrt(T(radial_index - 1) / T(grid.ppq)),
                         sqrt(T(radial_index) / T(grid.ppq)))
        odd_layer = isodd(layer)
        angular_bounds = if shape_code == 6
            nothing
        else
            lower = T(quadrant - 1) * T(π) / T(2) -
                    (odd_layer ? T(π) / T(4) : zero(T))
            (lower, lower + T(π) / T(2))
        end
        cross_section = shape_code == 6 ?
            _quadrature_box_section(radial_bounds..., odd_layer, quadrant) : nothing
        volume_m3 = crown_segment_volume(shape_code,
            height_bounds[2] * tree.crown_depth, height_bounds[1] * tree.crown_depth,
            tree.radius_x, tree.radius_y, tree.crown_depth) / T(grid.pplay)
        return (; point_index, geometric_layer=layer,
                physiological_layer=grid.nolay - layer + 1, quadrant, radial_index,
                normalized_height_bounds=height_bounds, radial_bounds,
                angular_bounds, cross_section, volume_m3)
    end
end

function _quadrature_layout_tolerance(value, fallback, name)
    isnothing(value) && return fallback
    value isa Real && !(value isa Bool) && isfinite(value) && value >= zero(value) ||
        throw(ArgumentError("$name must be finite and non-negative"))
    return value
end

"""
    _recognizes_quadrature_layout(tree, nolay, pplay, point_indices, positions;
        representative_volumes=nothing, rtol=nothing, atol=nothing)

Recognise retained coordinates as the configured `POINTSNEW` layout before
offering its display cells. `positions` contains absolute three-coordinate
tuples aligned with `point_indices`; all configured indices must occur exactly
once, in any order. Optionally also check one associated volume per point.
Malformed, incomplete or different layouts return `false`; invalid tree/grid
configuration and invalid tolerances throw at this boundary.

Default tolerances use eight epsilons of the least precise supplied floating
storage type, permitting retained status storage to differ from parameter
storage (for example through `type_promotion`). `atol` has coordinate units
(metres), scaled by crown dimensions by default; volume recognition uses the
relative tolerance only. This numerical recognition does not assert that a
custom sampler chose the same, nonunique ownership boundaries.
"""
function _recognizes_quadrature_layout(tree::TreeSnapshot{T}, nolay::Integer,
        pplay::Integer, point_indices, positions;
        representative_volumes=nothing, rtol=nothing, atol=nothing) where {T}
    grid = _canopy_discretisation(nolay, pplay)
    shape_code = _quadrature_cell_tree(tree)
    rtol = _quadrature_layout_tolerance(rtol, nothing, "rtol")
    atol = _quadrature_layout_tolerance(atol, nothing, "atol")
    length(point_indices) == length(positions) == grid.point_count || return false
    isnothing(representative_volumes) ||
        length(representative_volumes) == grid.point_count || return false

    precision = eps(T)
    for position in positions
        length(position) == 3 || return false
        for value in position
            value isa Real && !(value isa Bool) && isfinite(value) || return false
            value isa AbstractFloat && (precision = max(precision, eps(typeof(value))))
        end
    end
    if !isnothing(representative_volumes)
        for value in representative_volumes
            value isa Real && !(value isa Bool) && isfinite(value) || return false
            value isa AbstractFloat && (precision = max(precision, eps(typeof(value))))
        end
    end
    relative_tolerance = isnothing(rtol) ? T(8) * precision : rtol
    absolute_tolerance = isnothing(atol) ?
        T(8) * precision * max(one(T), tree.radius_x, tree.radius_y, tree.crown_depth) : atol
    expected = crown_quadrature(tree.position..., tree.radius_x, tree.radius_y,
        tree.crown_depth, tree.crown_base_height, shape_code, grid.nolay, grid.pplay)
    seen = falses(grid.point_count)
    for (row, (point_index, position)) in enumerate(zip(point_indices, positions))
        point_index isa Integer && !(point_index isa Bool) || return false
        1 <= point_index <= grid.point_count || return false
        seen[point_index] && return false
        seen[point_index] = true
        coordinates = (expected.representative_x[point_index],
                       expected.representative_y[point_index],
                       expected.representative_z[point_index])
        all(zip(position, coordinates)) do (actual, reference)
            isapprox(actual, reference; rtol=relative_tolerance, atol=absolute_tolerance)
        end || return false
        if !isnothing(representative_volumes)
            isapprox(representative_volumes[row], expected.representative_volumes[point_index];
                rtol=relative_tolerance, atol=zero(T)) || return false
        end
    end
    return all(seen)
end
