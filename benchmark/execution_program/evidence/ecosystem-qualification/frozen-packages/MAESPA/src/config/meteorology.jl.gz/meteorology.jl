@enum MeteorologyFrequency::UInt8 begin
    DailyMeteorology = 0
    SubdailyMeteorology = 1
end

"""One source column declared by a historical `METFORMAT` namelist."""
struct MeteorologyColumn
    source_index::Int
    raw_name::String
    variable::Union{Nothing,Symbol}
end

"""A localized, non-destructive diagnostic emitted while reading met data."""
struct MeteorologyDiagnostic
    level::Symbol
    code::Symbol
    location::SourceLocation
    message::String
end

"""Monthly mean daily temperature amplitudes (°C) for historical `BRISTO`."""
struct BristowParameters{T<:AbstractFloat}
    monthly_temperature_amplitude_c::NTuple{12,T}

    function BristowParameters(amplitudes::NTuple{12,T}) where {T<:AbstractFloat}
        all(value -> isfinite(value) && value >= zero(T), amplitudes) || throw(
            ArgumentError("BRISTO.DELTAT must contain finite nonnegative temperature amplitudes"),
        )
        return new{T}(amplitudes)
    end
end

function BristowParameters(amplitudes::AbstractVector{T}) where {T<:AbstractFloat}
    length(amplitudes) == 12 || throw(ArgumentError("BRISTO.DELTAT requires 12 monthly amplitudes"))
    return BristowParameters(Tuple(amplitudes))
end

"""Typed metadata and constants from a MAESPA meteorological file."""
struct MeteorologyConfig{T<:AbstractFloat}
    source::String
    title::String
    data_start_line::Int
    day_or_hour::Int
    frequency::MeteorologyFrequency
    steps_per_day::Int
    step_seconds::T
    declared_column_count::Int
    column_count::Int
    columns::Vector{MeteorologyColumn}
    column_lookup::Dict{Symbol,Int}
    start_date::LegacyDate
    end_date::LegacyDate
    constant_co2::T
    constant_pressure_pa::T
    diffuse_sky::T
    soil_water_min::T
    soil_water_max::T
    diagnostics::Vector{MeteorologyDiagnostic}
    bristow::Union{Nothing,BristowParameters{T}}
end

"""
    LegacyMeteorology{T}

Source meteorological records in their declared column order. Rows are kept
exactly as read; `date50` and `step_index` are derived from `STARTDATE` and row
position because the Fortran reader ignores `TIME` and uses `DATE/DOY` only as
a within-block consistency check.
"""
struct LegacyMeteorology{T<:AbstractFloat}
    config::MeteorologyConfig{T}
    values::Matrix{T}
    date50::Vector{Int}
    step_index::Vector{Int}
    declared_day::Union{Nothing,Vector{Int}}
    declared_step::Union{Nothing,Vector{Int}}
    source_lines::Vector{Int}
    diagnostics::Vector{MeteorologyDiagnostic}
end

Base.length(meteorology::LegacyMeteorology) = size(meteorology.values, 1)

const _MAX_METEOROLOGY_COLUMNS = 21
const _MAX_METEOROLOGY_STEPS_PER_DAY = 96

const _SUBDAILY_METEOROLOGY_COLUMNS = Dict(
    "DATE" => :declared_day,
    "DOY" => :declared_day,
    "TIME" => :declared_step,
    "WIND" => :wind_speed,
    "TAIR" => :air_temperature,
    "TSOIL" => :soil_temperature,
    "RH" => :relative_humidity,
    "RH%" => :relative_humidity_percent,
    "VPD" => :vapour_pressure_deficit,
    "PAR" => :incident_par_photons,
    "RAD" => :global_radiation,
    "FBEAM" => :beam_fraction,
    "CA" => :co2,
    "MFD" => :mole_fraction_deficit,
    "VMFD" => :mole_fraction_deficit,
    "PRESS" => :air_pressure,
    "TDEW" => :dew_temperature,
    "PPT" => :precipitation,
    "ET" => :measured_evapotranspiration,
    "SMD" => :soil_moisture_deficit,
    "SWC" => :soil_water_content,
    "SW" => :soil_water_content,
    "SWP" => :soil_water_potential,
    "RTHERM" => :thermal_radiation,
)

const _DAILY_METEOROLOGY_COLUMNS = Dict(
    "DATE" => :declared_day,
    "DOY" => :declared_day,
    "WIND" => :wind_speed,
    "TMIN" => :minimum_air_temperature,
    "TMAX" => :maximum_air_temperature,
    "PAR" => :daily_incident_par,
    "SI" => :daily_global_radiation,
    "FBEAM" => :beam_fraction,
    "CA" => :co2,
    "PRESS" => :air_pressure,
    "PPT" => :precipitation,
    "SMD" => :soil_moisture_deficit,
    "SWP" => :soil_water_potential,
    "SWC" => :soil_water_content,
    "SW" => :soil_water_content,
    "ET" => :measured_evapotranspiration,
    "RTHERM" => :thermal_radiation,
)

function _canonical_meteorology_column(
    label::AbstractString,
    frequency::MeteorologyFrequency,
    mode::Symbol,
)
    key = mode === :strict ? uppercase(String(label)) : String(label)
    vocabulary = frequency === DailyMeteorology ?
                 _DAILY_METEOROLOGY_COLUMNS : _SUBDAILY_METEOROLOGY_COLUMNS
    return get(vocabulary, key, nothing)
end

function _meteorology_data_marker(document::NamelistDocument)
    matches = filter(
        entry -> rstrip(last(entry)) == "DATA STARTS",
        document.free_text,
    )
    isempty(matches) && throw(
        ArgumentError("could not find literal DATA STARTS in $(document.source)"),
    )
    return first(matches)
end

function _meteorology_title(document::NamelistDocument, mode::Symbol)
    first_line = findfirst(entry -> first(entry) == 1, document.free_text)
    isnothing(first_line) && return ""
    title = String(rstrip(last(document.free_text[first_line])))
    if mode === :strict && length(title) > 60
        throw(ArgumentError("meteorology title exceeds the historical A60 field"))
    end
    return length(title) <= 60 ? title : first(title, 60)
end

function _optional_meteorology_group(document::NamelistDocument, name::Symbol)
    try
        return namelist_group(document, name)
    catch exception
        exception isa KeyError || rethrow()
        return nothing
    end
end

function _meteorology_header_diagnostic(
    document::NamelistDocument,
    group::NamelistGroup,
    code::Symbol,
    message::AbstractString,
)
    return MeteorologyDiagnostic(
        :warning,
        code,
        SourceLocation(document.source, group.location.line),
        String(message),
    )
end

function _meteorology_config(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    _check_input_mode(mode)
    metformat = _config_group(document, :metformat, mode)
    environ = _optional_meteorology_group(document, :environ)
    marker = _meteorology_data_marker(document)
    diagnostics = MeteorologyDiagnostic[]

    day_or_hour = _integer_value(metformat, :dayorhr)
    if mode === :strict
        day_or_hour in (0, 1) || throw(ArgumentError("DAYORHR must be 0 or 1"))
    end
    frequency = day_or_hour == 0 ? DailyMeteorology : SubdailyMeteorology

    steps_per_day = _integer_value(metformat, :khrsperday)
    1 <= steps_per_day <= _MAX_METEOROLOGY_STEPS_PER_DAY || throw(
        ArgumentError(
            "KHRSPERDAY must be between 1 and $_MAX_METEOROLOGY_STEPS_PER_DAY",
        ),
    )

    declared_column_count = _integer_value(metformat, :nocolumns)
    declared_column_count > 0 || throw(ArgumentError("NOCOLUMNS must be positive"))
    column_count = declared_column_count
    if column_count > _MAX_METEOROLOGY_COLUMNS
        mode === :strict && throw(
            ArgumentError("NOCOLUMNS must not exceed $_MAX_METEOROLOGY_COLUMNS"),
        )
        push!(
            diagnostics,
            _meteorology_header_diagnostic(
                document,
                metformat,
                :column_count_truncated,
                "NOCOLUMNS=$column_count is truncated to $_MAX_METEOROLOGY_COLUMNS",
            ),
        )
        column_count = _MAX_METEOROLOGY_COLUMNS
    end

    raw_columns = _string_values(metformat, :columns)
    if mode === :strict && length(raw_columns) != declared_column_count
        throw(
            ArgumentError(
                "COLUMNS has $(length(raw_columns)) labels but NOCOLUMNS=" *
                "$declared_column_count",
            ),
        )
    end
    length(raw_columns) >= column_count || throw(
        ArgumentError(
            "COLUMNS provides $(length(raw_columns)) labels for $column_count columns",
        ),
    )

    columns = MeteorologyColumn[]
    lookup = Dict{Symbol,Int}()
    for source_index in 1:column_count
        original = raw_columns[source_index]
        if mode === :strict && length(original) > 8
            throw(ArgumentError("meteorology column $(repr(original)) exceeds 8 characters"))
        end
        effective = length(original) <= 8 ? original : first(original, 8)
        variable = _canonical_meteorology_column(effective, frequency, mode)
        if isnothing(variable)
            if mode === :strict
                throw(ArgumentError("unknown meteorology column $(repr(original))"))
            end
            push!(
                diagnostics,
                _meteorology_header_diagnostic(
                    document,
                    metformat,
                    :unknown_column,
                    "unknown meteorology column $(repr(original)) is retained and ignored",
                ),
            )
        elseif mode === :strict && haskey(lookup, variable)
            throw(ArgumentError("duplicate meteorology variable $variable"))
        else
            # Historical aliases overwrite the previous mapping.
            lookup[variable] = source_index
        end
        push!(columns, MeteorologyColumn(source_index, effective, variable))
    end

    required = frequency === DailyMeteorology ?
               (:minimum_air_temperature, :maximum_air_temperature) :
               (:air_temperature,)
    for variable in required
        haskey(lookup, variable) || throw(
            ArgumentError("missing required meteorology column $variable"),
        )
    end

    has_radiation = if frequency === DailyMeteorology
        haskey(lookup, :daily_incident_par) || haskey(lookup, :daily_global_radiation)
    else
        haskey(lookup, :incident_par_photons) || haskey(lookup, :global_radiation)
    end
    bristow_group = _optional_meteorology_group(document, :bristo)
    has_radiation || !isnothing(bristow_group) || throw(ArgumentError(
        "meteorology needs PAR/RAD (or PAR/SI daily) or a BRISTO group",
    ))
    # READDELTAT is only called when radiation is absent. Do not turn an
    # unused historical group into a new requirement for measured forcing.
    bristow = has_radiation ? nothing : BristowParameters(_real_values(bristow_group, :deltat, T))

    constant_co2 = isnothing(environ) ? zero(T) :
                   _real_value(environ, :ca, T; default=zero(T))
    constant_pressure = isnothing(environ) ? T(101_250) :
                        _real_value(environ, :press, T; default=T(101_250))
    diffuse_sky = isnothing(environ) ? zero(T) :
                  _real_value(environ, :difsky, T; default=zero(T))
    soil_water_min = isnothing(environ) ? zero(T) :
                     _real_value(environ, :swmin, T; default=zero(T))
    soil_water_max = isnothing(environ) ? one(T) :
                     _real_value(environ, :swmax, T; default=one(T))
    if iszero(constant_co2) && !haskey(lookup, :co2)
        throw(ArgumentError("meteorology needs ENVIRON.CA or a CA column"))
    end

    start_date = legacy_date(_string_value(metformat, :startdate); mode=mode)
    end_date = legacy_date(_string_value(metformat, :enddate); mode=mode)
    end_date.days_since_1950 >= start_date.days_since_1950 || throw(
        ArgumentError("meteorology ENDDATE precedes STARTDATE"),
    )

    return MeteorologyConfig(
        document.source,
        _meteorology_title(document, mode),
        first(marker),
        day_or_hour,
        frequency,
        steps_per_day,
        T(86_400) / T(steps_per_day),
        declared_column_count,
        column_count,
        columns,
        lookup,
        start_date,
        end_date,
        constant_co2,
        constant_pressure,
        diffuse_sky,
        soil_water_min,
        soil_water_max,
        diagnostics,
        bristow,
    )
end

function _parse_fortran_real(
    text::AbstractString,
    ::Type{T},
    location::SourceLocation,
) where {T<:AbstractFloat}
    normalized = replace(String(text), 'd' => 'e', 'D' => 'E')
    value = tryparse(T, normalized)
    isnothing(value) && throw(
        ArgumentError(
            "invalid meteorology number $(repr(text)) at " *
            "$(location.file):$(location.line)",
        ),
    )
    return value
end

function _declared_integer_column(
    values::AbstractVector{T},
    lines::Vector{Int},
    source::String,
    mode::Symbol,
    name::Symbol,
) where {T<:AbstractFloat}
    result = Vector{Int}(undef, length(values))
    for index in eachindex(values)
        value = values[index]
        isfinite(value) || throw(
            ArgumentError("$name must be finite at $source:$(lines[index])"),
        )
        if mode === :strict && !isinteger(value)
            throw(ArgumentError("$name must be an integer at $source:$(lines[index])"))
        end
        result[index] = trunc(Int, value)
    end
    return result
end

function _meteorology_record_diagnostics!(
    diagnostics::Vector{MeteorologyDiagnostic},
    config::MeteorologyConfig,
    declared_day,
    declared_step,
    source_lines,
    record_count::Int,
    mode::Symbol,
)
    expected_days = config.end_date.days_since_1950 -
                    config.start_date.days_since_1950 + 1
    expected_records = config.frequency === DailyMeteorology ?
                       expected_days : expected_days * config.steps_per_day
    if record_count != expected_records
        message = "meteorology has $record_count records; header implies $expected_records"
        mode === :strict && throw(ArgumentError(message))
        line = isempty(source_lines) ? config.data_start_line : first(source_lines)
        push!(
            diagnostics,
            MeteorologyDiagnostic(
                :warning,
                :record_count_mismatch,
                SourceLocation(config.source, line),
                message,
            ),
        )
    end

    if mode === :strict
        block_size = config.frequency === DailyMeteorology ? 1 :
                     config.steps_per_day
        for block_start in 1:block_size:record_count
            block_end = min(block_start + block_size - 1, record_count)
            if !isnothing(declared_day)
                day_key = declared_day[block_start]
                all(
                    ==(day_key),
                    @view(declared_day[block_start:block_end]),
                ) || throw(
                    ArgumentError(
                        "declared DATE/DOY changes within the meteorology block " *
                        "starting at $(config.source):$(source_lines[block_start])",
                    ),
                )
            end
            if !isnothing(declared_step) &&
               config.frequency === SubdailyMeteorology
                supplied = @view declared_step[block_start:block_end]
                expected = 1:(block_end - block_start + 1)
                all(supplied .== expected) || throw(
                    ArgumentError(
                        "declared TIME sequence for the meteorology block at " *
                        "$(config.source):$(source_lines[block_start]) is not " *
                        "1:$(length(expected))",
                    ),
                )
            end
        end
        return diagnostics
    end

    isnothing(declared_day) && return diagnostics
    group_start = 1
    while group_start <= record_count
        group_end = group_start
        while group_end < record_count &&
              declared_day[group_end + 1] == declared_day[group_start]
            group_end += 1
        end
        group_length = group_end - group_start + 1
        expected_group_length = config.frequency === DailyMeteorology ? 1 :
                                config.steps_per_day
        if group_length != expected_group_length
            message = "declared day $(declared_day[group_start]) has $group_length records; " *
                      "expected $expected_group_length"
            push!(
                diagnostics,
                MeteorologyDiagnostic(
                    :warning,
                    :day_record_count_mismatch,
                    SourceLocation(config.source, source_lines[group_start]),
                    message,
                ),
            )
        end
        if !isnothing(declared_step) && config.frequency === SubdailyMeteorology
            supplied = @view declared_step[group_start:group_end]
            expected = 1:group_length
            if !all(supplied .== expected)
                message = "declared TIME sequence for day $(declared_day[group_start]) is not 1:$group_length"
                push!(
                    diagnostics,
                    MeteorologyDiagnostic(
                        :warning,
                        :step_sequence_mismatch,
                        SourceLocation(config.source, source_lines[group_start]),
                        message,
                    ),
                )
            end
        end
        group_start = group_end + 1
    end
    return diagnostics
end

function _meteorology_table(
    document::NamelistDocument,
    config::MeteorologyConfig{T},
    mode::Symbol,
) where {T<:AbstractFloat}
    raw_records = Pair{Int,String}[]
    for entry in document.free_text
        first(entry) > config.data_start_line || continue
        line = _strip_namelist_comment(last(entry))
        isempty(strip(line)) && continue
        push!(raw_records, first(entry) => line)
    end

    values = Matrix{T}(undef, length(raw_records), config.column_count)
    source_lines = Vector{Int}(undef, length(raw_records))
    for (record_index, entry) in enumerate(raw_records)
        line_number, line = entry
        fields = split(replace(strip(line), ',' => ' '))
        if mode === :strict && length(fields) != config.column_count
            throw(
                ArgumentError(
                    "expected $(config.column_count) meteorology fields at " *
                    "$(config.source):$line_number, got $(length(fields))",
                ),
            )
        end
        length(fields) >= config.column_count || throw(
            ArgumentError(
                "expected $(config.column_count) meteorology fields at " *
                "$(config.source):$line_number, got $(length(fields))",
            ),
        )
        source_lines[record_index] = line_number
        for column_index in 1:config.column_count
            value = _parse_fortran_real(
                fields[column_index],
                T,
                SourceLocation(config.source, line_number),
            )
            mode === :strict && !isfinite(value) && throw(
                ArgumentError(
                    "meteorology values must be finite at $(config.source):$line_number",
                ),
            )
            values[record_index, column_index] = value
        end
    end

    record_count = size(values, 1)
    date50 = Vector{Int}(undef, record_count)
    step_index = Vector{Int}(undef, record_count)
    for record_index in 1:record_count
        if config.frequency === DailyMeteorology
            date50[record_index] = config.start_date.days_since_1950 + record_index - 1
            step_index[record_index] = 1
        else
            day_offset, step_offset = divrem(record_index - 1, config.steps_per_day)
            date50[record_index] = config.start_date.days_since_1950 + day_offset
            step_index[record_index] = step_offset + 1
        end
    end

    day_column = get(config.column_lookup, :declared_day, nothing)
    declared_day = isnothing(day_column) ? nothing : _declared_integer_column(
        @view(values[:, day_column]),
        source_lines,
        config.source,
        mode,
        :DATE,
    )
    step_column = get(config.column_lookup, :declared_step, nothing)
    declared_step = isnothing(step_column) ? nothing : _declared_integer_column(
        @view(values[:, step_column]),
        source_lines,
        config.source,
        mode,
        :TIME,
    )

    diagnostics = copy(config.diagnostics)
    _meteorology_record_diagnostics!(
        diagnostics,
        config,
        declared_day,
        declared_step,
        source_lines,
        record_count,
        mode,
    )
    return LegacyMeteorology(
        config,
        values,
        date50,
        step_index,
        declared_day,
        declared_step,
        source_lines,
        diagnostics,
    )
end

"""Read the typed meteorological table retained in a parsed MAESPA document."""
function read_meteorology(
    document::NamelistDocument;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
)
    config = _meteorology_config(document, mode, T)
    return _meteorology_table(document, config, mode)
end

"""Read one historical `met.dat` file."""
function read_meteorology(
    path::AbstractString;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
)
    return read_meteorology(read_namelist(path; mode=mode); mode=mode, T=T)
end

"""Return a zero-copy view of one canonical source column, or `nothing`."""
function meteorology_column(meteorology::LegacyMeteorology, variable::Symbol)
    column_index = get(meteorology.config.column_lookup, variable, nothing)
    isnothing(column_index) && return nothing
    return @view meteorology.values[:, column_index]
end
