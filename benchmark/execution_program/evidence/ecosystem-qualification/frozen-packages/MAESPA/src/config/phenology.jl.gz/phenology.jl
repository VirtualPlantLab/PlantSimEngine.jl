"""
    LegacyPhenologyInput{T}

Typed, source-located primary inputs from the historical `&PHENOLOGY` group.
`dt1_days` through `dt4_days` and `expansion_days` are days after the absolute
`flush_date`; `maximum_leaf_count` is an integer and `mature_leaf_area_m2` is
square metres per leaf. `location` identifies the original namelist group.

This is an **input record**, not a physically validated curve or a simulation
model. It requires finite, representable real inputs, but deliberately does not
choose phase ordering, nonnegative amplitudes, arithmetic/physical eligibility,
tree/species assignment, a LAI basis, or a plant-storage reference. Zero and
unordered durations are retained as data; no APP/EXPAN coefficients are derived.
Scene-level PHENOLOGY simulation remains explicitly unsupported.
"""
struct LegacyPhenologyInput{T<:AbstractFloat}
    flush_date::LegacyDate
    dt1_days::T
    dt2_days::T
    dt3_days::T
    dt4_days::T
    expansion_days::T
    maximum_leaf_count::Int
    mature_leaf_area_m2::T
    location::SourceLocation

    function LegacyPhenologyInput{T}(
        flush_date, dt1, dt2, dt3, dt4, expansion, maximum_leaf_count,
        mature_leaf_area, location::SourceLocation,
    ) where {T<:AbstractFloat}
        isconcretetype(T) || throw(ArgumentError("PHENOLOGY input type must be concrete"))
        flush_date isa LegacyDate || throw(ArgumentError("PHENOLOGY.FLUSHDATE must be a LegacyDate"))
        maximum_leaf_count isa Integer && !(maximum_leaf_count isa Bool) ||
            throw(ArgumentError("PHENOLOGY.MAXLEAVES must be an integer, not Bool"))
        count = Int(maximum_leaf_count)
        values = map(((:dt1, dt1), (:dt2, dt2), (:dt3, dt3), (:dt4, dt4),
            (:exptime, expansion), (:sizeleaf, mature_leaf_area))) do (name, value)
            _phenology_input_real(value, T, name, location)
        end
        return new{T}(flush_date, values[1], values[2], values[3], values[4],
            values[5], count, values[6], location)
    end
end

const _PHENOLOGY_INPUT_FIELDS =
    (:flushdate, :dt1, :dt2, :dt3, :dt4, :exptime, :maxleaves, :sizeleaf)
const _PHENOLOGY_REAL_FIELDS = (:dt1, :dt2, :dt3, :dt4, :exptime, :sizeleaf)

function _phenology_input_real(value, ::Type{T}, name, location) where {T<:AbstractFloat}
    field = "PHENOLOGY.$(uppercase(String(name)))"
    value isa Real && !(value isa Bool) && isfinite(value) || throw(ArgumentError(
        "$field must be a finite real, not Bool, at $(location.file):$(location.line)",
    ))
    converted = convert(T, value)
    isfinite(converted) || throw(ArgumentError(
        "$field must remain finite in $T at $(location.file):$(location.line)",
    ))
    return converted
end

# Preserve the ordinary scalar reader's ordered assignments, repetitions and
# null handling; add the schema field and location to its existing diagnostics.
function _phenology_input_field(reader, group::NamelistGroup, name)
    field = "PHENOLOGY.$(uppercase(String(name)))"
    _has_assignment(group, name) || throw(ArgumentError(
        "$field is required at $(group.location.file):$(group.location.line); " *
        "there is no PHENOLOGY input default",
    ))
    assignment = namelist_assignment(group, name; occurrence=:last)
    try
        return reader(assignment.location)
    catch exception
        exception isa Union{ArgumentError,InexactError,OverflowError,KeyError} || rethrow()
        throw(ArgumentError(
            "$field at $(assignment.location.file):$(assignment.location.line): " *
            sprint(showerror, exception),
        ))
    end
end

"""
    read_phenology_input(document_or_path; mode=:legacy, T=Float32)

Read the first `&PHENOLOGY` group into a [`LegacyPhenologyInput`](@ref).
All eight scalar inputs (`FLUSHDATE`, `DT1`–`DT4`, `EXPTIME`, `MAXLEAVES`,
`SIZELEAF`) are required. Dates use [`legacy_date`](@ref) with the selected
mode; real input storage uses `T`. Scalar assignments retain the common
namelist rules, including last concrete value and null preservation. Unknown
or indexed fields are diagnosed rather than silently ignored.

This reader neither falls back to LAREA nor installs a leaf-area law. A complete
historical PHENOLOGY group has priority over LAREA, but scene construction still
rejects PHENOLOGY until assignment, physical-domain and reference-area policies
are chosen. A returned input record is not scientific eligibility or support for
PHENOLOGY simulation, annual repetition, LAI or plant-water initialization.
"""
function read_phenology_input(
    document::NamelistDocument;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
)
    _check_input_mode(mode)
    isconcretetype(T) || throw(ArgumentError("PHENOLOGY input type must be concrete"))
    group = _config_group(document, :phenology, mode)
    for assignment in group.assignments
        assignment.name in _PHENOLOGY_INPUT_FIELDS || throw(ArgumentError(
            "unknown or indexed PHENOLOGY field $(assignment.original_name) at " *
            "$(assignment.location.file):$(assignment.location.line); " *
            "PHENOLOGY declares only its eight scalar inputs",
        ))
    end
    flush_date = _phenology_input_field(group, :flushdate) do _
        legacy_date(_string_value(group, :flushdate); mode)
    end
    count = _phenology_input_field(group, :maxleaves) do _
        _integer_value(group, :maxleaves)
    end
    reals = NamedTuple{_PHENOLOGY_REAL_FIELDS}(map(_PHENOLOGY_REAL_FIELDS) do name
        _phenology_input_field(group, name) do location
            _phenology_input_real(_real_value(group, name, T), T, name, location)
        end
    end)
    return LegacyPhenologyInput{T}(flush_date, reals.dt1, reals.dt2, reals.dt3,
        reals.dt4, reals.exptime, count, reals.sizeleaf, group.location)
end

function read_phenology_input(path::AbstractString; mode::Symbol=:legacy, kwargs...)
    return read_phenology_input(read_namelist(path; mode); mode, kwargs...)
end
