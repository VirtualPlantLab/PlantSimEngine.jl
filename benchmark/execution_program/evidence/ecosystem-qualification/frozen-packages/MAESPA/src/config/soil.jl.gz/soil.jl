"""
Resolved switches from the historical `&WATCONTROL` namelist.

The fields retain the legacy integer codes because `use_stand` and
`soil_water_method` are selections rather than Boolean switches. Fields that
are switches are validated as `0` or `1` when read.
"""
struct WaterBalanceOptions
    keep_wet::Int
    keep_dry::Int
    simulate_soil_temperature::Int
    reassign_rain::Int
    soil_water_method::Int
    retention_function::Int
    equal_uptake::Int
    use_measured_evapotranspiration::Int
    use_measured_soil_water::Int
    simulate_soil_evaporation::Int
    use_stand::Int
    simulate_storage::Int
    simulate_water_table::Int
    simulate_soil_dew::Int
end

"""Layer geometry and water-capacity parameters from `&LAYPARS`."""
struct SoilLayerConfig{T<:AbstractFloat}
    layer_count::Int
    thickness_m::Vector{T}
    core_water_content::T
    pore_fraction::Vector{T}
    drainage_limit::Vector{T}
    organic_fraction::Vector{T}
    water_table_layer::Union{Nothing,Int}
    plateau_drainage::T
end

"""
Soil-water retention parameters in the units consumed by Julia processes.

`method` is the historical `RETFUNCTION` code. Methods 1 and 2 use
`b_parameter` and `air_entry_water_potential_mpa`; method 3 uses
`alpha_mpa_inverse`, `saturated_water_content`, `residual_water_content`, and
`shape_parameter_n`. Arrays which were not supplied and are unused by the
selected method are `nothing`.

`saturated_hydraulic_conductivity_m_s` is canonical SI conductivity. MAESPA
reads `KSAT` in `mol m^-1 s^-1 MPa^-1` and performs exactly
`KSAT * 18.05e-6 * 9.8067 * 1e-3`, using respectively the partial molal volume
of water, gravitational acceleration, and the MPa conversion factor. The
conversion is evaluated in the requested floating-point type `T`.
"""
struct SoilRetentionConfig{T<:AbstractFloat}
    method::Int
    b_parameter::Union{Nothing,Vector{T}}
    air_entry_water_potential_mpa::Union{Nothing,Vector{T}}
    saturated_hydraulic_conductivity_m_s::Vector{T}
    alpha_mpa_inverse::Union{Nothing,Vector{T}}
    saturated_water_content::Union{Nothing,Vector{T}}
    residual_water_content::Union{Nothing,Vector{T}}
    shape_parameter_n::Union{Nothing,Vector{T}}
end

"""
Initial soil state from `&INITPARS`.

Temperatures deliberately remain in degrees Celsius and retain the raw
historical `SOILTEMP(1:n)` indexing. In the executable, `SOILTEMP(1)` first
provides the surface boundary while physical layers use `SOILTEMP(2:n+1)`,
with the last configured value duplicated at `n+1`. Conversion to the
profile-node representation and to kelvins belongs to the soil-temperature
process rather than input parsing.
"""
struct InitialSoilState{T<:AbstractFloat}
    water_content::Vector{T}
    temperature_c::Vector{T}
end

"""
    _legacy_soil_temperature_nodes_c(temperature_c)

Split the raw historical `SOILTEMP(1:n)` initialization into its surface
boundary and the `n` physical profile nodes represented in Julia. The latter
map to Fortran `SOILTEMP(2:n+1)`, hence `[raw[2:end]; raw[end]]`; a one-layer
profile duplicates its sole configured value. The input is never mutated.
"""
function _legacy_soil_temperature_nodes_c(
    temperature_c::AbstractVector{T},
) where {T<:AbstractFloat}
    Base.require_one_based_indexing(temperature_c)
    layer_count = length(temperature_c)
    layer_count > 0 || throw(
        ArgumentError("initial soil temperature must contain at least one layer"),
    )
    layer_temperatures_c = Vector{T}(undef, layer_count)
    if layer_count == 1
        layer_temperatures_c[1] = temperature_c[1]
    else
        copyto!(layer_temperatures_c, 1, temperature_c, 2, layer_count - 1)
        layer_temperatures_c[layer_count] = temperature_c[layer_count]
    end
    return (
        surface_temperature_c=temperature_c[1],
        layer_temperatures_c,
    )
end

"""Soil-evaporation parameters from `&SOILETPARS`."""
struct SoilEvaporationConfig{T<:AbstractFloat}
    minimum_dry_layer_thickness_m::T
    tortuosity::T
    dry_layer_thermal_conductivity::T
end

"""
Infiltration-depth distribution from the historical `&WATINFILT` group.

`exponent` is the dimensionless `EXPINF` used on cumulative relative soil
depth. The historical value zero sends all water to the first layer before
capacity overflow is carried downwards; one distributes water in proportion
to layer thickness. Negative values produce negative layer fractions and are
therefore rejected rather than repaired.
"""
struct SoilInfiltrationConfig{T<:AbstractFloat}
    exponent::T
end

"""
Canopy interception parameters from the historical `&WATTFALL` group.

Values are retained in the units consumed directly by `WATBALLAY`; no unit
conversion or formula correction is applied. In particular,
`maximum_storage` uses the same historical millimetre storage/rain basis as
`CANOPY_STORE` and `PPT`. `rutter_d` behaves as `mm min^-1` and `rutter_b` as
`mm^-1` in the implemented drainage equation, despite the legacy comment that
labels `RUTTERB` differently. The routine multiplies `MAXSTORAGE` by LAI in
some expressions but compares canopy storage with `MAXSTORAGE` alone in its
drainage threshold; this inconsistent historical scalar is preserved as-is.
The Fortran reader does not constrain the sign of `RUTTERB`, which enters
linearly in the exponential argument, so every finite value is retained.

A finite negative `throughfall` is not a fraction error: it is the historical
sentinel requesting `1 - min(max(LAI / 2.5, 0), 1)` at runtime. The negative
value is preserved here because the parser has no LAI. Exactly one, or a zero
`maximum_storage`, makes `WATBALLAY` bypass canopy interception and route all
rain directly to the soil.
"""
struct CanopyInterceptionConfig{T<:AbstractFloat}
    rutter_b::T
    rutter_d::T
    maximum_storage::T
    throughfall::T
end

"""
Plant-water storage parameters from the historical `&PLANTSTORAGE` group.

At the first simulated step, MAESPA initializes the water store of a target
tree from leaf area `A` as

```text
plant water (legacy litre label) = storage_coefficient * A^(storage_exponent + 1)
```

The Fortran reader applies no dimensional or sign checks to the two real
parameters, so Julia preserves every finite value. The runtime model will be
responsible for checking the formula's domain against the actual leaf area.
`stop_simulation_when_empty` retains the original integer switch so the input
contract remains explicit.
"""
struct PlantStorageConfig{T<:AbstractFloat}
    storage_coefficient::T
    storage_exponent::T
    stop_simulation_when_empty::Int
end

"""
Typed root-system parameters read from the historical `&ROOTPARS` group.

`root_layer_fractions` has dimensions `rooted layer × date × resolved scene
species`, matching the order in which `READROOTPARS` consumes the flattened
Fortran `FRACROOT` array. `input_profile_count` preserves `NOROOTSPEC`, while
`species_count` records the requested scene multiplicity. When a scene has
more species than input profiles, legacy mode reproduces the executable's
surprising rule: profile one replaces every species after the first, including
profiles that were explicitly supplied. Strict mode permits only an exact
profile count or the unambiguous broadcast of one profile.

The dated radius, specific-root-length, and total-mass vectors are shared by
all profiles, as in MAESPA. `specific_root_length_source` is `:root_srl` when
`ROOTSRL` was selected and `:root_density` when the historical
`1 / (ROOTDENS * 3.1415927 * ROOTRAD^2)` conversion was applied.

Root-front arrays retain the `NOROOTSPEC` width. `root_front_enabled` follows
the exact global switch in `READROOTPARS`: only `RFPAR1(1) != 0` controls it,
even when later profiles have non-zero coefficients.
"""
struct RootParametersConfig{T<:AbstractFloat}
    dates::Vector{LegacyDate}
    rooted_layer_count::Int
    input_profile_count::Int
    species_count::Int
    root_resistance_fraction::T
    root_radius_m::Vector{T}
    specific_root_length_m_g::Vector{T}
    total_root_mass_g_m2::Vector{T}
    root_layer_fractions::Array{T,3}
    root_beta::T
    specific_root_length_source::Symbol
    root_front_age_offset_days::Vector{Int}
    root_front_asymptotic_depth_m::Vector{T}
    root_front_rate_per_day::Vector{T}
    root_front_shape::Vector{T}
    root_front_enabled::Bool
end

"""
Typed plant-hydraulic parameters read from the historical `&PLANTPARS` group.

`plant_hydraulic_conductance_mmol_m2_leaf_s_mpa` is the dated `PLANTK` table and
`conductance_scaling_exponent` is `KSCALING`. Minimum leaf water potentials
are resolved to the requested scene species count with the executable
`FILLWITHLAST` rule. The scalar minimum root water potential reproduces the
legacy fallback to the first leaf value whenever `MINROOTWP < -900`.

The Fortran caller initializes `KSCALING` to zero, but `READPLANTPARS` copies
from an uninitialized local when the namelist omits it. Julia uses the intended
deterministic zero default instead of preserving undefined memory.
"""
struct PlantHydraulicConfig{T<:AbstractFloat}
    dates::Vector{LegacyDate}
    minimum_root_water_potential_mpa::T
    minimum_leaf_water_potential_mpa::Vector{T}
    plant_hydraulic_conductance_mmol_m2_leaf_s_mpa::Vector{T}
    conductance_scaling_exponent::T
end

"""
Typed configuration of the current MAESPA soil-input slice.

`WATCONTROL`, `LAYPARS`, `INITPARS`, `SOILRET`, and `SOILETPARS` are required.
`WATINFILT`, `WATTFALL`, `ROOTPARS`, `PLANTPARS`, and `PLANTSTORAGE` are parsed
when present and represented by optional fields, so older callers and partial
Julia fixtures remain valid. When `SIMSTORE=1`, `PLANTSTORAGE` is required just
as in the historical executable.

All real values are materialised in `T`. A later PlantSimEngine
`type_promotion` mapping transforms runtime statuses, not these configuration
objects; callers that want `Float32` parameters should therefore read with
`T=Float32` rather than relying on status promotion.
"""
struct SoilConfig{T<:AbstractFloat}
    source::String
    options::WaterBalanceOptions
    layers::SoilLayerConfig{T}
    retention::SoilRetentionConfig{T}
    initial_state::InitialSoilState{T}
    evaporation::SoilEvaporationConfig{T}
    infiltration::Union{Nothing,SoilInfiltrationConfig{T}}
    canopy_interception::Union{Nothing,CanopyInterceptionConfig{T}}
    root_parameters::Union{Nothing,RootParametersConfig{T}}
    plant_hydraulics::Union{Nothing,PlantHydraulicConfig{T}}
    plant_storage::Union{Nothing,PlantStorageConfig{T}}
end

function SoilConfig{T}(
    source::String,
    options::WaterBalanceOptions,
    layers::SoilLayerConfig{T},
    retention::SoilRetentionConfig{T},
    initial_state::InitialSoilState{T},
    evaporation::SoilEvaporationConfig{T},
) where {T<:AbstractFloat}
    return SoilConfig{T}(
        source,
        options,
        layers,
        retention,
        initial_state,
        evaporation,
        nothing,
        nothing,
        nothing,
        nothing,
        nothing,
    )
end

function SoilConfig{T}(
    source::String,
    options::WaterBalanceOptions,
    layers::SoilLayerConfig{T},
    retention::SoilRetentionConfig{T},
    initial_state::InitialSoilState{T},
    evaporation::SoilEvaporationConfig{T},
    infiltration::Union{Nothing,SoilInfiltrationConfig{T}},
    canopy_interception::Union{Nothing,CanopyInterceptionConfig{T}},
    root_parameters::Union{Nothing,RootParametersConfig{T}},
    plant_hydraulics::Union{Nothing,PlantHydraulicConfig{T}},
) where {T<:AbstractFloat}
    return SoilConfig{T}(
        source,
        options,
        layers,
        retention,
        initial_state,
        evaporation,
        infiltration,
        canopy_interception,
        root_parameters,
        plant_hydraulics,
        nothing,
    )
end

function SoilConfig(
    source::String,
    options::WaterBalanceOptions,
    layers::SoilLayerConfig{T},
    retention::SoilRetentionConfig{T},
    initial_state::InitialSoilState{T},
    evaporation::SoilEvaporationConfig{T},
) where {T<:AbstractFloat}
    return SoilConfig{T}(
        source,
        options,
        layers,
        retention,
        initial_state,
        evaporation,
    )
end

function SoilConfig{T}(
    source::String,
    options::WaterBalanceOptions,
    layers::SoilLayerConfig{T},
    retention::SoilRetentionConfig{T},
    initial_state::InitialSoilState{T},
    evaporation::SoilEvaporationConfig{T},
    infiltration::Union{Nothing,SoilInfiltrationConfig{T}},
    canopy_interception::Union{Nothing,CanopyInterceptionConfig{T}},
) where {T<:AbstractFloat}
    return SoilConfig{T}(
        source,
        options,
        layers,
        retention,
        initial_state,
        evaporation,
        infiltration,
        canopy_interception,
        nothing,
        nothing,
        nothing,
    )
end

function SoilConfig(
    source::String,
    options::WaterBalanceOptions,
    layers::SoilLayerConfig{T},
    retention::SoilRetentionConfig{T},
    initial_state::InitialSoilState{T},
    evaporation::SoilEvaporationConfig{T},
    infiltration::Union{Nothing,SoilInfiltrationConfig{T}},
    canopy_interception::Union{Nothing,CanopyInterceptionConfig{T}},
) where {T<:AbstractFloat}
    return SoilConfig{T}(
        source,
        options,
        layers,
        retention,
        initial_state,
        evaporation,
        infiltration,
        canopy_interception,
    )
end

function _soil_group(document::NamelistDocument, name::Symbol)
    try
        return namelist_group(document, name)
    catch exception
        exception isa KeyError || rethrow()
        throw(
            ArgumentError(
                "core soil configuration requires namelist " *
                "&$(uppercase(String(name))) in $(document.source)",
            ),
        )
    end
end

function _soil_optional_group(document::NamelistDocument, name::Symbol)
    try
        return namelist_group(document, name)
    catch exception
        exception isa KeyError || rethrow()
        return nothing
    end
end

_soil_has_array(group::NamelistGroup, name) =
    !isempty(_namelist_array_assignments(group, name))

function _soil_missing(group::NamelistGroup, name)
    return ArgumentError(
        "missing required $(uppercase(String(name))) in &$(group.original_name)",
    )
end

function _soil_integer(
    group::NamelistGroup,
    name;
    default=_NO_NAMELIST_DEFAULT,
)
    value = try
        _namelist_scalar_value(group, name; default=default)
    catch exception
        exception isa KeyError || rethrow()
        throw(_soil_missing(group, name))
    end
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError(
            "$(uppercase(String(name))) in &$(group.original_name) must be an integer, not Bool",
        ),
    )
    return Int(value)
end

function _soil_real(
    group::NamelistGroup,
    name,
    ::Type{T};
    default=_NO_NAMELIST_DEFAULT,
) where {T<:AbstractFloat}
    value = try
        _namelist_scalar_value(group, name; T=T, default=default)
    catch exception
        exception isa KeyError || rethrow()
        throw(_soil_missing(group, name))
    end
    value isa Real && !(value isa Bool) || throw(
        ArgumentError(
            "$(uppercase(String(name))) in &$(group.original_name) must be numeric, not Bool",
        ),
    )
    converted = convert(T, value)
    isfinite(converted) || throw(
        ArgumentError(
            "$(uppercase(String(name))) in &$(group.original_name) must be finite",
        ),
    )
    return converted
end

function _soil_selection(
    group::NamelistGroup,
    name,
    allowed;
    default=_NO_NAMELIST_DEFAULT,
)
    value = _soil_integer(group, name; default=default)
    value in allowed || throw(
        ArgumentError(
            "$(uppercase(String(name))) in &$(group.original_name) must be one of " *
            "$(join(allowed, ", ")); got $value",
        ),
    )
    return value
end

function _soil_flag(
    group::NamelistGroup,
    name;
    default=_NO_NAMELIST_DEFAULT,
)
    return _soil_selection(group, name, 0:1; default=default)
end

function _soil_array_slots(
    group::NamelistGroup,
    name,
    layer_count::Int,
    ::Type{T};
    initial,
) where {T<:AbstractFloat}
    return _namelist_array_values(
        group,
        name;
        T=T,
        initial=initial,
        fill_value=nothing,
        size=layer_count,
    )
end

function _soil_numeric_slot(value, group::NamelistGroup, name, ::Type{T}) where {T}
    value isa Real && !(value isa Bool) || throw(
        ArgumentError(
            "$(uppercase(String(name))) in &$(group.original_name) must contain numbers, not Bool",
        ),
    )
    converted = convert(T, value)
    isfinite(converted) || throw(
        ArgumentError(
            "$(uppercase(String(name))) in &$(group.original_name) must contain only finite values",
        ),
    )
    return converted
end

function _soil_last_filled_array(
    group::NamelistGroup,
    name,
    layer_count::Int,
    ::Type{T};
    required::Bool=true,
    mode::Symbol,
) where {T<:AbstractFloat}
    if !_soil_has_array(group, name)
        required && throw(_soil_missing(group, name))
        return nothing
    end
    slots = _soil_array_slots(
        group,
        name,
        layer_count,
        T;
        initial=fill(nothing, layer_count),
    )
    return _soil_last_filled_slots(group, name, slots, T; required, mode)
end

function _soil_last_filled_slots(
    group::NamelistGroup,
    name,
    slots::AbstractVector,
    ::Type{T};
    required::Bool=true,
    mode::Symbol,
) where {T<:AbstractFloat}
    layer_count = length(slots)
    if !required && mode === :legacy
        first_slot = slots[firstindex(slots)]
        first_is_legacy_empty = isnothing(first_slot) ||
                                _soil_numeric_slot(
            first_slot,
            group,
            name,
            T,
        ) <= T(-900)
        first_is_legacy_empty && return nothing
    end
    values = Vector{T}(undef, layer_count)
    has_previous = false
    for index in eachindex(slots)
        slot = slots[index]
        converted = if isnothing(slot)
            nothing
        else
            _soil_numeric_slot(slot, group, name, T)
        end
        sentinel = !isnothing(converted) && converted <= T(-900)
        if sentinel && mode === :strict
            throw(
                ArgumentError(
                    "$(uppercase(String(name))) in &$(group.original_name) contains the legacy empty sentinel at layer $index",
                ),
            )
        end
        if isnothing(converted) || sentinel
            has_previous || throw(
                ArgumentError(
                    "$(uppercase(String(name))) in &$(group.original_name) must define " *
                    "its first layer before null or trailing slots can be filled",
                ),
            )
            if mode === :legacy
                fill!(view(values, index:layer_count), values[index - 1])
                return values
            end
            values[index] = values[index - 1]
        else
            values[index] = converted
            has_previous = true
        end
    end
    return values
end

function _soil_layer_thickness(
    group::NamelistGroup,
    declared_count::Int,
    layer_count::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    declared_count == layer_count && return _soil_last_filled_array(
        group, :laythick, layer_count, T; mode,
    )
    _soil_has_array(group, :laythick) || throw(_soil_missing(group, :laythick))
    slots = _soil_array_slots(group, :laythick, layer_count, T;
        initial=fill(nothing, layer_count))
    # FILLWITHLAST runs before the root reader expands NLAYER. In legacy
    # mode it stops at the first prefix gap, ignoring later prefix slots.
    prefix = _soil_last_filled_slots(
        group, :laythick, view(slots, 1:declared_count), T; mode,
    )
    thickness = Vector{T}(undef, layer_count)
    thickness[1:declared_count] .= prefix
    for index in (declared_count + 1):layer_count
        slot = slots[index]
        isnothing(slot) && throw(ArgumentError(
            "NROOTLAYER > NLAYER requires explicit LAYTHICK at added layer $index",
        ))
        value = _soil_numeric_slot(slot, group, :laythick, T)
        value > zero(T) || throw(ArgumentError(
            "LAYTHICK at added layer $index must be positive",
        ))
        thickness[index] = value
    end
    return thickness
end

function _soil_zero_filled_array(
    group::NamelistGroup,
    name,
    layer_count::Int,
    ::Type{T},
) where {T<:AbstractFloat}
    _soil_has_array(group, name) || return zeros(T, layer_count)
    slots = _namelist_array_values(
        group,
        name;
        T=T,
        initial=zeros(T, layer_count),
        fill_value=zero(T),
        size=layer_count,
    )
    return [_soil_numeric_slot(value, group, name, T) for value in slots]
end

function _soil_validate_interval(values, lower, upper, name; lower_open::Bool=false)
    valid = lower_open ?
            all(value -> lower < value <= upper, values) :
            all(value -> lower <= value <= upper, values)
    valid || throw(
        ArgumentError(
            "$name must lie in " *
            (lower_open ? "($lower, $upper]" : "[$lower, $upper]"),
        ),
    )
    return values
end

function _soil_scene_species_count(value)
    isnothing(value) && return nothing
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError("species_count must be an integer, not Bool"),
    )
    count = Int(value)
    count > 0 || throw(ArgumentError("species_count must be positive"))
    return count
end

function _soil_positive_count(group::NamelistGroup, name; default)
    count = _soil_integer(group, name; default=default)
    count > 0 || throw(
        ArgumentError("$(uppercase(String(name))) in &$(group.original_name) must be positive"),
    )
    return count
end

function _soil_dated_values(
    group::NamelistGroup,
    name,
    count::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    _soil_has_array(group, name) || throw(_soil_missing(group, name))
    slots = _namelist_array_values(
        group,
        name;
        T=T,
        initial=fill(nothing, count),
        fill_value=nothing,
        size=mode === :strict ? count : nothing,
    )
    values = Vector{T}(undef, count)
    has_previous = false
    for index in 1:count
        slot = slots[index]
        converted = isnothing(slot) ? nothing :
                    _soil_numeric_slot(slot, group, name, T)
        is_legacy_empty = !isnothing(converted) && converted <= T(-900)
        if isnothing(converted) || is_legacy_empty
            if mode === :strict
                throw(
                    ArgumentError(
                        "$(uppercase(String(name))) in &$(group.original_name) " *
                        "must contain exactly $count concrete values",
                    ),
                )
            end
            has_previous || throw(
                ArgumentError(
                    "$(uppercase(String(name))) in &$(group.original_name) " *
                    "must define its first dated value",
                ),
            )
            fill!(view(values, index:count), values[index - 1])
            return values
        end
        values[index] = converted
        has_previous = true
    end
    return values
end

function _soil_dates(
    group::NamelistGroup,
    name,
    count::Int,
    mode::Symbol,
    ::Type{T};
    default::AbstractString="01/01/99",
) where {T<:AbstractFloat}
    raw = if !_soil_has_array(group, name)
        fill(String(default), count)
    else
        initial = mode === :strict ? fill(nothing, count) :
                  fill(String(default), count)
        values = _namelist_array_values(
            group,
            name;
            T=T,
            initial=initial,
            fill_value=mode === :strict ? nothing : String(default),
            size=mode === :strict ? count : nothing,
        )
        selected = values[1:count]
        all(value -> value isa AbstractString, selected) || throw(
            ArgumentError(
                "$(uppercase(String(name))) in &$(group.original_name) " *
                "must contain $count dates",
            ),
        )
        String.(selected)
    end
    dates = [legacy_date(value; mode=mode) for value in raw]
    for index in 2:length(dates)
        dates[index].days_since_1950 > dates[index - 1].days_since_1950 || throw(
            ArgumentError(
                "$(uppercase(String(name))) in &$(group.original_name) must be strictly increasing",
            ),
        )
    end
    return dates
end

function _soil_defaulted_real_array(
    group::NamelistGroup,
    name,
    count::Int,
    mode::Symbol,
    ::Type{T};
    default,
) where {T<:AbstractFloat}
    initial = fill(convert(T, default), count)
    !_soil_has_array(group, name) && return initial
    slots = _namelist_array_values(
        group,
        name;
        T=T,
        initial=initial,
        fill_value=convert(T, default),
        size=mode === :strict ? count : nothing,
    )
    return [
        _soil_numeric_slot(slots[index], group, name, T) for index in 1:count
    ]
end

function _soil_defaulted_integer_array(
    group::NamelistGroup,
    name,
    count::Int,
    mode::Symbol;
    default::Integer,
)
    initial = fill(Int(default), count)
    !_soil_has_array(group, name) && return initial
    slots = _namelist_array_values(
        group,
        name;
        initial=initial,
        fill_value=Int(default),
        size=mode === :strict ? count : nothing,
    )
    values = Vector{Int}(undef, count)
    for index in 1:count
        value = slots[index]
        value isa Integer && !(value isa Bool) || throw(
            ArgumentError(
                "$(uppercase(String(name))) in &$(group.original_name) must contain integers",
            ),
        )
        values[index] = Int(value)
    end
    return values
end

function _soil_root_source_values(
    group::NamelistGroup,
    name,
    count::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    sentinel = T(-999)
    !_soil_has_array(group, name) && return fill(sentinel, count)
    slots = _namelist_array_values(
        group,
        name;
        T=T,
        initial=fill(sentinel, count),
        fill_value=sentinel,
        size=mode === :strict ? count : nothing,
    )
    return [
        _soil_numeric_slot(slots[index], group, name, T) for index in 1:count
    ]
end

function _soil_complete_root_source!(
    values::Vector{T},
    mode::Symbol,
    label::AbstractString;
    strictly_positive::Bool,
) where {T<:AbstractFloat}
    valid(value) = strictly_positive ? value > zero(T) : value >= zero(T)
    valid(first(values)) || throw(
        ArgumentError("$label must define a non-negative first dated value"),
    )
    for index in eachindex(values)
        valid(values[index]) && continue
        mode === :strict && throw(
            ArgumentError("$label must contain one valid value per declared date"),
        )
        fill!(view(values, index:lastindex(values)), values[index - 1])
        return values
    end
    return values
end

function _soil_root_specific_length(
    group::NamelistGroup,
    root_radius::Vector{T},
    date_count::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    root_srl = _soil_root_source_values(
        group,
        :rootsrl,
        date_count,
        mode,
        T,
    )
    root_density = _soil_root_source_values(
        group,
        :rootdens,
        date_count,
        mode,
        T,
    )
    has_srl = first(root_srl) >= zero(T)
    has_density = first(root_density) >= zero(T)

    if has_srl && has_density
        mode === :strict && throw(
            ArgumentError(
                "strict mode accepts only one of ROOTSRL and ROOTDENS in &$(group.original_name)",
            ),
        )
        @warn "ROOTSRL and ROOTDENS are both present; legacy READROOTPARS uses ROOTSRL"
    end

    if has_srl
        _soil_complete_root_source!(
            root_srl,
            mode,
            "ROOTSRL in &$(group.original_name)";
            strictly_positive=false,
        )
        return root_srl, :root_srl
    end
    has_density || throw(
        ArgumentError(
            "&$(group.original_name) requires ROOTSRL or ROOTDENS with a non-negative first value",
        ),
    )
    _soil_complete_root_source!(
        root_density,
        mode,
        "ROOTDENS in &$(group.original_name)";
        strictly_positive=true,
    )
    legacy_pi = T(3.1415927)
    specific_length = Vector{T}(undef, date_count)
    for index in eachindex(specific_length)
        denominator = root_density[index] * legacy_pi * root_radius[index]^2
        denominator > zero(T) && isfinite(denominator) || throw(
            ArgumentError(
                "ROOTDENS and ROOTRAD must define a positive finite specific-root-length denominator",
            ),
        )
        specific_length[index] = inv(denominator)
        isfinite(specific_length[index]) || throw(
            ArgumentError("ROOTDENS conversion produced a non-finite ROOTSRL"),
        )
    end
    return specific_length, :root_density
end

function _soil_beta_root_fractions(
    beta::T,
    thickness_m::AbstractVector{T},
) where {T<:AbstractFloat}
    cumulative_depth_cm = zero(T)
    previous_cumulative_fraction = zero(T)
    fractions = Vector{T}(undef, length(thickness_m))
    for index in eachindex(thickness_m)
        cumulative_depth_cm += T(100) * thickness_m[index]
        cumulative_fraction = one(T) - beta^cumulative_depth_cm
        fractions[index] = cumulative_fraction - previous_cumulative_fraction
        previous_cumulative_fraction = cumulative_fraction
    end
    total = sum(fractions)
    total > zero(T) && isfinite(total) || throw(
        ArgumentError("ROOTBETA does not define a positive finite root profile"),
    )
    fractions ./= total
    all(value -> value >= zero(T) && isfinite(value), fractions) || throw(
        ArgumentError("ROOTBETA produces invalid root fractions"),
    )
    return fractions
end

function _soil_root_fraction_table(
    group::NamelistGroup,
    layers::SoilLayerConfig{T},
    rooted_layer_count::Int,
    date_count::Int,
    profile_count::Int,
    beta::T,
    mode::Symbol,
) where {T<:AbstractFloat}
    expected = rooted_layer_count * date_count * profile_count
    sentinel = T(-999.9)
    values = fill(sentinel, expected)
    has_explicit = _soil_has_array(group, :fracroot)
    if has_explicit
        raw = _namelist_array_values(
            group,
            :fracroot;
            T=T,
            initial=values,
            fill_value=sentinel,
            size=mode === :strict ? expected : nothing,
        )
        values .= [
            _soil_numeric_slot(raw[index], group, :fracroot, T) for
            index in 1:expected
        ]
    end

    if beta > zero(T)
        profile_count == 1 || throw(
            ArgumentError("ROOTBETA cannot be combined with NOROOTSPEC > 1"),
        )
        if mode === :strict && has_explicit &&
           any(>=(zero(T)), view(values, 1:rooted_layer_count))
            throw(
                ArgumentError(
                    "strict mode does not accept both ROOTBETA and explicit first-date FRACROOT values",
                ),
            )
        end
        values[1:rooted_layer_count] .= _soil_beta_root_fractions(
            beta,
            view(layers.thickness_m, 1:rooted_layer_count),
        )
    end

    for index in eachindex(values)
        values[index] >= zero(T) || throw(
            ArgumentError(
                "FRACROOT is missing or negative at flattened position $index " *
                "(layer varies fastest, then date, then root profile)",
            ),
        )
    end
    profile_table = reshape(values, rooted_layer_count, date_count, profile_count)
    for profile in 1:profile_count, date in 1:date_count
        total = sum(@view profile_table[:, date, profile])
        total > zero(T) && isfinite(total) || throw(
            ArgumentError(
                "FRACROOT must have a positive finite sum for date $date and profile $profile",
            ),
        )
    end
    return profile_table
end

function _soil_resolve_root_profiles(
    profile_table::Array{T,3},
    scene_species_count::Int,
    mode::Symbol,
) where {T<:AbstractFloat}
    profile_count = size(profile_table, 3)
    scene_species_count >= profile_count || throw(
        ArgumentError(
            "species_count ($scene_species_count) cannot be smaller than NOROOTSPEC ($profile_count)",
        ),
    )
    scene_species_count == profile_count && return copy(profile_table)
    if mode === :strict && profile_count != 1
        throw(
            ArgumentError(
                "strict mode requires NOROOTSPEC to equal species_count, or NOROOTSPEC=1 for broadcast",
            ),
        )
    end

    resolved = Array{T,3}(
        undef,
        size(profile_table, 1),
        size(profile_table, 2),
        scene_species_count,
    )
    for species in 1:scene_species_count
        # READROOTPARS copies profile one to every species after the first as
        # soon as NOSPEC exceeds NOROOTSPEC; this also overwrites explicitly
        # supplied intermediate profiles.
        source_profile = species == 1 || scene_species_count == profile_count ?
                         species : 1
        resolved[:, :, species] .= profile_table[:, :, source_profile]
    end
    return resolved
end

function _soil_root_parameters(
    group::NamelistGroup,
    layers::SoilLayerConfig{T},
    requested_species_count,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    rooted_layer_count = _soil_positive_count(group, :nrootlayer; default=0)
    rooted_layer_count <= layers.layer_count || throw(
        ArgumentError(
            "NROOTLAYER cannot exceed the resolved soil layer count",
        ),
    )
    date_count = _soil_positive_count(group, :nodatesroot; default=1)
    profile_count = _soil_positive_count(group, :norootspec; default=1)
    scene_species_count = isnothing(requested_species_count) ?
                          profile_count : requested_species_count
    dates = _soil_dates(
        group,
        :datesroot,
        date_count,
        mode,
        T;
        default="01/01/99",
    )

    resistance_fraction = _soil_real(group, :rootresfrac, T; default=one(T))
    if mode === :strict
        zero(T) <= resistance_fraction <= one(T) || throw(
            ArgumentError("ROOTRESFRAC must lie in [0, 1] in strict mode"),
        )
    end
    beta = _soil_real(group, :rootbeta, T; default=zero(T))
    beta >= zero(T) || throw(ArgumentError("ROOTBETA must be non-negative"))
    if beta > zero(T)
        beta < one(T) || throw(
            ArgumentError("positive ROOTBETA must be smaller than one"),
        )
    end

    root_radius = _soil_dated_values(
        group,
        :rootrad,
        date_count,
        mode,
        T,
    )
    all(>(zero(T)), root_radius) || throw(
        ArgumentError("ROOTRAD must contain positive radii"),
    )
    total_root_mass = _soil_dated_values(
        group,
        :rootmasstot,
        date_count,
        mode,
        T,
    )
    all(>=(zero(T)), total_root_mass) || throw(
        ArgumentError("ROOTMASSTOT must contain non-negative values"),
    )
    specific_root_length, specific_root_length_source =
        _soil_root_specific_length(
            group,
            root_radius,
            date_count,
            mode,
            T,
        )
    profile_table = _soil_root_fraction_table(
        group,
        layers,
        rooted_layer_count,
        date_count,
        profile_count,
        beta,
        mode,
    )
    resolved_table = _soil_resolve_root_profiles(
        profile_table,
        scene_species_count,
        mode,
    )

    root_front_age = _soil_defaulted_integer_array(
        group,
        :rfagebegin,
        profile_count,
        mode;
        default=999,
    )
    root_front_asymptote = _soil_defaulted_real_array(
        group,
        :rfpar1,
        profile_count,
        mode,
        T;
        default=zero(T),
    )
    root_front_rate = _soil_defaulted_real_array(
        group,
        :rfpar2,
        profile_count,
        mode,
        T;
        default=zero(T),
    )
    root_front_shape = _soil_defaulted_real_array(
        group,
        :rfpar3,
        profile_count,
        mode,
        T;
        default=zero(T),
    )
    root_front_enabled = !iszero(first(root_front_asymptote))
    if mode === :strict
        if root_front_enabled
            all(>(zero(T)), root_front_asymptote) || throw(
                ArgumentError("enabled RFPAR1 values must all be positive"),
            )
            all(>=(zero(T)), root_front_rate) || throw(
                ArgumentError("enabled RFPAR2 values must all be non-negative"),
            )
            all(>(zero(T)), root_front_shape) || throw(
                ArgumentError("enabled RFPAR3 values must all be positive"),
            )
        elseif any(!iszero, view(root_front_asymptote, 2:profile_count))
            throw(
                ArgumentError(
                    "RFPAR1(1)=0 disables root-front limiting globally; later non-zero RFPAR1 values are ignored by READROOTPARS",
                ),
            )
        end
    end

    return RootParametersConfig{T}(
        dates,
        rooted_layer_count,
        profile_count,
        scene_species_count,
        resistance_fraction,
        root_radius,
        specific_root_length,
        total_root_mass,
        resolved_table,
        beta,
        specific_root_length_source,
        root_front_age,
        root_front_asymptote,
        root_front_rate,
        root_front_shape,
        root_front_enabled,
    )
end

function _soil_minimum_leaf_potentials(
    group::NamelistGroup,
    species_count::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    sentinel = T(-999)
    slots = if _soil_has_array(group, :minleafwp)
        _namelist_array_values(
            group,
            :minleafwp;
            T=T,
            initial=fill(sentinel, species_count),
            fill_value=sentinel,
            size=mode === :strict ? species_count : nothing,
        )
    else
        fill(sentinel, species_count)
    end
    values = [
        _soil_numeric_slot(slots[index], group, :minleafwp, T) for
        index in 1:species_count
    ]
    first_empty = findfirst(value -> value <= sentinel, values)
    if !isnothing(first_empty)
        if mode === :strict && any(
            value -> value > sentinel,
            view(values, (first_empty + 1):species_count),
        )
            throw(
                ArgumentError(
                    "MINLEAFWP cannot contain concrete values after its first legacy empty slot",
                ),
            )
        end
        filled_length = first_empty - 1
        filled_length == 0 && (filled_length = 1)
        fill!(
            view(values, filled_length:species_count),
            values[filled_length],
        )
    end
    if mode === :strict
        all(value -> T(-900) < value < zero(T), values) || throw(
            ArgumentError(
                "MINLEAFWP must contain available negative water potentials in strict mode",
            ),
        )
    end
    return values
end

function _soil_plant_hydraulics(
    group::NamelistGroup,
    species_count::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    date_count = _soil_positive_count(group, :nodateskp; default=1)
    dates = _soil_dates(
        group,
        :dateskp,
        date_count,
        mode,
        T;
        default="01/01/99",
    )
    minimum_leaf = _soil_minimum_leaf_potentials(
        group,
        species_count,
        mode,
        T,
    )
    minimum_root_input = _soil_real(
        group,
        :minrootwp,
        T;
        default=T(-999),
    )
    minimum_root = minimum_root_input < T(-900) ?
                   first(minimum_leaf) : minimum_root_input
    if mode === :strict
        T(-900) < minimum_root < zero(T) || throw(
            ArgumentError(
                "MINROOTWP must resolve to an available negative water potential in strict mode",
            ),
        )
    end
    plant_conductance = _soil_dated_values(
        group,
        :plantk,
        date_count,
        mode,
        T,
    )
    all(>(zero(T)), plant_conductance) || throw(
        ArgumentError("PLANTK must contain positive conductances"),
    )
    conductance_scaling = _soil_real(
        group,
        :kscaling,
        T;
        default=zero(T),
    )
    return PlantHydraulicConfig{T}(
        dates,
        minimum_root,
        minimum_leaf,
        plant_conductance,
        conductance_scaling,
    )
end

function _soil_options(group::NamelistGroup, mode::Symbol)
    keep_wet = _soil_flag(group, :keepwet; default=0)
    keep_dry = _soil_flag(group, :keepdry; default=0)
    simulate_soil_temperature = _soil_flag(group, :simtsoil)
    reassign_rain = _soil_flag(group, :reassignrain)
    soil_water_method = _soil_selection(
        group,
        :wsoilmethod,
        (0, 1, 2, 4);
        default=1,
    )
    retention_function = _soil_selection(group, :retfunction, 1:3)
    equal_uptake = _soil_flag(group, :equaluptake; default=0)
    use_measured_evapotranspiration = _soil_flag(group, :usemeaset; default=0)
    use_measured_soil_water = _soil_flag(group, :usemeassw; default=0)
    simulate_soil_evaporation = _soil_flag(group, :simsoilevap; default=1)
    use_stand = _soil_selection(group, :usestand, 0:2; default=1)
    simulate_storage = _soil_flag(group, :simstore; default=0)
    simulate_water_table = _soil_flag(group, :isimwattab; default=0)
    simulate_soil_dew = _soil_flag(group, :isimsoildew; default=0)

    if use_measured_evapotranspiration == 1
        if mode === :strict &&
           (simulate_soil_temperature != 0 || equal_uptake != 1)
            throw(
                ArgumentError(
                    "USEMEASET=1 requires SIMTSOIL=0 and EQUALUPTAKE=1; " *
                    "legacy mode applies the historical override",
                ),
            )
        end
        simulate_soil_temperature = 0
        equal_uptake = 1
    end

    return WaterBalanceOptions(
        keep_wet,
        keep_dry,
        simulate_soil_temperature,
        reassign_rain,
        soil_water_method,
        retention_function,
        equal_uptake,
        use_measured_evapotranspiration,
        use_measured_soil_water,
        simulate_soil_evaporation,
        use_stand,
        simulate_storage,
        simulate_water_table,
        simulate_soil_dew,
    )
end

function _soil_layers(
    group::NamelistGroup,
    options::WaterBalanceOptions,
    mode::Symbol,
    ::Type{T};
    rooted_layer_count::Int=0,
) where {T<:AbstractFloat}
    declared_count = _soil_integer(group, :nlayer)
    declared_count > 0 || throw(ArgumentError("NLAYER must be positive"))
    layer_count = max(declared_count, rooted_layer_count)

    thickness = _soil_layer_thickness(
        group, declared_count, layer_count, mode, T,
    )
    all(>(zero(T)), thickness) || throw(
        ArgumentError("LAYTHICK must contain positive layer thicknesses"),
    )
    pore_fraction = _soil_last_filled_array(
        group,
        :porefrac,
        layer_count,
        T;
        mode=mode,
    )
    _soil_validate_interval(
        pore_fraction,
        zero(T),
        one(T),
        "POREFRAC";
        lower_open=true,
    )
    drainage_limit = _soil_last_filled_array(
        group,
        :drainlimit,
        layer_count,
        T,
        mode=mode,
    )
    _soil_validate_interval(
        drainage_limit,
        zero(T),
        one(T),
        "DRAINLIMIT",
    )
    organic_fraction = _soil_zero_filled_array(
        group,
        :fracorganic,
        layer_count,
        T,
    )
    _soil_validate_interval(
        organic_fraction,
        zero(T),
        one(T),
        "FRACORGANIC",
    )

    core_water_content = _soil_real(group, :corewater, T; default=zero(T))
    zero(T) <= core_water_content <= one(T) || throw(
        ArgumentError("COREWATER must lie in [0, 1]"),
    )
    plateau_drainage = _soil_real(group, :platdrain, T; default=zero(T))
    zero(T) <= plateau_drainage <= one(T) || throw(
        ArgumentError("PLATDRAIN must lie in [0, 1]"),
    )

    raw_water_table_layer = _soil_integer(group, :iwattablayer; default=-999)
    water_table_layer = if options.simulate_water_table == 0 && mode === :legacy
        nothing
    elseif raw_water_table_layer == -999
        nothing
    else
        1 <= raw_water_table_layer <= layer_count + 1 || throw(
            ArgumentError("IWATTABLAYER must be a 1-based index in 1:NLAYER+1"),
        )
        raw_water_table_layer
    end
    options.simulate_water_table == 1 && isnothing(water_table_layer) && throw(
        ArgumentError("ISIMWATTAB=1 requires a 1-based IWATTABLAYER"),
    )
    options.simulate_water_table == 1 && water_table_layer == 1 && throw(
        ArgumentError(
            "ISIMWATTAB=1 requires IWATTABLAYER in 2:NLAYER+1; layer 1 would index the legacy capillary boundary at zero",
        ),
    )

    return SoilLayerConfig{T}(
        layer_count,
        thickness,
        core_water_content,
        pore_fraction,
        drainage_limit,
        organic_fraction,
        water_table_layer,
        plateau_drainage,
    )
end

function _soil_optional_retention_array(
    group::NamelistGroup,
    name,
    layer_count::Int,
    ::Type{T};
    required::Bool,
    mode::Symbol,
) where {T<:AbstractFloat}
    return _soil_last_filled_array(
        group,
        name,
        layer_count,
        T;
        required=required,
        mode=mode,
    )
end

function _soil_retention(
    group::NamelistGroup,
    method::Int,
    layer_count::Int,
    water_table_enabled::Bool,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    campbell_required = method in (1, 2)
    van_genuchten_required = method == 3
    b_parameter = _soil_optional_retention_array(
        group,
        :bpar,
        layer_count,
        T;
        required=campbell_required,
        mode=mode,
    )
    air_entry = _soil_optional_retention_array(
        group,
        :psie,
        layer_count,
        T;
        required=campbell_required,
        mode=mode,
    )
    hydraulic_conductivity_input = _soil_last_filled_array(
        group,
        :ksat,
        layer_count,
        T,
        mode=mode,
    )
    alpha = _soil_optional_retention_array(
        group,
        :alpha,
        layer_count,
        T;
        required=van_genuchten_required,
        mode=mode,
    )
    saturated_water = _soil_optional_retention_array(
        group,
        :ws,
        layer_count,
        T;
        required=van_genuchten_required || water_table_enabled,
        mode=mode,
    )
    residual_water = _soil_optional_retention_array(
        group,
        :wr,
        layer_count,
        T;
        required=van_genuchten_required,
        mode=mode,
    )
    shape_n = _soil_optional_retention_array(
        group,
        :n,
        layer_count,
        T;
        required=van_genuchten_required,
        mode=mode,
    )

    isnothing(b_parameter) || all(>(zero(T)), b_parameter) || throw(
        ArgumentError("BPAR must contain positive values"),
    )
    isnothing(air_entry) || all(<(zero(T)), air_entry) || throw(
        ArgumentError("PSIE must contain negative water potentials in MPa"),
    )
    all(>=(zero(T)), hydraulic_conductivity_input) || throw(
        ArgumentError("KSAT must contain non-negative values"),
    )
    isnothing(alpha) || all(>(zero(T)), alpha) || throw(
        ArgumentError("ALPHA must contain positive values"),
    )
    if !isnothing(saturated_water)
        _soil_validate_interval(
            saturated_water,
            zero(T),
            one(T),
            "WS";
            lower_open=true,
        )
    end
    if !isnothing(residual_water)
        _soil_validate_interval(
            residual_water,
            zero(T),
            one(T),
            "WR",
        )
    end
    if !isnothing(saturated_water) && !isnothing(residual_water)
        all(residual_water .< saturated_water) || throw(
            ArgumentError("WR must be lower than WS in every soil layer"),
        )
    end
    isnothing(shape_n) || all(>(one(T)), shape_n) || throw(
        ArgumentError("N must be greater than one for RETFUNCTION=3"),
    )

    water_partial_molar_volume = T(18.05e-6)
    gravitational_acceleration = T(9.8067)
    megapascal_factor = T(1e-3)
    conductivity_factor = water_partial_molar_volume *
                          gravitational_acceleration *
                          megapascal_factor
    hydraulic_conductivity = hydraulic_conductivity_input .* conductivity_factor
    all(isfinite, hydraulic_conductivity) || throw(
        ArgumentError("converted KSAT values must be finite"),
    )

    return SoilRetentionConfig{T}(
        method,
        b_parameter,
        air_entry,
        hydraulic_conductivity,
        alpha,
        saturated_water,
        residual_water,
        shape_n,
    )
end

function _soil_initial_state(
    group::NamelistGroup,
    layers::SoilLayerConfig{T},
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    water_content = _soil_last_filled_array(
        group,
        :initwater,
        layers.layer_count,
        T,
        mode=mode,
    )
    all(>=(zero(T)), water_content) || throw(
        ArgumentError("INITWATER must contain non-negative water contents"),
    )
    temperature_c = _soil_last_filled_array(
        group,
        :soiltemp,
        layers.layer_count,
        T,
        mode=mode,
    )

    excessive = findall(water_content .> layers.pore_fraction)
    if !isempty(excessive)
        if mode === :strict
            throw(
                ArgumentError(
                    "INITWATER cannot exceed POREFRAC; offending layers: " *
                    join(excessive, ", "),
                ),
            )
        end
        @warn "INITWATER exceeded POREFRAC and was clamped to POREFRAC" layers = excessive
        for index in excessive
            water_content[index] = layers.pore_fraction[index]
        end
    end
    return InitialSoilState{T}(water_content, temperature_c)
end

function _soil_evaporation(group::NamelistGroup, ::Type{T}) where {T<:AbstractFloat}
    minimum_dry_layer_thickness = _soil_real(
        group,
        :drythickmin,
        T;
        default=T(0.001),
    )
    minimum_dry_layer_thickness > zero(T) || throw(
        ArgumentError("DRYTHICKMIN must be positive"),
    )

    input_tortuosity = _soil_real(group, :tortpar, T; default=T(0.66))
    input_tortuosity > zero(T) || throw(ArgumentError("TORTPAR must be positive"))
    tortuosity = input_tortuosity < one(T) ? inv(input_tortuosity) : input_tortuosity
    isfinite(tortuosity) || throw(
        ArgumentError("canonical TORTPAR must be finite after inversion"),
    )

    dry_layer_thermal_conductivity = _soil_real(
        group,
        :drytherm,
        T;
        default=-one(T),
    )
    iszero(dry_layer_thermal_conductivity) && throw(
        ArgumentError(
            "DRYTHERM cannot be zero; a negative value requests runtime recalculation",
        ),
    )
    return SoilEvaporationConfig{T}(
        minimum_dry_layer_thickness,
        tortuosity,
        dry_layer_thermal_conductivity,
    )
end

function _soil_infiltration(
    group::NamelistGroup,
    ::Type{T},
) where {T<:AbstractFloat}
    exponent = _soil_real(group, :expinf, T)
    exponent >= zero(T) || throw(
        ArgumentError(
            "EXPINF must be non-negative; negative values create negative infiltration fractions",
        ),
    )
    return SoilInfiltrationConfig{T}(exponent)
end

function _soil_canopy_interception(
    group::NamelistGroup,
    ::Type{T},
) where {T<:AbstractFloat}
    rutter_b = _soil_real(group, :rutterb, T)
    rutter_d = _soil_real(group, :rutterd, T)
    maximum_storage = _soil_real(group, :maxstorage, T)
    throughfall = _soil_real(group, :throughfall, T)

    rutter_d > zero(T) || throw(
        ArgumentError(
            "RUTTERD must be positive because the legacy equation takes log(RUTTERD)",
        ),
    )
    maximum_storage >= zero(T) || throw(
        ArgumentError("MAXSTORAGE must be non-negative"),
    )
    throughfall <= one(T) || throw(
        ArgumentError(
            "THROUGHFALL must not exceed one; finite negative values are " *
            "the historical LAI sentinel",
        ),
    )
    return CanopyInterceptionConfig{T}(
        rutter_b,
        rutter_d,
        maximum_storage,
        throughfall,
    )
end

function _soil_plant_storage(
    group::NamelistGroup,
    ::Type{T},
) where {T<:AbstractFloat}
    storage_coefficient = _soil_real(group, :storecoef, T)
    storage_exponent = _soil_real(group, :storeexp, T)
    stop_simulation_when_empty = _soil_flag(group, :stopsimonempty)
    return PlantStorageConfig{T}(
        storage_coefficient,
        storage_exponent,
        stop_simulation_when_empty,
    )
end

"""
    read_soil_config(document; mode=:legacy, T=Float32, species_count=nothing)

Read the typed soil configuration from a parsed MAESPA `NamelistDocument`.
The five groups `WATCONTROL`, `LAYPARS`, `INITPARS`, `SOILRET`, and
`SOILETPARS` are required in both modes. `WATINFILT` and `WATTFALL` are
optional as complete groups: an absent group becomes `nothing`, whereas every
field is required when its group is present. This avoids reproducing the
undefined local variables used by the historical partial-group readers.
`ROOTPARS` and `PLANTPARS` are likewise optional as complete groups for
compatibility with soil-only Julia configurations. When present, they are
materialised as `RootParametersConfig{T}` and `PlantHydraulicConfig{T}`.
`PLANTSTORAGE` is parsed whenever present and is required when `SIMSTORE=1`;
its three fields are all mandatory because the Fortran reader has no safe
partial-group defaults.
Pass the scene's `species_count` to resolve the historical `NOSPEC` versus
`NOROOTSPEC` mapping; when omitted, the parser uses `NOROOTSPEC` for roots and
one species for a standalone `PLANTPARS` group.

Layer arrays may use ordered indexed assignments, null slots, and Fortran
repetition. `LAYTHICK`, `POREFRAC`, `DRAINLIMIT`, retention parameters,
`INITWATER`, and `SOILTEMP` reproduce the historical `FILLWITHLAST` rule in
legacy mode. `FRACORGANIC` instead fills unspecified layers with zero as a
deliberate deterministic migration rule: the Fortran reader leaves that local
tail undefined and never calls `FILLWITHLAST`, so Julia does not preserve
uninitialised memory. In `mode=:legacy`, initial water above pore fraction is
clamped with a warning; `mode=:strict` rejects it.

`SOILTEMP` remains in degrees Celsius. `KSAT` is converted from historical
`mol m^-1 s^-1 MPa^-1` units to `m s^-1` as documented by
[`SoilRetentionConfig`](@ref). `WATINFILT` and `WATTFALL` values are retained
without unit conversion or sentinel resolution.

The legacy root and plant readers leave trailing dated arrays uninitialised.
Julia's legacy mode deterministically repeats the last concrete dated value,
which also makes the bundled historical input with seven values for eight root
dates readable. Strict mode requires exactly one concrete value per declared
date. When `NROOTLAYER > NLAYER`, the resolved soil count becomes
`NROOTLAYER`. Thickness filling still applies only through the original
`NLAYER`; every added layer must have an explicit finite positive `LAYTHICK`.
Other layer arrays retain their usual fill rules through the resolved count.
"""
function read_soil_config(
    document::NamelistDocument;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
    species_count=nothing,
)
    _check_input_mode(mode)
    requested_species_count = _soil_scene_species_count(species_count)
    watcontrol = _soil_group(document, :watcontrol)
    laypars = _soil_group(document, :laypars)
    initpars = _soil_group(document, :initpars)
    soilret = _soil_group(document, :soilret)
    soiletpars = _soil_group(document, :soiletpars)
    watinfilt = _soil_optional_group(document, :watinfilt)
    wattfall = _soil_optional_group(document, :wattfall)
    rootpars = _soil_optional_group(document, :rootpars)
    plantpars = _soil_optional_group(document, :plantpars)
    plantstorage = _soil_optional_group(document, :plantstorage)

    options = _soil_options(watcontrol, mode)
    if options.simulate_storage == 1 && isnothing(plantstorage)
        throw(
            ArgumentError(
                "SIMSTORE=1 requires a complete &PLANTSTORAGE group in $(document.source)",
            ),
        )
    end
    rooted_layer_count = isnothing(rootpars) ? 0 :
                        _soil_positive_count(rootpars, :nrootlayer; default=0)
    layers = _soil_layers(laypars, options, mode, T; rooted_layer_count)
    retention = _soil_retention(
        soilret,
        options.retention_function,
        layers.layer_count,
        options.simulate_water_table == 1,
        mode,
        T,
    )
    initial_state = _soil_initial_state(initpars, layers, mode, T)
    evaporation = _soil_evaporation(soiletpars, T)
    infiltration = isnothing(watinfilt) ?
                   nothing : _soil_infiltration(watinfilt, T)
    canopy_interception = isnothing(wattfall) ?
                          nothing : _soil_canopy_interception(wattfall, T)
    root_parameters = isnothing(rootpars) ? nothing : _soil_root_parameters(
        rootpars,
        layers,
        requested_species_count,
        mode,
        T,
    )
    hydraulic_species_count = if !isnothing(requested_species_count)
        requested_species_count
    elseif !isnothing(root_parameters)
        root_parameters.species_count
    else
        1
    end
    plant_hydraulics = isnothing(plantpars) ? nothing :
                       _soil_plant_hydraulics(
        plantpars,
        hydraulic_species_count,
        mode,
        T,
    )
    plant_storage = isnothing(plantstorage) ? nothing :
                    _soil_plant_storage(plantstorage, T)
    return SoilConfig{T}(
        document.source,
        options,
        layers,
        retention,
        initial_state,
        evaporation,
        infiltration,
        canopy_interception,
        root_parameters,
        plant_hydraulics,
        plant_storage,
    )
end
