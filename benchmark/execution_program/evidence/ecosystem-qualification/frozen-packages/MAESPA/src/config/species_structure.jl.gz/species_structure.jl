"""Historical crown-shape selection and its MAESPA volume multiplier."""
struct CrownShape{T<:AbstractFloat}
    name::Symbol
    legacy_name::String
    legacy_code::Int
    volume_factor::T
end

"""Canopy aerodynamic parameters read from the historical `&AERO` group."""
struct CanopyAerodynamics{T<:AbstractFloat}
    wind_extinction::T
end

"""
Leaf-angle classes and their dated area fractions.

`angles_rad` is ordered from horizontal to vertical. `fractions` has dimensions
`angle class × date`; `mean_angles_rad` contains one area-weighted mean per
date.
"""
struct LeafAngleDistribution{T<:AbstractFloat}
    source::Symbol
    angles_rad::Vector{T}
    dates::Vector{LegacyDate}
    fractions::Matrix{T}
    mean_angles_rad::Vector{T}
    ellipticity::T
end

"""
Parameters of the historical uniform/beta leaf-area-density distribution.

`beta_coefficients` has dimensions `8 × leaf age × date`. Its first four rows
are the vertical coefficients and its last four rows the horizontal
coefficients, matching MAESPA's internal `BPTI` ordering.
"""
struct LeafAreaDensity{T<:AbstractFloat}
    mode::Symbol
    legacy_mode::Int
    leaf_age_count::Int
    clumping_factor::T
    dates::Vector{LegacyDate}
    beta_coefficients::Array{T,3}
end

"""One height-diameter allometric equation in historical MAESPA units."""
struct AllometricEquation{T<:AbstractFloat}
    coefficient::T
    diameter_exponent::T
    intercept::T
end

"""Stem, branch, root, and fine-root structural allometry for one species."""
struct SpeciesAllometry{T<:AbstractFloat}
    trunk::AllometricEquation{T}
    branches::AllometricEquation{T}
    roots::AllometricEquation{T}
    fine_root_fraction::T
end

"""Typed structural configuration read from one historical species STR file."""
struct SpeciesStructureConfig{T<:AbstractFloat}
    source::String
    crown::CrownShape{T}
    aerodynamics::CanopyAerodynamics{T}
    leaf_angles::LeafAngleDistribution{T}
    leaf_density::LeafAreaDensity{T}
    allometry::SpeciesAllometry{T}
    leaf_age_count::Int
end

function _structure_mode(mode::Symbol)
    mode in (:legacy, :strict) || throw(
        ArgumentError("mode must be :legacy or :strict, got $(repr(mode))"),
    )
    return mode
end

function _structure_group(document::NamelistDocument, name::Symbol, mode::Symbol)
    try
        return namelist_group(document, name)
    catch exception
        if exception isa KeyError
            mode === :legacy && return nothing
            throw(
                ArgumentError(
                    "strict mode requires namelist &$(uppercase(String(name))) in " *
                    document.source,
                ),
            )
        end
        rethrow()
    end
end

_structure_name(name) = Symbol(lowercase(String(name)))

function _structure_has_scalar(group::NamelistGroup, name)
    normalised = _structure_name(name)
    return any(assignment -> assignment.name === normalised, group.assignments)
end

function _structure_has_array(group::NamelistGroup, name)
    normalised = _structure_name(name)
    prefix = String(normalised) * "("
    return any(
        assignment -> assignment.name === normalised ||
                      startswith(String(assignment.name), prefix),
        group.assignments,
    )
end

function _structure_missing(group, name)
    group_name = isnothing(group) ? "the missing namelist" : "&$(group.original_name)"
    return ArgumentError("missing required $(uppercase(String(name))) in $group_name")
end

function _structure_integer(
    group,
    name,
    mode::Symbol;
    default::Integer,
    required_in_strict::Bool=true,
)
    if isnothing(group) || !_structure_has_scalar(group, name)
        mode === :strict && required_in_strict && throw(_structure_missing(group, name))
        return Int(default)
    end
    value = _namelist_scalar_value(group, name)
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError("$(uppercase(String(name))) in &$(group.original_name) must be an integer"),
    )
    return Int(value)
end

function _structure_real(
    group,
    name,
    mode::Symbol,
    ::Type{T};
    default::Real,
    required_in_strict::Bool=true,
) where {T<:AbstractFloat}
    if isnothing(group) || !_structure_has_scalar(group, name)
        mode === :strict && required_in_strict && throw(_structure_missing(group, name))
        return convert(T, default)
    end
    value = _namelist_scalar_value(group, name; T=T)
    value isa Real && !(value isa Bool) || throw(
        ArgumentError("$(uppercase(String(name))) in &$(group.original_name) must be numeric"),
    )
    return convert(T, value)
end

function _structure_string(
    group,
    name,
    mode::Symbol;
    default::AbstractString,
    required_in_strict::Bool=true,
)
    if isnothing(group) || !_structure_has_scalar(group, name)
        mode === :strict && required_in_strict && throw(_structure_missing(group, name))
        return String(default)
    end
    value = _namelist_scalar_value(group, name)
    value isa AbstractString || throw(
        ArgumentError("$(uppercase(String(name))) in &$(group.original_name) must be a string"),
    )
    return String(value)
end

function _structure_real_array(
    group,
    name,
    count::Int,
    mode::Symbol,
    ::Type{T};
    defaults::AbstractVector,
    required_in_strict::Bool=false,
) where {T<:AbstractFloat}
    length(defaults) == count || throw(DimensionMismatch("array defaults have the wrong size"))
    if isnothing(group) || !_structure_has_array(group, name)
        mode === :strict && required_in_strict && throw(_structure_missing(group, name))
        return T.(defaults)
    end

    initial = mode === :strict ? fill(T(NaN), count) : T.(defaults)
    fill_value = mode === :strict ? T(NaN) : zero(T)
    values = _namelist_array_values(
        group,
        name;
        T=T,
        initial=initial,
        fill_value=fill_value,
    )
    mode === :strict && length(values) != count && throw(
        DimensionMismatch(
            "$(uppercase(String(name))) in &$(group.original_name) must contain exactly " *
            "$count values",
        ),
    )
    selected = values[1:count]
    all(value -> value isa Real && !(value isa Bool), selected) || throw(
        ArgumentError("$(uppercase(String(name))) in &$(group.original_name) must be numeric"),
    )
    converted = T.(selected)
    all(isfinite, converted) || throw(
        ArgumentError("$(uppercase(String(name))) in &$(group.original_name) must be finite"),
    )
    return converted
end

function _structure_dates(
    group,
    name,
    count::Int,
    mode::Symbol,
    ::Type{T};
    default::AbstractString="01/01/99",
) where {T<:AbstractFloat}
    raw = if isnothing(group) || !_structure_has_array(group, name)
        mode === :strict && throw(_structure_missing(group, name))
        fill(String(default), count)
    else
        sentinel = "\0"
        initial = mode === :strict ? fill(sentinel, count) : fill(String(default), count)
        values = _namelist_array_values(
            group,
            name;
            T=T,
            initial=initial,
            fill_value=mode === :strict ? sentinel : String(default),
        )
        mode === :strict && length(values) != count && throw(
            DimensionMismatch(
                "$(uppercase(String(name))) in &$(group.original_name) must contain exactly " *
                "$count dates",
            ),
        )
        selected = values[1:count]
        all(value -> value isa AbstractString && value != sentinel, selected) || throw(
            ArgumentError(
                "$(uppercase(String(name))) in &$(group.original_name) must contain dates",
            ),
        )
        String.(selected)
    end

    dates = [legacy_date(value; mode=mode) for value in raw]
    if mode === :strict
        for index in 2:length(dates)
            dates[index].days_since_1950 > dates[index - 1].days_since_1950 || throw(
                ArgumentError(
                    "$(uppercase(String(name))) in &$(group.original_name) must be strictly increasing",
                ),
            )
        end
    end
    return dates
end

function _read_crown_shape(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    group = _structure_group(document, :canopy, mode)
    raw = _structure_string(group, :cshape, mode; default="ELIP")
    specification = if raw == "CONE"
        (:cone, 1, T(1) / T(3))
    elseif raw == "ELIP"
        (:half_ellipsoid, 2, T(2) / T(3))
    elseif raw == "PARA"
        (:paraboloid, 3, T(1) / T(2))
    elseif raw == "ROUND"
        (:full_ellipsoid, 4, T(2) / T(3))
    elseif raw == "CYL"
        (:cylinder, 5, one(T))
    elseif raw == "BOX"
        (:box, 6, T(4) / T(pi))
    elseif mode === :legacy
        (:half_ellipsoid, 2, T(2) / T(3))
    else
        throw(
            ArgumentError(
                "CSHAPE must be one of CONE, ELIP, PARA, ROUND, CYL, or BOX; got " *
                repr(raw),
            ),
        )
    end
    canonical = specification[1] === :cone ? "CONE" :
                specification[1] === :half_ellipsoid ? "ELIP" :
                specification[1] === :paraboloid ? "PARA" :
                specification[1] === :full_ellipsoid ? "ROUND" :
                specification[1] === :cylinder ? "CYL" : "BOX"
    return CrownShape{T}(specification[1], canonical, specification[2], specification[3])
end

function _read_canopy_aerodynamics(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    group = _structure_group(document, :aero, mode)
    # READAERO reports this default but leaves its local variable undefined.
    # Julia makes the intended historical fallback deterministic.
    extinction = _structure_real(group, :extwind, mode, T; default=one(T))
    isfinite(extinction) || throw(ArgumentError("EXTWIND must be finite"))
    mode === :strict && extinction < zero(T) && throw(
        ArgumentError("EXTWIND must be non-negative"),
    )
    return CanopyAerodynamics{T}(extinction)
end

function _structure_average_leaf_angle(ellipticity::T) where {T<:AbstractFloat}
    ellipticity > zero(T) || throw(ArgumentError("ELP must be positive"))
    if ellipticity > one(T)
        return inv(T(0.5901) * ellipticity + T(0.3037))
    end
    return inv(T(0.3782) * ellipticity + T(0.6131))
end

function _structure_ellipticity_from_mean(
    angle_degrees::T,
) where {T<:AbstractFloat}
    angle_rad = angle_degrees * T(pi) / T(180)
    angle_rad > zero(T) || throw(ArgumentError("AVGANG must be positive"))
    if angle_rad < one(T)
        return (inv(angle_rad) - T(0.3037)) / T(0.5901)
    end
    return (inv(angle_rad) - T(0.6131)) / T(0.3782)
end

function _structure_leaf_angle_density(
    ellipticity::T,
    normalisation::T,
    angle::T,
) where {T<:AbstractFloat}
    sine = sin(angle)
    cosine = cos(angle)
    denominator = normalisation * (cosine^2 + (ellipticity * sine)^2)^2
    return T(2) * ellipticity^2 * sine / denominator
end

function _structure_integrated_leaf_angle_density(
    lower::T,
    upper::T,
    ellipticity::T,
    normalisation::T,
) where {T<:AbstractFloat}
    step = (upper - lower) / T(50)
    up = lower + step * T(0.42265)
    down = lower + step * T(1.57735)
    total = _structure_leaf_angle_density(ellipticity, normalisation, up) +
            _structure_leaf_angle_density(ellipticity, normalisation, down)
    for _ in 1:24
        up += T(2) * step
        down += T(2) * step
        total += _structure_leaf_angle_density(ellipticity, normalisation, up) +
                 _structure_leaf_angle_density(ellipticity, normalisation, down)
    end
    return step * total
end

function _structure_elliptical_fractions(
    ellipticity::T,
    class_count::Int,
) where {T<:AbstractFloat}
    ellipticity > zero(T) || throw(ArgumentError("ELP must be positive"))
    class_count > 0 || throw(ArgumentError("NALPHA must be positive"))
    class_width = T(pi) / (T(2) * T(class_count))
    if ellipticity == one(T)
        return [
            cos(T(index - 1) * class_width) - cos(T(index) * class_width) for
            index in 1:class_count
        ]
    end

    eccentricity, normalisation = if ellipticity < one(T)
        eccentricity = sqrt(one(T) - ellipticity^2)
        normalisation = one(T) +
                        asin(eccentricity) / (eccentricity * ellipticity)
        (eccentricity, normalisation)
    else
        eccentricity = sqrt(one(T) - inv(ellipticity)^2)
        normalisation = one(T) +
                        log((one(T) + eccentricity) / (one(T) - eccentricity)) /
                        (T(2) * ellipticity^2 * eccentricity)
        (eccentricity, normalisation)
    end
    isfinite(eccentricity) && isfinite(normalisation) || throw(
        ArgumentError("ELP does not define a finite leaf-angle distribution"),
    )

    fractions = Vector{T}(undef, class_count)
    for index in eachindex(fractions)
        lower = T(index - 1) * class_width
        upper = T(index) * class_width
        fractions[index] = _structure_integrated_leaf_angle_density(
            lower,
            upper,
            ellipticity,
            normalisation,
        )
    end
    total = sum(fractions)
    total > zero(T) && isfinite(total) || throw(
        ArgumentError("ELP produces an invalid leaf-angle distribution"),
    )
    fractions ./= total
    return fractions
end

function _read_leaf_angle_distribution(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    group = _structure_group(document, :lia, mode)
    class_count = _structure_integer(group, :nalpha, mode; default=1)
    date_count = _structure_integer(group, :nodateslia, mode; default=1)
    1 <= class_count <= 20 || throw(ArgumentError("NALPHA must be between 1 and 20"))
    date_count > 0 || throw(ArgumentError("NODATESLIA must be positive"))
    dates = _structure_dates(group, :dateslia, date_count, mode, T)
    average_degrees = _structure_real(
        group,
        :avgang,
        mode,
        T;
        default=-one(T),
        required_in_strict=false,
    )
    ellipticity = _structure_real(
        group,
        :elp,
        mode,
        T;
        default=one(T),
        required_in_strict=false,
    )

    if mode === :strict && average_degrees > zero(T)
        average_degrees <= T(90) || throw(ArgumentError("AVGANG must not exceed 90 degrees"))
    end

    angles = Vector{T}(undef, class_count)
    fractions = Matrix{T}(undef, class_count, date_count)
    source = :elliptical
    effective_ellipticity = ellipticity

    if class_count == 1
        if average_degrees > zero(T)
            angles[1] = average_degrees * T(pi) / T(180)
            source = :mean_angle
        elseif ellipticity > zero(T)
            angles[1] = _structure_average_leaf_angle(ellipticity)
        else
            throw(ArgumentError("NALPHA=1 requires AVGANG > 0 or ELP > 0"))
        end
        fill!(fractions, one(T))
    else
        if average_degrees > zero(T)
            effective_ellipticity = _structure_ellipticity_from_mean(average_degrees)
            effective_ellipticity > zero(T) || throw(
                ArgumentError("AVGANG does not define a positive ELP"),
            )
            source = :mean_angle
        elseif ellipticity > zero(T)
            source = :elliptical
        elseif average_degrees < zero(T) && ellipticity < zero(T)
            source = :explicit
        else
            throw(
                ArgumentError(
                    "NALPHA>1 requires AVGANG > 0, ELP > 0, or AVGANG < 0 and ELP < 0",
                ),
            )
        end

        class_width = T(pi) / (T(2) * T(class_count))
        for index in eachindex(angles)
            angles[index] = (T(index) - T(0.5)) * class_width
        end
        if source === :explicit
            isnothing(group) || _structure_has_array(group, :falpha) || throw(
                ArgumentError("explicit LIA input requires FALPHA"),
            )
            expected = class_count * date_count
            defaults = zeros(T, expected)
            defaults[1] = one(T)
            raw = _structure_real_array(
                group,
                :falpha,
                expected,
                mode,
                T;
                defaults=defaults,
                required_in_strict=true,
            )
            fractions .= reshape(raw, class_count, date_count)
        else
            generated = _structure_elliptical_fractions(
                effective_ellipticity,
                class_count,
            )
            # The Fortran branch initializes only date one. Repeating the same
            # generated distribution is the deterministic interpretation for
            # an otherwise uninitialized multi-date input.
            for date_index in 1:date_count
                fractions[:, date_index] .= generated
            end
        end
    end

    all(isfinite, fractions) || throw(ArgumentError("FALPHA must be finite"))
    if mode === :strict
        all(value -> value >= zero(T), fractions) || throw(
            ArgumentError("FALPHA must be non-negative"),
        )
        tolerance = max(T(1.0e-4), T(20) * eps(T))
        for date_index in 1:date_count
            isapprox(sum(view(fractions, :, date_index)), one(T); atol=tolerance, rtol=tolerance) ||
                throw(ArgumentError("FALPHA must sum to one on every LIA date"))
        end
    end
    mean_angles = vec(sum(fractions .* reshape(angles, :, 1), dims=1))
    return LeafAngleDistribution{T}(
        source,
        angles,
        dates,
        fractions,
        mean_angles,
        effective_ellipticity,
    )
end

function _read_leaf_area_density(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    group = _structure_group(document, :ladd, mode)
    age_count = _structure_integer(group, :noagec, mode; default=1)
    legacy_mode = _structure_integer(group, :jleaf, mode; default=0)
    date_count = _structure_integer(group, :nodateslad, mode; default=1)
    clumping = _structure_real(group, :random, mode, T; default=one(T))
    1 <= age_count <= 3 || throw(ArgumentError("NOAGEC must be between 1 and 3"))
    legacy_mode in (0, 1, 2) || throw(ArgumentError("JLEAF must be 0, 1, or 2"))
    date_count > 0 || throw(ArgumentError("NODATESLAD must be positive"))
    isfinite(clumping) || throw(ArgumentError("RANDOM must be finite"))
    mode === :strict && clumping <= zero(T) && throw(
        ArgumentError("RANDOM must be positive"),
    )
    dates = _structure_dates(group, :dateslad, date_count, mode, T)

    beta_count = 6 * age_count * date_count
    extension_count = 2 * age_count * date_count
    needs_beta = legacy_mode != 0
    if needs_beta && (isnothing(group) || !_structure_has_array(group, :bpt))
        throw(ArgumentError("JLEAF != 0 requires BPT coefficients"))
    end
    if mode === :strict && needs_beta &&
       (isnothing(group) || !_structure_has_array(group, :bptext))
        throw(ArgumentError("strict non-uniform LADD input requires BPTEXT coefficients"))
    end
    beta = _structure_real_array(
        group,
        :bpt,
        beta_count,
        mode,
        T;
        defaults=zeros(T, beta_count),
        required_in_strict=needs_beta,
    )
    extension = _structure_real_array(
        group,
        :bptext,
        extension_count,
        mode,
        T;
        defaults=ones(T, extension_count),
        required_in_strict=needs_beta,
    )

    coefficients = Array{T}(undef, 8, age_count, date_count)
    for date_index in 1:date_count, age_index in 1:age_count
        beta_offset = (date_index - 1) * 6 * age_count + (age_index - 1) * 6
        extension_offset = (date_index - 1) * 2 * age_count + (age_index - 1) * 2
        coefficients[1:3, age_index, date_index] .=
            beta[(beta_offset + 1):(beta_offset + 3)]
        coefficients[4, age_index, date_index] = extension[extension_offset + 1]
        coefficients[5:7, age_index, date_index] .=
            beta[(beta_offset + 4):(beta_offset + 6)]
        coefficients[8, age_index, date_index] = extension[extension_offset + 2]
    end

    if needs_beta
        if mode === :legacy
            coefficients[1, 1, 1] != zero(T) || throw(
                ArgumentError("missing beta coefficients for leaf age 1"),
            )
            if age_count > 1
                coefficients[1, 2, 1] != zero(T) || throw(
                    ArgumentError("missing beta coefficients for leaf age 2"),
                )
            end
        else
            all(view(coefficients, 1, :, :) .> zero(T)) || throw(
                ArgumentError("the first BPT coefficient must be positive for every age and date"),
            )
        end
    end
    distribution_mode = legacy_mode == 0 ? :uniform :
                        legacy_mode == 1 ? :vertical : :vertical_horizontal
    return LeafAreaDensity{T}(
        distribution_mode,
        legacy_mode,
        age_count,
        clumping,
        dates,
        coefficients,
    )
end

function _read_allometric_equation(
    document::NamelistDocument,
    group_name::Symbol,
    coefficient_name::Symbol,
    exponent_name::Symbol,
    intercept_name::Symbol,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    group = _structure_group(document, group_name, mode)
    coefficient = _structure_real(group, coefficient_name, mode, T; default=zero(T))
    exponent = _structure_real(group, exponent_name, mode, T; default=T(2))
    intercept = _structure_real(group, intercept_name, mode, T; default=zero(T))
    all(isfinite, (coefficient, exponent, intercept)) || throw(
        ArgumentError("allometric parameters in &$(uppercase(String(group_name))) must be finite"),
    )
    return AllometricEquation{T}(coefficient, exponent, intercept)
end

function _read_species_allometry(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    trunk = _read_allometric_equation(
        document,
        :allom,
        :coefft,
        :expont,
        :winterc,
        mode,
        T,
    )
    branches = _read_allometric_equation(
        document,
        :allomb,
        :bcoefft,
        :bexpont,
        :binterc,
        mode,
        T,
    )
    roots = _read_allometric_equation(
        document,
        :allomr,
        :rcoefft,
        :rexpont,
        :rinterc,
        mode,
        T,
    )
    root_group = _structure_group(document, :allomr, mode)
    fine_root_fraction = _structure_real(
        root_group,
        :frfrac,
        mode,
        T;
        default=one(T),
    )
    isfinite(fine_root_fraction) || throw(ArgumentError("FRFRAC must be finite"))
    mode === :strict && !(zero(T) <= fine_root_fraction <= one(T)) && throw(
        ArgumentError("FRFRAC must be between zero and one"),
    )
    return SpeciesAllometry{T}(trunk, branches, roots, fine_root_fraction)
end

"""
    read_species_structure(document; mode=:legacy, T=Float32)

Read the CANOPY, AERO, LIA, LADD, ALLOM, ALLOMB, and ALLOMR groups of one
historical species structure file. In `:legacy` mode missing groups and fields
receive the initialized defaults of the corresponding Fortran readers. In
`:strict` mode groups, scalar fields, declared date/value counts, date order,
and the active model options are validated.
"""
function read_species_structure(
    document::NamelistDocument;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
)
    _structure_mode(mode)
    crown = _read_crown_shape(document, mode, T)
    aerodynamics = _read_canopy_aerodynamics(document, mode, T)
    leaf_angles = _read_leaf_angle_distribution(document, mode, T)
    leaf_density = _read_leaf_area_density(document, mode, T)
    allometry = _read_species_allometry(document, mode, T)
    return SpeciesStructureConfig{T}(
        document.source,
        crown,
        aerodynamics,
        leaf_angles,
        leaf_density,
        allometry,
        leaf_density.leaf_age_count,
    )
end

function read_species_structure(
    path::AbstractString;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
)
    return read_species_structure(read_namelist(path; mode=mode); mode=mode, T=T)
end

"""Calculate crown volume from the two crown radii and crown height."""
function crown_volume(
    shape::CrownShape{T},
    radius_x::Real,
    radius_y::Real,
    height::Real,
) where {T<:AbstractFloat}
    return T(pi) * convert(T, radius_x) * convert(T, radius_y) *
           convert(T, height) * shape.volume_factor
end

crown_volume(config::SpeciesStructureConfig, dimensions...) =
    crown_volume(config.crown, dimensions...)

"""Evaluate `coefficient * height * diameter^exponent + intercept`."""
function allometric_biomass(
    equation::AllometricEquation{T},
    height::Real,
    diameter::Real,
) where {T<:AbstractFloat}
    height_t = convert(T, height)
    diameter_t = convert(T, diameter)
    return equation.coefficient * height_t * diameter_t^equation.diameter_exponent +
           equation.intercept
end

_structure_ordinal(date::LegacyDate) = date.days_since_1950
function _structure_ordinal(date::Integer)
    date isa Bool && throw(ArgumentError("a date ordinal must be an integer"))
    return Int(date)
end

"""
Linearly interpolate dated LIA fractions and clamp outside the supplied date
range, matching MAESPA's daily `DISTINTERP2` behavior.
"""
function interpolate_leaf_angle_distribution(
    distribution::LeafAngleDistribution{T},
    date::Union{LegacyDate,Integer},
) where {T<:AbstractFloat}
    target = _structure_ordinal(date)
    days = getfield.(distribution.dates, :days_since_1950)
    target <= first(days) && return copy(view(distribution.fractions, :, 1))
    target >= last(days) && return copy(view(distribution.fractions, :, length(days)))
    lower = searchsortedlast(days, target)
    upper = lower + 1
    span = days[upper] - days[lower]
    span > 0 || throw(ArgumentError("LIA dates must increase for interpolation"))
    weight = T(target - days[lower]) / T(span)
    return (one(T) - weight) .* view(distribution.fractions, :, lower) .+
           weight .* view(distribution.fractions, :, upper)
end

interpolate_leaf_angle_distribution(config::SpeciesStructureConfig, date) =
    interpolate_leaf_angle_distribution(config.leaf_angles, date)

"""
Return the active `8 × leaf age` LADD coefficient table. Historical MAESPA
uses a dated step function for beta-distribution parameters.
"""
function leaf_density_coefficients(
    density::LeafAreaDensity,
    date::Union{LegacyDate,Integer},
)
    target = _structure_ordinal(date)
    days = getfield.(density.dates, :days_since_1950)
    date_index = clamp(searchsortedlast(days, target), 1, length(days))
    return copy(view(density.beta_coefficients, :, :, date_index))
end

leaf_density_coefficients(config::SpeciesStructureConfig, date) =
    leaf_density_coefficients(config.leaf_density, date)
