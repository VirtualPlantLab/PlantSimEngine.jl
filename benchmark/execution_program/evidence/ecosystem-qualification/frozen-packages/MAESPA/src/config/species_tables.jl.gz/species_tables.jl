"""
    SpeciesParameterTable(dates, values)

A validated dated table for one species parameter. `values` has dimensions
`date × canopy layer × foliage age class`. The table owns copies of its inputs,
requires at least one entry on every axis, strictly increasing MAESPA dates,
and finite values. Its floating-point element type is preserved.
"""
struct SpeciesParameterTable{T<:AbstractFloat}
    dates::Vector{LegacyDate}
    values::Array{T,3}

    function SpeciesParameterTable(
        dates::AbstractVector{LegacyDate},
        values::AbstractArray{T,3},
    ) where {T<:AbstractFloat}
        isempty(dates) && throw(
            ArgumentError("species parameter tables require at least one date"),
        )
        size(values, 2) > 0 || throw(
            ArgumentError("species parameter tables require at least one canopy layer"),
        )
        size(values, 3) > 0 || throw(
            ArgumentError("species parameter tables require at least one foliage age class"),
        )
        length(dates) == size(values, 1) || throw(
            DimensionMismatch(
                "the number of dates ($(length(dates))) must equal the first value dimension ($(size(values, 1)))",
            ),
        )

        for index in 2:length(dates)
            previous_day = dates[index - 1].days_since_1950
            current_day = dates[index].days_since_1950
            current_day > previous_day || throw(
                ArgumentError(
                    "species parameter dates must be strictly increasing; entries $(index - 1) and $index are out of order or duplicated",
                ),
            )
        end

        for index in CartesianIndices(values)
            isfinite(values[index]) || throw(
                ArgumentError("species parameter value at $index must be finite"),
            )
        end

        return new{T}(collect(dates), Array(values))
    end
end

_species_parameter_day(date::LegacyDate) = date.days_since_1950

function _species_parameter_day(days_since_1950::Integer)
    days_since_1950 isa Bool && throw(
        ArgumentError("days_since_1950 must be an integer date, not Bool"),
    )
    return Int(days_since_1950)
end

function _species_parameter_interval(
    table::SpeciesParameterTable{T},
    requested_day::Integer,
) where {T}
    first_day = first(table.dates).days_since_1950
    requested_day <= first_day && return (1, 1, zero(T))

    final_index = length(table.dates)
    final_day = last(table.dates).days_since_1950
    requested_day >= final_day && return (final_index, final_index, zero(T))

    upper_index = 2
    while requested_day > table.dates[upper_index].days_since_1950
        upper_index += 1
    end
    table.dates[upper_index].days_since_1950 == requested_day &&
        return (upper_index, upper_index, zero(T))

    lower_index = upper_index - 1
    lower_day = table.dates[lower_index].days_since_1950
    upper_day = table.dates[upper_index].days_since_1950
    fraction = convert(T, requested_day - lower_day) / convert(T, upper_day - lower_day)
    return (lower_index, upper_index, fraction)
end

"""
    interpolate_species_parameters!(destination, table, date)

Interpolate one `layer × age class` parameter matrix at `date`, writing into
`destination`. Requests outside the dated range are clamped to the first or
last entry. All interpolation arithmetic is performed in the table's type `T`.
"""
function interpolate_species_parameters!(
    destination::AbstractMatrix{T},
    table::SpeciesParameterTable{T},
    date::Union{LegacyDate,Integer},
) where {T}
    expected_size = (size(table.values, 2), size(table.values, 3))
    size(destination) == expected_size || throw(
        DimensionMismatch(
            "destination size $(size(destination)) must equal layer × age size $expected_size",
        ),
    )

    requested_day = _species_parameter_day(date)
    lower_index, upper_index, fraction =
        _species_parameter_interval(table, requested_day)

    if lower_index == upper_index
        copyto!(destination, @view(table.values[lower_index, :, :]))
        return destination
    end

    for index in CartesianIndices(destination)
        @inbounds begin
            layer_index, age_index = Tuple(index)
            lower_value = table.values[lower_index, layer_index, age_index]
            upper_value = table.values[upper_index, layer_index, age_index]
            destination[index] = lower_value + fraction * (upper_value - lower_value)
        end
    end
    return destination
end

"""
    interpolate_species_parameters(table, date)

Return the interpolated `layer × age class` parameter matrix, preserving the
numeric element type of `table`.
"""
function interpolate_species_parameters(
    table::SpeciesParameterTable{T},
    date::Union{LegacyDate,Integer},
) where {T}
    destination = Matrix{T}(undef, size(table.values, 2), size(table.values, 3))
    return interpolate_species_parameters!(destination, table, date)
end

function _positive_count(value::Integer, name::AbstractString)
    value isa Bool && throw(ArgumentError("$name must be an integer, not Bool"))
    value > 0 || throw(ArgumentError("$name must be positive"))
    return Int(value)
end

"""
    resample_uniform_layers(source, target_layer_count)

Average a piecewise-constant vertical profile from uniform source layers onto
`target_layer_count` uniform layers. Each target value is the overlap-weighted
mean over its vertical interval, matching the historical Fortran `RINTEG`
calculation. The operation is pure and keeps the source element type `T`.
"""
function resample_uniform_layers(
    source::AbstractVector{T},
    target_layer_count::Integer,
) where {T<:AbstractFloat}
    isempty(source) && throw(ArgumentError("the source profile must not be empty"))
    target_count = _positive_count(target_layer_count, "target_layer_count")
    for (position, value) in enumerate(source)
        isfinite(value) || throw(
            ArgumentError("source profile value at position $position must be finite"),
        )
    end

    source_count = length(source)
    source_count_t = convert(T, source_count)
    result = Vector{T}(undef, target_count)

    for target_index in 1:target_count
        # Work on the exact common integer grid of both uniform partitions.
        # Dividing only once avoids introducing slightly different floating
        # boundaries on either side of an otherwise shared layer edge.
        target_lower = (target_index - 1) * source_count
        target_upper = target_index * source_count
        weighted_sum = zero(T)

        for (source_index, value) in enumerate(source)
            source_lower = (source_index - 1) * target_count
            source_upper = source_index * target_count
            overlap = min(target_upper, source_upper) - max(target_lower, source_lower)
            overlap > 0 && (weighted_sum += value * convert(T, overlap))
        end
        result[target_index] = weighted_sum / source_count_t
    end

    return result
end

"""
    unpack_legacy_species_values(
        flat_values,
        date_count,
        source_layer_count,
        age_class_count;
        target_layer_count=source_layer_count,
    )

Unpack a historical flat MAESPA parameter array into dimensions
`date × target layer × age class`. The flat order is date-major, then foliage
age class, then canopy layer, exactly as used by `READPHYARRAY`. Each vertical
profile is resampled with [`resample_uniform_layers`](@ref).
"""
function unpack_legacy_species_values(
    flat_values::AbstractVector{T},
    date_count::Integer,
    source_layer_count::Integer,
    age_class_count::Integer;
    target_layer_count::Integer=source_layer_count,
) where {T<:AbstractFloat}
    number_of_dates = _positive_count(date_count, "date_count")
    source_layers = _positive_count(source_layer_count, "source_layer_count")
    age_classes = _positive_count(age_class_count, "age_class_count")
    target_layers = _positive_count(target_layer_count, "target_layer_count")
    expected_length = number_of_dates * source_layers * age_classes
    length(flat_values) == expected_length || throw(
        DimensionMismatch(
            "flat_values has $(length(flat_values)) entries; $expected_length are required for $number_of_dates dates × $age_classes ages × $source_layers layers",
        ),
    )

    source_values = collect(flat_values)
    result = Array{T}(undef, number_of_dates, target_layers, age_classes)
    for date_index in 1:number_of_dates
        for age_index in 1:age_classes
            offset = ((date_index - 1) * age_classes + age_index - 1) * source_layers
            profile = @view source_values[(offset + 1):(offset + source_layers)]
            result[date_index, :, age_index] =
                resample_uniform_layers(profile, target_layers)
        end
    end
    return result
end
