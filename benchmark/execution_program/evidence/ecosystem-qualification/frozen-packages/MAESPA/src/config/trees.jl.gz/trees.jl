"""
Geometry and historical plot controls read from `trees.dat`.

`wind_measurement_height`, `roughness_length`, and
`zero_plane_displacement_height` are the metre-valued `ZHT`, `Z0HT`, and
`ZPD` fields from the required historical `&AERODYN` group.
"""
struct LegacyPlotConfig{T<:AbstractFloat}
    origin::NTuple{2,T}
    upper_corner::NTuple{2,T}
    slope_rad::NTuple{2,T}
    bearing_rad::T
    shade_height::T
    plot_shape::Int
    tree_count::Int
    water_balance_area::T
    stocking::T
    wind_measurement_height::T
    roughness_length::T
    zero_plane_displacement_height::T
end

"""
Compatibility constructor for Julia code written before `&AERODYN` was
represented in `LegacyPlotConfig`.

The three new fields are set to typed `NaN` markers because the old signature
contains no aerodynamic information. Parsed `trees.dat` inputs never use this
fallback: their `&AERODYN` values are required and retained exactly.
"""
function LegacyPlotConfig{T}(
    origin::NTuple{2,T},
    upper_corner::NTuple{2,T},
    slope_rad::NTuple{2,T},
    bearing_rad::T,
    shade_height::T,
    plot_shape::Int,
    tree_count::Int,
    water_balance_area::T,
    stocking::T,
) where {T<:AbstractFloat}
    unavailable = T(NaN)
    return LegacyPlotConfig{T}(
        origin,
        upper_corner,
        slope_rad,
        bearing_rad,
        shade_height,
        plot_shape,
        tree_count,
        water_balance_area,
        stocking,
        unavailable,
        unavailable,
        unavailable,
    )
end

function LegacyPlotConfig(
    origin::NTuple{2,T},
    upper_corner::NTuple{2,T},
    slope_rad::NTuple{2,T},
    bearing_rad::T,
    shade_height::T,
    plot_shape::Int,
    tree_count::Int,
    water_balance_area::T,
    stocking::T,
) where {T<:AbstractFloat}
    return LegacyPlotConfig{T}(
        origin,
        upper_corner,
        slope_rad,
        bearing_rad,
        shade_height,
        plot_shape,
        tree_count,
        water_balance_area,
        stocking,
    )
end

"""
One MAESPA tree identity and its position in the translated scene frame.

`id` remains stable when a scene is subsetted. `trajectory_index` identifies
the corresponding column in the shared structural tables and may therefore
differ from `id` in a compact extracted scene.
"""
struct LegacyTreeRecord{T<:AbstractFloat}
    id::Int
    trajectory_index::Int
    species_id::Int
    position::NTuple{3,T}
end

LegacyTreeRecord(id::Int, species_id::Int, position::NTuple{3,T}) where {T<:AbstractFloat} =
    LegacyTreeRecord{T}(id, id, species_id, position)

"""Dated structural trajectories shared by all tree instances in a scene."""
struct LegacyTreeTrajectories{T<:AbstractFloat}
    radius_x::TreeDimensionTable{T}
    radius_y::TreeDimensionTable{T}
    crown_depth::TreeDimensionTable{T}
    crown_base_height::TreeDimensionTable{T}
    leaf_area::TreeDimensionTable{T}
    stem_diameter::Union{Nothing,TreeDimensionTable{T}}
end

"""Typed tree scene reconstructed from a historical MAESPA `trees.dat`."""
struct LegacyTreeScene{T<:AbstractFloat}
    plot::LegacyPlotConfig{T}
    trees::Vector{LegacyTreeRecord{T}}
    trajectories::LegacyTreeTrajectories{T}
end

const _TREE_TRAJECTORY_GROUPS = (
    radius_x=(:indivradx, :allradx),
    radius_y=(:indivrady, :allrady),
    crown_depth=(:indivhtcrown, :allhtcrown),
    crown_base_height=(:indivhttrunk, :allhttrunk),
    leaf_area=(:indivlarea, :alllarea),
    stem_diameter=(:indivdiam, :alldiam),
)
const _LEGACY_MAX_TREES = 364

function _optional_namelist_group(document::NamelistDocument, name)
    normalised = _normalise_name(String(name))
    index = findfirst(group -> group.name === normalised, document.groups)
    return isnothing(index) ? nothing : document.groups[index]
end

function _tree_trajectory_input_present(document::NamelistDocument)
    !isnothing(_optional_namelist_group(document, :phenology)) && return true
    return any(
        group_names -> any(
            name -> !isnothing(_optional_namelist_group(document, name)),
            group_names,
        ),
        values(_TREE_TRAJECTORY_GROUPS),
    )
end

function _required_aerodyn_real(
    group::NamelistGroup,
    name::Symbol,
    document::NamelistDocument,
    ::Type{T},
) where {T<:AbstractFloat}
    _has_assignment(group, name) || throw(
        ArgumentError(
            "AERODYN.$(uppercase(String(name))) is required in $(document.source); " *
            "READZPD has no historical default for this field",
        ),
    )
    try
        return _real_value(group, name, T)
    catch exception
        exception isa Union{ArgumentError,InexactError,OverflowError} || rethrow()
        throw(
            ArgumentError(
                "AERODYN.$(uppercase(String(name))) must be numeric, finite, and " *
                "representable as $(T) in $(document.source): " *
                sprint(showerror, exception),
            ),
        )
    end
end

function _legacy_aerodynamic_heights(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    # READZPD treats &AERODYN as mandatory in MAESPA. Legacy mode therefore
    # does not use the optional-group convention applied to some MAESTRA
    # inputs: silently fabricating ZHT or ZPD would replace undefined Fortran
    # state with an invented physical parameter.
    aerodyn = _config_group(document, :aerodyn, mode)
    wind_measurement_height =
        _required_aerodyn_real(aerodyn, :zht, document, T)
    roughness_length = _required_aerodyn_real(aerodyn, :z0ht, document, T)
    zero_plane_displacement_height =
        _required_aerodyn_real(aerodyn, :zpd, document, T)

    all(
        isfinite,
        (
            wind_measurement_height,
            roughness_length,
            zero_plane_displacement_height,
        ),
    ) || throw(
        ArgumentError("AERODYN fields must be finite in $(document.source)"),
    )
    !iszero(roughness_length) || throw(
        ArgumentError(
            "AERODYN.Z0HT must be non-zero in $(document.source), as required by READZPD",
        ),
    )
    return (
        wind_measurement_height,
        roughness_length,
        zero_plane_displacement_height,
    )
end

function _legacy_plot_config(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    plot = _config_group(document, :plot, mode)
    (
        wind_measurement_height,
        roughness_length,
        zero_plane_displacement_height,
    ) = _legacy_aerodynamic_heights(
        document,
        mode,
        T,
    )
    x0 = _real_value(plot, :x0, T; default=zero(T))
    y0 = _real_value(plot, :y0, T; default=zero(T))
    xmax = _real_value(plot, :xmax, T)
    ymax = _real_value(plot, :ymax, T)
    xslope_degrees = _real_value(plot, :xslope, T)
    yslope_degrees = _real_value(plot, :yslope, T)
    bearing_degrees = _real_value(plot, :bearing, T)
    shade_height = _real_value(plot, :shadeht, T; default=zero(T))
    plot_shape = _integer_value(plot, :plotshape; default=0)
    tree_count = _integer_value(plot, :notrees)
    water_balance_area = _real_value(plot, :watbalarea, T; default=-one(T))

    numeric_fields = (
        x0,
        y0,
        xmax,
        ymax,
        xslope_degrees,
        yslope_degrees,
        bearing_degrees,
        shade_height,
        water_balance_area,
    )
    all(isfinite, numeric_fields) || throw(
        ArgumentError("PLOT fields must be finite in $(document.source)"),
    )
    tree_count > 0 || throw(ArgumentError("PLOT.NOTREES must be positive"))
    if tree_count > _LEGACY_MAX_TREES
        mode === :strict && throw(
            ArgumentError(
                "PLOT.NOTREES cannot exceed historical MAXT=$(_LEGACY_MAX_TREES)",
            ),
        )
        tree_count = _LEGACY_MAX_TREES
    end
    xmax > x0 || throw(ArgumentError("PLOT.XMAX must be greater than X0"))
    ymax > y0 || throw(ArgumentError("PLOT.YMAX must be greater than Y0"))
    shade_height >= zero(T) || throw(ArgumentError("PLOT.SHADEHT must be non-negative"))
    plot_shape == 0 || throw(
        ArgumentError("only rectangular MAESPA plots (PLOTSHAPE=0) are supported"),
    )

    width = xmax - x0
    height = ymax - y0
    water_balance_area < zero(T) && (water_balance_area = width * height)
    water_balance_area > zero(T) || throw(
        ArgumentError("PLOT.WATBALAREA must be positive or omitted"),
    )

    degrees_to_radians = convert(T, π) / T(180)
    slope_rad = (
        xslope_degrees * degrees_to_radians,
        yslope_degrees * degrees_to_radians,
    )
    stocking = T(tree_count) / (xmax * ymax)
    return LegacyPlotConfig(
        (x0, y0),
        (xmax, ymax),
        slope_rad,
        bearing_degrees * degrees_to_radians,
        shade_height,
        plot_shape,
        tree_count,
        water_balance_area,
        stocking,
        wind_measurement_height,
        roughness_length,
        zero_plane_displacement_height,
    )
end

function _legacy_tree_positions(
    document::NamelistDocument,
    plot::LegacyPlotConfig{T},
    mode::Symbol,
) where {T<:AbstractFloat}
    tree_count = plot.tree_count
    xy = _optional_namelist_group(document, :xy)
    x = Vector{T}(undef, tree_count)
    y = similar(x)

    if isnothing(xy)
        # READXYZ historically constructs the fallback grid from the raw
        # XMAX/YMAX values before translating the plot origin.
        raw_xmax, raw_ymax = plot.upper_corner
        spacing = sqrt(raw_xmax * raw_ymax / T(tree_count))
        number_on_x = raw_xmax / spacing + one(T)
        for tree_index in 1:tree_count
            offset = T(tree_index - 1)
            x[tree_index] = offset / number_on_x * spacing
            y[tree_index] = mod(offset, number_on_x) * spacing
        end
    else
        coordinates = _real_values(xy, :xycoords, T)
        required = 2 * tree_count
        length(coordinates) >= required || throw(
            DimensionMismatch(
                "XY.XYCOORDS provides $(length(coordinates)) values for $tree_count trees; $required are required",
            ),
        )
        mode === :strict && length(coordinates) != required && throw(
            DimensionMismatch("strict mode requires exactly $required XY coordinates"),
        )
        for tree_index in 1:tree_count
            x[tree_index] = coordinates[2 * tree_index - 1] - plot.origin[1]
            y[tree_index] = coordinates[2 * tree_index] - plot.origin[2]
        end
    end

    z = similar(x)
    for tree_index in eachindex(x)
        isfinite(x[tree_index]) && isfinite(y[tree_index]) || throw(
            ArgumentError("tree coordinates must be finite"),
        )
        z[tree_index] =
            x[tree_index] * sin(plot.slope_rad[1]) / T(2) +
            y[tree_index] * sin(plot.slope_rad[2]) / T(2)
    end
    return x, y, z
end

function _legacy_species_ids(
    document::NamelistDocument,
    tree_count::Int,
    species_count::Int,
    mode::Symbol,
)
    species_count > 0 || throw(ArgumentError("species_count must be positive"))
    group = _optional_namelist_group(document, :speclist)
    isnothing(group) && return ones(Int, tree_count)

    target_size = mode === :legacy ? _LEGACY_MAX_TREES : tree_count
    initial = mode === :legacy ? ones(Int, target_size) : Any[]
    fill_value = mode === :legacy ? 1 : nothing
    values = _namelist_array_values(
        group,
        :ispecies;
        initial=initial,
        fill_value=fill_value,
        size=target_size,
    )
    all(value -> value isa Integer && !(value isa Bool), values) || throw(
        ArgumentError("SPECLIST.ISPECIES must contain integers for every tree"),
    )
    species_ids = Int.(values)
    all(>(0), species_ids) || throw(
        ArgumentError("SPECLIST.ISPECIES identifiers must be positive"),
    )
    if any(>(species_count), species_ids)
        mode === :strict && throw(
            ArgumentError("SPECLIST.ISPECIES exceeds the configured species count"),
        )
        fill!(species_ids, 1)
    end
    return species_ids[1:tree_count]
end

function _legacy_tree_dates(
    group::NamelistGroup,
    number_of_dates::Int,
    mode::Symbol,
)
    default_dates = number_of_dates == 1 ? ["01/01/50"] : String[]
    if !_has_array_assignment(group, :dates)
        isempty(default_dates) && throw(
            ArgumentError("$(group.original_name).DATES is required when NODATES > 1"),
        )
        return legacy_date.(default_dates; mode=mode)
    end

    target_size = mode === :legacy ? 14 : number_of_dates
    initial = if mode === :legacy
        defaults = Any[nothing for _ in 1:target_size]
        number_of_dates == 1 && (defaults[1] = "01/01/50")
        defaults
    else
        Any[]
    end
    raw_dates = _namelist_array_values(
        group,
        :dates;
        initial=initial,
        fill_value=nothing,
        size=target_size,
    )
    active_dates = raw_dates[1:number_of_dates]
    all(value -> value isa AbstractString, active_dates) || throw(
        ArgumentError("$(group.original_name).DATES must contain $number_of_dates dates"),
    )
    return [legacy_date(String(value); mode=mode) for value in active_dates]
end

function _legacy_tree_table(
    document::NamelistDocument,
    individual_name::Symbol,
    common_name::Symbol,
    tree_count::Int,
    mode::Symbol,
    ::Type{T};
    optional::Bool=false,
) where {T<:AbstractFloat}
    individual = _optional_namelist_group(document, individual_name)
    common = _optional_namelist_group(document, common_name)
    if !isnothing(individual) && !isnothing(common) && mode === :strict
        throw(
            ArgumentError(
                "strict mode accepts only one of &$(uppercase(String(individual_name))) " *
                "and &$(uppercase(String(common_name)))",
            ),
        )
    end
    group = isnothing(individual) ? common : individual
    if isnothing(group)
        optional && return nothing
        throw(
            ArgumentError(
                "missing tree trajectory &$(uppercase(String(individual_name))) or " *
                "&$(uppercase(String(common_name))) in $(document.source)",
            ),
        )
    end

    number_of_dates = _integer_value(group, :nodates; default=0)
    number_of_dates > 0 || throw(
        ArgumentError("$(group.original_name).NODATES must be positive"),
    )
    if number_of_dates > 14
        mode === :strict && throw(
            ArgumentError("$(group.original_name).NODATES cannot exceed historical MAXDATE=14"),
        )
        number_of_dates = 14
    end
    dates = _legacy_tree_dates(group, number_of_dates, mode)

    individual_values = !isnothing(individual)
    expected = number_of_dates * (individual_values ? tree_count : 1)
    initial = fill(-one(T), expected)
    raw_values = _namelist_array_values(
        group,
        :values;
        T=T,
        initial=initial,
        fill_value=-one(T),
        size=mode === :strict ? expected : nothing,
    )
    length(raw_values) >= expected || throw(
        DimensionMismatch(
            "$(group.original_name).VALUES needs $expected entries, got $(length(raw_values))",
        ),
    )
    all(value -> value isa Real && !(value isa Bool), raw_values[1:expected]) || throw(
        ArgumentError("$(group.original_name).VALUES must contain numeric dimensions"),
    )
    values = T.(raw_values[1:expected])
    matrix = if individual_values
        reshape(values, number_of_dates, tree_count)
    else
        repeat(reshape(values, number_of_dates, 1), 1, tree_count)
    end
    return TreeDimensionTable(dates, matrix)
end

function _legacy_tree_scene(
    document::NamelistDocument,
    species_count::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    if !isnothing(_optional_namelist_group(document, :phenology))
        # Diagnose the actual primary input before the unresolved scientific
        # assignment boundary. Parsing never enables or installs this curve.
        read_phenology_input(document; mode, T)
        throw(ArgumentError(
            "tree leaf area from &PHENOLOGY is not implemented yet; refusing to " *
            "silently use a lower-priority LAREA table in $(document.source)",
        ))
    end
    plot = _legacy_plot_config(document, mode, T)
    x, y, z = _legacy_tree_positions(document, plot, mode)
    species_ids = _legacy_species_ids(
        document,
        plot.tree_count,
        species_count,
        mode,
    )
    trees = [
        LegacyTreeRecord(index, species_ids[index], (x[index], y[index], z[index])) for
        index in 1:plot.tree_count
    ]

    trajectories = LegacyTreeTrajectories(
        _legacy_tree_table(
            document,
            _TREE_TRAJECTORY_GROUPS.radius_x...,
            plot.tree_count,
            mode,
            T,
        ),
        _legacy_tree_table(
            document,
            _TREE_TRAJECTORY_GROUPS.radius_y...,
            plot.tree_count,
            mode,
            T,
        ),
        _legacy_tree_table(
            document,
            _TREE_TRAJECTORY_GROUPS.crown_depth...,
            plot.tree_count,
            mode,
            T,
        ),
        _legacy_tree_table(
            document,
            _TREE_TRAJECTORY_GROUPS.crown_base_height...,
            plot.tree_count,
            mode,
            T,
        ),
        _legacy_tree_table(
            document,
            _TREE_TRAJECTORY_GROUPS.leaf_area...,
            plot.tree_count,
            mode,
            T,
        ),
        _legacy_tree_table(
            document,
            _TREE_TRAJECTORY_GROUPS.stem_diameter...,
            plot.tree_count,
            mode,
            T;
            optional=true,
        ),
    )
    return LegacyTreeScene(plot, trees, trajectories)
end

"""Plot width and height in the translated MAESPA scene frame."""
plot_dimensions(plot::LegacyPlotConfig) = (
    plot.upper_corner[1] - plot.origin[1],
    plot.upper_corner[2] - plot.origin[2],
)

function _tree_indices_by_id(scene::LegacyTreeScene)
    indices = Dict{Int,Int}()
    trajectory_count = size(scene.trajectories.radius_x.values, 2)
    for tree in scene.trees
        haskey(indices, tree.id) && throw(
            ArgumentError("tree identifiers must be unique; found $(tree.id) more than once"),
        )
        1 <= tree.trajectory_index <= trajectory_count || throw(
            BoundsError(scene.trajectories.radius_x.values, (:, tree.trajectory_index)),
        )
        indices[tree.id] = tree.trajectory_index
    end
    return indices
end

"""Sum target-tree leaf area and divide by MAESPA's water-balance area."""
function stand_leaf_area_index(
    scene::LegacyTreeScene{T},
    date::Union{LegacyDate,Integer},
    target_ids,
) where {T}
    total_leaf_area = zero(T)
    tree_indices = _tree_indices_by_id(scene)
    for tree_id in target_ids
        tree_id isa Integer && !(tree_id isa Bool) || throw(
            ArgumentError("target tree identifiers must be integers"),
        )
        haskey(tree_indices, Int(tree_id)) || throw(
            ArgumentError("unknown target tree identifier $(tree_id)"),
        )
        total_leaf_area += interpolate_tree_dimension(
            scene.trajectories.leaf_area,
            date,
            tree_indices[Int(tree_id)],
        )
    end
    return total_leaf_area / scene.plot.water_balance_area
end
