"""
    LegacyDiffuseTransmissionTable

Typed contents of a historical `NNNN_tutd.dat` file used when `IOTUTD=0`.
Rows are positional and contain `point_index`, upward transmittance (`TU`),
downward transmittance (`TD`), and relative diffuse penetration (`RELDF`).
`TU` and `TD` are fractions in `[0, 1]`; `RELDF` is an
extinction-weighted penetration diagnostic and is only required to be finite
and non-negative.
The table is copied on construction so it can safely be shared by the
per-target PlantSimEngine models.
"""
struct LegacyDiffuseTransmissionTable{T<:AbstractFloat}
    source::String
    point_index::Vector{Int}
    upward_transmittance::Vector{T}
    downward_transmittance::Vector{T}
    relative_diffuse_penetration::Vector{T}

    function LegacyDiffuseTransmissionTable{T}(
        source::AbstractString,
        point_index::AbstractVector{<:Integer},
        upward_transmittance::AbstractVector{<:Real},
        downward_transmittance::AbstractVector{<:Real},
        relative_diffuse_penetration::AbstractVector{<:Real},
    ) where {T<:AbstractFloat}
        point_count = length(point_index)
        point_count > 0 || throw(
            ArgumentError("a legacy diffuse-transmission table must not be empty"),
        )
        for (values, name) in (
            (upward_transmittance, "upward transmittance"),
            (downward_transmittance, "downward transmittance"),
            (relative_diffuse_penetration, "relative diffuse penetration"),
        )
            length(values) == point_count || throw(
                DimensionMismatch("$name must contain $point_count values"),
            )
        end

        indices = Vector{Int}(undef, point_count)
        upward = Vector{T}(undef, point_count)
        downward = Vector{T}(undef, point_count)
        relative = Vector{T}(undef, point_count)
        for row in 1:point_count
            raw_index = point_index[row]
            raw_index isa Bool && throw(
                ArgumentError("point indices must be integers, not Bool"),
            )
            indices[row] = Int(raw_index)
            upward[row] = _legacy_diffuse_fraction(
                T,
                upward_transmittance[row],
                "upward transmittance",
                row,
            )
            downward[row] = _legacy_diffuse_fraction(
                T,
                downward_transmittance[row],
                "downward transmittance",
                row,
            )
            relative[row] = _legacy_diffuse_nonnegative(
                T,
                relative_diffuse_penetration[row],
                "relative diffuse penetration",
                row,
            )
        end
        return new{T}(String(source), indices, upward, downward, relative)
    end
end

function _legacy_diffuse_nonnegative(
    ::Type{T},
    value::Real,
    name::AbstractString,
    row::Int,
) where {T<:AbstractFloat}
    value isa Bool && throw(ArgumentError("$name at row $row must not be Bool"))
    isfinite(value) || throw(
        ArgumentError("$name at row $row must be finite"),
    )
    value >= zero(value) || throw(
        DomainError(value, "$name at row $row must be non-negative"),
    )
    converted = convert(T, value)
    isfinite(converted) || throw(
        ArgumentError("$name at row $row must remain finite after conversion"),
    )
    return converted
end

function _legacy_diffuse_fraction(
    ::Type{T},
    value::Real,
    name::AbstractString,
    row::Int,
) where {T<:AbstractFloat}
    value isa Bool && throw(ArgumentError("$name at row $row must not be Bool"))
    isfinite(value) || throw(
        ArgumentError("$name at row $row must be finite"),
    )
    zero(value) <= value <= one(value) || throw(
        DomainError(value, "$name at row $row must lie in [0, 1]"),
    )
    converted = convert(T, value)
    isfinite(converted) || throw(
        ArgumentError("$name at row $row must remain finite after conversion"),
    )
    return converted
end

function LegacyDiffuseTransmissionTable(
    upward_transmittance::AbstractVector{<:Real},
    downward_transmittance::AbstractVector{<:Real},
    relative_diffuse_penetration::AbstractVector{<:Real};
    point_index=collect(1:length(upward_transmittance)),
    source::AbstractString="<interactive>",
    T::Type{<:AbstractFloat}=promote_type(
        float(eltype(upward_transmittance)),
        float(eltype(downward_transmittance)),
        float(eltype(relative_diffuse_penetration)),
    ),
)
    return LegacyDiffuseTransmissionTable{T}(
        source,
        point_index,
        upward_transmittance,
        downward_transmittance,
        relative_diffuse_penetration,
    )
end

Base.length(table::LegacyDiffuseTransmissionTable) = length(table.point_index)

function _parse_legacy_diffuse_real(
    text::AbstractString,
    ::Type{T},
    source::AbstractString,
    line_number::Int,
) where {T<:AbstractFloat}
    normalized = replace(String(text), 'd' => 'e', 'D' => 'E')
    value = tryparse(T, normalized)
    isnothing(value) && throw(
        ArgumentError(
            "invalid diffuse-transmission number $(repr(text)) at " *
            "$source:$line_number",
        ),
    )
    return value
end

"""
    read_legacy_diffuse_transmission(path; mode=:legacy, T=Float32,
                                     expected_point_count=nothing)

Read the positional `J TU TD RELDF` records consumed by the legacy
`TRANSD` branch for `IOTUTD=0`. Blank lines and trailing `!` comments are
accepted. Every non-empty record must contain exactly four values. Legacy mode
preserves the first `J` field without interpreting it, as the Fortran implied
read does; strict mode requires the ordered sequence `1:n`.
"""
function read_legacy_diffuse_transmission(
    path::AbstractString;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
    expected_point_count::Union{Nothing,Integer}=nothing,
)
    _check_input_mode(mode)
    if !isnothing(expected_point_count)
        expected_point_count isa Bool && throw(
            ArgumentError("expected_point_count must be an integer, not Bool"),
        )
        expected_point_count > 0 || throw(
            ArgumentError("expected_point_count must be positive"),
        )
    end
    source = abspath(path)
    isfile(source) || throw(
        ArgumentError("missing MAESPA diffuse-transmission input file $source"),
    )
    indices = Int[]
    upward = T[]
    downward = T[]
    relative = T[]
    for (line_number, raw_line) in enumerate(eachline(source))
        content = first(split(raw_line, '!'; limit=2))
        stripped = strip(content)
        isempty(stripped) && continue
        fields = split(replace(stripped, ',' => ' '))
        length(fields) == 4 || throw(
            ArgumentError(
                "expected four values J TU TD RELDF at $source:$line_number; " *
                "found $(length(fields))",
            ),
        )
        point = tryparse(Int, fields[1])
        isnothing(point) && throw(
            ArgumentError(
                "invalid diffuse-transmission point index $(repr(fields[1])) " *
                "at $source:$line_number",
            ),
        )
        push!(indices, point)
        push!(
            upward,
            _parse_legacy_diffuse_real(fields[2], T, source, line_number),
        )
        push!(
            downward,
            _parse_legacy_diffuse_real(fields[3], T, source, line_number),
        )
        push!(
            relative,
            _parse_legacy_diffuse_real(fields[4], T, source, line_number),
        )
    end
    table = LegacyDiffuseTransmissionTable{T}(
        source,
        indices,
        upward,
        downward,
        relative,
    )
    if !isnothing(expected_point_count) && length(table) != expected_point_count
        throw(
            DimensionMismatch(
                "$source contains $(length(table)) diffuse-transmission rows; " *
                "expected $(Int(expected_point_count))",
            ),
        )
    end
    if mode === :strict
        expected_indices = collect(1:length(table))
        table.point_index == expected_indices || throw(
            ArgumentError(
                "$source must declare ordered point indices 1:$(length(table)) " *
                "in strict mode",
            ),
        )
    end
    return table
end
