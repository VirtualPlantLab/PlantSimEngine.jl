"""
    RadiationSensorPoints{T}(positions_m; ids=nothing, source="native", title="")
    RadiationSensorPoints(positions_m; ids=nothing, source="native", title="")

Fixed radiation-sensor identities and local `(x,y,z)` positions in metres.
Coordinates are already in the translated MAESPA scene frame: do not subtract
the original plot origin, rotate by plot bearing, or add ground-slope height.
Omitted IDs become `1:N`; explicit IDs must be distinct integers (not Bool) or
distinct symbols. A collection uses one of those two identity families.

The immutable configuration owns copied typed vectors, without specializing
its type on point count. Inputs must be nonempty and finite. Plot XY bounds
are checked separately at scene assembly, not guessed by this constructor.
Direct mutation of the owned vectors is not a supported structural update:
rebuild a point set and reassemble/revalidate the scenario after changes.
The inferred constructor promotes the supplied real coordinate types; the
explicit `{T}` constructor selects the requested coordinate precision.
"""
struct RadiationSensorPoints{T<:AbstractFloat,I}
    ids::Vector{I}
    positions_m::Vector{NTuple{3,T}}
    source::String
    title::String

    function RadiationSensorPoints{T}(
        positions_m;
        ids=nothing,
        source::AbstractString="native",
        title::AbstractString="",
    ) where {T<:AbstractFloat}
        positions = collect(positions_m)
        isempty(positions) && throw(ArgumentError("radiation sensor points must not be empty"))
        identities = isnothing(ids) ? collect(1:length(positions)) : collect(ids)
        length(identities) == length(positions) || throw(DimensionMismatch(
            "sensor IDs and positions must have the same length",
        ))
        checked_ids = if all(id -> id isa Symbol, identities)
            Symbol[id for id in identities]
        elseif all(id -> id isa Integer && !(id isa Bool), identities)
            # Identities must not undergo lossy signed/unsigned promotion.
            # Homogeneous IDs retain their concrete type; mixed integers keep
            # their original values under the common integer supertype.
            I = foldl(typejoin, (typeof(id) for id in identities))
            I[id for id in identities]
        else
            throw(ArgumentError("sensor IDs must be all non-Bool integers or all symbols"))
        end
        length(Set(checked_ids)) == length(checked_ids) || throw(
            ArgumentError("sensor IDs must be unique"),
        )
        checked_positions = Vector{NTuple{3,T}}(undef, length(positions))
        for (index, position) in pairs(positions)
            (position isa Tuple || position isa AbstractVector) && length(position) == 3 || throw(
                ArgumentError("sensor position $index must contain exactly three coordinates"),
            )
            checked_positions[index] = ntuple(3) do axis
                value = position[axis]
                value isa Real && !(value isa Bool) && isfinite(value) || throw(
                    ArgumentError("sensor position $index must contain finite real coordinates, not Bool"),
                )
                converted = convert(T, value)
                isfinite(converted) || throw(ArgumentError(
                    "sensor position $index must remain finite in the requested coordinate type",
                ))
                converted
            end
        end
        return new{T,eltype(checked_ids)}(
            checked_ids, checked_positions, String(source), String(title),
        )
    end
end

function RadiationSensorPoints(positions_m; ids=nothing, source="native", title="")
    positions = collect(positions_m)
    isempty(positions) && throw(ArgumentError("radiation sensor points must not be empty"))
    numeric_type = nothing
    for position in positions
        (position isa Tuple || position isa AbstractVector) && length(position) == 3 || throw(
            ArgumentError("sensor positions must contain exactly three coordinates"),
        )
        for value in position
            value isa Real && !(value isa Bool) || throw(
                ArgumentError("sensor coordinates must be real numbers, not Bool"),
            )
            value_type = typeof(float(value))
            numeric_type = isnothing(numeric_type) ? value_type : promote_type(numeric_type, value_type)
        end
    end
    return RadiationSensorPoints{numeric_type}(positions; ids, source, title)
end

Base.length(points::RadiationSensorPoints) = length(points.ids)

"""
    read_radiation_sensor_points(document_or_path; mode=:legacy, T=Float32)

Read GETPOINTSF's `&CONTROL NOPOINTS, INPUTTYPE`, `&XYZ COORDS`, or
`&TRANSECT ANGLE, SPACING, ZHEIGHT`. INPUTTYPE defaults to 1; NOPOINTS must be
explicitly positive. XYZ consists of consecutive local `(x,y,z)` triples.
Transect angles are degrees, with point n at distance `(n-1/2)*SPACING` from
the local origin and every Z equal to ZHEIGHT. No missing coordinates or
transect parameters are inferred. The old MAXP allocation is not a scientific
point-count cap. This reader creates no radiation model or output file.
"""
function read_radiation_sensor_points(
    document::NamelistDocument;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
)
    _check_input_mode(mode)
    control = _config_group(document, :control, mode)
    count = _integer_value(control, :nopoints; default=0)
    count > 0 || throw(ArgumentError("points CONTROL.NOPOINTS must be positive"))
    input_type = _integer_value(control, :inputtype; default=1)
    input_type in (1, 2) || throw(ArgumentError("points CONTROL.INPUTTYPE must be 1 or 2"))
    positions = if input_type == 1
        xyz = _config_group(document, :xyz, mode)
        coordinate_count = Base.Checked.checked_mul(3, count)
        coordinates = _namelist_array_values(xyz, :coords;
            T, size=coordinate_count, fill_value=nothing)
        all(value -> value isa Real && !(value isa Bool), coordinates) || throw(
            ArgumentError("XYZ.COORDS must fully assign all 3*NOPOINTS real coordinates"),
        )
        [(coordinates[3 * index - 2], coordinates[3 * index - 1], coordinates[3 * index])
            for index in 1:count]
    else
        transect = _config_group(document, :transect, mode)
        angle = _real_value(transect, :angle, T)
        spacing = _real_value(transect, :spacing, T)
        height = _real_value(transect, :zheight, T)
        all(isfinite, (angle, spacing, height)) || throw(
            ArgumentError("TRANSECT ANGLE, SPACING and ZHEIGHT must be finite"),
        )
        angle_rad = angle * (T(π) / T(180))
        cosine, sine = cos(angle_rad), sin(angle_rad)
        distance = spacing / T(2)
        points = Vector{NTuple{3,T}}(undef, count)
        for index in eachindex(points)
            points[index] = (distance * cosine, distance * sine, height)
            distance += spacing
        end
        points
    end
    first_line = findfirst(entry -> first(entry) == 1, document.free_text)
    title = isnothing(first_line) ? "" : String(rstrip(last(document.free_text[first_line])))
    return RadiationSensorPoints{T}(positions; source=document.source, title)
end

function read_radiation_sensor_points(path::AbstractString; mode::Symbol=:legacy, kwargs...)
    return read_radiation_sensor_points(read_namelist(path; mode); mode, kwargs...)
end

# Return a detached, revalidated configuration for the scene builder to retain.
# This is a boundary check, not a timestep check or a ground-height transform.
function _checked_radiation_sensor_points(scene::LegacyTreeScene, points::RadiationSensorPoints{T}) where {T}
    checked = RadiationSensorPoints{T}(points.positions_m;
        ids=points.ids, source=points.source, title=points.title)
    width, height = plot_dimensions(scene.plot)
    for (id, position) in zip(checked.ids, checked.positions_m)
        x, y, _ = position
        zero(x) <= x <= width && zero(y) <= y <= height || throw(ArgumentError(
            "sensor $id lies outside the local plot XY bounds [0,$width] x [0,$height]",
        ))
    end
    return checked
end

# Keep the enable switch in raw CONTROL, without another SimulationConfig field.
function _radiation_sensor_option(document::NamelistDocument, mode::Symbol)
    group = try
        namelist_group(document, :control)
    catch exception
        exception isa KeyError || rethrow()
        nothing
    end
    option = isnothing(group) ? 0 : _integer_value(group, :ipoints; default=0)
    mode === :strict && !(option in (0, 1, 2)) && throw(
        ArgumentError("CONTROL.IPOINTS must be 0, 1 or 2 in strict mode"),
    )
    return option
end

function _read_radiation_sensor_input(documents, root, prefix, mode, policy, ::Type{T}) where {T<:AbstractFloat}
    policy in (:auto, :required, :skip) || throw(
        ArgumentError("points must be :auto, :required or :skip"),
    )
    option = _radiation_sensor_option(documents[:control], mode)
    policy === :skip && return nothing
    path = joinpath(root, "$(prefix)_points.dat")
    if option <= 0
        policy === :required && throw(ArgumentError("points=:required requires active CONTROL.IPOINTS"))
        isfile(path) && @warn "points input ignored because CONTROL.IPOINTS is inactive" source=path value=option
        return nothing
    end
    isfile(path) || throw(ArgumentError("active CONTROL.IPOINTS requires points input file $path"))
    document = read_namelist(path; mode)
    documents[:points] = document
    return read_radiation_sensor_points(document; mode, T)
end
