"""Leaf-area fractions used by the structural and physiological age classes."""
struct FoliageAgeClasses{T<:AbstractFloat}
    structural_count::Int
    physiological_count::Int
    structural_proportions::Vector{T}
    physiological_proportions::Vector{T}
end

"""
Layer-resolved optical properties for the three historical MAESPA wavebands.

Matrices have dimensions `canopy layer × waveband`, ordered as PAR, near
infrared, and thermal radiation. `soil_reflectance` follows the same order.
"""
struct LeafOptics{T<:AbstractFloat}
    reflectance::Matrix{T}
    transmittance::Matrix{T}
    absorptance::Matrix{T}
    soil_reflectance::NTuple{3,T}
end

"""Common dispatch root for the typed `READGS` stomatal variants."""
abstract type AbstractStomatalParameters{T<:AbstractFloat} end

"""
Canonical CO₂-basis parameters for the historical Ball--Berry model.

The soil-response coefficients are retained as input provenance for a later
`CALCFSOIL` process. This structure does not claim to evaluate that response.
"""
struct BallBerryStomatalParameters{T<:AbstractFloat} <:
       AbstractStomatalParameters{T}
    dates::Vector{LegacyDate}
    minimum_conductance::T
    night_conductance::T
    g0::Vector{T}
    g1::Vector{T}
    g20::Vector{T}
    g21::Vector{T}
    gamma::T
    minimum_vpd_pa::T
    leaf_width_dates::Vector{LegacyDate}
    leaf_width::Vector{T}
    stomatal_sides::Int
    source_conductance_basis::Symbol
    second_curve::Bool
    soil_moisture_deficit_amplitude::T
    soil_moisture_deficit_rate::T
    water_content_lower_fraction::T
    water_content_upper_fraction::T
    soil_water_potential_exponent_mpa_inverse::T
end

"""
Canonical CO₂-basis parameters for Ball--Berry--Leuning conductance.

Legacy H₂O inputs preserve the Fortran omission that leaves `GSMIN` on its
source basis, while strict inputs normalize it to CO₂ with the other
conductance coefficients.
"""
struct LeuningStomatalParameters{T<:AbstractFloat} <:
       AbstractStomatalParameters{T}
    dates::Vector{LegacyDate}
    minimum_conductance::T
    night_conductance::T
    g0::Vector{T}
    g1::Vector{T}
    g20::Vector{T}
    g21::Vector{T}
    gamma::T
    minimum_vpd_pa::T
    leaf_width_dates::Vector{LegacyDate}
    leaf_width::Vector{T}
    stomatal_sides::Int
    source_conductance_basis::Symbol
    second_curve::Bool
    vpd_scale_pa::T
    soil_moisture_deficit_amplitude::T
    soil_moisture_deficit_rate::T
    water_content_lower_fraction::T
    water_content_upper_fraction::T
    soil_water_potential_exponent_mpa_inverse::T
end

"""
Canonical CO₂-basis parameters for the historical Medlyn model.

The ambiguous legacy `VPDMIN` convention is normalized to Pa: values no
larger than one are interpreted as kPa, while larger values are already Pa.
"""
struct MedlynStomatalParameters{T<:AbstractFloat} <:
       AbstractStomatalParameters{T}
    dates::Vector{LegacyDate}
    minimum_conductance::T
    night_conductance::T
    g0::Vector{T}
    g1::Vector{T}
    g20::Vector{T}
    g21::Vector{T}
    gamma::T
    minimum_vpd_pa::T
    leaf_width_dates::Vector{LegacyDate}
    leaf_width::Vector{T}
    stomatal_sides::Int
    source_conductance_basis::Symbol
    second_curve::Bool
    medlyn_vpd_exponent::T
    water_content_lower_fraction::T
    water_content_upper_fraction::T
end

"""Canonical CO₂-basis parameters for the historical Tuzet stomatal model."""
struct TuzetStomatalParameters{T<:AbstractFloat} <:
       AbstractStomatalParameters{T}
    dates::Vector{LegacyDate}
    minimum_conductance::T
    night_conductance::T
    g0::Vector{T}
    g1::Vector{T}
    g20::Vector{T}
    g21::Vector{T}
    sensitivity_factor::T
    reference_water_potential::T
    gamma::T
    minimum_vpd_pa::T
    leaf_width_dates::Vector{LegacyDate}
    leaf_width::Vector{T}
    stomatal_sides::Int
    source_conductance_basis::Symbol
    second_curve::Bool
end

"""
Temperature-response parameters associated with the historical `RD0` table.

MAESPA stores `Q10F` and `K10F` as exponential coefficients in °C⁻¹, despite
the legacy `Q10` name. `reference_temperature_c` is the configurable `RTEMP`
at which the tabulated respiration rate applies.
"""
struct LeafRespirationParameters{T<:AbstractFloat}
    temperature_response_dates::Vector{LegacyDate}
    temperature_response_coefficients_c_inverse::Vector{T}
    acclimation_coefficient_c_inverse::T
    reference_temperature_c::T
    minimum_temperature_c::T
    day_respiration_multiplier::T
    growth_respiration_efficiency::T
end

"""
Fixed photosynthetic-capacity parameters prepared by the historical
`READJMAX` and `READVSTRESS` routines.

The activation and deactivation energies are in J mol⁻¹, the entropy terms
in J mol⁻¹ K⁻¹, and the low-temperature ramp bounds in °C. `THETA` is
retained as `electron_transport_curvature` because it is consumed by the
downstream electron-transport quadratic rather than by the temperature
response itself.

The units of the historical water-stress parameters depend on `VFUN`: for the
linear model (`1`), `VPARA` and `VPARB` are soil water potentials in MPa; for
the logistic model (`2`), `VPARA` is in MPa⁻¹ and `VPARB` in MPa. `VPARC` is
retained for input provenance even though the executable `VJMAXWFN` never
uses it.
"""
struct PhotosyntheticCapacityParameters{T<:AbstractFloat}
    ieco::Int
    jmax_activation_energy_j_mol::T
    jmax_deactivation_energy_j_mol::T
    jmax_entropy_j_mol_k::T
    vcmax_activation_energy_j_mol::T
    vcmax_deactivation_energy_j_mol::T
    vcmax_entropy_j_mol_k::T
    low_temperature_ramp_upper_c::T
    low_temperature_ramp_lower_c::T
    electron_transport_curvature::T
    water_stress_model::Int
    water_stress_parameter_a::T
    water_stress_parameter_b::T
    water_stress_parameter_c::T
end

"""
Woody-respiration parameters prepared by the historical `READRW` routine.

`rate_model` is the effective `MODELRW` choice after retaining the legacy
`RM == 0 && RMA > 0` switch to mode 2. `configured_woody_respiration_rate`
(`RM`) is mass-specific, while `stem_area_respiration_rate` (`RMA`) is
surface-specific. The dated temperature coefficients come from `WOODQ10`
when present and otherwise contain the scalar `WRESP.Q10W` at the conventional
pre-simulation date.

Although `STEMFORM` describes geometry, it belongs here because MAESPA reads
it from the physiology-file `WRESP` group and uses it only in `CALCRMW`.
"""
struct WoodyRespirationParameters{T<:AbstractFloat}
    rate_model::Int
    growth_respiration_efficiency::T
    configured_woody_respiration_rate_umol_per_unit_s::T
    stem_area_respiration_rate_umol_co2_m2_s::T
    reference_temperature_c::T
    temperature_response_dates::Vector{LegacyDate}
    temperature_response_coefficients_c_inverse::Vector{T}
    stem_form_factor::T
    collelongo_coefficient_a::T
    collelongo_coefficient_k_cm_inverse::T
    stem_specific_dry_weight::T
end

"""
Root-maintenance-respiration parameters prepared by the historical `READRR`
routine.

The coarse- and fine-root base rates (`RMCR` and `RMFR`) are expressed per kg
of root dry matter. `temperature_response_coefficient_c_inverse` is the
historical `Q10R` exponential coefficient used directly by `RESP`, despite its
legacy `Q10` name. `TBELOW` remains part of the shared leaf-respiration input
group and is therefore deliberately not duplicated here.
"""
struct RootRespirationParameters{T<:AbstractFloat}
    coarse_root_base_respiration_rate_umol_per_kg_dry_matter_s::T
    fine_root_base_respiration_rate_umol_per_kg_dry_matter_s::T
    temperature_response_coefficient_c_inverse::T
    reference_temperature_c::T
end

"""
Branch-maintenance-respiration parameters prepared by historical `READRB`.

`base_respiration_rate_umol_per_kg_dry_matter_s` is `RMB`, specified per kg
of branch dry matter. `temperature_response_coefficient_c_inverse` is the
historical `Q10B` exponential coefficient used directly by `RESP`, not a
multiplicative Q10. `TBELOW` is shared with leaf respiration and branch
biomass comes from the structural `ALLOMB` allometry, so neither belongs in
this fixed physiology structure.
"""
struct BranchRespirationParameters{T<:AbstractFloat}
    base_respiration_rate_umol_per_kg_dry_matter_s::T
    temperature_response_coefficient_c_inverse::T
    reference_temperature_c::T
end

"""
Typed first-slice physiology configuration for one MAESPA species.

`sla` is `nothing` when a legacy input omits the optional SLA table. Strict
inputs always contain a positive-valued SLA table.
"""
struct SpeciesPhysiologyConfig{T<:AbstractFloat}
    source::String
    canopy_layers::Int
    age_classes::FoliageAgeClasses{T}
    optics::LeafOptics{T}
    stomatal::AbstractStomatalParameters{T}
    leaf_respiration::LeafRespirationParameters{T}
    woody_respiration::WoodyRespirationParameters{T}
    root_respiration::RootRespirationParameters{T}
    branch_respiration::BranchRespirationParameters{T}
    photosynthetic_capacity::Union{Nothing,PhotosyntheticCapacityParameters{T}}
    jmax::SpeciesParameterTable{T}
    vcmax::SpeciesParameterTable{T}
    rd::SpeciesParameterTable{T}
    sla::Union{Nothing,SpeciesParameterTable{T}}
    ajq::SpeciesParameterTable{T}
end

function _inactive_woody_respiration_parameters(::Type{T}) where {T<:AbstractFloat}
    return WoodyRespirationParameters{T}(
        0,
        zero(T),
        zero(T),
        zero(T),
        zero(T),
        [legacy_date("01/01/50")],
        T[zero(T)],
        zero(T),
        zero(T),
        zero(T),
        zero(T),
    )
end

function _inactive_root_respiration_parameters(::Type{T}) where {T<:AbstractFloat}
    return RootRespirationParameters{T}(
        zero(T),
        zero(T),
        zero(T),
        zero(T),
    )
end

function _inactive_branch_respiration_parameters(::Type{T}) where {T<:AbstractFloat}
    return BranchRespirationParameters{T}(
        zero(T),
        zero(T),
        zero(T),
    )
end

# Preserve the original positional construction contract used by interactive
# callers before woody respiration became part of the typed PHY schema.
function SpeciesPhysiologyConfig{T}(
    source,
    canopy_layers,
    age_classes::FoliageAgeClasses{T},
    optics::LeafOptics{T},
    stomatal::AbstractStomatalParameters{T},
    leaf_respiration::LeafRespirationParameters{T},
    jmax::SpeciesParameterTable{T},
    vcmax::SpeciesParameterTable{T},
    rd::SpeciesParameterTable{T},
    sla::Union{Nothing,SpeciesParameterTable{T}},
    ajq::SpeciesParameterTable{T},
) where {T<:AbstractFloat}
    return SpeciesPhysiologyConfig{T}(
        String(source),
        Int(canopy_layers),
        age_classes,
        optics,
        stomatal,
        leaf_respiration,
        _inactive_woody_respiration_parameters(T),
        _inactive_root_respiration_parameters(T),
        _inactive_branch_respiration_parameters(T),
        nothing,
        jmax,
        vcmax,
        rd,
        sla,
        ajq,
    )
end

# Preserve the positional contract introduced with WoodyRespirationParameters,
# before root respiration became part of the typed PHY schema.
function SpeciesPhysiologyConfig{T}(
    source,
    canopy_layers,
    age_classes::FoliageAgeClasses{T},
    optics::LeafOptics{T},
    stomatal::AbstractStomatalParameters{T},
    leaf_respiration::LeafRespirationParameters{T},
    woody_respiration::WoodyRespirationParameters{T},
    jmax::SpeciesParameterTable{T},
    vcmax::SpeciesParameterTable{T},
    rd::SpeciesParameterTable{T},
    sla::Union{Nothing,SpeciesParameterTable{T}},
    ajq::SpeciesParameterTable{T},
) where {T<:AbstractFloat}
    return SpeciesPhysiologyConfig{T}(
        String(source),
        Int(canopy_layers),
        age_classes,
        optics,
        stomatal,
        leaf_respiration,
        woody_respiration,
        _inactive_root_respiration_parameters(T),
        _inactive_branch_respiration_parameters(T),
        nothing,
        jmax,
        vcmax,
        rd,
        sla,
        ajq,
    )
end


# Preserve the positional contract introduced with RootRespirationParameters,
# before branch respiration became part of the typed PHY schema.
function SpeciesPhysiologyConfig{T}(
    source,
    canopy_layers,
    age_classes::FoliageAgeClasses{T},
    optics::LeafOptics{T},
    stomatal::AbstractStomatalParameters{T},
    leaf_respiration::LeafRespirationParameters{T},
    woody_respiration::WoodyRespirationParameters{T},
    root_respiration::RootRespirationParameters{T},
    jmax::SpeciesParameterTable{T},
    vcmax::SpeciesParameterTable{T},
    rd::SpeciesParameterTable{T},
    sla::Union{Nothing,SpeciesParameterTable{T}},
    ajq::SpeciesParameterTable{T},
) where {T<:AbstractFloat}
    return SpeciesPhysiologyConfig{T}(
        String(source),
        Int(canopy_layers),
        age_classes,
        optics,
        stomatal,
        leaf_respiration,
        woody_respiration,
        root_respiration,
        _inactive_branch_respiration_parameters(T),
        nothing,
        jmax,
        vcmax,
        rd,
        sla,
        ajq,
    )
end

# Preserve the complete positional contract that existed immediately before
# PhotosyntheticCapacityParameters became part of the typed PHY schema. The
# explicit `nothing` records that these interactive configurations predate the
# parser slice; it avoids inventing activation energies that were never given.
function SpeciesPhysiologyConfig{T}(
    source,
    canopy_layers,
    age_classes::FoliageAgeClasses{T},
    optics::LeafOptics{T},
    stomatal::AbstractStomatalParameters{T},
    leaf_respiration::LeafRespirationParameters{T},
    woody_respiration::WoodyRespirationParameters{T},
    root_respiration::RootRespirationParameters{T},
    branch_respiration::BranchRespirationParameters{T},
    jmax::SpeciesParameterTable{T},
    vcmax::SpeciesParameterTable{T},
    rd::SpeciesParameterTable{T},
    sla::Union{Nothing,SpeciesParameterTable{T}},
    ajq::SpeciesParameterTable{T},
) where {T<:AbstractFloat}
    return SpeciesPhysiologyConfig{T}(
        String(source),
        Int(canopy_layers),
        age_classes,
        optics,
        stomatal,
        leaf_respiration,
        woody_respiration,
        root_respiration,
        branch_respiration,
        nothing,
        jmax,
        vcmax,
        rd,
        sla,
        ajq,
    )
end

function _required_photosynthetic_capacity_parameters(
    config::SpeciesPhysiologyConfig,
)
    parameters = config.photosynthetic_capacity
    isnothing(parameters) && throw(
        ArgumentError(
            "this SpeciesPhysiologyConfig predates typed JMAXPARS/VCMAXPARS parameters",
        ),
    )
    return parameters
end

function _read_leaf_respiration_parameters(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    group = _physiology_group(document, :rdpars; required=false)
    parameter(name, default) = isnothing(group) ? convert(T, default) :
                               _physiology_real(group, name, T; default=default)
    scalar_temperature_response = parameter(:q10f, zero(T))
    acclimation = parameter(:k10f, zero(T))
    reference_temperature = parameter(:rtemp, zero(T))
    minimum_temperature = parameter(:tbelow, T(-100))
    day_multiplier = parameter(:dayresp, one(T))
    growth_efficiency = parameter(:effyrf, zero(T))
    dated_group = _physiology_group(document, :folq10; required=false)
    temperature_response_dates, temperature_responses = if isnothing(dated_group)
        scalar_temperature_response != zero(T) || throw(
            ArgumentError(
                "leaf respiration requires RDPARS.Q10F or a dated &FOLQ10 table",
            ),
        )
        ([legacy_date("01/01/50"; mode=mode)], T[scalar_temperature_response])
    else
        date_count = _physiology_positive_count(
            _physiology_integer(dated_group, :ndates, T),
            "NDATES in &FOLQ10",
        )
        dates = _physiology_dates(dated_group, :dates, date_count, mode, T)
        _physiology_has_array(dated_group, :rates) || throw(
            ArgumentError("missing required RATES in &FOLQ10"),
        )
        rates = _physiology_declared_values(
            _physiology_real_array(dated_group, :rates, T),
            date_count,
            "RATES in &FOLQ10",
            mode,
        )
        _physiology_validate_dated_values(dates, rates, "FOLQ10")
        dates, rates
    end
    values = (
        temperature_responses...,
        acclimation,
        reference_temperature,
        minimum_temperature,
        day_multiplier,
        growth_efficiency,
    )
    all(isfinite, values) || throw(
        ArgumentError("leaf-respiration parameters must be finite"),
    )
    first(temperature_responses) != zero(T) || throw(
        ArgumentError("the first Q10F/FOLQ10 coefficient must be non-zero"),
    )
    if mode === :strict
        all(>(zero(T)), temperature_responses) || throw(
            ArgumentError("Q10F/FOLQ10 rates must be positive in strict mode"),
        )
        day_multiplier >= zero(T) || throw(
            ArgumentError("DAYRESP must be non-negative in strict mode"),
        )
        growth_efficiency >= zero(T) || throw(
            ArgumentError("EFFYRF must be non-negative in strict mode"),
        )
    end
    return LeafRespirationParameters{T}(
        temperature_response_dates,
        temperature_responses,
        acclimation,
        reference_temperature,
        minimum_temperature,
        day_multiplier,
        growth_efficiency,
    )
end

struct _RequiredPhysiologyValue end
const _REQUIRED_PHYSIOLOGY_VALUE = _RequiredPhysiologyValue()

function _physiology_mode(mode::Symbol)
    mode in (:legacy, :strict) || throw(
        ArgumentError("mode must be :legacy or :strict, got $(repr(mode))"),
    )
    return mode
end

function _physiology_group(
    document::NamelistDocument,
    name::Symbol;
    required::Bool=true,
)
    try
        return namelist_group(document, name)
    catch exception
        if exception isa KeyError
            required || return nothing
            throw(
                ArgumentError(
                    "missing required namelist &$(uppercase(String(name))) in $(document.source)",
                ),
            )
        end
        rethrow()
    end
end

_physiology_name(name) = Symbol(lowercase(String(name)))

function _physiology_has_scalar(group::NamelistGroup, name)
    normalised = _physiology_name(name)
    return any(assignment -> assignment.name === normalised, group.assignments)
end

function _physiology_has_array(group::NamelistGroup, name)
    normalised = _physiology_name(name)
    prefix = String(normalised) * "("
    return any(
        assignment -> assignment.name === normalised ||
                      startswith(String(assignment.name), prefix),
        group.assignments,
    )
end

function _physiology_parser_helper(name::Symbol)
    parser_module = parentmodule(NamelistDocument)
    isdefined(parser_module, name) || error("MAESPA parser helper $name is unavailable")
    return getfield(parser_module, name)
end

function _physiology_raw_scalar(
    group::NamelistGroup,
    name,
    ::Type{T};
    default=_REQUIRED_PHYSIOLOGY_VALUE,
) where {T}
    helper = _physiology_parser_helper(:_namelist_scalar_value)
    return helper(group, name; T=T, default=default)
end

function _physiology_raw_array(
    group::NamelistGroup,
    name,
    ::Type{T};
    initial::AbstractVector=Any[],
    fill_value=nothing,
    size::Union{Nothing,Int}=nothing,
) where {T}
    helper = _physiology_parser_helper(:_namelist_array_values)
    return helper(
        group,
        name;
        T=T,
        initial=initial,
        fill_value=fill_value,
        size=size,
    )
end

function _physiology_integer(
    group::NamelistGroup,
    name,
    ::Type{T};
    default=_REQUIRED_PHYSIOLOGY_VALUE,
) where {T<:AbstractFloat}
    if !_physiology_has_scalar(group, name)
        default isa _RequiredPhysiologyValue && throw(
            ArgumentError(
                "missing required $(uppercase(String(name))) in &$(group.original_name)",
            ),
        )
        return Int(default)
    end
    value = _physiology_raw_scalar(group, name, T; default=default)
    value isa _RequiredPhysiologyValue && throw(
        ArgumentError("$(String(name)) in &$(group.original_name) has no concrete value"),
    )
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError("$(String(name)) in &$(group.original_name) must be an integer"),
    )
    return Int(value)
end

function _physiology_real(
    group::NamelistGroup,
    name,
    ::Type{T};
    default=_REQUIRED_PHYSIOLOGY_VALUE,
) where {T<:AbstractFloat}
    if !_physiology_has_scalar(group, name)
        default isa _RequiredPhysiologyValue && throw(
            ArgumentError(
                "missing required $(uppercase(String(name))) in &$(group.original_name)",
            ),
        )
        return convert(T, default)
    end
    value = _physiology_raw_scalar(group, name, T; default=default)
    value isa _RequiredPhysiologyValue && throw(
        ArgumentError("$(String(name)) in &$(group.original_name) has no concrete value"),
    )
    value isa Real && !(value isa Bool) || throw(
        ArgumentError("$(String(name)) in &$(group.original_name) must be numeric"),
    )
    return convert(T, value)
end

function _physiology_string(
    group::NamelistGroup,
    name,
    ::Type{T};
    default=_REQUIRED_PHYSIOLOGY_VALUE,
) where {T<:AbstractFloat}
    if !_physiology_has_scalar(group, name)
        default isa _RequiredPhysiologyValue && throw(
            ArgumentError(
                "missing required $(uppercase(String(name))) in &$(group.original_name)",
            ),
        )
        return String(default)
    end
    value = _physiology_raw_scalar(group, name, T; default=default)
    value isa _RequiredPhysiologyValue && throw(
        ArgumentError("$(String(name)) in &$(group.original_name) has no concrete value"),
    )
    value isa AbstractString || throw(
        ArgumentError("$(String(name)) in &$(group.original_name) must be a string"),
    )
    return String(value)
end

function _physiology_real_array(
    group::NamelistGroup,
    name,
    ::Type{T};
    initial::AbstractVector=Any[],
    fill_value=nothing,
    size::Union{Nothing,Int}=nothing,
) where {T}
    values = _physiology_raw_array(
        group,
        name,
        T;
        initial=initial,
        fill_value=fill_value,
        size=size,
    )
    all(value -> value isa Real && !(value isa Bool), values) || throw(
        ArgumentError("$(String(name)) in &$(group.original_name) must contain numbers"),
    )
    return T.(values)
end

function _physiology_string_array(
    group::NamelistGroup,
    name,
    ::Type{T};
    initial::AbstractVector=Any[],
    fill_value=nothing,
    size::Union{Nothing,Int}=nothing,
) where {T}
    values = _physiology_raw_array(
        group,
        name,
        T;
        initial=initial,
        fill_value=fill_value,
        size=size,
    )
    all(value -> value isa AbstractString, values) || throw(
        ArgumentError("$(String(name)) in &$(group.original_name) must contain strings"),
    )
    return String.(values)
end

function _physiology_declared_values(
    values::AbstractVector,
    count::Int,
    label::AbstractString,
    mode::Symbol,
)
    length(values) >= count || throw(
        DimensionMismatch("$label has $(length(values)) values; $count are declared"),
    )
    mode === :strict && length(values) != count && throw(
        DimensionMismatch(
            "$label has $(length(values)) values but strict mode requires exactly $count",
        ),
    )
    return collect(@view values[1:count])
end

function _physiology_positive_count(value::Integer, label::AbstractString)
    value isa Bool && throw(ArgumentError("$label must be an integer, not Bool"))
    value > 0 || throw(ArgumentError("$label must be positive"))
    return Int(value)
end

function _physiology_dates(
    group::NamelistGroup,
    name,
    count::Int,
    mode::Symbol,
    ::Type{T};
    legacy_single_default::Union{Nothing,String}=nothing,
) where {T}
    raw = if _physiology_has_array(group, name)
        initial = if mode === :legacy && !isnothing(legacy_single_default)
            String[legacy_single_default]
        else
            Any[]
        end
        _physiology_string_array(
            group,
            name,
            T;
            initial=initial,
            fill_value=nothing,
            size=nothing,
        )
    elseif mode === :legacy && count == 1 && !isnothing(legacy_single_default)
        [legacy_single_default]
    else
        throw(
            ArgumentError(
                "missing required $(uppercase(String(name))) in &$(group.original_name)",
            ),
        )
    end
    selected = _physiology_declared_values(
        raw,
        count,
        "$(uppercase(String(name))) in &$(group.original_name)",
        mode,
    )
    return [legacy_date(value; mode=mode) for value in selected]
end

function _physiology_validate_dated_values(
    dates::AbstractVector{LegacyDate},
    values::AbstractVector,
    label::AbstractString,
)
    length(dates) == length(values) || throw(
        DimensionMismatch("$label dates and values must have equal lengths"),
    )
    isempty(dates) && throw(ArgumentError("$label must contain at least one date"))
    for index in 2:length(dates)
        dates[index].days_since_1950 > dates[index - 1].days_since_1950 || throw(
            ArgumentError("$label dates must be strictly increasing"),
        )
    end
    return nothing
end

function _read_photosynthetic_capacity_parameters(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    _physiology_mode(mode)
    jmax_parameters = _physiology_group(document, :jmaxpars)
    vcmax_parameters = _physiology_group(document, :vcmaxpars)

    # READJMAX initializes only these five values before the namelist reads.
    # The remaining fields are deliberately required even in legacy mode:
    # omitting one left an undefined local REAL in the Fortran executable.
    ieco = _physiology_integer(jmax_parameters, :ieco, T; default=1)
    jmax_activation = _physiology_real(jmax_parameters, :eavj, T)
    jmax_deactivation = _physiology_real(jmax_parameters, :edvj, T)
    jmax_entropy = _physiology_real(jmax_parameters, :delsj, T)
    curvature = _physiology_real(jmax_parameters, :theta, T)
    vcmax_activation = _physiology_real(vcmax_parameters, :eavc, T)
    vcmax_deactivation =
        _physiology_real(vcmax_parameters, :edvc, T; default=zero(T))
    vcmax_entropy =
        _physiology_real(vcmax_parameters, :delsc, T; default=zero(T))
    ramp_upper = _physiology_real(
        vcmax_parameters,
        :tvjup,
        T;
        default=T(-100),
    )
    ramp_lower = _physiology_real(
        vcmax_parameters,
        :tvjdn,
        T;
        default=T(-100),
    )

    stress = _physiology_group(document, :vjmaxstress; required=false)
    function stress_integer(name, default)
        isnothing(stress) && return Int(default)
        return _physiology_integer(stress, name, T; default=default)
    end
    function stress_real(name, default)
        isnothing(stress) && return convert(T, default)
        return _physiology_real(stress, name, T; default=default)
    end
    water_stress_model = stress_integer(:vfun, 0)
    stress_a = stress_real(:vpara, -200)
    stress_b = stress_real(:vparb, -199)
    stress_c = stress_real(:vparc, 1)

    values = (
        jmax_activation,
        jmax_deactivation,
        jmax_entropy,
        vcmax_activation,
        vcmax_deactivation,
        vcmax_entropy,
        ramp_upper,
        ramp_lower,
        curvature,
        stress_a,
        stress_b,
        stress_c,
    )
    all(isfinite, values) || throw(
        ArgumentError("photosynthetic-capacity parameters must be finite"),
    )
    ieco in (0, 1) || throw(
        ArgumentError("IECO in &JMAXPARS must be 0 or 1"),
    )
    zero(T) <= curvature <= one(T) || throw(
        ArgumentError("THETA in &JMAXPARS must lie between zero and one"),
    )
    ramp_upper >= ramp_lower || throw(
        ArgumentError("TVJUP in &VCMAXPARS must be at least TVJDN"),
    )
    water_stress_model in (0, 1, 2) || throw(
        ArgumentError("VFUN in &VJMAXSTRESS must be 0, 1, or 2"),
    )
    water_stress_model == 1 && stress_b <= stress_a && throw(
        ArgumentError("VFUN=1 requires VPARB to exceed VPARA"),
    )

    return PhotosyntheticCapacityParameters{T}(
        ieco,
        jmax_activation,
        jmax_deactivation,
        jmax_entropy,
        vcmax_activation,
        vcmax_deactivation,
        vcmax_entropy,
        ramp_upper,
        ramp_lower,
        curvature,
        water_stress_model,
        stress_a,
        stress_b,
        stress_c,
    )
end

function _woody_respiration_model(value)
    value isa Integer && !(value isa Bool) || throw(
        ArgumentError("wood_respiration_model must be an integer, not Bool"),
    )
    value in 0:2 || throw(
        ArgumentError("wood_respiration_model must be 0, 1, or 2"),
    )
    return Int(value)
end

function _read_woody_temperature_response(
    document::NamelistDocument,
    wresp::Union{Nothing,NamelistGroup},
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    scalar_coefficient = isnothing(wresp) ? zero(T) : _physiology_real(
        wresp,
        :q10w,
        T;
        default=zero(T),
    )
    dated = _physiology_group(document, :woodq10; required=false)
    if isnothing(dated)
        return (
            [legacy_date("01/01/50"; mode=mode)],
            T[scalar_coefficient],
        )
    end

    date_count = _physiology_positive_count(
        _physiology_integer(dated, :ndates, T),
        "NDATES in &WOODQ10",
    )
    dates = _physiology_dates(dated, :dates, date_count, mode, T)
    _physiology_has_array(dated, :rates) || throw(
        ArgumentError("missing required RATES in &WOODQ10"),
    )
    coefficients = _physiology_declared_values(
        _physiology_real_array(dated, :rates, T),
        date_count,
        "RATES in &WOODQ10",
        mode,
    )
    _physiology_validate_dated_values(dates, coefficients, "WOODQ10")
    return dates, coefficients
end

function _read_woody_respiration_parameters(
    document::NamelistDocument,
    requested_rate_model,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    requested_model = _woody_respiration_model(requested_rate_model)
    wresp = _physiology_group(document, :wresp; required=false)
    parameter(name, default) = isnothing(wresp) ? convert(T, default) :
                               _physiology_real(wresp, name, T; default=default)

    growth_efficiency = parameter(:effy, zero(T))
    configured_rate = parameter(:rm, zero(T))
    area_rate = parameter(:rma, zero(T))
    reference_temperature = parameter(:rtemp, zero(T))
    stem_form = parameter(:stemform, zero(T))
    temperature_dates, temperature_coefficients =
        _read_woody_temperature_response(document, wresp, mode, T)

    coefficient_a = zero(T)
    coefficient_k = zero(T)
    stem_specific_dry_weight = zero(T)
    if requested_model == 1
        # READRW makes the whole group fatal for MODELRW=1. Requiring all
        # three members also replaces the legacy routine's undefined values
        # when a syntactically present group omitted an individual member.
        collelongo = _physiology_group(document, :collwresp)
        coefficient_a = _physiology_real(collelongo, :ca, T)
        coefficient_k = _physiology_real(collelongo, :ck, T)
        stem_specific_dry_weight =
            _physiology_real(collelongo, :stemsdw, T)
    end

    values = (
        growth_efficiency,
        configured_rate,
        area_rate,
        reference_temperature,
        temperature_coefficients...,
        stem_form,
        coefficient_a,
        coefficient_k,
        stem_specific_dry_weight,
    )
    all(isfinite, values) || throw(
        ArgumentError("woody-respiration parameters must be finite"),
    )

    rate_is_active = requested_model == 1 ||
                     !iszero(configured_rate) ||
                     !iszero(area_rate)
    if rate_is_active && iszero(first(temperature_coefficients))
        throw(
            ArgumentError(
                "active woody respiration requires WRESP.Q10W or WOODQ10 rates",
            ),
        )
    end

    effective_model =
        iszero(configured_rate) && area_rate > zero(T) ? 2 : requested_model
    if effective_model == 2 && area_rate > zero(T)
        isnothing(wresp) && throw(
            ArgumentError("mode-2 woody respiration requires &WRESP"),
        )
        _physiology_has_scalar(wresp, :stemform) || throw(
            ArgumentError("mode-2 woody respiration requires STEMFORM in &WRESP"),
        )
    end

    if mode === :strict
        for (name, value) in (
            (:growth_respiration_efficiency, growth_efficiency),
            (
                :configured_woody_respiration_rate_umol_per_unit_s,
                configured_rate,
            ),
            (:stem_area_respiration_rate_umol_co2_m2_s, area_rate),
            (:stem_form_factor, stem_form),
            (:collelongo_coefficient_a, coefficient_a),
            (:stem_specific_dry_weight, stem_specific_dry_weight),
        )
            value >= zero(T) || throw(
                ArgumentError("$(String(name)) must be non-negative in strict mode"),
            )
        end
        if rate_is_active
            all(>(zero(T)), temperature_coefficients) || throw(
                ArgumentError(
                    "Q10W/WOODQ10 rates must be positive in strict mode",
                ),
            )
        end
    end

    return WoodyRespirationParameters{T}(
        effective_model,
        growth_efficiency,
        configured_rate,
        area_rate,
        reference_temperature,
        temperature_dates,
        temperature_coefficients,
        stem_form,
        coefficient_a,
        coefficient_k,
        stem_specific_dry_weight,
    )
end

function _read_root_respiration_parameters(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    group = _physiology_group(document, :rresp; required=false)
    parameter(name) = isnothing(group) ? zero(T) :
                      _physiology_real(group, name, T; default=zero(T))

    coarse_rate = parameter(:rmcr)
    fine_rate = parameter(:rmfr)
    temperature_coefficient = parameter(:q10r)
    reference_temperature = parameter(:rtempr)
    values = (
        coarse_rate,
        fine_rate,
        temperature_coefficient,
        reference_temperature,
    )
    all(isfinite, values) || throw(
        ArgumentError("root-respiration parameters must be finite"),
    )

    respiration_is_active = !iszero(coarse_rate) || !iszero(fine_rate)
    respiration_is_active && iszero(temperature_coefficient) && throw(
        ArgumentError(
            "active root respiration requires Q10R in &RRESP",
        ),
    )

    if mode === :strict
        coarse_rate >= zero(T) || throw(
            ArgumentError(
                "coarse-root base respiration rate must be non-negative in strict mode",
            ),
        )
        fine_rate >= zero(T) || throw(
            ArgumentError(
                "fine-root base respiration rate must be non-negative in strict mode",
            ),
        )
        if respiration_is_active
            temperature_coefficient > zero(T) || throw(
                ArgumentError("Q10R must be positive in strict mode"),
            )
        end
    end

    return RootRespirationParameters{T}(
        coarse_rate,
        fine_rate,
        temperature_coefficient,
        reference_temperature,
    )
end

function _read_branch_respiration_parameters(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    group = _physiology_group(document, :bresp; required=false)
    parameter(name) = isnothing(group) ? zero(T) :
                      _physiology_real(group, name, T; default=zero(T))

    base_rate = parameter(:rmb)
    temperature_coefficient = parameter(:q10b)
    reference_temperature = parameter(:rtempb)
    values = (base_rate, temperature_coefficient, reference_temperature)
    all(isfinite, values) || throw(
        ArgumentError("branch-respiration parameters must be finite"),
    )

    respiration_is_active = !iszero(base_rate)
    respiration_is_active && iszero(temperature_coefficient) && throw(
        ArgumentError(
            "active branch respiration requires Q10B in &BRESP",
        ),
    )

    if mode === :strict
        base_rate >= zero(T) || throw(
            ArgumentError(
                "branch base respiration rate must be non-negative in strict mode",
            ),
        )
        if respiration_is_active
            temperature_coefficient > zero(T) || throw(
                ArgumentError("Q10B must be positive in strict mode"),
            )
        end
    end

    return BranchRespirationParameters{T}(
        base_rate,
        temperature_coefficient,
        reference_temperature,
    )
end

function _read_foliage_age_classes(
    document::NamelistDocument,
    structural_count::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    noages = _physiology_group(document, :noages; required=mode === :strict)
    physiological_count = if isnothing(noages)
        1
    else
        _physiology_integer(
            noages,
            :noagep,
            T;
            default=mode === :legacy ? 1 : _REQUIRED_PHYSIOLOGY_VALUE,
        )
    end
    physiological_count =
        _physiology_positive_count(physiological_count, "NOAGEP")

    if structural_count != 1 && physiological_count != 1 &&
       structural_count != physiological_count
        throw(
            ArgumentError(
                "structural and physiological foliage age counts must agree unless one is 1",
            ),
        )
    end

    active_count = max(structural_count, physiological_count)
    proportions = if active_count == 1
        T[one(T)]
    else
        phenol = _physiology_group(document, :phenol)
        _physiology_has_array(phenol, :prop) || throw(
            ArgumentError("missing required PROP in &$(phenol.original_name)"),
        )
        initial_proportions = fill(zero(T), active_count)
        raw = _physiology_real_array(
            phenol,
            :prop,
            T;
            initial=initial_proportions,
            fill_value=zero(T),
            size=mode === :strict ? active_count : nothing,
        )
        _physiology_declared_values(
            raw,
            active_count,
            "PROP in &$(phenol.original_name)",
            mode,
        )
    end

    if mode === :strict
        all(>=(zero(T)), proportions) || throw(
            ArgumentError("foliage age proportions must be non-negative"),
        )
    end
    tolerance = one(T) / convert(T, 10_000)
    abs(sum(proportions) - one(T)) <= tolerance || throw(
        ArgumentError("foliage age proportions must sum to one"),
    )

    structural_proportions =
        structural_count == 1 ? T[one(T)] : copy(proportions[1:structural_count])
    physiological_proportions = physiological_count == 1 ?
                                    T[one(T)] :
                                    copy(proportions[1:physiological_count])
    return FoliageAgeClasses{T}(
        structural_count,
        physiological_count,
        structural_proportions,
        physiological_proportions,
    )
end

function _read_leaf_optics(
    document::NamelistDocument,
    canopy_layers::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    group = _physiology_group(document, :absorp)
    source_layers = _physiology_positive_count(
        _physiology_integer(
            group,
            :nolayers,
            T;
            default=mode === :legacy ? 1 : _REQUIRED_PHYSIOLOGY_VALUE,
        ),
        "NOLAYERS in &ABSORP",
    )
    wavelength_count = 3

    for name in (:rhosol, :arho, :atau)
        _physiology_has_array(group, name) || throw(
            ArgumentError("missing required $(uppercase(String(name))) in &ABSORP"),
        )
    end
    soil = _physiology_declared_values(
        _physiology_real_array(group, :rhosol, T),
        wavelength_count,
        "RHOSOL in &ABSORP",
        mode,
    )
    declared_optical_values = wavelength_count * source_layers
    source_reflectance = _physiology_declared_values(
        _physiology_real_array(group, :arho, T),
        declared_optical_values,
        "ARHO in &ABSORP",
        mode,
    )
    source_transmittance = _physiology_declared_values(
        _physiology_real_array(group, :atau, T),
        declared_optical_values,
        "ATAU in &ABSORP",
        mode,
    )

    if mode === :strict
        optical_tolerance = eps(T) * convert(T, 8)
        all(value -> zero(T) <= value <= one(T), soil) || throw(
            ArgumentError("RHOSOL values must lie between zero and one"),
        )
        for index in eachindex(source_reflectance, source_transmittance)
            reflectance = source_reflectance[index]
            transmittance = source_transmittance[index]
            zero(T) <= reflectance <= one(T) || throw(
                ArgumentError("ARHO values must lie between zero and one"),
            )
            zero(T) <= transmittance <= one(T) || throw(
                ArgumentError("ATAU values must lie between zero and one"),
            )
            reflectance + transmittance <= one(T) + optical_tolerance || throw(
                ArgumentError("leaf reflectance plus transmittance must not exceed one"),
            )
        end
    end

    reflectance = Matrix{T}(undef, canopy_layers, wavelength_count)
    transmittance = similar(reflectance)
    for wavelength in 1:wavelength_count
        first_index = (wavelength - 1) * source_layers + 1
        last_index = wavelength * source_layers
        reflectance[:, wavelength] = resample_uniform_layers(
            @view(source_reflectance[first_index:last_index]),
            canopy_layers,
        )
        transmittance[:, wavelength] = resample_uniform_layers(
            @view(source_transmittance[first_index:last_index]),
            canopy_layers,
        )
    end
    absorptance = one(T) .- reflectance .- transmittance
    return LeafOptics{T}(
        reflectance,
        transmittance,
        absorptance,
        (soil[1], soil[2], soil[3]),
    )
end

function _physiology_legacy_or_exact_array(
    group::NamelistGroup,
    name,
    count::Int,
    default::T,
    mode::Symbol,
    ::Type{T};
    required_in_strict::Bool=true,
) where {T<:AbstractFloat}
    if !_physiology_has_array(group, name)
        mode === :strict && required_in_strict && throw(
            ArgumentError(
                "missing required $(uppercase(String(name))) in &$(group.original_name)",
            ),
        )
        return fill(default, count)
    end
    values = _physiology_real_array(
        group,
        name,
        T;
        initial=fill(default, count),
        fill_value=default,
        size=mode === :strict ? count : nothing,
    )
    return _physiology_declared_values(
        values,
        count,
        "$(uppercase(String(name))) in &$(group.original_name)",
        mode,
    )
end

function _read_stomatal_common_parameters(
    document::NamelistDocument,
    group_name::Symbol,
    mode::Symbol,
    ::Type{T},
    ;
    vpd_units::Symbol=:kpa,
) where {T<:AbstractFloat}
    constants_group = _physiology_group(document, :bbgscon)
    parameters_group = _physiology_group(document, group_name)
    date_count = _physiology_positive_count(
        _physiology_integer(
            constants_group,
            :nodates,
            T;
            default=mode === :legacy ? 1 : _REQUIRED_PHYSIOLOGY_VALUE,
        ),
        "NODATES in &BBGSCON",
    )
    leaf_width_date_count = _physiology_positive_count(
        _physiology_integer(
            constants_group,
            :wleafnodates,
            T;
            default=mode === :legacy ? 1 : _REQUIRED_PHYSIOLOGY_VALUE,
        ),
        "WLEAFNODATES in &BBGSCON",
    )
    units = uppercase(
        strip(
            _physiology_string(
                constants_group,
                :condunits,
                T;
                default=mode === :legacy ? "CO2" : _REQUIRED_PHYSIOLOGY_VALUE,
            ),
        ),
    )
    if mode === :strict && !(units in ("CO2", "H2O"))
        throw(ArgumentError("CONDUNITS must be CO2 or H2O"))
    end
    source_basis = units == "H2O" ? :H2O : :CO2

    dates = _physiology_dates(
        parameters_group,
        :dates,
        date_count,
        mode,
        T;
        legacy_single_default="01/01/99",
    )
    leaf_width_dates = _physiology_dates(
        parameters_group,
        :wleafdates,
        leaf_width_date_count,
        mode,
        T;
        legacy_single_default="01/01/99",
    )

    zero_value = zero(T)
    inactive_curve = -convert(T, 999)
    has_g20 = _physiology_has_array(parameters_group, :g20)
    has_g21 = _physiology_has_array(parameters_group, :g21)
    if mode === :strict && has_g20 != has_g21
        throw(
            ArgumentError(
                "G20 and G21 must be supplied together in &" *
                uppercase(String(group_name)),
            ),
        )
    end
    g0 = _physiology_legacy_or_exact_array(
        parameters_group,
        :g0,
        date_count,
        zero_value,
        mode,
        T,
    )
    g1 = _physiology_legacy_or_exact_array(
        parameters_group,
        :g1,
        date_count,
        zero_value,
        mode,
        T,
    )
    g20 = _physiology_legacy_or_exact_array(
        parameters_group,
        :g20,
        date_count,
        inactive_curve,
        mode,
        T;
        required_in_strict=false,
    )
    g21 = _physiology_legacy_or_exact_array(
        parameters_group,
        :g21,
        date_count,
        inactive_curve,
        mode,
        T;
        required_in_strict=false,
    )
    leaf_width = _physiology_legacy_or_exact_array(
        parameters_group,
        :wleaf,
        leaf_width_date_count,
        zero_value,
        mode,
        T,
    )

    minimum_conductance = _physiology_real(
        parameters_group,
        :gsmin,
        T;
        default=one(T) / convert(T, 1_000),
    )
    night_conductance = _physiology_real(
        parameters_group,
        :gnight,
        T;
        default=-one(T),
    )
    night_conductance < zero(T) && (night_conductance = first(g0))
    gamma = _physiology_real(
        parameters_group,
        :gamma,
        T;
        default=mode === :legacy ? zero(T) : _REQUIRED_PHYSIOLOGY_VALUE,
    )
    minimum_vpd = _physiology_real(
        parameters_group,
        :vpdmin,
        T;
        default=one(T) / convert(T, 2),
    )
    stomatal_sides = _physiology_integer(
        parameters_group,
        :nsides,
        T;
        default=mode === :legacy ? 1 : _REQUIRED_PHYSIOLOGY_VALUE,
    )

    _physiology_validate_dated_values(dates, g0, "stomatal conductance")
    _physiology_validate_dated_values(leaf_width_dates, leaf_width, "leaf width")
    if mode === :strict
        stomatal_sides in (1, 2) || throw(
            ArgumentError("NSIDES must be one or two"),
        )
        minimum_conductance >= zero(T) || throw(
            ArgumentError("GSMIN must be non-negative"),
        )
        all(>=(zero(T)), g0) || throw(ArgumentError("G0 values must be non-negative"))
        all(>=(zero(T)), g1) || throw(ArgumentError("G1 values must be non-negative"))
        all(>(zero(T)), leaf_width) || throw(
            ArgumentError("WLEAF values must be positive"),
        )
        gamma >= zero(T) || throw(ArgumentError("GAMMA must be non-negative"))
        minimum_vpd > zero(T) || throw(ArgumentError("VPDMIN must be positive"))
    else
        stomatal_sides > 0 || throw(ArgumentError("NSIDES must be positive"))
    end
    all(
        isfinite,
        (
            minimum_conductance,
            night_conductance,
            gamma,
            minimum_vpd,
            g0...,
            g1...,
            g20...,
            g21...,
            leaf_width...,
        ),
    ) || throw(ArgumentError("READGS parameters must be finite"))

    if source_basis === :H2O
        water_to_co2_ratio = convert(T, 157) / convert(T, 100)
        if !(group_name === :bblgs && mode === :legacy)
            minimum_conductance /= water_to_co2_ratio
        end
        night_conductance /= water_to_co2_ratio
        g0 ./= water_to_co2_ratio
        g1 ./= water_to_co2_ratio
        g20 ./= water_to_co2_ratio
        g21 ./= water_to_co2_ratio
    end
    side_factor = convert(T, stomatal_sides)
    minimum_conductance *= side_factor
    night_conductance *= side_factor
    g0 .*= side_factor
    g1 .*= side_factor
    g20 .*= side_factor
    g21 .*= side_factor
    minimum_vpd_pa = if vpd_units === :kpa
        minimum_vpd * convert(T, 1_000)
    elseif vpd_units === :legacy_kpa_or_pa
        minimum_vpd <= one(T) ? minimum_vpd * convert(T, 1_000) : minimum_vpd
    else
        throw(ArgumentError("unsupported READGS VPD unit policy $(repr(vpd_units))"))
    end

    return (
        dates=dates,
        minimum_conductance=minimum_conductance,
        night_conductance=night_conductance,
        g0=g0,
        g1=g1,
        g20=g20,
        g21=g21,
        gamma=gamma,
        minimum_vpd_pa=minimum_vpd_pa,
        leaf_width_dates=leaf_width_dates,
        leaf_width=leaf_width,
        stomatal_sides=stomatal_sides,
        source_conductance_basis=source_basis,
        second_curve=first(g21) >= zero(T),
    )
end

function _stomatal_soil_response_parameters(
    group::NamelistGroup,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    smd_amplitude = _physiology_real(group, :smd1, T; default=zero(T))
    smd_rate = _physiology_real(group, :smd2, T; default=zero(T))
    water_content_lower = _physiology_real(group, :wc1, T; default=zero(T))
    water_content_upper = _physiology_real(group, :wc2, T; default=zero(T))
    potential_exponent = _physiology_real(
        group,
        :swpexp,
        T;
        default=mode === :legacy ? zero(T) : _REQUIRED_PHYSIOLOGY_VALUE,
    )
    all(
        isfinite,
        (
            smd_amplitude,
            smd_rate,
            water_content_lower,
            water_content_upper,
            potential_exponent,
        ),
    ) || throw(ArgumentError("READGS soil-response parameters must be finite"))
    return (
        smd_amplitude,
        smd_rate,
        water_content_lower,
        water_content_upper,
        potential_exponent,
    )
end

function _stomatal_common_constructor_arguments(common)
    return (
        common.dates,
        common.minimum_conductance,
        common.night_conductance,
        common.g0,
        common.g1,
        common.g20,
        common.g21,
        common.gamma,
        common.minimum_vpd_pa,
        common.leaf_width_dates,
        common.leaf_width,
        common.stomatal_sides,
        common.source_conductance_basis,
        common.second_curve,
    )
end

function _read_stomatal_parameters(
    document::NamelistDocument,
    stomatal_model::Integer,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    stomatal_model isa Bool && throw(
        ArgumentError("stomatal_model must be an integer, not Bool"),
    )
    model = Int(stomatal_model)
    group_name = if model == 2
        :bbgs
    elseif model == 3
        :bblgs
    elseif model == 4
        :bbmgs
    elseif model == 6
        :bbtuz
    else
        throw(ArgumentError("READGS supports only MODELGS=2, 3, 4, or 6"))
    end
    vpd_units = model == 4 ? :legacy_kpa_or_pa : :kpa
    common = _read_stomatal_common_parameters(
        document,
        group_name,
        mode,
        T;
        vpd_units=vpd_units,
    )
    group = _physiology_group(document, group_name)
    common_arguments = _stomatal_common_constructor_arguments(common)

    if model == 2
        soil = _stomatal_soil_response_parameters(group, mode, T)
        return BallBerryStomatalParameters{T}(common_arguments..., soil...)
    elseif model == 3
        vpd_scale = _physiology_real(group, :d0l, T)
        isfinite(vpd_scale) || throw(ArgumentError("D0L must be finite"))
        vpd_scale > zero(T) || throw(ArgumentError("D0L must be positive"))
        soil = _stomatal_soil_response_parameters(group, mode, T)
        return LeuningStomatalParameters{T}(
            common_arguments...,
            vpd_scale,
            soil...,
        )
    elseif model == 4
        medlyn_exponent = _physiology_real(group, :gk, T; default=T(0.5))
        water_content_lower = _physiology_real(group, :wc1, T; default=zero(T))
        water_content_upper = _physiology_real(group, :wc2, T; default=zero(T))
        all(
            isfinite,
            (medlyn_exponent, water_content_lower, water_content_upper),
        ) || throw(ArgumentError("BBMGS parameters must be finite"))
        return MedlynStomatalParameters{T}(
            common_arguments...,
            medlyn_exponent,
            water_content_lower,
            water_content_upper,
        )
    end

    sensitivity_factor = _physiology_real(
        group,
        :sf,
        T;
        default=mode === :legacy ? zero(T) : _REQUIRED_PHYSIOLOGY_VALUE,
    )
    reference_water_potential = _physiology_real(
        group,
        :psiv,
        T;
        default=mode === :legacy ? zero(T) : _REQUIRED_PHYSIOLOGY_VALUE,
    )
    all(isfinite, (sensitivity_factor, reference_water_potential)) || throw(
        ArgumentError("Tuzet SF and PSIV must be finite"),
    )
    if mode === :strict
        sensitivity_factor > zero(T) || throw(ArgumentError("SF must be positive"))
        reference_water_potential < zero(T) || throw(
            ArgumentError("PSIV must be negative"),
        )
    end
    return TuzetStomatalParameters{T}(
        common.dates,
        common.minimum_conductance,
        common.night_conductance,
        common.g0,
        common.g1,
        common.g20,
        common.g21,
        sensitivity_factor,
        reference_water_potential,
        common.gamma,
        common.minimum_vpd_pa,
        common.leaf_width_dates,
        common.leaf_width,
        common.stomatal_sides,
        common.source_conductance_basis,
        common.second_curve,
    )
end

function _read_tuzet_stomatal_parameters(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    return _read_stomatal_parameters(document, 6, mode, T)
end

_stomatal_model(::BallBerryStomatalParameters) = 2
_stomatal_model(::LeuningStomatalParameters) = 3
_stomatal_model(::MedlynStomatalParameters) = 4
_stomatal_model(::TuzetStomatalParameters) = 6

function _physiology_target_ages(
    source::Array{T,3},
    target_age_count::Int,
) where {T<:AbstractFloat}
    source_age_count = size(source, 3)
    result = Array{T}(undef, size(source, 1), size(source, 2), target_age_count)
    copied_age_count = min(source_age_count, target_age_count)
    result[:, :, 1:copied_age_count] = source[:, :, 1:copied_age_count]
    if copied_age_count < target_age_count
        for age in (copied_age_count + 1):target_age_count
            result[:, :, age] = source[:, :, 1]
        end
    end
    return result
end

function _read_direct_species_table(
    document::NamelistDocument,
    table_name::Symbol,
    target_layer_count::Int,
    target_age_count::Int,
    mode::Symbol,
    ::Type{T};
    required::Bool=true,
    strictly_positive::Bool=false,
    legacy_default_dimensions::Bool=false,
) where {T<:AbstractFloat}
    constants_name = Symbol(String(table_name) * "con")
    constants_group = _physiology_group(
        document,
        constants_name;
        required=mode === :strict ||
                 (required && !legacy_default_dimensions),
    )
    isnothing(constants_group) && !legacy_default_dimensions && return nothing
    data_group = _physiology_group(document, table_name)
    constants_label = uppercase(String(constants_name))
    date_count, source_layer_count, source_age_count = if isnothing(constants_group)
        (1, 1, 1)
    else
        (
            _physiology_positive_count(
                _physiology_integer(
                    constants_group,
                    :nodates,
                    T;
                    default=mode === :legacy ? 1 : _REQUIRED_PHYSIOLOGY_VALUE,
                ),
                "NODATES in &$constants_label",
            ),
            _physiology_positive_count(
                _physiology_integer(
                    constants_group,
                    :nolayers,
                    T;
                    default=mode === :legacy ? 1 : _REQUIRED_PHYSIOLOGY_VALUE,
                ),
                "NOLAYERS in &$constants_label",
            ),
            _physiology_positive_count(
                _physiology_integer(
                    constants_group,
                    :noages,
                    T;
                    default=mode === :legacy ? 1 : _REQUIRED_PHYSIOLOGY_VALUE,
                ),
                "NOAGES in &$constants_label",
            ),
        )
    end
    if mode === :strict && !(source_age_count in (1, target_age_count))
        throw(
            ArgumentError(
                "$(uppercase(String(table_name))) NOAGES must be one or match NOAGEP",
            ),
        )
    end
    _physiology_has_array(data_group, :values) || throw(
        ArgumentError(
            "missing required VALUES in &$(uppercase(String(table_name)))",
        ),
    )
    dates = _physiology_dates(
        data_group,
        :dates,
        date_count,
        mode,
        T;
        legacy_single_default="01/01/50",
    )
    expected_value_count = date_count * source_age_count * source_layer_count
    missing_value = -one(T)
    values = _physiology_declared_values(
        _physiology_real_array(
            data_group,
            :values,
            T;
            initial=fill(missing_value, expected_value_count),
            fill_value=missing_value,
            size=nothing,
        ),
        expected_value_count,
        "VALUES in &$(uppercase(String(table_name)))",
        mode,
    )
    mode === :strict && any(==(missing_value), values) && throw(
        DimensionMismatch(
            "VALUES in &$(uppercase(String(table_name))) leaves declared slots unset",
        ),
    )
    if strictly_positive && mode === :strict
        all(>(zero(T)), values) || throw(
            ArgumentError("$(uppercase(String(table_name))) values must be positive"),
        )
    else
        all(>=(zero(T)), values) || throw(
            ArgumentError(
                "$(uppercase(String(table_name))) values must be non-negative",
            ),
        )
    end
    unpacked = unpack_legacy_species_values(
        values,
        date_count,
        source_layer_count,
        source_age_count;
        target_layer_count=target_layer_count,
    )
    target_values = _physiology_target_ages(unpacked, target_age_count)
    return SpeciesParameterTable(dates, target_values)
end

function _read_leaf_nitrogen_table(
    document::NamelistDocument,
    target_layer_count::Int,
    target_age_count::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    return _read_direct_species_table(
        document,
        :nfol,
        target_layer_count,
        target_age_count,
        mode,
        T,
        legacy_default_dimensions=true,
    )
end

function _read_required_nitrogen_relation(
    document::NamelistDocument,
    group_name::Symbol,
    slope_name::Symbol,
    intercept_name::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    group = _physiology_group(document, group_name)
    slope = _physiology_real(group, slope_name, T)
    intercept = _physiology_real(group, intercept_name, T)
    all(isfinite, (slope, intercept)) || throw(
        ArgumentError(
            "$(uppercase(String(group_name))) coefficients must be finite",
        ),
    )
    return slope, intercept
end

"""
    _affine_species_parameter_table(table, slope, intercept, label, mode)

Materialise one legacy leaf-nitrogen relation after `READPHYARRAY` has already
resampled the nitrogen profile and expanded missing physiological ages. Dates
and dimensions are retained exactly. Historical mode preserves finite negative
derived values because `READJMAX` and `READRD` did not validate them; strict
mode rejects them consistently with directly supplied capacity tables.
"""
function _affine_species_parameter_table(
    table::SpeciesParameterTable{T},
    slope::T,
    intercept::T,
    label::AbstractString,
    mode::Symbol,
) where {T<:AbstractFloat}
    all(isfinite, (slope, intercept)) || throw(
        ArgumentError("$label leaf-nitrogen coefficients must be finite"),
    )
    values = similar(table.values)
    for index in eachindex(values, table.values)
        @inbounds values[index] = slope * table.values[index] + intercept
        isfinite(values[index]) || throw(
            ArgumentError("$label derived from leaf nitrogen must be finite"),
        )
        mode === :strict && values[index] < zero(T) && throw(
            ArgumentError(
                "$label derived from leaf nitrogen must be non-negative in strict mode",
            ),
        )
    end
    return SpeciesParameterTable(table.dates, values)
end

function _read_nitrogen_derived_capacity_tables(
    document::NamelistDocument,
    leaf_nitrogen::SpeciesParameterTable{T},
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    jmax_slope, jmax_intercept = _read_required_nitrogen_relation(
        document,
        :jmaxn,
        :jmaxa,
        :jmaxb,
        T,
    )
    vcmax_slope, vcmax_intercept = _read_required_nitrogen_relation(
        document,
        :jmaxn,
        :vcmaxa,
        :vcmaxb,
        T,
    )
    return (
        jmax=_affine_species_parameter_table(
            leaf_nitrogen,
            jmax_slope,
            jmax_intercept,
            "JMAX",
            mode,
        ),
        vcmax=_affine_species_parameter_table(
            leaf_nitrogen,
            vcmax_slope,
            vcmax_intercept,
            "VCMAX",
            mode,
        ),
    )
end

function _read_nitrogen_derived_respiration_table(
    document::NamelistDocument,
    leaf_nitrogen::SpeciesParameterTable{T},
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    slope, intercept = _read_required_nitrogen_relation(
        document,
        :rdn,
        :rda,
        :rdb,
        T,
    )
    return _affine_species_parameter_table(
        leaf_nitrogen,
        slope,
        intercept,
        "RD",
        mode,
    )
end

function _constant_species_parameter_table(
    value::T,
    target_layer_count::Int,
    target_age_count::Int,
) where {T<:AbstractFloat}
    values = fill(value, 1, target_layer_count, target_age_count)
    return SpeciesParameterTable([legacy_date("01/01/50")], values)
end

function _read_legacy_or_direct_ajq(
    document::NamelistDocument,
    target_layer_count::Int,
    target_age_count::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    constants_group = _physiology_group(document, :ajqcon; required=false)
    if !isnothing(constants_group) || mode === :strict
        return _read_direct_species_table(
            document,
            :ajq,
            target_layer_count,
            target_age_count,
            mode,
            T,
        )
    end

    default_quantum_yield = convert(T, 425) / convert(T, 1_000)
    jmax_parameters = _physiology_group(document, :jmaxpars; required=false)
    quantum_yield = isnothing(jmax_parameters) ?
                    default_quantum_yield :
                    _physiology_real(
        jmax_parameters,
        :ajq,
        T;
        default=default_quantum_yield,
    )
    quantum_yield >= zero(T) || throw(
        ArgumentError("AJQ in &JMAXPARS must be non-negative"),
    )
    return _constant_species_parameter_table(
        quantum_yield,
        target_layer_count,
        target_age_count,
    )
end

function _physiology_requested_day(date::LegacyDate)
    return date.days_since_1950
end

function _physiology_requested_day(date::Integer)
    date isa Bool && throw(ArgumentError("date must be an integer ordinal, not Bool"))
    return Int(date)
end

function _interpolate_dated_species_value(
    dates::Vector{LegacyDate},
    values::Vector{T},
    date::Union{LegacyDate,Integer},
) where {T<:AbstractFloat}
    requested_day = _physiology_requested_day(date)
    requested_day <= first(dates).days_since_1950 && return first(values)
    requested_day >= last(dates).days_since_1950 && return last(values)
    upper = 2
    while requested_day > dates[upper].days_since_1950
        upper += 1
    end
    requested_day == dates[upper].days_since_1950 && return values[upper]
    lower = upper - 1
    lower_day = dates[lower].days_since_1950
    upper_day = dates[upper].days_since_1950
    fraction = convert(T, requested_day - lower_day) /
               convert(T, upper_day - lower_day)
    return values[lower] + fraction * (values[upper] - values[lower])
end

"""
    interpolate_stomatal_parameters(parameters, date)

Interpolate the dated `READGS` conductance coefficients at `date`. Values
outside the configured interval are clamped to its first or last date.
"""
function interpolate_stomatal_parameters(
    parameters::AbstractStomatalParameters{T},
    date::Union{LegacyDate,Integer},
) where {T}
    return (
        g0=_interpolate_dated_species_value(parameters.dates, parameters.g0, date),
        g1=_interpolate_dated_species_value(parameters.dates, parameters.g1, date),
        g20=_interpolate_dated_species_value(parameters.dates, parameters.g20, date),
        g21=_interpolate_dated_species_value(parameters.dates, parameters.g21, date),
    )
end

"""Compatibility alias for the original Tuzet-only interpolation API."""
function interpolate_tuzet_stomatal(
    parameters::TuzetStomatalParameters,
    date::Union{LegacyDate,Integer},
)
    return interpolate_stomatal_parameters(parameters, date)
end

"""Interpolate the historical characteristic leaf width at `date`."""
function interpolate_leaf_width(
    parameters::AbstractStomatalParameters{T},
    date::Union{LegacyDate,Integer},
) where {T}
    return _interpolate_dated_species_value(
        parameters.leaf_width_dates,
        parameters.leaf_width,
        date,
    )
end

"""Interpolate the dated exponential leaf-respiration coefficient at `date`."""
function interpolate_leaf_respiration_temperature_coefficient(
    parameters::LeafRespirationParameters{T},
    date::Union{LegacyDate,Integer},
) where {T}
    return _interpolate_dated_species_value(
        parameters.temperature_response_dates,
        parameters.temperature_response_coefficients_c_inverse,
        date,
    )
end

"""Interpolate the dated exponential woody-respiration coefficient."""
function interpolate_woody_respiration_temperature_coefficient(
    parameters::WoodyRespirationParameters{T},
    date::Union{LegacyDate,Integer},
) where {T}
    return _interpolate_dated_species_value(
        parameters.temperature_response_dates,
        parameters.temperature_response_coefficients_c_inverse,
        date,
    )
end

"""
    read_species_physiology(document; canopy_layers, structural_age_count=1,
                            stomatal_model=6,
                            photosynthetic_capacity_model=0,
                            leaf_respiration_model=0,
                            wood_respiration_model=0, mode=:legacy, T)

Read the first autonomous MAESPA species-physiology slice. This version
supports Ball--Berry, Leuning, Medlyn, and Tuzet stomatal inputs
(`MODELGS=2,3,4,6`). JMAX and VCMAX may be read directly (`MODELJM=0`) or
materialised from the shared dated `NFOL` table and `JMAXN` coefficients
(`MODELJM=1`); RD follows the analogous direct (`MODELRD=0`) or `RDN`
(`MODELRD=1`) path. In both cases the result is the same typed dated-table
contract consumed by downstream processes. `JMAXPARS`, `VCMAXPARS`, and the
optional `VJMAXSTRESS` group provide a typed, directly executable capacity
response. In legacy mode SLA may be absent and AJQ then falls back to
`JMAXPARS.AJQ` (or `0.425`); strict mode requires both tables. `WRESP`,
optional `WOODQ10`, and mode-dependent `COLLWRESP`
parameters are retained for all three `MODELRW` choices. The optional `RRESP`
group retains separate fine- and coarse-root base rates plus their shared
temperature response. The optional scalar `BRESP` group retains branch
maintenance respiration without activating the unused legacy `BRANQ10`
declarations. Fixed parameters are parsed in `T`; no runtime status conversion
is performed here. In legacy mode, undefined `READGS` locals are replaced by
documented deterministic values (`GAMMA=0`, `NSIDES=1`, `SWPEXP=0`, and
Tuzet `SF=PSIV=0`); strict mode requires those inputs. Leuning `D0L` remains
required and positive in both modes because its executable equation divides by
that scale.
"""
function read_species_physiology(
    document::NamelistDocument;
    canopy_layers::Integer,
    structural_age_count::Integer=1,
    stomatal_model::Integer=6,
    photosynthetic_capacity_model::Integer=0,
    leaf_respiration_model::Integer=0,
    wood_respiration_model::Integer=0,
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat},
)
    _physiology_mode(mode)
    layers = _physiology_positive_count(canopy_layers, "canopy_layers")
    structural_ages =
        _physiology_positive_count(structural_age_count, "structural_age_count")
    for (value, label) in (
        (stomatal_model, "stomatal_model"),
        (photosynthetic_capacity_model, "photosynthetic_capacity_model"),
        (leaf_respiration_model, "leaf_respiration_model"),
        (wood_respiration_model, "wood_respiration_model"),
    )
        value isa Integer && !(value isa Bool) || throw(
            ArgumentError("$label must be an integer"),
        )
    end
    stomatal_model in (2, 3, 4, 6) || throw(
        ArgumentError("this physiology slice supports MODELGS=2, 3, 4, or 6"),
    )
    photosynthetic_capacity_model in (0, 1) || throw(
        ArgumentError("photosynthetic_capacity_model must be 0 or 1"),
    )
    leaf_respiration_model in (0, 1) || throw(
        ArgumentError("leaf_respiration_model must be 0 or 1"),
    )
    _woody_respiration_model(wood_respiration_model)

    age_classes =
        _read_foliage_age_classes(document, structural_ages, mode, T)
    optics = _read_leaf_optics(document, layers, mode, T)
    stomatal = _read_stomatal_parameters(document, stomatal_model, mode, T)
    leaf_respiration = _read_leaf_respiration_parameters(document, mode, T)
    woody_respiration = _read_woody_respiration_parameters(
        document,
        wood_respiration_model,
        mode,
        T,
    )
    root_respiration = _read_root_respiration_parameters(document, mode, T)
    branch_respiration =
        _read_branch_respiration_parameters(document, mode, T)
    photosynthetic_capacity =
        _read_photosynthetic_capacity_parameters(document, mode, T)
    physiological_ages = age_classes.physiological_count
    leaf_nitrogen = if photosynthetic_capacity_model == 1 ||
                       leaf_respiration_model == 1
        _read_leaf_nitrogen_table(
            document,
            layers,
            physiological_ages,
            mode,
            T,
        )
    else
        nothing
    end
    jmax, vcmax = if photosynthetic_capacity_model == 1
        nitrogen_tables = _read_nitrogen_derived_capacity_tables(
            document,
            something(leaf_nitrogen),
            mode,
            T,
        )
        nitrogen_tables.jmax, nitrogen_tables.vcmax
    else
        (
            _read_direct_species_table(
                document,
                :jmax,
                layers,
                physiological_ages,
                mode,
                T,
            ),
            _read_direct_species_table(
                document,
                :vcmax,
                layers,
                physiological_ages,
                mode,
                T,
            ),
        )
    end
    rd = if leaf_respiration_model == 1
        _read_nitrogen_derived_respiration_table(
            document,
            something(leaf_nitrogen),
            mode,
            T,
        )
    else
        _read_direct_species_table(
            document,
            :rd,
            layers,
            physiological_ages,
            mode,
            T,
        )
    end
    sla = _read_direct_species_table(
        document,
        :sla,
        layers,
        physiological_ages,
        mode,
        T;
        required=mode === :strict,
        strictly_positive=true,
    )
    ajq = _read_legacy_or_direct_ajq(
        document,
        layers,
        physiological_ages,
        mode,
        T,
    )
    return SpeciesPhysiologyConfig{T}(
        document.source,
        layers,
        age_classes,
        optics,
        stomatal,
        leaf_respiration,
        woody_respiration,
        root_respiration,
        branch_respiration,
        photosynthetic_capacity,
        jmax,
        vcmax,
        rd,
        sla,
        ajq,
    )
end

function read_species_physiology(path::AbstractString; mode::Symbol=:legacy, kwargs...)
    document = read_namelist(path; mode=mode)
    return read_species_physiology(document; mode=mode, kwargs...)
end
