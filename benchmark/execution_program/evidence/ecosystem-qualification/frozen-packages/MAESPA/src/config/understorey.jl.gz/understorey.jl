"""Stable identity, horizontal position, and equal ground area of one patch."""
struct UnderstoreyPatchRecord{T<:AbstractFloat}
    id::Int
    position_m::NTuple{2,T}
    area_m2::T
end

"""Dated height, LAI, and mean leaf-nitrogen trajectories for all patches."""
struct UnderstoreyTrajectories{T<:AbstractFloat}
    height_m::TreeDimensionTable{T}
    leaf_area_index::TreeDimensionTable{T}
    mean_leaf_nitrogen_g_m2::TreeDimensionTable{T}
end

"""
Typed structural part of one historical `NNNN_ustorey.dat` file.

The historical "points" are represented as equal-area ground patches. Leaf
angle is retained in its dated input form, while
`vertical_extinction_coefficient` is the first-date `EXBEAM` value evaluated
at zenith zero, matching `INPUTUSSTR`.
"""
struct UnderstoreyStructureConfig{T<:AbstractFloat}
    source::String
    origin_m::NTuple{2,T}
    upper_corner_m::NTuple{2,T}
    ground_area_m2::T
    patches::Vector{UnderstoreyPatchRecord{T}}
    trajectories::UnderstoreyTrajectories{T}
    leaf_angles::LeafAngleDistribution{T}
    vertical_extinction_coefficient::T
end

"""Common dispatch root for the two historical C3 stomatal closures."""
abstract type AbstractUnderstoreyStomatalParameters{T<:AbstractFloat} end

"""Whole-patch Ball--Berry parameters used after the BEWDY assimilation step."""
struct UnderstoreyBallBerryParameters{T<:AbstractFloat} <:
       AbstractUnderstoreyStomatalParameters{T}
    intercept_mol_co2_m2_ground_s::T
    slope::T
end

"""Prescribed `Ci/Ca` closure used by the historical understorey model."""
struct UnderstoreyCiRatioParameters{T<:AbstractFloat} <:
       AbstractUnderstoreyStomatalParameters{T}
    ratio::T
end

"""
Parameters of the C3 `BEWDYPARMS -> BEWDY` branch.

`jmax25_per_leaf_nitrogen` and `vcmax25_per_leaf_nitrogen` retain the legacy
`JMAX25`/`VCMAX25` contract: the temperature-adjusted values are multiplied by
top-minus-minimum leaf nitrogen inside BEWDY. The optional respiration fields
are kept as input provenance; V1 uses the historical unadjusted `RD` value.
"""
struct UnderstoreyC3Physiology{
    T<:AbstractFloat,
    S<:AbstractUnderstoreyStomatalParameters{T},
}
    jmax25_per_leaf_nitrogen::T
    vcmax25_per_leaf_nitrogen::T
    minimum_leaf_nitrogen_g_m2::T
    par_absorptance::T
    ieco::Int
    jmax_activation_energy_j_mol::T
    jmax_deactivation_energy_j_mol::T
    jmax_entropy_j_mol_k::T
    vcmax_activation_energy_j_mol::T
    vcmax_deactivation_energy_j_mol::T
    vcmax_entropy_j_mol_k::T
    low_temperature_ramp_upper_c::T
    low_temperature_ramp_lower_c::T
    quantum_yield::T
    stomatal::S
    respiration_umol_co2_m2_ground_s::T
    respiration_temperature_coefficient_c_inverse::T
    respiration_reference_temperature_c::T
    specific_leaf_area_m2_kg::Union{Nothing,T}
    growth_respiration_efficiency::T
end

"""
Direct photosynthetic capacities of the historical `MOSSPARS` branch.

Unlike the C3 BEWDY capacities, `jmax25_umol_electron_m2_s` and
`vcmax25_umol_co2_m2_s` are not scaled by leaf nitrogen. The common
`JMAXPARS` and `VCMAXPARS` groups still define their temperature responses.
"""
struct UnderstoreyMossPhysiology{T<:AbstractFloat}
    jmax25_umol_electron_m2_s::T
    vcmax25_umol_co2_m2_s::T
    electron_transport_curvature::T

    function UnderstoreyMossPhysiology{T}(
        jmax25_umol_electron_m2_s::T,
        vcmax25_umol_co2_m2_s::T,
        electron_transport_curvature::T,
    ) where {T<:AbstractFloat}
        all(
            isfinite,
            (
                jmax25_umol_electron_m2_s,
                vcmax25_umol_co2_m2_s,
                electron_transport_curvature,
            ),
        ) || throw(ArgumentError("understorey moss parameters must be finite"))
        jmax25_umol_electron_m2_s >= zero(T) || throw(
            DomainError(
                jmax25_umol_electron_m2_s,
                "understorey moss JMAX25 must be non-negative",
            ),
        )
        vcmax25_umol_co2_m2_s >= zero(T) || throw(
            DomainError(
                vcmax25_umol_co2_m2_s,
                "understorey moss VCMAX25 must be non-negative",
            ),
        )
        zero(T) <= electron_transport_curvature <= one(T) || throw(
            DomainError(
                electron_transport_curvature,
                "understorey moss THETA must lie between zero and one",
            ),
        )
        return new{T}(
            jmax25_umol_electron_m2_s,
            vcmax25_umol_co2_m2_s,
            electron_transport_curvature,
        )
    end
end

function UnderstoreyMossPhysiology(
    jmax25_umol_electron_m2_s::Real,
    vcmax25_umol_co2_m2_s::Real,
    electron_transport_curvature::Real,
)
    values = (
        jmax25_umol_electron_m2_s,
        vcmax25_umol_co2_m2_s,
        electron_transport_curvature,
    )
    any(value -> value isa Bool, values) && throw(
        ArgumentError("understorey moss parameters must be numeric, not Bool"),
    )
    T = promote_type(map(value -> typeof(float(value)), values)...)
    isconcretetype(T) && T <: AbstractFloat || throw(
        ArgumentError("understorey moss parameters must promote to a concrete float"),
    )
    return UnderstoreyMossPhysiology{T}(map(value -> convert(T, value), values)...)
end

"""Parameters of the historical understorey Collatz C4 branch."""
struct UnderstoreyC4Physiology{T<:AbstractFloat}
    vcmax25_umol_co2_m2_s::T
    low_temperature_ramp_upper_c::T
    low_temperature_ramp_lower_c::T
    vcmax_entropy_j_mol_k::T
    vcmax_activation_energy_j_mol::T
    vcmax_deactivation_energy_j_mol::T
    ci_to_ca_ratio::T

    function UnderstoreyC4Physiology{T}(
        vcmax25_umol_co2_m2_s::T,
        low_temperature_ramp_upper_c::T,
        low_temperature_ramp_lower_c::T,
        vcmax_entropy_j_mol_k::T,
        vcmax_activation_energy_j_mol::T,
        vcmax_deactivation_energy_j_mol::T,
        ci_to_ca_ratio::T,
    ) where {T<:AbstractFloat}
        values = (
            vcmax25_umol_co2_m2_s,
            low_temperature_ramp_upper_c,
            low_temperature_ramp_lower_c,
            vcmax_entropy_j_mol_k,
            vcmax_activation_energy_j_mol,
            vcmax_deactivation_energy_j_mol,
            ci_to_ca_ratio,
        )
        all(isfinite, values) || throw(
            ArgumentError("understorey C4 parameters must be finite"),
        )
        vcmax25_umol_co2_m2_s >= zero(T) || throw(
            DomainError(
                vcmax25_umol_co2_m2_s,
                "understorey C4 VCMAXC4 must be non-negative",
            ),
        )
        low_temperature_ramp_upper_c >= low_temperature_ramp_lower_c || throw(
            ArgumentError(
                "understorey C4 TVJUPC4 must be greater than or equal to TVJDNC4",
            ),
        )
        zero(T) <= ci_to_ca_ratio < one(T) || throw(
            DomainError(
                ci_to_ca_ratio,
                "understorey C4 CICAC4 must lie in [0, 1)",
            ),
        )
        return new{T}(values...)
    end
end

function UnderstoreyC4Physiology(
    vcmax25_umol_co2_m2_s::Real,
    low_temperature_ramp_upper_c::Real,
    low_temperature_ramp_lower_c::Real,
    vcmax_entropy_j_mol_k::Real,
    vcmax_activation_energy_j_mol::Real,
    vcmax_deactivation_energy_j_mol::Real,
    ci_to_ca_ratio::Real,
)
    values = (
        vcmax25_umol_co2_m2_s,
        low_temperature_ramp_upper_c,
        low_temperature_ramp_lower_c,
        vcmax_entropy_j_mol_k,
        vcmax_activation_energy_j_mol,
        vcmax_deactivation_energy_j_mol,
        ci_to_ca_ratio,
    )
    any(value -> value isa Bool, values) && throw(
        ArgumentError("understorey C4 parameters must be numeric, not Bool"),
    )
    T = promote_type(map(value -> typeof(float(value)), values)...)
    isconcretetype(T) && T <: AbstractFloat || throw(
        ArgumentError("understorey C4 parameters must promote to a concrete float"),
    )
    return UnderstoreyC4Physiology{T}(map(value -> convert(T, value), values)...)
end

"""
Physiological choices read from `NNNN_ustorey.dat`.

`moss` is `nothing` when `MOSSPARS` is absent and `c4` is `nothing` when
`C4FRAC` is zero. When both moss and a positive C4 fraction are present, both
parameter blocks are parsed as in the legacy reader, then moss takes precedence
in the process specification.
"""
struct UnderstoreyPhysiologyConfig{
    T<:AbstractFloat,
    S<:AbstractUnderstoreyStomatalParameters{T},
}
    c3::UnderstoreyC3Physiology{T,S}
    moss::Union{Nothing,UnderstoreyMossPhysiology{T}}
    c4::Union{Nothing,UnderstoreyC4Physiology{T}}
    c4_fraction::T
end

"""Complete typed configuration read from one historical understorey file."""
struct UnderstoreyConfig{
    T<:AbstractFloat,
    S<:AbstractUnderstoreyStomatalParameters{T},
}
    source::String
    structure::UnderstoreyStructureConfig{T}
    physiology::UnderstoreyPhysiologyConfig{T,S}
end

@inline function _understorey_finite(value::T, name::Symbol) where {T}
    isfinite(value) || throw(ArgumentError("$(uppercase(String(name))) must be finite"))
    return value
end

@inline function _understorey_nonnegative(value::T, name::Symbol) where {T}
    value >= zero(T) || throw(
        DomainError(value, "$(uppercase(String(name))) must be non-negative"),
    )
    return value
end

@inline function _understorey_positive(value::T, name::Symbol) where {T}
    value > zero(T) || throw(
        DomainError(value, "$(uppercase(String(name))) must be positive"),
    )
    return value
end

function _understorey_real(
    group::NamelistGroup,
    name::Symbol,
    ::Type{T};
    default=_NO_NAMELIST_DEFAULT,
) where {T<:AbstractFloat}
    return _understorey_finite(
        _real_value(group, name, T; default=default),
        name,
    )
end

function _understorey_patch_records(
    point_count::Int,
    origin::NTuple{2,T},
    upper_corner::NTuple{2,T},
) where {T<:AbstractFloat}
    point_count > 0 || throw(ArgumentError("CONTROL.NOUSPOINTS must be positive"))
    width = upper_corner[1] - origin[1]
    height = upper_corner[2] - origin[2]
    width > zero(T) || throw(
        ArgumentError("understorey XMAX must be greater than X0"),
    )
    height > zero(T) || throw(
        ArgumentError("understorey YMAX must be greater than Y0"),
    )
    area = width * height
    patch_area = area / T(point_count)
    spacing = sqrt(patch_area)
    points_on_y = floor(Int, sqrt(T(point_count)))
    points_on_y > 0 || throw(ArgumentError("understorey grid is empty"))
    patches = Vector{UnderstoreyPatchRecord{T}}(undef, point_count)
    for patch_id in 1:point_count
        offset = patch_id - 1
        x = origin[1] + T(div(offset, points_on_y)) * spacing
        y = origin[2] + T(mod(offset, points_on_y)) * spacing
        patches[patch_id] = UnderstoreyPatchRecord{T}(
            patch_id,
            (x, y),
            patch_area,
        )
    end
    return patches, area
end

function _understorey_table(
    document::NamelistDocument,
    individual_group::Symbol,
    common_group::Symbol,
    point_count::Int,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    return _legacy_tree_table(
        document,
        individual_group,
        common_group,
        point_count,
        mode,
        T,
    )
end

function read_understorey_structure(
    document::NamelistDocument;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
)
    _check_input_mode(mode)
    isconcretetype(T) || throw(ArgumentError("T must be a concrete floating-point type"))
    control = _config_group(document, :control, mode)
    point_count = _integer_value(control, :nouspoints)
    point_count > 0 || throw(ArgumentError("CONTROL.NOUSPOINTS must be positive"))
    x0 = _understorey_real(control, :x0, T; default=zero(T))
    y0 = _understorey_real(control, :y0, T; default=zero(T))
    xmax = _understorey_real(control, :xmax, T)
    ymax = _understorey_real(control, :ymax, T)
    patches, ground_area = _understorey_patch_records(
        point_count,
        (x0, y0),
        (xmax, ymax),
    )

    trajectories = UnderstoreyTrajectories{T}(
        _understorey_table(
            document,
            :indivhtcrown,
            :allhtcrown,
            point_count,
            mode,
            T,
        ),
        _understorey_table(
            document,
            :indivuslai,
            :alluslai,
            point_count,
            mode,
            T,
        ),
        _understorey_table(
            document,
            :indivfoln,
            :allfoln,
            point_count,
            mode,
            T,
        ),
    )
    leaf_angles = _read_leaf_angle_distribution(document, mode, T)
    vertical_extinction = beam_extinction(
        leaf_angles.angles_rad,
        view(leaf_angles.fractions, :, 1),
        one(T),
        zero(T),
    ).coefficient
    _understorey_positive(vertical_extinction, :vertical_extinction_coefficient)

    return UnderstoreyStructureConfig{T}(
        document.source,
        (x0, y0),
        (xmax, ymax),
        ground_area,
        patches,
        trajectories,
        leaf_angles,
        vertical_extinction,
    )
end

function _understorey_stomatal_parameters(
    document::NamelistDocument,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    cica = _optional_namelist_group(document, :cica)
    if !isnothing(cica)
        ratio = _understorey_real(cica, :cicarat, T)
        zero(T) < ratio < one(T) || throw(
            DomainError(ratio, "CICA.CICARAT must lie strictly between zero and one"),
        )
        return UnderstoreyCiRatioParameters{T}(ratio)
    end
    bbgs = _config_group(document, :bbgs, mode)
    g0 = _understorey_nonnegative(
        _understorey_real(bbgs, :g0, T),
        :g0,
    )
    g1 = _understorey_positive(
        _understorey_real(bbgs, :g1, T),
        :g1,
    )
    return UnderstoreyBallBerryParameters{T}(g0, g1)
end

function _understorey_moss_physiology(
    document::NamelistDocument,
    ::Type{T},
) where {T<:AbstractFloat}
    group = _optional_namelist_group(document, :mosspars)
    isnothing(group) && return nothing

    jmax25 = _understorey_nonnegative(
        _understorey_real(group, :jmax25, T),
        :jmax25,
    )
    vcmax25 = _understorey_nonnegative(
        _understorey_real(group, :vcmax25, T),
        :vcmax25,
    )
    curvature = _understorey_real(group, :theta, T)
    zero(T) <= curvature <= one(T) || throw(
        DomainError(curvature, "MOSSPARS.THETA must lie between zero and one"),
    )
    return UnderstoreyMossPhysiology{T}(jmax25, vcmax25, curvature)
end

function _understorey_c4_physiology(
    document::NamelistDocument,
    c4_fraction::T,
    mode::Symbol,
    ::Type{T},
) where {T<:AbstractFloat}
    iszero(c4_fraction) && return nothing
    group = _config_group(document, :usc4pars, mode)
    vcmax25 = _understorey_nonnegative(
        _understorey_real(group, :vcmaxc4, T),
        :vcmaxc4,
    )
    ramp_upper = _understorey_real(group, :tvjupc4, T; default=T(-100))
    ramp_lower = _understorey_real(group, :tvjdnc4, T; default=T(-100))
    ramp_upper >= ramp_lower || throw(
        ArgumentError("USC4PARS.TVJUPC4 must be greater than or equal to TVJDNC4"),
    )
    entropy = _understorey_real(group, :delscc4, T; default=zero(T))
    activation = _understorey_real(group, :eavcc4, T)
    deactivation = _understorey_real(group, :edvcc4, T)
    ci_to_ca_ratio = _understorey_real(group, :cicac4, T; default=T(0.7))
    zero(T) <= ci_to_ca_ratio < one(T) || throw(
        DomainError(
            ci_to_ca_ratio,
            "USC4PARS.CICAC4 must lie in [0, 1)",
        ),
    )
    return UnderstoreyC4Physiology{T}(
        vcmax25,
        ramp_upper,
        ramp_lower,
        entropy,
        activation,
        deactivation,
        ci_to_ca_ratio,
    )
end

function read_understorey_physiology(
    document::NamelistDocument;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
)
    _check_input_mode(mode)
    isconcretetype(T) || throw(ArgumentError("T must be a concrete floating-point type"))
    bewdy = _config_group(document, :bewdypars, mode)
    jmax = _config_group(document, :jmaxpars, mode)
    vcmax = _config_group(document, :vcmaxpars, mode)

    jmax25 = _understorey_nonnegative(
        _understorey_real(bewdy, :jmax25, T),
        :jmax25,
    )
    vcmax25 = _understorey_nonnegative(
        _understorey_real(bewdy, :vcmax25, T),
        :vcmax25,
    )
    minimum_nitrogen = _understorey_nonnegative(
        _understorey_real(bewdy, :unmin, T),
        :unmin,
    )
    absorptance = _understorey_real(bewdy, :absrp, T)
    zero(T) <= absorptance <= one(T) || throw(
        DomainError(absorptance, "BEWDYPARS.ABSRP must lie between zero and one"),
    )

    ieco = _integer_value(jmax, :ieco; default=1)
    ieco in (0, 1) || throw(ArgumentError("JMAXPARS.IECO must be 0 or 1"))
    eavj = _understorey_real(jmax, :eavj, T)
    edvj = _understorey_real(jmax, :edvj, T)
    delsj = _understorey_real(jmax, :delsj, T)
    quantum_yield = _understorey_positive(
        _understorey_real(jmax, :ajq, T; default=T(0.425)),
        :ajq,
    )
    eavc = _understorey_real(vcmax, :eavc, T)
    edvc = _understorey_real(vcmax, :edvc, T; default=zero(T))
    delsc = _understorey_real(vcmax, :delsc, T; default=zero(T))
    ramp_upper = _understorey_real(vcmax, :tvjup, T; default=T(-100))
    ramp_lower = _understorey_real(vcmax, :tvjdn, T; default=T(-100))
    ramp_upper >= ramp_lower || throw(
        ArgumentError("VCMAXPARS.TVJUP must be greater than or equal to TVJDN"),
    )

    respiration = _optional_namelist_group(document, :rdpars)
    rd = isnothing(respiration) ? zero(T) : _understorey_nonnegative(
        _understorey_real(respiration, :rd, T; default=zero(T)),
        :rd,
    )
    rdk = isnothing(respiration) ? zero(T) : _understorey_real(
        respiration,
        :rdk,
        T;
        default=zero(T),
    )
    rdt = isnothing(respiration) ? zero(T) : _understorey_real(
        respiration,
        :rdt,
        T;
        default=zero(T),
    )
    sla_value = isnothing(respiration) ? T(-1) : _understorey_real(
        respiration,
        :sla,
        T;
        default=T(-1),
    )
    sla = sla_value > zero(T) ? sla_value : nothing
    efficiency = isnothing(respiration) ? zero(T) : _understorey_real(
        respiration,
        :effy,
        T;
        default=zero(T),
    )
    zero(T) <= efficiency <= one(T) || throw(
        DomainError(efficiency, "RDPARS.EFFY must lie between zero and one"),
    )

    phycon = _optional_namelist_group(document, :phycon)
    c4_fraction = isnothing(phycon) ? zero(T) : _understorey_real(
        phycon,
        :c4frac,
        T;
        default=zero(T),
    )
    zero(T) <= c4_fraction <= one(T) || throw(
        DomainError(c4_fraction, "PHYCON.C4FRAC must lie between zero and one"),
    )
    moss = _understorey_moss_physiology(document, T)
    c4 = _understorey_c4_physiology(document, c4_fraction, mode, T)

    stomatal = _understorey_stomatal_parameters(document, mode, T)
    c3 = UnderstoreyC3Physiology{T,typeof(stomatal)}(
        jmax25,
        vcmax25,
        minimum_nitrogen,
        absorptance,
        ieco,
        eavj,
        edvj,
        delsj,
        eavc,
        edvc,
        delsc,
        ramp_upper,
        ramp_lower,
        quantum_yield,
        stomatal,
        rd,
        rdk,
        rdt,
        sla,
        efficiency,
    )
    return UnderstoreyPhysiologyConfig{T,typeof(stomatal)}(
        c3,
        moss,
        c4,
        c4_fraction,
    )
end

function read_understorey_config(
    document::NamelistDocument;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
)
    structure = read_understorey_structure(document; mode=mode, T=T)
    physiology = read_understorey_physiology(document; mode=mode, T=T)
    return UnderstoreyConfig{T,typeof(physiology.c3.stomatal)}(
        document.source,
        structure,
        physiology,
    )
end

"""Read and type one historical `NNNN_ustorey.dat` file."""
function read_understorey_config(
    path::AbstractString;
    mode::Symbol=:legacy,
    T::Type{<:AbstractFloat}=Float32,
)
    return read_understorey_config(
        read_namelist(path; mode=mode);
        mode=mode,
        T=T,
    )
end
