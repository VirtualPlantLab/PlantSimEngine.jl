"""
    WatsoiltProfilePlan

Validated pre-run snapshot for the historical soil-temperature record boundary.
The final physical heat profile, heat availability/convergence, current SOILTK
boundary and its availability are distinct exact publishers. `manifest` includes
the gates themselves, so their native clocks and datetime labels can be checked.
The optional surface convergence stream is solver evidence, not availability.
"""
struct WatsoiltProfilePlan{Q,G,C,S,B,D,L,I,O,P,K,A}
    quantity::Q
    gate::G
    convergence::C
    surface::S
    surface_gate::B
    surface_convergence::D
    layer_ids::L
    layer_indices::I
    source_layer_ids::O
    profile_positions::P
    kelvin_offset::K
    surface_mode::Symbol
    manifest::Tuple
    availability::A
    function WatsoiltProfilePlan(::Val{:validated}, quantity, gate, convergence,
        surface, surface_gate, surface_convergence, layer_ids::Tuple,
        layer_indices::Tuple, source_layer_ids::Tuple, profile_positions::Tuple,
        kelvin_offset, surface_mode::Symbol, availability::Tuple)
        manifest = isnothing(surface_convergence) ?
            (quantity, gate, convergence, surface, surface_gate) :
            (quantity, gate, convergence, surface, surface_gate, surface_convergence)
        offset_snapshot = deepcopy(kelvin_offset)
        return new{typeof(quantity),typeof(gate),typeof(convergence),typeof(surface),
            typeof(surface_gate),typeof(surface_convergence),typeof(layer_ids),
            typeof(layer_indices),typeof(source_layer_ids),typeof(profile_positions),
            typeof(offset_snapshot),typeof(availability)}(quantity, gate, convergence,
                surface, surface_gate, surface_convergence, layer_ids, layer_indices,
                source_layer_ids, profile_positions, offset_snapshot, surface_mode,
                manifest, availability)
    end
end

function _watsoilt_publisher(model, application)
    mounted = filter(row -> row.application_id === application,
        PlantSimEngine.Diagnostics.explain_applications(model))
    length(mounted) == 1 || throw(ArgumentError("watsoilt needs one exact application $application"))
    only(mounted).model_storage === :shared_application || throw(ArgumentError(
        "watsoilt does not yet support per-object publisher overrides",
    ))
    declaration = model.applications[only(mounted).application_slot]
    return declaration isa PlantSimEngine.ModelSpec ? declaration.model : declaration
end

function _watsoilt_entry(model, application, object, variable, contract)
    rows = maespa_output_manifest(model; variables=variable,
        applications=application, on=PlantSimEngine.One(id=object.id))
    length(rows) == 1 || throw(ArgumentError("watsoilt needs one exact $variable publisher"))
    row = only(rows)
    row.contract == contract || throw(ArgumentError("watsoilt $variable has an incompatible contract"))
    row.output_role === :local && isequal(row.object_id, object.id.value) &&
        isequal(row.source_object_id, object.id.value) || throw(ArgumentError(
            "watsoilt $variable must be local to the selected Soil",
        ))
    return deepcopy(row)
end

function _watsoilt_surface_binding(model, application, soil, interface)
    haskey(interface.inputs, :soil_heat_surface_boundary_temperature_k) || return nothing
    bindings = filter(row -> row.application_id === application &&
        isequal(row.consumer_id, soil.id.value) &&
        row.input === :soil_heat_surface_boundary_temperature_k,
        PlantSimEngine.Diagnostics.explain_bindings(model))
    length(bindings) == 1 || throw(ArgumentError(
        "watsoilt requires an exact current SOILTK value binding, not status or a previous seed",
    ))
    binding = only(bindings)
    !binding.breaks_same_step_cycle &&
        (isnothing(binding.policy) || binding.policy isa PlantSimEngine.HoldLast) &&
        length(binding.source_ids) == length(binding.source_application_ids) == 1 ||
        throw(ArgumentError("watsoilt SOILTK binding must name one same-step source without resampling"))
    return binding
end

"""
    maespa_watsoilt_plan(model; application=:soil_heat_transfer,
        on=PlantSimEngine.One(scale=:Soil), surface_application=nothing,
        surface_variable=nothing, surface_gate_variable=nothing,
        surface_convergence_variable=nothing, profile_layer_order=nothing,
        kelvin_offset=273.15)

Capture the final physical Kelvin profile and current heat upper boundary before
running a scenario. Native heat publishes in explicit `layer_index=1:n` order;
compatible alternatives must name the stable SoilLayer IDs at every vector
position with `profile_layer_order`. The subtree must have complete unique
integer indices and match the declared vector dimension.

Automatic surface selection follows only the exact same-step heat input edge to
the known simulated surface solver or the active prescribed forcing adapter.
Inactive prescribed placeholders, radiative TSOILSURFACE and persistent seeds
are not SOILTK. An alternative boundary publisher needs explicit application,
quantity and gate names; when the heat input exists it must match that edge.
The engine's default `HoldLast` carrier is allowed only with equal native source
clocks and a non-cycle current edge. Projection still requires actual retained
source quantities and gates at the exact step/datetime: no held observation is
created, and a previous-step, interpolated or aggregated binding is rejected.

Retain every entry in `plan.manifest`, collect using `plan.availability`, and
project those rows. Heat convergence (and simulated surface convergence) may be
false while the corresponding evaluation is available. A prescribed adapter has
no solver: its no-attempt metadata is configuration evidence, not a fabricated
observed flag. The offset is copied without changing its type, so later mutation
of the supplied number does not alter the plan. Kelvin-to-Celsius subtraction is
deferred to the IO boundary.
"""
function maespa_watsoilt_plan(model::PlantSimEngine.CompositeModel;
    application=:soil_heat_transfer, on=PlantSimEngine.One(scale=:Soil),
    surface_application=nothing, surface_variable=nothing,
    surface_gate_variable=nothing, surface_convergence_variable=nothing,
    profile_layer_order=nothing, kelvin_offset=273.15)
    application isa Symbol || throw(ArgumentError("application must be a Symbol"))
    all(value -> isnothing(value) || value isa Symbol,
        (surface_application, surface_variable, surface_gate_variable,
            surface_convergence_variable)) || throw(ArgumentError(
                "surface publisher names must be Symbols or nothing",
            ))
    kelvin_offset isa Real && !(kelvin_offset isa Bool) && isfinite(kelvin_offset) ||
        throw(ArgumentError("kelvin_offset must be a finite real number, not Bool"))
    objects = PlantSimEngine.resolve_objects(model, on)
    length(objects) == 1 || throw(ArgumentError("watsoilt needs exactly one selected Soil object"))
    soil = only(objects)
    soil.scale === :Soil || throw(ArgumentError("watsoilt publisher must be on a Soil object"))
    publisher = _watsoilt_publisher(model, application)
    interface = PlantSimEngine.Authoring.model_interface(publisher)
    quantity = _watsoilt_entry(model, application, soil, :soil_layer_temperatures_k,
        SOIL_PROFILE_NODE_TEMPERATURE_CONTRACT)
    gate = _watsoilt_entry(model, application, soil, :soil_heat_transfer_available,
        SOIL_HEAT_TRANSFER_AVAILABLE_CONTRACT)
    convergence = _watsoilt_entry(model, application, soil, :soil_heat_transfer_converged,
        SOIL_HEAT_DIFFUSION_CONVERGED_CONTRACT)
    all(row -> isequal(row.source_clock, quantity.source_clock), (gate, convergence)) ||
        throw(ArgumentError("watsoilt heat profile, gate and convergence must share a source clock"))
    profile = interface.outputs.soil_layer_temperatures_k
    profile isa AbstractVector && !isempty(profile) || throw(ArgumentError(
        "watsoilt publisher must declare a nonempty final physical vector",
    ))
    Base.require_one_based_indexing(profile)
    interface.outputs.soil_heat_transfer_available isa Bool &&
        interface.outputs.soil_heat_transfer_converged isa Bool || throw(ArgumentError(
            "watsoilt heat availability and convergence must be declared scalar Bool values",
        ))
    count = length(profile)
    layers = PlantSimEngine.resolve_objects(model, PlantSimEngine.Many(
        scale=:SoilLayer, within=PlantSimEngine.Scope(soil.id)))
    length(layers) == count || throw(ArgumentError(
        "watsoilt physical SoilLayer coverage must match the configured profile dimension",
    ))
    indexed = map(layers) do layer
        index = _maespa_manifest_scalar(PlantSimEngine.model_status(model, layer.id), :layer_index)
        index isa Integer && !(index isa Bool) || throw(ArgumentError(
            "watsoilt SoilLayer identities need explicit integer layer_index metadata",
        ))
        return (id=layer.id, index)
    end
    sort!(indexed; by=layer -> layer.index)
    [layer.index for layer in indexed] == collect(1:count) || throw(ArgumentError(
        "watsoilt layer_index metadata must contain 1:$count exactly once",
    ))
    ids, indices = Tuple(layer.id.value for layer in indexed), Tuple(layer.index for layer in indexed)
    source_ids = if publisher isa MAESPASoilHeatTransfer
        if !isnothing(profile_layer_order)
            isequal(_watlay_explicit_layer_order(profile_layer_order, ids), ids) ||
                throw(ArgumentError("native heat publishes in layer_index order, not the supplied order"))
        end
        ids
    else
        isnothing(profile_layer_order) && throw(ArgumentError(
            "an alternative watsoilt publisher requires explicit profile_layer_order stable IDs",
        ))
        _watlay_explicit_layer_order(profile_layer_order, ids)
    end
    positions = Tuple(only(findall(source -> isequal(source, id), source_ids)) for id in ids)

    binding = _watsoilt_surface_binding(model, application, soil, interface)
    automatic_surface = isnothing(surface_application)
    if isnothing(surface_application)
        isnothing(binding) && throw(ArgumentError("automatic watsoilt surface discovery requires the heat input edge"))
        surface_application = only(binding.source_application_ids)
    end
    boundary_publisher = _watsoilt_publisher(model, surface_application)
    surface_mode = if boundary_publisher isa MAESPASoilSurfaceEnergyBalance
        surface_variable = isnothing(surface_variable) ? :soil_temperature_k : surface_variable
        surface_gate_variable = isnothing(surface_gate_variable) ? :soil_surface_energy_available : surface_gate_variable
        surface_convergence_variable = isnothing(surface_convergence_variable) ?
            :soil_surface_energy_converged : surface_convergence_variable
        (surface_variable, surface_gate_variable, surface_convergence_variable) ==
            (:soil_temperature_k, :soil_surface_energy_available, :soil_surface_energy_converged) ||
            throw(ArgumentError("native simulated SOILTK requires its exact availability and convergence ports"))
        :simulated
    elseif boundary_publisher isa MAESPASoilSurfaceEnergyForcing
        boundary_publisher.simulate_soil_temperature && throw(ArgumentError(
            "the simulated-temperature forcing port is an inactive prescribed placeholder, not SOILTK",
        ))
        surface_variable = isnothing(surface_variable) ? :soil_energy_prescribed_temperature_k : surface_variable
        surface_gate_variable = isnothing(surface_gate_variable) ? :soil_energy_forcing_available : surface_gate_variable
        (surface_variable, surface_gate_variable) ==
            (:soil_energy_prescribed_temperature_k, :soil_energy_forcing_available) ||
            throw(ArgumentError("native prescribed SOILTK requires the active forcing quantity and gate"))
        isnothing(surface_convergence_variable) || throw(ArgumentError(
            "a prescribed forcing adapter publishes no surface solver convergence",
        ))
        :prescribed
    else
        automatic_surface && throw(ArgumentError(
            "automatic SOILTK discovery is restricted to exact known active native producers",
        ))
        if isnothing(surface_variable) || isnothing(surface_gate_variable)
            throw(ArgumentError("an alternative SOILTK publisher needs explicit quantity and gate names"))
        end
        :explicit_compatible
    end
    surface = _watsoilt_entry(model, surface_application, soil, surface_variable,
        SOIL_HEAT_SURFACE_BOUNDARY_TEMPERATURE_CONTRACT)
    surface_gate = _watsoilt_entry(model, surface_application, soil, surface_gate_variable,
        SOIL_SURFACE_ENERGY_CONTEXT_AVAILABLE_CONTRACT)
    surface_convergence = isnothing(surface_convergence_variable) ? nothing :
        _watsoilt_entry(model, surface_application, soil, surface_convergence_variable,
            SOIL_SURFACE_ENERGY_SOLVE_CONVERGED_CONTRACT)
    surface_interface = PlantSimEngine.Authoring.model_interface(boundary_publisher)
    surface_interface.outputs[surface_variable] isa Real &&
        !(surface_interface.outputs[surface_variable] isa Bool) &&
        surface_interface.outputs[surface_gate_variable] isa Bool || throw(ArgumentError(
            "watsoilt SOILTK must be a scalar real temperature with a scalar Bool gate",
        ))
    isnothing(surface_convergence) || surface_interface.outputs[surface_convergence_variable] isa Bool ||
        throw(ArgumentError("watsoilt surface convergence must be a declared scalar Bool"))
    all(row -> isequal(row.source_clock, quantity.source_clock),
        isnothing(surface_convergence) ? (surface, surface_gate) :
            (surface, surface_gate, surface_convergence)) || throw(ArgumentError(
                "watsoilt heat and SOILTK evidence must share one native source clock",
            ))
    if !isnothing(binding)
        only(binding.source_application_ids) === surface.application_id &&
            isequal(only(binding.source_ids), surface.object_id) &&
            binding.source_var === surface.variable || throw(ArgumentError(
                "selected watsoilt SOILTK publisher does not match the exact heat input edge",
            ))
    end
    availability = (
        (application, quantity.variable) =>
            (application=application, variable=gate.variable, object=:source),
        (application, convergence.variable) =>
            (application=application, variable=gate.variable, object=:source),
        (surface_application, surface.variable) =>
            (application=surface_application, variable=surface_gate.variable, object=:source),
    )
    if !isnothing(surface_convergence)
        availability = (availability..., (surface_application, surface_convergence.variable) =>
            (application=surface_application, variable=surface_gate.variable, object=:source))
    end
    return WatsoiltProfilePlan(Val(:validated), quantity, gate, convergence,
        surface, surface_gate, surface_convergence, deepcopy(ids), indices,
        deepcopy(source_ids), positions, kelvin_offset, surface_mode, availability)
end

function _watsoilt_profile_values(value, count)
    value isa AbstractVector && length(value) == count || throw(ArgumentError(
        "watsoilt needs one complete vector with $count physical-node temperatures",
    ))
    Base.require_one_based_indexing(value)
    all(number -> number isa Real && !(number isa Bool) && isfinite(number), value) ||
        throw(ArgumentError("watsoilt temperatures must be finite real numbers, not Bool"))
    return value
end

function _watsoilt_project_sample(plan, quantity, gate, convergence, surface,
    surface_gate, surface_convergence; detach_plan=true)
    _legacy_profile_observation(quantity, plan.quantity; family=:watsoilt)
    _legacy_profile_observation(gate, plan.gate; family=:watsoilt)
    _legacy_profile_observation(convergence, plan.convergence; family=:watsoilt)
    _legacy_profile_observation(surface, plan.surface; family=:watsoilt)
    _legacy_profile_observation(surface_gate, plan.surface_gate; family=:watsoilt)
    _legacy_profile_available(quantity, gate; family=:watsoilt)
    _legacy_profile_available(convergence, gate; family=:watsoilt)
    _legacy_profile_available(surface, surface_gate; family=:watsoilt)
    _legacy_profile_same_sample(quantity, convergence; family=:watsoilt)
    _legacy_profile_same_sample(quantity, surface; family=:watsoilt)
    convergence.value isa Bool || throw(ArgumentError("watsoilt heat convergence must be scalar Bool"))
    surface.value isa Real && !(surface.value isa Bool) && isfinite(surface.value) ||
        throw(ArgumentError("watsoilt current SOILTK must be a finite scalar real number"))
    if isnothing(plan.surface_convergence)
        isnothing(surface_convergence) || throw(ArgumentError("unexpected watsoilt surface convergence evidence"))
    else
        _legacy_profile_observation(surface_convergence, plan.surface_convergence; family=:watsoilt)
        _legacy_profile_available(surface_convergence, surface_gate; family=:watsoilt)
        _legacy_profile_same_sample(quantity, surface_convergence; family=:watsoilt)
        surface_convergence.value isa Bool || throw(ArgumentError("watsoilt surface convergence must be scalar Bool"))
    end
    _watsoilt_profile_values(quantity.value, length(plan.layer_ids))
    physical = quantity.value[collect(plan.profile_positions)]
    # Each record owns its historical configuration. The public offset is a
    # separate copy so tampering cannot silently alter its captured evidence.
    captured_plan = detach_plan ? deepcopy(plan) : plan
    return merge(deepcopy(quantity), (
        family=:watsoilt, projection_plan=captured_plan,
        layer_ids=deepcopy(plan.layer_ids), layer_indices=plan.layer_indices,
        source_layer_ids=deepcopy(plan.source_layer_ids),
        source_profile_positions=plan.profile_positions,
        phase=:accepted_post_water_heat_transfer, encoding_phase=:unencoded,
        ascii_grid=:physical_profile_nodes, binary_grid=:surface_then_profile_without_deepest,
        kelvin_offset=deepcopy(captured_plan.kelvin_offset), value=deepcopy(physical),
        boundary_value_k=deepcopy(surface.value),
        heat_converged=convergence.value, heat_convergence_provenance=:same_step_snapshot,
        surface_mode=plan.surface_mode,
        surface_solve=plan.surface_mode === :prescribed ? :not_attempted_prescribed :
            plan.surface_mode === :simulated ? :bounded_solver : :unspecified_compatible_publisher,
        surface_solve_provenance=:model_configuration,
        surface_converged=isnothing(surface_convergence) ? missing : surface_convergence.value,
        surface_convergence_provenance=isnothing(surface_convergence) ? :not_published : :same_step_snapshot,
        quantity_sample=deepcopy(quantity), heat_availability_sample=deepcopy(gate),
        heat_convergence_sample=deepcopy(convergence), boundary_sample=deepcopy(surface),
        boundary_availability_sample=deepcopy(surface_gate),
        surface_convergence_sample=deepcopy(surface_convergence),
    ))
end

"""
    project_legacy_profile(rows, plan::WatsoiltProfilePlan; family=:watsoilt)

Join the complete retained manifest by exact source identity and native step.
Every profile requires same-step/clock/datetime heat availability, independent
Boolean convergence, active SOILTK and its own availability. False convergence
is preserved; missing/false availability and incomplete histories are errors.
Returned physical values and boundary values remain Kelvin in their original
numeric types. ASCII and binary grid selection and Celsius conversion occur
only when writing. Each record owns detached copies of its plan, offset and
native evidence; changing the caller's plan or another record cannot relabel it.
Projection never runs a model or reads current/final state.
"""
function project_legacy_profile(rows, plan::WatsoiltProfilePlan; family=:watsoilt)
    family === :watsoilt || throw(ArgumentError("legacy profile family $(repr(family)) is not implemented by this plan"))
    expected = Dict(_legacy_profile_source_key(entry) => entry for entry in plan.manifest)
    streams = Dict(key => Dict{Any,Any}() for key in keys(expected))
    for row in rows
        row isa NamedTuple && all(name -> haskey(row, name), (:application_id, :object_id, :variable)) ||
            throw(ArgumentError("watsoilt requires collected rows with exact publisher identities"))
        key = _legacy_profile_source_key(row)
        haskey(expected, key) || throw(ArgumentError("unexpected watsoilt source identity $key"))
        _legacy_profile_observation(row, expected[key]; family=:watsoilt)
        haskey(streams[key], row.timestep) && throw(ArgumentError("duplicate watsoilt source sample at timestep $(row.timestep)"))
        streams[key][row.timestep] = row
    end
    steps = Set(keys(streams[_legacy_profile_source_key(plan.quantity)]))
    all(stream -> Set(keys(stream)) == steps, values(streams)) || throw(ArgumentError(
        "watsoilt requires complete matching native histories for all quantities, gates and convergence",
    ))
    records = NamedTuple[]
    sample(entry, step) = streams[_legacy_profile_source_key(entry)][step]
    for step in sort!(collect(steps))
        push!(records, _watsoilt_project_sample(plan, sample(plan.quantity, step),
            sample(plan.gate, step), sample(plan.convergence, step),
            sample(plan.surface, step), sample(plan.surface_gate, step),
            isnothing(plan.surface_convergence) ? nothing : sample(plan.surface_convergence, step)))
    end
    return records
end

function _validate_watsoilt_records(records)
    validated = NamedTuple[]
    previous = nothing
    required = (:projection_plan, :quantity_sample, :heat_availability_sample,
        :heat_convergence_sample, :boundary_sample, :boundary_availability_sample,
        :surface_convergence_sample)
    for record in records
        record isa NamedTuple && all(name -> haskey(record, name), required) &&
            record.projection_plan isa WatsoiltProfilePlan || throw(ArgumentError(
                "write_legacy_profile requires complete projected watsoilt records",
            ))
        plan = record.projection_plan
        expected = _watsoilt_project_sample(plan, record.quantity_sample,
            record.heat_availability_sample, record.heat_convergence_sample,
            record.boundary_sample, record.boundary_availability_sample,
            record.surface_convergence_sample; detach_plan=false)
        _legacy_profile_record_matches_evidence(record, expected) || throw(ArgumentError(
            "watsoilt record values or metadata differ from their captured native evidence",
        ))
        if !isnothing(previous)
            record.timestep > previous.timestep || throw(ArgumentError(
                "watsoilt records must have unique increasing native timesteps",
            ))
            prior = previous.projection_plan
            all(name -> isequal(getproperty(plan, name), getproperty(prior, name)),
                fieldnames(typeof(plan))) || throw(ArgumentError(
                    "watsoilt records cannot mix publishers, clocks, grids or conversion boundaries",
                ))
        end
        push!(validated, record)
        previous = record
    end
    return validated
end

function _watsoilt_celsius(value, offset, encoding)
    converted_offset = try
        convert(typeof(value), offset)
    catch error
        error isa Union{InexactError,OverflowError,MethodError} || rethrow()
        throw(ArgumentError("kelvin_offset is not representable in the native temperature type"))
    end
    isfinite(converted_offset) || throw(ArgumentError("kelvin_offset must remain finite in the native temperature type"))
    result = value - converted_offset
    isfinite(result) || throw(ArgumentError("Celsius conversion must remain finite"))
    return _legacy_encoded_number(result, encoding)
end

function _write_watsoilt_ascii(io, records, encoding)
    for record in records
        for first_index in 1:25:length(record.value)
            last_index = min(first_index + 24, length(record.value))
            for index in first_index:last_index
                index == first_index || write(io, ' ')
                number = _watsoilt_celsius(record.value[index], record.kelvin_offset, encoding)
                field = @sprintf("%10.2f", number)
                write(io, ncodeunits(field) > 10 ? "**********" : field)
            end
            write(io, '\n')
        end
    end
    return nothing
end

function _write_watsoilt_binary(io, records, encoding::LegacyProfileEncoding{T}) where {T}
    U = T === Float32 ? UInt32 : UInt64
    for record in records
        # Historical binary nodes 1:n are SOILTK then physical nodes 2:n;
        # ASCII nodes 2:n+1 include the deepest physical node instead.
        values = (record.boundary_value_k, record.value[1:end-1]...)
        for value in values
            bits = reinterpret(U, _watsoilt_celsius(value, record.kelvin_offset, encoding))
            for position in (encoding.byte_order === :little ? (0:(sizeof(T)-1)) : ((sizeof(T)-1):-1:0))
                write(io, UInt8((bits >> (8 * position)) & U(0xff)))
            end
        end
    end
    return nothing
end
