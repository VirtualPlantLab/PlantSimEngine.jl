"""
    legacy_output_catalogue()
    legacy_output_catalogue(id::Symbol)

Describe the 19 historical MAESPA output families without writing any files.
The zero-argument form returns an immutable tuple of immutable `NamedTuple`
records. The single-family form accepts an exact canonical lowercase ID;
for example, use `:resph`, not the binary filename stem `:resphr`.

`columns` names the actual ASCII quantities, not necessarily the labels or
units advertised by historical headers. Profile and mixed-block expressions
retain their Fortran indices; `records` explains their dimensions and order.
`ascii` uses `{plot}` for the unpadded plot number and `{plot4}` for four digits.
`binary` lists only filenames actually opened by the historical program,
including header files that remain empty. Its numerical files are native
unformatted **streams**, without sequential-record markers; native REAL kind
and byte order are compiler/platform dependent.

This is a source-backed file-format inventory, not a writer API, a variable
contract registry, or a promise of scientific equivalence. `writer_available=true`
for `:watlay`, `:swplay` and `:watsoilt` denotes explicit pure record IO, not automatic
file creation or legacy control-switch orchestration. `:watlay` has
`:record_writer` status; `:watsoilt` retains `:legacy_quirk` for its distinct
ASCII/binary grids, both implemented explicitly.
`:swplay` retains `:legacy_quirk`: only its defined ASCII record is implemented,
not the compiler-dependent implicit binary unit or invented binary filenames.
`:legacy_quirk` identifies consequential historical anomalies; `:deferred`
means no exporter is implemented. Portable synthetic writer checkpoints are
format tests, not physiological validation or a qualification of whole files.
"""
legacy_output_catalogue() = _LEGACY_OUTPUT_CATALOGUE

function legacy_output_catalogue(id::Symbol)
    for family in _LEGACY_OUTPUT_CATALOGUE
        family.id === id && return family
    end
    throw(ArgumentError(
        "unknown historical output family $(repr(id)); use an exact canonical lowercase ID",
    ))
end

# Source: historical Fortran reference 6c74d4b, inout.f90, maespa.f90,
# radn.f90 and unstor.f90. This package metadata never reads that checkout.
# Keep entries flat and all nested values immutable: callers can safely share
# this inventory without mutating a package-global dictionary or array.
const _LEGACY_OUTPUT_CATALOGUE = (
    (
        id=:dayflx, category=:scientific,
        switch="IODAILY=1 writes; IODAILY>0 opens; fixed to 1 by DEFAULT_CONDITIONS, not /CONTROL/",
        cadence=:daily, directory=:output,
        ascii="{plot}_Dayflx.dat", binary=("Dayflx.bin", "Dayflx.hdr"),
        layout=:table,
        columns=(
            :IDAY, :ITREE, :ISPEC, :TDYAB1, :TDYAB2, :TDYAB3,
            Symbol("TOTCO2+TOTRESPF"), :TOTRESPF, :TOTCO2, :TOTH2O,
            :TOTH2OCAN, :TOTHFX, :TOTH2OEV, :FOLT,
        ),
        records="One 14-value row per target slot after SUMDAILY; day=loop IDAY+1; ITREE=ITARGETS(ITAR)",
        ascii_format="(I7,1X,I4,1X,I4,1X,11(F16.6,1X))",
        binary_records="Unformatted STREAM without record markers: same 14 quantities as ASCII, IDs converted to native REAL",
        status=:legacy_quirk, writer_available=false,
        notes=(
            "FOLT is indexed by ITAR although the tree identity is ITARGETS(ITAR); the caller supplies the final target's sorted FOLT array.",
            "SUMDAILY never applies SPERHR*1e-6 to TOTH2OEV: it is a raw sum of rate samples, not the header's mol H2O tree-1 day-1.",
            "The other rate integrals use SPERHR*1e-6; absorbed energy and sensible heat are MJ tree-1 day-1.",
        ),
    ),
    (
        id=:hrflux, category=:scientific,
        switch="IOHRLY>=1 and ISTARTHR<=IDAY+ISTART<=IENDHR",
        cadence=:subdaily, directory=:output,
        ascii="{plot}_hrflux.dat", binary=("hrflux.bin", "hrflux.hdr"),
        layout=:table,
        columns=(
            :IDAY, :ITREE, :ISPEC, :IHOUR, :THRAB1, :THRAB2, :THRAB3,
            :FCO2, :FRESPF, Symbol("FRESPW+FRESPB"), :FH2OT, :FH2OCAN,
            :GSCAN, :GBHCAN, :FHEAT, :TCAN, :ACANMAX, :ETCANDEFICIT,
            :PSILCAN, :PSILCANMIN, :CICAN, :TAIRABOVE, :VPD, :PAR,
            :ZEN, :AZ, :FBEAM,
        ),
        records="One 27-value ASCII row per accepted timestep and target; binary has 23 values; day=loop IDAY+1",
        ascii_format="(I7,1X,3(I4,1X),23(F12.5,1X))",
        binary_records="Unformatted STREAM without record markers: ASCII order excluding ETCANDEFICIT, ZEN, AZ and FBEAM; 23 native REAL values including IDs",
        status=:legacy_quirk, writer_available=false,
        notes=(
            "The date filter adds ISTART after the caller already supplied loop IDAY+1, shifting the physical calendar filter by one day.",
            "THRAB1 is multiplied by UMOLPERJ; FH2OT and FH2OCAN by 1e-3; VPD by 1/1000; only FBEAM(IHOUR,1) is written.",
            "FHEAT is W tree-1 multiplied by 1e-3, hence kW tree-1, not the header's MJ tree-1 s-1.",
            "ETCANDEFICIT is written as accumulated umol H2O tree-1 s-1 without the 1e-3 conversion, despite a mmol header.",
            "The binary header writes format 725 (the PAR description) instead of the columns format 728 and does not describe its actual schema.",
        ),
    ),
    (
        id=:layflx, category=:scientific, switch="IOHRLY>=2",
        cadence=:trial_and_subdaily, directory=:output,
        ascii="{plot}_layflx.dat", binary=("layflx.bin", "layflx.hdr"),
        layout=:mixed_blocks,
        columns=(
            Symbol("FOLLAY(1:NOLAY)"), Symbol("JMAX25(1:NOLAY,1)"),
            Symbol("VCMAX25(1:NOLAY,1)"), :IDAY, :IHOUR,
            Symbol("PPAR(1,1:NOLAY,IHOUR)/FOLLAY(1:NOLAY)"),
            Symbol("PPS(1,1:NOLAY,IHOUR)/FOLLAY(1:NOLAY)"),
            Symbol("PTRANSP(1,1:NOLAY,IHOUR)/FOLLAY(1:NOLAY)"),
        ),
        records="ASCII: three labelled parameter profiles per target/trial, then DAY/HOUR and three accepted flux profiles; each profile contains NOLAY values",
        ascii_format="Parameter profiles: (10(F10.5,1X)); time heading: (A5,I5,A5,I5); flux profiles: (10(F10.2,1X)); list-directed labels and blank lines",
        binary_records="Unformatted STREAM without record markers: native REAL IDAY, IHOUR, then three NOLAY-value normalized flux profiles; no parameter blocks; no foliage gives one -999.9 value after time",
        status=:legacy_quirk, writer_available=false,
        notes=(
            "Parameter blocks occur inside timestep, canopy-air trial and target loops, without time/tree IDs. Exact trial counts are not scientific acceptance criteria.",
            "Accepted blocks are outside the hrflux calendar filter and use the first target's fluxes with the shared final target's FOLLAY vector.",
            "Only FOLLAY(1)>0 is checked before dividing every layer; otherwise ASCII writes NO FOLIAGE AT THIS TIME and binary writes -999.9.",
        ),
    ),
    (
        id=:histo, category=:scientific, switch="IOHIST=1",
        cadence=:end_of_run, directory=:output,
        ascii="{plot}_histo.dat", binary=("histo.bin", "histo.hdr"),
        layout=:histogram,
        columns=(:ITAR, Symbol("(IBIN-0.5)*BINSIZE"), Symbol("HISTO(ITAR,IBIN)")),
        records="For each target slot: TREE NO heading, PAR/FREQUENCY heading, then MAXHISTO bin/frequency pairs; written only after the daily loop",
        ascii_format="('TREE NO: ',I6); ('  PAR:         FREQUENCY (M^2.HR): '); (F8.2,1X,F12.6)",
        binary_records="Unformatted STREAM without record markers: native REAL ITAR followed by MAXHISTO pairs of bin centre and HISTO; histo.hdr is opened but never populated",
        status=:legacy_quirk, writer_available=false,
        notes=(
            "TREE NO means target slot ITAR, not ITARGETS(ITAR).",
            "ZEROSTART resets HISTO every simulated day; the final file is not a histogram integrated over the whole run.",
            "CATEGO adds AREA inside daylight canopy trials without SPERHR or timestep weighting: repeated trials contribute, and the advertised m2.hour frequency is not an actual duration integral.",
        ),
    ),
    (
        id=:resp, category=:scientific, switch="IORESP=1",
        cadence=:daily, directory=:output,
        ascii="{plot}_resp.dat", binary=("resp.bin", "resp.hdr"),
        layout=:table,
        columns=(
            :IDAY, :ITREE, :ISPEC, :TOTRESPF, :TOTRESPW, :TOTRESPB,
            :TOTRESPCR, :TOTRESPFR, :TOTRESPFG, :TOTRESPWG, :TOTRESPBG,
            :TOTRESPCRG, :TOTRESPFRG,
        ),
        records="One 13-value row per target after daily aggregation, independently of IODAILY; day=loop IDAY+1",
        ascii_format="(I7,1X,I4,1X,I4,1X,10(F10.5,1X))",
        binary_records="Unformatted STREAM without record markers: same 13 quantities as ASCII, IDs converted to native REAL",
        status=:legacy_quirk, writer_available=false,
        notes=(
            "Maintenance totals are per-tree rate integrals; the header's mol m-2 day-1 basis is not established by this writer.",
            "Growth respiration arguments are shared scalars repeated for every target, not target-specific arrays; do not invent an area conversion or missing components.",
        ),
    ),
    (
        id=:resph, category=:scientific, switch="IORESP=1",
        cadence=:headers_only, directory=:output,
        ascii="{plot}_resph.dat", binary=("resphr.bin", "resphr.hdr"),
        layout=:headers_only, columns=(),
        records="Headers only: no numerical WRITE to URESPHR appears in the historical executable path",
        ascii_format="Header prose; no numerical record format",
        binary_records="Unformatted STREAM opened without record markers but no numerical values written; resphr.hdr contains descriptive headers",
        status=:legacy_quirk, writer_available=false,
        notes=(
            "Canonical ID is resph; resphr is only the historical binary filename stem.",
            "The header advertises hourly maintenance components but is not evidence that numerical records exist.",
        ),
    ),
    (
        id=:watbal, category=:scientific,
        switch="ISMAESPA opens; IOWATBAL=1 writes",
        cadence=:subdaily, directory=:output,
        ascii="{plot}_watbal.dat", binary=("watbal.bin", "watbal.hdr"),
        layout=:table,
        columns=(
            :IDAY, :IHOUR, :WSOIL, :WSOILROOT, :PPT, :CANOPY_STORE,
            :EVAPSTORE, :DRAINSTORE, :SURFACE_WATERMM, :ETMM, :ETMM2,
            :DISCHARGE, Symbol("OVERFLOW*1000"), :WEIGHTEDSWP, :KTOT,
            :DRYTHICK, :SOILEVAP, :SOILMOISTURE, :FSOIL1, :QH, :QE,
            :QN, :QC, :RGLOBUND, :RGLOBABV, :RADINTERC, :RNET, :TOTLAI,
            :TAIRABOVE, :TAIRCAN, :TCANMEAN, Symbol("TSOILSURFACE-273.15"),
            Symbol("SOILTEMP(1)"), Symbol("SOILTEMP(2)"), Symbol("SOILTEMP(3)"),
            Symbol("FRACWATER(1)"), Symbol("FRACWATER(2)"), :FRACAPAR,
            :VPD, :VPDCAN, :GCANOP, :ITERTAIR, :HTOT, :RTHERMINC,
            :SCLOSTTOT3, :SCLOSTTOT, :EVMM, :DRYCAN,
        ),
        records="One 48-value ASCII row after accepted water/heat calculations; day=loop IDAY+1; fixed accesses include the first three soil temperatures",
        ascii_format="(I7,I7,39(F14.6,1X),I7,6(F14.6,1X))",
        binary_records="Unformatted STREAM without record markers: native REAL quantities through TAIRCAN (30 scalars), entire TCAN(MAXT,MAXHRS) array in Fortran column-major order, SOILTEMP(1:2), FRACWATER(1:2); 34+MAXT*MAXHRS values, not the ASCII schema",
        status=:legacy_quirk, writer_available=false,
        notes=(
            "OUTPUTWATBAL modifies FSOIL1 and ETMM2 before testing IOWATBAL; output must not become a state-mutating Julia exporter.",
            "FSOIL1 becomes 1 when TOTTMP=0, otherwise FSOIL1/TOTTMP; ETMM2 becomes measured ET when USEMEASET=1, otherwise 0.",
            "TCANMEAN is an unweighted target-slot mean; binary writes the full TCAN array including unused slots/timesteps instead.",
            "Column 9 is SURFACE_WATERMM despite the tfall header label; RNET=RGLOBABV-SCLOSTTOT-ESOIL.",
            "The caller passes SOILTEMP-FREEZE in degrees Celsius; TSOILSURFACE is separately converted from Kelvin here. The binary header describes the incompatible ASCII schema.",
        ),
    ),
    (
        id=:watlay, category=:scientific,
        switch="ISMAESPA opens; IOWATBAL=1 writes",
        cadence=:subdaily, directory=:output,
        ascii="{plot}_watlay.dat", binary=("watlay.bin", "watlay.hdr"),
        layout=:profile, columns=(Symbol("FRACWATER(1:NLAYER)"),),
        records="One volumetric water-content profile per accepted water-balance timestep, in configured layer order; NLAYER values, no time/layer IDs",
        ascii_format="(60(F10.4,1X)); format reversion wraps longer profiles",
        binary_records="Unformatted STREAM without record markers: NLAYER native REAL values per timestep, FRACWATER(1:NLAYER); watlay.hdr is opened but never populated",
        status=:record_writer, writer_available=true,
        notes=(
            "Values are total water-equivalent volumetric water content including frozen storage (m3 m-3); ASCII has neither a header nor explicit time/layer identity.",
            "maespa_watlay_plan, project_legacy_profile and write_legacy_profile implement exact accepted-profile record IO with explicit ordered coverage and same-step availability.",
            "Automatic legacy filenames and control switches are not implemented; binary REAL kind and byte order must be chosen explicitly at the IO boundary.",
        ),
    ),
    (
        id=:swplay, category=:scientific,
        switch="ISMAESPA opens ASCII; IOWATBAL=1 writes",
        cadence=:subdaily, directory=:output,
        ascii="{plot}_swplay.dat", binary=nothing,
        layout=:profile, columns=(Symbol("SOILWP(1:NLAYER)"),),
        records="One soil-water-potential profile per water-balance timestep, NLAYER values, no time/layer IDs",
        ascii_format="(60(F10.4,1X)); format reversion wraps longer profiles",
        binary_records=nothing,
        status=:legacy_quirk, writer_available=true,
        notes=(
            "No binary file is opened for USWPLAY, although the binary OUTPUTWATBAL branch performs an unformatted WRITE on that unit; implicit-file effects are compiler dependent.",
            "Soil water potential is in MPa; do not invent swplay.bin or a corresponding .hdr filename.",
            "SOILWP is computed before WATBALLAY and not refreshed before this writer; maespa_swplay_plan selects the explicitly captured accepted pre-water profile, not post-water hydraulic rows.",
            "project_legacy_profile and write_legacy_profile provide strict retained-source ASCII record IO only; binary swplay is explicitly rejected and automatic filenames/switches remain separate.",
        ),
    ),
    (
        id=:watsoilt, category=:scientific,
        switch="ISMAESPA opens; IOWATBAL=1 writes",
        cadence=:subdaily, directory=:output,
        ascii="{plot}_watsoilt.dat", binary=("watsoilt.bin", "watsoilt.hdr"),
        layout=:profile, columns=(Symbol("SOILTEMP(2:NLAYER+1)"),),
        records="One NLAYER-value soil-temperature profile per water-balance timestep; ASCII starts at index 2; no time/layer IDs",
        ascii_format="(25(F10.2,1X)); format reversion wraps longer profiles",
        binary_records="Unformatted STREAM without record markers: NLAYER native REAL values SOILTEMP(1:NLAYER), unlike the ASCII indices; watsoilt.hdr is opened but never populated",
        status=:legacy_quirk, writer_available=true,
        notes=(
            "The caller passes SOILTEMP-FREEZE, so written profile temperatures are degrees Celsius.",
            "ASCII skips the temperature just below the dry surface layer; binary retains it and omits the last ASCII element.",
            "maespa_watsoilt_plan captures the final physical Kelvin profile and its exact current SOILTK input with same-step availability and separate convergence evidence; Celsius conversion occurs only during record IO.",
            "Only explicit record projection/IO is supported; legacy filenames and control switches remain unimplemented.",
        ),
    ),
    (
        id=:wattest, category=:scientific,
        switch="ISMAESPA and IOFORMAT=0 opens; daily WRITE is unconditional",
        cadence=:daily, directory=:output,
        ascii="{plot}_wattest.dat", binary=nothing,
        layout=:scalar, columns=(Symbol("PLANTWATER(IDAY+1,1)"),),
        records="One list-directed value after the hourly loop, without day/tree IDs; only plant-water column 1 is written",
        ascii_format="List-directed scalar WRITE",
        binary_records=nothing,
        status=:legacy_quirk, writer_available=false,
        notes=(
            "No binary wattest file is opened. The unconditional formatted WRITE can implicitly connect a compiler-dependent file when the expected ASCII unit was not opened, including MAESTRA mode.",
            "This debug scalar is not a complete plant-water state or a restart representation.",
        ),
    ),
    (
        id=:watupt, category=:scientific,
        switch="ISMAESPA opens; IOWATBAL=1 writes",
        cadence=:subdaily, directory=:output,
        ascii="{plot}_watupt.dat", binary=("watupt.bin", "watupt.hdr"),
        layout=:profile, columns=(Symbol("FRACUPTAKE(1:min(40,NROOTLAYER))"),),
        records="One fractional root-uptake profile per water-balance timestep, in root-layer order, at most 40 values; no time/layer IDs",
        ascii_format="(60(F7.4,1X))",
        binary_records="Unformatted STREAM without record markers: min(40,NROOTLAYER) native REAL FRACUPTAKE values per timestep; watupt.hdr is opened but never populated",
        status=:legacy_quirk, writer_available=false,
        notes=(
            "The writer still truncates to 40 root layers even though the ASCII format accommodates 60 values.",
            "Fractional allocation is not an absolute water-uptake amount; preserve its distinction from interval water fluxes.",
            "On the audited main-program path, FRACUPTAKESPEC is assigned but the separate FRACUPTAKE argument passed to this writer is not; its numerical contents are not a physiological oracle.",
        ),
    ),
    (
        id=:watbalday, category=:scientific,
        switch="ISMAESPA; independent of IOWATBAL",
        cadence=:daily, directory=:output,
        ascii="{plot}_watbalday.dat", binary=("watbalday.bin", "watbalday.hdr"),
        layout=:table,
        columns=(
            :IDAY, :WSOILMEAN, :WSOILROOTMEAN, :SWPMEAN, :PPTTOT,
            :TFALLTOT, :ETMMTOT, :ETMEASTOT, :DISCHARGETOT, :SOILEVAPTOT,
            :FSOILMEAN, :QHTOT, :QETOT, :QNTOT, :QCTOT, :RADINTERCTOT,
            :EVMMTOT,
        ),
        records="One 17-value row after daily water aggregation; day=loop IDAY+1; means and interval totals have distinct temporal meanings",
        ascii_format="(I7,16(F12.4))",
        binary_records="Unformatted STREAM without record markers: same 17 quantities as ASCII, IDAY converted to native REAL",
        status=:legacy_quirk, writer_available=false,
        notes=(
            "Both historical full-file headers omit the seventeenth field EVMMTOT; it remains part of the actual data schema.",
            "TFALLTOT precedes ETMMTOT in the record despite its later position in OUTPUTDYWAT's argument list.",
            "The portable synthetic fixture checks numerical record order/format only; it is not a complete header or physiological reference.",
        ),
    ),
    (
        id=:sunla, category=:scientific,
        switch="ISUNLA=1 opens; numerical writer additionally requires ISMAESPA",
        cadence=:subdaily, directory=:output,
        ascii="{plot}_sunla.dat", binary=nothing,
        layout=:table,
        columns=(:IDAY, :IHOUR, :ITREE, :MAXTLEAF, :MINTLEAF, :MEANTLEAF),
        records="One six-value row per accepted MAESPA timestep and target; day=loop IDAY, starting at zero; max/min/mean over NUMPNT representative point temperatures",
        ascii_format="(3(1X,I4),3(1X,F12.3))",
        binary_records=nothing,
        status=:legacy_quirk, writer_available=false,
        notes=(
            "Despite its name, this family writes leaf-temperature statistics, not sunlit leaf area.",
            "MEANTLEAF is the unweighted point mean, not the area-weighted Crown temperature; tree IDs are ITARGETS(ITAR).",
            "Always ASCII, even with IOFORMAT=1; its header is written only with IOFORMAT=0. MAESTRA can open a header-only file.",
        ),
    ),
    (
        id=:uspar, category=:scientific, switch="ISIMUS=1",
        cadence=:daily_flush_of_subdaily, directory=:output,
        ascii="{plot}_uspar.dat", binary=("uspar.bin",),
        layout=:table,
        columns=(
            :IDAY, :IHOUR, :IPTUS, :XLU, :YLU, :ZLU, :UIBEAM,
            :UIDIFF, :PARUS, :APARUS, :PSUS, :ETUS,
        ),
        records="Daily flush: for each timestep I=1:KHRS, points J=1:NOUSPOINTS; 12 values per row; day=loop IDAY+1",
        ascii_format="(I3,1X,2(I4,1X),10(F7.2,1X)); only nine real values are supplied",
        binary_records="Unformatted STREAM without record markers: same 12 quantities as ASCII, the three IDs converted to native REAL; no .hdr is opened",
        status=:legacy_quirk, writer_available=false,
        notes=(
            "UIBEAM, UIDIFF and PARUS are written in W m-2; non-moss APARUS is converted back to W m-2, contrary to their umol m-2 s-1 header descriptions.",
            "PSUS is net photosynthesis in umol CO2 m-2 ground s-1; ETUS is transpiration in mmol H2O m-2 ground s-1.",
            "The legacy overwrites TRANSB's sunlit fraction with a clump sunlit LAI. Corrected Julia transmission is not exact reproduction of that defect.",
            "No night/reset assignments or moss APARUS assignment establish all KHRS values on the audited path; do not fabricate missing records or treat stale values as accepted science.",
            "Two intended understorey-header blank lines are mistakenly written to UWATDAY, potentially creating an implicit file outside MAESPA mode.",
        ),
    ),
    (
        id=:testflx, category=:scientific, switch="IPOINTS>=1",
        cadence=:point_ray_visits, directory=:working_directory,
        ascii="{plot}_testflx.dat", binary=nothing,
        layout=:table,
        columns=(
            :IDAY, :IHOUR, :IPTEST, :XLP, :YLP, :ZLP, :PAR, :FBEAM,
            :TDP, :TSCAT, :TBEAM, :TDIFF, :TTOT,
        ),
        records="One 13-value row per test-point visit in daylight/nonzero-foliage target and canopy-air trials; day=loop IDAY; no target/trial IDs",
        ascii_format="(3(I5,1X),12(F12.5,1X)); only ten real values are supplied",
        binary_records=nothing,
        status=:legacy_quirk, writer_available=false,
        notes=(
            "GETPOINTSF opens the file in the working directory, ignoring out_path; it is always ASCII.",
            "The prose header describes SUNLA, but no SUNLA data column is written.",
            "PAR, TBEAM and TDIFF are formed on the UMOLPERJ-converted photon basis, while TSCAT is assigned DIFDN without that conversion before TTOT is formed; do not infer consistent units from the header.",
            "Visits can repeat for each target/trial and do not constitute a rectangular accepted-timestep stream.",
        ),
    ),
    (
        id=:pttd, category=:scientific,
        switch="IPOINTS=2 opens; TRANSD writes only with IPROG=ITEST during diffuse recomputation",
        cadence=:diffuse_recomputation, directory=:working_directory,
        ascii="{plot}_ptTD.dat", binary=nothing,
        layout=:table,
        columns=(:IPT, :DZUP, :DAZ, Symbol("exp(-DEXT(J)*(SU+SU1))")),
        records="One list-directed point/upward-zenith/azimuth/transmittance row per diffuse ray visit; no date, tree or call-source IDs",
        ascii_format="List-directed integer and three REAL values",
        binary_records=nothing,
        status=:legacy_quirk, writer_available=false,
        notes=(
            "Always ASCII in the working directory; understorey TRANSD calls use ITEST and can contribute the same family.",
            "The angular quantities are radians; recomputation cadence depends on IOTUTD and canopy changes, not accepted subdaily publication.",
            "Shaded/above-slope rays can jump past the upward TREDST calculation before this WRITE; SU/SU1 may then be carried from an earlier visit.",
        ),
    ),
    (
        id=:tutd, category=:auxiliary,
        switch="Opened unconditionally; final WRITE independent of IOTUTD",
        cadence=:final_state, directory=:input,
        ascii="{plot4}_tutd.dat", binary=nothing,
        layout=:table, columns=(:IPT, :TU, :TD, :RELDF),
        records="After the run: REWIND and write NUMPNT final shared-array point/TU/TD/RELDF records; also an input when IOTUTD=0",
        ascii_format="(1X,I3,5X,F8.4,1X,F8.4,1X,F8.4)",
        binary_records=nothing,
        status=:legacy_quirk, writer_available=false,
        notes=(
            "Always ASCII in the input directory, with four-digit plot padding and STATUS=UNKNOWN rather than an output replace policy.",
            "Final arrays do not preserve every target, scene, understorey field or state needed for a complete restart.",
            "IOTUTD=0 is nominally the read-from-file path, but the main program also evaluates MOD(IDAY,IOTUTD) without a zero guard.",
        ),
    ),
    (
        id=:maeserr, category=:auxiliary, switch="Opened before control parsing",
        cadence=:event_driven, directory=:input,
        ascii="{plot}_Maeserr.dat", binary=nothing,
        layout=:text, columns=(),
        records="Error, warning and completion text from SUBERROR; not a numerical table",
        ascii_format="Diagnostic text records, not a fixed-column numerical format",
        binary_records=nothing,
        status=:deferred, writer_available=false,
        notes=(
            "Always ASCII in the input directory; STATUS=UNKNOWN does not establish a clean replaced output file.",
            "FLOCATIONS is read into local fin_dir/fout_dir but is not applied to the passed in_path/out_path used by opening routines.",
            "A completion message is a diagnostic event, not independent evidence of scientific validation.",
        ),
    ),
)
