"""
    SwplayProfilePlan

Validated pre-run snapshot of the historical pre-water soil-potential boundary.
The complete native profile and its own accepted-capture gate are distinct
retained sources. Physical layer identity/order is captured before simulation;
the plan does not calculate potential or select the post-water hydraulic rows.
"""
struct SwplayProfilePlan{Q,G,L,I,S,P,A}
    quantity::Q
    gate::G
    layer_ids::L
    layer_indices::I
    source_layer_ids::S
    profile_positions::P
    manifest::Tuple{Q,G}
    availability::A
    function SwplayProfilePlan(::Val{:validated}, quantity, gate,
        layer_ids::Tuple, layer_indices::Tuple, source_layer_ids::Tuple,
        profile_positions::Tuple, availability::Tuple)
        return new{typeof(quantity),typeof(gate),typeof(layer_ids),
            typeof(layer_indices),typeof(source_layer_ids),typeof(profile_positions),
            typeof(availability)}(quantity, gate, layer_ids, layer_indices,
                source_layer_ids, profile_positions, (quantity, gate), availability)
    end
end

"""
    maespa_swplay_plan(model; application=:soil_water_balance,
        on=PlantSimEngine.One(scale=:Soil), profile_layer_order=nothing)

Capture the local `soil_water_potentials_before_water_balance_mpa` publisher
and its `soil_pre_water_potential_available` gate before running. Both must
have their complete native-potential/accepted-pre-water contracts, exact Soil
identity and one source clock. Physical SoilLayers need unique `layer_index=1:n`
metadata and the declared profile dimension.

Native water balance publishes in physical layer order; its layer-index binding
must cover that subtree without a temporal lag. Other compatible publishers
must explicitly name stable source-position IDs with `profile_layer_order`.
Pre-water profiles have no distributed post-water scalar equivalence requirement.

Retain both entries of `plan.manifest`, collect with `plan.availability`, then
project. A schema zero, unprepared first step, skipped transition, held source
value or final status does not supply an accepted pre-water observation. Native
construction prepares the first state; custom hypotheses need their own initial
calculation before temporal compilation. Regenerate plans after structural
changes. This API neither opens files nor orchestrates legacy IO switches.
"""
function maespa_swplay_plan(model::PlantSimEngine.CompositeModel;
    application=:soil_water_balance, on=PlantSimEngine.One(scale=:Soil),
    profile_layer_order=nothing)
    application isa Symbol || throw(ArgumentError("application must be a Symbol"))
    objects = PlantSimEngine.resolve_objects(model, on)
    length(objects) == 1 || throw(ArgumentError("swplay needs exactly one selected Soil object"))
    soil = only(objects)
    soil.scale === :Soil || throw(ArgumentError("swplay publisher must be on a Soil object"))
    mounted = filter(row -> row.application_id === application,
        PlantSimEngine.Diagnostics.explain_applications(model))
    length(mounted) == 1 || throw(ArgumentError("swplay needs one exact application $application"))
    only(mounted).model_storage === :shared_application || throw(ArgumentError(
        "swplay does not yet support per-object publisher overrides",
    ))
    declaration = model.applications[only(mounted).application_slot]
    publisher = declaration isa PlantSimEngine.ModelSpec ? declaration.model : declaration
    interface = PlantSimEngine.Authoring.model_interface(publisher)
    metadata = maespa_output_manifest(model;
        variables=(:soil_water_potentials_before_water_balance_mpa,
            :soil_pre_water_potential_available),
        applications=application, on=PlantSimEngine.One(id=soil.id))
    quantities = filter(row -> row.variable === :soil_water_potentials_before_water_balance_mpa, metadata)
    gates = filter(row -> row.variable === :soil_pre_water_potential_available, metadata)
    length(quantities) == length(gates) == 1 || throw(ArgumentError(
        "swplay needs one exact pre-water profile publisher and one exact capture gate",
    ))
    quantity, gate = only(quantities), only(gates)
    quantity.contract == SOIL_LAYER_WATER_POTENTIAL_CONTRACT || throw(ArgumentError(
        "swplay needs physical-layer soil-water pressure potential in MPa",
    ))
    gate.contract == SOIL_PRE_WATER_POTENTIAL_AVAILABLE_CONTRACT || throw(ArgumentError(
        "swplay needs the accepted pre-water-capture availability contract",
    ))
    all(row -> row.output_role === :local &&
        isequal(row.object_id, soil.id.value) &&
        isequal(row.source_object_id, soil.id.value), (quantity, gate)) || throw(ArgumentError(
            "swplay quantity and gate must be local to the selected Soil",
        ))
    isequal(quantity.source_clock, gate.source_clock) || throw(ArgumentError(
        "swplay quantity and gate must share one source clock",
    ))
    declared_profile = interface.outputs.soil_water_potentials_before_water_balance_mpa
    declared_profile isa AbstractVector && !isempty(declared_profile) || throw(ArgumentError(
        "swplay publisher must declare a nonempty vector profile",
    ))
    Base.require_one_based_indexing(declared_profile)
    interface.outputs.soil_pre_water_potential_available isa Bool || throw(ArgumentError(
        "swplay publisher must declare a scalar Bool capture gate",
    ))
    count = length(declared_profile)
    layers = PlantSimEngine.resolve_objects(model, PlantSimEngine.Many(
        scale=:SoilLayer, within=PlantSimEngine.Scope(soil.id)))
    length(layers) == count || throw(ArgumentError(
        "swplay physical SoilLayer coverage must match the declared profile dimension",
    ))
    indexed = map(layers) do layer
        index = _maespa_manifest_scalar(PlantSimEngine.model_status(model, layer.id), :layer_index)
        index isa Integer && !(index isa Bool) || throw(ArgumentError(
            "swplay SoilLayers need explicit integer layer_index metadata",
        ))
        return (id=layer.id, index)
    end
    sort!(indexed; by=layer -> layer.index)
    [layer.index for layer in indexed] == collect(1:count) || throw(ArgumentError(
        "swplay layer_index metadata must contain 1:$count exactly once",
    ))
    ids = Tuple(layer.id.value for layer in indexed)
    indices = Tuple(layer.index for layer in indexed)
    source_ids = if publisher isa MAESPASoilWaterBalance
        bindings = filter(row -> row.application_id === application &&
            isequal(row.consumer_id, soil.id.value) && row.input === :layer_indices,
            PlantSimEngine.Diagnostics.explain_bindings(model))
        length(bindings) == 1 || throw(ArgumentError("swplay needs an exact native layer-index binding"))
        binding = only(bindings)
        binding.source_var === :layer_index && !binding.breaks_same_step_cycle &&
            Set(PlantSimEngine.ObjectId(id) for id in binding.source_ids) ==
            Set(layer.id for layer in indexed) || throw(ArgumentError(
                "swplay native layer-index binding must cover physical layers without a temporal lag",
            ))
        if !isnothing(profile_layer_order)
            isequal(_watlay_explicit_layer_order(profile_layer_order, ids), ids) ||
                throw(ArgumentError("native pre-water profiles publish in layer_index order"))
        end
        ids
    else
        isnothing(profile_layer_order) && throw(ArgumentError(
            "an alternative swplay publisher requires explicit profile_layer_order stable IDs",
        ))
        _watlay_explicit_layer_order(profile_layer_order, ids)
    end
    positions = Tuple(only(findall(source -> isequal(source, id), source_ids)) for id in ids)
    availability = ((application, quantity.variable) =>
        (application=application, variable=gate.variable, object=:source),)
    return SwplayProfilePlan(Val(:validated), deepcopy(quantity), deepcopy(gate),
        deepcopy(ids), indices, deepcopy(source_ids), positions, availability)
end

function _swplay_project_sample(plan, quantity, gate; detach_plan=true)
    _legacy_profile_observation(quantity, plan.quantity; family=:swplay)
    _legacy_profile_observation(gate, plan.gate; family=:swplay)
    _legacy_profile_available(quantity, gate; family=:swplay)
    _legacy_profile_values(quantity.value, length(plan.layer_ids); family=:swplay)
    physical = quantity.value[collect(plan.profile_positions)]
    return merge(deepcopy(quantity), (
        family=:swplay, projection_plan=detach_plan ? deepcopy(plan) : plan,
        layer_ids=deepcopy(plan.layer_ids), layer_indices=plan.layer_indices,
        source_layer_ids=deepcopy(plan.source_layer_ids),
        source_profile_positions=plan.profile_positions,
        phase=:accepted_pre_water_balance, encoding_phase=:unencoded,
        value=deepcopy(physical), quantity_sample=deepcopy(quantity),
        pre_water_availability_sample=deepcopy(gate),
    ))
end

"""
    project_legacy_profile(rows, plan::SwplayProfilePlan; family=:swplay)

Join the retained incoming-potential profile and its own capture gate at exactly
the same native step, datetime and source clock. Missing/incomplete histories,
false availability, duplicates and altered source metadata are errors. Returned
MPa values retain their numeric type, in complete physical layer order. Each
record owns detached plan/value/native-evidence copies. No potential equation,
lagged resampling, time relabeling, post-water substitution or model execution
occurs. Serialization is ASCII-only through [`write_legacy_profile`](@ref).
"""
function project_legacy_profile(rows, plan::SwplayProfilePlan; family=:swplay)
    family === :swplay || throw(ArgumentError("legacy profile family $(repr(family)) is not implemented by this plan"))
    expected = Dict(_legacy_profile_source_key(entry) => entry for entry in plan.manifest)
    streams = Dict(key => Dict{Any,Any}() for key in keys(expected))
    for row in rows
        row isa NamedTuple && all(name -> haskey(row, name), (:application_id, :object_id, :variable)) ||
            throw(ArgumentError("swplay requires collected rows with exact publisher identities"))
        key = _legacy_profile_source_key(row)
        haskey(expected, key) || throw(ArgumentError("unexpected swplay source identity $key"))
        _legacy_profile_observation(row, expected[key]; family=:swplay)
        haskey(streams[key], row.timestep) && throw(ArgumentError("duplicate swplay source sample at timestep $(row.timestep)"))
        streams[key][row.timestep] = row
    end
    steps = Set(keys(streams[_legacy_profile_source_key(plan.quantity)]))
    all(stream -> Set(keys(stream)) == steps, values(streams)) || throw(ArgumentError(
        "swplay requires complete matching native profile and capture-gate histories",
    ))
    records = NamedTuple[]
    sample(entry, step) = streams[_legacy_profile_source_key(entry)][step]
    for step in sort!(collect(steps))
        push!(records, _swplay_project_sample(plan, sample(plan.quantity, step), sample(plan.gate, step)))
    end
    return records
end

function _validate_swplay_records(records)
    validated = NamedTuple[]
    previous = nothing
    required = (:projection_plan, :quantity_sample, :pre_water_availability_sample)
    for record in records
        record isa NamedTuple && all(name -> haskey(record, name), required) &&
            record.projection_plan isa SwplayProfilePlan || throw(ArgumentError(
                "write_legacy_profile requires complete projected swplay records",
            ))
        plan = record.projection_plan
        expected = _swplay_project_sample(plan, record.quantity_sample,
            record.pre_water_availability_sample; detach_plan=false)
        _legacy_profile_record_matches_evidence(record, expected) || throw(ArgumentError(
            "swplay record values or metadata differ from captured native evidence",
        ))
        if !isnothing(previous)
            record.timestep > previous.timestep || throw(ArgumentError(
                "swplay records must have unique increasing native timesteps",
            ))
            prior = previous.projection_plan
            all(name -> isequal(getproperty(plan, name), getproperty(prior, name)),
                fieldnames(typeof(plan))) || throw(ArgumentError(
                    "swplay records cannot mix publishers, clocks or physical layer identities",
                ))
        end
        push!(validated, record)
        previous = record
    end
    return validated
end
