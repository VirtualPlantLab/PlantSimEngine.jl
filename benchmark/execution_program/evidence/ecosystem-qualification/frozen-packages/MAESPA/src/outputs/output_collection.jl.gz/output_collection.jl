"""
    maespa_output_manifest(model; variables=nothing, on=PlantSimEngine.Many(),
                           applications=nothing)

Capture an identity and scientific-contract snapshot for the fully contracted
outputs currently mounted in `model`. Call this **before** starting the
simulation, and keep it with the returned native PlantSimEngine `Simulation`.
The selection keywords have the same meaning as [`maespa_output_requests`](@ref).
With `variables=nothing`, include all fully contracted outputs in the selection.

The manifest preserves typed object IDs, output/source-object identities,
contracts and nominal source clocks. Ancestor IDs come from public object
topology. MAESPA's explicit, static builder metadata supplies tree/species
indices on Plant objects, soil-layer indices on SoilLayer objects, simulation
point/class/age indices on LogicalLeafUnit objects, and understorey-patch
indices on UnderstoreyPatch objects. Missing labels remain `missing`: object
IDs are not parsed and array positions are not assigned biological identities.

LogicalLeafUnit is a simulation unit, not a botanical leaf organ or an invented
Point object. Array-valued crown/soil/species profiles remain whole values; a
single scalar layer or point identity is not inferred for those profiles.

This is a composition snapshot, not a lifecycle history. New objects or
changed identity metadata require an explicitly captured new manifest; the
collector does not relabel old samples from the final topology or status.
No forcing, historical availability, conversions or aggregations are inferred.
"""
function maespa_output_manifest(model::PlantSimEngine.CompositeModel;
    variables=nothing, on=PlantSimEngine.Many(), applications=nothing)
    variable_names = isnothing(variables) ? nothing :
        _output_selection_names(variables, "variables")
    application_names = isnothing(applications) ? nothing :
        _output_selection_names(applications, "applications")
    if !isnothing(application_names)
        mounted = Set(row.application_id for row in
            PlantSimEngine.Diagnostics.explain_applications(model))
        unknown = filter(name -> !(name in mounted), application_names)
        isempty(unknown) || throw(ArgumentError("unknown output applications: $unknown"))
    end
    # Reuse the established strict request-selection contract, without running
    # a model or retaining anything. Partial/uncontracted requested ports fail.
    if !isnothing(variable_names)
        maespa_output_requests(model, variable_names; on, applications=application_names)
    end
    selected_ids = Set(object.id for object in PlantSimEngine.resolve_objects(model, on))
    identities = Dict{PlantSimEngine.ObjectId,Any}()
    manifest = NamedTuple[]
    for entry in maespa_output_catalogue(model)
        id = PlantSimEngine.ObjectId(entry.object_id)
        id in selected_ids || continue
        isnothing(variable_names) || entry.variable in variable_names || continue
        isnothing(application_names) || entry.application_id in application_names || continue
        identity = get!(identities, id) do
            _maespa_manifest_identity(model, id)
        end
        push!(manifest, deepcopy(merge(entry, identity)))
    end
    return manifest
end

function _maespa_manifest_scalar(status, name::Symbol)
    hasproperty(status, name) || return missing
    value = getproperty(status, name)
    isnothing(value) && return missing
    value isa AbstractArray && throw(ArgumentError(
        "manifest identity $name must be explicit scalar metadata, not an array",
    ))
    return deepcopy(value)
end

function _maespa_manifest_identity(model, id)
    object = PlantSimEngine.model_object(model, id)
    lineage = Any[]
    visited = Set{PlantSimEngine.ObjectId}()
    ancestor = object
    while true
        ancestor.id in visited && throw(ArgumentError("cyclic output-object ancestry"))
        push!(visited, ancestor.id)
        push!(lineage, ancestor)
        isnothing(ancestor.parent) && break
        ancestor = PlantSimEngine.model_object(model, ancestor.parent)
    end
    scene_index = findfirst(item -> item.scale === :Scene, lineage)
    plant_index = findfirst(item -> item.scale === :Plant, lineage)
    plant_status = isnothing(plant_index) ? nothing :
        PlantSimEngine.model_status(model, lineage[plant_index].id)
    status = PlantSimEngine.model_status(model, object.id)
    return (
        scene_id=isnothing(scene_index) ? missing : lineage[scene_index].id.value,
        plant_id=isnothing(plant_index) ? missing : lineage[plant_index].id.value,
        tree_id=isnothing(plant_status) ? missing : _maespa_manifest_scalar(plant_status, :tree_id),
        tree_index=isnothing(plant_status) ? missing : _maespa_manifest_scalar(plant_status, :tree_index),
        species_id=isnothing(plant_status) ? missing : _maespa_manifest_scalar(plant_status, :species_id),
        layer_index=object.scale === :SoilLayer ?
            _maespa_manifest_scalar(status, :layer_index) : missing,
        point_index=object.scale === :LogicalLeafUnit ?
            _maespa_manifest_scalar(status, :logical_leaf_point_index) : missing,
        logical_leaf_unit_index=object.scale === :LogicalLeafUnit ?
            _maespa_manifest_scalar(status, :logical_leaf_unit_index) : missing,
        radiation_class_index=object.scale === :LogicalLeafUnit ?
            _maespa_manifest_scalar(status, :logical_leaf_radiation_class_index) : missing,
        physiological_age_index=object.scale === :LogicalLeafUnit ?
            _maespa_manifest_scalar(status, :logical_leaf_physiological_age_index) : missing,
        understorey_patch_index=object.scale === :UnderstoreyPatch ?
            _maespa_manifest_scalar(status, :understorey_patch_index) : missing,
        identity_provenance=:composition_snapshot,
    )
end

function _maespa_collection_entries(manifest)
    entries = Dict{Tuple{Symbol,PlantSimEngine.ObjectId,Symbol},Any}()
    fields = (:application_id, :object_id, :variable, :source_object_id,
        :contract, :source_clock, :provenance, :identity_provenance)
    for entry in manifest
        entry isa NamedTuple && all(name -> haskey(entry, name), fields) ||
            throw(ArgumentError("collect_maespa_outputs requires rows from maespa_output_manifest"))
        entry.application_id isa Symbol && entry.variable isa Symbol ||
            throw(ArgumentError("manifest application and variable identities must be Symbols"))
        entry.contract isa PlantSimEngine.VariableContract &&
            _complete_output_contract(entry.contract) && entry.provenance === :exact &&
            entry.identity_provenance === :composition_snapshot || throw(ArgumentError(
                "manifest rows need exact complete contracts and captured identity metadata",
            ))
        key = (entry.application_id, PlantSimEngine.ObjectId(entry.object_id), entry.variable)
        haskey(entries, key) && throw(ArgumentError("duplicate output source in manifest: $key"))
        entries[key] = entry
    end
    return entries
end

function _maespa_availability_rules(availability, entries)
    availability isa Union{Tuple,AbstractVector,AbstractDict} || throw(ArgumentError(
        "availability must be a dictionary or tuple/vector of explicit mapping pairs",
    ))
    declarations = availability isa AbstractDict ? pairs(availability) : availability
    targets = Set((entry.application_id, entry.variable) for entry in values(entries))
    rules = Dict{Tuple{Symbol,Symbol},Any}()
    for declaration in declarations
        declaration isa Pair || throw(ArgumentError("availability entries must be mapping pairs"))
        target, rule = first(declaration), last(declaration)
        target isa Tuple{Symbol,Symbol} || throw(ArgumentError(
            "availability keys must be (application_id, variable) tuples",
        ))
        target in targets || throw(ArgumentError("availability target is not in the manifest: $target"))
        haskey(rules, target) && throw(ArgumentError("duplicate availability mapping for $target"))
        rule isa NamedTuple && Set(keys(rule)) == Set((:application, :variable, :object)) ||
            throw(ArgumentError(
                "availability mappings require (application=..., variable=..., object=:source or :destination)",
            ))
        rule.application isa Symbol && rule.variable isa Symbol &&
            rule.object in (:source, :destination) || throw(ArgumentError(
                "availability mappings need Symbol names and explicit :source or :destination location",
            ))
        rules[target] = rule
    end
    return rules
end

function _maespa_retained_source_rows(simulation, cache, object_id, variable)
    key = (PlantSimEngine.ObjectId(object_id), variable)
    return get!(cache, key) do
        # This overload returns retained source samples even when the simulation
        # also contains resampled OutputRequests. Never collect by request name.
        PlantSimEngine.collect_outputs(simulation, object_id, variable; sink=nothing)
    end
end

function _maespa_sample_availability(simulation, cache, retained, rules, entry, sample)
    rule = get(rules, (entry.application_id, entry.variable), nothing)
    if isnothing(rule)
        return (availability=missing, availability_provenance=:unmapped,
            availability_application_id=missing, availability_variable=missing,
            availability_object_id=missing)
    end
    object_id = rule.object === :source ? entry.source_object_id : entry.object_id
    key = (rule.application, PlantSimEngine.ObjectId(object_id), rule.variable)
    provenance = :not_retained
    available = missing
    if key in retained
        matches = filter(_maespa_retained_source_rows(simulation, cache, object_id, rule.variable)) do row
            row.application_id === rule.application && row.timestep == sample.timestep
        end
        length(matches) <= 1 || throw(ArgumentError("ambiguous same-step availability samples for $key"))
        provenance = isempty(matches) ? :no_same_step_sample : :same_step_snapshot
        if !isempty(matches)
            value = only(matches).value
            value isa Union{Bool,AbstractArray{Bool}} || throw(ArgumentError(
                "availability $key must publish Bool or an array of Bool; no reduction is inferred",
            ))
            available = deepcopy(value)
        end
    end
    return (availability=available, availability_provenance=provenance,
        availability_application_id=rule.application, availability_variable=rule.variable,
        availability_object_id=object_id)
end

"""
    collect_maespa_outputs(simulation, manifest; availability=(), sink=nothing)

Project retained native source samples onto an explicitly captured
[`maespa_output_manifest`](@ref). Return a vector of named tuples, or pass those
rows to `sink(rows)` when a sink is supplied. This function does not inspect
final topology/status to reconstruct historical metadata and does not create
new observations from `OutputRequest` hold/interpolation/aggregation policies.

Rows preserve the manifest metadata and native `timestep`/`datetime`. `value`
is a deep copy of the retained payload, preserving numeric and array types;
`value_provenance=:retained_source_sample` does not assert physiological
availability or acceptance of a scientific trial. `source_clock` is the
nominal configured clock, not a measured duration or aggregation-window bound.
Native missing/repeated datetime labels remain unchanged. No initial-status
sample, later date, unit conversion, profile flattening or aggregation is added.

Availability is never associated by variable-name patterns or final state.
Supply explicit mappings, for example:

```julia
availability = Dict(
    (:soil_water_balance, :soil_water_content) =>
        (application=:soil_water_balance, variable=:soil_water_balance_available,
         object=:source),
)
```

Each key names a manifest application's quantity. The mapping names the gate
publisher and variable and explicitly chooses the quantity's `:source` or
`:destination` object. Retain the gate before running, then join its native
sample at exactly the quantity's timestep. Bool values and Bool-array masks are
copied unchanged; arrays are not reduced or interpreted as scalar validity.
Missing mappings/gate retention/same-step samples produce `availability=missing`
with `:unmapped`, `:not_retained` or `:no_same_step_sample` provenance.

Only samples still retained by PlantSimEngine can be projected. Unretained
manifest entries produce no rows, and temporal-dependency-only buffers may
have discarded older samples. Use explicit OutputRequests when complete
histories are required. An empty result is not evidence of inactivity or
availability. A pre-run manifest may preserve removed-object metadata but does
not supply identities for later objects; capture those explicitly.
"""
function collect_maespa_outputs(simulation::PlantSimEngine.Simulation,
    manifest::AbstractVector; availability=(), sink=nothing)
    entries = _maespa_collection_entries(manifest)
    rules = _maespa_availability_rules(availability, entries)
    retained = Set((row.application_id, PlantSimEngine.ObjectId(row.object_id), row.variable)
        for row in PlantSimEngine.Diagnostics.explain_outputs(simulation))
    cache = Dict{Tuple{PlantSimEngine.ObjectId,Symbol},Any}()
    rows = NamedTuple[]
    for (key, entry) in entries
        key in retained || continue
        for sample in _maespa_retained_source_rows(
            simulation, cache, entry.object_id, entry.variable)
            sample.application_id === entry.application_id || continue
            gate = _maespa_sample_availability(simulation, cache, retained, rules, entry, sample)
            push!(rows, merge(entry, sample, gate,
                (value=deepcopy(sample.value), value_provenance=:retained_source_sample)))
        end
    end
    sort!(rows; by=row -> (row.timestep, string(row.application_id),
        string(row.object_id), string(row.variable)))
    return isnothing(sink) ? rows : sink(rows)
end
