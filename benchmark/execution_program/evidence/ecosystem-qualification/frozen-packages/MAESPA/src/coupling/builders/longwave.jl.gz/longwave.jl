# Longwave forcing and canopy-exchange applications.

function _mono_pass_longwave_can_mount(
    config::SimulationConfig,
    soil,
    meteorology,
    species_set,
    targets,
)
    return !isnothing(soil) &&
           !isnothing(meteorology) &&
           !isnothing(species_set) &&
           !isempty(targets) &&
           config.canopy_air_iterations <= 1 &&
           iszero(soil.options.simulate_soil_temperature)
end

function _simulated_soil_longwave_can_mount(
    config::SimulationConfig,
    soil,
    meteorology,
    species_set,
    targets;
    mount_non_tuzet_leaf_exchange::Bool=false,
)
    return mount_non_tuzet_leaf_exchange &&
           !isnothing(soil) &&
           !isnothing(meteorology) &&
           !isnothing(species_set) &&
           !isempty(targets) &&
           config.canopy_air_iterations <= 1 &&
           soil.options.simulate_soil_temperature == 1
end

function _mono_pass_longwave_modelspecs(
    ::Type{T},
    config::SimulationConfig,
    soil::SoilConfig,
    target::Integer,
    point_count::Integer,
    equivalent_canopy_application::Symbol,
) where {T<:AbstractFloat}
    config.canopy_air_iterations <= 1 || throw(
        ArgumentError(
            "prescribed mono-pass longwave requires ITERTAIRMAX <= 1",
        ),
    )
    iszero(soil.options.simulate_soil_temperature) || throw(
        ArgumentError(
            "prescribed mono-pass longwave requires SIMTSOIL = 0",
        ),
    )

    tree_id = Int(target)
    target_name = _radiation_crown_name(tree_id)
    forcing_application = Symbol("mono_pass_longwave_forcing_", tree_id)
    exchange_application = Symbol("longwave_canopy_exchange_", tree_id)
    return (
        PlantSimEngine.ModelSpec(
            MAESPAMonoPassLongwaveForcing(T, point_count);
            name=forcing_application,
            on=PlantSimEngine.One(scale=:Crown, id=target_name),
            inputs=(
                :source_meteorology_available =>
                    _radiation_scene_application_input(
                        :meteorology,
                        :meteorology_reconstruction_available,
                    ),
                :source_equivalent_canopy_available =>
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_canopy_available,
                    ),
                :source_air_temperature_c =>
                    _radiation_scene_application_input(
                        :meteorology,
                        :air_temperature_c,
                    ),
                :source_prescribed_soil_temperature_c =>
                    _radiation_scene_application_input(
                        :meteorology,
                        :soil_temperature_c,
                    ),
                :source_incident_thermal_w_m2 =>
                    _radiation_scene_application_input(
                        :meteorology,
                        :incident_thermal_w_m2,
                    ),
                :source_soil_reflectance => _radiation_target_input(
                    tree_id,
                    :species_physiology,
                    :soil_reflectance,
                ),
            ),
        ),
        PlantSimEngine.ModelSpec(
            MAESPALongwaveCanopyExchange(
                T,
                point_count;
                maximum_layer_count=150,
            );
            name=exchange_application,
            on=PlantSimEngine.One(scale=:Crown, id=target_name),
            inputs=(
                equivalent_point_layer_count=
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_point_layer_count,
                    ),
                equivalent_point_layer_index=
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_point_layer_index,
                    ),
                equivalent_diffuse_transmittance=
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_diffuse_transmittance,
                    ),
                longwave_forcing_available=
                    _radiation_self_application_input(
                        forcing_application,
                        :mono_pass_longwave_forcing_available,
                    ),
                target_leaf_area=_radiation_target_input(
                    tree_id,
                    :crown_geometry,
                    :leaf_area,
                ),
                incident_thermal_w_m2=_radiation_self_application_input(
                    forcing_application,
                    :incident_thermal_w_m2,
                ),
                canopy_temperature_c=_radiation_self_application_input(
                    forcing_application,
                    :canopy_temperature_c,
                ),
                leaf_temperature_c=_radiation_self_application_input(
                    forcing_application,
                    :leaf_temperature_c,
                ),
                soil_surface_temperature_k=
                    _radiation_self_application_input(
                        forcing_application,
                        :soil_surface_temperature_k,
                    ),
                soil_reflectance_thermal=
                    _radiation_self_application_input(
                        forcing_application,
                        :soil_reflectance_thermal,
                    ),
            ),
        ),
    )
end

function _simulated_soil_longwave_modelspecs(
    ::Type{T},
    config::SimulationConfig,
    soil::SoilConfig,
    target::Integer,
    point_count::Integer,
    equivalent_canopy_application::Symbol,
) where {T<:AbstractFloat}
    config.canopy_air_iterations <= 1 || throw(
        ArgumentError(
            "simulated-soil mono-pass longwave requires ITERTAIRMAX <= 1",
        ),
    )
    soil.options.simulate_soil_temperature == 1 || throw(
        ArgumentError(
            "simulated-soil mono-pass longwave requires SIMTSOIL = 1",
        ),
    )

    tree_id = Int(target)
    target_name = _radiation_crown_name(tree_id)
    forcing_application = Symbol("simulated_soil_longwave_forcing_", tree_id)
    exchange_application = Symbol("longwave_canopy_exchange_", tree_id)
    soil_state(variable) = PlantSimEngine.One(
        scale=:Soil,
        kind=:soil,
        within=PlantSimEngine.SceneScope(),
        application=:soil_surface_temperature_state,
        var=variable,
    )
    return (
        PlantSimEngine.ModelSpec(
            MAESPASimulatedSoilLongwaveForcing(T, point_count);
            name=forcing_application,
            on=PlantSimEngine.One(scale=:Crown, id=target_name),
            inputs=(
                :source_meteorology_available =>
                    _radiation_scene_application_input(
                        :meteorology,
                        :meteorology_reconstruction_available,
                    ),
                :source_equivalent_canopy_available =>
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_canopy_available,
                    ),
                PlantSimEngine.PreviousTimeStep(
                    :source_previous_soil_surface_temperature_available,
                ) => soil_state(:soil_surface_temperature_state_available),
                :source_air_temperature_c =>
                    _radiation_scene_application_input(
                        :meteorology,
                        :air_temperature_c,
                    ),
                PlantSimEngine.PreviousTimeStep(
                    :source_previous_soil_surface_temperature_k,
                ) => soil_state(:soil_surface_temperature_state_k),
                :source_incident_thermal_w_m2 =>
                    _radiation_scene_application_input(
                        :meteorology,
                        :incident_thermal_w_m2,
                    ),
                :source_soil_reflectance => _radiation_target_input(
                    tree_id,
                    :species_physiology,
                    :soil_reflectance,
                ),
            ),
        ),
        PlantSimEngine.ModelSpec(
            MAESPALongwaveCanopyExchange(
                T,
                point_count;
                maximum_layer_count=150,
            );
            name=exchange_application,
            on=PlantSimEngine.One(scale=:Crown, id=target_name),
            inputs=(
                equivalent_point_layer_count=
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_point_layer_count,
                    ),
                equivalent_point_layer_index=
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_point_layer_index,
                    ),
                equivalent_diffuse_transmittance=
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_diffuse_transmittance,
                    ),
                longwave_forcing_available=
                    _radiation_self_application_input(
                        forcing_application,
                        :simulated_soil_longwave_forcing_available,
                    ),
                target_leaf_area=_radiation_target_input(
                    tree_id,
                    :crown_geometry,
                    :leaf_area,
                ),
                incident_thermal_w_m2=_radiation_self_application_input(
                    forcing_application,
                    :incident_thermal_w_m2,
                ),
                canopy_temperature_c=_radiation_self_application_input(
                    forcing_application,
                    :canopy_temperature_c,
                ),
                leaf_temperature_c=_radiation_self_application_input(
                    forcing_application,
                    :leaf_temperature_c,
                ),
                soil_surface_temperature_k=
                    _radiation_self_application_input(
                        forcing_application,
                        :soil_surface_temperature_k,
                    ),
                soil_reflectance_thermal=
                    _radiation_self_application_input(
                        forcing_application,
                        :soil_reflectance_thermal,
                    ),
            ),
        ),
    )
end

function _canopy_air_trial_longwave_modelspecs(
    ::Type{T},
    target::Integer,
    target_index::Integer,
    point_count::Integer,
    equivalent_canopy_application::Symbol,
) where {T<:AbstractFloat}
    tree_id = Int(target)
    target_name = _radiation_crown_name(tree_id)
    forcing_application =
        Symbol("canopy_air_trial_longwave_forcing_", tree_id)
    exchange_application = Symbol("longwave_canopy_exchange_", tree_id)
    return (
        PlantSimEngine.ModelSpec(
            MAESPACanopyAirTrialLongwaveForcing(
                T,
                target_index,
                point_count,
            );
            name=forcing_application,
            on=PlantSimEngine.One(scale=:Crown, id=target_name),
            inputs=(
                source_equivalent_canopy_available=
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_canopy_available,
                    ),
                source_incident_thermal_w_m2=
                    _radiation_scene_application_input(
                        :meteorology,
                        :incident_thermal_w_m2,
                    ),
                source_soil_reflectance=_radiation_target_input(
                    tree_id,
                    :species_physiology,
                    :soil_reflectance,
                ),
                canopy_air_trial_longwave_forcing_inputs_available=
                    _radiation_scene_application_input(
                        :meteorology,
                        :meteorology_reconstruction_available,
                    ),
            ),
            environment=PlantSimEngine.Environment(provider=:canopy),
        ),
        PlantSimEngine.ModelSpec(
            MAESPALongwaveCanopyExchange(
                T,
                point_count;
                maximum_layer_count=150,
            );
            name=exchange_application,
            on=PlantSimEngine.One(scale=:Crown, id=target_name),
            inputs=(
                equivalent_point_layer_count=
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_point_layer_count,
                    ),
                equivalent_point_layer_index=
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_point_layer_index,
                    ),
                equivalent_diffuse_transmittance=
                    _radiation_self_application_input(
                        equivalent_canopy_application,
                        :equivalent_diffuse_transmittance,
                    ),
                longwave_forcing_available=
                    _radiation_self_application_input(
                        forcing_application,
                        :canopy_air_trial_longwave_forcing_available,
                    ),
                target_leaf_area=_radiation_target_input(
                    tree_id,
                    :crown_geometry,
                    :leaf_area,
                ),
                incident_thermal_w_m2=_radiation_self_application_input(
                    forcing_application,
                    :incident_thermal_w_m2,
                ),
                canopy_temperature_c=_radiation_self_application_input(
                    forcing_application,
                    :canopy_temperature_c,
                ),
                leaf_temperature_c=_radiation_self_application_input(
                    forcing_application,
                    :leaf_temperature_c,
                ),
                soil_surface_temperature_k=
                    _radiation_self_application_input(
                        forcing_application,
                        :soil_surface_temperature_k,
                    ),
                soil_reflectance_thermal=
                    _radiation_self_application_input(
                        forcing_application,
                        :soil_reflectance_thermal,
                    ),
            ),
        ),
    )
end

