# Stem and foliage growth respiration applications.

function _stem_growth_target_names_by_species(
    scene::LegacyTreeScene,
    targets,
    species_count::Integer,
)
    count = Int(species_count)
    count >= 0 || throw(ArgumentError("species_count must be non-negative"))
    tree_by_id = Dict(tree.id => tree for tree in scene.trees)
    names = [Symbol[] for _ in 1:count]
    seen = Set{Int}()
    for target in targets
        target isa Integer && !(target isa Bool) || throw(
            ArgumentError("target tree identifiers must be integers"),
        )
        tree_id = Int(target)
        tree = get(tree_by_id, tree_id, nothing)
        isnothing(tree) && throw(
            ArgumentError("unknown target tree identifier $tree_id"),
        )
        tree_id in seen && continue
        push!(seen, tree_id)
        1 <= tree.species_id <= count || throw(
            BoundsError(1:count, tree.species_id),
        )
        push!(names[tree.species_id], _stem_object_name(tree_id))
    end
    return Tuple(Tuple(species_names) for species_names in names)
end

function _stem_growth_modelspecs(
    config::SimulationConfig{T},
    scene::LegacyTreeScene{T},
    species_set,
    targets,
    structure_clock,
) where {T<:AbstractFloat}
    isnothing(species_set) && return ()
    isnothing(scene.trajectories.stem_diameter) && return ()

    # MAESPA calls CALCWBIOM/GRESP from its hourly target loop while their
    # biomass variables are shared globals. The last visited target can thus
    # affect the next call. Julia deliberately gives every physical target
    # Stem its own daily state and PreviousTimeStep carrier instead.
    species_symbols = _species_symbols(config)
    target_names = _stem_growth_target_names_by_species(
        scene,
        targets,
        config.species_count,
    )
    calendar_input(variable) = PlantSimEngine.One(
        scale=:Scene,
        within=PlantSimEngine.Ancestor(scale=:Scene),
        application=:legacy_calendar,
        var=variable,
    )
    tree_by_stem_name =
        Dict(_stem_object_name(tree.id) => tree for tree in scene.trees)
    applications = PlantSimEngine.ModelSpec[]
    for species_id in eachindex(target_names)
        names = target_names[species_id]
        for stem_name in names
            tree = tree_by_stem_name[stem_name]
            tree_dimensions_application =
                _radiation_mounted_application(tree.id, :tree_dimensions)
            plant_dimension_input(variable) = PlantSimEngine.One(
                scale=:Plant,
                within=PlantSimEngine.Ancestor(scale=:Plant),
                application=tree_dimensions_application,
                var=variable,
            )
            target_selector = PlantSimEngine.One(
                scale=:Stem,
                kind=:stem,
                species=species_symbols[species_id],
                id=stem_name,
            )
            biomass_application =
                Symbol("stem_woody_biomass_tree_", tree.id)
            growth_application =
                Symbol("stem_growth_respiration_tree_", tree.id)
            push!(
                applications,
                PlantSimEngine.ModelSpec(
                    MAESPAWoodyBiomassTrajectory(
                        species_set[species_id].structure.allometry.trunk,
                    );
                    name=biomass_application,
                    on=target_selector,
                    every=structure_clock,
                    inputs=(
                        :simulation_day => calendar_input(:simulation_day),
                        :tree_height => plant_dimension_input(:tree_height),
                        :stem_diameter =>
                            plant_dimension_input(:stem_diameter),
                        :woody_biomass_trajectory_inputs_available =>
                            plant_dimension_input(
                                :stem_diameter_available,
                            ),
                        PlantSimEngine.PreviousTimeStep(
                            :previous_woody_biomass_kg_dry_matter_tree,
                        ) => PlantSimEngine.One(
                            within=PlantSimEngine.Self(),
                            application=biomass_application,
                            var=:woody_biomass_kg_dry_matter_tree,
                        ),
                    ),
                ),
            )
            push!(
                applications,
                PlantSimEngine.ModelSpec(
                    MAESPAGrowthRespiration(T);
                    name=growth_application,
                    on=target_selector,
                    every=structure_clock,
                    inputs=(
                        biomass_increment_g_dry_matter_tree_day=
                            PlantSimEngine.One(
                                within=PlantSimEngine.Self(),
                                application=biomass_application,
                                var=:woody_biomass_increment_g_dry_matter_tree_day,
                            ),
                        growth_respiration_efficiency=PlantSimEngine.One(
                            within=PlantSimEngine.Self(),
                            var=:stem_growth_respiration_efficiency,
                            from_status=true,
                        ),
                        date50=calendar_input(:date50),
                        growth_respiration_inputs_available=
                            PlantSimEngine.One(
                                within=PlantSimEngine.Self(),
                                application=biomass_application,
                                var=:woody_biomass_trajectory_available,
                            ),
                    ),
                ),
            )
        end
    end
    return Tuple(applications)
end

function _foliage_growth_modelspecs(
    config::SimulationConfig{T},
    scene::LegacyTreeScene{T},
    species_set,
    targets,
    structure_clock,
) where {T<:AbstractFloat}
    isnothing(species_set) && return ()

    # FOLLAY, SLA and PROP are Crown-level daily trajectories. Keep one
    # private CALCFBIOM/PreviousTimeStep state per physical target Crown so a
    # repeated target only affects later stand weighting, never its biomass.
    species_symbols = _species_symbols(config)
    tree_by_id = Dict(tree.id => tree for tree in scene.trees)
    seen = Set{Int}()
    applications = PlantSimEngine.ModelSpec[]
    calendar_input(variable) = PlantSimEngine.One(
        scale=:Scene,
        within=PlantSimEngine.Ancestor(scale=:Scene),
        application=:legacy_calendar,
        var=variable,
    )
    for target in targets
        target isa Integer && !(target isa Bool) || throw(
            ArgumentError("target tree identifiers must be integers"),
        )
        tree_id = Int(target)
        tree = get(tree_by_id, tree_id, nothing)
        isnothing(tree) && throw(
            ArgumentError("unknown target tree identifier $tree_id"),
        )
        tree_id in seen && continue
        push!(seen, tree_id)
        1 <= tree.species_id <= config.species_count || throw(
            BoundsError(1:config.species_count, tree.species_id),
        )

        crown_name = _radiation_crown_name(tree_id)
        target_selector = PlantSimEngine.One(
            scale=:Crown,
            kind=:crown,
            species=species_symbols[tree.species_id],
            id=crown_name,
        )
        physiology_application =
            _radiation_mounted_application(tree_id, :species_physiology)
        leaf_area_application =
            _radiation_mounted_application(tree_id, :leaf_area_distribution)
        crown_application_input(application, variable) =
            PlantSimEngine.One(
                within=PlantSimEngine.Self(),
                application=application,
                var=variable,
            )
        biomass_application = Symbol("foliage_biomass_tree_", tree_id)
        growth_application =
            Symbol("foliage_growth_respiration_tree_", tree_id)
        age_class_count = species_set[
            tree.species_id
        ].physiology.age_classes.physiological_count

        push!(
            applications,
            PlantSimEngine.ModelSpec(
                MAESPAFoliageBiomassTrajectory(
                    T,
                    config.canopy_layers,
                    age_class_count,
                );
                name=biomass_application,
                on=target_selector,
                every=structure_clock,
                inputs=(
                    :simulation_day => calendar_input(:simulation_day),
                    :leaf_area_by_layer => crown_application_input(
                        leaf_area_application,
                        :leaf_area_by_layer,
                    ),
                    :specific_leaf_area_m2_kg => crown_application_input(
                        physiology_application,
                        :specific_leaf_area_m2_kg,
                    ),
                    :physiological_foliage_age_proportions =>
                        crown_application_input(
                            physiology_application,
                            :physiological_foliage_age_proportions,
                        ),
                    :specific_leaf_area_available => crown_application_input(
                        physiology_application,
                        :specific_leaf_area_available,
                    ),
                    PlantSimEngine.PreviousTimeStep(
                        :previous_foliage_biomass_kg_dry_matter_tree,
                    ) => PlantSimEngine.One(
                        within=PlantSimEngine.Self(),
                        application=biomass_application,
                        var=:foliage_biomass_kg_dry_matter_tree,
                    ),
                ),
            ),
        )
        push!(
            applications,
            PlantSimEngine.ModelSpec(
                MAESPAGrowthRespiration(T);
                name=growth_application,
                on=target_selector,
                every=structure_clock,
                inputs=(
                    biomass_increment_g_dry_matter_tree_day=
                        crown_application_input(
                            biomass_application,
                            :foliage_biomass_increment_g_dry_matter_tree_day,
                        ),
                    growth_respiration_efficiency=crown_application_input(
                        physiology_application,
                        :leaf_growth_respiration_efficiency,
                    ),
                    date50=calendar_input(:date50),
                    growth_respiration_inputs_available=
                        crown_application_input(
                            biomass_application,
                            :foliage_biomass_trajectory_available,
                        ),
                ),
            ),
        )
    end
    return Tuple(applications)
end

