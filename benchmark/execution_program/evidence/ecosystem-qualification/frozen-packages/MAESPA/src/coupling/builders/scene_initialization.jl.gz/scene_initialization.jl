# Simulation clocks and initial scene, calendar, and radiation statuses.

function _daily_structure_clock(config::SimulationConfig, step_index::Integer)
    # Statuses are initialized at build time. The first scheduled execution is
    # therefore the next step 1, followed by one execution per MAESPA day.
    next_update = mod(config.steps_per_day - Int(step_index) + 1, config.steps_per_day) + 1
    return PlantSimEngine.ClockSpec(config.steps_per_day, next_update)
end

_base_step_seconds(config::SimulationConfig) = 86_400.0 / config.steps_per_day

function _initial_stand_leaf_area(
    scene::LegacyTreeScene{T},
    date50::Integer,
    targets,
) where {T<:AbstractFloat}
    total = zero(T)
    tree_indices = _tree_indices_by_id(scene)
    for target in targets
        total += interpolate_tree_dimension(
            scene.trajectories.leaf_area,
            date50,
            tree_indices[target],
        )
    end
    return total
end

function _initial_canopy_height_status(
    scene::LegacyTreeScene{T},
    date50::Integer,
) where {T<:AbstractFloat}
    dimensions_model = MAESPATreeDimensions(scene.trajectories)
    tree_heights = T[
        _tree_dimensions_at(
            dimensions_model,
            date50,
            tree.trajectory_index,
        ).tree_height for tree in scene.trees
    ]
    aggregation_model = MAESPACanopyHeightAggregation(T)
    status = PlantSimEngine.Status(;
        tree_heights_m=tree_heights,
        canopy_height_aggregation_inputs_available=true,
        PlantSimEngine.outputs_(aggregation_model)...,
    )
    PlantSimEngine.run!(aggregation_model, status, nothing, nothing, nothing)
    return (
        canopy_height_m=status.canopy_height_m,
        canopy_height_available=status.canopy_height_available,
    )
end

function _initial_stand_leaf_area_statistics_status(
    scene::LegacyTreeScene{T},
    date50::Integer,
) where {T<:AbstractFloat}
    leaf_areas = T[
        interpolate_tree_dimension(
            scene.trajectories.leaf_area,
            date50,
            tree.trajectory_index,
        ) for tree in scene.trees
    ]
    width, height = plot_dimensions(scene.plot)
    result = stand_leaf_area_statistics(T, leaf_areas, width * height)
    return (
        full_stand_leaf_area_m2=result.full_stand_leaf_area_m2,
        mean_tree_leaf_area_m2=result.mean_tree_leaf_area_m2,
        full_stand_lai=result.full_stand_lai,
        stand_leaf_area_statistics_available=true,
    )
end

function _simulation_step(
    config::SimulationConfig,
    date::Integer,
    step_index::Integer,
)
    1 <= step_index <= config.steps_per_day || throw(
        BoundsError(1:config.steps_per_day, step_index),
    )
    start_date50 = config.start_date.days_since_1950
    end_date50 = config.end_date.days_since_1950
    start_date50 <= date <= end_date50 || throw(
        BoundsError(start_date50:end_date50, date),
    )
    source_day_offset = _source_day_offset(start_date50, date, config.source_day_stride)
    return source_day_offset * config.steps_per_day + (Int(step_index) - 1)
end

"""Compressed execution offset, distinct from the absolute source position."""
function _executed_step_offset(config::SimulationConfig, date::Integer, step_index::Integer)
    source_offset = _simulation_step(config, date, step_index)
    source_day, step_offset = divrem(source_offset, config.steps_per_day)
    return div(source_day, config.source_day_stride) * config.steps_per_day + step_offset
end

function _initial_calendar_status(
    config::SimulationConfig,
    date::Integer,
    step_index::Integer,
    simulation_step::Integer,
)
    date50 = Int(date)
    return (
        simulation_step=Int(simulation_step),
        simulation_day=div(Int(simulation_step), config.steps_per_day),
        date50=date50,
        step_index=Int(step_index),
        legacy_day_of_year=legacy_julian_day(date50),
        astronomical_day=legacy_dayjul(date50),
    )
end

function _initial_solar_status(
    config::SimulationConfig,
    date::Integer,
    step_index::Integer,
)
    return solar_geometry(
        MAESPASolarGeometry(config.solar_geometry),
        legacy_dayjul(date),
        legacy_julian_day(date),
        step_index,
    )
end

function _initial_slope_radiation_status(
    config::SimulationConfig{T},
    scene::LegacyTreeScene{T},
    solar_status::NamedTuple,
    step_index::Integer,
) where {T<:AbstractFloat}
    if !solar_status.astronomical_daylight
        return (
            beam_slope_multiplier=zero(T),
            diffuse_slope_multiplier=zero(T),
            soil_reflection_slope_multiplier=zero(T),
            slope_radiation_correction_available=false,
        )
    end
    result = slope_radiation_correction(
        step_index,
        config.solar_geometry.time_difference_steps,
        solar_status.equation_of_time_steps,
        config.solar_geometry.latitude_rad,
        solar_status.solar_declination_rad,
        scene.plot.slope_rad[1],
        scene.plot.slope_rad[2],
        config.solar_geometry.scene_bearing_rad,
        solar_status.sun_zenith_rad;
        steps_per_day=config.steps_per_day,
    )
    return (
        beam_slope_multiplier=result.beam_slope_multiplier,
        diffuse_slope_multiplier=result.diffuse_slope_multiplier,
        soil_reflection_slope_multiplier=result.soil_reflection_slope_multiplier,
        slope_radiation_correction_available=true,
    )
end

