# Initial Crown, stem, branch, and root status values.

function _initial_species_crown_status(
    species_set::SpeciesSet{T},
    species_id::Integer,
    date50::Integer,
    config::SimulationConfig{T},
    solar_status::NamedTuple,
) where {T<:AbstractFloat}
    species = species_set[species_id]
    structure_model = MAESPASpeciesStructureTrajectory(species.structure)
    physiology_model = MAESPASpeciesPhysiologyTrajectory(species.physiology)
    structure_status = merge(
        PlantSimEngine.outputs_(structure_model),
        _species_structure_at(structure_model, date50),
    )
    diffuse_zeniths = diffuse_zenith_class_centres(T, config.zenith_angles)
    diffuse_coefficients = diffuse_extinction(
        diffuse_zeniths,
        structure_status.leaf_angle_class_centres_rad,
        structure_status.leaf_angle_fractions,
        structure_status.leaf_clumping_factor,
    )
    beam = if solar_status.astronomical_daylight
        result = beam_extinction(
            structure_status.leaf_angle_class_centres_rad,
            structure_status.leaf_angle_fractions,
            structure_status.leaf_clumping_factor,
            solar_status.sun_zenith_rad,
        )
        (
            beam_extinction_coefficient=result.coefficient,
            beam_extinction_by_leaf_angle=result.by_leaf_angle,
            beam_extinction_available=true,
        )
    else
        (
            beam_extinction_coefficient=zero(T),
            beam_extinction_by_leaf_angle=zeros(
                T,
                length(structure_status.leaf_angle_class_centres_rad),
            ),
            beam_extinction_available=false,
        )
    end
    return merge(
        structure_status,
        PlantSimEngine.outputs_(physiology_model),
        _species_physiology_at(physiology_model, date50),
        (
            diffuse_zenith_class_centres_rad=diffuse_zeniths,
            diffuse_extinction_coefficients=diffuse_coefficients,
        ),
        beam,
    )
end

_initial_canopy_status(
    ::Nothing,
    ::Integer,
    ::SimulationConfig,
    ::Tuple,
    ::NamedTuple,
    ::NamedTuple,
) = NamedTuple()

_initial_stem_growth_status(
    ::Nothing,
    ::Integer,
    ::Bool,
    ::NamedTuple,
    ;
    date50::Integer=1,
) = NamedTuple()

function _initial_stem_growth_outputs(
    equation::AllometricEquation{T},
    efficiency::T,
    dimensions::NamedTuple,
    ;
    date50::Integer=1,
) where {T<:AbstractFloat}
    biomass = woody_biomass_trajectory(
        equation,
        dimensions.tree_height,
        dimensions.stem_diameter,
        zero(T);
        simulation_day=0,
    )
    respiration = growth_respiration(
        biomass.biomass_increment_g_dry_matter_tree_day,
        efficiency,
    )
    return (
        stem_growth_respiration_efficiency=efficiency,
        previous_woody_biomass_kg_dry_matter_tree=
            biomass.biomass_kg_dry_matter_tree,
        woody_biomass_kg_dry_matter_tree=
            biomass.biomass_kg_dry_matter_tree,
        woody_biomass_increment_g_dry_matter_tree_day=
            biomass.biomass_increment_g_dry_matter_tree_day,
        woody_biomass_trajectory_available=true,
        growth_respiration_mol_co2_tree_day=
            respiration.growth_respiration_mol_co2_tree_day,
        positive_biomass_increment=respiration.positive_biomass_increment,
        growth_respiration_date50=_growth_respiration_date50(date50),
        growth_respiration_available=true,
    )
end

function _initial_stem_growth_status(
    species_set::SpeciesSet{T},
    species_id::Integer,
    is_target::Bool,
    dimensions::NamedTuple,
    ;
    date50::Integer=1,
) where {T<:AbstractFloat}
    is_target || return NamedTuple()
    dimensions.stem_diameter_available || return NamedTuple()
    equation = species_set[species_id].structure.allometry.trunk
    woody_respiration = species_set[species_id].physiology.woody_respiration
    efficiency = woody_respiration.growth_respiration_efficiency
    return _initial_stem_growth_outputs(
        equation,
        efficiency,
        dimensions,
        ;
        date50,
    )
end

_initial_foliage_growth_status(
    ::Nothing,
    ::Integer,
    ::Bool,
    ::NamedTuple,
    ::NamedTuple;
    date50::Integer=1,
) = NamedTuple()

function _initial_foliage_growth_status(
    species_set::SpeciesSet{T},
    species_id::Integer,
    is_target::Bool,
    species_status::NamedTuple,
    canopy_status::NamedTuple;
    date50::Integer=1,
) where {T<:AbstractFloat}
    is_target || return NamedTuple()
    biomass = foliage_biomass_trajectory(
        canopy_status.leaf_area_by_layer,
        species_status.specific_leaf_area_m2_kg,
        species_status.physiological_foliage_age_proportions,
        zero(T);
        simulation_day=0,
        specific_leaf_area_available=
            species_status.specific_leaf_area_available,
    )
    efficiency = species_set[
        species_id
    ].physiology.leaf_respiration.growth_respiration_efficiency
    respiration = growth_respiration(
        biomass.biomass_increment_g_dry_matter_tree_day,
        efficiency,
    )
    return (
        previous_foliage_biomass_kg_dry_matter_tree=
            biomass.biomass_kg_dry_matter_tree,
        foliage_biomass_kg_dry_matter_tree=
            biomass.biomass_kg_dry_matter_tree,
        foliage_biomass_increment_g_dry_matter_tree_day=
            biomass.biomass_increment_g_dry_matter_tree_day,
        foliage_biomass_trajectory_available=true,
        growth_respiration_mol_co2_tree_day=
            respiration.growth_respiration_mol_co2_tree_day,
        positive_biomass_increment=respiration.positive_biomass_increment,
        growth_respiration_date50=_growth_respiration_date50(date50),
        growth_respiration_available=true,
    )
end

_initial_stem_woody_respiration_status(
    ::Nothing,
    ::Integer,
    ::Bool,
    ::NamedTuple,
    ::NamedTuple,
    ::Integer,
) = NamedTuple()

function _initial_stem_woody_respiration_outputs(
    parameters::WoodyRespirationParameters{T},
    dimensions::NamedTuple,
    woody_biomass_kg_dry_matter_tree::T,
    date50::Integer,
) where {T<:AbstractFloat}
    trajectory_model = MAESPAWoodyRespirationTrajectory(parameters)
    trajectory_model.active || return NamedTuple()
    trajectory = woody_respiration_trajectory(trajectory_model, date50)
    rate_model = MAESPAWoodyRespirationRate(parameters)
    rate = if rate_model.mode == 0
        woody_respiration_rate(
            rate_model;
            configured_woody_respiration_rate_umol_per_unit_s=
                trajectory.configured_woody_respiration_rate_umol_per_unit_s,
        )
    elseif rate_model.mode == 1
        woody_respiration_rate(
            rate_model;
            stem_diameter_m=dimensions.stem_diameter,
        )
    else
        woody_respiration_rate(
            rate_model;
            stem_diameter_m=dimensions.stem_diameter,
            tree_height_m=dimensions.tree_height,
            woody_biomass_kg_dry_matter_tree=
                woody_biomass_kg_dry_matter_tree,
        )
    end
    return (
        configured_woody_respiration_rate_umol_per_unit_s=
            trajectory.configured_woody_respiration_rate_umol_per_unit_s,
        temperature_response_coefficient_c_inverse=
            trajectory.temperature_response_coefficient_c_inverse,
        woody_respiration_parameters_available=true,
        base_respiration_rate_umol_per_unit_s=
            rate.base_respiration_rate_umol_per_unit_s,
        stem_surface_area_m2=rate.stem_surface_area_m2,
        woody_respiration_rate_recalculated=rate.rate_recalculated,
        woody_respiration_rate_available=true,
    )
end

function _initial_stem_woody_respiration_status(
    species_set::SpeciesSet{T},
    species_id::Integer,
    is_target::Bool,
    dimensions::NamedTuple,
    stem_growth_status::NamedTuple,
    date50::Integer,
) where {T<:AbstractFloat}
    is_target || return NamedTuple()
    dimensions.stem_diameter_available || return NamedTuple()
    parameters = species_set[species_id].physiology.woody_respiration
    return _initial_stem_woody_respiration_outputs(
        parameters,
        dimensions,
        stem_growth_status.woody_biomass_kg_dry_matter_tree,
        date50,
    )
end

function _initial_structural_biomass_outputs(
    equation::AllometricEquation{T},
    dimensions::NamedTuple,
) where {T<:AbstractFloat}
    biomass = woody_biomass_trajectory(
        equation,
        dimensions.tree_height,
        dimensions.stem_diameter,
        zero(T);
        simulation_day=0,
    )
    return (
        previous_woody_biomass_kg_dry_matter_tree=
            biomass.biomass_kg_dry_matter_tree,
        woody_biomass_kg_dry_matter_tree=
            biomass.biomass_kg_dry_matter_tree,
        woody_biomass_increment_g_dry_matter_tree_day=
            biomass.biomass_increment_g_dry_matter_tree_day,
        woody_biomass_trajectory_available=true,
    )
end

function _initial_branch_system_status(
    species_set::SpeciesSet{T},
    species_id::Integer,
    dimensions::NamedTuple,
    ;
    date50::Integer=1,
) where {T<:AbstractFloat}
    species = species_set[Int(species_id)]
    biomass = _initial_structural_biomass_outputs(
        species.structure.allometry.branches,
        dimensions,
    )
    respiration = species.physiology.branch_respiration
    growth_efficiency =
        species.physiology.woody_respiration.growth_respiration_efficiency
    growth = growth_respiration(
        biomass.woody_biomass_increment_g_dry_matter_tree_day,
        growth_efficiency,
    )
    return (
        structural_respiration_compartment_role=:branch_system,
        biomass...,
        branch_growth_respiration_efficiency=growth_efficiency,
        branch_base_respiration_rate_umol_per_kg_dry_matter_s=
            respiration.base_respiration_rate_umol_per_kg_dry_matter_s,
        branch_temperature_response_coefficient_c_inverse=
            respiration.temperature_response_coefficient_c_inverse,
        growth_respiration_mol_co2_tree_day=
            growth.growth_respiration_mol_co2_tree_day,
        positive_biomass_increment=growth.positive_biomass_increment,
        growth_respiration_date50=_growth_respiration_date50(date50),
        growth_respiration_available=true,
        acclimated_base_respiration_umol_per_unit_s=zero(T),
        specific_respiration_umol_per_unit_s=zero(T),
        maintenance_respiration_umol_s=zero(T),
        maintenance_respiration_temperature_active=false,
        maintenance_respiration_available=false,
    )
end

function _initial_root_structural_status(
    species_set::SpeciesSet{T},
    species_id::Integer,
    dimensions::NamedTuple,
) where {T<:AbstractFloat}
    species = species_set[Int(species_id)]
    biomass = _initial_structural_biomass_outputs(
        species.structure.allometry.roots,
        dimensions,
    )
    partition = root_biomass_partition(
        biomass.woody_biomass_kg_dry_matter_tree,
        biomass.woody_biomass_increment_g_dry_matter_tree_day;
        fine_root_fraction=species.structure.allometry.fine_root_fraction,
    )
    return (
        biomass...,
        fine_root_biomass_kg_dry_matter_tree=
            partition.fine_root_biomass_kg_dry_matter_tree,
        coarse_root_biomass_kg_dry_matter_tree=
            partition.coarse_root_biomass_kg_dry_matter_tree,
        fine_root_biomass_increment_g_dry_matter_tree_day=
            partition.fine_root_biomass_increment_g_dry_matter_tree_day,
        coarse_root_biomass_increment_g_dry_matter_tree_day=
            partition.coarse_root_biomass_increment_g_dry_matter_tree_day,
        root_biomass_partition_available=true,
    )
end

function _initial_root_pool_status(
    species_set::SpeciesSet{T},
    species_id::Integer,
    kind::Symbol,
    ;
    date50::Integer=1,
) where {T<:AbstractFloat}
    kind in (:fine_root, :coarse_root) || throw(
        ArgumentError("root-pool kind must be :fine_root or :coarse_root"),
    )
    physiology = species_set[Int(species_id)].physiology
    root_respiration = physiology.root_respiration
    fine = kind === :fine_root
    growth_efficiency = fine ?
                        physiology.leaf_respiration.growth_respiration_efficiency :
                        physiology.woody_respiration.growth_respiration_efficiency
    base_rate = fine ?
                root_respiration.fine_root_base_respiration_rate_umol_per_kg_dry_matter_s :
                root_respiration.coarse_root_base_respiration_rate_umol_per_kg_dry_matter_s
    pool_parameters = if fine
        (
            fine_root_growth_respiration_efficiency=growth_efficiency,
            fine_root_base_respiration_rate_umol_per_kg_dry_matter_s=
                base_rate,
        )
    else
        (
            coarse_root_growth_respiration_efficiency=growth_efficiency,
            coarse_root_base_respiration_rate_umol_per_kg_dry_matter_s=
                base_rate,
        )
    end
    return (
        structural_respiration_compartment_role=kind,
        root_pool_kind=kind,
        pool_parameters...,
        root_temperature_response_coefficient_c_inverse=
            root_respiration.temperature_response_coefficient_c_inverse,
        growth_respiration_mol_co2_tree_day=zero(T),
        positive_biomass_increment=false,
        growth_respiration_date50=_growth_respiration_date50(date50),
        growth_respiration_available=true,
        acclimated_base_respiration_umol_per_unit_s=zero(T),
        specific_respiration_umol_per_unit_s=zero(T),
        maintenance_respiration_umol_s=zero(T),
        maintenance_respiration_temperature_active=false,
        maintenance_respiration_available=false,
    )
end

function _initial_canopy_status(
    species_set::SpeciesSet{T},
    species_id::Integer,
    config::SimulationConfig{T},
    tree_position::NTuple{3,T},
    dimensions::NamedTuple,
    species_status::NamedTuple,
) where {T<:AbstractFloat}
    sampling = crown_quadrature(
        tree_position[1],
        tree_position[2],
        tree_position[3],
        dimensions.radius_x,
        dimensions.radius_y,
        dimensions.crown_depth,
        dimensions.crown_base_height,
        species_status.crown_shape_code,
        config.canopy_layers,
        config.points_per_layer,
    )
    distribution = if species_status.leaf_density_legacy_mode == 0
        uniform_leaf_area_distribution(
            sampling.representative_volumes,
            sampling.physiological_layers,
            dimensions.leaf_area,
            species_status.physiological_foliage_age_proportions,
            species_status.leaf_density_legacy_mode,
            config.canopy_layers,
        )
    else
        beta_leaf_area_distribution(
            sampling.representative_volumes,
            sampling.physiological_layers,
            dimensions.leaf_area,
            species_status.leaf_density_coefficients,
            species_status.structural_foliage_age_proportions,
            species_status.physiological_foliage_age_proportions,
            species_status.leaf_density_legacy_mode,
            config.canopy_layers,
            config.points_per_layer,
        )
    end
    return merge(sampling, distribution)
end

