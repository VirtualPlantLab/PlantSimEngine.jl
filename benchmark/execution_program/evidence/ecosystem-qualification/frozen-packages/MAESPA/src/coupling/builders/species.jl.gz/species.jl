# Shared species parameter applications and PlantSimEngine templates.

_configured_species_name(config::SimulationConfig, species_index::Int) =
    species_index <= length(config.species_names) ? config.species_names[species_index] : ""

function _species_symbols(config::SimulationConfig)
    symbols = Symbol[]
    for species_index in 1:config.species_count
        name = strip(_configured_species_name(config, species_index))
        candidate = isempty(name) ? Symbol("species_", species_index) : Symbol(name)
        candidate in symbols && (candidate = Symbol(candidate, "_", species_index))
        push!(symbols, candidate)
    end
    return symbols
end

function _species_parameter_modelspecs(
    species::SpeciesConfig{T},
    config::SimulationConfig{T},
    structure_clock,
) where {T<:AbstractFloat}
    date_input = PlantSimEngine.One(
        scale=:Scene,
        within=PlantSimEngine.Ancestor(scale=:Scene),
        application=:legacy_calendar,
        var=:date50,
    )
    structure_input(variable) = PlantSimEngine.One(
        within=PlantSimEngine.Self(),
        application=:species_structure,
        var=variable,
    )
    physiology_input(variable) = PlantSimEngine.One(
        within=PlantSimEngine.Self(),
        application=:species_physiology,
        var=variable,
    )
    crown_geometry_input(variable) = PlantSimEngine.One(
        within=PlantSimEngine.Self(),
        application=:crown_geometry,
        var=variable,
    )
    canopy_sampling_input(variable) = PlantSimEngine.One(
        within=PlantSimEngine.Self(),
        application=:canopy_sampling,
        var=variable,
    )
    plant_status_input(variable) = PlantSimEngine.One(
        scale=:Plant,
        within=PlantSimEngine.Ancestor(scale=:Plant),
        var=variable,
        from_status=true,
    )
    solar_input(variable) = PlantSimEngine.One(
        scale=:Scene,
        within=PlantSimEngine.Ancestor(scale=:Scene),
        application=:solar_geometry,
        var=variable,
    )
    leaf_density = species.structure.leaf_density
    physiological_age_count =
        species.physiology.age_classes.physiological_count
    leaf_area_distribution_model, leaf_area_distribution_inputs = if leaf_density.legacy_mode == 0
        (
            MAESPAUniformLeafAreaDistribution(
                T,
                config.canopy_layers,
                config.points_per_layer,
                physiological_age_count,
            ),
            (
                representative_volumes=canopy_sampling_input(
                    :representative_volumes,
                ),
                physiological_layers=canopy_sampling_input(
                    :physiological_layers,
                ),
                leaf_area=crown_geometry_input(:leaf_area),
                physiological_age_proportions=physiology_input(
                    :physiological_foliage_age_proportions,
                ),
                leaf_density_legacy_mode=structure_input(
                    :leaf_density_legacy_mode,
                ),
            ),
        )
    else
        (
            MAESPABetaLeafAreaDistribution(
                T,
                config.canopy_layers,
                config.points_per_layer,
                leaf_density.leaf_age_count,
                physiological_age_count,
            ),
            (
                representative_volumes=canopy_sampling_input(
                    :representative_volumes,
                ),
                physiological_layers=canopy_sampling_input(
                    :physiological_layers,
                ),
                leaf_area=crown_geometry_input(:leaf_area),
                leaf_density_coefficients=structure_input(
                    :leaf_density_coefficients,
                ),
                structural_foliage_age_proportions=physiology_input(
                    :structural_foliage_age_proportions,
                ),
                physiological_foliage_age_proportions=physiology_input(
                    :physiological_foliage_age_proportions,
                ),
                leaf_density_legacy_mode=structure_input(
                    :leaf_density_legacy_mode,
                ),
            ),
        )
    end
    return (
        PlantSimEngine.ModelSpec(
            MAESPASpeciesStructureTrajectory(species.structure);
            name=:species_structure,
            on=PlantSimEngine.One(scale=:Crown),
            every=structure_clock,
            inputs=(date50=date_input,),
        ),
        PlantSimEngine.ModelSpec(
            MAESPASpeciesPhysiologyTrajectory(species.physiology);
            name=:species_physiology,
            on=PlantSimEngine.One(scale=:Crown),
            every=structure_clock,
            inputs=(date50=date_input,),
        ),
        PlantSimEngine.ModelSpec(
            MAESPADiffuseExtinction(T, config.zenith_angles);
            name=:diffuse_extinction,
            on=PlantSimEngine.One(scale=:Crown),
            every=structure_clock,
            inputs=(
                leaf_angle_class_centres_rad=structure_input(
                    :leaf_angle_class_centres_rad,
                ),
                leaf_angle_fractions=structure_input(:leaf_angle_fractions),
                leaf_clumping_factor=structure_input(:leaf_clumping_factor),
            ),
        ),
        PlantSimEngine.ModelSpec(
            MAESPABeamExtinction(T);
            name=:beam_extinction,
            on=PlantSimEngine.One(scale=:Crown),
            inputs=(
                leaf_angle_class_centres_rad=structure_input(
                    :leaf_angle_class_centres_rad,
                ),
                leaf_angle_fractions=structure_input(:leaf_angle_fractions),
                leaf_clumping_factor=structure_input(:leaf_clumping_factor),
                sun_zenith_rad=solar_input(:sun_zenith_rad),
                astronomical_daylight=solar_input(:astronomical_daylight),
            ),
        ),
        PlantSimEngine.ModelSpec(
            MAESPACanopySampling(
                T,
                config.canopy_layers,
                config.points_per_layer,
            );
            name=:canopy_sampling,
            on=PlantSimEngine.One(scale=:Crown),
            every=structure_clock,
            inputs=(
                tree_x_m=plant_status_input(:tree_x_m),
                tree_y_m=plant_status_input(:tree_y_m),
                tree_z_m=plant_status_input(:tree_z_m),
                radius_x=crown_geometry_input(:radius_x),
                radius_y=crown_geometry_input(:radius_y),
                crown_depth=crown_geometry_input(:crown_depth),
                crown_base_height=crown_geometry_input(:crown_base_height),
                crown_shape_code=structure_input(:crown_shape_code),
            ),
        ),
        PlantSimEngine.ModelSpec(
            leaf_area_distribution_model;
            name=:leaf_area_distribution,
            on=PlantSimEngine.One(scale=:Crown),
            every=structure_clock,
            inputs=leaf_area_distribution_inputs,
        ),
    )
end

"""Build one shared PlantSimEngine template for each configured species."""
function maespa_species_templates(
    config::SimulationConfig{T},
    scene::LegacyTreeScene{T},
    ;
    structure_clock=PlantSimEngine.ClockSpec(config.steps_per_day, 1),
    species_set=nothing,
) where {T<:AbstractFloat}
    if !isnothing(species_set)
        species_set isa SpeciesSet{T} || throw(
            ArgumentError("species inputs and tree scene must use the same numeric type"),
        )
        length(species_set) == config.species_count || throw(
            DimensionMismatch("species input count does not match NSPECIES"),
        )
        getfield.(species_set.species, :id) == collect(1:config.species_count) || throw(
            ArgumentError("species input identifiers must follow configured species order"),
        )
        getfield.(species_set.species, :name) == [
            _configured_species_name(config, index) for index in 1:config.species_count
        ] || throw(
            ArgumentError("species input names do not match the simulation configuration"),
        )
        if !_is_native_species_set(species_set)
        getfield.(species_set.species, :configured_structure_file) ==
        config.structure_files || throw(
            ArgumentError("species STR files do not match the simulation configuration"),
        )
        getfield.(species_set.species, :configured_physiology_file) ==
        config.physiology_files || throw(
            ArgumentError("species PHY files do not match the simulation configuration"),
        )
        expected_structure_paths, expected_physiology_paths = _species_input_paths(
            species_set.root,
            config,
            species_set.plot,
            :legacy,
        )
        getfield.(species_set.species, :structure_path) == expected_structure_paths || throw(
            ArgumentError("species STR paths are inconsistent with SpeciesSet root/plot"),
        )
        getfield.(species_set.species, :physiology_path) ==
        expected_physiology_paths || throw(
            ArgumentError("species PHY paths are inconsistent with SpeciesSet root/plot"),
        )
        end
    end
    dimensions = MAESPATreeDimensions(scene.trajectories)
    target_area = MAESPATargetLeafArea(T)
    crown_geometry = MAESPACrownGeometry(T)
    stem_geometry = MAESPAStemGeometry(
        T,
        !isnothing(scene.trajectories.stem_diameter),
    )
    species_symbols = _species_symbols(config)
    return [
        PlantSimEngine.CompositeModelTemplate(
            (
                PlantSimEngine.ModelSpec(
                    dimensions;
                    name=:tree_dimensions,
                    on=PlantSimEngine.One(scale=:Plant),
                    every=structure_clock,
                    inputs=(
                        date50=PlantSimEngine.One(
                            scale=:Scene,
                            within=PlantSimEngine.Ancestor(scale=:Scene),
                            application=:legacy_calendar,
                            var=:date50,
                        ),
                        tree_index=PlantSimEngine.One(
                            within=PlantSimEngine.Self(),
                            var=:tree_index,
                            from_status=true,
                        ),
                    ),
                ),
                (
                    isnothing(species_set) ?
                    () :
                    _species_parameter_modelspecs(
                        species_set[species_index],
                        config,
                        structure_clock,
                    )
                )...,
                PlantSimEngine.ModelSpec(
                    target_area;
                    name=:target_leaf_area,
                    on=PlantSimEngine.One(scale=:Crown),
                    every=structure_clock,
                    inputs=(
                        leaf_area=PlantSimEngine.One(
                            within=PlantSimEngine.Self(),
                            application=:crown_geometry,
                            var=:leaf_area,
                        ),
                        target_weight=PlantSimEngine.One(
                            scale=:Plant,
                            within=PlantSimEngine.Ancestor(scale=:Plant),
                            var=:target_weight,
                            from_status=true,
                        ),
                    ),
                ),
                PlantSimEngine.ModelSpec(
                    crown_geometry;
                    name=:crown_geometry,
                    on=PlantSimEngine.One(scale=:Crown),
                    every=structure_clock,
                    inputs=(
                        plant_radius_x=PlantSimEngine.One(
                            scale=:Plant,
                            within=PlantSimEngine.Ancestor(scale=:Plant),
                            application=:tree_dimensions,
                            var=:radius_x,
                        ),
                        plant_radius_y=PlantSimEngine.One(
                            scale=:Plant,
                            within=PlantSimEngine.Ancestor(scale=:Plant),
                            application=:tree_dimensions,
                            var=:radius_y,
                        ),
                        plant_crown_depth=PlantSimEngine.One(
                            scale=:Plant,
                            within=PlantSimEngine.Ancestor(scale=:Plant),
                            application=:tree_dimensions,
                            var=:crown_depth,
                        ),
                        plant_crown_base_height=PlantSimEngine.One(
                            scale=:Plant,
                            within=PlantSimEngine.Ancestor(scale=:Plant),
                            application=:tree_dimensions,
                            var=:crown_base_height,
                        ),
                        plant_tree_height=PlantSimEngine.One(
                            scale=:Plant,
                            within=PlantSimEngine.Ancestor(scale=:Plant),
                            application=:tree_dimensions,
                            var=:tree_height,
                        ),
                        plant_leaf_area=PlantSimEngine.One(
                            scale=:Plant,
                            within=PlantSimEngine.Ancestor(scale=:Plant),
                            application=:tree_dimensions,
                            var=:leaf_area,
                        ),
                    ),
                ),
                PlantSimEngine.ModelSpec(
                    stem_geometry;
                    name=:stem_geometry,
                    on=PlantSimEngine.One(scale=:Stem),
                    every=structure_clock,
                    inputs=(
                        plant_crown_base_height=PlantSimEngine.One(
                            scale=:Plant,
                            within=PlantSimEngine.Ancestor(scale=:Plant),
                            application=:tree_dimensions,
                            var=:crown_base_height,
                        ),
                        plant_stem_diameter=PlantSimEngine.One(
                            scale=:Plant,
                            within=PlantSimEngine.Ancestor(scale=:Plant),
                            application=:tree_dimensions,
                            var=:stem_diameter,
                        ),
                        plant_stem_diameter_available=PlantSimEngine.One(
                            scale=:Plant,
                            within=PlantSimEngine.Ancestor(scale=:Plant),
                            application=:tree_dimensions,
                            var=:stem_diameter_available,
                        ),
                    ),
                ),
            );
            species=species_symbols[species_index],
            parameters=(
                species_id=species_index,
                species_name=_configured_species_name(config, species_index),
            ),
        ) for species_index in 1:config.species_count
    ]
end

_initial_species_crown_status(
    ::Nothing,
    ::Integer,
    ::Integer,
    ::SimulationConfig,
    ::NamedTuple,
) = NamedTuple()
