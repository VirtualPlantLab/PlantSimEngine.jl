# User-facing orchestration only. Equations and configuration checks remain
# owned by the existing models, parser and scenario constructor.
function _maespa_run_length(config::SimulationConfig, steps, model_options::NamedTuple)
    date = get(model_options, :date, config.start_date.days_since_1950)
    step_index = get(model_options, :step_index, 1)
    offset = _executed_step_offset(config, date, step_index)
    elapsed_days = config.end_date.days_since_1950 - config.start_date.days_since_1950
    visited_days = div(elapsed_days, config.source_day_stride) + 1
    configured_steps = visited_days * config.steps_per_day
    remaining = configured_steps - offset
    isnothing(steps) && return remaining
    steps isa Integer && !(steps isa Bool) ||
        throw(ArgumentError("steps must be a nonnegative integer or nothing"))
    0 <= steps <= remaining || throw(ArgumentError(
        "steps=$steps exceeds the allowed range 0:$remaining from the requested start"))
    return Int(steps)
end

_maespa_stop_on_empty(::Nothing) = false
_maespa_stop_on_empty(soil::SoilConfig) =
    soil.options.simulate_storage == 1 && !isnothing(soil.plant_storage) &&
    soil.plant_storage.stop_simulation_when_empty == 1

# Resolve the accepted-store protocol once at the runner boundary. Only an
# actual Plant storage publisher with canonical local Bool outputs can stop
# this run; incidental status fields or stream-only diagnostics cannot.
function _maespa_storage_stop_targets(model)
    any(spec -> PlantSimEngine.process(spec) === :plant_water_storage,
        model.applications) || return PlantSimEngine.ObjectId[]
    ports = (:plant_water_storage_stop_requested,
        :plant_water_storage_available, :plant_water_storage_initialized)
    plants = Set(id.value for id in PlantSimEngine.resolve_object_ids(
        model, PlantSimEngine.Many(scale=:Plant)))
    applications = PlantSimEngine.Diagnostics.explain_applications(model)
    writers = PlantSimEngine.Diagnostics.explain_writers(model)
    schedule = PlantSimEngine.Diagnostics.explain_schedule(model)
    targets = PlantSimEngine.ObjectId[]
    for application in applications
        application.process === :plant_water_storage || continue
        any(entry -> entry.application_id === application.application_id &&
            !entry.manual_call_only && entry.dt_steps == 1, schedule) || continue
        all(port -> port in application.local_outputs, ports) || continue
        declaration = model.applications[application.application_slot]
        instance = declaration isa PlantSimEngine.ModelSpec ? declaration.model : declaration
        schema = PlantSimEngine.Authoring.model_interface(instance).outputs
        all(port -> get(schema, port, nothing) isa Bool, ports) || continue
        for id in application.target_ids
            id in plants || continue
            canonical = all(ports) do port
                any(writers) do writer
                    isequal(writer.object_id, id) && writer.variable === port &&
                        length(writer.application_ids) == 1 &&
                        only(writer.application_ids) === application.application_id
                end
            end
            canonical && push!(targets, PlantSimEngine.ObjectId(id))
        end
    end
    return unique!(targets)
end

_maespa_accepted_storage_stop(state) =
    state.plant_water_storage_available === true &&
    state.plant_water_storage_initialized === true &&
    state.plant_water_storage_stop_requested === true

function _run_maespa_model(model, count, config, start_offset;
    stop_on_empty=false, outputs=:none, kwargs...)
    (!stop_on_empty || count == 0) &&
        return PlantSimEngine.run!(model; steps=count, outputs, kwargs...)
    targets = _maespa_storage_stop_targets(model)
    isempty(targets) && return PlantSimEngine.run!(model; steps=count, outputs, kwargs...)

    # Fortran latches ABORTSIMULATION inside the target/hour loops, but only
    # consumes it before starting another day. Complete every model of the
    # current day, and never extend a caller's explicit step upper bound.
    simulation = PlantSimEngine.run!(model; steps=1, outputs, kwargs...)
    stop_requested = false
    for executed in 1:count
        executed > 1 && PlantSimEngine.step!(simulation)
        stop_requested |= any(targets) do id
            _maespa_accepted_storage_stop(PlantSimEngine.final_state(simulation, id))
        end
        if stop_requested && mod(start_offset + executed, config.steps_per_day) == 0
            break
        end
    end
    return simulation
end

"""
    run_maespa(input::LegacyInputSet; steps=nothing, outputs=:none,
               model_options=(;), kwargs...)
    run_maespa(config::SimulationConfig, scene::LegacyTreeScene; kwargs...)
    run_maespa(path::AbstractString; read_options=(;), kwargs...)

Assemble MAESPA and return a PlantSimEngine `Simulation`. The directory form
first calls [`read_maespa`](@ref). The native Julia form takes a configuration
and tree scene; pass species, weather and soil through `model_options`.

Keyword ownership is explicit:

- `read_options` are forwarded only to `read_maespa` (directory form).
- `model_options` are forwarded to [`build_model`](@ref), including
  `leaf_models`, `leaf_composition`, `type_promotion`, `date` and `step_index`.
- `outputs` and other `kwargs` are forwarded to `PlantSimEngine.run!`.

Leaf exchange is enabled by default. Set
`model_options=(mount_leaf_exchange=false,)` explicitly for a partial scenario.
A parsed header without tree trajectories otherwise raises an error; it is
never silently presented as a complete canopy simulation. Existing builder
errors for missing inputs or unsupported options are preserved.

With `steps=nothing`, execute through the final step of the last visited source
day on or before `config.end_date`, starting at `model_options.date`/`step_index`
when supplied. `source_day_stride` selects days from the configured start;
it never enlarges the physical timestep. A later start must be on that lattice. An
explicit `steps` may shorten that interval, including zero for initialization,
but may not exceed it. This wrapper does not extend weather or invent forcing.
`PlantSimEngine.continue!` advances the returned simulation on the same timeline.

With effective soil options `SIMSTORE=1` and `STOPSIMONEMPTY=1`, latch an
accepted target-plant storage stop request and finish the current configured
day before returning, without exceeding `steps`. Zero steps only initializes.
Direct `PlantSimEngine.run!` or subsequent `continue!` remains manual execution;
the returned `Simulation` does not carry a persistent MAESPA stopping policy.
No storage recharge, clamp or physiological feedback is introduced.

Only final states are retained by default. Supply `OutputRequest`s through
`outputs` for the histories you need; inspect them with `collect_outputs` and
use `final_state` for current states. No legacy output files are written.
For model inspection or composition changes before execution, call
`build_model` and `PlantSimEngine.run!` separately instead.
"""
function run_maespa(
    input::LegacyInputSet;
    steps=nothing,
    outputs=:none,
    model_options::NamedTuple=NamedTuple(),
    kwargs...,
)
    count = _maespa_run_length(input.config, steps, model_options)
    options = merge((mount_leaf_exchange=true,), model_options)
    if isnothing(input.tree_scene)
        options.mount_leaf_exchange && throw(ArgumentError(
            "run_maespa requires tree trajectories for leaf exchange; " *
            "supply complete inputs or explicitly set model_options=(mount_leaf_exchange=false,)"))
        # The Scene-only builder has no leaf-exchange option.
        options = Base.structdiff(options, (mount_leaf_exchange=nothing,))
    end
    model = build_model(input; options...)
    date = get(options, :date, input.config.start_date.days_since_1950)
    start_offset = _executed_step_offset(input.config, date, get(options, :step_index, 1))
    return _run_maespa_model(model, count, input.config, start_offset;
        stop_on_empty=_maespa_stop_on_empty(get(options, :soil, input.soil)),
        outputs, kwargs...)
end

function run_maespa(
    config::SimulationConfig,
    scene::LegacyTreeScene;
    steps=nothing,
    outputs=:none,
    model_options::NamedTuple=NamedTuple(),
    kwargs...,
)
    count = _maespa_run_length(config, steps, model_options)
    options = merge((mount_leaf_exchange=true,), model_options)
    model = build_model(config, scene; options...)
    date = get(options, :date, config.start_date.days_since_1950)
    start_offset = _executed_step_offset(config, date, get(options, :step_index, 1))
    return _run_maespa_model(model, count, config, start_offset;
        stop_on_empty=_maespa_stop_on_empty(get(options, :soil, nothing)),
        outputs, kwargs...)
end

function run_maespa(path::AbstractString; read_options::NamedTuple=NamedTuple(), kwargs...)
    input = read_maespa(path; read_options...)
    return run_maespa(input; kwargs...)
end
