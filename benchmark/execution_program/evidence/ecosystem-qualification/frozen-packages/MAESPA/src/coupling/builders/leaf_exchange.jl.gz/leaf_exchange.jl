# Leaf-exchange controllers, their child applications, and mount validation.

function _non_tuzet_root_system_input(application::Symbol, variable::Symbol)
    return PlantSimEngine.One(
        scale=:RootSystem,
        kind=:root_system,
        within=PlantSimEngine.SelfPlant(),
        application=application,
        var=variable,
    )
end

const _TUZET_LOGICAL_LEAF_CALL_NAMES = (:energy_balance, :stomatal_coupling, :stomatal_response)

_tuzet_logical_leaf_scope_name(tree_id::Integer) =
    Symbol("crown_", Int(tree_id))

function _tuzet_logical_leaf_application_name(
    call_name::Symbol,
    tree_id::Integer,
)
    call_name in _TUZET_LOGICAL_LEAF_CALL_NAMES || throw(
        ArgumentError("unknown Tuzet logical-leaf call name $(call_name)"),
    )
    return Symbol("logical_leaf_", call_name, "_", Int(tree_id))
end

function _tuzet_logical_leaf_child_models(
    controller,
)
    return (
        energy_balance=MAESPACoupledLeafEnergyBalance(controller),
        stomatal_coupling=MAESPALeafPhotosynthesis(controller.capacity_model,
            MAESPAAnalyticalPhotosynthesis(controller.stomatal_model), controller.hydraulic_constraint_model),
        stomatal_response=maespa_stomatal_response(controller.stomatal_model),
    )
end

function _selected_leaf_models(defaults, replacements::NamedTuple)
    unknown = setdiff(keys(replacements), keys(defaults))
    isempty(unknown) || throw(ArgumentError("unknown leaf-model roles: $unknown"))
    for (role, replacement) in pairs(replacements)
        validation = PlantSimEngine.Authoring.validate_model(replacement)
        validation.valid || throw(ArgumentError(
            "leaf model `$role` has an invalid model boundary; inspect " *
            "PlantSimEngine.Authoring.validate_model for its diagnostics"))
        report = PlantSimEngine.Authoring.compare_models(getproperty(defaults, role), replacement)
        # This builder assembles a fresh scenario, not an Override of a compiled
        # application. A selected input default is intentional reconfiguration;
        # ports, types, contracts, dependencies and traits must still agree.
        changed_defaults_only = report.same_process && !isempty(report.differences) &&
            all(report.differences) do difference
                startswith(difference.path, "inputs.") &&
                    difference.left isa PlantSimEngine.Default &&
                    difference.right isa PlantSimEngine.Default &&
                    typeof(difference.left) === typeof(difference.right)
            end
        (report.override_compatible || changed_defaults_only) || throw(ArgumentError(
            "leaf model `$role` is not a compatible replacement; inspect " *
            "PlantSimEngine.Authoring.compare_models before reconfiguring this chain"))
    end
    return merge(defaults, replacements)
end

_species_leaf_models(models::NamedTuple, species_id) = models
_species_leaf_models(models::AbstractDict, species_id) = get(models, species_id, NamedTuple())

function _validate_leaf_model_selection(models, species_count, active)
    models isa Union{NamedTuple,AbstractDict} ||
        throw(ArgumentError("leaf_models must be a NamedTuple or a dictionary keyed by species id"))
    !active && !isempty(models) &&
        throw(ArgumentError("leaf_models requires mount_leaf_exchange=true"))
    if models isa AbstractDict
        for (species_id, replacements) in pairs(models)
            species_id isa Integer && !(species_id isa Bool) && 1 <= species_id <= species_count ||
                throw(ArgumentError("leaf_models contains an unknown species id: $species_id"))
            replacements isa NamedTuple ||
                throw(ArgumentError("leaf_models[$species_id] must be a NamedTuple of model roles"))
        end
    end
    return nothing
end

# A complete child graph is a separate assembly choice, not a relaxed model
# override. Factories run only while constructing a distinct physical Crown.
function _validate_leaf_composition_selection(composition, models, species_count, active)
    isnothing(composition) && return nothing
    active || throw(ArgumentError("leaf_composition requires mount_leaf_exchange=true"))
    isempty(models) || throw(ArgumentError("leaf_composition cannot be combined with nonempty leaf_models"))
    if composition isa AbstractDict
        for species_id in keys(composition)
            species_id isa Integer && !(species_id isa Bool) && 1 <= species_id <= species_count ||
                throw(ArgumentError("leaf_composition contains an unknown species id: $species_id"))
        end
    end
    return nothing
end

_species_leaf_composition(composition, species_id) = composition
_species_leaf_composition(composition::AbstractDict, species_id) = get(composition, species_id, nothing)

function _logical_leaf_composition_target(tree_id)
    return PlantSimEngine.Many(
        scale=:LogicalLeafUnit, kind=:logical_leaf_unit,
        within=PlantSimEngine.Scope(_tuzet_logical_leaf_scope_name(tree_id)),
    )
end

# Clone only the immutable mounting plan. All validated numerical parameter
# objects and scalar settings remain exactly those supplied to the factory.
function _with_leaf_trial_input_projection(
    c::MAESPANonTuzetCrownLeafExchangeController{T,C,S,H,N,B,P,W,E,U,R}, projection::Val,
) where {T,C,S,H,N,B,P,W,E,U,R}
    return MAESPANonTuzetCrownLeafExchangeController{T,C,S,H,N,B,P,W,E,U,R,typeof(projection)}(
        c.unit_count, c.maximum_iterations, c.capacity_model, c.stomatal_model,
        c.hydraulic_constraint_model, c.night_exchange_model, c.boundary_layer_model,
        c.penman_monteith_model, c.surface_water_partition_model,
        c.energy_balance_step_model, c.surface_state_update_model,
        c.maintenance_respiration_model, projection)
end

function _with_leaf_trial_input_projection(
    c::MAESPATuzetCrownLeafExchangeController{T,C,S,H,HC,N,B,P,W,E,U,R}, projection::Val,
) where {T,C,S,H,HC,N,B,P,W,E,U,R}
    return MAESPATuzetCrownLeafExchangeController{T,C,S,H,HC,N,B,P,W,E,U,R,typeof(projection)}(
        c.unit_count, c.maximum_iterations, c.maximum_hydraulic_iterations,
        c.hydraulic_lower_bound_mpa, c.hydraulic_upper_bound_mpa,
        c.hydraulic_candidate_tolerance_mpa, c.hydraulic_residual_tolerance_mpa,
        c.flux_window_seconds, c.standard_atmospheric_pressure_pa,
        c.capacity_model, c.stomatal_model, c.hydraulic_constraint_model,
        c.hydraulic_closure_model, c.night_exchange_model, c.boundary_layer_model,
        c.penman_monteith_model, c.surface_water_partition_model,
        c.energy_balance_step_model, c.surface_state_update_model,
        c.maintenance_respiration_model, projection)
end

function _resolve_leaf_composition(controller::Union{MAESPANonTuzetCrownLeafExchangeController{T},
    MAESPATuzetCrownLeafExchangeController{T}}, factory, tree_id, species_id, environment) where {T}
    isnothing(factory) && return nothing
    on = _logical_leaf_composition_target(tree_id)
    energy_application = _tuzet_logical_leaf_application_name(:energy_balance, tree_id)
    context = (; controller, tree_id, species_id, on, environment, energy_application)
    applicable(factory, context) || throw(ArgumentError("leaf_composition must be callable with its mounting context"))
    result = factory(context)
    result isa NamedTuple && Set(keys(result)) == Set((:applications, :scratch_seeds)) ||
        throw(ArgumentError("leaf_composition must return exactly (applications=..., scratch_seeds=...)"))
    result.applications isa Tuple && all(spec -> spec isa PlantSimEngine.ModelSpec, result.applications) ||
        throw(ArgumentError("leaf_composition applications must be a tuple of PlantSimEngine.ModelSpecs"))
    result.scratch_seeds isa NamedTuple ||
        throw(ArgumentError("leaf_composition scratch_seeds must be a NamedTuple"))
    names = map(spec -> spec.name, result.applications)
    all(name -> name isa Symbol, names) && allunique(names) ||
        throw(ArgumentError("leaf_composition applications require unique explicit names"))
    count(==(energy_application), names) == 1 ||
        throw(ArgumentError("leaf_composition requires exactly one energy application named $energy_application"))
    for spec in result.applications
        isequal(spec.applies_to, on) || throw(ArgumentError(
            "leaf_composition applications must use the supplied context.on target"))
        PlantSimEngine.Authoring.validate_model(spec.model).valid ||
            throw(ArgumentError("leaf_composition contains an invalid model boundary: $(spec.name)"))
    end
    native_children = _tuzet_logical_leaf_child_models(controller)
    energy = only(spec.model for spec in result.applications if spec.name === energy_application)
    comparison = PlantSimEngine.Authoring.compare_models(native_children.energy_balance, energy)
    comparison.same_process && all(difference -> startswith(difference.path, "dependencies."), comparison.differences) ||
        throw(ArgumentError("leaf_composition energy must preserve the Crown energy boundary; only its declared dependencies may differ"))
    scratch = _tuzet_logical_leaf_unit_scratch_status(T, 1, 1, 1, 1)
    reserved = Set(keys(scratch))
    native_inputs = Symbol[]
    for child in values(native_children)
        append!(native_inputs, PlantSimEngine.inputs(child))
    end
    unique!(native_inputs)
    union!(reserved, native_inputs)
    # A factory seed must not turn this physical Crown driver into a constant,
    # including on a non-Tuzet graph where the Crown supplies no such value.
    push!(reserved, :candidate_leaf_water_potential_mpa)
    collisions = sort!(collect(intersect(reserved, keys(result.scratch_seeds))); by=string)
    isempty(collisions) || throw(ArgumentError(
        "leaf_composition scratch_seeds collide with existing leaf identity or forcing fields: $collisions"))
    selected_inputs = Set{Symbol}()
    for spec in result.applications
        declared_inputs = PlantSimEngine.inputs(spec.model)
        union!(selected_inputs, declared_inputs)
        if controller isa MAESPATuzetCrownLeafExchangeController &&
           :candidate_leaf_water_potential_mpa in declared_inputs
            contract = get(PlantSimEngine.variable_contracts(spec.model),
                :candidate_leaf_water_potential_mpa, nothing)
            expected = LEAF_WATER_POTENTIAL_CONTRACT
            matching = !isnothing(contract) && all((:unit, :basis, :temporal, :aggregation, :extent)) do field
                isequal(getproperty(contract, field), getproperty(expected, field))
            end
            matching || throw(ArgumentError(
                "leaf_composition application `$(spec.name)` must declare " *
                "`candidate_leaf_water_potential_mpa=LEAF_WATER_POTENTIAL_CONTRACT` " *
                "with all five fields; received $(repr(contract))"))
        end
    end
    candidate_selected = controller isa MAESPATuzetCrownLeafExchangeController &&
        :candidate_leaf_water_potential_mpa in selected_inputs
    candidate_selected && push!(native_inputs, :candidate_leaf_water_potential_mpa)
    # Only Crown-supplied inputs consumed by the selected graph are written.
    # Fresh Required inputs still need a declared producer or explicit seed;
    # resolving their sources and contracts remains the PSE compiler's job.
    names = Tuple(name for name in native_inputs if name in selected_inputs)
    mounted_controller = _with_leaf_trial_input_projection(controller, Val(names))
    seeds = deepcopy(result.scratch_seeds)
    if candidate_selected
        # Assembly-owned storage only. Every active trial and accepted replay
        # overwrites this non-physical startup sentinel with the actual candidate.
        seeds = merge(seeds, (candidate_leaf_water_potential_mpa=T(NaN),))
    end
    # Non-Tuzet graphs get neither automatic storage nor a projected driver.
    # An unprovided Required input remains the compiler's error; an explicitly
    # declared producer or a model's own Default remains an honest alternative.
    # Keep caller-selected routing: libraries can require shared canonical
    # fields across their declared hard calls, unlike MAESPA's private outputs.
    return (; controller=mounted_controller, applications=result.applications,
        scratch_seeds=seeds)
end

function _native_leaf_compositions(config::SimulationConfig{T}, scene, targets,
    species_set, soil, meteorology, composition) where {T}
    isnothing(composition) && return nothing
    selected = unique(targets)
    tree_by_id = Dict(tree.id => tree for tree in scene.trees)
    any(tree_id -> !isnothing(_species_leaf_composition(composition, tree_by_id[tree_id].species_id)), selected) ||
        return Dict{Int,Any}()
    _validate_non_tuzet_leaf_exchange_mount(config, soil, meteorology, species_set, selected, tree_by_id)
    bundles = Dict{Int,Any}()
    for tree_id in selected
        species_id = tree_by_id[tree_id].species_id
        factory = _species_leaf_composition(composition, species_id)
        isnothing(factory) && continue
        species = species_set[species_id]
        points = config.canopy_layers * config.points_per_layer
        slots = _leaf_partition_slot_count(length(species.structure.leaf_angles.angles_rad))
        units = _logical_leaf_layout_unit_count(points, slots, species.physiology.age_classes.physiological_count)
        controller = _leaf_exchange_controller(T, config, species.physiology, units)
        bundles[Int(tree_id)] = _resolve_leaf_composition(controller, factory, tree_id, species_id,
            PlantSimEngine.Environment(provider=:canopy))
    end
    return bundles
end

function _tuzet_logical_leaf_unit_scratch_status(
    ::Type{T},
    unit_index::Integer,
    point_index::Integer,
    class_index::Integer,
    age_index::Integer,
) where {T<:AbstractFloat}
    z = zero(T)
    return (
        logical_leaf_unit_index=Int(unit_index),
        logical_leaf_point_index=Int(point_index),
        logical_leaf_radiation_class_index=Int(class_index),
        logical_leaf_physiological_age_index=Int(age_index),
        leaf_temperature_c=z,
        jmax25_umol_m2_s=z, vcmax25_umol_m2_s=z, rd0_umol_m2_s=z,
        leaf_respiration_temperature_coefficient_c_inverse=z,
        weighted_soil_water_potential_mpa=z,
        absorbed_par_umol_m2_s=z, surface_co2_umol_mol=z,
        quantum_yield=z, stomatal_g0=z, stomatal_g1=z,
        stomatal_g20=z, stomatal_g21=z,
        minimum_stomatal_conductance_mol_co2_m2_s=z,
        stomatal_co2_compensation_point_umol_mol=z, minimum_vpd_pa=z,
        soil_water_stomatal_modifier=one(T), hydraulic_stomatal_factor=one(T),
        astronomical_daylight=false, second_stomatal_curve=false,
        leaf_radiative_forcing_available=false,
        photosynthetic_capacity_inputs_available=false,
        characteristic_leaf_width_m=z, stomatal_sides=1,
        saturation_vapour_pressure_slope_pa_k=z, latent_heat_vaporization_j_mol=z,
        dry_canopy_fraction=one(T), canopy_surface_water_storage_mm=z,
        leaf_net_radiation_w_m2=z, relative_wind_speed=z,
        relative_diffuse_penetration=z, diffuse_transmittance_up=z,
        diffuse_transmittance_down=z,
        night_stomatal_conductance_mol_co2_m2_s=z,
        maximum_leaf_transpiration_mmol_m2_leaf_s=z,
    )
end

function _validate_tuzet_logical_leaf_scratch_status(status, child_models)
    missing = Symbol[]
    for child_model in values(child_models)
        for (name, declaration) in pairs(PlantSimEngine.inputs_(child_model))
            declaration isa PlantSimEngine.Required || continue
            haskey(status, name) || push!(missing, name)
        end
    end
    isempty(missing) || throw(
        ArgumentError(
            "Tuzet LogicalLeafUnit scratch status is missing Required child " *
            "inputs $(Tuple(sort!(unique!(missing))))",
        ),
    )
    return status
end

function _stream_only_outputs(model)
    names = keys(PlantSimEngine.outputs_(model))
    return NamedTuple{names}(ntuple(_ -> :stream_only, length(names)))
end

_tuzet_logical_leaf_stream_only_outputs(model) =
    _stream_only_outputs(model)

function _tuzet_logical_leaf_call_selector(
    tree_id::Integer,
    call_name::Symbol,
)
    return PlantSimEngine.Many(
        scale=:LogicalLeafUnit,
        kind=:logical_leaf_unit,
        within=PlantSimEngine.Subtree(),
        application=_tuzet_logical_leaf_application_name(call_name, tree_id),
    )
end

function _tuzet_logical_leaf_child_modelspecs(
    controller::Union{MAESPATuzetCrownLeafExchangeController{T},
        MAESPANonTuzetCrownLeafExchangeController{T}},
    tree_id::Integer;
    leaf_models::NamedTuple=NamedTuple(),
    environment=nothing,
    leaf_composition=nothing,
) where {T<:AbstractFloat}
    isnothing(leaf_composition) || return leaf_composition.applications
    child_models = _selected_leaf_models(_tuzet_logical_leaf_child_models(controller), leaf_models)
    scratch = _tuzet_logical_leaf_unit_scratch_status(T, 1, 1, 1, 1)
    _validate_tuzet_logical_leaf_scratch_status(scratch, child_models)
    target = PlantSimEngine.Many(
        scale=:LogicalLeafUnit,
        kind=:logical_leaf_unit,
        within=PlantSimEngine.Scope(
            _tuzet_logical_leaf_scope_name(tree_id),
        ),
    )
    return Tuple(
        PlantSimEngine.ModelSpec(
            getproperty(child_models, call_name);
            name=_tuzet_logical_leaf_application_name(call_name, tree_id),
            on=target,
            environment,
            output_routing=_tuzet_logical_leaf_stream_only_outputs(
                getproperty(child_models, call_name),
            ),
        ) for call_name in keys(child_models)
    )
end

function _leaf_process_calls(controller, tree_id)
    roles = keys(PlantSimEngine.dep(controller))
    return NamedTuple{roles}(map(role -> _tuzet_logical_leaf_call_selector(tree_id, role), roles))
end

function _non_tuzet_leaf_exchange_modelspecs(
    controller::Union{
        MAESPANonTuzetCrownLeafExchangeController{T},
        MAESPATuzetCrownLeafExchangeController{T},
    },
    target::Integer,
    target_name::Symbol,
    layout_application::Symbol,
    unit_count::Integer,
    layer_count::Integer,
    point_count::Integer,
    ;
    mount_canopy_air_iteration::Bool=false,
    leaf_models::NamedTuple=NamedTuple(),
    leaf_composition=nothing,
) where {T<:AbstractFloat}
    is_tuzet = controller isa MAESPATuzetCrownLeafExchangeController
    controller_application = Symbol(
        is_tuzet ?
        "tuzet_crown_leaf_exchange_controller_" :
        "non_tuzet_crown_leaf_exchange_controller_",
        target,
    )
    respiration_accounting_application =
        Symbol("crown_leaf_respiration_accounting_", target)
    aggregation_application =
        Symbol("crown_leaf_exchange_aggregation_", target)
    thermal_snapshot_application =
        Symbol("crown_leaf_thermal_snapshot_", target)
    thermodynamic_application =
        Symbol("leaf_thermodynamic_forcing_", target)
    daylight_application = Symbol("leaf_exchange_daylight_", target)

    layout_input(variable) =
        _radiation_self_application_input(layout_application, variable)
    controller_input(variable) =
        _radiation_self_application_input(controller_application, variable)
    respiration_accounting_input(variable) =
        _radiation_self_application_input(
            respiration_accounting_application,
            variable,
        )
    thermodynamic_input(variable) =
        _radiation_self_application_input(thermodynamic_application, variable)
    species_input(variable) =
        _radiation_target_input(target, :species_physiology, variable)
    scene_input(application, variable) =
        _radiation_scene_application_input(application, variable)
    air_environment = PlantSimEngine.Environment(provider=:canopy)
    root_input(application, variable) =
        _non_tuzet_root_system_input(application, variable)

    controller_specific_inputs = if is_tuzet
        (
            tuzet_crown_leaf_exchange_controller_inputs_available=scene_input(
                :canopy_surface_water_forcing,
                :pstransp_canopy_surface_water_forcing_available,
            ),
        )
    else
        (
            emax_non_tuzet_constraint_active=
                _radiation_scene_status_input(
                    :emax_non_tuzet_constraint_active,
                ),
            non_tuzet_crown_leaf_exchange_controller_inputs_available=
                scene_input(
                    :canopy_surface_water_forcing,
                    :pstransp_canopy_surface_water_forcing_available,
                ),
        )
    end
    controller_outputs = if is_tuzet
        (
            net_assimilation=
                :accepted_logical_leaf_net_assimilation_umol_co2_m2_s,
            rd=:accepted_logical_leaf_rd_umol_m2_s,
            actual_transpiration=
                :accepted_logical_leaf_actual_transpiration_umol_h2o_m2_s,
            transpiration_deficit=
                :accepted_logical_leaf_transpiration_deficit_mmol_h2o_m2_s,
            wet_evaporation=
                :accepted_logical_leaf_actual_wet_surface_evaporation_umol_h2o_m2_s,
            sensible_heat=:accepted_logical_leaf_sensible_heat_flux_w_m2,
            stomatal_conductance=
                :accepted_logical_leaf_stomatal_conductance_co2_mol_m2_s,
            boundary_layer_conductance=
                :accepted_logical_leaf_boundary_layer_heat_conductance_mol_m2_s,
            leaf_temperature=:accepted_logical_leaf_temperature_c,
            intercellular_co2=
                :accepted_logical_leaf_intercellular_co2_umol_mol,
            leaf_water_potential=
                :accepted_logical_leaf_water_potential_mpa,
            available=:tuzet_crown_leaf_exchange_controller_available,
        )
    else
        (
            net_assimilation=
                :non_tuzet_accepted_logical_leaf_net_assimilation_umol_co2_m2_s,
            rd=:non_tuzet_accepted_logical_leaf_rd_umol_m2_s,
            actual_transpiration=
                :non_tuzet_accepted_logical_leaf_actual_transpiration_umol_h2o_m2_s,
            transpiration_deficit=
                :non_tuzet_accepted_logical_leaf_transpiration_deficit_mmol_h2o_m2_s,
            wet_evaporation=
                :non_tuzet_accepted_logical_leaf_actual_wet_surface_evaporation_umol_h2o_m2_s,
            sensible_heat=
                :non_tuzet_accepted_logical_leaf_sensible_heat_flux_w_m2,
            stomatal_conductance=
                :non_tuzet_accepted_logical_leaf_stomatal_conductance_co2_mol_m2_s,
            boundary_layer_conductance=
                :non_tuzet_accepted_logical_leaf_boundary_layer_heat_conductance_mol_m2_s,
            leaf_temperature=
                :non_tuzet_accepted_logical_leaf_temperature_c,
            intercellular_co2=
                :non_tuzet_accepted_logical_leaf_intercellular_co2_umol_mol,
            leaf_water_potential=
                :non_tuzet_accepted_logical_leaf_water_potential_mpa,
            available=:non_tuzet_crown_leaf_exchange_controller_available,
        )
    end

    controller_spec = PlantSimEngine.ModelSpec(
        controller;
        name=controller_application,
        environment=air_environment,
        on=PlantSimEngine.One(scale=:Crown, id=target_name),
        calls=_leaf_process_calls(controller, target),
        inputs=merge(
            (
            logical_leaf_unit_active=layout_input(:logical_leaf_unit_active),
            logical_leaf_unit_forcing_available=layout_input(
                :logical_leaf_unit_forcing_available,
            ),
            logical_leaf_absorbed_par_umol_m2_s=layout_input(
                :logical_leaf_absorbed_par_umol_m2_s,
            ),
            logical_leaf_net_radiation_w_m2=layout_input(
                :logical_leaf_net_radiation_w_m2,
            ),
            logical_leaf_relative_diffuse_penetration=layout_input(
                :logical_leaf_relative_diffuse_penetration,
            ),
            logical_leaf_diffuse_transmittance_up=layout_input(
                :logical_leaf_diffuse_transmittance_up,
            ),
            logical_leaf_diffuse_transmittance_down=layout_input(
                :logical_leaf_diffuse_transmittance_down,
            ),
            logical_leaf_relative_wind_speed=layout_input(
                :logical_leaf_relative_wind_speed,
            ),
            logical_leaf_jmax25_umol_m2_s=layout_input(
                :logical_leaf_jmax25_umol_m2_s,
            ),
            logical_leaf_vcmax25_umol_m2_s=layout_input(
                :logical_leaf_vcmax25_umol_m2_s,
            ),
            logical_leaf_rd0_umol_m2_s=layout_input(
                :logical_leaf_rd0_umol_m2_s,
            ),
            logical_leaf_quantum_yield=layout_input(
                :logical_leaf_quantum_yield,
            ),
            latent_heat_vaporization_j_mol=thermodynamic_input(
                :latent_heat_vaporization_j_mol,
            ),
            saturation_vapour_pressure_slope_pa_k=thermodynamic_input(
                :saturation_vapour_pressure_slope_pa_k,
            ),
            leaf_respiration_temperature_coefficient_c_inverse=species_input(
                :leaf_respiration_temperature_coefficient_c_inverse,
            ),
            minimum_stomatal_conductance_mol_co2_m2_s=species_input(
                :minimum_stomatal_conductance_mol_co2_m2_s,
            ),
            night_stomatal_conductance_mol_co2_m2_s=species_input(
                :night_stomatal_conductance_mol_co2_m2_s,
            ),
            stomatal_g0=species_input(:stomatal_g0),
            stomatal_g1=species_input(:stomatal_g1),
            stomatal_g20=species_input(:stomatal_g20),
            stomatal_g21=species_input(:stomatal_g21),
            co2_compensation_point_umol_mol=species_input(
                :co2_compensation_point_umol_mol,
            ),
            minimum_vpd_pa=species_input(:minimum_vpd_pa),
            characteristic_leaf_width_m=species_input(
                :characteristic_leaf_width_m,
            ),
            stomatal_sides=species_input(:stomatal_sides),
            second_stomatal_curve=species_input(:second_stomatal_curve),
            weighted_soil_water_potential_mpa=root_input(
                :root_water_uptake,
                :weighted_soil_water_potential_mpa,
            ),
            soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa=root_input(
                :soil_to_leaf_hydraulic_supply,
                :soil_to_leaf_hydraulic_conductance_mmol_m2_leaf_s_mpa,
            ),
            maximum_leaf_transpiration_mmol_m2_leaf_s=root_input(
                :soil_to_leaf_hydraulic_supply,
                :maximum_leaf_transpiration_mmol_m2_leaf_s,
            ),
            dry_canopy_fraction=scene_input(
                :canopy_surface_water_forcing,
                :pstransp_dry_canopy_fraction,
            ),
            canopy_surface_water_storage_mm=scene_input(
                :canopy_surface_water_forcing,
                :pstransp_canopy_surface_water_storage_mm,
            ),
            sun_zenith_rad=scene_input(:solar_geometry, :sun_zenith_rad),
            incident_par_w_m2=scene_input(
                :meteorology,
                :incident_par_w_m2,
            ),
            logical_leaf_area_total_m2=layout_input(
                :logical_leaf_area_total_m2,
            ),
            leaf_exchange_daylight=_radiation_self_application_input(
                daylight_application,
                :leaf_exchange_daylight,
            ),
            leaf_exchange_daylight_available=
                _radiation_self_application_input(
                    daylight_application,
                    :leaf_exchange_daylight_available,
                ),
            logical_leaf_unit_layout_available=layout_input(
                :logical_leaf_unit_layout_available,
            ),
            logical_leaf_forcing_available=layout_input(
                :logical_leaf_forcing_available,
            ),
            leaf_thermodynamic_forcing_available=thermodynamic_input(
                :leaf_thermodynamic_forcing_available,
            ),
            soil_to_leaf_hydraulic_supply_available=root_input(
                :soil_to_leaf_hydraulic_supply,
                :soil_to_leaf_hydraulic_supply_available,
            ),
            ),
            controller_specific_inputs,
        ),
    )

    respiration_accounting_spec = PlantSimEngine.ModelSpec(
        MAESPACrownLeafRespirationAccounting(
            T,
            unit_count;
            maintenance_respiration_model=
                controller.maintenance_respiration_model,
        );
        name=respiration_accounting_application,
        environment=air_environment,
        on=PlantSimEngine.One(scale=:Crown, id=target_name),
        inputs=(
            logical_leaf_unit_active=layout_input(
                :logical_leaf_unit_active,
            ),
            logical_leaf_rd0_umol_m2_s=layout_input(
                :logical_leaf_rd0_umol_m2_s,
            ),
            accepted_logical_leaf_rd_umol_m2_s=controller_input(
                controller_outputs.rd,
            ),
            leaf_respiration_temperature_coefficient_c_inverse=species_input(
                :leaf_respiration_temperature_coefficient_c_inverse,
            ),
            leaf_exchange_daylight=_radiation_self_application_input(
                daylight_application,
                :leaf_exchange_daylight,
            ),
            logical_leaf_unit_layout_available=layout_input(
                :logical_leaf_unit_layout_available,
            ),
            crown_leaf_exchange_controller_available=controller_input(
                controller_outputs.available,
            ),
            leaf_exchange_daylight_available=
                _radiation_self_application_input(
                    daylight_application,
                    :leaf_exchange_daylight_available,
                ),
        ),
    )

    thermal_snapshot_spec = PlantSimEngine.ModelSpec(
        MAESPACrownLeafThermalSnapshot(T, point_count);
        name=thermal_snapshot_application,
        environment=air_environment,
        on=PlantSimEngine.One(scale=:Crown, id=target_name),
        inputs=(
            logical_leaf_point_index=layout_input(
                :logical_leaf_point_index,
            ),
            logical_leaf_area_m2=layout_input(:logical_leaf_area_m2),
            logical_leaf_unit_active=layout_input(
                :logical_leaf_unit_active,
            ),
            logical_leaf_temperature_c=controller_input(
                controller_outputs.leaf_temperature,
            ),
            logical_leaf_unit_layout_available=layout_input(
                :logical_leaf_unit_layout_available,
            ),
            leaf_exchange_solution_available=controller_input(
                controller_outputs.available,
            ),
        ),
    )

    aggregation_spec = PlantSimEngine.ModelSpec(
        MAESPACrownLeafExchangeAggregation(
            T,
            unit_count,
            layer_count,
        );
        name=aggregation_application,
        on=PlantSimEngine.One(scale=:Crown, id=target_name),
        inputs=(
            logical_leaf_area_fraction=layout_input(
                :logical_leaf_area_fraction,
            ),
            logical_leaf_area_density=layout_input(:logical_leaf_area_density),
            logical_leaf_representative_volume_m3=layout_input(
                :logical_leaf_representative_volume_m3,
            ),
            logical_leaf_physiological_layer=layout_input(
                :logical_leaf_physiological_layer,
            ),
            net_assimilation_umol_co2_m2_s=controller_input(
                controller_outputs.net_assimilation,
            ),
            rd_umol_m2_s=respiration_accounting_input(
                :accounting_logical_leaf_rd_umol_m2_s,
            ),
            actual_transpiration_umol_h2o_m2_s=controller_input(
                controller_outputs.actual_transpiration,
            ),
            transpiration_supply_deficit_mmol_h2o_m2_s=controller_input(
                controller_outputs.transpiration_deficit,
            ),
            actual_wet_surface_evaporation_umol_h2o_m2_s=controller_input(
                controller_outputs.wet_evaporation,
            ),
            sensible_heat_flux_w_m2=controller_input(
                controller_outputs.sensible_heat,
            ),
            stomatal_conductance_co2_mol_m2_s=controller_input(
                controller_outputs.stomatal_conductance,
            ),
            boundary_layer_heat_conductance_mol_m2_s=controller_input(
                controller_outputs.boundary_layer_conductance,
            ),
            logical_leaf_temperature_c=controller_input(
                controller_outputs.leaf_temperature,
            ),
            intercellular_co2_umol_mol=controller_input(
                controller_outputs.intercellular_co2,
            ),
            leaf_water_potential_mpa=controller_input(
                controller_outputs.leaf_water_potential,
            ),
            crown_leaf_exchange_aggregation_inputs_available=
                respiration_accounting_input(
                    :crown_leaf_respiration_accounting_available,
                ),
        ),
    )
    child_specs = _tuzet_logical_leaf_child_modelspecs(controller, target;
        leaf_models, environment=air_environment, leaf_composition)
    return (
        child_specs...,
        controller_spec,
        thermal_snapshot_spec,
        respiration_accounting_spec,
        aggregation_spec,
    )
end

function _leaf_exchange_controller(::Type{T}, config::SimulationConfig,
    physiology::SpeciesPhysiologyConfig, unit_count::Integer) where {T<:AbstractFloat}
    surface_partition = MAESPALeafSurfaceWaterPartition(
        T;
        flux_window_seconds=convert(T, _base_step_seconds(config)),
    )
    return if config.stomatal_model == 6
        MAESPATuzetCrownLeafExchangeController(
            physiology,
            unit_count;
            maximum_leaf_temperature_iterations=
                config.leaf_temperature_iterations,
            surface_water_partition_model=surface_partition,
        )
    else
        MAESPANonTuzetCrownLeafExchangeController(
            physiology,
            unit_count;
            maximum_iterations=config.leaf_temperature_iterations,
            surface_water_partition_model=surface_partition,
        )
    end
end

function _non_tuzet_leaf_exchange_modelspecs(
    ::Type{T},
    config::SimulationConfig,
    physiology::SpeciesPhysiologyConfig,
    target::Integer,
    target_name::Symbol,
    layout_application::Symbol,
    unit_count::Integer,
    ;
    mount_canopy_air_iteration::Bool=false,
    leaf_models::NamedTuple=NamedTuple(),
    leaf_composition=nothing,
) where {T<:AbstractFloat}
    controller = isnothing(leaf_composition) ?
        _leaf_exchange_controller(T, config, physiology, unit_count) : leaf_composition.controller
    return _non_tuzet_leaf_exchange_modelspecs(
        controller,
        target,
        target_name,
        layout_application,
        unit_count,
        config.canopy_layers,
        config.canopy_layers * config.points_per_layer,
        ;
        mount_canopy_air_iteration,
        leaf_models,
        leaf_composition,
    )
end

function _validate_non_tuzet_leaf_exchange_mount(
    config::SimulationConfig,
    soil,
    meteorology,
    species_set,
    target_ids,
    tree_by_id,
)
    isnothing(meteorology) && throw(
        ArgumentError("leaf exchange requires meteorology"),
    )
    isnothing(soil) && throw(
        ArgumentError("leaf exchange requires a Soil configuration"),
    )
    isnothing(species_set) && throw(
        ArgumentError("leaf exchange requires parsed species inputs"),
    )
    isempty(target_ids) && throw(
        ArgumentError("leaf exchange requires at least one target"),
    )
    config.stomatal_model in (2, 3, 4, 6) || throw(
        ArgumentError("leaf exchange supports MODELGS=2, 3, 4, or 6"),
    )
    isnothing(soil.root_parameters) && throw(
        ArgumentError("leaf exchange requires ROOTPARS"),
    )
    isnothing(soil.plant_hydraulics) && throw(
        ArgumentError("leaf exchange requires PLANTPARS"),
    )
    _root_water_uptake_active(soil) || throw(
        ArgumentError(
            "leaf exchange requires SPA or equal root uptake " *
            "(EQUALUPTAKE=0 or 1, resolved soil water, USEMEASET=0)",
        ),
    )
    for target in unique(target_ids)
        physiology = species_set[tree_by_id[target].species_id].physiology
        model = _stomatal_model(physiology.stomatal)
        model in (2, 3, 4, 6) || throw(
            ArgumentError(
                "target tree $target uses unsupported stomatal MODELGS=$model",
            ),
        )
        model == config.stomatal_model || throw(
            ArgumentError(
                "target tree $target stomatal model $model does not match " *
                "CONTROL.MODELGS=$(config.stomatal_model)",
            ),
        )
        isnothing(physiology.photosynthetic_capacity) && throw(
            ArgumentError(
                "target tree $target lacks fixed JMAX/VCMAX capacity parameters",
            ),
        )
    end
    return nothing
end
