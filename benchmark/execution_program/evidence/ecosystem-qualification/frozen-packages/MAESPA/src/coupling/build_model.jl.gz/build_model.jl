# Scenario assembly is organized by scientific domain. These files define
# applications and object builders; process equations live in src/processes/.
# The public build_model methods are in builders/scenario.jl.

include("builders/meteorology.jl")
include("builders/radiation_bindings.jl")

include("builders/growth_respiration.jl")
include("builders/woody_respiration.jl")
include("builders/respiration_aggregation.jl")

include("builders/longwave.jl")
include("builders/leaf_exchange.jl")
include("builders/stand_fluxes.jl")
include("builders/radiation.jl")
include("builders/sensor_radiation.jl")
include("builders/canopy_air.jl")

include("builders/roots.jl")
include("builders/soil_surface.jl")
include("builders/soil_heat_and_water.jl")
include("builders/soil_radiation.jl")
include("builders/soil_objects.jl")
include("builders/understorey.jl")

include("builders/species.jl")
include("builders/plant_initialization.jl")
include("builders/plant_objects.jl")
include("builders/scene_initialization.jl")
include("builders/applications.jl")
include("builders/scenario.jl")
