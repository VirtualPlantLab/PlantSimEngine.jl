# Soil-surface water and energy exchange applications.

function _soil_surface_water_flux_modelspecs(
    ::Type{T},
    config::SimulationConfig,
    soil,
    meteorology,
    species_set,
    targets,
    rooted_layer_count;
    mount_non_tuzet_leaf_exchange::Bool=false,
    root_water_uptake_active::Bool=false,
    mount_soil_heat_transfer::Bool=false,
    mount_canopy_air_iteration::Bool=false,
    mount_understorey_shortwave_reconciliation::Bool=false,
) where {T<:AbstractFloat}
    mount_non_tuzet_leaf_exchange || return ()

    isnothing(soil) && throw(
        ArgumentError("soil surface water fluxes require a Soil configuration"),
    )
    isnothing(meteorology) && throw(
        ArgumentError("soil surface water fluxes require meteorology"),
    )
    isnothing(species_set) && throw(
        ArgumentError("soil surface water fluxes require parsed species inputs"),
    )
    isempty(species_set) && throw(
        ArgumentError("soil surface water fluxes require at least one species"),
    )
    isempty(targets) && throw(
        ArgumentError("soil surface water fluxes require at least one target"),
    )
    (mount_canopy_air_iteration || config.canopy_air_iterations <= 1) || throw(
        ArgumentError(
            "soil surface water fluxes require ITERTAIRMAX <= 1",
        ),
    )
    soil.options.simulate_soil_temperature in (0, 1) || throw(
        ArgumentError("soil surface water fluxes require SIMTSOIL=0 or 1"),
    )
    soil.options.simulate_soil_evaporation in (0, 1) || throw(
        ArgumentError("soil surface water fluxes require SIMSOILEVAP=0 or 1"),
    )
    iszero(soil.options.use_measured_evapotranspiration) || throw(
        ArgumentError("soil surface water fluxes require USEMEASET=0"),
    )
    soil.options.keep_wet in (0, 1) || throw(ArgumentError("KEEPWET must be 0 or 1"))
    soil.options.use_stand in (0, 1, 2) || throw(
        ArgumentError("soil surface water fluxes require USESTAND=0, 1, or 2"),
    )
    root_water_uptake_active && _root_water_uptake_active(soil) || throw(
        ArgumentError(
            "soil surface water fluxes require an executable root-uptake branch",
        ),
    )
    isnothing(rooted_layer_count) && throw(
        ArgumentError(
            "soil surface water fluxes require a resolved rooted-layer count",
        ),
    )
    rooted_layer_count isa Integer && !(rooted_layer_count isa Bool) || throw(
        ArgumentError("rooted_layer_count must be an integer, not Bool"),
    )
    rooted_count = Int(rooted_layer_count)
    1 <= rooted_count <= soil.layers.layer_count || throw(
        DomainError(
            rooted_count,
            "rooted_layer_count must lie in 1:$(soil.layers.layer_count)",
        ),
    )
    soil.evaporation.minimum_dry_layer_thickness_m <=
    soil.layers.thickness_m[1] || throw(
        DomainError(
            soil.evaporation.minimum_dry_layer_thickness_m,
            "DRYTHICKMIN cannot exceed first-layer thickness",
        ),
    )

    soil_target = PlantSimEngine.One(scale=:Soil, kind=:soil)
    soil_application(application, variable) = PlantSimEngine.One(
        within=PlantSimEngine.Self(),
        application=application,
        var=variable,
    )
    scene_application(application, variable) = PlantSimEngine.One(
        scale=:Scene,
        within=PlantSimEngine.Ancestor(scale=:Scene),
        application=application,
        var=variable,
    )
    soil_status(variable) = PlantSimEngine.One(
        within=PlantSimEngine.Self(),
        var=variable,
        from_status=true,
    )
    first_layer_application(application, variable) = PlantSimEngine.One(
        scale=:SoilLayer,
        kind=:soil_layer,
        id=:soil_layer_1,
        within=PlantSimEngine.Subtree(),
        application=application,
        var=variable,
    )
    first_layer_status(variable) = PlantSimEngine.One(
        scale=:SoilLayer,
        kind=:soil_layer,
        id=:soil_layer_1,
        within=PlantSimEngine.Subtree(),
        var=variable,
        from_status=true,
    )
    first_layer_status_after(variable, application) = PlantSimEngine.One(
        scale=:SoilLayer,
        kind=:soil_layer,
        id=:soil_layer_1,
        within=PlantSimEngine.Subtree(),
        var=variable,
        from_status=true,
        after=application,
    )
    prepared(variable) = soil_application(
        :soil_surface_energy_forcing,
        variable,
    )
    accepted_shortwave_application =
        mount_understorey_shortwave_reconciliation ?
        :understorey_shortwave_reconciliation : :soil_shortwave_radiation
    accepted_soil_par_variable =
        mount_understorey_shortwave_reconciliation ?
        :reconciled_soil_absorbed_par_w_m2 : :soil_absorbed_par_w_m2
    accepted_soil_nir_variable =
        mount_understorey_shortwave_reconciliation ?
        :reconciled_soil_absorbed_nir_w_m2 : :soil_absorbed_nir_w_m2
    accepted_shortwave_availability =
        mount_understorey_shortwave_reconciliation ?
        :understorey_shortwave_reconciliation_available :
        :soil_shortwave_radiation_available
    deep_soil_node_temperature_input = if mount_soil_heat_transfer
        PlantSimEngine.PreviousTimeStep(
            :source_deep_soil_node_temperature_k,
        ) => soil_application(
            :soil_heat_transfer,
            :soil_first_profile_node_temperature_k,
        )
    else
        :source_deep_soil_node_temperature_k => soil_status(
            :configured_initial_deep_soil_node_temperature_k,
        )
    end

    thermal_reflectance =
        species_set[1].physiology.optics.soil_reflectance[3]
    forcing_model = MAESPASoilSurfaceEnergyForcing(
        soil;
        soil_thermal_reflectance=thermal_reflectance,
    )
    dry_thermal_conductivity =
        soil.evaporation.dry_layer_thermal_conductivity
    simulated_soil_temperature =
        soil.options.simulate_soil_temperature == 1
    surface_energy_application = simulated_soil_temperature ?
                                 :simulated_soil_surface_energy :
                                 :prescribed_soil_surface_energy
    surface_energy_model = if simulated_soil_temperature
        MAESPASoilSurfaceEnergyBalance(
            T;
            simulate_soil_evaporation=soil.options.simulate_soil_evaporation == 1,
            tortuosity=soil.evaporation.tortuosity,
            dry_layer_thermal_conductivity_w_m_k=
                dry_thermal_conductivity < zero(T) ? nothing :
                dry_thermal_conductivity,
        )
    else
        MAESPAPrescribedSoilSurfaceEnergyBalance(
            T;
            tortuosity=soil.evaporation.tortuosity,
            dry_layer_thermal_conductivity_w_m_k=
                dry_thermal_conductivity < zero(T) ? nothing :
                dry_thermal_conductivity,
        )
    end
    initial_temperature_nodes =
        _legacy_soil_temperature_nodes_c(soil.initial_state.temperature_c)
    initial_soil_surface_temperature_k =
        convert(T, initial_temperature_nodes.surface_temperature_c) +
        convert(T, 273.15)
    surface_temperature_state_model = if simulated_soil_temperature
        MAESPASoilSurfaceTemperatureState(
            T;
            initial_soil_surface_temperature_k,
        )
    else
        nothing
    end
    evaporation_model = MAESPASoilSurfaceEvaporation(soil.evaporation)
    dry_layer_model = MAESPASoilDryLayerState(soil.evaporation;
        keep_wet=soil.options.keep_wet == 1)
    partition_model = MAESPASoilWaterFluxPartition(
        T,
        soil.layers.layer_count;
        rooted_layer_count=rooted_count,
        species_count=config.species_count,
    )
    clock = PlantSimEngine.ClockSpec(1, 1)

    surface_water_input = if isnothing(soil.canopy_interception)
        scene_application(:meteorology, :precipitation_mm)
    else
        scene_application(:canopy_water_storage, :surface_water_mm)
    end
    dry_layer_inputs_available = if isnothing(soil.canopy_interception)
        soil_application(
            :soil_surface_evaporation,
            :soil_surface_evaporation_available,
        )
    else
        scene_application(
            :canopy_water_storage,
            :canopy_water_storage_available,
        )
    end
    # Conductance is already in m/s: use its owner directly. Routing this
    # same-name input through the forcing copy would alias that copy back onto
    # the producer on this Soil; resetting the copy would erase the source.
    surface_energy_inputs = if simulated_soil_temperature
        (
            air_temperature_k=prepared(:soil_energy_air_temperature_k),
            second_layer_temperature_k=prepared(
                :soil_energy_first_profile_node_temperature_k,
            ),
            vapour_pressure_deficit_kpa=prepared(
                :soil_energy_vapour_pressure_deficit_kpa,
            ),
            aerodynamic_conductance_m_s=soil_application(
                :soil_surface_aerodynamics,
                :aerodynamic_conductance_m_s,
            ),
            atmospheric_pressure_pa=prepared(
                :soil_energy_atmospheric_pressure_pa,
            ),
            first_layer_thermal_conductivity_w_m_k=prepared(
                :soil_energy_first_layer_thermal_conductivity_w_m_k,
            ),
            first_layer_thickness_m=prepared(
                :soil_energy_first_layer_thickness_m,
            ),
            first_layer_pore_fraction=prepared(
                :soil_energy_first_layer_pore_fraction,
            ),
            first_layer_soil_water_potential_mpa=prepared(
                :soil_energy_first_layer_soil_water_potential_mpa,
            ),
            soil_energy_previous_dry_layer_thickness_m=prepared(
                :soil_energy_previous_dry_layer_thickness_m,
            ),
            soil_thermal_reflectance=prepared(
                :soil_energy_thermal_reflectance,
            ),
            surface_absorbed_par_w_m2=prepared(
                :soil_energy_absorbed_par_w_m2,
            ),
            surface_absorbed_nir_w_m2=prepared(
                :soil_energy_absorbed_nir_w_m2,
            ),
            surface_downward_thermal_radiation_w_m2=prepared(
                :soil_energy_downward_thermal_radiation_w_m2,
            ),
            simulate_soil_dew=prepared(:soil_energy_simulate_soil_dew),
            soil_surface_energy_inputs_available=prepared(
                :soil_energy_forcing_available,
            ),
        )
    else
        (
            soil_temperature_k=prepared(
                :soil_energy_prescribed_temperature_k,
            ),
            air_temperature_k=prepared(:soil_energy_air_temperature_k),
            second_layer_temperature_k=prepared(
                :soil_energy_first_profile_node_temperature_k,
            ),
            vapour_pressure_deficit_kpa=prepared(
                :soil_energy_vapour_pressure_deficit_kpa,
            ),
            aerodynamic_conductance_m_s=soil_application(
                :soil_surface_aerodynamics,
                :aerodynamic_conductance_m_s,
            ),
            atmospheric_pressure_pa=prepared(
                :soil_energy_atmospheric_pressure_pa,
            ),
            first_layer_thermal_conductivity_w_m_k=prepared(
                :soil_energy_first_layer_thermal_conductivity_w_m_k,
            ),
            first_layer_thickness_m=prepared(
                :soil_energy_first_layer_thickness_m,
            ),
            first_layer_pore_fraction=prepared(
                :soil_energy_first_layer_pore_fraction,
            ),
            first_layer_soil_water_potential_mpa=prepared(
                :soil_energy_first_layer_soil_water_potential_mpa,
            ),
            soil_energy_previous_dry_layer_thickness_m=prepared(
                :soil_energy_previous_dry_layer_thickness_m,
            ),
            soil_thermal_reflectance=prepared(
                :soil_energy_thermal_reflectance,
            ),
            surface_absorbed_par_w_m2=prepared(
                :soil_energy_absorbed_par_w_m2,
            ),
            surface_absorbed_nir_w_m2=prepared(
                :soil_energy_absorbed_nir_w_m2,
            ),
            surface_downward_thermal_radiation_w_m2=prepared(
                :soil_energy_downward_thermal_radiation_w_m2,
            ),
            simulate_soil_temperature=prepared(
                :soil_energy_simulate_soil_temperature,
            ),
            simulate_soil_evaporation=prepared(
                :soil_energy_simulate_soil_evaporation,
            ),
            use_measured_evapotranspiration=prepared(
                :soil_energy_use_measured_evapotranspiration,
            ),
            simulate_soil_dew=prepared(:soil_energy_simulate_soil_dew),
            soil_surface_energy_inputs_available=prepared(
                :soil_energy_forcing_available,
            ),
        )
    end
    surface_energy_spec = PlantSimEngine.ModelSpec(
        surface_energy_model;
        name=surface_energy_application,
        on=soil_target,
        environment=PlantSimEngine.Environment(provider=:canopy),
        every=mount_canopy_air_iteration ? nothing : clock,
        inputs=surface_energy_inputs,
    )
    surface_temperature_state_specs = if simulated_soil_temperature
        (
            PlantSimEngine.ModelSpec(
                surface_temperature_state_model;
                name=:soil_surface_temperature_state,
                on=soil_target,
                every=clock,
                inputs=(
                    PlantSimEngine.PreviousTimeStep(
                        :previous_soil_surface_temperature_state_k,
                    ) => soil_application(
                        :soil_surface_temperature_state,
                        :soil_surface_temperature_state_k,
                    ),
                    PlantSimEngine.PreviousTimeStep(
                        :previous_soil_surface_temperature_state_initialized,
                    ) => soil_application(
                        :soil_surface_temperature_state,
                        :soil_surface_temperature_state_initialized,
                    ),
                    :candidate_soil_surface_temperature_k =>
                    soil.options.use_measured_soil_water == 1 ?
                    # Without HEATBALANCE, SOILTEMP(1) retains its initial
                    # value even though the current surface solve still runs.
                    soil_status(:configured_initial_soil_surface_temperature_k) : soil_application(
                        surface_energy_application,
                        # CRANKNICHOLS stores SOILTK in SOILTEMP(1). The next
                        # timestep's first canopy trial starts from that node,
                        # not the above-dry-layer ENERGYCALC diagnostic.
                        :soil_temperature_k,
                    ),
                    :candidate_soil_surface_energy_available => soil_application(
                        surface_energy_application,
                        :soil_surface_energy_available,
                    ),
                ),
            ),
        )
    else
        ()
    end
    active_soil_temperature_input = if simulated_soil_temperature
        soil_application(surface_energy_application, :soil_temperature_k)
    else
        prepared(:soil_energy_prescribed_temperature_k)
    end
    evaporation_inputs_available = if simulated_soil_temperature
        soil_application(
            surface_energy_application,
            :soil_surface_energy_available,
        )
    else
        prepared(:soil_energy_forcing_available)
    end
    prescribed_soil_temperature_inputs = if simulated_soil_temperature
        ()
    else
        (
            :source_prescribed_soil_temperature_c => scene_application(
                :meteorology,
                :soil_temperature_c,
            ),
            :source_prescribed_soil_temperature_available =>
                scene_application(
                    :meteorology,
                    :meteorology_reconstruction_available,
                ),
        )
    end

    return (
        PlantSimEngine.ModelSpec(
            forcing_model;
            name=:soil_surface_energy_forcing,
            environment=PlantSimEngine.Environment(provider=:canopy),
            on=soil_target,
            every=mount_canopy_air_iteration ? nothing : clock,
            inputs=(
                prescribed_soil_temperature_inputs...,
                (mount_canopy_air_iteration ? () : (
                    :atmosphere_ready => scene_application(:prescribed_canopy_atmosphere, :atmosphere_ready),
                ))...,
                deep_soil_node_temperature_input,
                :source_soil_aerodynamic_conductance_m_s => soil_application(
                    :soil_surface_aerodynamics,
                    :aerodynamic_conductance_m_s,
                ),
                :source_surface_layer_thermal_conductivity_w_m_k =>
                    first_layer_application(
                        :soil_thermal_properties,
                        :soil_thermal_conductivity_w_m_k,
                    ),
                PlantSimEngine.PreviousTimeStep(
                    :source_surface_layer_soil_water_potential_mpa,
                ) =>
                    first_layer_application(
                        :soil_hydraulic_properties,
                        :soil_water_potential_mpa,
                    ),
                PlantSimEngine.PreviousTimeStep(
                    :source_previous_dry_layer_thickness_m,
                ) => soil_application(
                    :soil_dry_layer_state,
                    :dry_layer_thickness_m,
                ),
                :source_absorbed_soil_par_w_m2 => soil_application(
                    accepted_shortwave_application,
                    accepted_soil_par_variable,
                ),
                :source_absorbed_soil_nir_w_m2 => soil_application(
                    accepted_shortwave_application,
                    accepted_soil_nir_variable,
                ),
                :source_downward_soil_thermal_radiation_w_m2 =>
                    soil_application(
                        :soil_longwave_radiation,
                        :downward_thermal_radiation_w_m2,
                    ),
                :source_deep_soil_node_temperature_available => soil_status(
                    :configured_initial_deep_soil_node_temperature_available,
                ),
                :source_soil_surface_aerodynamics_available => soil_application(
                    :soil_surface_aerodynamics,
                    :soil_surface_aerodynamics_available,
                ),
                :source_first_layer_thermal_properties_available =>
                    first_layer_status_after(
                        :soil_thermal_properties_available,
                        :soil_thermal_properties,
                    ),
                :source_first_layer_hydraulic_properties_available =>
                    first_layer_status(
                        :soil_hydraulic_properties_available,
                    ),
                :source_previous_soil_dry_layer_state_available => soil_status(
                    :configured_soil_dry_layer_state_seed_available,
                ),
                :source_soil_shortwave_radiation_available => soil_application(
                    accepted_shortwave_application,
                    accepted_shortwave_availability,
                ),
                :source_soil_longwave_radiation_available => soil_application(
                    :soil_longwave_radiation,
                    :soil_longwave_radiation_available,
                ),
            ),
        ),
        surface_energy_spec,
        surface_temperature_state_specs...,
        PlantSimEngine.ModelSpec(
            evaporation_model;
            name=:soil_surface_evaporation,
            on=soil_target,
            every=clock,
            inputs=(
                soil_temperature_k=active_soil_temperature_input,
                air_temperature_k=prepared(:soil_energy_air_temperature_k),
                vapour_pressure_deficit_kpa=prepared(
                    :soil_energy_vapour_pressure_deficit_kpa,
                ),
                pore_fraction=prepared(:soil_energy_first_layer_pore_fraction),
                soil_water_potential_mpa=prepared(
                    :soil_energy_first_layer_soil_water_potential_mpa,
                ),
                aerodynamic_conductance_m_s=soil_application(
                    :soil_surface_aerodynamics,
                    :aerodynamic_conductance_m_s,
                ),
                atmospheric_pressure_pa=prepared(
                    :soil_energy_atmospheric_pressure_pa,
                ),
                soil_energy_previous_dry_layer_thickness_m=prepared(
                    :soil_energy_previous_dry_layer_thickness_m,
                ),
                timestep_seconds=soil_status(:configured_timestep_seconds),
                simulate_soil_evaporation=prepared(
                    :soil_energy_simulate_soil_evaporation,
                ),
                use_measured_evapotranspiration=prepared(
                    :soil_energy_use_measured_evapotranspiration,
                ),
                simulate_soil_dew=prepared(:soil_energy_simulate_soil_dew),
                soil_surface_evaporation_inputs_available=
                    evaporation_inputs_available,
            ),
        ),
        PlantSimEngine.ModelSpec(
            dry_layer_model;
            name=:soil_dry_layer_state,
            on=soil_target,
            every=clock,
            inputs=(
                PlantSimEngine.PreviousTimeStep(
                    :previous_wetting_layer_top_m,
                ) => soil_application(
                    :soil_dry_layer_state,
                    :wetting_layer_top_m,
                ),
                PlantSimEngine.PreviousTimeStep(
                    :previous_wetting_layer_bottom_m,
                ) => soil_application(
                    :soil_dry_layer_state,
                    :wetting_layer_bottom_m,
                ),
                PlantSimEngine.PreviousTimeStep(
                    :previous_dry_layer_thickness_m,
                ) => soil_application(
                    :soil_dry_layer_state,
                    :dry_layer_thickness_m,
                ),
                PlantSimEngine.PreviousTimeStep(
                    :previous_soil_dry_layer_state_initialized,
                ) => soil_application(
                    :soil_dry_layer_state,
                    :soil_dry_layer_state_initialized,
                ),
                :surface_water_mm => surface_water_input,
                :snow_water_equivalent_m => soil_status(
                    :configured_snow_water_equivalent_m,
                ),
                :dry_layer_soil_temperature_k =>
                    active_soil_temperature_input,
                :latent_heat_flux_w_m2 => soil_application(
                    :soil_surface_evaporation,
                    :latent_heat_flux_w_m2,
                ),
                :first_layer_pore_fraction => prepared(
                    :soil_energy_first_layer_pore_fraction,
                ),
                :first_layer_thickness_m => prepared(
                    :soil_energy_first_layer_thickness_m,
                ),
                :timestep_seconds => soil_status(:configured_timestep_seconds),
                :soil_dry_layer_update_accepted => soil_application(
                    surface_energy_application,
                    :soil_surface_energy_available,
                ),
                :soil_dry_layer_inputs_available => dry_layer_inputs_available,
            ),
        ),
        PlantSimEngine.ModelSpec(
            partition_model;
            name=:soil_water_flux_partition,
            on=soil_target,
            every=clock,
            inputs=(
                soil_evaporation_mm_timestep=soil_application(
                    :soil_surface_evaporation,
                    :soil_evaporation_mm_timestep,
                ),
                dry_layer_thickness_m=soil_application(
                    :soil_dry_layer_state,
                    :dry_layer_thickness_m,
                ),
                first_layer_thickness_m=prepared(
                    :soil_energy_first_layer_thickness_m,
                ),
                use_measured_evapotranspiration=prepared(
                    :soil_energy_use_measured_evapotranspiration,
                ),
                evapotranspiration_by_species_mm=scene_application(
                    :stand_water_flux_scaling,
                    :evapotranspiration_by_species_mm,
                ),
                root_water_uptake_fractions_by_species=scene_application(
                    :root_water_uptake_species_aggregation,
                    :root_water_uptake_fractions_by_species,
                ),
                soil_surface_evaporation_available=soil_application(
                    :soil_surface_evaporation,
                    :soil_surface_evaporation_available,
                ),
                soil_dry_layer_state_available=soil_application(
                    :soil_dry_layer_state,
                    :soil_dry_layer_state_available,
                ),
                stand_water_flux_scaling_available=scene_application(
                    :stand_water_flux_scaling,
                    :stand_water_flux_scaling_available,
                ),
                root_water_uptake_species_aggregation_available=
                    scene_application(
                        :root_water_uptake_species_aggregation,
                        :root_water_uptake_species_aggregation_available,
                    ),
            ),
        ),
    )
end
