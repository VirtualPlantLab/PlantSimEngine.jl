# Sparse source-day preparation is orchestration, not a larger physical step.
# Keep source indices beside the private compact buffer; never apply the dense
# _meteorology_record_range mapping to that buffer or return it as a raw source.
function _sparse_meteorology_environment(
    meteorology::LegacyMeteorology{T};
    start_date, step_index::Integer, end_date, require_coverage::Bool,
    solar_geometry, rng::Random.AbstractRNG, keep_dry::Bool,
    reassign_rain::Bool, source_day_stride::Int, simulation_start_date,
) where {T<:AbstractFloat}
    source = meteorology.config
    steps = source.steps_per_day
    1 <= step_index <= steps || throw(BoundsError(1:steps, step_index))
    anchor = _meteorology_day50(simulation_start_date)
    requested_start = _meteorology_day50(start_date)
    elapsed = _source_day_offset(anchor, requested_start, source_day_stride)
    source_start = source.start_date.days_since_1950
    anchor >= source_start || throw(ArgumentError(
        "sparse meteorology requires the configured simulation-start rain prefix; " *
        "the meteorology begins after that anchor"))
    daily = source.frequency === DailyMeteorology
    complete_days = daily ? length(meteorology) : div(length(meteorology), steps)
    available_end = source_start + complete_days - 1
    requested_end = isnothing(end_date) ? available_end : _meteorology_day50(end_date)
    requested_end >= requested_start || throw(ArgumentError("end date precedes start date"))
    effective_end = require_coverage ? requested_end : min(requested_end, available_end)
    effective_end >= requested_start || throw(ArgumentError(
        "meteorology does not cover the requested visited day"))
    final_visit = anchor + div(effective_end - anchor, source_day_stride) * source_day_stride
    final_visit <= available_end || throw(ArgumentError(
        "meteorology does not cover a complete source day at date50=$final_visit"))
    visited_dates = collect(anchor:source_day_stride:final_visit)
    source_days = visited_dates .- source_start .+ 1
    raw_records = daily ? repeat(source_days; inner=steps) :
        [((day - 1) * steps + step) for day in source_days for step in 1:steps]
    prepared_count = length(visited_dates) * steps
    first_prepared_record = div(elapsed, source_day_stride) * steps + Int(step_index)
    records = first_prepared_record:prepared_count

    reconstruct_radiation = !daily &&
        !haskey(source.column_lookup, :global_radiation) &&
        !haskey(source.column_lookup, :incident_par_photons)
    needs_solar = daily || reconstruct_radiation
    if needs_solar
        isnothing(solar_geometry) && throw(ArgumentError(
            "daily or BRISTO meteorology requires solar_geometry::SolarGeometryConfig"))
        solar_geometry.steps_per_day == steps || throw(ArgumentError(
            "meteorology and solar geometry steps_per_day disagree"))
    end
    config = daily ? _expanded_daily_meteorology_config(source) :
        reconstruct_radiation ? _bristow_meteorology_config(source) : source
    reconstruct_radiation && isnothing(source.bristow) && throw(ArgumentError("missing BRISTO parameters"))
    if daily && haskey(source.column_lookup, :thermal_radiation)
        @warn "Daily RTHERM is ignored; thermal radiation is reconstructed as in GETMETDAY (source: $(source.source))" source=source.source
    end
    solar = if needs_solar
        MAESPASolarGeometry(SolarGeometryConfig(
            T(solar_geometry.latitude_rad), T(solar_geometry.time_difference_steps),
            T(solar_geometry.scene_bearing_rad), steps;
            solar_constant=T(solar_geometry.solar_constant),
            reference_astronomical_day=solar_geometry.reference_astronomical_day,
        ))
    else
        nothing
    end
    values = if daily
        Matrix{T}(undef, prepared_count, config.column_count)
    elseif reconstruct_radiation
        hcat(meteorology.values[raw_records, :], Vector{T}(undef, prepared_count))
    else
        copy(meteorology.values[raw_records, :])
    end
    controlled_rain = (keep_dry || reassign_rain) ? Vector{T}(undef, prepared_count) : nothing
    has_daily_rain = haskey(source.column_lookup, :precipitation)
    for (visit, day) in enumerate(source_days)
        rows = ((visit - 1) * steps + 1):(visit * steps)
        if daily
            # Source GETMETDAY skips the initial ASSIGNRAIN when PPT is absent;
            # the supported stride-1 wrapper intentionally keeps its old draws.
            _expand_daily_meteorology_day!(values, rows, meteorology, day, config, solar;
                rng, draw_rain=has_daily_rain)
        elseif reconstruct_radiation
            source_rows = ((day - 1) * steps + 1):(day * steps)
            temperature = @view meteorology_column(meteorology, :air_temperature)[source_rows]
            all(isfinite, temperature) || throw(ArgumentError("BRISTO air temperatures must be finite"))
            precipitation = meteorology_column(meteorology, :precipitation)
            isnothing(precipitation) || all(value -> isfinite(value) && value >= zero(T),
                @view(precipitation[source_rows])) || throw(ArgumentError(
                    "BRISTO precipitation must be finite and nonnegative"))
            values[rows, end] = _bristow_subdaily_radiation_day(meteorology, source_rows, solar)
        end
        if !isnothing(controlled_rain)
            precipitation_column = get(config.column_lookup, :precipitation, nothing)
            rain = isnothing(precipitation_column) ? zeros(T, steps) :
                copy(@view values[rows, precipitation_column])
            all(value -> isfinite(value) && value >= zero(T), rain) || throw(ArgumentError(
                "precipitation must be finite and nonnegative"))
            keep_dry && fill!(rain, zero(T))
            if reassign_rain
                total = sum(rain)
                isfinite(total) || throw(ArgumentError("daily precipitation total must be finite"))
                rain = _daily_rainfall(total, steps, rng)
            end
            controlled_rain[rows] = rain
        end
    end

    # This compact buffer is private. Explicit raw_records and actual dates
    # preserve provenance while contiguous storage means seven *visited* days.
    prepared = LegacyMeteorology(
        config, values, repeat(visited_dates; inner=steps),
        repeat(collect(1:steps), length(visited_dates)),
        isnothing(meteorology.declared_day) ? nothing : meteorology.declared_day[raw_records],
        daily || isnothing(meteorology.declared_step) ? nothing : meteorology.declared_step[raw_records],
        meteorology.source_lines[raw_records], copy(meteorology.diagnostics),
    )
    minimum_temperature, mean_temperature = _meteorology_daily_air_statistics(prepared)
    tmove = _meteorology_moving_average_air_temperature(prepared, records)
    consistency = _meteorology_block_day_consistency(prepared)
    rows = [_meteorology_environment_row(prepared, row,
        minimum_temperature, mean_temperature, tmove[index], consistency)
        for (index, row) in enumerate(records)]
    if !isnothing(controlled_rain)
        rows = [merge(row, (raw_precipitation=controlled_rain[index],))
            for (row, index) in zip(rows, records)]
    end
    metadata = (
        source=source.source,
        start_record=raw_records[first(records)],
        end_record=raw_records[last(records)],
        source_record_indices=raw_records[records],
        source_day_stride=source_day_stride,
        simulation_start_date50=anchor,
        frequency=:subdaily,
        units=(
            raw_air_temperature="degC",
            raw_moving_average_air_temperature="degC",
            raw_wind_speed="m s-1",
            raw_air_pressure="Pa",
            raw_precipitation="mm per step",
            raw_global_radiation="W m-2",
            raw_incident_par_photons="umol photons m-2 s-1",
        ),
    )
    return PlantMeteo.TimeStepTable(rows, metadata)
end
