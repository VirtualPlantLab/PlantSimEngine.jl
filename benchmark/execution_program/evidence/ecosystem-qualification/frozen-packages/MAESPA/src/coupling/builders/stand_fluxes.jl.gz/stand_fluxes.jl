# Stand radiation and water fluxes, storage, and surface-water forcing.

function _plant_water_storage_modelspecs(
    soil,
    targets;
    mount_non_tuzet_leaf_exchange::Bool=false,
)
    if !mount_non_tuzet_leaf_exchange ||
       isnothing(soil) ||
       soil.options.simulate_storage != 1
        return ()
    end
    isnothing(soil.plant_storage) && throw(
        ArgumentError(
            "SIMSTORE=1 requires parsed PLANTSTORAGE parameters",
        ),
    )

    target_ids = sort!(unique!(Int[target for target in targets]))
    isempty(target_ids) && return ()
    crown_aggregation(target, variable) = PlantSimEngine.One(
        scale=:Crown,
        kind=:crown,
        within=PlantSimEngine.SelfPlant(),
        application=Symbol("crown_leaf_exchange_aggregation_", target),
        var=variable,
    )

    return Tuple(
        maespa_plant_water_storage_modelspec(
            soil.plant_storage;
            name=Symbol("plant_water_storage_", target),
            on=PlantSimEngine.One(
                scale=:Plant,
                kind=:plant,
                id=Symbol("tree_", target),
            ),
            inputs=(
                initial_leaf_area_m2=PlantSimEngine.One(
                    within=PlantSimEngine.Self(),
                    var=:initial_leaf_area_m2,
                    from_status=true,
                ),
                transpiration_supply_deficit_mmol_h2o_tree_s=
                    crown_aggregation(
                        target,
                        :transpiration_supply_deficit_mmol_h2o_tree_s,
                    ),
                transpiration_supply_deficit_available=crown_aggregation(
                    target,
                    :crown_leaf_exchange_aggregation_available,
                ),
            ),
        ) for target in target_ids
    )
end

function _stand_radiation_scaling_modelspecs(
    ::Type{T},
    scene::LegacyTreeScene,
    soil,
    targets;
    mount_leaf_exchange::Bool=false,
    mount_canopy_air_iteration::Bool=false,
) where {T<:AbstractFloat}
    mount_leaf_exchange || return ()
    isnothing(soil) && throw(
        ArgumentError(
            "stand radiation scaling requires a Soil configuration",
        ),
    )

    target_names, _ = _soil_radiation_target_selection(targets)
    isempty(target_names) && throw(
        ArgumentError(
            "stand radiation scaling requires at least one target Crown",
        ),
    )
    crown_process(process, variable) =
        _radiation_many_process_input(target_names, process, variable)
    scene_application(application, variable) =
        _radiation_self_application_input(application, variable)

    return (
        PlantSimEngine.ModelSpec(
            MAESPAStandRadiationScaling(
                T;
                use_stand=soil.options.use_stand,
                water_balance_area_m2=scene.plot.water_balance_area,
                stocking_trees_m2=scene.plot.stocking,
                total_tree_count=scene.plot.tree_count,
            );
            name=:stand_radiation_scaling,
            on=PlantSimEngine.One(scale=:Scene, kind=:scene),
            every=mount_canopy_air_iteration ? nothing :
                  PlantSimEngine.ClockSpec(1, 1),
            inputs=(
                target_leaf_area_m2=crown_process(
                    :crown_geometry,
                    :leaf_area,
                ),
                target_multiplicities=crown_process(
                    :target_leaf_area,
                    :target_multiplicity,
                ),
                absorbed_par_crown_w=crown_process(
                    :crown_radiation_aggregation,
                    :absorbed_par_crown_w,
                ),
                absorbed_nir_crown_w=crown_process(
                    :crown_radiation_aggregation,
                    :absorbed_nir_crown_w,
                ),
                absorbed_thermal_crown_w=crown_process(
                    :crown_radiation_aggregation,
                    :absorbed_thermal_crown_w,
                ),
                target_exchange_daylight=crown_process(
                    :leaf_exchange_daylight,
                    :leaf_exchange_daylight,
                ),
                crown_radiation_aggregation_available=crown_process(
                    :crown_radiation_aggregation,
                    :crown_radiation_aggregation_available,
                ),
                crown_thermal_radiation_aggregation_available=crown_process(
                    :crown_radiation_aggregation,
                    :crown_thermal_radiation_aggregation_available,
                ),
                stand_lai=scene_application(
                    :stand_leaf_area_index,
                    :stand_lai,
                ),
                stand_radiation_scaling_inputs_available=scene_application(
                    :stand_leaf_area_statistics,
                    :stand_leaf_area_statistics_available,
                ),
            ),
        ),
    )
end

function _stand_water_flux_scaling_modelspecs(
    ::Type{T},
    config::SimulationConfig,
    scene::LegacyTreeScene,
    soil,
    targets;
    mount_non_tuzet_leaf_exchange::Bool=false,
    mount_canopy_air_iteration::Bool=false,
) where {T<:AbstractFloat}
    mount_non_tuzet_leaf_exchange || return ()
    isnothing(soil) && throw(
        ArgumentError(
            "stand water-flux scaling requires a Soil configuration",
        ),
    )

    target_names, _ = _soil_radiation_target_selection(targets)
    isempty(target_names) && throw(
        ArgumentError(
            "stand water-flux scaling requires at least one target Crown",
        ),
    )
    crown_process(process, variable) =
        _radiation_many_process_input(target_names, process, variable)
    scene_statistics(variable) = _radiation_self_application_input(
        :stand_leaf_area_statistics,
        variable,
    )
    scene_application(application, variable) =
        _radiation_self_application_input(application, variable)
    soil_application(application, variable) = PlantSimEngine.One(
        scale=:Soil,
        kind=:soil,
        within=PlantSimEngine.SceneScope(),
        application=application,
        var=variable,
    )
    wet_canopy_input = (
        wet_evaporation_crown_umol_h2o_s=crown_process(
            :crown_leaf_exchange_aggregation,
            :wet_evaporation_crown_umol_h2o_s,
        ),
    )
    mode_one_inputs = if soil.options.use_stand == 1
        (
            stomatal_conductance_co2_crown_mol_s=crown_process(
                :crown_leaf_exchange_aggregation,
                :stomatal_conductance_co2_crown_mol_s,
            ),
            target_exchange_daylight=crown_process(
                :leaf_exchange_daylight,
                :leaf_exchange_daylight,
            ),
            absorbed_par_crown_w=crown_process(
                :crown_radiation_aggregation,
                :absorbed_par_crown_w,
            ),
            absorbed_nir_crown_w=crown_process(
                :crown_radiation_aggregation,
                :absorbed_nir_crown_w,
            ),
            absorbed_thermal_crown_w=crown_process(
                :crown_radiation_aggregation,
                :absorbed_thermal_crown_w,
            ),
            crown_radiation_aggregation_available=crown_process(
                :crown_radiation_aggregation,
                :crown_radiation_aggregation_available,
            ),
            crown_thermal_radiation_aggregation_available=crown_process(
                :crown_radiation_aggregation,
                :crown_thermal_radiation_aggregation_available,
            ),
            canopy_atmosphere_aerodynamic_conductance_m_s=soil_application(
                :soil_surface_aerodynamics,
                :canopy_atmosphere_aerodynamic_conductance_m_s,
            ),
            soil_surface_aerodynamics_available=soil_application(
                :soil_surface_aerodynamics,
                :soil_surface_aerodynamics_available,
            ),
            astronomical_daylight=scene_application(
                :solar_geometry,
                :astronomical_daylight,
            ),
        )
    else
        NamedTuple()
    end
    wet_budget_inputs = if isnothing(soil.canopy_interception)
        ()
    else
        (
            :wet_budget_precipitation_mm => scene_application(
                :meteorology, :precipitation_mm,
            ),
            :wet_budget_full_stand_lai => scene_statistics(:full_stand_lai),
            PlantSimEngine.PreviousTimeStep(
                :wet_budget_previous_canopy_water_storage_mm,
            ) => scene_application(:canopy_water_storage, :canopy_water_storage_mm),
            PlantSimEngine.PreviousTimeStep(
                :wet_budget_previous_effective_throughfall_fraction,
            ) => scene_application(:canopy_water_storage, :effective_throughfall_fraction),
            PlantSimEngine.PreviousTimeStep(
                :wet_budget_previous_dry_canopy_fraction,
            ) => scene_application(:canopy_water_storage, :dry_canopy_fraction),
        )
    end

    return (
        PlantSimEngine.ModelSpec(
            MAESPAStandWaterFluxScaling(
                T;
                use_stand=soil.options.use_stand,
                species_count=config.species_count,
                water_balance_area_m2=scene.plot.water_balance_area,
                stocking_trees_m2=scene.plot.stocking,
                total_tree_count=scene.plot.tree_count,
                canopy_interception=soil.canopy_interception,
            );
            name=:stand_water_flux_scaling,
            environment=PlantSimEngine.Environment(provider=:canopy),
            on=PlantSimEngine.One(scale=:Scene, kind=:scene),
            every=mount_canopy_air_iteration ? nothing :
                  PlantSimEngine.ClockSpec(1, 1),
            inputs=(pairs((
                target_leaf_area_m2=crown_process(
                    :crown_geometry,
                    :leaf_area,
                ),
                target_multiplicities=crown_process(
                    :target_leaf_area,
                    :target_multiplicity,
                ),
                target_species_ids=_radiation_many_status_input(
                    target_names,
                    :species_id,
                ),
                dry_transpiration_crown_umol_h2o_s=crown_process(
                    :crown_leaf_exchange_aggregation,
                    :dry_transpiration_crown_umol_h2o_s,
                ),
                wet_canopy_input...,
                crown_leaf_exchange_aggregation_available=crown_process(
                    :crown_leaf_exchange_aggregation,
                    :crown_leaf_exchange_aggregation_available,
                ),
                stand_lai=scene_application(
                    :stand_leaf_area_index,
                    :stand_lai,
                ),
                stand_water_flux_scaling_inputs_available=scene_statistics(
                    :stand_leaf_area_statistics_available,
                ),
                mode_one_inputs...,
            ))..., wet_budget_inputs...),
        ),
    )
end

function _canopy_water_storage_modelspecs(
    soil;
    mount_non_tuzet_leaf_exchange::Bool=false,
)
    mount_non_tuzet_leaf_exchange || return ()
    isnothing(soil) && return ()
    isnothing(soil.canopy_interception) && return ()

    scene_application(application, variable) =
        _radiation_self_application_input(application, variable)
    return (
        maespa_canopy_water_storage_modelspec(
            soil.canopy_interception;
            inputs=(
                precipitation_mm=scene_application(
                    :meteorology,
                    :precipitation_mm,
                ),
                interception_stand_lai=scene_application(
                    :stand_leaf_area_statistics,
                    :full_stand_lai,
                ),
                wet_canopy_evaporation_mm=scene_application(
                    :stand_water_flux_scaling,
                    :wet_canopy_evaporation_mm_timestep,
                ),
                canopy_water_storage_inputs_available=scene_application(
                    :stand_water_flux_scaling,
                    :stand_water_flux_scaling_available,
                ),
            ),
        ),
    )
end

function _root_water_uptake_species_aggregation_modelspecs(
    ::Type{T},
    config::SimulationConfig,
    targets,
    rooted_layer_count;
    mount_non_tuzet_leaf_exchange::Bool=false,
    root_water_uptake_active::Bool=false,
) where {T<:AbstractFloat}
    if !mount_non_tuzet_leaf_exchange || !root_water_uptake_active
        return ()
    end
    isnothing(rooted_layer_count) && throw(
        ArgumentError(
            "root-uptake species aggregation requires a resolved rooted-layer count",
        ),
    )

    target_ids = sort!(
        unique!(Int[target for target in targets]);
        by=_radiation_crown_name,
    )
    isempty(target_ids) && throw(
        ArgumentError(
            "root-uptake species aggregation requires at least one target tree",
        ),
    )
    crown_names = Tuple(_radiation_crown_name.(target_ids))
    root_names = Tuple(Symbol("root_system_", target) for target in target_ids)
    crown_status(variable) =
        _radiation_many_status_input(crown_names, variable)
    crown_process(process, variable) =
        _radiation_many_process_input(crown_names, process, variable)
    root_status(variable) = PlantSimEngine.Many(
        scale=:RootSystem,
        kind=:root_system,
        id=root_names,
        within=PlantSimEngine.SceneScope(),
        var=variable,
        from_status=true,
    )
    root_uptake(variable) = PlantSimEngine.Many(
        scale=:RootSystem,
        kind=:root_system,
        id=root_names,
        within=PlantSimEngine.SceneScope(),
        application=:root_water_uptake,
        var=variable,
    )

    return (
        PlantSimEngine.ModelSpec(
            MAESPARootWaterUptakeSpeciesAggregation(
                T;
                rooted_layer_count,
                species_count=config.species_count,
            );
            name=:root_water_uptake_species_aggregation,
            on=PlantSimEngine.One(scale=:Scene, kind=:scene),
            every=PlantSimEngine.ClockSpec(1, 1),
            inputs=(
                crown_tree_ids=crown_status(:tree_id),
                crown_species_ids=crown_status(:species_id),
                target_multiplicities=crown_process(
                    :target_leaf_area,
                    :target_multiplicity,
                ),
                dry_transpiration_crown_umol_h2o_s=crown_process(
                    :crown_leaf_exchange_aggregation,
                    :dry_transpiration_crown_umol_h2o_s,
                ),
                crown_leaf_exchange_aggregation_available=crown_process(
                    :crown_leaf_exchange_aggregation,
                    :crown_leaf_exchange_aggregation_available,
                ),
                root_system_tree_ids=root_status(:tree_id),
                root_water_uptake_fraction_by_root_system=root_uptake(
                    :root_water_uptake_fraction,
                ),
                root_water_uptake_available=root_uptake(
                    :root_water_uptake_available,
                ),
            ),
        ),
    )
end

function _canopy_surface_water_forcing_modelspec(::Type{T}, soil) where {T}
    interception_enabled = !isnothing(soil.canopy_interception)
    if !interception_enabled
        return PlantSimEngine.ModelSpec(
            MAESPACanopySurfaceWaterForcing(
                T;
                interception_enabled=false,
            );
            name=:canopy_surface_water_forcing,
            on=PlantSimEngine.One(scale=:Scene, kind=:scene),
        )
    end

    return PlantSimEngine.ModelSpec(
        MAESPACanopySurfaceWaterForcing(
            T;
            interception_enabled=true,
        );
        name=:canopy_surface_water_forcing,
        on=PlantSimEngine.One(scale=:Scene, kind=:scene),
        inputs=(
            PlantSimEngine.PreviousTimeStep(
                :previous_dry_canopy_fraction,
            ) => _radiation_self_application_input(
                :canopy_water_storage,
                :dry_canopy_fraction,
            ),
            PlantSimEngine.PreviousTimeStep(
                :previous_canopy_water_storage_mm,
            ) => _radiation_self_application_input(
                :canopy_water_storage,
                :canopy_water_storage_mm,
            ),
            :surface_water_stand_lai => _radiation_self_application_input(
                :stand_leaf_area_statistics,
                :full_stand_lai,
            ),
            :canopy_surface_water_forcing_inputs_available =>
                _radiation_self_application_input(
                    :stand_leaf_area_statistics,
                    :stand_leaf_area_statistics_available,
                ),
        ),
    )
end
