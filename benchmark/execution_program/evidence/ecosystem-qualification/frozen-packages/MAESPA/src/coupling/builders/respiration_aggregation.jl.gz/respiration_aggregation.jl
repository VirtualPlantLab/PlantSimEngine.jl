# Plant respiration accounting and daily scene aggregation.

function _structural_respiration_configured(species)
    allometry = species.structure.allometry
    branch = allometry.branches
    roots = allometry.roots
    branch_respiration = species.physiology.branch_respiration
    root_respiration = species.physiology.root_respiration
    return !iszero(branch.coefficient) || !iszero(branch.intercept) ||
           !iszero(roots.coefficient) || !iszero(roots.intercept) ||
           !iszero(
               branch_respiration.base_respiration_rate_umol_per_kg_dry_matter_s,
           ) ||
           !iszero(
               root_respiration.fine_root_base_respiration_rate_umol_per_kg_dry_matter_s,
           ) ||
           !iszero(
               root_respiration.coarse_root_base_respiration_rate_umol_per_kg_dry_matter_s,
           )
end

function _plant_structural_respiration_upstream_applications(
    species,
    tree_id::Integer,
    meteorology,
)
    applications = Symbol[
        Symbol("stem_woody_biomass_tree_", tree_id),
        Symbol("stem_growth_respiration_tree_", tree_id),
        Symbol("branch_woody_biomass_tree_", tree_id),
        Symbol("branch_growth_respiration_tree_", tree_id),
        Symbol("root_woody_biomass_tree_", tree_id),
        Symbol("root_biomass_partition_tree_", tree_id),
        Symbol("fine_root_growth_respiration_tree_", tree_id),
        Symbol("coarse_root_growth_respiration_tree_", tree_id),
    ]
    woody_model = MAESPAWoodyRespirationTrajectory(
        species.physiology.woody_respiration,
    )
    if woody_model.active
        push!(
            applications,
            Symbol("stem_woody_respiration_trajectory_tree_", tree_id),
            Symbol("stem_woody_respiration_rate_tree_", tree_id),
        )
        isnothing(meteorology) || push!(
            applications,
            Symbol("stem_maintenance_respiration_tree_", tree_id),
        )
    end
    if !isnothing(meteorology)
        push!(
            applications,
            Symbol("branch_maintenance_respiration_tree_", tree_id),
            Symbol("fine_root_maintenance_respiration_tree_", tree_id),
            Symbol("coarse_root_maintenance_respiration_tree_", tree_id),
        )
    end
    return Tuple(applications)
end

function _plant_structural_respiration_modelspecs(
    config::SimulationConfig{T},
    scene::LegacyTreeScene{T},
    species_set,
    targets,
    meteorology,
    ;
    force_complete_topology::Bool=false,
) where {T<:AbstractFloat}
    isnothing(species_set) && return ()
    structural_geometry_available =
        !isnothing(scene.trajectories.stem_diameter)

    target_names = _stem_growth_target_names_by_species(
        scene,
        targets,
        config.species_count,
    )
    tree_by_stem_name =
        Dict(_stem_object_name(tree.id) => tree for tree in scene.trees)
    applications = PlantSimEngine.ModelSpec[]
    for species_id in eachindex(target_names)
        species = species_set[species_id]
        (_structural_respiration_configured(species) ||
         force_complete_topology) || continue
        for stem_name in target_names[species_id]
            tree_id = tree_by_stem_name[stem_name].id
            application_name = Symbol(
                "plant_structural_respiration_aggregation_tree_",
                tree_id,
            )
            if !structural_geometry_available
                push!(
                    applications,
                    PlantSimEngine.ModelSpec(
                        MAESPAUnavailablePlantStructuralRespirationAggregation(
                            T;
                            reason=:missing_stem_diameter,
                        );
                        name=application_name,
                        on=PlantSimEngine.One(
                            scale=:Plant,
                            kind=:plant,
                            id=Symbol("tree_", tree_id),
                        ),
                    ),
                )
                continue
            end
            upstream = _plant_structural_respiration_upstream_applications(
                species,
                tree_id,
                meteorology,
            )
            descendant_status(variable) = PlantSimEngine.Many(
                scale=(:Stem, :BranchSystem, :RootPool),
                kind=(:stem, :branch_system, :fine_root, :coarse_root),
                within=PlantSimEngine.Subtree(),
                var=variable,
                from_status=true,
                after=upstream,
            )
            push!(
                applications,
                PlantSimEngine.ModelSpec(
                    MAESPAPlantStructuralRespirationAggregation(T);
                    name=application_name,
                    on=PlantSimEngine.One(
                        scale=:Plant,
                        kind=:plant,
                        id=Symbol("tree_", tree_id),
                    ),
                    inputs=(
                        structural_respiration_compartment_roles=
                            descendant_status(
                                :structural_respiration_compartment_role,
                            ),
                        structural_compartment_maintenance_respiration_umol_co2_s=
                            descendant_status(:maintenance_respiration_umol_s),
                        structural_compartment_maintenance_respiration_available=
                            descendant_status(:maintenance_respiration_available),
                        structural_compartment_growth_respiration_mol_co2_tree_day=
                            descendant_status(
                                :growth_respiration_mol_co2_tree_day,
                            ),
                        structural_compartment_growth_respiration_available=
                            descendant_status(:growth_respiration_available),
                        structural_compartment_growth_respiration_date50=
                            descendant_status(:growth_respiration_date50),
                    ),
                ),
            )
        end
    end
    return Tuple(applications)
end

function _whole_plant_growth_respiration_modelspecs(
    config::SimulationConfig{T},
    scene::LegacyTreeScene{T},
    species_set,
    targets,
    structure_clock;
    force_complete_topology::Bool=false,
) where {T<:AbstractFloat}
    isnothing(species_set) && return ()

    target_names = _stem_growth_target_names_by_species(
        scene,
        targets,
        config.species_count,
    )
    tree_by_stem_name =
        Dict(_stem_object_name(tree.id) => tree for tree in scene.trees)
    applications = PlantSimEngine.ModelSpec[]
    for species_id in eachindex(target_names)
        species = species_set[species_id]
        (_structural_respiration_configured(species) ||
         force_complete_topology) || continue
        for stem_name in target_names[species_id]
            tree_id = tree_by_stem_name[stem_name].id
            structural_application = Symbol(
                "plant_structural_respiration_aggregation_tree_",
                tree_id,
            )
            foliage_application =
                Symbol("foliage_growth_respiration_tree_", tree_id)
            aggregation_application = Symbol(
                "whole_plant_growth_respiration_aggregation_tree_",
                tree_id,
            )
            structural_input(variable) = PlantSimEngine.One(
                within=PlantSimEngine.Self(),
                application=structural_application,
                var=variable,
            )
            foliage_input(variable) = PlantSimEngine.One(
                scale=:Crown,
                kind=:crown,
                within=PlantSimEngine.SelfPlant(),
                application=foliage_application,
                var=variable,
            )
            push!(
                applications,
                PlantSimEngine.ModelSpec(
                    MAESPAWholePlantGrowthRespirationAggregation(T);
                    name=aggregation_application,
                    on=PlantSimEngine.One(
                        scale=:Plant,
                        kind=:plant,
                        id=Symbol("tree_", tree_id),
                    ),
                    every=structure_clock,
                    inputs=(
                        structural_growth_respiration_mol_co2_tree_day=
                            structural_input(
                                :structural_growth_respiration_mol_co2_tree_day,
                            ),
                        structural_growth_respiration_available=
                            structural_input(
                                :structural_growth_respiration_available,
                            ),
                        structural_growth_respiration_date50=
                            structural_input(
                                :structural_growth_respiration_date50,
                            ),
                        leaf_growth_respiration_mol_co2_tree_day=foliage_input(
                            :growth_respiration_mol_co2_tree_day,
                        ),
                        leaf_growth_respiration_available=foliage_input(
                            :growth_respiration_available,
                        ),
                        leaf_growth_respiration_date50=foliage_input(
                            :growth_respiration_date50,
                        ),
                    ),
                ),
            )
        end
    end
    return Tuple(applications)
end

function _whole_plant_maintenance_respiration_modelspecs(
    config::SimulationConfig{T},
    scene::LegacyTreeScene{T},
    species_set,
    targets;
    mount_leaf_exchange::Bool=false,
) where {T<:AbstractFloat}
    mount_leaf_exchange || return ()
    isnothing(species_set) && return ()

    target_names = _stem_growth_target_names_by_species(
        scene,
        targets,
        config.species_count,
    )
    tree_by_stem_name =
        Dict(_stem_object_name(tree.id) => tree for tree in scene.trees)
    applications = PlantSimEngine.ModelSpec[]
    for species_id in eachindex(target_names)
        species = species_set[species_id]
        for stem_name in target_names[species_id]
            tree_id = tree_by_stem_name[stem_name].id
            structural_application = Symbol(
                "plant_structural_respiration_aggregation_tree_",
                tree_id,
            )
            crown_application =
                Symbol("crown_leaf_exchange_aggregation_", tree_id)
            aggregation_application = Symbol(
                "whole_plant_maintenance_respiration_aggregation_tree_",
                tree_id,
            )
            structural_input(variable) = PlantSimEngine.One(
                within=PlantSimEngine.Self(),
                application=structural_application,
                var=variable,
            )
            crown_input(variable) = PlantSimEngine.One(
                scale=:Crown,
                kind=:crown,
                within=PlantSimEngine.SelfPlant(),
                application=crown_application,
                var=variable,
            )
            push!(
                applications,
                PlantSimEngine.ModelSpec(
                    MAESPAWholePlantMaintenanceRespirationAggregation(T);
                    name=aggregation_application,
                    on=PlantSimEngine.One(
                        scale=:Plant,
                        kind=:plant,
                        id=Symbol("tree_", tree_id),
                    ),
                    inputs=(
                        structural_maintenance_respiration_umol_co2_tree_s=
                            structural_input(
                                :structural_maintenance_respiration_umol_co2_tree_s,
                            ),
                        structural_maintenance_respiration_available=
                            structural_input(
                                :structural_maintenance_respiration_available,
                            ),
                        leaf_respiration_crown_umol_co2_s=crown_input(
                            :leaf_respiration_crown_umol_co2_s,
                        ),
                        crown_leaf_exchange_aggregation_available=crown_input(
                            :crown_leaf_exchange_aggregation_available,
                        ),
                    ),
                ),
            )
        end
    end
    return Tuple(applications)
end

function _plant_maintenance_accumulator_modelspecs(
    config::SimulationConfig{T},
    scene::LegacyTreeScene{T},
    species_set,
    targets;
    mount_leaf_exchange::Bool=false,
) where {T<:AbstractFloat}
    isnothing(species_set) && return ()

    target_names = _stem_growth_target_names_by_species(
        scene,
        targets,
        config.species_count,
    )
    tree_by_stem_name =
        Dict(_stem_object_name(tree.id) => tree for tree in scene.trees)
    calendar_input(variable) = PlantSimEngine.One(
        scale=:Scene,
        within=PlantSimEngine.Ancestor(scale=:Scene),
        application=:legacy_calendar,
        var=variable,
    )
    applications = PlantSimEngine.ModelSpec[]
    for species_id in eachindex(target_names)
        species = species_set[species_id]
        (_structural_respiration_configured(species) ||
         mount_leaf_exchange) || continue
        for stem_name in target_names[species_id]
            tree_id = tree_by_stem_name[stem_name].id
            aggregation_application = if mount_leaf_exchange
                Symbol(
                    "whole_plant_maintenance_respiration_aggregation_tree_",
                    tree_id,
                )
            else
                Symbol(
                    "plant_structural_respiration_aggregation_tree_",
                    tree_id,
                )
            end
            accumulator_application = Symbol(
                "plant_maintenance_civil_day_accumulator_tree_",
                tree_id,
            )
            aggregation_input(variable) = PlantSimEngine.One(
                within=PlantSimEngine.Self(),
                application=aggregation_application,
                var=variable,
            )
            previous_output(input_variable, output_variable) =
                PlantSimEngine.PreviousTimeStep(input_variable) =>
                PlantSimEngine.One(
                    within=PlantSimEngine.Self(),
                    application=accumulator_application,
                    var=output_variable,
                )
            push!(
                applications,
                PlantSimEngine.ModelSpec(
                    MAESPACivilDayRespirationAccumulator(
                        T,
                        config.steps_per_day,
                        source_day_stride=config.source_day_stride,
                    );
                    name=accumulator_application,
                    on=PlantSimEngine.One(
                        scale=:Plant,
                        kind=:plant,
                        id=Symbol("tree_", tree_id),
                    ),
                    inputs=(
                        :instantaneous_respiration_umol_s => aggregation_input(
                            mount_leaf_exchange ?
                            :whole_plant_maintenance_respiration_umol_co2_tree_s :
                            :structural_maintenance_respiration_umol_co2_tree_s,
                        ),
                        :civil_day_respiration_accumulator_inputs_available =>
                            aggregation_input(
                                mount_leaf_exchange ?
                                :whole_plant_maintenance_respiration_aggregation_available :
                                :structural_maintenance_respiration_available,
                            ),
                        :date50 => calendar_input(:date50),
                        :step_index => calendar_input(:step_index),
                        previous_output(
                            :previous_accumulator_initialized,
                            :respiration_accumulator_initialized,
                        ),
                        previous_output(
                            :previous_accumulator_date50,
                            :respiration_accumulator_date50,
                        ),
                        previous_output(
                            :previous_accumulator_step_index,
                            :respiration_accumulator_step_index,
                        ),
                        previous_output(
                            :previous_current_day_respiration_mol,
                            :current_day_respiration_mol,
                        ),
                        previous_output(
                            :previous_current_day_coverage_complete,
                            :current_day_coverage_complete,
                        ),
                    ),
                ),
            )
        end
    end
    return Tuple(applications)
end

function _daily_whole_plant_respiration_scene_aggregation_modelspecs(
    config::SimulationConfig{T},
    scene::LegacyTreeScene{T},
    species_set,
    targets;
    mount_leaf_exchange::Bool=false,
) where {T<:AbstractFloat}
    # Both Scene channels must already be whole-plant amounts for one physical
    # tree. Structural-only diagnostics stay on their Plant and are never
    # silently relabelled at this boundary.
    mount_leaf_exchange || return ()
    isnothing(species_set) && return ()

    target_names = _stem_growth_target_names_by_species(
        scene,
        targets,
        config.species_count,
    )
    tree_by_stem_name =
        Dict(_stem_object_name(tree.id) => tree for tree in scene.trees)
    tree_ids = Int[]
    for species_id in eachindex(target_names)
        for stem_name in target_names[species_id]
            push!(tree_ids, tree_by_stem_name[stem_name].id)
        end
    end
    sort!(unique!(tree_ids))
    isempty(tree_ids) && return ()

    plant_names = Tuple(Symbol("tree_", tree_id) for tree_id in tree_ids)
    accumulator_applications = Tuple(
        Symbol("plant_maintenance_civil_day_accumulator_tree_", tree_id) for
        tree_id in tree_ids
    )
    growth_applications = Tuple(
        Symbol("whole_plant_growth_respiration_aggregation_tree_", tree_id) for
        tree_id in tree_ids
    )
    plant_status(variable; after=nothing) = if isnothing(after)
        PlantSimEngine.Many(
            scale=:Plant,
            kind=:plant,
            id=plant_names,
            within=PlantSimEngine.SceneScope(),
            var=variable,
            from_status=true,
        )
    else
        PlantSimEngine.Many(
            scale=:Plant,
            kind=:plant,
            id=plant_names,
            within=PlantSimEngine.SceneScope(),
            var=variable,
            from_status=true,
            after=after,
        )
    end

    return (
        PlantSimEngine.ModelSpec(
            MAESPADailyWholePlantRespirationSceneAggregation(
                T;
                species_count=config.species_count,
            );
            name=:daily_whole_plant_respiration_scene_aggregation,
            on=PlantSimEngine.One(scale=:Scene, kind=:scene),
            inputs=(
                tree_ids=plant_status(:tree_id),
                species_ids=plant_status(:species_id),
                target_weights=plant_status(:target_weight),
                daily_maintenance_respiration_mol_co2_tree_day=plant_status(
                    :daily_respiration_mol;
                    after=accumulator_applications,
                ),
                daily_maintenance_respiration_available=plant_status(
                    :daily_respiration_available;
                    after=accumulator_applications,
                ),
                daily_maintenance_respiration_date50=plant_status(
                    :daily_respiration_date50;
                    after=accumulator_applications,
                ),
                whole_plant_growth_respiration_mol_co2_tree_day=plant_status(
                    :whole_plant_growth_respiration_mol_co2_tree_day;
                    after=growth_applications,
                ),
                whole_plant_growth_respiration_available=plant_status(
                    :whole_plant_growth_respiration_available;
                    after=growth_applications,
                ),
                whole_plant_growth_respiration_date50=plant_status(
                    :whole_plant_growth_respiration_date50;
                    after=growth_applications,
                ),
            ),
        ),
    )
end

_radiation_mounted_application(tree_id::Integer, application::Symbol) =
    Symbol("tree_", Int(tree_id), "__", application)

