# Root hydraulics, water uptake, and soil aerodynamic coupling.

function _checked_soil_config(
    config::SimulationConfig{T},
    soil::SoilConfig,
) where {T<:AbstractFloat}
    soil isa SoilConfig{T} || throw(
        ArgumentError(
            "simulation and soil configurations must use the same numeric type",
        ),
    )
    return soil
end

function _measured_soil_water_variable(meteorology)
    isnothing(meteorology) && return nothing
    # Same precedence as MAESPAMeteorologyReconstruction / GETMETHR.
    for variable in (:soil_water_potential, :soil_moisture_deficit, :soil_water_content)
        haskey(meteorology.config.column_lookup, variable) && return variable
    end
    return nothing
end

"""Resolve INITWATBAL's automatic measured-water selection at the scenario boundary."""
function _resolved_measured_soil_water(soil::SoilConfig{T}, meteorology, environment;
    config=nothing, date=nothing, step_index=1) where {T}
    flag = soil.options.use_measured_soil_water
    flag in (0, 1) || throw(ArgumentError("USEMEASSW must be 0 or 1"))
    variable = _measured_soil_water_variable(meteorology)
    isnothing(variable) && flag == 0 && return soil
    isnothing(variable) && throw(ArgumentError("USEMEASSW=1 requires measured soil water in meteorology"))
    isnothing(environment) || throw(ArgumentError(
        "measured soil-water selection requires the supplied meteorology, not an explicit environment",
    ))
    records = if isnothing(config) || config.source_day_stride == 1
        Colon()
    else
        first_date = isnothing(date) ? config.start_date.days_since_1950 : Int(date)
        anchor = config.start_date.days_since_1950
        [index for index in eachindex(meteorology.date50) if
            first_date <= meteorology.date50[index] <= config.end_date.days_since_1950 &&
            iszero(mod(meteorology.date50[index] - anchor, config.source_day_stride)) &&
            (meteorology.date50[index] > first_date ||
             meteorology.config.frequency === DailyMeteorology ||
             meteorology.step_index[index] >= step_index)]
    end
    measurements = view(meteorology.values, records, meteorology.config.column_lookup[variable])
    all(isfinite, measurements) || throw(ArgumentError(
        "measured soil water must contain finite values",
    ))
    if variable === :soil_water_potential
        soil.options.soil_water_method == 4 && throw(ArgumentError(
            "WSOILMETHOD=4 cannot convert measured soil potential to deficit",
        ))
        all(<(zero(T)), measurements) || throw(ArgumentError(
            "SWP must contain negative soil water potentials in MPa",
        ))
        retention = soil.retention
        for (name, values) in ((:BPAR, retention.b_parameter),
            (:PSIE, retention.air_entry_water_potential_mpa),
            (:KSAT, retention.saturated_hydraulic_conductivity_m_s))
            isnothing(values) && throw(ArgumentError("measured SWP requires explicit $name, including RETFUNCTION=3"))
            length(values) == soil.layers.layer_count || throw(DimensionMismatch(
                "$name must have one value per soil layer",
            ))
            value = first(values)
            isfinite(value) && (name === :PSIE ? value < zero(T) : value > zero(T)) ||
                throw(ArgumentError("measured SWP requires finite KSAT(1)>0, BPAR(1)>0 and PSIE(1)<0"))
        end
    elseif variable === :soil_water_content && soil.options.soil_water_method == 4
        minimum = meteorology.config.soil_water_min
        maximum = meteorology.config.soil_water_max
        isfinite(minimum) && isfinite(maximum) && maximum > minimum ||
            throw(ArgumentError("WSOILMETHOD=4 with SWC requires finite SWMIN < SWMAX"))
    end
    flag == 1 && return soil
    # INITWATBAL promotes the flag when any soil measurement is present. Copy
    # the configuration; never mutate the user's parsed options or weather.
    options = WaterBalanceOptions((name === :use_measured_soil_water ? 1 :
        getfield(soil.options, name) for name in fieldnames(WaterBalanceOptions))...)
    return SoilConfig{T}(soil.source, options, soil.layers, soil.retention,
        soil.initial_state, soil.evaporation, soil.infiltration,
        soil.canopy_interception, soil.root_parameters, soil.plant_hydraulics,
        soil.plant_storage)
end

function _root_hydraulic_model(
    config::SimulationConfig{T},
    soil::SoilConfig{T},
) where {T<:AbstractFloat}
    roots = soil.root_parameters
    plant = soil.plant_hydraulics
    if isnothing(roots) != isnothing(plant)
        throw(
            ArgumentError(
                "ROOTPARS and PLANTPARS must both be present to mount the root-hydraulic trajectory",
            ),
        )
    end
    isnothing(roots) && return nothing
    roots.species_count == config.species_count || throw(
        DimensionMismatch(
            "ROOTPARS species count $(roots.species_count) does not match configured NSPECIES $(config.species_count)",
        ),
    )
    return MAESPARootHydraulicTrajectory(
        roots,
        plant,
        soil.layers.thickness_m,
    )
end

function _resolved_rooted_layer_count(
    root_hydraulic_model,
    rooted_layer_count,
)
    isnothing(root_hydraulic_model) && return rooted_layer_count
    parsed_count = root_hydraulic_model.root_parameters.rooted_layer_count
    isnothing(rooted_layer_count) && return parsed_count
    rooted_layer_count isa Integer && !(rooted_layer_count isa Bool) || throw(
        ArgumentError("rooted_layer_count must be an integer, not Bool"),
    )
    Int(rooted_layer_count) == parsed_count || throw(
        ArgumentError(
            "rooted_layer_count=$(Int(rooted_layer_count)) conflicts with ROOTPARS NROOTLAYER=$parsed_count",
        ),
    )
    return parsed_count
end

function _initial_root_system_status(
    model::MAESPARootHydraulicTrajectory,
    root_water_uptake_model::AbstractRoot_Water_UptakeModel,
    root_water_uptake_active::Bool,
    date50::Integer,
    simulation_day::Integer,
    tree_id::Integer,
    species_index::Integer,
    initial_rooted_soil_hydraulic_status::NamedTuple=NamedTuple(),
    structural_status::NamedTuple=NamedTuple(),
)
    status = PlantSimEngine.Status(;
        tree_id=Int(tree_id),
        species_id=Int(species_index),
        species_index=Int(species_index),
        date50=Int(date50),
        simulation_day=Int(simulation_day),
        root_hydraulic_trajectory_active=true,
        root_hydraulic_trajectory_inputs_available=true,
        root_water_uptake_active=root_water_uptake_active,
        root_water_uptake_inputs_available=true,
        soil_water_potential_mpa=copy(
            initial_rooted_soil_hydraulic_status.soil_water_potential_mpa,
        ),
        soil_hydraulic_conductivity_m_s=copy(
            initial_rooted_soil_hydraulic_status.soil_hydraulic_conductivity_m_s,
        ),
        structural_status...,
        PlantSimEngine.outputs_(model)...,
        PlantSimEngine.outputs_(root_water_uptake_model)...,
    )
    _publish_root_hydraulic_trajectory!(
        model,
        status,
        Int(date50),
        Int(simulation_day),
        Int(species_index),
    )
    return status
end

function _root_water_uptake_model(
    ::Type{T},
    root_hydraulic_model::MAESPARootHydraulicTrajectory;
    equal_uptake=0,
    measured_retention=nothing,
    measured_variable=nothing,
) where {T<:AbstractFloat}
    equal_uptake in (0, 1) || throw(ArgumentError("EQUALUPTAKE must be 0 or 1"))
    if measured_variable in (:soil_water_content, :soil_moisture_deficit)
        return MAESPAMeasuredContentRootWaterUptake(T,
            root_hydraulic_model.root_parameters.rooted_layer_count;
            equal_uptake=equal_uptake == 1)
    elseif measured_variable === :soil_water_potential
        return MAESPAMeasuredPotentialRootWaterUptake(T,
            root_hydraulic_model.root_parameters.rooted_layer_count;
            equal_uptake=equal_uptake == 1,
            saturated_conductivity_m_s=first(measured_retention.saturated_hydraulic_conductivity_m_s),
            campbell_exponent=first(measured_retention.b_parameter),
            air_entry_potential_mpa=first(measured_retention.air_entry_water_potential_mpa))
    end
    uptake_model = equal_uptake == 1 ? MAESPAEqualRootWaterUptake : MAESPARootWaterUptake
    return uptake_model(
        T,
        root_hydraulic_model.root_parameters.rooted_layer_count,
    )
end

function _root_water_uptake_active(soil::SoilConfig)
    # The scenario boundary resolves measured soil water before this gate.
    # Measured ET remains a separate, currently unsupported allocation branch.
    # Zero LAI remains a dynamic unavailable state handled by each model.
    return soil.options.equal_uptake in (0, 1) &&
           soil.options.use_measured_soil_water in (0, 1) &&
           soil.options.use_measured_evapotranspiration == 0
end

function _root_hydraulic_modelspec(
    model::MAESPARootHydraulicTrajectory,
    structure_clock,
)
    calendar_input(variable) = PlantSimEngine.One(
        scale=:Scene,
        within=PlantSimEngine.Ancestor(scale=:Scene),
        application=:legacy_calendar,
        var=variable,
    )
    return PlantSimEngine.ModelSpec(
        model;
        name=:root_hydraulic_trajectory,
        on=PlantSimEngine.Many(scale=:RootSystem, kind=:root_system),
        every=structure_clock,
        inputs=(
            date50=calendar_input(:date50),
            simulation_day=calendar_input(:simulation_day),
            species_index=PlantSimEngine.One(
                scale=:Plant,
                within=PlantSimEngine.Ancestor(scale=:Plant),
                var=:species_id,
                from_status=true,
            ),
        ),
    )
end

function _root_water_uptake_modelspec(
    model::AbstractRoot_Water_UptakeModel,
    rooted_layer_count::Integer,
    tree_ids,
)
    rooted_layer_names = ntuple(
        layer_index -> Symbol("soil_layer_", layer_index),
        Int(rooted_layer_count),
    )
    tree_dimension_applications = Tuple(
        _radiation_mounted_application(tree_id, :tree_dimensions) for
        tree_id in tree_ids
    )
    root_status(variable; after=nothing) = if isnothing(after)
        PlantSimEngine.One(
            within=PlantSimEngine.Self(),
            var=variable,
            from_status=true,
        )
    else
        PlantSimEngine.One(
            within=PlantSimEngine.Self(),
            var=variable,
            from_status=true,
            after=after,
        )
    end
    soil_status(variable) = PlantSimEngine.Many(
        scale=:SoilLayer,
        kind=:soil_layer,
        id=rooted_layer_names,
        within=PlantSimEngine.SceneScope(),
        var=variable,
        from_status=true,
    )
    soil_hydraulic_output(variable) = PlantSimEngine.Many(
        scale=:SoilLayer,
        kind=:soil_layer,
        id=rooted_layer_names,
        within=PlantSimEngine.SceneScope(),
        application=:soil_hydraulic_properties,
        var=variable,
    )
    spa_allocation = model isa MAESPARootWaterUptake ||
        (model isa Union{MAESPAMeasuredPotentialRootWaterUptake,
            MAESPAMeasuredContentRootWaterUptake} && !model.equal_uptake)
    spa_inputs = spa_allocation ? (
        PlantSimEngine.PreviousTimeStep(:soil_water_potential_mpa) =>
            soil_hydraulic_output(:soil_water_potential_mpa),
        :soil_ice_fraction => soil_status(:soil_ice_fraction),
        :minimum_root_water_potential_mpa => root_status(
            :minimum_root_water_potential_mpa; after=:root_hydraulic_trajectory),
        :tree_height_m => PlantSimEngine.One(
            scale=:Plant, within=PlantSimEngine.Ancestor(scale=:Plant),
            var=:tree_height, from_status=true, after=tree_dimension_applications),
    ) : ()
    return PlantSimEngine.ModelSpec(
        model;
        name=:root_water_uptake,
        on=PlantSimEngine.Many(scale=:RootSystem, kind=:root_system),
        every=PlantSimEngine.ClockSpec(1, 1),
        environment=model isa MAESPAMeasuredPotentialRootWaterUptake ?
            PlantSimEngine.Environment(provider=:forcing,
                sources=(measured_soil_water_potential_mpa=:raw_soil_water_potential,)) :
            PlantSimEngine.Environment(),
        inputs=(
            :rooted_soil_layer_indices => soil_status(:layer_index),
            PlantSimEngine.PreviousTimeStep(
                :soil_hydraulic_conductivity_m_s,
            ) => soil_hydraulic_output(:soil_hydraulic_conductivity_m_s),
            :root_length_density_m_m3 => root_status(
                :root_length_density_m_m3;
                after=:root_hydraulic_trajectory,
            ),
            :soil_layer_thickness_m => soil_status(:layer_thickness_m),
            :fine_root_radius_m => root_status(
                :fine_root_radius_m;
                after=:root_hydraulic_trajectory,
            ),
            :total_leaf_area_index => PlantSimEngine.One(
                scale=:Scene,
                within=PlantSimEngine.SceneScope(),
                var=:stand_lai,
                from_status=true,
                after=:stand_leaf_area_index,
            ),
            :root_water_uptake_active => root_status(
                :root_water_uptake_active,
            ),
            :root_water_uptake_inputs_available => root_status(
                :root_hydraulic_trajectory_available;
                after=:root_hydraulic_trajectory,
            ),
            spa_inputs...,
        ),
    )
end

function _soil_to_leaf_hydraulic_supply_modelspec(::Type{T}) where {T<:AbstractFloat}
    root_output(variable, producer) = PlantSimEngine.One(
        within=PlantSimEngine.Self(),
        application=producer,
        var=variable,
        policy=PlantSimEngine.HoldLast(),
    )
    return PlantSimEngine.ModelSpec(
        MAESPASoilToLeafHydraulicSupply(T);
        name=:soil_to_leaf_hydraulic_supply,
        on=PlantSimEngine.Many(scale=:RootSystem, kind=:root_system),
        every=PlantSimEngine.ClockSpec(1, 1),
        inputs=(
            plant_hydraulic_conductance_mmol_m2_leaf_s_mpa=root_output(
                :plant_hydraulic_conductance_mmol_m2_leaf_s_mpa,
                :root_hydraulic_trajectory,
            ),
            total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol=root_output(
                :total_soil_hydraulic_resistance_mpa_m2_leaf_s_per_mmol,
                :root_water_uptake,
            ),
            weighted_soil_water_potential_mpa=root_output(
                :weighted_soil_water_potential_mpa,
                :root_water_uptake,
            ),
            minimum_leaf_water_potential_mpa=root_output(
                :minimum_leaf_water_potential_mpa,
                :root_hydraulic_trajectory,
            ),
            soil_to_leaf_hydraulic_inputs_available=root_output(
                :root_water_uptake_available,
                :root_water_uptake,
            ),
        ),
    )
end

function _soil_surface_aerodynamics_modelspec(::Type{T}) where {T<:AbstractFloat}
    scene_status(variable; after=nothing) = if isnothing(after)
        PlantSimEngine.One(
            scale=:Scene,
            within=PlantSimEngine.Ancestor(scale=:Scene),
            var=variable,
            from_status=true,
        )
    else
        PlantSimEngine.One(
            scale=:Scene,
            within=PlantSimEngine.Ancestor(scale=:Scene),
            var=variable,
            from_status=true,
            after=after,
        )
    end
    return PlantSimEngine.ModelSpec(
        MAESPASoilSurfaceAerodynamics(T);
        name=:soil_surface_aerodynamics,
        on=PlantSimEngine.One(scale=:Soil, kind=:soil),
        inputs=(
            wind_speed_m_s=PlantSimEngine.One(
                scale=:Scene,
                within=PlantSimEngine.Ancestor(scale=:Scene),
                application=:meteorology,
                var=:wind_speed_m_s,
            ),
            wind_measurement_height_m=scene_status(
                :wind_measurement_height_m,
            ),
            canopy_height_m=scene_status(
                :canopy_height_m;
                after=:canopy_height_aggregation,
            ),
            soil_surface_aerodynamics_inputs_available=scene_status(
                :canopy_height_available;
                after=:canopy_height_aggregation,
            ),
        ),
    )
end
