# Shared radiation selectors, bindings, and scheduling dependencies.

function _radiation_target_input(
    tree_id::Integer,
    application::Symbol,
    variable::Symbol,
)
    return PlantSimEngine.One(
        within=PlantSimEngine.Self(),
        application=_radiation_mounted_application(tree_id, application),
        var=variable,
    )
end

function _radiation_scene_application_input(application::Symbol, variable::Symbol)
    return PlantSimEngine.One(
        scale=:Scene,
        within=PlantSimEngine.Ancestor(scale=:Scene),
        application=application,
        var=variable,
    )
end

function _radiation_self_application_input(application::Symbol, variable::Symbol)
    return PlantSimEngine.One(
        within=PlantSimEngine.Self(),
        application=application,
        var=variable,
    )
end

# Trial atmosphere is live canonical state on a separate object. Keeping it
# distinct from Scene meteorology lets unpublished hard calls share the current
# trial without overwriting the above-canopy forcing or reading retained streams.

function _radiation_scene_status_input(variable::Symbol)
    return PlantSimEngine.One(
        scale=:Scene,
        within=PlantSimEngine.Ancestor(scale=:Scene),
        var=variable,
        from_status=true,
    )
end

function _radiation_many_status_input(names::Tuple, variable::Symbol)
    return PlantSimEngine.Many(
        scale=:Crown,
        id=names,
        within=PlantSimEngine.SceneScope(),
        var=variable,
        from_status=true,
    )
end

function _radiation_many_process_input(
    names::Tuple,
    process::Symbol,
    variable::Symbol,
)
    return PlantSimEngine.Many(
        scale=:Crown,
        id=names,
        within=PlantSimEngine.SceneScope(),
        process=process,
        var=variable,
    )
end

function _radiation_common_bindings(neighbourhood::RadiationNeighbourhood)
    names = Tuple(_radiation_crown_name.(neighbourhood.tree_ids))
    target = neighbourhood.target_tree_id
    scene_status(variable) = _radiation_scene_status_input(variable)
    crown_status(variable) = _radiation_many_status_input(names, variable)
    crown_process(process, variable) =
        _radiation_many_process_input(names, process, variable)
    return (
        representative_x=_radiation_target_input(
            target,
            :canopy_sampling,
            :representative_x,
        ),
        representative_y=_radiation_target_input(
            target,
            :canopy_sampling,
            :representative_y,
        ),
        representative_z=_radiation_target_input(
            target,
            :canopy_sampling,
            :representative_z,
        ),
        all_tree_x_m=crown_status(:tree_x_m),
        all_tree_y_m=crown_status(:tree_y_m),
        all_tree_z_m=crown_status(:tree_z_m),
        all_radius_x=crown_process(:crown_geometry, :radius_x),
        all_radius_y=crown_process(:crown_geometry, :radius_y),
        all_crown_depth=crown_process(:crown_geometry, :crown_depth),
        all_crown_base_height=crown_process(
            :crown_geometry,
            :crown_base_height,
        ),
        all_leaf_area=crown_process(:crown_geometry, :leaf_area),
        all_uniform_leaf_area_density=crown_process(
            :leaf_area_distribution,
            :uniform_leaf_area_density,
        ),
        all_leaf_density_coefficients=crown_process(
            :species_structure_trajectory,
            :leaf_density_coefficients,
        ),
        all_structural_age_proportions=crown_process(
            :species_physiology_trajectory,
            :structural_foliage_age_proportions,
        ),
        all_crown_shape_code=crown_process(
            :species_structure_trajectory,
            :crown_shape_code,
        ),
        all_leaf_density_legacy_mode=crown_process(
            :species_structure_trajectory,
            :leaf_density_legacy_mode,
        ),
        slope_x_rad=scene_status(:plot_slope_x_rad),
        slope_y_rad=scene_status(:plot_slope_y_rad),
        plot_width=scene_status(:plot_width_m),
        plot_height=scene_status(:plot_height_m),
        shade_height=scene_status(:shade_height_m),
    )
end

# One scientific Crown boundary owns every producer needed by its numerical
# kernels. Explicit inputs therefore order all sources without a token barrier.
function _crown_radiation_modelspec(model::MAESPACrownRadiation)
    neighbourhood = model.neighbourhood
    target = neighbourhood.target_tree_id
    names = Tuple(_radiation_crown_name.(neighbourhood.tree_ids))
    crown(variable, process) = _radiation_target_input(target, process, variable)
    neighbours(variable, process) = _radiation_many_process_input(names, process, variable)
    scene(variable, application) = _radiation_scene_application_input(application, variable)
    cache = (
        simulation_step=scene(:simulation_step, :legacy_calendar),
        stand_lai=scene(:stand_lai, :stand_leaf_area_index),
        diffuse_zenith_angles_rad=crown(:diffuse_zenith_class_centres_rad, :diffuse_extinction),
        all_diffuse_extinction_coefficients=neighbours(:diffuse_extinction_coefficients, :diffuse_extinction),
        all_diffuse_zenith_angles_rad=neighbours(:diffuse_zenith_class_centres_rad, :diffuse_extinction),
        diffuse_sky=_radiation_scene_status_input(:diffuse_sky),
        radius_x=crown(:radius_x, :crown_geometry),
        radius_y=crown(:radius_y, :crown_geometry),
        crown_depth=crown(:crown_depth, :crown_geometry),
        crown_base_height=crown(:crown_base_height, :crown_geometry),
        target_leaf_area=crown(:leaf_area, :crown_geometry),
    )
    shortwave = (
        target_leaf_angle_class_centres_rad=crown(:leaf_angle_class_centres_rad, :species_structure),
        all_beam_extinction_coefficient=neighbours(:beam_extinction_coefficient, :beam_extinction),
        all_beam_extinction_by_leaf_angle=neighbours(:beam_extinction_by_leaf_angle, :beam_extinction),
        sun_zenith_rad=scene(:sun_zenith_rad, :solar_geometry),
        sun_azimuth_rad=scene(:sun_azimuth_scene_rad, :solar_geometry),
        astronomical_daylight=scene(:astronomical_daylight, :solar_geometry),
        incident_par_w_m2=scene(:incident_par_w_m2, :meteorology),
        incident_nir_w_m2=scene(:incident_nir_w_m2, :meteorology),
        beam_fraction_par=scene(:beam_fraction_par, :meteorology),
        beam_fraction_nir=scene(:beam_fraction_nir, :meteorology),
        slope_diffuse_multiplier=scene(:diffuse_slope_multiplier, :slope_radiation_correction),
        slope_reflection_multiplier=scene(:soil_reflection_slope_multiplier, :slope_radiation_correction),
        slope_beam_multiplier=scene(:beam_slope_multiplier, :slope_radiation_correction),
        physiological_layers=crown(:physiological_layers, :canopy_sampling),
        leaf_reflectance=crown(:leaf_reflectance, :species_physiology),
        leaf_transmittance=crown(:leaf_transmittance, :species_physiology),
        soil_reflectance=crown(:soil_reflectance, :species_physiology),
        leaf_absorptance=crown(:leaf_absorptance, :species_physiology),
        target_diffuse_extinction_coefficients=crown(:diffuse_extinction_coefficients, :diffuse_extinction),
        beam_extinction_coefficient=crown(:beam_extinction_coefficient, :beam_extinction),
        beam_extinction_available=crown(:beam_extinction_available, :beam_extinction),
        leaf_angle_fractions=crown(:leaf_angle_fractions, :species_structure),
    )
    bindings = merge(_radiation_common_bindings(neighbourhood), cache, shortwave)
    # File-only and diffuse-only modes declare smaller interfaces. Do not bind
    # undeclared ports or turn an optional invalidation revision into a required
    # external producer; its scientific default remains zero.
    input_names = Tuple(name for name in keys(PlantSimEngine.inputs_(model))
        if name !== :diffuse_invalidation_revision)
    all(name -> haskey(bindings, name), input_names) || throw(ArgumentError(
        "a Crown radiation input has no configured scientific source"))
    inputs = NamedTuple{input_names}(map(name -> getproperty(bindings, name), input_names))
    return PlantSimEngine.ModelSpec(model;
        name=Symbol("crown_radiation_", target),
        on=PlantSimEngine.One(scale=:Crown, id=_radiation_crown_name(target)),
        inputs,
    )
end
