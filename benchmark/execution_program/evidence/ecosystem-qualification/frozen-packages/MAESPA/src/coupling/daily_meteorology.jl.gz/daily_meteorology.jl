const _DAILY_EXPANDED_COLUMNS = (
    "TAIR" => :air_temperature,
    "TDEW" => :dew_temperature,
    "RAD" => :global_radiation,
    "FBEAM" => :beam_fraction,
    "WIND" => :wind_speed,
    "PPT" => :precipitation,
)

function _expanded_daily_meteorology_config(config::MeteorologyConfig{T}) where {T}
    lookup = config.column_lookup
    haskey(lookup, :daily_global_radiation) || haskey(lookup, :daily_incident_par) || !isnothing(config.bristow) || throw(
        ArgumentError("daily radiation requires PAR, SI or BRISTO parameters"),
    )
    haskey(lookup, :measured_evapotranspiration) && throw(ArgumentError(
        "daily measured_evapotranspiration is not supported by GETMETDAY; provide subdaily forcing explicitly",
    ))
    columns = [MeteorologyColumn(i, name, variable) for (i, (name, variable)) in enumerate(_DAILY_EXPANDED_COLUMNS)]
    for column in config.columns
        if column.variable in (:co2, :air_pressure, :soil_water_potential,
                               :soil_moisture_deficit, :soil_water_content)
            push!(columns, MeteorologyColumn(length(columns) + 1, column.raw_name, column.variable))
        end
    end
    expanded_lookup = Dict{Symbol,Int}(column.variable => column.source_index for column in columns)
    return MeteorologyConfig(
        config.source, config.title, config.data_start_line, 1, SubdailyMeteorology,
        config.steps_per_day, config.step_seconds, length(columns), length(columns),
        columns, expanded_lookup, config.start_date, config.end_date,
        config.constant_co2, config.constant_pressure_pa, config.diffuse_sky,
        config.soil_water_min, config.soil_water_max, copy(config.diagnostics), config.bristow,
    )
end

"""Expand one complete GETMETDAY row into an owned subdaily destination block."""
function _expand_daily_meteorology_day!(
    values::AbstractMatrix{T}, rows::AbstractUnitRange{Int},
    meteorology::LegacyMeteorology{T}, day::Int, config::MeteorologyConfig{T},
    solar::MAESPASolarGeometry;
    rng::Random.AbstractRNG, draw_rain::Bool=true,
) where {T<:AbstractFloat}
    source = meteorology.config
    steps = source.steps_per_day
    tmin = _meteorology_source_value(meteorology, :minimum_air_temperature, day)
    tmax = _meteorology_source_value(meteorology, :maximum_air_temperature, day)
    isfinite(tmin) && isfinite(tmax) && tmin <= tmax || throw(
        ArgumentError("daily TMIN/TMAX must be finite and ordered at source line $(meteorology.source_lines[day])"),
    )
    geometry = solar_day_geometry(solar, legacy_dayjul(meteorology.date50[day]))
    zero(T) < geometry.day_length_steps < T(steps) || throw(
        DomainError(geometry.day_length_steps, "CALCTHRLY requires a day with sunrise and sunset"),
    )
    temperature = _daily_air_temperatures(tmin, tmax, geometry.day_length_steps, steps)
    precipitation = something(_meteorology_source_value(meteorology, :precipitation, day), zero(T))
    isfinite(precipitation) && precipitation >= zero(T) || throw(ArgumentError("daily PPT must be finite and nonnegative"))
    global_radiation = _meteorology_source_value(meteorology, :daily_global_radiation, day)
    par = isnothing(global_radiation) ?
        _meteorology_source_value(meteorology, :daily_incident_par, day) : global_radiation * T(0.5)
    if isnothing(par)
        par = _bristow_daily_par(source.bristow, meteorology.date50[day],
            tmin, tmax, precipitation, solar.latitude_rad,
            geometry.solar_declination_rad, geometry.day_length_steps, steps, solar.solar_constant)
    end
    isfinite(par) && par >= zero(T) || throw(ArgumentError("daily PAR/SI must be finite and nonnegative"))
    beam = _meteorology_source_value(meteorology, :beam_fraction, day)
    if isnothing(beam)
        extraterrestrial = _daily_extraterrestrial_radiation(solar, meteorology.date50[day], geometry, source.step_seconds)
        beam = _daily_beam_fraction(par, extraterrestrial)
    end
    isfinite(beam) && zero(T) <= beam <= one(T) || throw(ArgumentError("daily FBEAM must be between zero and one"))
    radiation, fractions = _daily_par_distribution(par, beam, geometry.sun_zenith_rad, source.step_seconds)
    rain = draw_rain ? _daily_rainfall(precipitation, steps, rng) : zeros(T, steps)
    wind = something(_meteorology_source_value(meteorology, :wind_speed, day), T(2.5))
    isfinite(wind) || throw(ArgumentError("daily WIND must be finite"))
    wind <= zero(T) && (wind = T(2.5)) # GETMETDAY, unlike GETMETHR's 0.001.
    values[rows, 1] = temperature
    values[rows, 2] .= tmin # Original minimum, not the sampled curve's minimum.
    values[rows, 3] = radiation ./ T(0.5)
    values[rows, 4] = fractions
    values[rows, 5] .= wind
    values[rows, 6] = rain
    for column in config.columns[7:end]
        values[rows, column.source_index] .= _meteorology_source_value(meteorology, column.variable, day)
    end
    return nothing
end

"""
    expand_daily_meteorology(meteorology, solar_geometry; rng=Random.default_rng())

Prepare `DAYORHR=0` forcing using the historical `GETMETDAY`, `CALCTHRLY`,
`CALCFBMD`, `CALCPARHRLY` and `ASSIGNRAIN` equations. Daily PAR and SI are
MJ m⁻² d⁻¹, not photon fluxes; SI takes precedence when both are supplied.
The returned `LegacyMeteorology` contains subdaily source fields consumed by
the ordinary meteorology model. The original table is not modified.

Rain is drawn once during preparation. Pass a seeded Julia RNG for repeatable
scenarios; `continue!` reuses the same prepared forcing. Julia does not promise
the Fortran random sequence. The complete source is expanded before slicing,
so a fixed RNG seed also preserves rainfall when starting part-way through it.

The historical daily reader leaves soil temperature undefined. This port uses
the existing estimated daily-mean-air fallback, never marks it as measured,
and rejects daily ET whose meaning is not implemented. Daily RTHERM is ignored
with one warning per preparation call: thermal radiation is reconstructed as in
`GETMETDAY`, never marked as measured. If neither SI nor PAR is supplied, the
typed `BRISTO.DELTAT` parameters estimate daily PAR.
"""
function expand_daily_meteorology(
    meteorology::LegacyMeteorology{T},
    solar_config::SolarGeometryConfig;
    rng::Random.AbstractRNG=Random.default_rng(),
) where {T<:AbstractFloat}
    source = meteorology.config
    source.frequency === DailyMeteorology || throw(ArgumentError("expected daily meteorology"))
    solar_config.steps_per_day == source.steps_per_day || throw(
        ArgumentError("meteorology and solar geometry steps_per_day disagree"),
    )
    config = _expanded_daily_meteorology_config(source)
    if haskey(source.column_lookup, :thermal_radiation)
        @warn "Daily RTHERM is ignored; thermal radiation is reconstructed as in GETMETDAY (source: $(source.source))" source=source.source
    end
    solar = MAESPASolarGeometry(SolarGeometryConfig(
        T(solar_config.latitude_rad), T(solar_config.time_difference_steps),
        T(solar_config.scene_bearing_rad), source.steps_per_day;
        solar_constant=T(solar_config.solar_constant),
        reference_astronomical_day=solar_config.reference_astronomical_day,
    ))
    steps = source.steps_per_day
    values = Matrix{T}(undef, length(meteorology) * steps, config.column_count)
    for day in 1:length(meteorology)
        rows = ((day - 1) * steps + 1):(day * steps)
        _expand_daily_meteorology_day!(values, rows, meteorology, day, config, solar; rng)
    end
    return LegacyMeteorology(
        config, values, repeat(meteorology.date50; inner=steps),
        repeat(collect(1:steps), length(meteorology)),
        isnothing(meteorology.declared_day) ? nothing : repeat(meteorology.declared_day; inner=steps),
        nothing, repeat(meteorology.source_lines; inner=steps), copy(meteorology.diagnostics),
    )
end

"""BRISTO/PAR distribution for one complete, already-validated source day."""
function _bristow_subdaily_radiation_day(
    meteorology::LegacyMeteorology{T}, rows::AbstractUnitRange{Int},
    solar::MAESPASolarGeometry,
) where {T<:AbstractFloat}
    source = meteorology.config
    temperature = meteorology_column(meteorology, :air_temperature)
    precipitation = meteorology_column(meteorology, :precipitation)
    tmin, tmax = extrema(@view temperature[rows])
    rain = isnothing(precipitation) ? zero(T) : sum(@view precipitation[rows])
    date50 = meteorology.date50[first(rows)]
    geometry = solar_day_geometry(solar, legacy_dayjul(date50))
    par = _bristow_daily_par(source.bristow, date50, tmin, tmax, rain,
        solar.latitude_rad, geometry.solar_declination_rad, geometry.day_length_steps,
        source.steps_per_day, solar.solar_constant)
    isfinite(par) && par >= zero(T) || throw(DomainError(par, "BRISTO daily PAR must be finite and nonnegative"))
    extraterrestrial = _daily_extraterrestrial_radiation(solar, date50, geometry, source.step_seconds)
    beam = _daily_beam_fraction(par, extraterrestrial)
    par_steps, _ = _daily_par_distribution(par, beam, geometry.sun_zenith_rad, source.step_seconds)
    return par_steps ./ T(0.5)
end

function _bristow_meteorology_config(source::MeteorologyConfig)
    columns = [source.columns; MeteorologyColumn(source.column_count + 1, "RAD", :global_radiation)]
    lookup = copy(source.column_lookup)
    lookup[:global_radiation] = length(columns)
    return MeteorologyConfig(
        source.source, source.title, source.data_start_line, source.day_or_hour,
        source.frequency, source.steps_per_day, source.step_seconds, length(columns), length(columns),
        columns, lookup, source.start_date, source.end_date, source.constant_co2,
        source.constant_pressure_pa, source.diffuse_sky, source.soil_water_min,
        source.soil_water_max, copy(source.diagnostics), source.bristow,
    )
end

"""Fill absent subdaily radiation using BRISTO without altering measured weather columns."""
function _bristow_subdaily_meteorology(meteorology::LegacyMeteorology{T}, solar_config::SolarGeometryConfig) where {T}
    source = meteorology.config
    steps = source.steps_per_day
    steps == solar_config.steps_per_day || throw(ArgumentError("meteorology and solar geometry steps_per_day disagree"))
    iszero(length(meteorology) % steps) || throw(ArgumentError("subdaily BRISTO requires complete meteorological days"))
    isnothing(source.bristow) && throw(ArgumentError("missing BRISTO parameters"))
    solar = MAESPASolarGeometry(SolarGeometryConfig(
        T(solar_config.latitude_rad), T(solar_config.time_difference_steps),
        T(solar_config.scene_bearing_rad), steps;
        solar_constant=T(solar_config.solar_constant),
        reference_astronomical_day=solar_config.reference_astronomical_day,
    ))
    radiation = Vector{T}(undef, length(meteorology))
    temperature = meteorology_column(meteorology, :air_temperature)
    precipitation = meteorology_column(meteorology, :precipitation)
    all(isfinite, temperature) || throw(ArgumentError("BRISTO air temperatures must be finite"))
    isnothing(precipitation) || all(value -> isfinite(value) && value >= zero(T), precipitation) || throw(
        ArgumentError("BRISTO precipitation must be finite and nonnegative"),
    )
    for first_record in 1:steps:length(meteorology)
        rows = first_record:(first_record + steps - 1)
        radiation[rows] = _bristow_subdaily_radiation_day(meteorology, rows, solar)
    end
    config = _bristow_meteorology_config(source)
    return LegacyMeteorology(config, hcat(meteorology.values, radiation),
        copy(meteorology.date50), copy(meteorology.step_index),
        isnothing(meteorology.declared_day) ? nothing : copy(meteorology.declared_day),
        isnothing(meteorology.declared_step) ? nothing : copy(meteorology.declared_step),
        copy(meteorology.source_lines), copy(meteorology.diagnostics))
end
