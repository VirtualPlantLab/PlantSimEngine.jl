function _meteorology_source_value(
    meteorology::LegacyMeteorology{T},
    variable::Symbol,
    row::Int,
) where {T}
    column_index = get(meteorology.config.column_lookup, variable, nothing)
    isnothing(column_index) && return nothing
    return meteorology.values[row, column_index]
end

function _meteorology_daily_air_statistics(meteorology::LegacyMeteorology{T}) where {T}
    air_temperature = meteorology_column(meteorology, :air_temperature)
    isnothing(air_temperature) && throw(
        ArgumentError("subdaily meteorology requires an air-temperature column"),
    )
    record_count = length(meteorology)
    daily_minimum = Vector{T}(undef, record_count)
    daily_mean = Vector{T}(undef, record_count)
    steps_per_day = meteorology.config.steps_per_day
    for first_record in 1:steps_per_day:record_count
        last_record = min(first_record + steps_per_day - 1, record_count)
        temperatures = @view air_temperature[first_record:last_record]
        minimum_temperature = minimum(temperatures)
        mean_temperature = sum(temperatures) / T(length(temperatures))
        daily_minimum[first_record:last_record] .= minimum_temperature
        daily_mean[first_record:last_record] .= mean_temperature
    end
    return daily_minimum, daily_mean
end

"""
    _meteorology_moving_average_air_temperature(meteorology, records)

Prepare the historical `TMOVE` forcing for one simulation slice. MAESPA adds
the whole current meteorological day to its temperature memory before running
any of that day's subdaily steps, then averages at most `7 * KHRS` values.
Consequently every selected step of one day receives the same value, including
when the simulation starts part-way through that day. History starts with the
day containing `first(records)`; source days before the requested simulation
start are deliberately excluded.
"""
function _meteorology_moving_average_air_temperature(
    meteorology::LegacyMeteorology{T},
    records::AbstractUnitRange{<:Integer},
) where {T<:AbstractFloat}
    air_temperature = meteorology_column(meteorology, :air_temperature)
    isnothing(air_temperature) && throw(
        ArgumentError("subdaily meteorology requires an air-temperature column"),
    )
    isempty(records) && return T[]

    steps_per_day = meteorology.config.steps_per_day
    first_record = Int(first(records))
    last_record = Int(last(records))
    first_step = meteorology.step_index[first_record]
    simulation_first_day_record = first_record - first_step + 1
    maximum_window_records = 7 * steps_per_day
    moving_average = Vector{T}(undef, length(records))
    destination = 1

    day_first_record = simulation_first_day_record
    while day_first_record <= last_record
        day_last_record = min(
            day_first_record + steps_per_day - 1,
            length(meteorology),
        )
        window_first_record = max(
            simulation_first_day_record,
            day_last_record - maximum_window_records + 1,
        )
        window = @view air_temperature[window_first_record:day_last_record]
        temperature_sum = sum(window; init=zero(T))
        temperature_mean = temperature_sum / T(length(window))

        selected_first_record = max(first_record, day_first_record)
        selected_last_record = min(last_record, day_last_record)
        selected_count = selected_last_record - selected_first_record + 1
        fill!(
            @view(moving_average[destination:(destination + selected_count - 1)]),
            temperature_mean,
        )
        destination += selected_count
        day_first_record += steps_per_day
    end

    destination == length(moving_average) + 1 || error(
        "internal meteorology moving-average alignment error",
    )
    return moving_average
end

function _meteorology_block_day_consistency(meteorology::LegacyMeteorology)
    consistency = trues(length(meteorology))
    isnothing(meteorology.declared_day) && return consistency
    steps_per_day = meteorology.config.steps_per_day
    for first_record in 1:steps_per_day:length(meteorology)
        last_record = min(first_record + steps_per_day - 1, length(meteorology))
        day_key = meteorology.declared_day[first_record]
        consistent = all(
            ==(day_key),
            @view(meteorology.declared_day[first_record:last_record]),
        )
        consistency[first_record:last_record] .= consistent
    end
    return consistency
end

_meteorology_day50(date::LegacyDate) = date.days_since_1950
_meteorology_day50(date::Integer) = Int(date)

function _meteorology_record_range(
    meteorology::LegacyMeteorology,
    start_date,
    step_index::Integer,
    end_date,
    require_coverage::Bool,
)
    config = meteorology.config
    config.frequency === SubdailyMeteorology || throw(ArgumentError(
        "record selection requires subdaily forcing; expand daily meteorology first",
    ))
    1 <= step_index <= config.steps_per_day || throw(
        BoundsError(1:config.steps_per_day, step_index),
    )
    start_date50 = _meteorology_day50(start_date)
    offset_days = start_date50 - config.start_date.days_since_1950
    offset_days >= 0 || throw(ArgumentError("requested date precedes meteorology STARTDATE"))
    first_record = offset_days * config.steps_per_day + Int(step_index)
    first_record <= length(meteorology) || throw(
        BoundsError(meteorology, first_record),
    )

    last_record = if isnothing(end_date)
        length(meteorology)
    else
        end_date50 = _meteorology_day50(end_date)
        end_date50 >= start_date50 || throw(ArgumentError("end date precedes start date"))
        requested = (
            end_date50 - config.start_date.days_since_1950 + 1
        ) * config.steps_per_day
        if requested > length(meteorology)
            require_coverage && throw(
                ArgumentError(
                    "meteorology has $(length(meteorology)) records but record " *
                    "$requested is required by the requested end date",
                ),
            )
            length(meteorology)
        else
            requested
        end
    end
    return first_record:last_record
end

function _meteorology_midpoint(
    date50::Integer,
    step_index::Integer,
    step_seconds::T,
) where {T<:AbstractFloat}
    civil_day = Date(1950, 1, 1) + Day(Int(date50) - 1)
    milliseconds = round(
        Int,
        (T(step_index) - one(T) / T(2)) * step_seconds * T(1000),
    )
    return DateTime(civil_day) + Millisecond(milliseconds)
end

function _meteorology_environment_row(
    meteorology::LegacyMeteorology{T},
    row::Int,
    daily_minimum::AbstractVector{T},
    daily_mean::AbstractVector{T},
    moving_average_air_temperature::T,
    block_consistency::AbstractVector{Bool},
) where {T}
    declared_day = isnothing(meteorology.declared_day) ? nothing :
                   meteorology.declared_day[row]
    declared_step = isnothing(meteorology.declared_step) ? nothing :
                    meteorology.declared_step[row]
    config = meteorology.config
    return (
        date=_meteorology_midpoint(
            meteorology.date50[row],
            meteorology.step_index[row],
            config.step_seconds,
        ),
        duration=config.step_seconds,
        source_line=meteorology.source_lines[row],
        raw_declared_day=declared_day,
        raw_declared_step=declared_step,
        raw_block_day_consistent=block_consistency[row],
        raw_daily_minimum_air_temperature=daily_minimum[row],
        raw_daily_mean_air_temperature=daily_mean[row],
        raw_moving_average_air_temperature=moving_average_air_temperature,
        raw_wind_speed=_meteorology_source_value(meteorology, :wind_speed, row),
        raw_air_temperature=_meteorology_source_value(
            meteorology,
            :air_temperature,
            row,
        ),
        raw_soil_temperature=_meteorology_source_value(
            meteorology,
            :soil_temperature,
            row,
        ),
        raw_relative_humidity=_meteorology_source_value(
            meteorology,
            :relative_humidity,
            row,
        ),
        raw_relative_humidity_percent=_meteorology_source_value(
            meteorology,
            :relative_humidity_percent,
            row,
        ),
        raw_vapour_pressure_deficit=_meteorology_source_value(
            meteorology,
            :vapour_pressure_deficit,
            row,
        ),
        raw_incident_par_photons=_meteorology_source_value(
            meteorology,
            :incident_par_photons,
            row,
        ),
        raw_global_radiation=_meteorology_source_value(
            meteorology,
            :global_radiation,
            row,
        ),
        raw_beam_fraction=_meteorology_source_value(
            meteorology,
            :beam_fraction,
            row,
        ),
        raw_co2=_meteorology_source_value(meteorology, :co2, row),
        raw_mole_fraction_deficit=_meteorology_source_value(
            meteorology,
            :mole_fraction_deficit,
            row,
        ),
        raw_air_pressure=_meteorology_source_value(
            meteorology,
            :air_pressure,
            row,
        ),
        raw_dew_temperature=_meteorology_source_value(
            meteorology,
            :dew_temperature,
            row,
        ),
        raw_precipitation=_meteorology_source_value(
            meteorology,
            :precipitation,
            row,
        ),
        raw_measured_evapotranspiration=_meteorology_source_value(
            meteorology,
            :measured_evapotranspiration,
            row,
        ),
        raw_soil_moisture_deficit=_meteorology_source_value(
            meteorology,
            :soil_moisture_deficit,
            row,
        ),
        raw_soil_water_content=_meteorology_source_value(
            meteorology,
            :soil_water_content,
            row,
        ),
        raw_soil_water_potential=_meteorology_source_value(
            meteorology,
            :soil_water_potential,
            row,
        ),
        raw_thermal_radiation=_meteorology_source_value(
            meteorology,
            :thermal_radiation,
            row,
        ),
    )
end

# WATCONTROL modifies precipitation after GETMET (including BRISTO), before
# interception. Prepare complete days once, then slice for the simulation.
function _controlled_precipitation(
    meteorology::LegacyMeteorology{T};
    keep_dry::Bool=false,
    reassign_rain::Bool=false,
    rng::Random.AbstractRNG=Random.default_rng(),
) where {T<:AbstractFloat}
    (keep_dry || reassign_rain) || return nothing
    meteorology.config.frequency === SubdailyMeteorology || throw(
        ArgumentError("prepare daily meteorology before controlling precipitation"),
    )
    source = meteorology_column(meteorology, :precipitation)
    rain = isnothing(source) ? zeros(T, length(meteorology)) : copy(source)
    all(value -> isfinite(value) && value >= zero(T), rain) || throw(
        ArgumentError("precipitation must be finite and nonnegative"),
    )
    keep_dry && fill!(rain, zero(T))
    if reassign_rain
        steps = meteorology.config.steps_per_day
        iszero(length(rain) % steps) || throw(
            ArgumentError("REASSIGNRAIN requires complete source-day blocks before slicing"),
        )
        for first_record in 1:steps:length(rain)
            rows = first_record:(first_record + steps - 1)
            daily_total = sum(@view rain[rows])
            isfinite(daily_total) || throw(ArgumentError("daily precipitation total must be finite"))
            rain[rows] = _daily_rainfall(daily_total, steps, rng)
        end
    end
    return rain
end

"""
    meteorology_environment(meteorology; start_date, step_index=1, end_date=nothing,
                            solar_geometry=nothing, rng=Random.default_rng(),
                            keep_dry=false, reassign_rain=false,
                            source_day_stride=1, simulation_start_date=meteorology.config.start_date)

Build the PlantMeteo timestep table consumed by PlantSimEngine. The slice is
positional, matching `RESTARTMETF`; PSE itself does not align rows by `date`.
All numeric source fields and the physical duration retain `T`. The `TMOVE`
history is reset at this slice's `start_date`, while the complete first day is
included even when `step_index > 1`.
For daily input, supply `solar_geometry::SolarGeometryConfig`; the complete
source is first expanded by [`expand_daily_meteorology`](@ref). A seeded `rng`
makes the rainfall disaggregation reproducible. `build_model` supplies the site
geometry automatically and forwards its `meteorology_rng` keyword.

`keep_dry=true` suppresses rain before interception and infiltration.
`reassign_rain=true` redistributes each complete source day's total with the
historical ASSIGNRAIN rule and the supplied RNG. KEEPDRY takes precedence if
both are enabled. Controls apply after radiation reconstruction, without
modifying the input weather or other forcing fields. Preparation precedes date
selection; `continue!` reuses these values instead of drawing rain again.

With `source_day_stride > 1`, visit only dates on the configured
`simulation_start_date + k * source_day_stride` lattice, using ordinary
subdaily durations. Reconstruct complete visited days and prepare their rain
in source visit order, including a prefix from the configured anchor before
slicing at `start_date`/`step_index`. Skipped dates execute no reconstruction
or rain draws. Cold-start `TMOVE` still begins at the requested visited day.
Stride 1 preserves the existing complete-source, two-pass rain preparation;
neither branch promises the Fortran PRNG sequence.
"""
function meteorology_environment(
    meteorology::LegacyMeteorology{T};
    start_date=meteorology.config.start_date,
    step_index::Integer=1,
    end_date=nothing,
    require_coverage::Bool=true,
    solar_geometry=nothing,
    rng::Random.AbstractRNG=Random.default_rng(),
    keep_dry::Bool=false,
    reassign_rain::Bool=false,
    source_day_stride=1,
    simulation_start_date=meteorology.config.start_date,
) where {T<:AbstractFloat}
    stride = _checked_source_day_stride(source_day_stride)
    if stride != 1
        return _sparse_meteorology_environment(meteorology;
            start_date, step_index, end_date, require_coverage, solar_geometry,
            rng, keep_dry, reassign_rain, source_day_stride=stride,
            simulation_start_date)
    end
    if meteorology.config.frequency === DailyMeteorology
        isnothing(solar_geometry) && throw(ArgumentError(
            "daily meteorology requires solar_geometry::SolarGeometryConfig",
        ))
        expanded = expand_daily_meteorology(meteorology, solar_geometry; rng)
        return meteorology_environment(expanded; start_date, step_index, end_date,
            require_coverage, rng, keep_dry, reassign_rain)
    end
    if !haskey(meteorology.config.column_lookup, :global_radiation) &&
       !haskey(meteorology.config.column_lookup, :incident_par_photons)
        isnothing(solar_geometry) && throw(ArgumentError("BRISTO reconstruction requires solar_geometry::SolarGeometryConfig"))
        prepared = _bristow_subdaily_meteorology(meteorology, solar_geometry)
        return meteorology_environment(prepared; start_date, step_index, end_date,
            require_coverage, rng, keep_dry, reassign_rain)
    end
    controlled_rain = _controlled_precipitation(meteorology; keep_dry, reassign_rain, rng)
    records = _meteorology_record_range(
        meteorology,
        start_date,
        step_index,
        end_date,
        require_coverage,
    )
    daily_minimum, daily_mean = _meteorology_daily_air_statistics(meteorology)
    moving_average_air_temperature =
        _meteorology_moving_average_air_temperature(meteorology, records)
    block_consistency = _meteorology_block_day_consistency(meteorology)
    rows = [
        _meteorology_environment_row(
            meteorology,
            row,
            daily_minimum,
            daily_mean,
            moving_average_air_temperature[index],
            block_consistency,
        ) for (index, row) in enumerate(records)
    ]
    if !isnothing(controlled_rain)
        rows = [merge(row, (raw_precipitation=controlled_rain[index],))
            for (row, index) in zip(rows, records)]
    end
    metadata = (
        source=meteorology.config.source,
        start_record=first(records),
        end_record=last(records),
        frequency=:subdaily,
        units=(
            raw_air_temperature="degC",
            raw_moving_average_air_temperature="degC",
            raw_wind_speed="m s-1",
            raw_air_pressure="Pa",
            raw_precipitation="mm per step",
            raw_global_radiation="W m-2",
            raw_incident_par_photons="umol photons m-2 s-1",
        ),
    )
    return PlantMeteo.TimeStepTable(rows, metadata)
end
