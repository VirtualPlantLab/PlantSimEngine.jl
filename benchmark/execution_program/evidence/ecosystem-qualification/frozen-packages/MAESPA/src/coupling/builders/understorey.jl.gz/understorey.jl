# Understorey objects and the default patch-scale model bundle.

function _understorey_radiation_field_neighbourhood(
    scene::LegacyTreeScene,
    patches,
    shading_tree_count::Integer,
)
    tree_count = length(scene.trees)
    tree_count > 0 || throw(
        ArgumentError("computed understorey radiation requires at least one tree"),
    )
    count = _radiation_shading_tree_count(shading_tree_count, tree_count)
    patch_count = length(patches)
    patch_count > 0 || throw(ArgumentError("understorey requires at least one patch"))
    centre_x = sum(patch.position_m[1] for patch in patches) / patch_count
    centre_y = sum(patch.position_m[2] for patch in patches) / patch_count
    distances = [
        begin
            dx = tree.position[1] - centre_x
            dy = tree.position[2] - centre_y
            dx * dx + dy * dy
        end for tree in scene.trees
    ]
    permutation = sortperm(distances; alg=Base.Sort.MergeSort)
    selected = permutation[1:count]
    return RadiationFieldNeighbourhood(getfield.(scene.trees[selected], :id))
end

function _understorey_model_bundle(
    config::SimulationConfig{T},
    understorey,
    radiation,
    meteorology;
    simulation_step::Integer,
    structure_clock,
    tree_scene=nothing,
    species_set=nothing,
) where {T<:AbstractFloat}
    if isnothing(understorey) && isnothing(radiation)
        return nothing
    end
    isnothing(understorey) && throw(
        ArgumentError(
            "understorey_radiation requires an understorey configuration",
        ),
    )
    understorey isa UnderstoreyConfig{T} || throw(
        ArgumentError(
            "simulation and understorey configurations must use the same numeric type",
        ),
    )
    isnothing(meteorology) && throw(
        ArgumentError("the understorey slice requires meteorology"),
    )
    computed_radiation = isnothing(radiation)
    if computed_radiation
        isnothing(tree_scene) && throw(
            ArgumentError(
                "a configuration-only understorey requires PrescribedUnderstoreyRadiation",
            ),
        )
        isnothing(species_set) && throw(
            ArgumentError(
                "computed understorey radiation requires parsed species inputs",
            ),
        )
    else
        radiation isa PrescribedUnderstoreyRadiation || throw(
            ArgumentError(
                "understorey_radiation must be PrescribedUnderstoreyRadiation or nothing",
            ),
        )
    end
    moss_mode = !isnothing(understorey.physiology.moss)
    c4_mode = !moss_mode && !iszero(understorey.physiology.c4_fraction)

    patches = understorey.structure.patches
    patch_count = length(patches)
    patch_count > 0 || throw(ArgumentError("understorey requires at least one patch"))
    if !computed_radiation
        size(radiation.direct_par_w_m2, 2) == patch_count || throw(
            DimensionMismatch(
                "prescribed understorey radiation has " *
                "$(size(radiation.direct_par_w_m2, 2)) patches, expected $patch_count",
            ),
        )
    end
    simulation_step >= 0 || throw(
        DomainError(simulation_step, "simulation_step must be non-negative"),
    )
    if !computed_radiation
        required_row = Int(simulation_step) + 1
        size(radiation.direct_par_w_m2, 1) >= required_row || throw(
            BoundsError(radiation.direct_par_w_m2, (required_row, 1)),
        )
    end

    structure = understorey.structure
    structure_model = MAESPAUnderstoreyStructureTrajectory(understorey)
    current_date50 = config.start_date.days_since_1950 +
                     div(Int(simulation_step), config.steps_per_day)
    x0, y0 = structure.origin_m
    xmax, ymax = structure.upper_corner_m
    z0 = zero(T)
    parent = PlantSimEngine.Object(
        :understorey;
        scale=:Understorey,
        kind=:understorey,
        parent=:scene,
        name=:understorey,
        geometry=(
            position=(x=x0, y=y0, z=z0),
            bounds=(xmin=x0, xmax=xmax, ymin=y0, ymax=ymax),
            dimensions=(xmax - x0, ymax - y0),
        ),
        status=PlantSimEngine.Status(;
            understorey_patch_count=patch_count,
            understorey_ground_area_m2=structure.ground_area_m2,
        ),
    )
    patch_names = Tuple(Symbol("understorey_patch_", patch.id) for patch in patches)
    patch_objects = Tuple(begin
        initial_structure = understorey_structure_state(
            structure_model,
            current_date50,
            patch.id,
            T,
        )
        PlantSimEngine.Object(
            patch_names[index];
            scale=:UnderstoreyPatch,
            kind=:understorey_patch,
            parent=:understorey,
            name=patch_names[index],
            geometry=(
                position=(
                    x=patch.position_m[1],
                    y=patch.position_m[2],
                    z=z0,
                ),
            ),
            status=PlantSimEngine.Status(;
                understorey_patch_index=patch.id,
                understorey_patch_area_m2=patch.area_m2,
                understorey_patch_x_m=patch.position_m[1],
                understorey_patch_y_m=patch.position_m[2],
                understorey_height_m=initial_structure.height_m,
                understorey_leaf_area_index=initial_structure.leaf_area_index,
                understorey_mean_leaf_nitrogen_g_m2=
                    initial_structure.mean_leaf_nitrogen_g_m2,
                understorey_top_leaf_nitrogen_g_m2=
                    initial_structure.top_leaf_nitrogen_g_m2,
                understorey_vertical_extinction_coefficient=
                    initial_structure.vertical_extinction_coefficient,
                understorey_structure_available=true,
            ),
        )
    end for (index, patch) in pairs(patches))

    scene_application(application, variable) = PlantSimEngine.One(
        scale=:Scene,
        kind=:scene,
        within=PlantSimEngine.Ancestor(scale=:Scene),
        application=application,
        var=variable,
    )
    self_application(application, variable) = PlantSimEngine.One(
        within=PlantSimEngine.Self(),
        application=application,
        var=variable,
    )
    self_status(variable) = PlantSimEngine.One(
        within=PlantSimEngine.Self(),
        var=variable,
        from_status=true,
    )
    parent_application(application, variable) = PlantSimEngine.One(
        scale=:Understorey,
        kind=:understorey,
        within=PlantSimEngine.Ancestor(scale=:Understorey),
        application=application,
        var=variable,
    )
    patch_application(application, variable) = PlantSimEngine.Many(
        scale=:UnderstoreyPatch,
        kind=:understorey_patch,
        id=patch_names,
        within=PlantSimEngine.Subtree(),
        application=application,
        var=variable,
    )
    patch_status(variable) = PlantSimEngine.Many(
        scale=:UnderstoreyPatch,
        kind=:understorey_patch,
        id=patch_names,
        within=PlantSimEngine.Subtree(),
        var=variable,
        from_status=true,
    )

    parameter_model = moss_mode ? nothing :
                      MAESPAUnderstoreyBewdyParameters(understorey)
    absorption_model = MAESPAUnderstoreyShortwaveAbsorption(understorey)
    photosynthesis_model = moss_mode ?
                           MAESPAUnderstoreyMossPhotosynthesis(understorey) :
                           c4_mode ?
                           MAESPAUnderstoreyC3C4Photosynthesis(understorey) :
                           MAESPAUnderstoreyBewdyPhotosynthesis(understorey)
    conductance_model = moss_mode ?
                        MAESPAUnderstoreyZeroStomatalConductance(understorey) :
                        c4_mode ?
                        MAESPAUnderstoreyC3C4StomatalConductance(understorey) :
                        MAESPAUnderstoreyStomatalConductance(understorey)
    respiration_model = moss_mode ?
                        MAESPAUnderstoreyNoRespiration(understorey) :
                        MAESPAUnderstoreyConstantDayRespiration(understorey)
    transpiration_model = MAESPAUnderstoreyTranspiration(T)
    radiation_aggregation_model = MAESPAUnderstoreyRadiationAggregation(
        T;
        patch_count=patch_count,
    )
    aggregation_model = MAESPAUnderstoreyFluxAggregation(
        T;
        patch_count=patch_count,
    )

    structure_application = PlantSimEngine.ModelSpec(
        structure_model;
        name=:understorey_structure_trajectory,
        on=PlantSimEngine.Many(
            scale=:UnderstoreyPatch,
            kind=:understorey_patch,
            id=patch_names,
        ),
        every=structure_clock,
        inputs=(
            date50=scene_application(:legacy_calendar, :date50),
            understorey_patch_index=self_status(:understorey_patch_index),
        ),
    )
    radiation_applications = if !computed_radiation
        (
            PlantSimEngine.ModelSpec(
                MAESPAPrescribedUnderstoreyRadiation(radiation);
                name=:understorey_radiation,
                on=PlantSimEngine.Many(
                    scale=:UnderstoreyPatch,
                    kind=:understorey_patch,
                    id=patch_names,
                ),
                inputs=(
                    simulation_step=scene_application(
                        :legacy_calendar,
                        :simulation_step,
                    ),
                    understorey_patch_index=self_status(
                        :understorey_patch_index,
                    ),
                ),
            ),
        )
    else
        field = _understorey_radiation_field_neighbourhood(
            tree_scene,
            patches,
            config.shading_tree_count,
        )
        crown_names = Tuple(_radiation_crown_name.(field.tree_ids))
        crown_status(variable) =
            _radiation_many_status_input(crown_names, variable)
        crown_process(process, variable) =
            _radiation_many_process_input(crown_names, process, variable)
        reference_crown(process, variable) = PlantSimEngine.One(
            scale=:Crown,
            id=first(crown_names),
            within=PlantSimEngine.SceneScope(),
            application=_radiation_mounted_application(
                first(field.tree_ids),
                process,
            ),
            var=variable,
        )
        common = (
            all_tree_x_m=crown_status(:tree_x_m),
            all_tree_y_m=crown_status(:tree_y_m),
            all_tree_z_m=crown_status(:tree_z_m),
            all_radius_x=crown_process(:crown_geometry, :radius_x),
            all_radius_y=crown_process(:crown_geometry, :radius_y),
            all_crown_depth=crown_process(:crown_geometry, :crown_depth),
            all_crown_base_height=crown_process(
                :crown_geometry,
                :crown_base_height,
            ),
            all_leaf_area=crown_process(:crown_geometry, :leaf_area),
            all_uniform_leaf_area_density=crown_process(
                :leaf_area_distribution,
                :uniform_leaf_area_density,
            ),
            all_leaf_density_coefficients=crown_process(
                :species_structure_trajectory,
                :leaf_density_coefficients,
            ),
            all_structural_age_proportions=crown_process(
                :species_physiology_trajectory,
                :structural_foliage_age_proportions,
            ),
            all_crown_shape_code=crown_process(
                :species_structure_trajectory,
                :crown_shape_code,
            ),
            all_leaf_density_legacy_mode=crown_process(
                :species_structure_trajectory,
                :leaf_density_legacy_mode,
            ),
            all_understorey_patch_index=patch_status(
                :understorey_patch_index,
            ),
            all_understorey_patch_x_m=patch_status(
                :understorey_patch_x_m,
            ),
            all_understorey_patch_y_m=patch_status(
                :understorey_patch_y_m,
            ),
            all_understorey_height_m=patch_application(
                :understorey_structure_trajectory,
                :understorey_height_m,
            ),
            all_understorey_structure_available=patch_application(
                :understorey_structure_trajectory,
                :understorey_structure_available,
            ),
            slope_x_rad=_radiation_scene_status_input(:plot_slope_x_rad),
            slope_y_rad=_radiation_scene_status_input(:plot_slope_y_rad),
            plot_width=_radiation_scene_status_input(:plot_width_m),
            plot_height=_radiation_scene_status_input(:plot_height_m),
            shade_height=_radiation_scene_status_input(:shade_height_m),
        )
        diffuse_model = MAESPAUnderstoreyDiffuseTransmission(
            T,
            field,
            config.zenith_angles,
            config.azimuth_angles,
            patch_count,
        )
        direct_model = MAESPAUnderstoreyDirectTransmission(
            T,
            field,
            patch_count;
            retain_crown_structure=config.diffuse_transmission_interval_days > 0,
        )
        interval_steps = iszero(config.diffuse_transmission_interval_days) ?
                         nothing :
                         config.diffuse_transmission_interval_days *
                         config.steps_per_day
        controller_model = MAESPAUnderstoreyDiffuseTransmissionController(
            T,
            interval_steps,
        )
        (
            PlantSimEngine.ModelSpec(
                diffuse_model;
                name=:understorey_diffuse_transmission,
                on=PlantSimEngine.One(
                    scale=:Understorey,
                    kind=:understorey,
                    id=:understorey,
                ),
                inputs=merge(
                    common,
                    (
                        diffuse_zenith_angles_rad=reference_crown(
                            :diffuse_extinction,
                            :diffuse_zenith_class_centres_rad,
                        ),
                        all_diffuse_zenith_angles_rad=crown_process(
                            :diffuse_extinction,
                            :diffuse_zenith_class_centres_rad,
                        ),
                        all_diffuse_extinction_coefficients=crown_process(
                            :diffuse_extinction,
                            :diffuse_extinction_coefficients,
                        ),
                        diffuse_sky=_radiation_scene_status_input(
                            :diffuse_sky,
                        ),
                    ),
                ),
            ),
            PlantSimEngine.ModelSpec(
                controller_model;
                name=:understorey_diffuse_transmission_control,
                on=PlantSimEngine.One(
                    scale=:Understorey,
                    kind=:understorey,
                    id=:understorey,
                ),
                every=PlantSimEngine.ClockSpec(1, 1),
                inputs=(
                    simulation_step=scene_application(
                        :legacy_calendar,
                        :simulation_step,
                    ),
                    all_understorey_height_m=patch_application(
                        :understorey_structure_trajectory,
                        :understorey_height_m,
                    ),
                    all_crown_radius_x=crown_process(
                        :crown_geometry,
                        :radius_x,
                    ),
                    all_diffuse_extinction_coefficients=crown_process(
                        :diffuse_extinction,
                        :diffuse_extinction_coefficients,
                    ),
                ),
                calls=(
                    transmission=PlantSimEngine.One(
                        within=PlantSimEngine.Self(),
                        application=:understorey_diffuse_transmission,
                    ),
                ),
            ),
            PlantSimEngine.ModelSpec(
                direct_model;
                name=:understorey_direct_transmission,
                on=PlantSimEngine.One(
                    scale=:Understorey,
                    kind=:understorey,
                    id=:understorey,
                ),
                inputs=merge(
                    common,
                    (
                        all_beam_extinction_coefficient=crown_process(
                            :beam_extinction,
                            :beam_extinction_coefficient,
                        ),
                        all_beam_extinction_by_leaf_angle=crown_process(
                            :beam_extinction,
                            :beam_extinction_by_leaf_angle,
                        ),
                        sun_zenith_rad=scene_application(
                            :solar_geometry,
                            :sun_zenith_rad,
                        ),
                        sun_azimuth_rad=scene_application(
                            :solar_geometry,
                            :sun_azimuth_scene_rad,
                        ),
                        astronomical_daylight=scene_application(
                            :solar_geometry,
                            :astronomical_daylight,
                        ),
                        incident_par_w_m2=scene_application(
                            :meteorology,
                            :incident_par_w_m2,
                        ),
                        beam_fraction_par=scene_application(
                            :meteorology,
                            :beam_fraction_par,
                        ),
                        beam_fraction_nir=scene_application(
                            :meteorology,
                            :beam_fraction_nir,
                        ),
                    ),
                    direct_model.retain_crown_structure ? (
                        understorey_diffuse_transmission_generation=self_application(
                            :understorey_diffuse_transmission_control,
                            :understorey_diffuse_transmission_generation,
                        ),
                        understorey_diffuse_field_available=self_application(
                            :understorey_diffuse_transmission,
                            :understorey_diffuse_field_available,
                        ),
                    ) : NamedTuple(),
                ),
            ),
            PlantSimEngine.ModelSpec(
                MAESPAComputedUnderstoreyRadiation(T, patch_count);
                name=:understorey_radiation,
                on=PlantSimEngine.Many(
                    scale=:UnderstoreyPatch,
                    kind=:understorey_patch,
                    id=patch_names,
                ),
                inputs=(
                    understorey_patch_index=self_status(
                        :understorey_patch_index,
                    ),
                    incident_par_w_m2=scene_application(
                        :meteorology,
                        :incident_par_w_m2,
                    ),
                    beam_fraction_par=scene_application(
                        :meteorology,
                        :beam_fraction_par,
                    ),
                    astronomical_daylight=scene_application(
                        :solar_geometry,
                        :astronomical_daylight,
                    ),
                    understorey_direct_transmittance=parent_application(
                        :understorey_direct_transmission,
                        :understorey_direct_transmittance,
                    ),
                    understorey_diffuse_transmittance=parent_application(
                        :understorey_diffuse_transmission,
                        :understorey_diffuse_transmittance,
                    ),
                    understorey_direct_field_available=parent_application(
                        :understorey_direct_transmission,
                        :understorey_direct_field_available,
                    ),
                    understorey_diffuse_field_available=parent_application(
                        :understorey_diffuse_transmission,
                        :understorey_diffuse_field_available,
                    ),
                    understorey_diffuse_transmission_generation=
                        parent_application(
                            :understorey_diffuse_transmission_control,
                            :understorey_diffuse_transmission_generation,
                        ),
                    meteorology_reconstruction_available=scene_application(
                        :meteorology,
                        :meteorology_reconstruction_available,
                    ),
                ),
            ),
        )
    end

    parameter_applications = if moss_mode
        ()
    else
        (
            PlantSimEngine.ModelSpec(
                parameter_model;
                name=:understorey_bewdy_parameters,
                on=PlantSimEngine.One(
                    scale=:Understorey,
                    kind=:understorey,
                    id=:understorey,
                ),
                inputs=(
                    air_temperature_c=scene_application(
                        :meteorology,
                        :air_temperature_c,
                    ),
                    relative_humidity=scene_application(
                        :meteorology,
                        :relative_humidity,
                    ),
                    co2_umol_mol=scene_application(
                        :meteorology,
                        :co2_umol_mol,
                    ),
                    meteorology_reconstruction_available=scene_application(
                        :meteorology,
                        :meteorology_reconstruction_available,
                    ),
                ),
            ),
        )
    end
    photosynthesis_inputs = if moss_mode
        (
            understorey_incident_par_w_m2=self_application(
                :understorey_shortwave_absorption,
                :understorey_incident_par_w_m2,
            ),
            air_temperature_c=scene_application(
                :meteorology,
                :air_temperature_c,
            ),
            co2_umol_mol=scene_application(
                :meteorology,
                :co2_umol_mol,
            ),
            astronomical_daylight=scene_application(
                :solar_geometry,
                :astronomical_daylight,
            ),
            understorey_shortwave_absorption_available=self_application(
                :understorey_shortwave_absorption,
                :understorey_shortwave_absorption_available,
            ),
            meteorology_reconstruction_available=scene_application(
                :meteorology,
                :meteorology_reconstruction_available,
            ),
        )
    elseif c4_mode
        (
            understorey_direct_par_w_m2=self_application(
                :understorey_radiation,
                :understorey_direct_par_w_m2,
            ),
            understorey_diffuse_par_w_m2=self_application(
                :understorey_radiation,
                :understorey_diffuse_par_w_m2,
            ),
            understorey_sunlit_leaf_area_index=self_application(
                :understorey_shortwave_absorption,
                :understorey_sunlit_leaf_area_index,
            ),
            understorey_canopy_interception_fraction=self_application(
                :understorey_shortwave_absorption,
                :understorey_canopy_interception_fraction,
            ),
            understorey_leaf_area_index=self_application(
                :understorey_structure_trajectory,
                :understorey_leaf_area_index,
            ),
            understorey_top_leaf_nitrogen_g_m2=self_application(
                :understorey_structure_trajectory,
                :understorey_top_leaf_nitrogen_g_m2,
            ),
            understorey_bewdy_alpha=parent_application(
                :understorey_bewdy_parameters,
                :understorey_bewdy_alpha,
            ),
            understorey_bewdy_lambda=parent_application(
                :understorey_bewdy_parameters,
                :understorey_bewdy_lambda,
            ),
            air_temperature_c=scene_application(
                :meteorology,
                :air_temperature_c,
            ),
            co2_umol_mol=scene_application(
                :meteorology,
                :co2_umol_mol,
            ),
            astronomical_daylight=scene_application(
                :solar_geometry,
                :astronomical_daylight,
            ),
            understorey_shortwave_absorption_available=self_application(
                :understorey_shortwave_absorption,
                :understorey_shortwave_absorption_available,
            ),
            understorey_bewdy_parameters_available=parent_application(
                :understorey_bewdy_parameters,
                :understorey_bewdy_parameters_available,
            ),
            meteorology_reconstruction_available=scene_application(
                :meteorology,
                :meteorology_reconstruction_available,
            ),
        )
    else
        (
            understorey_direct_par_w_m2=self_application(
                :understorey_radiation,
                :understorey_direct_par_w_m2,
            ),
            understorey_diffuse_par_w_m2=self_application(
                :understorey_radiation,
                :understorey_diffuse_par_w_m2,
            ),
            understorey_sunlit_leaf_area_index=self_application(
                :understorey_shortwave_absorption,
                :understorey_sunlit_leaf_area_index,
            ),
            understorey_canopy_interception_fraction=self_application(
                :understorey_shortwave_absorption,
                :understorey_canopy_interception_fraction,
            ),
            understorey_top_leaf_nitrogen_g_m2=self_application(
                :understorey_structure_trajectory,
                :understorey_top_leaf_nitrogen_g_m2,
            ),
            understorey_bewdy_alpha=parent_application(
                :understorey_bewdy_parameters,
                :understorey_bewdy_alpha,
            ),
            understorey_bewdy_lambda=parent_application(
                :understorey_bewdy_parameters,
                :understorey_bewdy_lambda,
            ),
            astronomical_daylight=scene_application(
                :solar_geometry,
                :astronomical_daylight,
            ),
            understorey_shortwave_absorption_available=self_application(
                :understorey_shortwave_absorption,
                :understorey_shortwave_absorption_available,
            ),
            understorey_bewdy_parameters_available=parent_application(
                :understorey_bewdy_parameters,
                :understorey_bewdy_parameters_available,
            ),
        )
    end
    conductance_inputs = if moss_mode
        (
            understorey_exchange_active=self_application(
                :understorey_photosynthesis,
                :understorey_exchange_active,
            ),
            understorey_photosynthesis_available=self_application(
                :understorey_photosynthesis,
                :understorey_photosynthesis_available,
            ),
        )
    elseif c4_mode
        (
            understorey_c3_gross_assimilation_umol_co2_m2_ground_s=
                self_application(
                    :understorey_photosynthesis,
                    :understorey_c3_gross_assimilation_umol_co2_m2_ground_s,
                ),
            understorey_c4_gross_assimilation_umol_co2_m2_ground_s=
                self_application(
                    :understorey_photosynthesis,
                    :understorey_c4_gross_assimilation_umol_co2_m2_ground_s,
                ),
            relative_humidity=scene_application(
                :meteorology,
                :relative_humidity,
            ),
            co2_umol_mol=scene_application(
                :meteorology,
                :co2_umol_mol,
            ),
            understorey_exchange_active=self_application(
                :understorey_photosynthesis,
                :understorey_exchange_active,
            ),
            understorey_photosynthesis_available=self_application(
                :understorey_photosynthesis,
                :understorey_photosynthesis_available,
            ),
            meteorology_reconstruction_available=scene_application(
                :meteorology,
                :meteorology_reconstruction_available,
            ),
        )
    else
        (
            understorey_gross_assimilation_umol_co2_m2_ground_s=
                self_application(
                    :understorey_photosynthesis,
                    :understorey_gross_assimilation_umol_co2_m2_ground_s,
                ),
            relative_humidity=scene_application(
                :meteorology,
                :relative_humidity,
            ),
            co2_umol_mol=scene_application(
                :meteorology,
                :co2_umol_mol,
            ),
            understorey_exchange_active=self_application(
                :understorey_photosynthesis,
                :understorey_exchange_active,
            ),
            understorey_photosynthesis_available=self_application(
                :understorey_photosynthesis,
                :understorey_photosynthesis_available,
            ),
            meteorology_reconstruction_available=scene_application(
                :meteorology,
                :meteorology_reconstruction_available,
            ),
        )
    end

    applications = (
        structure_application,
        radiation_applications...,
        PlantSimEngine.ModelSpec(
            absorption_model;
            name=:understorey_shortwave_absorption,
            on=PlantSimEngine.Many(
                scale=:UnderstoreyPatch,
                kind=:understorey_patch,
                id=patch_names,
            ),
            inputs=(
                understorey_direct_par_w_m2=self_application(
                    :understorey_radiation,
                    :understorey_direct_par_w_m2,
                ),
                understorey_diffuse_par_w_m2=self_application(
                    :understorey_radiation,
                    :understorey_diffuse_par_w_m2,
                ),
                understorey_leaf_area_index=self_application(
                    :understorey_structure_trajectory,
                    :understorey_leaf_area_index,
                ),
                astronomical_daylight=scene_application(
                    :solar_geometry,
                    :astronomical_daylight,
                ),
                understorey_structure_available=self_application(
                    :understorey_structure_trajectory,
                    :understorey_structure_available,
                ),
                understorey_radiation_available=self_application(
                    :understorey_radiation,
                    :understorey_radiation_available,
                ),
            ),
        ),
        parameter_applications...,
        PlantSimEngine.ModelSpec(
            photosynthesis_model;
            name=:understorey_photosynthesis,
            on=PlantSimEngine.Many(
                scale=:UnderstoreyPatch,
                kind=:understorey_patch,
                id=patch_names,
            ),
            inputs=photosynthesis_inputs,
        ),
        PlantSimEngine.ModelSpec(
            conductance_model;
            name=:understorey_stomatal_conductance,
            on=PlantSimEngine.Many(
                scale=:UnderstoreyPatch,
                kind=:understorey_patch,
                id=patch_names,
            ),
            inputs=conductance_inputs,
        ),
        PlantSimEngine.ModelSpec(
            respiration_model;
            name=:understorey_respiration_accounting,
            on=PlantSimEngine.Many(
                scale=:UnderstoreyPatch,
                kind=:understorey_patch,
                id=patch_names,
            ),
            inputs=(
                understorey_gross_assimilation_umol_co2_m2_ground_s=
                    self_application(
                        :understorey_photosynthesis,
                        :understorey_gross_assimilation_umol_co2_m2_ground_s,
                    ),
                understorey_exchange_active=self_application(
                    :understorey_photosynthesis,
                    :understorey_exchange_active,
                ),
                understorey_photosynthesis_available=self_application(
                    :understorey_photosynthesis,
                    :understorey_photosynthesis_available,
                ),
            ),
        ),
        PlantSimEngine.ModelSpec(
            transpiration_model;
            name=:understorey_transpiration,
            on=PlantSimEngine.Many(
                scale=:UnderstoreyPatch,
                kind=:understorey_patch,
                id=patch_names,
            ),
            inputs=(
                understorey_stomatal_conductance_h2o_mol_m2_ground_s=
                    self_application(
                        :understorey_stomatal_conductance,
                        :understorey_stomatal_conductance_h2o_mol_m2_ground_s,
                    ),
                vapour_pressure_deficit_pa=scene_application(
                    :meteorology,
                    :vapour_pressure_deficit_pa,
                ),
                air_pressure_pa=scene_application(
                    :meteorology,
                    :air_pressure_pa,
                ),
                understorey_exchange_active=self_application(
                    :understorey_photosynthesis,
                    :understorey_exchange_active,
                ),
                understorey_stomatal_conductance_available=self_application(
                    :understorey_stomatal_conductance,
                    :understorey_stomatal_conductance_available,
                ),
                meteorology_reconstruction_available=scene_application(
                    :meteorology,
                    :meteorology_reconstruction_available,
                ),
            ),
        ),
        PlantSimEngine.ModelSpec(
            radiation_aggregation_model;
            name=:understorey_radiation_aggregation,
            on=PlantSimEngine.One(
                scale=:Understorey,
                kind=:understorey,
                id=:understorey,
            ),
            inputs=(
                understorey_incident_par_w_m2=patch_application(
                    :understorey_shortwave_absorption,
                    :understorey_incident_par_w_m2,
                ),
                understorey_absorbed_par_w_m2=patch_application(
                    :understorey_shortwave_absorption,
                    :understorey_absorbed_par_w_m2,
                ),
                understorey_transmitted_par_w_m2=patch_application(
                    :understorey_shortwave_absorption,
                    :understorey_transmitted_par_w_m2,
                ),
                understorey_shortwave_absorption_available=patch_application(
                    :understorey_shortwave_absorption,
                    :understorey_shortwave_absorption_available,
                ),
            ),
        ),
        PlantSimEngine.ModelSpec(
            aggregation_model;
            name=:understorey_flux_aggregation,
            on=PlantSimEngine.One(
                scale=:Understorey,
                kind=:understorey,
                id=:understorey,
            ),
            inputs=(
                understorey_gross_assimilation_umol_co2_m2_ground_s=
                    patch_application(
                        :understorey_photosynthesis,
                        :understorey_gross_assimilation_umol_co2_m2_ground_s,
                    ),
                understorey_net_assimilation_umol_co2_m2_ground_s=
                    patch_application(
                        :understorey_respiration_accounting,
                        :understorey_net_assimilation_umol_co2_m2_ground_s,
                    ),
                understorey_stomatal_conductance_co2_mol_m2_ground_s=
                    patch_application(
                        :understorey_stomatal_conductance,
                        :understorey_stomatal_conductance_co2_mol_m2_ground_s,
                    ),
                understorey_transpiration_mmol_h2o_m2_ground_s=
                    patch_application(
                        :understorey_transpiration,
                        :understorey_transpiration_mmol_h2o_m2_ground_s,
                    ),
                understorey_exchange_active=patch_application(
                    :understorey_photosynthesis,
                    :understorey_exchange_active,
                ),
                understorey_photosynthesis_available=patch_application(
                    :understorey_photosynthesis,
                    :understorey_photosynthesis_available,
                ),
                understorey_stomatal_conductance_available=patch_application(
                    :understorey_stomatal_conductance,
                    :understorey_stomatal_conductance_available,
                ),
                understorey_respiration_accounting_available=patch_application(
                    :understorey_respiration_accounting,
                    :understorey_respiration_accounting_available,
                ),
                understorey_transpiration_available=patch_application(
                    :understorey_transpiration,
                    :understorey_transpiration_available,
                ),
            ),
        ),
    )
    return (
        objects=(parent, patch_objects...),
        applications=applications,
    )
end

