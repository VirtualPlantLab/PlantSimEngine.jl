"""
    MAESPACanopyEnvironment(forcing; canopy=nothing)

PlantSimEngine environment backend with two explicit views:

- `provider=:forcing` samples the immutable above-canopy forcing;
- `provider=:canopy` samples the accepted or transient
  [`MAESPACanopyAtmosphere`](@ref);
- `sink=:canopy` authorizes the root `ITERTCAN` controller to commit one
  accepted state or an explicit unavailable state for the current step.

The `canopy` field deliberately accepts every numeric specialization of
`MAESPACanopyAtmosphere`. PlantSimEngine promotes statuses, not environment
objects, so an accepted trial constructed from the effective status type must
be allowed to replace an atmosphere constructed with another floating type.
"""
mutable struct MAESPACanopyEnvironment{F,B} <:
               PlantSimEngine.EnvironmentAPI.AbstractEnvironmentBackend
    forcing::F
    forcing_backend::B
    canopy::Union{Nothing,MAESPACanopyAtmosphere}
end

struct MAESPACanopyEnvironmentHandle{H}
    provider::Symbol
    sink::Union{Nothing,Symbol}
    forcing_handle::H
end

function MAESPACanopyEnvironment(forcing; canopy=nothing)
    forcing_backend =
        PlantSimEngine.EnvironmentAPI.environment_backend(forcing)
    isnothing(canopy) || begin
        canopy isa MAESPACanopyAtmosphere || throw(
            ArgumentError("canopy must be a MAESPACanopyAtmosphere or nothing"),
        )
        _validate_canopy_atmosphere(canopy)
        _validate_canopy_atmosphere_timestep(forcing_backend, canopy)
    end
    return MAESPACanopyEnvironment{typeof(forcing),typeof(forcing_backend)}(
        forcing,
        forcing_backend,
        canopy,
    )
end

function _validate_canopy_atmosphere_timestep(
    forcing_backend,
    state::MAESPACanopyAtmosphere{T},
) where {T}
    forcing_seconds = PlantSimEngine.EnvironmentAPI.base_step_seconds(
        forcing_backend,
    )
    forcing_seconds isa Real && !(forcing_seconds isa Bool) || throw(
        ArgumentError(
            "the forcing backend base step must be a real number, not Bool",
        ),
    )
    expected = convert(T, forcing_seconds)
    isfinite(expected) && expected > zero(T) || throw(
        DomainError(
            expected,
            "the forcing backend base step must be finite and positive",
        ),
    )
    actual = _maespa_timestep_seconds(T, (duration=state.duration,))
    tolerance = T(8) * eps(T)
    isapprox(actual, expected; rtol=tolerance, atol=zero(T)) || throw(
        DimensionMismatch(
            "canopy-atmosphere duration represents $actual seconds but " *
            "the forcing base step represents $expected seconds",
        ),
    )
    return nothing
end

function PlantSimEngine.EnvironmentAPI.base_step_seconds(
    backend::MAESPACanopyEnvironment,
)
    return PlantSimEngine.EnvironmentAPI.base_step_seconds(
        backend.forcing_backend,
    )
end

function PlantSimEngine.EnvironmentAPI.get_nsteps(
    backend::MAESPACanopyEnvironment,
)
    return PlantSimEngine.EnvironmentAPI.get_nsteps(backend.forcing_backend)
end

function PlantSimEngine.EnvironmentAPI.environment_variables(
    backend::MAESPACanopyEnvironment,
)
    forcing_variables = PlantSimEngine.EnvironmentAPI.environment_variables(
        backend.forcing_backend,
    )
    isnothing(forcing_variables) && return nothing
    variables = Set{Symbol}(forcing_variables)
    union!(variables, _MAESPA_CANOPY_ATMOSPHERE_ENVIRONMENT_FIELDS)
    union!(variables, _MAESPA_CANOPY_AIR_TRIAL_ENVIRONMENT_FIELDS)
    union!(variables, _MAESPA_CANOPY_THERMAL_SNAPSHOT_ENVIRONMENT_FIELDS)
    return variables
end

function _sample_canopy_air_trial_metadata(
    state::MAESPACanopyAirTrialEnvironment,
    variable::Symbol,
)
    variable === :canopy_air_iteration_index &&
        return state.iteration_index
    variable === :canopy_air_maximum_iterations &&
        return state.maximum_iterations
    variable === :canopy_air_iteration_enabled &&
        return _canopy_air_trial_iteration_enabled(state)
    variable === :canopy_air_first_evaluation &&
        return _canopy_air_trial_first_evaluation(state)
    variable === :canopy_air_last_allowed_evaluation &&
        return _canopy_air_trial_last_allowed_evaluation(state)
    throw(
        ArgumentError(
            "MAESPACanopyAirTrialEnvironment does not provide " *
            "$(repr(variable))",
        ),
    )
end

function _maespa_canopy_environment_provider(config)
    isnothing(config) && return :forcing
    return Symbol(get(config, :provider, :forcing))
end

function _maespa_canopy_environment_sink(config)
    isnothing(config) && return nothing
    value = get(config, :sink, nothing)
    return isnothing(value) ? nothing : Symbol(value)
end

function PlantSimEngine.EnvironmentAPI.bind_environment(
    backend::MAESPACanopyEnvironment,
    object::PlantSimEngine.Object,
    context::PlantSimEngine.EnvironmentAPI.EnvironmentContext,
    config,
)
    provider = _maespa_canopy_environment_provider(config)
    sink = _maespa_canopy_environment_sink(config)
    provider in (:forcing, :canopy) || throw(
        ArgumentError(
            "MAESPA canopy environment provider must be :forcing or " *
            ":canopy, got $(repr(provider))",
        ),
    )
    isnothing(sink) || sink === :canopy || throw(
        ArgumentError(
            "MAESPA canopy environment sink must be :canopy, got " *
            "$(repr(sink))",
        ),
    )
    forcing_handle = PlantSimEngine.EnvironmentAPI.bind_environment(
        backend.forcing_backend,
        object,
        context,
        nothing,
    )
    return MAESPACanopyEnvironmentHandle(provider, sink, forcing_handle)
end

@noinline function _missing_committed_canopy_atmosphere(variable::Symbol)
    throw(
        ArgumentError(
            "no accepted canopy atmosphere is available while sampling " *
            "$(repr(variable)); initialize it or pass a transient state " *
            "through run_call!(...; environment=trial_state)",
        ),
    )
end

@inline function _sample_canopy_atmosphere(
    state::MAESPACanopyAtmosphere,
    variable::Symbol,
)
    hasproperty(state, variable) || throw(
        ArgumentError(
            "MAESPACanopyAtmosphere does not provide $(repr(variable))",
        ),
    )
    return getproperty(state, variable)
end

function PlantSimEngine.EnvironmentAPI.sample(
    backend::MAESPACanopyEnvironment,
    handle::MAESPACanopyEnvironmentHandle,
    variable::Symbol,
    time,
)
    if handle.provider === :forcing
        return PlantSimEngine.EnvironmentAPI.sample(
            backend.forcing_backend,
            handle.forcing_handle,
            variable,
            time,
        )
    end
    state = backend.canopy
    isnothing(state) && _missing_committed_canopy_atmosphere(variable)
    return _sample_canopy_atmosphere(state, variable)
end

function PlantSimEngine.EnvironmentAPI.sample(
    backend::MAESPACanopyEnvironment,
    handle::MAESPACanopyEnvironmentHandle,
    state::MAESPACanopyAirTrialEnvironment,
    variable::Symbol,
    time,
)
    if variable in _MAESPA_CANOPY_THERMAL_SNAPSHOT_ENVIRONMENT_FIELDS
        _validate_canopy_thermal_snapshot(state.thermal_snapshot)
        return state.thermal_snapshot
    end
    if variable in _MAESPA_CANOPY_AIR_TRIAL_ENVIRONMENT_FIELDS
        return _sample_canopy_air_trial_metadata(state, variable)
    end
    if handle.provider === :forcing
        return PlantSimEngine.EnvironmentAPI.sample(
            backend.forcing_backend,
            handle.forcing_handle,
            variable,
            time,
        )
    end
    _validate_canopy_atmosphere(state.atmosphere)
    _validate_canopy_atmosphere_timestep(
        backend.forcing_backend,
        state.atmosphere,
    )
    return _sample_canopy_atmosphere(state.atmosphere, variable)
end

function PlantSimEngine.EnvironmentAPI.sample(
    backend::MAESPACanopyEnvironment,
    handle::MAESPACanopyEnvironmentHandle,
    state::MAESPACanopyAtmosphere,
    variable::Symbol,
    time,
)
    if handle.provider === :forcing
        return PlantSimEngine.EnvironmentAPI.sample(
            backend.forcing_backend,
            handle.forcing_handle,
            variable,
            time,
        )
    end
    _validate_canopy_atmosphere(state)
    _validate_canopy_atmosphere_timestep(backend.forcing_backend, state)
    return _sample_canopy_atmosphere(state, variable)
end

function PlantSimEngine.EnvironmentAPI.commit_environment!(
    backend::MAESPACanopyEnvironment,
    handle::MAESPACanopyEnvironmentHandle,
    state::MAESPACanopyAtmosphere,
    time,
)
    handle.sink === :canopy || throw(
        ArgumentError(
            "MAESPA canopy environment handle for provider " *
            "$(repr(handle.provider)) has no :canopy commit sink",
        ),
    )
    _validate_canopy_atmosphere(state)
    _validate_canopy_atmosphere_timestep(backend.forcing_backend, state)
    backend.canopy = state
    return nothing
end
