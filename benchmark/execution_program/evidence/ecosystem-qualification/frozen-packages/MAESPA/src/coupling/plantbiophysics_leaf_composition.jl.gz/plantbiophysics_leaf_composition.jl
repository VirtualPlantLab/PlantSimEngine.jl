"""
    plantbiophysics_leaf_composition(fvcb, medlyn; leaf_deficit)
    plantbiophysics_leaf_composition(fvcb, tuzet)

Build an optional, fixed-parameter PlantBiophysics `Fvcb`/stomatal composition
for the `leaf_composition` keyword of [`build_leaf_exchange`](@ref) or
[`build_model`](@ref). Load PlantBiophysics to activate this extension.

For `Medlyn`, the deficit policy is required: `:leaf_to_air` uses saturation vapour pressure
at the current leaf temperature minus ambient vapour pressure, in kPa;
`:ambient_vpd` explicitly approximates it with ambient VPD (Pa divided by
1000). Absorbed leaf PAR is already a photon flux per represented leaf surface:
no energy conversion, LAI division or stomatal-sides factor is applied.

The returned immutable factory mounts the unchanged MAESPA energy root, a
declared interface adapter, and separately declared PlantBiophysics Fvcb and
stomatal applications. Their shared `A`, `Gₛ` and `Cᵢ` status fields remain
canonical. The adapter's H₂O conductance diagnostic uses the receiving
controller's *stomatal-model* water-to-CO₂ ratio; the native energy model
retains its separate boundary-layer parameters unchanged. Daytime respiration
uses the selected Fvcb parameters and its public Arrhenius function.

The `Tuzet` overload requires a native Crown Tuzet hydraulic controller and
exact equality of prescribed PB/native `sf` and `Ψᵥ`, without a tolerance or
automatic parameter conversion. It passes the actual native candidate water
potential to PB `Ψₗ` in MPa; PB computes its hydraulic factor once. It takes no
`leaf_deficit` keyword. `Γ` and surface CO₂ use µmol/mol; conductance uses
mol CO₂ per leaf area per second. Rebuild the factory when replacing its
prescribed stomatal model. The optional test project contains separate PB
reference and coupled-scene tests; those fixtures are not site calibration.

This is an experimental hybrid, not historical parity or pure PB Monteith:
MAESPA retains its energy, night respiration and wet-surface equations. Active
non-Tuzet Emax and the second stomatal curve are unsupported. User-supplied
PB parameters remain fixed: MAESPA dated capacity/aging, NFOL and VFUN controls
are not translated into them. A native mount does not claim those alternatives
are implemented. Status promotion does not convert PB model parameters or
guarantee that all PB arithmetic uses the status type. Record the loaded PB
source provenance when qualifying a result; a version number is insufficient.
"""
function plantbiophysics_leaf_composition(fvcb, medlyn; leaf_deficit)
    throw(ArgumentError("load PlantBiophysics and supply its Fvcb and Medlyn models to plantbiophysics_leaf_composition"))
end
