# Canopy-air trial applications and target selection.

function _soil_radiation_target_selection(targets)
    target_weights = Dict{Int,Int}()
    for target in targets
        target_weights[target] = get(target_weights, target, 0) + 1
    end
    target_ids = sort!(
        collect(keys(target_weights));
        by=_radiation_crown_name,
    )
    names = Tuple(_radiation_crown_name.(target_ids))
    weights = Tuple(target_weights[target] for target in target_ids)
    return names, weights
end

function _soil_radiation_target_ids(targets)
    target_weights = Dict{Int,Int}()
    for target in targets
        tree_id = Int(target)
        target_weights[tree_id] = get(target_weights, tree_id, 0) + 1
    end
    target_ids = sort!(collect(keys(target_weights)); by=_radiation_crown_name)
    weights = Tuple(target_weights[target] for target in target_ids)
    return Tuple(target_ids), weights
end

function _canopy_air_trial_modelspecs(
    ::Type{T},
    config::SimulationConfig,
    soil::SoilConfig,
    targets,
    ;
    mount_understorey_shortwave_reconciliation::Bool=false,
    mount_understorey_water_aggregation::Bool=false,
) where {T<:AbstractFloat}
    target_ids, target_weights = _soil_radiation_target_ids(targets)
    isempty(target_ids) && throw(
        ArgumentError("canopy-air iteration requires at least one target"),
    )
    crown_names = Tuple(_radiation_crown_name.(target_ids))
    root_names = Tuple(_root_system_object_name.(target_ids))
    point_count = config.canopy_layers * config.points_per_layer
    simulate_soil_temperature =
        soil.options.simulate_soil_temperature == 1
    surface_energy_application = simulate_soil_temperature ?
                                 :simulated_soil_surface_energy :
                                 :prescribed_soil_surface_energy
    leaf_exchange_process = config.stomatal_model == 6 ?
                            :tuzet_crown_leaf_exchange_controller :
                            :non_tuzet_crown_leaf_exchange_controller

    scene_application(application, variable) = PlantSimEngine.One(
        scale=:Scene,
        kind=:scene,
        within=PlantSimEngine.Self(),
        application=application,
        var=variable,
    )
    crown_process(process, variable) = PlantSimEngine.Many(
        scale=:Crown,
        kind=:crown,
        id=crown_names,
        within=PlantSimEngine.SceneScope(),
        process=process,
        var=variable,
    )
    crown_status(variable) = PlantSimEngine.Many(
        scale=:Crown,
        kind=:crown,
        id=crown_names,
        within=PlantSimEngine.SceneScope(),
        var=variable,
        from_status=true,
    )
    root_process(process, variable) = PlantSimEngine.Many(
        scale=:RootSystem,
        kind=:root_system,
        id=root_names,
        within=PlantSimEngine.SceneScope(),
        process=process,
        var=variable,
    )
    root_status(variable) = PlantSimEngine.Many(
        scale=:RootSystem,
        kind=:root_system,
        id=root_names,
        within=PlantSimEngine.SceneScope(),
        var=variable,
        from_status=true,
    )
    soil_application(application, variable) = PlantSimEngine.One(
        scale=:Soil,
        kind=:soil,
        within=PlantSimEngine.SceneScope(),
        application=application,
        var=variable,
    )
    understorey_application(application, variable) = PlantSimEngine.One(
        scale=:Understorey,
        kind=:understorey,
        within=PlantSimEngine.SceneScope(),
        application=application,
        var=variable,
    )
    soil_status(variable) = PlantSimEngine.One(
        scale=:Soil,
        kind=:soil,
        within=PlantSimEngine.SceneScope(),
        var=variable,
        from_status=true,
    )
    first_layer_status(variable) = PlantSimEngine.One(
        scale=:SoilLayer,
        kind=:soil_layer,
        id=:soil_layer_1,
        within=PlantSimEngine.SceneScope(),
        var=variable,
        from_status=true,
    )
    first_layer_status_after(variable, application) = PlantSimEngine.One(
        scale=:SoilLayer,
        kind=:soil_layer,
        id=:soil_layer_1,
        within=PlantSimEngine.SceneScope(),
        var=variable,
        from_status=true,
        after=application,
    )

    prescribed_temperature_model =
        MAESPAPrescribedSoilSurfaceTemperature(T)
    prescribed_temperature_specs = if simulate_soil_temperature
        ()
    else
        (
            PlantSimEngine.ModelSpec(
                prescribed_temperature_model;
                name=:prescribed_soil_surface_temperature,
                on=PlantSimEngine.One(scale=:Scene, kind=:scene),
                inputs=(
                    source_soil_temperature_c=scene_application(
                        :meteorology,
                        :soil_temperature_c,
                    ),
                    source_meteorology_available=scene_application(
                        :meteorology,
                        :meteorology_reconstruction_available,
                    ),
                ),
            ),
        )
    end
    soil_temperature_input = simulate_soil_temperature ?
                             soil_status(
        :soil_surface_temperature_state_k,
    ) : scene_application(
        :prescribed_soil_surface_temperature,
        :prescribed_soil_surface_temperature_k,
    )
    soil_temperature_available_input = simulate_soil_temperature ?
                                       soil_status(
        :soil_surface_temperature_state_available,
    ) : scene_application(
        :prescribed_soil_surface_temperature,
        :prescribed_soil_surface_temperature_available,
    )

    readiness_model = MAESPACanopyAirTrialReadiness(
        target_tree_ids=target_ids,
        require_understorey_shortwave=
            mount_understorey_shortwave_reconciliation,
        require_understorey_water=mount_understorey_water_aggregation,
    )
    understorey_shortwave_readiness_inputs =
        mount_understorey_shortwave_reconciliation ?
        (
            understorey_radiation_aggregation_available=
                understorey_application(
                    :understorey_radiation_aggregation,
                    :understorey_radiation_aggregation_available,
                ),
        ) : NamedTuple()
    understorey_water_readiness_inputs =
        mount_understorey_water_aggregation ?
        (
            understorey_flux_aggregation_available=understorey_application(
                :understorey_flux_aggregation,
                :understorey_flux_aggregation_available,
            ),
        ) : NamedTuple()
    readiness_spec = PlantSimEngine.ModelSpec(
        readiness_model;
        name=:canopy_air_trial_readiness,
        on=PlantSimEngine.One(scale=:Scene, kind=:scene),
        inputs=(
            meteorology_reconstruction_available=scene_application(
                :meteorology,
                :meteorology_reconstruction_available,
            ),
            stand_leaf_area_statistics_available=scene_application(
                :stand_leaf_area_statistics,
                :stand_leaf_area_statistics_available,
            ),
            pstransp_canopy_surface_water_forcing_available=
                scene_application(
                    :canopy_surface_water_forcing,
                    :pstransp_canopy_surface_water_forcing_available,
                ),
            soil_surface_temperature_available=
                soil_temperature_available_input,
            target_tree_ids=crown_status(:tree_id),
            equivalent_canopy_available=crown_process(
                :crown_radiation,
                :equivalent_canopy_available,
            ),
            leaf_radiation_partitioning_available=crown_process(
                :crown_radiation,
                :leaf_radiation_partitioning_available,
            ),
            leaf_exchange_daylight=crown_process(
                :leaf_exchange_daylight,
                :leaf_exchange_daylight,
            ),
            leaf_exchange_daylight_available=crown_process(
                :leaf_exchange_daylight,
                :leaf_exchange_daylight_available,
            ),
            canopy_wind_profile_available=crown_process(
                :canopy_wind_profile,
                :canopy_wind_profile_available,
            ),
            root_system_tree_ids=root_status(:tree_id),
            soil_to_leaf_hydraulic_supply_available=root_process(
                :soil_to_leaf_hydraulic_supply,
                :soil_to_leaf_hydraulic_supply_available,
            ),
            soil_surface_aerodynamics_available=soil_application(
                :soil_surface_aerodynamics,
                :soil_surface_aerodynamics_available,
            ),
            soil_thermal_properties_available=first_layer_status_after(
                :soil_thermal_properties_available,
                :soil_thermal_properties,
            ),
            soil_hydraulic_properties_available=first_layer_status(
                :soil_hydraulic_properties_available,
            ),
            configured_initial_deep_soil_node_temperature_available=
                soil_status(
                    :configured_initial_deep_soil_node_temperature_available,
                ),
            configured_soil_dry_layer_state_seed_available=soil_status(
                :configured_soil_dry_layer_state_seed_available,
            ),
            understorey_shortwave_readiness_inputs...,
            understorey_water_readiness_inputs...,
        ),
    )


    collector_model = MAESPACanopyThermalSnapshotCollection(
        T;
        target_tree_ids=target_ids,
        target_multiplicities=target_weights,
        point_count,
    )
    collector_spec = PlantSimEngine.ModelSpec(
        collector_model;
        name=:canopy_thermal_snapshot_collection,
        on=PlantSimEngine.One(scale=:Scene, kind=:scene),
        inputs=(
            target_tree_ids=crown_status(:tree_id),
            point_leaf_temperature_c_by_target=crown_process(
                :crown_leaf_thermal_snapshot,
                :point_leaf_temperature_c,
            ),
            mean_leaf_temperature_crown_c_by_target=crown_process(
                :crown_leaf_thermal_snapshot,
                :thermal_snapshot_mean_leaf_temperature_crown_c,
            ),
            crown_leaf_thermal_snapshot_available=crown_process(
                :crown_leaf_thermal_snapshot,
                :crown_leaf_thermal_snapshot_available,
            ),
        ),
        output_routing=_stream_only_outputs(collector_model),
    )

    microclimate_model = MAESPACanopyAirMicroclimate(T)
    microclimate_spec = PlantSimEngine.ModelSpec(
        microclimate_model;
        name=:canopy_air_microclimate,
        on=PlantSimEngine.One(scale=:Scene, kind=:scene),
        inputs=(
            above_canopy_air_temperature_c=scene_application(
                :meteorology,
                :air_temperature_c,
            ),
            above_canopy_vapour_pressure_deficit_pa=scene_application(
                :meteorology,
                :vapour_pressure_deficit_pa,
            ),
            atmospheric_pressure_pa=scene_application(
                :meteorology,
                :air_pressure_pa,
            ),
            canopy_atmosphere_aerodynamic_conductance_m_s=
                soil_application(
                    :soil_surface_aerodynamics,
                    :canopy_atmosphere_aerodynamic_conductance_m_s,
                ),
            soil_net_radiation_w_m2=soil_application(
                surface_energy_application,
                :soil_net_radiation_w_m2,
            ),
            soil_latent_heat_flux_w_m2=soil_application(
                surface_energy_application,
                :soil_latent_heat_flux_w_m2,
            ),
            soil_conductive_heat_flux_w_m2=soil_application(
                surface_energy_application,
                :soil_heat_flux_w_m2,
            ),
            canopy_net_radiation_w_m2=scene_application(
                :stand_radiation_scaling,
                :canopy_net_radiation_w_m2,
            ),
            vegetation_evapotranspiration_mm_timestep=scene_application(
                mount_understorey_water_aggregation ?
                :vegetation_water_flux_aggregation :
                :stand_water_flux_scaling,
                mount_understorey_water_aggregation ?
                :vegetation_evapotranspiration_mm_timestep :
                :canopy_transpiration_mm_timestep,
            ),
            wet_canopy_evaporation_mm_timestep=scene_application(
                :stand_water_flux_scaling,
                :wet_canopy_evaporation_mm_timestep,
            ),
            canopy_air_microclimate_inputs_available=soil_application(
                surface_energy_application,
                :soil_surface_energy_available,
            ),
        ),
        environment=PlantSimEngine.Environment(provider=:canopy),
        output_routing=_stream_only_outputs(microclimate_model),
    )

    crown_call(process) = PlantSimEngine.Many(
        scale=:Crown,
        kind=:crown,
        id=crown_names,
        within=PlantSimEngine.SceneScope(),
        process=process,
    )
    scene_call(application) = PlantSimEngine.One(
        scale=:Scene,
        kind=:scene,
        within=PlantSimEngine.Self(),
        application=application,
    )
    soil_call(application) = PlantSimEngine.One(
        scale=:Soil,
        kind=:soil,
        within=PlantSimEngine.SceneScope(),
        application=application,
    )
    evaluator_model = MAESPACanopyAirTrialEvaluation(
        T;
        target_count=length(target_ids),
        point_count,
        leaf_exchange_process,
        reconcile_understorey_shortwave=
            mount_understorey_shortwave_reconciliation,
        aggregate_understorey_water=mount_understorey_water_aggregation,
    )
    understorey_reconciliation_call =
        mount_understorey_shortwave_reconciliation ?
        (
            soil_shortwave_reconciliation=soil_call(
                :understorey_shortwave_reconciliation,
            ),
        ) : NamedTuple()
    understorey_water_call = mount_understorey_water_aggregation ?
                            (
        vegetation_water=scene_call(:vegetation_water_flux_aggregation),
    ) : NamedTuple()
    evaluator_spec = PlantSimEngine.ModelSpec(
        evaluator_model;
        name=:canopy_air_trial_evaluation,
        on=PlantSimEngine.One(scale=:Scene, kind=:scene),
        calls=(
            trial_longwave_forcing=crown_call(
                :canopy_air_trial_longwave_forcing,
            ),
            longwave_exchange=crown_call(:longwave_canopy_exchange),
            leaf_radiative_forcing=crown_call(:leaf_radiative_forcing),
            leaf_thermodynamic_forcing=crown_call(
                :leaf_thermodynamic_forcing,
            ),
            logical_leaf_layout=crown_call(:logical_leaf_unit_layout),
            leaf_exchange=crown_call(leaf_exchange_process),
            crown_leaf_thermal_snapshot=crown_call(
                :crown_leaf_thermal_snapshot,
            ),
            crown_leaf_respiration_accounting=crown_call(
                :crown_leaf_respiration_accounting,
            ),
            crown_leaf_exchange_aggregation=crown_call(
                :crown_leaf_exchange_aggregation,
            ),
            crown_radiation_aggregation=crown_call(
                :crown_radiation_aggregation,
            ),
            stand_radiation=scene_call(:stand_radiation_scaling),
            stand_water=scene_call(:stand_water_flux_scaling),
            understorey_water_call...,
            soil_shortwave=soil_call(:soil_shortwave_radiation),
            understorey_reconciliation_call...,
            soil_longwave=soil_call(:soil_longwave_radiation),
            soil_energy_forcing=soil_call(:soil_surface_energy_forcing),
            soil_energy=soil_call(surface_energy_application),
            thermal_collection=scene_call(
                :canopy_thermal_snapshot_collection,
            ),
            microclimate=scene_call(:canopy_air_microclimate),
        ),
        environment=PlantSimEngine.Environment(provider=:canopy),
        output_routing=_stream_only_outputs(evaluator_model),
    )

    controller_model = MAESPACanopyAirIterationController(
        T;
        maximum_iterations=config.canopy_air_iterations,
        iterate_soil_surface_temperature=simulate_soil_temperature,
        accept_iteration_limit=true,
    )
    controller_spec = PlantSimEngine.ModelSpec(
        controller_model;
        name=:canopy_air_iteration_controller,
        on=PlantSimEngine.One(scale=:Scene, kind=:scene),
        inputs=(
            above_canopy_air_temperature_c=scene_application(
                :meteorology,
                :air_temperature_c,
            ),
            above_canopy_moving_average_air_temperature_c=
                scene_application(
                    :meteorology,
                    :moving_average_air_temperature_c,
                ),
            above_canopy_wind_speed_m_s=scene_application(
                :meteorology,
                :wind_speed_m_s,
            ),
            above_canopy_relative_humidity=scene_application(
                :meteorology,
                :relative_humidity,
            ),
            above_canopy_vapour_pressure_deficit_pa=scene_application(
                :meteorology,
                :vapour_pressure_deficit_pa,
            ),
            above_canopy_mole_fraction_deficit_mmol_mol=
                scene_application(
                    :meteorology,
                    :mole_fraction_deficit_mmol_mol,
                ),
            above_canopy_co2_umol_mol=scene_application(
                :meteorology,
                :co2_umol_mol,
            ),
            above_canopy_air_pressure_pa=scene_application(
                :meteorology,
                :air_pressure_pa,
            ),
            initial_soil_surface_temperature_k=soil_temperature_input,
            soil_surface_temperature_available=
                soil_temperature_available_input,
            canopy_air_iteration_inputs_available=scene_application(
                :canopy_air_trial_readiness,
                :canopy_air_trial_ready,
            ),
        ),
        calls=(
            trial_evaluation=scene_call(:canopy_air_trial_evaluation),
        ),
        environment=PlantSimEngine.Environment(
            provider=:forcing,
            sink=:canopy,
        ),
    )

    return (
        prescribed_temperature_specs...,
        readiness_spec,
        collector_spec,
        microclimate_spec,
        evaluator_spec,
        controller_spec,
    )
end

_soil_shortwave_target_selection(targets) =
    _soil_radiation_target_selection(targets)

_soil_shortwave_radiation_can_mount(soil, meteorology, species_set, targets) =
    !isnothing(soil) &&
    !isnothing(meteorology) &&
    !isnothing(species_set) &&
    !isempty(targets)

# No leaf/canopy feedback: expose the reconstructed meteorology as prescribed
# air once per step, rather than copying it into every consuming object.
function _prescribed_canopy_atmosphere_modelspec(::Type{T}) where {T}
    model = MAESPAPrescribedCanopyAtmosphere{T}()
    inputs = NamedTuple{keys(PlantSimEngine.inputs_(model))}(map(
        name -> PlantSimEngine.One(within=PlantSimEngine.Self(),
            application=:meteorology, var=name),
        keys(PlantSimEngine.inputs_(model))))
    return PlantSimEngine.ModelSpec(model; name=:prescribed_canopy_atmosphere,
        on=PlantSimEngine.One(scale=:Scene), inputs,
        environment=PlantSimEngine.Environment(provider=:forcing, sink=:canopy))
end
