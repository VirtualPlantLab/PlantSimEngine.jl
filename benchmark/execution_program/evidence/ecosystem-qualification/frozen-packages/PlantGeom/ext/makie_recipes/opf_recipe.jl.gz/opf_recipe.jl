# Implementing our own plot recipe for PlantViz (plantviz and plantviz!):
Makie.@recipe PlantViz (mtg,) begin
    color = nothing
    "How to interpret attribute arrays: `:auto`, `:node`, or `:vertex`."
    color_mode = :auto
    colormap = nothing
    colorrange = nothing
    colorscale = identity
    alpha = 1.0
    highclip = Makie.automatic
    lowclip = Makie.automatic
    nan_color = :transparent
    "An integer giving the index of the attribute value to be vizualised. This is useful when the attribute is a vector of values for *e.g.* each timestep."
    index = nothing
    "The name of the color cache. Should be a string (default to a random string)."
    color_cache_name = nothing
    "The color to be used for missing values. Should be a colorant or a symbol of color."
    color_missing = RGBA(0, 0, 0, 0.3)
    "Filter the MTG nodes to be plotted by symbol"
    symbol = nothing
    "Filter the MTG nodes to be plotted using a function that takes a node as argument and returns a boolean"
    filter_fun = nothing
    "Filter the MTG nodes to be plotted by scale"
    scale = nothing
    "Filter the MTG nodes to be plotted by link"
    link = nothing
    visible = true
    "Cache the meshes computations for speeding-up plotting with only changes in coloring."
    cache = true
    "Draw the OPS `scene_dimensions` as a pure outline overlay."
    show_scene_boundary = false
end

Makie.args_preferred_axis(mtg::MultiScaleTreeGraph.Node) = Makie.LScene

function Makie.plot!(plot::PlantViz{<:Tuple{MultiScaleTreeGraph.Node}})
    show_scene_boundary = Makie.to_value(plot[:show_scene_boundary])
    plot_opf(
        plot,
        :mtg;
        cache=show_scene_boundary ? false : Makie.to_value(plot[:cache]),
    )
    if show_scene_boundary
        mesh = PlantGeom.scene_boundary_mesh(Makie.to_value(plot[:mtg]))
        points = Makie.Point3f.(GeometryBasics.coordinates(mesh))
        outline = copy(points)
        push!(outline, first(points))
        Makie.lines!(
            plot,
            outline;
            color=RGBA(159 / 255, 182 / 255, 205 / 255, 1),
            linewidth=2.0,
            visible=Makie.to_value(plot[:visible]),
        )
    end
    return plot
end

# To be able to call `Makie.Colorbar(fig[1,2], p)` directly.
function Makie.extract_colormap(plot::PlantViz{<:Tuple{MultiScaleTreeGraph.Node}})
    mtg_name = hasproperty(plot, :mtg) ? :mtg : :object
    attr_value = plot.colorant[].color

    attribute_values = _collect_plot_attribute_values(
        plot[mtg_name][],
        attr_value,
        plot.color_mode_resolved[],
        plot.index[],
    )

    return Makie.ColorMapping(
        attribute_values,
        Makie.ComputePipeline.get_observable!(plot.vertex_colors),
        Makie.ComputePipeline.get_observable!(plot.colormap_resolved),
        Makie.ComputePipeline.get_observable!(plot.colorrange_resolved),
        Makie.ComputePipeline.get_observable!(plot.colorscale),
        Makie.ComputePipeline.get_observable!(plot.alpha),
        Makie.ComputePipeline.get_observable!(plot.highclip),
        Makie.ComputePipeline.get_observable!(plot.lowclip),
        Makie.ComputePipeline.get_observable!(plot.nan_color),
    )
end

@inline _colorbar_value(x) = x
@inline _colorbar_value(x::Unitful.Quantity) = Unitful.ustrip(x)

function _collect_plot_attribute_values(mtg, attr_name::Symbol, index::Integer)
    error("`_collect_plot_attribute_values` now requires a color mode.")
end

function _collect_plot_attribute_values(mtg, attr_name::Symbol, color_mode, index)
    attribute_values = PlantGeom.attribute_color_values(mtg, attr_name; color_mode=color_mode, index=index)
    attribute_values = _colorbar_value.(attribute_values)
end
