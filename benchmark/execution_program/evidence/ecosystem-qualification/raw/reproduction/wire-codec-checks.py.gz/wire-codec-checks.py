"""Python-only lossless evidence codec checks; no scientific assertion credit.

Run in the original checkout, or pass --validator after restoring the archived
Python sources. Choose a new --output path for a repeat; results never overwrite.
"""

from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
from datetime import datetime, timezone


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    script = Path(__file__).resolve()
    root = script.parents[5]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validator", type=Path,
        default=root / "benchmark/execution_program/summarize_ecosystem_qualification.py")
    parser.add_argument("--output", type=Path, default=script.parent.parent / "wire-codec-checks.json")
    args = parser.parse_args()
    validator, output = args.validator.resolve(), args.output.resolve()
    if output.exists():
        raise FileExistsError("Refusing to overwrite an earlier wire-codec result")
    script_sha, validator_sha = sha(script), sha(validator)
    sys.path.insert(0, str(validator.parent))
    spec = importlib.util.spec_from_file_location("ecosystem_wire_validator", validator)
    codec = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(codec)
    results = []

    def passed(name):
        results.append(dict(name=name, passed=True))

    def rejects(name, value):
        try:
            codec.decode_lossless_wire(value)
        except ValueError:
            passed(name)
        else:
            raise AssertionError("Invalid lossless wire accepted: " + name)

    original = dict(s=0, o=[["s", 1]], a=[dict(r=0)], r=7,
        wire_format="marker-looking-original-value", strings=["µ", "same", "same"],
        references=[dict(r=0)], data=dict(s=1), unicode="Érable µ 🌿",
        numbers=[0, -3, 2**64-1, 1.25, -0.0], null=None, booleans=[True, False],
        empty_object={}, empty_array=[])
    strings, indices = [], {}

    def encode(value):
        if isinstance(value, str):
            if value not in indices:
                indices[value] = len(strings)
                strings.append(value)
            return dict(s=indices[value])
        if isinstance(value, dict):
            return dict(o=[[key, encode(child)] for key, child in value.items()])
        if isinstance(value, list):
            return dict(a=[encode(child) for child in value])
        return value

    encoded = encode(original)
    v1 = dict(wire_format=codec.WIRE_FORMAT, strings=strings, data=encoded)
    decoded = codec.decode_lossless_wire(v1)
    assert decoded == original
    assert json.dumps(decoded, ensure_ascii=False) == json.dumps(original, ensure_ascii=False)
    passed("v1_marker_keys_unicode_numbers_null_and_container_roundtrip")
    v2 = dict(wire_format=codec.WIRE_FORMAT_V2, strings=strings,
        references=[encoded, dict(a=[dict(r=0), 42])],
        data=dict(o=[["warmup", dict(r=0)], ["sample", dict(r=0)], ["prior", dict(r=1)]]))
    decoded = codec.decode_lossless_wire(v2)
    assert decoded == dict(warmup=original, sample=original, prior=[original, 42])
    assert decoded["warmup"] is decoded["sample"] is decoded["prior"][0]
    passed("v2_prior_reference_roundtrip_and_reused_snapshot_identity")
    wire_bytes = (json.dumps(v2, ensure_ascii=False) + "\n").encode()
    documents, metadata = codec.documents({"roundtrip.json": wire_bytes})
    assert documents["roundtrip.json"] == decoded
    assert metadata[0]["raw_sha256"] == hashlib.sha256(wire_bytes).hexdigest()
    assert metadata[0]["strings_count"] == len(strings) and metadata[0]["references_count"] == 2
    passed("document_reader_preserves_raw_hash_and_records_wire_table_counts")

    malformed_children = [dict(s=-1), dict(s=len(strings)), dict(s=True), dict(s=1.0),
        dict(o=[["duplicate", 0], ["duplicate", 1]]), dict(o=[[1, 0]]), dict(o={}),
        dict(a={}), dict(s=0, a=[]), dict(unknown=0), "untagged", [0], dict(r=0)]
    for index, child in enumerate(malformed_children):
        rejects(f"v1_invalid_marker_or_index_{index}",
            dict(wire_format=codec.WIRE_FORMAT, strings=strings, data=child))
    for index, (reference, data) in enumerate([
        (dict(r=0), None), (dict(a=[dict(r=0)]), None), (dict(r=1), None),
        (dict(r=True), None), (dict(r=-1), None), (dict(r=1.0), None),
        (0, dict(r=1)), (0, dict(r=True)), (0, dict(r=-1)), (0, dict(r=1.0))]):
        rejects(f"v2_self_forward_cycle_or_invalid_reference_{index}",
            dict(wire_format=codec.WIRE_FORMAT_V2, strings=[], references=[reference], data=data))
    for index, malformed in enumerate([
        dict(wire_format=codec.WIRE_FORMAT, strings=[None], data=None),
        dict(wire_format="unknown", strings=[], data=None),
        dict(wire_format=codec.WIRE_FORMAT, strings=[], data=None, extra=True),
        dict(wire_format=codec.WIRE_FORMAT_V2, strings=[], data=None),
        dict(wire_format=codec.WIRE_FORMAT_V2, strings=[], references={}, data=None)]):
        rejects(f"invalid_root_or_table_{index}", malformed)
    duplicate = b'{"wire_format":"pse_lossless_string_table_v1","strings":["a","b"],"data":{"s":0,"s":1}}'
    documents, metadata = codec.documents({"duplicate.json": duplicate})
    assert "_archive_parse_error" in documents["duplicate.json"] and not metadata
    passed("duplicate_transport_marker_keys_remain_invalid_raw_diagnostic")
    assert sha(script) == script_sha and sha(validator) == validator_sha
    report = dict(passed=True, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
        python=sys.version, script=dict(path=str(script), sha256=script_sha),
        validator=dict(path=str(validator), sha256=validator_sha), checks=results,
        checks_completed=len(results), scientific_assertion_count=0,
        scope="Python_evidence_codec_only_no_Julia_or_scientific_execution",
        raw_checksum_semantics="wire_bytes_unchanged_decoding_precedes_existing_scientific_validation")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x") as handle:
        json.dump(report, handle, indent=2, sort_keys=True, ensure_ascii=False)
        handle.write("\n")
    print(json.dumps(dict(passed=True, checks=len(results), output=str(output),
        validator_sha256=validator_sha, script_sha256=script_sha), sort_keys=True))


if __name__ == "__main__":
    main()
