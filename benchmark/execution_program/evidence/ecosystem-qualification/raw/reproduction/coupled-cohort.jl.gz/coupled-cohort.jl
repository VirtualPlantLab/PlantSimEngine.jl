task_local_storage(:pse_coupled_qualification_type_names,IdDict{Any,String}()) do
let spec=DownstreamQualification.register_case(:coupled_cohort,CoupledQualification;config=CoupledQualification.config(;steps=4,outputs=:none))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    buffer=IOBuffer()
    PlantSimEngine.JSON.print(buffer,result)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/coupled-cohort-screen.json"),"w") do io
        write(io,take!(buffer))
    end
end
nothing

end
nothing
