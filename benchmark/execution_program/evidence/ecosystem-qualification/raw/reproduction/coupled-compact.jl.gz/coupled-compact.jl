include("/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine/benchmark/native_downstream/results/ecosystem-qualification/reproduction/ecosystem-lossless-wire.jl")
EcosystemLosslessWire.check()
let spec=DownstreamQualification.register_case(:coupled_small,CoupledQualification;replace=true,config=CoupledQualification.config(;steps=4,outputs=:none))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/coupled-compact-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,EcosystemLosslessWire.encode(result))
    end
end
nothing
