from pathlib import Path
import importlib.util,json,subprocess,time
root=Path('/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine')
out=root/'benchmark/native_downstream/results/ecosystem-qualification'
gate=out/'coupled-cached-state-gates.json'
while True:
    stages=json.loads(gate.read_text()) if gate.exists() else {}
    if any(not value['passed'] for value in stages.values()):raise RuntimeError('Final coupled gate failed')
    if len(stages)==5:break
    time.sleep(5)
spec=importlib.util.spec_from_file_location('client','/private/tmp/pse_ecosystem_coupled_kaimon_client.py');client=importlib.util.module_from_spec(spec);spec.loader.exec_module(client)
session=json.loads(client.STATE.read_text())['session']
response,_=client.post('tools/call',{'name':'check_eval','arguments':{'eval_id':'5f9ea20a'}},session)
(out/'receipts/cached-diagnostic-gates-completion.json').write_text(json.dumps(response,indent=2)+'\n')
text=' '.join(c.get('text','') for c in response.get('result',{}).get('content',[]))
if 'completed' not in text:raise RuntimeError('Final coupled checks not complete: '+text[:300])
for label in ['amap-small-cohort','amap-width-cohort','maespa-small-cohort','maespa-day-cohort','coupled-cohort']:
    coupled=label=='coupled-cohort'
    command=['python3','/private/tmp/pse_ecosystem_screen_runner.py',label,'/private/tmp/pse-ecosystem-'+label+'.jl',label+'-screen.json','--session','b9a4aef4' if coupled else '18dec163','--pid','64001' if coupled else '25262']
    if coupled:command.extend(['--client','/private/tmp/pse_ecosystem_coupled_kaimon_client.py'])
    result=subprocess.run(command,cwd=root)
    if result.returncode:raise RuntimeError('Final screen controller failed: '+label)
print('Published same-cohort screens complete',flush=True)
