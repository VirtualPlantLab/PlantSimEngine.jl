module EcoQualificationReload
function ismethod(ex)
    ex isa Expr || return false
    ex.head===:function && return true
    ex.head===:(=) && return ex.args[1] isa Expr && ex.args[1].head in (:call,:where)
    ex.head===:macrocall && return any(ismethod,ex.args)
    return false
end
function reload!(mod,path)
    parsed=Meta.parseall(read(path,String);filename=path)
    tree=only(ex for ex in parsed.args if ex isa Expr && ex.head===:module)
    for ex in tree.args[end].args
        ismethod(ex) && Core.eval(mod,ex)
    end
end
end
EcoQualificationReload.reload!(MAESPAQualification,joinpath(pwd(),"benchmark/native_downstream/maespa_qualification.jl"))
let out=joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification"), stages=Dict{String,Any}()
    tests=(("maespa_corrected_ordinary",()->MAESPAQualification.check(;prepare=DownstreamQualification.prepare,steps=2,outputs_modes=(:all,),arms=(:ordinary_b,))),
        ("amap_graph",()->AMAPQualification.check(:graph_only)),
        ("amap_candidate",()->AMAPQualification.check(:prep_candidate)),
        ("maespa_candidate",()->MAESPAQualification.check(;prepare=DownstreamQualification.prepare,steps=2,outputs_modes=(:none,:all),arms=(:graph_only,:prep_candidate))),
        ("maespa_actual_work",()->MAESPAQualification.check_profiled_work(;prepare=DownstreamQualification.prepare,steps=1)))
    open(joinpath(out,"preparation-gates-test-output.txt"),"w") do io
        redirect_stdout(io) do
            for (label,check) in tests
                stages[label]=try
                    (passed=true,result=Base.invokelatest(check))
                catch error
                    (passed=false,error=sprint(showerror,error,catch_backtrace();context=:limit=>true))
                end
                open(joinpath(out,"preparation-gates.json"),"w") do target
                    PlantSimEngine.JSON.print(target,stages,2)
                end
                stages[label].passed || break
            end
        end
    end
end
nothing
