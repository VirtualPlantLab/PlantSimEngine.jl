let spec=DownstreamQualification.register_case(:maespa_day,MAESPAQualification;config=MAESPAQualification.config(;steps=24,outputs=:none,start_slot=13))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/maespa-day-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,result,2)
    end
end
nothing
