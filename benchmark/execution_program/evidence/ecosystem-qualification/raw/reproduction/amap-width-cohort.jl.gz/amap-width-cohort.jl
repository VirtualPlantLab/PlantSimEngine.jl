let spec=DownstreamQualification.register_case(:amap_width_cohort,AMAPQualification;config=AMAPQualification.config(;steps=2,outputs=:none,nplants=4))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    buffer=IOBuffer()
    PlantSimEngine.JSON.print(buffer,result)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/amap-width-cohort-screen.json"),"w") do io
        write(io,take!(buffer))
    end
end
nothing
