let spec=DownstreamQualification.register_case(:coupled_final,CoupledQualification;config=CoupledQualification.config(;steps=4,outputs=:none))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/coupled-final-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,result)
    end
end
nothing
