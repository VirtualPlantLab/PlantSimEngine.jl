let source=read(joinpath(pwd(),"benchmark/native_downstream/coupled_qualification.jl"),String)
    matches=collect(eachmatch(r"(?m)^function _status_snapshot",source))
    @assert length(matches)==1
    definition,_=Meta.parse(source,only(matches).offset;raise=true)
    Core.eval(CoupledQualification,definition)
end
task_local_storage(:pse_coupled_qualification_type_names,IdDict{Any,String}()) do
let spec=DownstreamQualification.register_case(:coupled_quiet,CoupledQualification;config=CoupledQualification.config(;steps=4,outputs=:none))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    @assert result.expected_digest=="621e1b08916c44602b1a849148173114c5b0a9a1661ebc4799e429de75629166"
    buffer=IOBuffer()
    PlantSimEngine.JSON.print(buffer,result)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/coupled-quiet-screen.json"),"w") do io
        write(io,take!(buffer))
    end
end
nothing

end
nothing
