isdefined(Main,:EcosystemLosslessWireV3) || include("/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine/benchmark/native_downstream/results/ecosystem-qualification/reproduction/pse-ecosystem-lossless-wire-v3.jl")
let checked=EcosystemLosslessWireV3.check()
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/wire-encoder-gates.json"),"w") do io
        PlantSimEngine.JSON.print(io,checked)
    end
end
let spec=DownstreamQualification.register_case(:coupled_small,CoupledQualification;replace=true,config=CoupledQualification.config(;steps=4,outputs=:none))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    destination=joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/coupled-terminal-v2-screen.json")
    open(destination*".partial","w") do io
        PlantSimEngine.JSON.print(io,EcosystemLosslessWireV3.encode_screen(result))
    end
    mv(destination*".partial",destination)
end
nothing
