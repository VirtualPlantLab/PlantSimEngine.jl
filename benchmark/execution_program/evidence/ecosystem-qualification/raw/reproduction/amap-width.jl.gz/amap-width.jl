let spec=DownstreamQualification.register_case(:amap_width,AMAPQualification;config=AMAPQualification.config(;steps=2,outputs=:none,nplants=4))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/amap-width-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,result,2)
    end
end
nothing
