module EcosystemLosslessWire
using PlantSimEngine
const JSON=PlantSimEngine.JSON
const FORMAT="pse_lossless_string_table_v1"

# This encoder runs only after every timing and scientific fingerprint. All
# object nodes are tagged, so user data may contain arbitrary marker-like keys.
Base.@nospecializeinfer @noinline function encode_node(value,strings,index)
    @nospecialize value
    if value isa Union{AbstractString,Symbol}
        text=string(value)
        id=get!(index,text) do
            push!(strings,text)
            length(strings)-1
        end
        return Dict("s"=>id)
    elseif value isa NamedTuple || value isa AbstractDict
        return Dict("o"=>Any[Any[string(key),encode_node(item,strings,index)] for (key,item) in pairs(value)])
    elseif value isa Union{AbstractArray,Tuple}
        return Dict("a"=>Any[encode_node(item,strings,index) for item in value])
    elseif value===nothing || value isa Union{Bool,Real}
        return value
    end
    error("Unsupported lossless JSON wire value: ",typeof(value))
end
function encode(value)
    strings=String[];index=Dict{String,Int}()
    data=encode_node(value,strings,index)
    return Dict("wire_format"=>FORMAT,"strings"=>strings,"data"=>data)
end
function decode_node(value,strings)
    if value isa AbstractDict
        length(value)==1 || error("Malformed wire object")
        if haskey(value,"s")
            id=value["s"]
            id isa Integer && !(id isa Bool) && 0<=id<length(strings) || error("Bad wire string reference")
            return strings[id+1]
        elseif haskey(value,"a")
            return [decode_node(item,strings) for item in value["a"]]
        elseif haskey(value,"o")
            result=Dict{String,Any}()
            for pair in value["o"]
                length(pair)==2 && pair[1] isa AbstractString || error("Malformed wire object pair")
                haskey(result,pair[1]) && error("Duplicate wire object key")
                result[pair[1]]=decode_node(pair[2],strings)
            end
            return result
        end
        error("Unknown wire object tag")
    end
    value===nothing || value isa Union{Bool,Real} || error("Malformed wire primitive")
    return value
end
function check()
    sample=(text="repeated text",symbols=(:repeated_text,:repeated_text),
        markers=Dict("s"=>0,"a"=>[1,true,nothing],"o"=>Dict("wire_format"=>FORMAT)),
        values=(1.25,-3,false,nothing))
    ordinary=JSON.parse(JSON.json(sample))
    packed=JSON.parse(JSON.json(encode(sample)))
    @assert isequal(decode_node(packed["data"],packed["strings"]),ordinary)
    return (;passed=true,protocol=FORMAT,scope=:exact_JSON_document_roundtrip_including_marker_keys)
end
end
