from pathlib import Path
import hashlib,json,re,subprocess,shutil
root=Path('/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine')
out=root/'benchmark/native_downstream/results/ecosystem-qualification'
base=Path('/private/tmp/pse-ecosystem-source-freeze-20261101')
if base.exists(): raise RuntimeError('Refuse existing frozen cohort')
sources={
 'AMAPSim':Path('/Users/rvezy/Documents/dev/AMAPSim/AMAPSim.jl'),
 'MAESPA':Path('/Users/rvezy/Documents/dev/MAESPA'),
 'ArchimedLight':Path('/Users/rvezy/Documents/dev/ArchimedLight'),
 'PlantBiophysics':Path('/Users/rvezy/Documents/dev/PlantBiophysics'),
 'PlantGeom':Path('/Users/rvezy/Documents/dev/PlantGeom'),
}
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(p,*args):
 r=subprocess.run(['git','-C',str(p),*args],capture_output=True,check=True)
 return r.stdout
records={}
for name,src in sources.items():
 files=[]
 for component in ('src','ext'):
  if (src/component).exists(): files += [p for p in (src/component).rglob('*') if p.is_file() and not p.is_symlink()]
 if name=='AMAPSim':
  for component in ('dev/native','examples/ecophysiology','test/fixtures/native_arena','test/fixtures/native_originals'):
   files += [p for p in (src/component).rglob('*') if p.is_file() and not p.is_symlink()]
  files += [src/'benchmark'/x for x in ['native_pse_benchmark.jl','native_physiology_benchmark.jl']]
 elif name=='MAESPA':
  files += [p for p in (src/'examples').rglob('*') if p.is_file() and not p.is_symlink()]
 for f in ('Project.toml','Manifest.toml','AGENTS.md'):
  if (src/f).is_file():files.append(src/f)
 dest=base/name
 image={}
 for p in sorted(set(files)):
  rel=p.relative_to(src);data=p.read_bytes();target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);image[rel.as_posix()]=sha(data)
 before={p.relative_to(src).as_posix():sha(p.read_bytes()) for p in files}
 if before!=image:raise RuntimeError('Source changed during freeze '+name)
 records[name]=dict(original=str(src),frozen=str(dest),revision=git(src,'rev-parse','HEAD').decode().strip(),tracked_status=git(src,'status','--porcelain=v1','--untracked-files=no').decode(),source_files=image)
 diff=git(src,'diff','HEAD','--binary')
 q=out/'source-origin'/f'{name}.diff';q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(diff)
 records[name]['tracked_diff_sha256']=sha(diff)
# Relocate path entries and pin shared scientific packages to this same cohort.
paths={k:str(base/k) for k in sources};paths['PlantSimEngine']=str(root)
for name,rec in records.items():
 src=sources[name];dest=base/name;p=dest/'Manifest.toml'
 if not p.exists():continue
 original=p.read_text();chunks=re.split(r'(?=^\[\[deps\.)',original,flags=re.M);new=[]
 for chunk in chunks:
  m=re.match(r'\[\[deps\.([^\]]+)\]\]',chunk)
  pkg=m.group(1) if m else None
  if pkg in paths:
   chunk=re.sub(r'^(?:path|git-tree-sha1|registries) = .*\n','',chunk,flags=re.M)
   at=chunk.index('\n')+1;chunk=chunk[:at]+'path = '+json.dumps(paths[pkg])+'\n'+chunk[at:]
  else:
   chunk=re.sub(r'^path = "([^"]+)"',lambda m:'path = '+json.dumps(str((src/m.group(1)).resolve())),chunk,flags=re.M)
  new.append(chunk)
 p.write_text(''.join(new));rec['relocated_manifest_sha256']=sha(p.read_bytes())
 rec['frozen_files']={x.relative_to(dest).as_posix():sha(x.read_bytes()) for x in dest.rglob('*') if x.is_file()}
(out/'source-freeze.json').write_text(json.dumps(dict(root=str(base),packages=records),indent=2)+'\n')
print(json.dumps({k:dict(files=len(v['source_files']),revision=v['revision'],dirty=bool(v['tracked_status'])) for k,v in records.items()}))
