let spec=DownstreamQualification.register_case(:amap_small_cohort,AMAPQualification;config=AMAPQualification.config(;steps=2,outputs=:none,nplants=1))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    buffer=IOBuffer()
    PlantSimEngine.JSON.print(buffer,result)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/amap-small-cohort-screen.json"),"w") do io
        write(io,take!(buffer))
    end
end
nothing
