include("/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine/benchmark/native_downstream/results/ecosystem-qualification/reproduction/pse-ecosystem-lossless-wire-v2.jl")
EcosystemLosslessWireV2.check()
let spec=DownstreamQualification.register_case(:coupled_small,CoupledQualification;replace=true,config=CoupledQualification.config(;steps=4,outputs=:none))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/coupled-shared-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,EcosystemLosslessWireV2.encode_screen(result))
    end
end
nothing
