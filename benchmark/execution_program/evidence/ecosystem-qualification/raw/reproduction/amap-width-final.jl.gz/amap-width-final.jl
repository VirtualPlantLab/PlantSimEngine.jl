let spec=DownstreamQualification.register_case(:amap_width_final,AMAPQualification;config=AMAPQualification.config(;steps=2,outputs=:none,nplants=4))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/amap-width-final-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,result)
    end
end
nothing
