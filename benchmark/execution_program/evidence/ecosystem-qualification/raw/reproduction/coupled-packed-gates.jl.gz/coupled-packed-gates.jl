include(joinpath(pwd(),"benchmark/native_downstream/ecosystem_surface_fvcb_checks.jl"))
Base.invokelatest(EcosystemSurfaceFvcbChecks.reload_surface_fvcb_methods!)
let result=Base.invokelatest(EcosystemSurfaceFvcbChecks.surface_fvcb_checks)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/surface-fvcb-packed-gates.json"),"w") do io
        PlantSimEngine.JSON.print(io,result,2)
    end
end
let out=joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification"), stages=Dict{String,Any}()
    coupled_prepare(fixture,config,arm)=DownstreamQualification.prepare(fixture.model,arm,config;constants=fixture.constants)
    tests=(("ordinary_one",()->CoupledQualificationChecks.coupled_checks(coupled_prepare;config=CoupledQualification.config(;steps=1,outputs=:none),arms=(:ordinary_b,))),
        ("two_step_candidate",()->CoupledQualificationChecks.coupled_checks(coupled_prepare;config=CoupledQualification.config(;steps=2,outputs=:none),arms=(:graph_only,:prep_candidate))),
        ("positive_four_step",()->CoupledQualificationChecks.coupled_checks(coupled_prepare;config=CoupledQualification.config(;steps=4,outputs=:all),arms=(:prep_candidate,),require_positive=true)),
        ("continuation",()->CoupledQualificationChecks.coupled_continuation_checks(coupled_prepare;config=CoupledQualification.config(;steps=2,outputs=:all))),
        ("fingerprint_negatives",()->CoupledQualificationChecks.coupled_snapshot_contract_checks(coupled_prepare)))
    open(joinpath(out,"coupled-packed-gates-test-output.txt"),"w") do io
        redirect_stdout(io) do
            for (label,check) in tests
                stages[label]=try
                    (passed=true,result=Base.invokelatest(check))
                catch error
                    (passed=false,error=sprint(showerror,error,catch_backtrace();context=:limit=>true))
                end
                open(joinpath(out,"coupled-packed-gates.json"),"w") do target
                    PlantSimEngine.JSON.print(target,stages,2)
                end
                stages[label].passed || break
            end
        end
    end
end
nothing
