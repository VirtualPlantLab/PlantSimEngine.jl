import argparse
import json
import os
from pathlib import Path
import tomllib
import urllib.request
from datetime import datetime, timezone

STATE = Path('/private/tmp/pse_ecosystem_coupled_mcp_state.json')
CATALOG = Path('/private/tmp/pse_kaimon_tools.json')
CONFIG = Path('/Users/rvezy/.codex/config.toml')
URL = 'http://localhost:2828/mcp'

def post(method, params, session=None, notification=False):
    cfg = tomllib.loads(CONFIG.read_text())['mcp_servers']['kaimon']
    key = os.environ.get('MCPREPL_API_KEY') or cfg.get('env', {}).get('MCPREPL_API_KEY')
    headers = {'Content-Type':'application/json', 'Accept':'application/json, text/event-stream'}
    if key:
        headers['Authorization'] = 'Bearer ' + key
    if session:
        headers['Mcp-Session-Id'] = session
    body = {'jsonrpc':'2.0', 'method':method, 'params':params}
    if not notification:
        body['id'] = 1
    req = urllib.request.Request(URL, data=json.dumps(body).encode(), headers=headers, method='POST')
    with urllib.request.urlopen(req, timeout=180) as response:
        text = response.read().decode()
        if text.startswith('event:') or text.startswith('data:'):
            messages = [json.loads(line[5:].strip()) for line in text.splitlines() if line.startswith('data:')]
            value = next((x for x in reversed(messages) if x.get('id') == 1), messages[-1] if messages else {})
        else:
            value = json.loads(text) if text else {}
        return value, response.headers.get('Mcp-Session-Id')

def initialize():
    result, session = post('initialize', {'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'pse-ecosystem-coupled-validation','version':'1.0'}})
    if 'error' in result:
        raise RuntimeError(result['error'])
    STATE.write_text(json.dumps({'session':session}))
    post('notifications/initialized', {}, session, notification=True)
    return session

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['init','list','schema','call'])
    parser.add_argument('name', nargs='?')
    parser.add_argument('arguments_file', nargs='?')
    parser.add_argument('--receipt')
    args = parser.parse_args()
    if args.action == 'init':
        initialize()
        print(json.dumps({'initialized':True}))
        return
    if args.action == 'schema':
        data = json.loads(CATALOG.read_text())
        print(json.dumps(next(x for x in data if x['name'] == args.name)))
        return
    session = json.loads(STATE.read_text()).get('session') if STATE.exists() else initialize()
    if args.action == 'list':
        result, _ = post('tools/list', {}, session)
        tools = result.get('result', {}).get('tools', [])
        CATALOG.write_text(json.dumps(tools, indent=2))
        print(json.dumps({'tools':[{'name':x['name'],'description':x.get('description','')[:130]} for x in tools],'error':result.get('error')}))
    else:
        arguments = json.loads(Path(args.arguments_file).read_text()) if args.arguments_file else {}
        result, _ = post('tools/call', {'name':args.name,'arguments':arguments}, session)
        if args.receipt:
            receipt = Path(args.receipt)
            receipt.parent.mkdir(parents=True, exist_ok=True)
            receipt.write_text(json.dumps({'recorded_at':datetime.now(timezone.utc).isoformat(),
                'tool':args.name,'arguments':arguments,'response':result}, indent=2)+'\n')
        print(json.dumps(result))

if __name__ == '__main__':
    main()
