let spec=DownstreamQualification.register_case(:coupled_small,CoupledQualification;config=CoupledQualification.config(;steps=4,outputs=:none))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/coupled-small-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,result,2)
    end
end
nothing
