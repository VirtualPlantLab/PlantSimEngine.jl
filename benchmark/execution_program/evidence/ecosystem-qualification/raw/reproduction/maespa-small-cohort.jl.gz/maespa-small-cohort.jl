let spec=DownstreamQualification.register_case(:maespa_small_cohort,MAESPAQualification;config=MAESPAQualification.config(;steps=2,outputs=:none,start_slot=13))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    buffer=IOBuffer()
    PlantSimEngine.JSON.print(buffer,result)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/maespa-small-cohort-screen.json"),"w") do io
        write(io,take!(buffer))
    end
end
nothing
