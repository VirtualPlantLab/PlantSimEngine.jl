let spec=DownstreamQualification.register_case(:maespa_small,MAESPAQualification;config=MAESPAQualification.config(;steps=2,outputs=:none,start_slot=13))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/maespa-small-repeat-screen.json"),"w") do io
        PlantSimEngine.JSON.print(io,result,2)
    end
end
nothing
