let base="/private/tmp/pse-ecosystem-source-freeze-20261101"
    for (name,key) in (("PlantGeom","PSE_PLANTGEOM_PATH"),("PlantBiophysics","PSE_PLANTBIOPHYSICS_PATH"),("ArchimedLight","PSE_ARCHIMEDLIGHT_PATH"),("MAESPA","PSE_MAESPA_PATH"),("AMAPSim","PSE_AMAPSIM_PATH"))
        path=joinpath(base,name)
        ENV[key]=path
        path in LOAD_PATH || pushfirst!(LOAD_PATH,path)
    end
end
using PlantSimEngine
open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/coupled-worker.json"),"w") do io
    PlantSimEngine.JSON.print(io,(pid=getpid(),version=string(VERSION),threads=Threads.nthreads(),project=Base.active_project(),PSE=pathof(PlantSimEngine)),2)
end
using PlantGeom, PlantBiophysics, ArchimedLight, AMAPSim, MAESPA
@assert getpid()!=25262
@assert isdefined(ArchimedLight,:LightOptions) && isdefined(ArchimedLight,:LightSimulation)
for file in ("measurements.jl","bounded_preparation.jl","graph_row_projection.jl","typed_output_preparation.jl","downstream_qualification.jl","amapsim_qualification.jl","maespa_qualification.jl","coupled_qualification.jl","coupled_qualification_checks.jl")
    include(joinpath(pwd(),"benchmark/native_downstream",file))
end
open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/coupled-loaded-packages.json"),"w") do io
    PlantSimEngine.JSON.print(io,[(name=string(nameof(m)),root=pkgdir(m),version=string(Base.pkgversion(m))) for m in (PlantSimEngine,PlantGeom,PlantBiophysics,ArchimedLight,AMAPSim,MAESPA)],2)
end
nothing
