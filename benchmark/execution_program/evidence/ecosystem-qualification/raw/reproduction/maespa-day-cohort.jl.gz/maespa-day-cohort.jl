let spec=DownstreamQualification.register_case(:maespa_day_cohort,MAESPAQualification;config=MAESPAQualification.config(;steps=24,outputs=:none,start_slot=13))
    result=DownstreamQualification.screen(spec;repetitions=2,measure_retained=true)
    buffer=IOBuffer()
    PlantSimEngine.JSON.print(buffer,result)
    open(joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification/maespa-day-cohort-screen.json"),"w") do io
        write(io,take!(buffer))
    end
end
nothing
