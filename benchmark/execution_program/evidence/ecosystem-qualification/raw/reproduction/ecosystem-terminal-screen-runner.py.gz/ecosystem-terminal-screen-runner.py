"""Serial Kaimon ecosystem screen, immutable source and strict CPU guards."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,re,time
from datetime import datetime,timezone

def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
cold=load('pse_ecosystem_guard','/private/tmp/pse_preparation_scaling_cold_pilot.py')
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('script');p.add_argument('artifact');p.add_argument('--session',required=True);p.add_argument('--pid',type=int,required=True);p.add_argument('--client',default='/private/tmp/pse_kaimon_client.py');a=p.parse_args()
client=load('ecosystem_client',a.client)
root=Path('/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine');out=root/'benchmark/native_downstream/results/ecosystem-qualification';expected=out/a.artifact
if expected.exists():raise RuntimeError('Refuse existing screen')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
scope=json.loads((out/'source-freeze.json').read_text())
def image():
 result={'PSE':cold.source_image(root)}
 for name,rec in scope['packages'].items():
  folder=Path(rec['frozen']);files={x.relative_to(folder).as_posix():sha(x) for x in folder.rglob('*') if x.is_file()}
  if files!=rec['frozen_files']:raise RuntimeError('Frozen scientific image drift: '+name)
  result[name]=files
 return result
before=image();image_path=out/(a.label+'-source-image.json')
if image_path.exists():raise RuntimeError('Refuse source image overwrite')
write(image_path,before)
repro=out/'reproduction';repro.mkdir(exist_ok=True);script=repro/(a.label+'.jl')
if script.exists():raise RuntimeError('Refuse script overwrite')
script.write_bytes(Path(a.script).read_bytes());script_sha=sha(script)
runner=repro/'ecosystem-terminal-screen-runner.py'
if runner.exists() and runner.read_bytes()!=Path(__file__).read_bytes():raise RuntimeError('Runner changed')
if not runner.exists():runner.write_bytes(Path(__file__).read_bytes())
# Wait locally for two quiet samples; never reserve or message other chats.
deadline=time.monotonic()+180;stable=0
while stable<2:
 obs=cold.strict_cpu_sample(a.pid)
 stable=0 if obs['other_busy'] else stable+1
 if stable<2:
  if time.monotonic()>deadline:raise RuntimeError('No locally quiet Julia window within180s')
  time.sleep(5)
session=json.loads(client.STATE.read_text())['session'];receipts=[]
def call(name,args):
 r,_=client.post('tools/call',{'name':name,'arguments':args},session)
 path=out/'receipts'/f'{a.label}-{len(receipts)+1:02}-{name}.json'
 if path.exists():raise RuntimeError('Refuse receipt overwrite')
 write(path,{'at':datetime.now(timezone.utc).isoformat(),'tool':name,'arguments':args,'response':r});receipts.append(path);return r
monitor=cold.StrictMonitor(a.pid);monitor.start();failure=None;cpu=None
try:
 e='@assert getpid()=='+str(a.pid)+'; include('+cold.jl_string(script)+'); nothing'
 r=call('ex',dict(ses=a.session,e=e,q=True,max_output=1200));status=cold.response_state(r)
 if status=='running':
  t=cold.content(r);m=re.search(r'Job ID:\s*([\w-]+)',t);job=r.get('result',{}).get('eval_id') or (m.group(1) if m else None)
  if not job:raise RuntimeError('Missing jobid')
  deadline=time.monotonic()+600
  while True:
   time.sleep(2)
   if not expected.exists() and time.monotonic()<deadline:
    continue
   if expected.exists() and cpu is None:
    cpu=monitor.finish()
    cpu['scope']='complete asynchronous model job through atomic terminal artifact; result retrieval outside monitor'
    cpu['terminal_artifact']={'path':a.artifact,'sha256':sha(expected)}
   r=call('check_eval',{'eval_id':job});status=cold.response_state(r)
   if status!='running':break
   if time.monotonic()>deadline:raise RuntimeError('Screen exceeded600s')
 if status=='failed' or not expected.exists():raise RuntimeError('Screenfailed: '+cold.content(r)[:1800])
 if image()!=before or sha(script)!=script_sha:raise RuntimeError('Source drift duringtiming')
except BaseException as err:failure=repr(err)
finally:
 if cpu is None:cpu=monitor.finish()
 cpu_path=out/(a.label+'-cpu.json');write(cpu_path,cpu)
 record=dict(cpu_scope=cpu['scope'],artifact=a.artifact,artifact_sha256=sha(expected) if expected.exists() else None,cpu_record=cpu_path.name,cpu_sha256=sha(cpu_path),script=dict(path=script.relative_to(out).as_posix(),sha256=script_sha),receipt=dict(path=receipts[-1].relative_to(out).as_posix(),sha256=sha(receipts[-1])) if receipts else None,qualified=failure is None and cpu['qualified'],failure=failure,source_and_forcing_unchanged=failure is None,source_image=dict(path=image_path.name,sha256=sha(image_path)),worker=dict(pid=a.pid,session=a.session))
 q=out/'qualification.json';rows=json.loads(q.read_text())['artifacts'] if q.exists() else [];rows.append(record);write(q,{'artifacts':rows});print(json.dumps(dict(stage='completed',label=a.label,qualified=record['qualified'],failure=failure)),flush=True)
if failure:raise RuntimeError(failure)
