using Test, SHA
let path=joinpath(pwd(),"benchmark/native_downstream/coupled_qualification.jl")
    source=read(path,String)
    starts=collect(eachmatch(r"(?m)^Base\.@nospecializeinfer @noinline function _value",source))
    length(starts)==1 || error("Expected one bounded value snapshot method")
    definition,_=Meta.parse(source,only(starts).offset;raise=true)
    Core.eval(CoupledQualification,definition)
end
let root=joinpath(pwd(),"benchmark/native_downstream/results/ecosystem-qualification"),passed=false
    open(joinpath(root,"numeric-snapshot-final-test-output.txt"),"w") do io
        redirect_stdout(io) do
            @testset "Exact primitive numeric scientific snapshot blocks" begin
                data=Any[reshape(UInt64.(1:6),2,3),Float32[-0.0,NaN,Inf],BitArray([true false;false true]),
                    reshape(Int16[],0,2),fill(4.0),Bool[true,false],
                    reshape(collect(UInt128(1):UInt128(8)),2,2,2),
                    view(reshape(collect(1:12),3,4),1:2,2:4)]
                for value in data
                    snapshot=Base.invokelatest(CoupledQualification._value,value,CoupledQualification.SnapshotContext())
                    contents=snapshot.contents
                    @test contents.element_type==string(eltype(value))
                    @test contents.shape==size(value)
                    @test contents.payload.encoding===:column_major_native_bytes_hex
                    expected=collect(reinterpret(UInt8,vec(collect(value))))
                    @test hex2bytes(contents.payload.data)==expected
                    @test contents.payload.byte_order===(Base.ENDIAN_BOM==0x04030201 ? :little : :big)
                end
                value=UInt64[1,2];context=CoupledQualification.SnapshotContext()
                snapshot=Base.invokelatest(CoupledQualification._value,value,context)
                alias=Base.invokelatest(CoupledQualification._value,value,context)
                @test alias.alias===snapshot.alias
                value[1]⊻=UInt64(1)
                altered=Base.invokelatest(CoupledQualification._value,value,CoupledQualification.SnapshotContext())
                @test snapshot.contents.payload.data!=altered.contents.payload.data
                fallback=Base.invokelatest(CoupledQualification._value,BigFloat[1,2],CoupledQualification.SnapshotContext())
                @test hasproperty(fallback.contents,:values)
                @test !hasproperty(fallback.contents,:payload)
                @test all(x->x.type=="BigFloat",fallback.contents.values)
            end
        end
    end
    open(joinpath(root,"numeric-snapshot-final-gates.json"),"w") do io
        PlantSimEngine.JSON.print(io,(passed=true,
            source_sha256=bytes2hex(sha256(read(joinpath(pwd(),"benchmark/native_downstream/coupled_qualification.jl")))),
            scope=:lossless_untimed_primitive_numeric_arrays_with_shape_type_alias_and_byte_order),2)
    end
end
nothing
