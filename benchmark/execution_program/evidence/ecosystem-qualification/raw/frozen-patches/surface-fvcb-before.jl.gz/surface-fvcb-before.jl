"""
Optional light–photosynthesis boundary for the experimental native arenas.

Load `native.jl` and `pse.jl` first. ArchimedLight, PlantBiophysics and PlantGeom
are needed only by this file. Light sees the committed opening geometry;
architecture and construction follow that interval's signed carbon exchange.
"""
module NativeAMAPPhysiology

import ..NativeAMAP as Native
import ..NativeAMAPPSE as Adapter
import PlantSimEngine as PSE
import PlantBiophysics as PB
import ArchimedLight as AL
import PlantGeom as PG
import MultiScaleTreeGraph as MTG
import GeometryBasics as GB

export NativeSurfaceGeometry, NativeRadiation, AtmosphericLeafState, SurfaceFvcb
export SurfaceNetCarbon, PhotosyntheticSupply, PhotosyntheticGrowthAllocation
export scenario, realized_scene, AREA_CONTRACT, ORGAN_CARBON_CONTRACT

const AREA_CONTRACT = PSE.VariableContract(unit=:square_metre, basis=:organ,
    temporal=nothing, aggregation=:total, extent=:extensive)
const ORGAN_CARBON_CONTRACT = PSE.VariableContract(unit=:g_carbon, basis=:organ,
    temporal=:step, aggregation=:total, extent=:extensive)
const PHOTON_CONTRACT = PSE.VariableContract(unit=:micromol_photon,
    basis=:surface_area, temporal=:second, aggregation=:rate, extent=:intensive)

function _finite(value, name; nonnegative=false, positive=false)
    value isa Real && !(value isa Bool) && isfinite(value) ||
        throw(ArgumentError("$name must be a finite real number"))
    nonnegative && value < 0 && throw(ArgumentError("$name must be nonnegative"))
    positive && value <= 0 && throw(ArgumentError("$name must be positive"))
    converted = Float64(value)
    isfinite(converted) && (!positive || converted > 0) ||
        throw(ArgumentError("$name is not representable in Float64"))
    return converted
end

"""
    NativeSurfaceGeometry(; metres_per_native_unit,
        leaf_width_per_native_diameter, domain, plant_positions_m, internode_sides=6)

Explicit radiative hypothesis: a native Leaf is represented by one flat diamond
with length equal to its realized native length and maximum width equal to its
realized bottom diameter times `leaf_width_per_native_diameter`. Its one-mesh
surface area is the reference surface for light and FvCB. This is an authored
lamina conversion, not inferred from the FPA or a leaf biomass calibration.
Non-leaf organs are capped polygonal frusta. All geometry is converted once to
metres and translated by each typed plant identity's supplied position.
Zero-dimensional organs have no radiative surface and no carbon exchange.
"""
struct NativeSurfaceGeometry
    metres_per_native_unit::Float64
    leaf_width_per_native_diameter::Float64
    domain::NTuple{4,Float64}
    plant_positions_m::Dict{PSE.ObjectId,NTuple{3,Float64}}
    internode_sides::Int
end
function NativeSurfaceGeometry(; metres_per_native_unit,
    leaf_width_per_native_diameter, domain, plant_positions_m,
    internode_sides::Integer=6)
    unit = _finite(metres_per_native_unit, "metres_per_native_unit"; positive=true)
    width = _finite(leaf_width_per_native_diameter,
        "leaf_width_per_native_diameter"; positive=true)
    length(domain) == 4 || throw(ArgumentError("domain requires four metre bounds"))
    bounds = Tuple(_finite(x, "domain bound") for x in domain)
    bounds[1] < bounds[3] && bounds[2] < bounds[4] ||
        throw(ArgumentError("domain bounds must be increasing"))
    internode_sides isa Bool && throw(ArgumentError("internode_sides must be an integer"))
    3 <= internode_sides <= typemax(Int) ||
        throw(ArgumentError("internode_sides must be at least 3"))
    positions = Dict{PSE.ObjectId,NTuple{3,Float64}}()
    for (id, position) in pairs(plant_positions_m)
        key = PSE.ObjectId(id)
        haskey(positions, key) && throw(ArgumentError("duplicate plant position $id"))
        length(position) == 3 || throw(ArgumentError("plant positions require xyz in metres"))
        positions[key] = Tuple(_finite(x, "plant position") for x in position)
    end
    return NativeSurfaceGeometry(unit, width, bounds, positions, Int(internode_sides))
end

_add(a, b) = ntuple(i -> a[i] + b[i], 3)
_scale(a, x) = ntuple(i -> Float64(a[i]) * x, 3)
_dot(a, b) = sum(a[i] * b[i] for i in 1:3)
function _unit(a)
    norm = sqrt(_dot(a, a))
    norm > 0 && isfinite(norm) || throw(ArgumentError("invalid native frame"))
    return _scale(a, inv(norm))
end

function _lamina_mesh(organ, surface, origin)
    along = _unit(organ.frame[1])
    transverse = _unit(ntuple(i -> organ.frame[2][i] -
        _dot(organ.frame[2], along) * along[i], 3))
    base = _add(origin, _scale(organ.base, surface.metres_per_native_unit))
    length = Float64(organ.length) * surface.metres_per_native_unit
    width = Float64(organ.diameter_bottom) * surface.metres_per_native_unit *
        surface.leaf_width_per_native_diameter
    midpoint = _add(base, _scale(along, length / 2))
    points = GB.Point3d[GB.Point3d(base...),
        GB.Point3d(_add(midpoint, _scale(transverse, width / 2))...),
        GB.Point3d(_add(base, _scale(along, length))...),
        GB.Point3d(_add(midpoint, _scale(transverse, -width / 2))...)]
    return GB.Mesh(points, GB.TriangleFace{Int}[(1, 2, 3), (1, 3, 4)])
end

function _organ_geometry(organ, leaf, surface, origin)
    if leaf
        return PG.Geometry(ref_mesh=PG.RefMesh("native_lamina", _lamina_mesh(organ,
            surface, origin)))
    end
    base = _add(origin, _scale(organ.base, surface.metres_per_native_unit))
    tip = _add(origin, _scale(organ.tip, surface.metres_per_native_unit))
    return PG.ExtrudedTubeGeometry([base, tip]; n_sides=surface.internode_sides,
        radius=1.0,
        radii=[Float64(organ.diameter_bottom), Float64(organ.diameter_top)] .*
            (surface.metres_per_native_unit / 2), cap_ends=true)
end

PSE.@process "native_radiation" verbose=false
"""A scene-scheduled radiative calculation over the opening realized geometry."""
mutable struct NativeRadiation{S,O,M} <: AbstractNative_RadiationModel
    surface::S
    options::O
    optical_models::M
    par_energy_to_photon::Float64
    last_scene::Any
    simulation::Any
end
function NativeRadiation(surface, options, optical_models; par_energy_to_photon)
    conversion = _finite(par_energy_to_photon, "par_energy_to_photon"; positive=true)
    return NativeRadiation(surface, options, optical_models, conversion, nothing, nothing)
end
PSE.inputs_(::NativeRadiation) = (native_states=PSE.Required(AbstractVector),)
PSE.environment_inputs_(::NativeRadiation) = (duration_seconds=0.0,
    sun_azimuth_deg=0.0, sun_elevation_deg=0.0,
    Ri_PAR_f=0.0, Ri_NIR_f=0.0, direct_fraction=0.0)
PSE.outputs_(::NativeRadiation) = (aPPFD=PSE.Distributed(PSE.Default(0.0)),
    area_m2=PSE.Distributed(PSE.Default(0.0)), light_epoch=0,
    radiation_records=NamedTuple[], opening_plant_times=NamedTuple[],
    preceding_interval_seconds=0.0, geometry_seconds=0.0, light_seconds=0.0)
PSE.variable_contracts_(::NativeRadiation) = (aPPFD=PHOTON_CONTRACT,
    area_m2=AREA_CONTRACT, duration_seconds=Adapter.COUPLING_DURATION_CONTRACT)

function _radiation_forcing(environment)
    azimuth = _finite(environment.sun_azimuth_deg, "sun azimuth in degrees")
    elevation = _finite(environment.sun_elevation_deg, "sun elevation in degrees")
    direct = _finite(environment.direct_fraction, "direct radiation fraction")
    0 <= azimuth < 360 || throw(ArgumentError("sun azimuth must be in [0,360) degrees"))
    -90 <= elevation <= 90 || throw(ArgumentError("sun elevation must be in [-90,90] degrees"))
    0 <= direct <= 1 || throw(ArgumentError("direct_fraction must be in [0,1]"))
    par = _finite(environment.Ri_PAR_f, "PAR irradiance"; nonnegative=true)
    nir = _finite(environment.Ri_NIR_f, "NIR irradiance"; nonnegative=true)
    duration = _finite(environment.duration_seconds, "duration_seconds"; positive=true)
    # The public SkyState API, also used by ArchimedLight's PSE wrapper, takes
    # degrees. It avoids conflating PSE's *_deg ports with the meteo-table aliases.
    return AL.SkyState(azimuth, elevation, par, nir, direct, 1.0-direct), duration
end

function _validate_preceding_exchange(status)
    states = status.native_states
    ids = [state.plant_id for state in states]
    length(ids) == length(unique(ids)) || throw(ArgumentError("duplicate native plant state"))
    all(state -> !state.coupled_pending, states) || throw(ArgumentError(
        "light requires completed native exchanges; discard a failed simulation"))
    iszero(status.light_epoch) && return nothing
    preceding = Dict(record.plant_id => record.physical_time
        for record in status.opening_plant_times)
    Set(ids) == Set(keys(preceding)) || throw(ArgumentError(
        "native plant membership changed across a physiology interval"))
    duration = _finite(status.preceding_interval_seconds,
        "preceding interval seconds"; positive=true)
    for state in states
        expected = preceding[state.plant_id] + duration
        actual = state.development.physical_time
        isfinite(expected) && isfinite(actual) && isapprox(actual, expected;
            rtol=1e-12, atol=0.0) || throw(ArgumentError(
            "the preceding physiology interval did not complete native advancement; discard this simulation"))
    end
    return nothing
end

function _prepare_scene(model::NativeRadiation, states)
    records = NamedTuple[]
    # Stable plant-scoped source ownership survives duplicate raw native slots.
    plants = Any[]
    instances = Dict{Int,PSE.ObjectId}()
    for (instance, state) in enumerate(states)
        state isa Adapter.NativePSEState || throw(ArgumentError("foreign native state"))
        state.coupled_pending && throw(ArgumentError(
            "light requires a completed preceding native exchange"))
        origin = get(model.surface.plant_positions_m, state.plant_id, nothing)
        origin === nothing && throw(ArgumentError("missing plant position $(state.plant_id)"))
        root = MTG.Node(1, MTG.NodeMTG(:/, :Plant, 1, 1), Dict{Symbol,Any}())
        instances[instance] = state.plant_id
        for (id, organ) in enumerate(state.native.plant.organs)
            organ.active || continue
            organ.length > 0 && max(organ.diameter_bottom, organ.diameter_top) > 0 || continue
            symbol = Adapter._product_symbol(state, organ)
            leaf = symbol === :Leaf
            leaf && organ.diameter_bottom <= 0 && continue
            child = MTG.Node(id + 1, root, MTG.NodeMTG(:+, leaf ? :Leaf : :Internode,
                id, 2), Dict{Symbol,Any}(:native_organ_id => id))
            child[:geometry] = _organ_geometry(organ, leaf, model.surface, origin)
            child[:type] = leaf ? "Leaf" : "Internode"
            if leaf
                push!(records, (plant_id=state.plant_id, organ_id=id,
                    object_id=Adapter.native_object_id(state.plant_id, :Leaf, id),
                    length=organ.length, diameter_top=organ.diameter_top,
                    diameter_bottom=organ.diameter_bottom, base=organ.base, tip=organ.tip,
                    source_instance_id=instance))
            end
        end
        push!(plants, root)
    end
    any_geometry = any(root -> any(PG.has_geometry, MTG.traverse(root, identity)), plants)
    any_geometry || return nothing, records, instances
    scene = PG.make_scene(domain=model.surface.domain,
        source_path="AMAPSim native realized geometry") do builder
        for (ordinal, plant) in enumerate(plants)
            PG.add_plant!(builder, plant; group="native", id=ordinal,
                source_owner=node -> node[:native_organ_id])
        end
    end
    return scene, records, instances
end

"""
    realized_scene(radiation, native_states)

Materialize a detached PlantGeom scene from the current committed native
dimensions. Coordinates use the radiation surface's explicit metre conversion
and source owners retain native organ slots within each supplied plant. An empty
plant set or a set without positive geometry returns `nothing`.

This observation neither advances development nor calculates radiation. It does
not update the radiation model's opening scene/cache, light epoch, or native RNG.
Only completed native exchanges may be observed.
"""
function realized_scene(model::NativeRadiation, states)
    for state in states
        state isa Adapter.NativePSEState || throw(ArgumentError("foreign native state"))
        state.coupled_pending && throw(ArgumentError(
            "realized geometry requires a completed native exchange"))
        growth = state.organ_growth
        growth === nothing || (!growth.failed &&
            growth.committed_revision == growth.revision) || throw(ArgumentError(
            "realized geometry requires committed organ growth"))
    end
    scene, _, _ = _prepare_scene(model, states)
    return scene
end

function PSE.run!(model::NativeRadiation, status, environment, constants, context)
    sky, duration = _radiation_forcing(environment)
    _validate_preceding_exchange(status)
    targets = PSE.output_targets(context, (:aPPFD, :area_m2))
    target_ids = collect(PSE.object_ids(targets))
    target_position = Dict(id => i for (i, id) in enumerate(target_ids))
    start = time_ns()
    scene, records, instances = _prepare_scene(model, status.native_states)
    geometry_seconds = (time_ns() - start) / 1e9
    photons = zeros(Float64, length(target_ids))
    areas = zeros(Float64, length(target_ids))
    result_records = NamedTuple[]
    model.last_scene = scene
    start = time_ns()
    if scene !== nothing
        if model.simulation === nothing
            model.simulation = AL.LightSimulation(scene, model.optical_models;
                options=model.options)
        else
            AL.update_scene!(model.simulation, scene)
        end
        result = AL.run_light(model.simulation, sky; step_duration_seconds=duration)
        values = AL.component_values(result; level=:source_owner,
            par_energy_to_photon=model.par_energy_to_photon)
        index = Dict((record.source_instance_id, record.organ_id) => record for record in records)
        seen = Set{Tuple{Int,Int}}()
        for i in eachindex(values.source_owner)
            owner = values.source_owner[i]
            key = (owner.source_instance_id, owner.source_node_id)
            record = get(index, key, nothing)
            record === nothing && continue # nonphotosynthetic stem still shades
            key in seen && throw(ArgumentError("duplicate radiative native Leaf owner"))
            push!(seen, key)
            instance_id = get(instances, owner.source_instance_id, nothing)
            instance_id == record.plant_id || throw(ArgumentError("foreign source owner"))
            position = get(target_position, record.object_id, nothing)
            position === nothing && throw(ArgumentError(
                "realized native Leaf has no declared physiology object"))
            area = _finite(values.radiative_mesh_area[i], "radiative area"; positive=true)
            ppfd = _finite(values.aPPFD[i], "absorbed PPFD"; nonnegative=true)
            areas[position] = area
            photons[position] = ppfd
            push!(result_records, merge(record, (area_m2=area, aPPFD=ppfd)))
        end
        length(seen) == length(index) || throw(ArgumentError(
            "light did not retain every positive-area opening native Leaf"))
    else
        # In particular, cutting the last organ must release the previous scene
        # and solver cache rather than keeping dead ownership/geometry alive.
        model.simulation = nothing
    end
    light_seconds = (time_ns() - start) / 1e9
    # Complete all validation before publishing this generation's distributed values.
    PSE.assign_outputs!(targets, target_ids, (aPPFD=photons, area_m2=areas))
    status.radiation_records = result_records
    status.opening_plant_times = [(plant_id=state.plant_id,
        physical_time=state.development.physical_time, development_time=state.native.plant.time)
        for state in status.native_states]
    status.preceding_interval_seconds = duration
    status.geometry_seconds = geometry_seconds
    status.light_seconds = light_seconds
    status.light_epoch += 1
    return nothing
end

PSE.@process "native_atmospheric_leaf_state" verbose=false
"""Explicit imposed-state hypothesis: Tleaf=Tair, Csurface=Ca, Dleaf=air VPD."""
struct AtmosphericLeafState <: AbstractNative_Atmospheric_Leaf_StateModel end
PSE.environment_inputs_(::AtmosphericLeafState) = (T=0.0, Cₐ=0.0, VPD=0.0)
PSE.outputs_(::AtmosphericLeafState) = (Tₗ=0.0, Cₛ=0.0, Dₗ=0.0)
function PSE.run!(::AtmosphericLeafState, status, environment, constants, context)
    temperature = _finite(environment.T, "air temperature")
    carbon = _finite(environment.Cₐ, "air CO2"; positive=true)
    vpd = _finite(environment.VPD, "air VPD"; nonnegative=true)
    status.Tₗ = temperature
    status.Cₛ = carbon
    status.Dₗ = vpd
    return nothing
end

"""Delegate real FvCB/Medlyn calls; a zero represented area exchanges no carbon."""
struct SurfaceFvcb{M<:PB.Fvcb} <: PB.AbstractPhotosynthesisModel
    model::M
end
PSE.inputs_(model::SurfaceFvcb) = merge(PSE.inputs_(model.model),
    (area_m2=PSE.Required(Real),))
PSE.outputs_(::SurfaceFvcb) = (A=0.0, Gₛ=0.0, Cᵢ=0.0)
PSE.dep(model::SurfaceFvcb) = PSE.dep(model.model)
PSE.variable_contracts_(model::SurfaceFvcb) = merge(PSE.variable_contracts_(model.model),
    (area_m2=AREA_CONTRACT,))
PSE.output_policy(::Type{SurfaceFvcb{M}}) where {M} = PSE.output_policy(M)
PSE.timestep_hint(::Type{SurfaceFvcb{M}}) where {M} = PSE.timestep_hint(M)
function PSE.run!(model::SurfaceFvcb, status, environment, constants, context)
    area = _finite(status.area_m2, "represented area"; nonnegative=true)
    if iszero(area)
        status.A = 0.0
        status.Gₛ = 0.0
        status.Cᵢ = 0.0
    else
        PSE.run!(model.model, status, environment, constants, context)
    end
    return nothing
end

PSE.@process "native_surface_carbon" verbose=false
struct SurfaceNetCarbon <: AbstractNative_Surface_CarbonModel end
PSE.inputs_(::SurfaceNetCarbon) = (A=PSE.Required(Real), area_m2=PSE.Required(Real))
PSE.environment_inputs_(::SurfaceNetCarbon) = (duration_seconds=0.0,)
PSE.outputs_(::SurfaceNetCarbon) = (carbon_step_gC=0.0,)
PSE.variable_contracts_(::SurfaceNetCarbon) = (area_m2=AREA_CONTRACT,
    duration_seconds=Adapter.COUPLING_DURATION_CONTRACT,
    carbon_step_gC=ORGAN_CARBON_CONTRACT)
function PSE.run!(::SurfaceNetCarbon, status, environment, constants, context)
    area = _finite(status.area_m2, "represented area"; nonnegative=true)
    assimilation = _finite(status.A, "net assimilation")
    duration = _finite(environment.duration_seconds, "duration_seconds"; positive=true)
    status.carbon_step_gC = _finite(assimilation * area * duration * 12e-6,
        "signed interval leaf carbon")
    return nothing
end

PSE.@process "native_photosynthetic_supply" verbose=false
struct PhotosyntheticSupply <: AbstractNative_Photosynthetic_SupplyModel end
PSE.inputs_(::PhotosyntheticSupply) = (leaf_carbon_gC=PSE.Required(AbstractVector),
    light_epoch=PSE.Required(Integer))
PSE.environment_inputs_(::PhotosyntheticSupply) = (development_rate_per_second=0.0,)
PSE.outputs_(::PhotosyntheticSupply) = (cumulative_carbon_supply_gC=0.0,
    cumulative_carbon_loss_gC=0.0, development_rate=0.0, credited_light_epoch=0)
PSE.variable_contracts_(::PhotosyntheticSupply) = (leaf_carbon_gC=ORGAN_CARBON_CONTRACT,
    cumulative_carbon_supply_gC=Adapter._CUMULATIVE_CARBON_CONTRACT,
    cumulative_carbon_loss_gC=Adapter._CUMULATIVE_CARBON_CONTRACT,
    development_rate=Adapter.DEVELOPMENT_RATE_CONTRACT,
    development_rate_per_second=Adapter.DEVELOPMENT_RATE_CONTRACT)
function PSE.run!(::PhotosyntheticSupply, status, environment, constants, context)
    epoch = status.light_epoch
    epoch isa Integer && !(epoch isa Bool) && epoch > 0 ||
        throw(ArgumentError("light_epoch must identify a completed radiation interval"))
    epoch >= status.credited_light_epoch || throw(ArgumentError(
        "a completed radiation interval cannot move backwards"))
    rate = _finite(environment.development_rate_per_second,
        "development_rate_per_second"; nonnegative=true)
    if epoch == status.credited_light_epoch
        status.development_rate = rate
        return nothing
    end
    supply = _finite(status.cumulative_carbon_supply_gC, "cumulative supply"; nonnegative=true)
    loss = _finite(status.cumulative_carbon_loss_gC, "cumulative loss"; nonnegative=true)
    for value in status.leaf_carbon_gC
        carbon = _finite(value, "signed leaf exchange")
        supply += max(carbon, 0.0)
        loss += max(-carbon, 0.0)
    end
    supply = _finite(supply, "cumulative supply"; nonnegative=true)
    loss = _finite(loss, "cumulative loss"; nonnegative=true)
    status.cumulative_carbon_supply_gC = supply
    status.cumulative_carbon_loss_gC = loss
    status.development_rate = rate
    status.credited_light_epoch = epoch
    return nothing
end

struct PhotosyntheticGrowthAllocation{T<:AbstractFloat} <:
    PSE.Examples.AbstractCarbon_AllocationModel
    initial_reserve_gC::T
end
function PhotosyntheticGrowthAllocation(; initial_reserve_gC)
    reserve = float(initial_reserve_gC)
    Adapter._nonnegative_carbon(reserve, "initial_reserve_gC")
    return PhotosyntheticGrowthAllocation(reserve)
end
PSE.inputs_(::PhotosyntheticGrowthAllocation{T}) where {T} = (
    _native_pse_state=PSE.Required(Adapter.NativePSEState),
    growth_demands=PSE.Required(Adapter.OrganDemandBatch{T}),
    cumulative_carbon_supply_gC=PSE.Required(Real),
    cumulative_carbon_loss_gC=PSE.Required(Real))
PSE.outputs_(model::PhotosyntheticGrowthAllocation{T}) where {T} = (
    growth_allocation=Adapter._empty_organ_allocations(T, model.initial_reserve_gC),)
PSE.variable_contracts_(::PhotosyntheticGrowthAllocation) = (
    growth_demands=Adapter._ORGAN_DEMAND_BATCH_CONTRACT,
    growth_allocation=Adapter._ORGAN_ALLOCATION_BATCH_CONTRACT,
    cumulative_carbon_supply_gC=Adapter._CUMULATIVE_CARBON_CONTRACT,
    cumulative_carbon_loss_gC=Adapter._CUMULATIVE_CARBON_CONTRACT)
function PSE.run!(model::PhotosyntheticGrowthAllocation, status, environment, constants, context)
    status.growth_allocation = Adapter._quote_growth_allocation(status._native_pse_state,
        status.growth_demands, model.initial_reserve_gC,
        status.cumulative_carbon_supply_gC, status.cumulative_carbon_loss_gC)
    return nothing
end

"""
    scenario(plants; weather, surface, light_options, optical_models,
        photosynthesis_model, conductance_model, demand_model,
        initial_reserve_gC, par_energy_to_photon, expansion_model, applications=())

Build the explicit interval composition. Weather supplies physical duration and
developmental rate independently of carbon. Leaves selected by the declared
physiology models become PSE Objects; stems shade but need no PSE organ Objects.
The supplied gas-exchange parameters and lamina conversion are demonstration
assumptions unless independently calibrated. Returns `(model, radiation)`.
"""
function scenario(plants; weather, surface, light_options, optical_models,
    photosynthesis_model, conductance_model, demand_model, initial_reserve_gC,
    par_energy_to_photon, expansion_model=Adapter.IsometricExpansion(), applications=(),
    kwargs...)
    radiation = NativeRadiation(surface, light_options, optical_models;
        par_energy_to_photon)
    own(application, var) = PSE.One(within=PSE.Self(), application=application,
        var=var, policy=PSE.HoldLast())
    specs = (
        PSE.ModelSpec(radiation; name=:native_radiation, on=PSE.One(scale=:Scene),
            inputs=(native_states=PSE.Many(scale=:Plant, within=PSE.SceneScope(),
                var=:_native_pse_state),),
            outputs_to=(PSE.OutputTo(PSE.Many(scale=:Leaf, within=PSE.SceneScope());
                coverage=:exact),)),
        PSE.ModelSpec(AtmosphericLeafState(); name=:native_leaf_state,
            on=PSE.Many(scale=:Leaf)),
        PSE.ModelSpec(SurfaceFvcb(photosynthesis_model); name=:native_photosynthesis,
            on=PSE.Many(scale=:Leaf), inputs=(
                aPPFD=own(:native_radiation, :aPPFD),
                area_m2=own(:native_radiation, :area_m2),
                Tₗ=own(:native_leaf_state, :Tₗ), Cₛ=own(:native_leaf_state, :Cₛ)),
            calls=(stomatal_conductance=PSE.One(within=PSE.Self(),
                application=:native_stomatal_conductance),)),
        PSE.ModelSpec(conductance_model; name=:native_stomatal_conductance,
            on=PSE.Many(scale=:Leaf), inputs=(Dₗ=own(:native_leaf_state, :Dₗ),
                Cₛ=own(:native_leaf_state, :Cₛ))),
        PSE.ModelSpec(SurfaceNetCarbon(); name=:native_leaf_carbon,
            on=PSE.Many(scale=:Leaf), inputs=(A=own(:native_photosynthesis, :A),
                area_m2=own(:native_radiation, :area_m2))),
        PSE.ModelSpec(PhotosyntheticSupply(); name=:native_carbon_supply,
            on=PSE.Many(scale=:Plant), inputs=(
                leaf_carbon_gC=PSE.Many(scale=:Leaf, within=PSE.Subtree(),
                    application=:native_leaf_carbon, var=:carbon_step_gC,
                    policy=PSE.HoldLast()),
                light_epoch=PSE.One(scale=:Scene, within=PSE.SceneScope(),
                    application=:native_radiation, var=:light_epoch))),
        PSE.ModelSpec(demand_model; name=:native_demand, on=PSE.Many(scale=:Plant)),
        PSE.ModelSpec(PhotosyntheticGrowthAllocation(; initial_reserve_gC);
            name=:native_allocation, on=PSE.Many(scale=:Plant), inputs=(
                growth_demands=own(:native_demand, :growth_demands),
                cumulative_carbon_supply_gC=own(:native_carbon_supply,
                    :cumulative_carbon_supply_gC),
                cumulative_carbon_loss_gC=own(:native_carbon_supply,
                    :cumulative_carbon_loss_gC))),
        PSE.ModelSpec(expansion_model; name=:native_expansion, on=PSE.Many(scale=:Plant),
            inputs=(growth_allocation=own(:native_allocation, :growth_allocation),)),
        applications...)
    model = Adapter.scenario(plants; mode=:coupled, realization=:models,
        applications=specs, environment=weather, kwargs...)
    return (; model, radiation)
end

end
