let out=joinpath(pwd(),"benchmark/native_downstream/results/persistent-program"), stages=Dict{String,Any}()
    tests=(
        ("conditional0",()->PersistentFeatureChecks.persistent_conditional_epoch_checks(;inspect_step=0)),
        ("conditional1",()->PersistentFeatureChecks.persistent_conditional_epoch_checks(;inspect_step=1)),
        ("conditional2",()->PersistentFeatureChecks.persistent_conditional_epoch_checks(;inspect_step=2)),
        ("conditional3",()->PersistentFeatureChecks.persistent_conditional_epoch_checks(;inspect_step=3)),
        ("late_unqueried",()->PersistentFeatureChecks.persistent_conditional_epoch_checks(;inspect_step=2,late_unqueried=true)),
        ("generic_all",()->PersistentTightChecks.persistent_all_checks()),
        ("float64",()->PersistentTightChecks.persistent_lifecycle_checks(;T=Float64,outputs_modes=(:all,))),
        ("nested_exceptions",()->PersistentFeatureChecks.persistent_nested_exception_checks()),
        ("partial_failure",()->PersistentFeatureChecks.persistent_partial_failure_checks()),
        ("consumed_exposure",()->PersistentFeatureChecks.persistent_consumed_exposure_checks()),
        ("evaluate_accept",()->PersistentFeatureChecks.persistent_protocol_fallback_checks(;case=:evaluate_accept)),
        ("stale_accept",()->PersistentFeatureChecks.persistent_protocol_fallback_checks(;case=:stale_accept)),
        ("backend_override",()->PersistentFeatureChecks.persistent_protocol_fallback_checks(;case=:backend_override)),
        ("mutable_environment",()->PersistentFeatureChecks.persistent_mutable_environment_checks()),
        ("many_membership",()->PersistentFeatureChecks.persistent_many_membership_checks()),
        ("targetless",()->PersistentTargetlessChecks.persistent_targetless_checks()),
        ("profile_fallback",()->begin
            model=PersistentTightChecks.persistent_fixture(;birth=false,removal=false)
            sim=PersistentTightProgram.prepare_persistent_tight(model;performance=true,
                constants=(effects=Any[],tick=Ref(1)),steps=1,count_calls=true)
            @assert PersistentTightProgram.persistent_tight_report(sim).performance_fallback
            @assert all(batch->batch isa PlantSimEngine.CompiledExecutionBatch,sim.execution_plan.batches)
            (passed=true,report=PersistentTightProgram.persistent_tight_report(sim))
        end),
    )
    open(joinpath(out,"final-gates-test-output.txt"),"w") do io
        redirect_stdout(io) do
            for (label,check) in tests
                stages[label]=try
                    check()
                catch error
                    (passed=false,error=sprint(showerror,error,catch_backtrace()))
                end
                open(joinpath(out,"final-gates.json"),"w") do target
                    PlantSimEngine.JSON.print(target,stages,2)
                end
                hasproperty(stages[label],:passed) && !stages[label].passed && break
            end
        end
    end
    (stages=collect(keys(stages)),path=joinpath(out,"final-gates.json"))
end
