# Independent review of the final persistent-program screen

The current Python check passes for the two explicitly selected final screens. It reports 0 unqualified **final** screens separately from 2 hash-bound CPU-excluded diagnostic XP attempts. The excluded attempts supply no derived timing ratios. Three controller-declared final gates pass; current src/ext bytes match a016b511d7919e1af88505be9ce000c8d643c56c. The recorded scientific/experimental manifests match captured current bytes, the backend is 2e2232708a0c4e9fc9f73d9f8026abf0b0db0dd3e8fa15b6da8684b0139b45dd, and the exact controller-supplied forcing copy is captured. The forcing copy does not independently reconstruct a during-screen I/O guard.

Only two balanced cycles were measured. All measured phase compilation/recompilation/GC counters are zero. These are warm fresh-scene screens with construction, ordinary preparation, additional typed installation and execution charged separately; they are not cold compilation measurements.

| Final workload | Arm | Paired execution ratio | Paired complete ratio |
|---|---|---:|---:|
| PB 16 objects × 8 steps | ordinary B/A | 1.0581 | 0.9561 |
| PB | preparation only | 1.0784 | 0.8449 |
| PB | typed only | 0.9888 | 1.6895 |
| PB | combined | 0.9366 | 1.5255 |
| XP 4 days, 20 final objects, 12 born | ordinary B/A | 0.9455 | 0.9765 |
| XP | preparation only | 0.8437 | 0.7941 |
| XP | typed only | 1.3585 | 1.2116 |
| XP | combined | 1.3545 | 1.0588 |

PB typed execution allocations fall from 48,080 to 7,280 bytes, but additional lowering costs about 1.85–1.87 ms and 4.29 MB per fresh scene. Execution itself is about 0.12 ms. Thus this small PB case demonstrates allocation reduction, not a useful fresh-complete typed improvement. Its two-cycle execution differences should be read beside A/A variation.

XP typed-only execution allocations increase from 12.47 MB to 15.54 MB. Combined execution uses 9.87 MB, which is lower than ordinary but **higher** than preparation-only's 6.82 MB. Combined execution is about 20.14 ms, versus 12.45 ms preparation-only. Additional typed lowering costs about 1.94 ms and 0.97 MB. In each typed arm the observed totals are 32 selected batch entries, 4 refreshes, 8 reused regions, 24 readmitted regions and 124 ordinary fallback/sentinel entries. There is real selected execution after growth, but maintaining it currently adds work.

The next useful diagnostic is a tiny CPU/allocation comparison of preparation-only versus combined on the same 4-day XP fixture, with separate preparation/lowering and execution windows. Keep `performance=false`: this prototype intentionally falls back to ordinary execution when framework performance instrumentation is enabled. Sample the actual custom path, rather than comparing an instrumentation-induced ordinary fallback. Attribute Persistent refresh capture, ordinary-plan refresh, epoch seeding, `_selected` readmission, `_tracked_frame`, and tracked per-row status/header writes separately. An allocation-site profile should explain the additional roughly 3.06 MB execution allocation relative to preparation-only. The zero timed JIT counters rule out measured JIT compilation as the explanation for this warm execution slowdown; no conclusion about unmeasured cold inference follows.

The first narrow candidate to assess after attribution is structural leaf-program handling (empty children), relevant to the selected XP numeric kernels: avoid rebuilding full ordinary owners solely to seed a child-free typed region, and use a coarse root invocation epoch where exact semantics permit. The full tracked/public path must remain for child calls, exposure, conditional invocation, exceptions and unknown layouts. A separate cheap candidate is reducing ordinary sentinel wrappers to those necessary for refresh/empty-plan readmission; their 124 entries are observed, but their time share has not been measured. Neither proposal is credited as a gain before tests.

Raw artifacts and both CPU-excluded attempts remain unchanged. No Julia, profiling, new benchmark or archive was run in this independent review.
