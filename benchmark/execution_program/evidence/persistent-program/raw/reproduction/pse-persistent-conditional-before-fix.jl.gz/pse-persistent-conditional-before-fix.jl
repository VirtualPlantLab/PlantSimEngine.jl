include(joinpath(pwd(),"benchmark/native_downstream/persistent_feature_checks.jl"))
let out=joinpath(pwd(),"benchmark/native_downstream/results/persistent-program"), result=nothing
    open(joinpath(out,"conditional-before-fix-test-output.txt"),"w") do io
        result=redirect_stdout(io) do
            try
                PersistentFeatureChecks.persistent_conditional_epoch_checks(;inspect_step=1)
            catch error
                (passed=false,error=sprint(showerror,error,catch_backtrace()))
            end
        end
    end
    open(joinpath(out,"conditional-before-fix.json"),"w") do io
        PlantSimEngine.JSON.print(io,result,2)
    end
    (passed=result.passed,path=joinpath(out,"conditional-before-fix.json"))
end
