"""One serial Kaimon warm-screen invocation with source/forcing/CPU guards."""
import argparse,hashlib,importlib.util,json,re,time
from pathlib import Path
from datetime import datetime,timezone

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
cold=load('persistent_guard','/private/tmp/pse_preparation_scaling_cold_pilot.py')
client=cold.client
root=Path('/Users/rvezy/.codex/worktrees/pse-interface-plan-prototypes/PlantSimEngine')
out=root/'benchmark/native_downstream/results/persistent-program'
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('script');p.add_argument('artifact');a=p.parse_args()
expected=out/a.artifact
if expected.exists():raise RuntimeError('Refuse to overwrite existing screen')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
(out/'reproduction').mkdir(exist_ok=True)
script=out/'reproduction'/f'{a.label}.jl'
if script.exists():raise RuntimeError('Refuse to overwrite executed script')
script.write_bytes(Path(a.script).read_bytes());script_digest=sha(script)
runner=out/'reproduction'/'screen-runner.py'
if runner.exists() and runner.read_bytes()!=Path(__file__).read_bytes():raise RuntimeError('Runner source changed')
if not runner.exists():runner.write_bytes(Path(__file__).read_bytes())

def image():
 result={'PSE':cold.source_image(root)}
 for package in ('PlantBiophysics','XPalm'):
  folder=Path('/Users/rvezy/Documents/dev')/package
  paths=[p for p in (folder/'src').rglob('*.jl') if p.is_file() and not p.is_symlink()]
  paths += [folder/name for name in ('Project.toml','Manifest.toml') if (folder/name).is_file()]
  result[package]={p.relative_to(folder).as_posix():sha(p) for p in sorted(paths)}
 scope=json.loads((out/'run-scope.json').read_text())
 forcing=Path(scope['forcing']['path'])
 if sha(forcing)!=scope['forcing']['sha256']:raise RuntimeError('Forcing changed')
 result['forcing_sha256']=sha(forcing)
 return result
before=image();image_path=out/'screen-source-image.json'
if image_path.exists() and json.loads(image_path.read_text())!=before:raise RuntimeError('Screen source cohort drift')
if not image_path.exists():write(image_path,before)
# The previous evaluation was fully consumed before this pipeline invocation.
for _ in range(2):
 obs=cold.strict_cpu_sample(13886)
 if obs['other_busy']:raise RuntimeError('Competing Julia work before screen: '+str(obs['other_busy']))
 time.sleep(3)
session=json.loads(client.STATE.read_text())['session'];receipts=[]
def call(name,arguments):
 r,_=client.post('tools/call',{'name':name,'arguments':arguments},session)
 path=out/'receipts'/f'{a.label}-{len(receipts)+1:02}-{name}.json'
 if path.exists():raise RuntimeError('Receipt would overwrite evidence')
 write(path,{'at':datetime.now(timezone.utc).isoformat(),'tool':name,'arguments':arguments,'response':r})
 receipts.append(path)
 return r
monitor=cold.StrictMonitor(13886);monitor.start();failure=None
try:
 e='@assert getpid()==13886; include('+cold.jl_string(script)+')'
 r=call('ex',{'ses':'3c6bd8ff','e':e,'q':False,'max_output':2000})
 status=cold.response_state(r)
 if status=='running':
  text=cold.content(r);match=re.search(r'Job ID:\s*([\w-]+)',text)
  job=r.get('result',{}).get('eval_id') or (match.group(1) if match else None)
  if not job:raise RuntimeError('Missing evaluation ID')
  deadline=time.monotonic()+600
  while True:
   time.sleep(30)
   if not expected.exists() and time.monotonic()<deadline:
    print(json.dumps({'stage':'waiting_for_screen','label':a.label}),flush=True);continue
   r=call('check_eval',{'eval_id':job});status=cold.response_state(r)
   if status!='running':break
   if time.monotonic()>deadline:raise RuntimeError('Screen exceeded time budget')
 if status=='failed' or not expected.exists():raise RuntimeError('Screen failed: '+cold.content(r)[:2000])
 if image()!=before or sha(script)!=script_digest:raise RuntimeError('Source, forcing or script drifted during screen')
except BaseException as error:
 failure=repr(error)
finally:
 cpu=monitor.finish();cpu_path=out/f'{a.label}-cpu.json';write(cpu_path,cpu)
 qualification=dict(artifact=a.artifact,artifact_sha256=sha(expected) if expected.exists() else None,
  cpu_record=cpu_path.relative_to(out).as_posix(),cpu_sha256=sha(cpu_path),
  script={'path':script.relative_to(out).as_posix(),'sha256':script_digest},
  receipt={'path':receipts[-1].relative_to(out).as_posix(),'sha256':sha(receipts[-1])} if receipts else None,
  qualified=failure is None and cpu['qualified'],failure=failure,source_and_forcing_unchanged=failure is None)
 qpath=out/'qualification.json';rows=json.loads(qpath.read_text())['artifacts'] if qpath.exists() else []
 rows.append(qualification);write(qpath,{'artifacts':rows})
 print(json.dumps({'stage':'completed','label':a.label,'qualified':qualification['qualified'],'failure':failure}),flush=True)
if failure:raise RuntimeError(failure)
