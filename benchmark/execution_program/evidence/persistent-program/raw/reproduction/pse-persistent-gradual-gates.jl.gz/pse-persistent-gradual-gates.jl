let out=joinpath(pwd(),"benchmark/native_downstream/results/persistent-program"), stages=Dict{String,Any}()
    open(joinpath(out,"gradual-gates-test-output.txt"),"w") do io
        redirect_stdout(io) do
            for kind in (:pb,:xp)
                stages[string(kind)]=try
                    PersistentDownstreamMeasurements.persistent_downstream_checks(kind;steps=4,nobjects=4,arms=(:typed_only,:combined))
                catch error
                    (passed=false,error=sprint(showerror,error,catch_backtrace()))
                end
                open(joinpath(out,"gradual-gates.json"),"w") do target
                    PlantSimEngine.JSON.print(target,stages,2)
                end
                stages[string(kind)].passed || break
            end
        end
    end
    (stages=collect(keys(stages)),path=joinpath(out,"gradual-gates.json"))
end
