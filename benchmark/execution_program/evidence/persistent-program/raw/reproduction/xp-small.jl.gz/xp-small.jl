let spec=PersistentDownstreamMeasurements.register_persistent_case!(:persistent_xp_small,:xp;
    nobjects=4,steps=4,outputs=:none)
    screen=PersistentDownstreamMeasurements.screen_persistent(spec;repetitions=2)
    path=joinpath(pwd(),"benchmark/native_downstream/results/persistent-program/xp-screen.json")
    open(path,"w") do io
        PlantSimEngine.JSON.print(io,screen,2)
    end
    (path=path,samples=length(screen.samples),case=screen.case)
end
