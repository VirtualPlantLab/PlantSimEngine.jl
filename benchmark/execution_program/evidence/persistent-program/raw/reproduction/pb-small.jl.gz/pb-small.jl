let spec=PersistentDownstreamMeasurements.register_persistent_case!(:persistent_pb_small,:pb;
    nobjects=16,steps=8,outputs=:none)
    screen=PersistentDownstreamMeasurements.screen_persistent(spec;repetitions=2)
    path=joinpath(pwd(),"benchmark/native_downstream/results/persistent-program/pb-screen.json")
    open(path,"w") do io
        PlantSimEngine.JSON.print(io,screen,2)
    end
    (path=path,samples=length(screen.samples),case=screen.case)
end
