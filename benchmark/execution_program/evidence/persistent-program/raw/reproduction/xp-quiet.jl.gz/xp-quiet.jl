let spec=PersistentDownstreamMeasurements.register_persistent_case!(:persistent_xp_small_quiet,:xp;
    nobjects=4,steps=4,outputs=:none)
    screen=PersistentDownstreamMeasurements.screen_persistent(spec;repetitions=2)
    path=joinpath(pwd(),"benchmark/native_downstream/results/persistent-program/xp-quiet-screen.json")
    open(path,"w") do io
        PlantSimEngine.JSON.print(io,screen,2)
    end
    nothing
end
