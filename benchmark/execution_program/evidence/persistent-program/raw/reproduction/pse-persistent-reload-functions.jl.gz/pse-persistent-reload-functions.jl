# Warm development only: layouts/constants are unchanged. Re-evaluate the
# frozen source's function definitions in its existing module, preserving types.
module PSEPersistentReloadHelper
function ismethod(ex)
    ex isa Expr || return false
    ex.head===:function && return true
    ex.head===:(=) && return ex.args[1] isa Expr && ex.args[1].head in (:call,:where)
    ex.head===:macrocall && return any(ismethod,ex.args)
    return false
end
function reload!(mod,path)
    parsed=Meta.parseall(read(path,String);filename=path)
    module_expr=only(ex for ex in parsed.args if ex isa Expr && ex.head===:module)
    count=0
    for ex in module_expr.args[end].args
        ismethod(ex) || continue
        Core.eval(mod,ex)
        count+=1
    end
    return count
end
end
let root=joinpath(pwd(),"benchmark/native_downstream")
    (driver=PSEPersistentReloadHelper.reload!(PersistentTightProgram,joinpath(root,"persistent_tight_program.jl")),
     checks=PSEPersistentReloadHelper.reload!(PersistentTightChecks,joinpath(root,"persistent_tight_checks.jl")))
end
