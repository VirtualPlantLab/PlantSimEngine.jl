PSEPersistentReloadHelper.reload!(PersistentFeatureChecks,joinpath(pwd(),"benchmark/native_downstream/persistent_feature_checks.jl"))
let out=joinpath(pwd(),"benchmark/native_downstream/results/persistent-program"), stages=Dict{String,Any}()
    tests=(
        ("late_unqueried",()->PersistentFeatureChecks.persistent_conditional_epoch_checks(;inspect_step=2,late_unqueried=true)),
        ("partial_failure",()->PersistentFeatureChecks.persistent_partial_failure_checks()),
        ("consumed_exposure",()->PersistentFeatureChecks.persistent_consumed_exposure_checks()),
        ("evaluate_accept",()->PersistentFeatureChecks.persistent_protocol_fallback_checks(;case=:evaluate_accept)),
        ("stale_accept",()->PersistentFeatureChecks.persistent_protocol_fallback_checks(;case=:stale_accept)),
        ("backend_override",()->PersistentFeatureChecks.persistent_protocol_fallback_checks(;case=:backend_override)),
        ("mutable_environment",()->PersistentFeatureChecks.persistent_mutable_environment_checks()),
        ("many_membership",()->PersistentFeatureChecks.persistent_many_membership_checks()),
        ("targetless",()->PersistentTargetlessChecks.persistent_targetless_checks()),
    )
    open(joinpath(out,"feature-v2-gates-test-output.txt"),"w") do io
        redirect_stdout(io) do
            for (label,check) in tests
                stages[label]=try
                    check()
                catch error
                    (passed=false,error=sprint(showerror,error,catch_backtrace()))
                end
                open(joinpath(out,"feature-v2-gates.json"),"w") do target
                    PlantSimEngine.JSON.print(target,stages,2)
                end
                hasproperty(stages[label],:passed) && !stages[label].passed && break
            end
        end
    end
    (stages=collect(keys(stages)),path=joinpath(out,"feature-v2-gates.json"))
end
