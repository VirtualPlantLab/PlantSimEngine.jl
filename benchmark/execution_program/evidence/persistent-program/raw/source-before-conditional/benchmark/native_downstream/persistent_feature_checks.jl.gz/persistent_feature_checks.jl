module PersistentFeatureChecks

using Dates, Test, PlantSimEngine
const PSE=PlantSimEngine
const D=Main.DirectPlanChecks
const CR=Main.CompiledRegionsExperiment
const F=Main.DirectPlannerFixtures

export persistent_nested_exception_checks, persistent_partial_failure_checks,
    persistent_consumed_exposure_checks, persistent_protocol_fallback_checks,
    persistent_mutable_environment_checks, persistent_many_membership_checks

_pt()=getfield(Main,:PersistentTightProgram)
_report(simulation)=Base.invokelatest(_pt().persistent_tight_report,simulation)
Base.@nospecializeinfer @noinline function _candidate(model;constants=PSE.PlantMeteo.Constants())
    @nospecialize model
    return Base.invokelatest(_pt().prepare_persistent_tight,model;
        steps=0,outputs=:all,constants,count_calls=true,state_strategy=:references)
end
Base.@nospecializeinfer @noinline function _reference(model;constants=PSE.PlantMeteo.Constants())
    @nospecialize model
    return PSE.run!(model;steps=0,outputs=:all,constants)
end
Base.@nospecializeinfer @noinline function _step!(simulation)
    @nospecialize simulation
    Base.invokelatest(PSE.step!,simulation)
    return nothing
end
Base.@nospecializeinfer @noinline function _science_equal(left,right)
    @nospecialize left right
    @test isequal(CR.downstream_fingerprint(left),CR.downstream_fingerprint(right))
    @test isequal(F.snapshot(left,:generic),F.snapshot(right,:generic))
    @test isequal(F.scientific_rngs(left.model),F.scientific_rngs(right.model))
    return nothing
end
function _add_spectator!(simulation;consume_refresh=false)
    PSE.register_object!(simulation.model,PSE.Object(:feature_spectator;status=(sentinel=1f0,)))
    if consume_refresh
        PSE.refresh_bindings!(simulation.model)
        PSE.refresh_environment_bindings!(simulation.model)
    end
    return nothing
end
function _owner(simulation,id)
    group=only(group for group in simulation.execution_plan.groups if group.application.id===:root)
    return only(target for batch in group.batches for target in batch.targets if target.object_id==PSE.ObjectId(id))
end
function _metadata(collection)
    target=only(collection)
    return (time=collection.time,publication_allowed=collection.publication_allowed,
        target_time=target.time,target_publication_allowed=target.publication_allowed,
        object_id=target.object_id,application=target.application.id,
        context_time=target.execution_target.context.time,
        context_publication_allowed=target.execution_target.context.publication_allowed)
end

"""Original nested catch/retry kernels remain typed after an unrelated event."""
function persistent_nested_exception_checks(;throw_first=true)
    left=_reference(D._fixture(false;throw_first))
    right=_candidate(D._fixture(false;throw_first))
    reports=Any[]
    @testset "Persistent child frames preserve original catches across refresh" begin
        for tick in 1:2
            tick==2 && foreach(_add_spectator!,(left,right))
            before=_report(right)
            _step!(left);_step!(right)
            _science_equal(left,right)
            after=_report(right)
            @test after.executed_numerical_roots-before.executed_numerical_roots==2
            @test after.executed_numerical_calls-before.executed_numerical_calls==
                (throw_first && tick==1 ? 8 : 4)
            for id in 1:2
                @test PSE.model_status(right.model,id).caught==throw_first
            end
            push!(reports,(tick=tick,report=after))
        end
    end
    return (passed=true,throw_first,reports,
        scope=:original_scientific_exception_frames_before_and_after_refresh)
end

"""Unhandled middle-row failure keeps entered and unentered public epochs."""
function persistent_partial_failure_checks(;consume_refresh=true)
    left=_reference(D._fixture(false;nobjects=3))
    right=_candidate(D._fixture(false;nobjects=3))
    @testset "Persistent failed rows preserve ordinary partial execution" begin
        _step!(left);_step!(right)
        _science_equal(left,right)
        for simulation in (left,right)
            PSE.model_status(simulation.model,2).fail=true
        end
        left_error=try _step!(left);nothing catch error;error end
        right_error=try _step!(right);nothing catch error;error end
        @test left_error isa ArgumentError
        @test typeof(right_error)===typeof(left_error)
        @test sprint(showerror,right_error)==sprint(showerror,left_error)
        @test PSE.current_step(left)==PSE.current_step(right)==1
        _science_equal(left,right)
        epochs=Any[]
        for id in 1:3
            control,actual=_owner(left,id),_owner(right,id)
            @test actual.context.time==control.context.time
            @test !actual.call_context_cache.in_use
            expected=PSE.call_targets(control.context,:middle)
            observed=PSE.call_targets(actual.context,:middle)
            @test isequal(_metadata(observed),_metadata(expected))
            @test !only(observed).context_cache.in_use
            push!(epochs,actual.context.time)
        end
        @test epochs==[2.0,2.0,1.0]
        for simulation in (left,right)
            PSE.model_status(simulation.model,2).fail=false
            _add_spectator!(simulation;consume_refresh)
        end
        _step!(left);_step!(right)
        @test PSE.current_step(left)==PSE.current_step(right)==2
        _science_equal(left,right)
        return (passed=true,consume_refresh,epochs,report=_report(right),
            scope=:failed_frame_cleanup_public_epoch_and_post_failure_lifecycle)
    end
end

"""Saved owners/collections remain exact when both refresh APIs consume an event."""
function persistent_consumed_exposure_checks(;consume_refresh=true)
    left=_reference(D._fixture(false))
    right=_candidate(D._fixture(false))
    @testset "Persistent public exposure survives externally consumed refresh" begin
        _step!(left);_step!(right)
        _science_equal(left,right)
        saved_left=PSE.call_targets(_owner(left,1).context,:middle)
        saved_right=PSE.call_targets(_owner(right,1).context,:middle)
        expected_ref=PSE.refvalue(only(saved_left).canonical_status,:value)
        actual_ref=PSE.refvalue(only(saved_right).canonical_status,:value)
        @test isequal(_metadata(saved_left),_metadata(saved_right))
        for simulation in (left,right)
            _add_spectator!(simulation;consume_refresh)
        end
        for _ in 1:2
            _step!(left);_step!(right)
            _science_equal(left,right)
            @test isequal(_metadata(saved_left),_metadata(saved_right))
            @test PSE.refvalue(only(saved_left).canonical_status,:value)===expected_ref
            @test PSE.refvalue(only(saved_right).canonical_status,:value)===actual_ref
            current_left=PSE.call_targets(_owner(left,1).context,:middle)
            current_right=PSE.call_targets(_owner(right,1).context,:middle)
            @test isequal(_metadata(current_left),_metadata(current_right))
        end
        PSE.run_call!(only(saved_left);sampled_environment=(duration=Hour(1),),publish=true)
        PSE.run_call!(only(saved_right);sampled_environment=(duration=Hour(1),),publish=true)
        _science_equal(left,right)
        @test isequal(_metadata(saved_left),_metadata(saved_right))
        return (passed=true,consume_refresh,report=_report(right),
            scope=:saved_nested_singular_views_and_public_reexecution)
    end
end

"""Original evaluate/accept and backend-override fixtures use the full protocol."""
function persistent_protocol_fallback_checks(;case=:evaluate_accept)
    controller=case===:evaluate_accept ? CR.GateCallController() :
        case===:stale_accept ? CR.GateStaleController() :
        case===:backend_override ? CR.GateOverrideController() :
        throw(ArgumentError("Unknown protocol case"))
    left=_reference(CR.gate_call_fixture(controller))
    right=_candidate(CR.gate_call_fixture(controller))
    @testset "Persistent unsupported call protocols remain ordinary" begin
        for tick in 1:2
            tick==2 && foreach(simulation->_add_spectator!(simulation;consume_refresh=true),(left,right))
            _step!(left);_step!(right)
            _science_equal(left,right)
            @test _report(right).executed_numerical_roots==0
            @test _report(right).executed_numerical_calls==0
        end
        return (passed=true,case,report=_report(right),
            scope=:original_evaluation_staleness_publication_and_transient_backend_override)
    end
end

"""A child samples fresh mutable committed environment before/after refresh."""
function persistent_mutable_environment_checks()
    T=getfield(Main,:TightCallProgramChecks)
    left_fixture=T._environment_fixture(false)
    right_fixture=T._environment_fixture(false)
    left=_reference(left_fixture.model)
    right=_candidate(right_fixture.model)
    reports=Any[]
    @testset "Persistent environment handles never cache mutable sampled values" begin
        for (tick,value) in enumerate((1.0,7.0,11.0))
            if tick==2
                _add_spectator!(left;consume_refresh=true)
                _add_spectator!(right;consume_refresh=true)
            end
            left_fixture.driver[1]=right_fixture.driver[1]=value
            before=_report(right)
            _step!(left);_step!(right)
            _science_equal(left,right)
            after=_report(right)
            @test PSE.model_status(right.model,:unit).value==value
            @test after.executed_numerical_roots-before.executed_numerical_roots==1
            @test after.executed_numerical_calls-before.executed_numerical_calls==1
            push!(reports,(tick=tick,value=value,report=after))
        end
    end
    return (passed=true,reports,scope=:fresh_committed_environment_with_compiled_child_handle)
end

"""Retained singleton-Many results track a second worker after consumed growth."""
function persistent_many_membership_checks(;inspect_before_growth=true)
    Many=getfield(Main,:DirectManyChecks)
    left_constants,right_constants=(capture=Any[],),(capture=Any[],)
    left=_reference(Many._many_fixture(false);constants=left_constants)
    right=_candidate(Many._many_fixture(false);constants=right_constants)
    @testset "Persistent fallback retains live Many result membership" begin
        _step!(left);_step!(right)
        _science_equal(left,right)
        saved_left,saved_right=only(left_constants.capture),only(right_constants.capture)
        if inspect_before_growth
            @test Many._membership(saved_left)==Many._membership(saved_right)==[:worker_1]
        end
        for simulation in (left,right)
            PSE.register_object!(simulation.model,
                PSE.Object(:worker_2;kind=:tracked_worker,status=(value=0.0,)))
            PSE.refresh_bindings!(simulation.model)
            PSE.refresh_environment_bindings!(simulation.model)
        end
        _step!(left);_step!(right)
        _science_equal(left,right)
        @test Many._membership(saved_left)==Many._membership(saved_right)==[:worker_1,:worker_2]
        @test only(left_constants.capture)===saved_left
        @test only(right_constants.capture)===saved_right
        @test PSE.model_status(right.model,:worker_2).value==1.0
        @test _report(right).executed_numerical_roots==0
        @test _report(right).executed_numerical_calls==0
        return (passed=true,inspect_before_growth,report=_report(right),
            scope=:real_retained_many_membership_ordinary_fallback)
    end
end

end # module
