Base.invokelatest() do
    checks=Any[]
    for kind in (:pb,:xp)
        @info "Binding program downstream gate" kind
        push!(checks,NewbornBindingProgramChecks.newborn_binding_downstream_checks(kind))
        arm=kind===:pb ? :typed_instructions : :bounded_instructions
        push!(checks,NewbornBindingMeasurements.newborn_binding_checks(kind;arm,steps=2,outputs=:all))
    end
    open(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/downstream-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
    end
    (;passed=true,cases=length(checks))
end
