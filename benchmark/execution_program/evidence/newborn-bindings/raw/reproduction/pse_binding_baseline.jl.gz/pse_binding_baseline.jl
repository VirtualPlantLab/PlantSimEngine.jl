using PlantSimEngine, SHA
include(joinpath(pwd(),"benchmark/native_downstream/load_direct_planner_experiment.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/newborn_binding_measurements.jl"))
Base.invokelatest() do
    config=DirectPlannerMeasurements.construct_config(:xp;steps=2,outputs=:all)
    fixture=Base.invokelatest(DirectPlannerFixtures.construct_fixture,:xp,config)
    sim=Base.invokelatest(DirectPlannerMeasurements.prepare_arm,fixture.model,:reference_executor;outputs=:all)
    Base.invokelatest(PlantSimEngine.continue!,sim;steps=2)
    inventory=Base.invokelatest(NewbornBindingMeasurements.binding_plan_inventory,sim;initial_ids=fixture.initial_ids)
    state=(state=DirectPlannerFixtures.snapshot(sim,:xp),scientific_rngs=DirectPlannerFixtures.scientific_rngs(sim.model))
    open(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/ordinary-xp-inventory.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),julia=string(VERSION),project=Base.active_project(),pse=pathof(PlantSimEngine),inventory,digest=bytes2hex(sha256(repr(state))),state,work=CompiledRegionsExperiment.downstream_work_report(sim,fixture.initial_ids)),2)
    end
    (;passed=true,pid=getpid(),plans=inventory.plan_count,bindings=inventory.binding_count)
end
