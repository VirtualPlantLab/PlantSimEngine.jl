include(joinpath(pwd(), "benchmark/native_downstream/newborn_binding_program.jl"))
include(joinpath(pwd(), "benchmark/native_downstream/newborn_binding_sequence.jl"))
Base.invokelatest() do
    checks = [NewbornBindingProgramChecks.newborn_binding_generic_checks(),
              NewbornBindingProgramChecks.newborn_binding_declaration_checks()]
    open(joinpath(pwd(), "benchmark/native_downstream/results/newborn-binding/shared-extraction-checks.json"), "w") do io
        PlantSimEngine.JSON.print(io, (;pid=getpid(), checks), 2)
    end
    (;passed=true, cases=length(checks), sequence_loaded=isdefined(Main,:NewbornBindingSequence))
end
