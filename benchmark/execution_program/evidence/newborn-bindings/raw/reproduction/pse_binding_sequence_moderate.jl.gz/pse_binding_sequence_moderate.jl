Base.invokelatest() do
    reports=Any[]
    for (name,kind,steps,nobjects,additions) in (
        (:sequence_generic_births,:generic,2,128,128),
        (:sequence_xp_longer,:xp,12,2,3),
    )
        case=NewbornBindingSequenceMeasurements.register_newborn_sequence_case!(name,kind;steps,nobjects,additions)
        DirectPlannerMeasurements._stage(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/sequence-moderate-stages.tsv"),kind,:sequence,"before_screen")
        screen=NativeDownstreamMeasurements.screen_case(case;repetitions=6,measure_retained=false)
        DirectPlannerMeasurements._stage(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/sequence-moderate-stages.tsv"),kind,:sequence,"after_screen")
        push!(reports,(;kind,screen,summary=NativeDownstreamMeasurements.summarize_screen(screen)))
    end
    open(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/sequence-moderate-screens.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),reports),2)
    end
    (;passed=true,cases=length(reports))
end
