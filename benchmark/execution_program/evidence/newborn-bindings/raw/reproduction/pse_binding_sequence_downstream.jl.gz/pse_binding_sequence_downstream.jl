Base.invokelatest() do
    checks = Any[]
    for (kind, arm) in ((:pb,:binding_sequence),(:pb,:typed_sequence),
                        (:xp,:binding_sequence),(:xp,:bounded_sequence))
        @info "Sequence downstream parity" kind arm
        push!(checks, NewbornBindingSequenceMeasurements.newborn_sequence_checks(kind;
            arm, steps=2, outputs=:all, details=true))
    end
    open(joinpath(pwd(), "benchmark/native_downstream/results/newborn-binding/sequence-downstream-checks.json"), "w") do io
        PlantSimEngine.JSON.print(io, (;pid=getpid(), checks), 2)
    end
    (;passed=true, cases=length(checks))
end
