include(joinpath(pwd(), "benchmark/native_downstream/newborn_binding_sequence_checks.jl"))
Base.invokelatest() do
    checks = Any[]
    for fn in (NewbornBindingSequenceChecks.sequence_generic_checks,
        NewbornBindingSequenceChecks.sequence_order_membership_checks,
        NewbornBindingSequenceChecks.sequence_declaration_checks,
        ()->NewbornBindingSequenceChecks.sequence_feature_checks(:initializer),
        ()->NewbornBindingSequenceChecks.sequence_feature_checks(:mixed_cadence),
        ()->NewbornBindingSequenceChecks.sequence_feature_checks(:distributed),
        NewbornBindingSequenceChecks.sequence_recompile_checks,
        NewbornBindingSequenceChecks.sequence_header_world_checks)
        push!(checks, fn())
    end
    open(joinpath(pwd(), "benchmark/native_downstream/results/newborn-binding/sequence-feature-checks.json"), "w") do io
        PlantSimEngine.JSON.print(io, (;pid=getpid(), checks), 2)
    end
    (;passed=true, cases=length(checks))
end
