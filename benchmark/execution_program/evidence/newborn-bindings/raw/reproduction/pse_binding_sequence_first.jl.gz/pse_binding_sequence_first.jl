include(joinpath(pwd(), "benchmark/native_downstream/newborn_binding_sequence_measurements.jl"))
Base.invokelatest() do
    checks = [NewbornBindingSequenceMeasurements.newborn_sequence_checks(:generic;
        arm, steps=2, details=true) for arm in (:binding_sequence,:bounded_sequence)]
    open(joinpath(pwd(), "benchmark/native_downstream/results/newborn-binding/sequence-first-generic.json"), "w") do io
        PlantSimEngine.JSON.print(io, (;pid=getpid(), checks), 2)
    end
    (;passed=true, cases=length(checks))
end
