# Narrow candidates after the sequence screen

Source-only review, 2026-10-31. No implementation, Julia execution, or new benchmark. Current sequence sources remain frozen. These are hypotheses, not measured application gains.

## First choice: direct scalar carrier assembly

`_input_carrier` currently allocates `Ref[]`, appends the canonical source reference, and calls `only(refs)` even for a `One` or `OptionalOne` that resolved exactly one object. A narrow branch can remove this temporary vector independently of declaration certificates and policy lowering:

```julia
if selector isa Union{One,OptionalOne} && length(source_ids) == 1
    object = _model_object(model, source_ids[1])
    return _status_ref_or_nothing(object.status, source_var)
end
# Existing body unchanged for every other case.
```

This must stay inside the existing carrier stage: after source matching, ambiguity/policy validation and stream-only routing. It must not bypass stream-only carrier construction or move reference lookup before policy errors. Within the branch, current ordering is unchanged: one current registry lookup, one current status/ref lookup, no reference dereference or value copy. `Status` enforces `Tuple{Vararg{Ref}}`, so the helper returns the same `Ref` or `nothing` that the old vector loop would retain. Restricting the branch to exactly one source is essential: with two sources the old code may stop at a missing reference before reaching `only`'s error, and that ordering must remain unchanged. Empty and multi-source cases use the original body, as do all `Many` cases.

Cheap independent test first: a new private benchmark helper implements only this branch and delegates all other inputs to the untouched `PSE._input_carrier`. Compare that helper directly with the ordinary helper using identical independently prepared objects, escaped result sinks and warmed calls. Check canonical reference identity, missing status/field, empty and two-source error ordering, absent IDs, an undefined `Ref` (no value read), `RefArray`, Float32 and generic values. This establishes a carrier-level allocation/time result only. Do not call it an XP/PB gain.

If the micro result is worthwhile, compare the actual scalar branch in isolated source variants with identical fixtures/loaders and per-file manifests. Keep the ordinary implementation untouched in its baseline process; avoid globally replacing `_input_carrier` with a method that affects every benchmark arm. A new unconditional policy lookup or wrapper in all arms would need a same-source hook-disabled control and explicit accounting for the hook cost; it would not establish a gain against today's untouched executor by itself. Begin with one tiny PB/XP correctness run, then one small warmed screen; no larger scale or cold matrix until that screen warrants it.

Expected scope: reduces temporary carrier assembly for ordinary scalar bindings, including unsupported instruction cases. It does not reduce selector queries, producer matching, temporal stream setup or full refresh work. Since optimized scalar instructions already fetch the direct reference, this should be tested independently before claiming additivity with the sequence.

## Second choice: share value-free declaration certificates

The current `_declaration_proof!` cache is per model instance, although its result depends only on the actual `ModelSpec` type and method world. It stores inferred names/field types and strict effect-proof metadata; it never needs a model value. A separately enabled shared cache can reuse both positive certificates and conservative rejection reasons across fresh simulations of the same types.

Use the exact delegated spec type plus a world captured before inference. Require the same world after all inference before publishing the certificate. Keep the existing program-entry-world/runtime guard. Retain strict `consistent == ALWAYS_TRUE`, `effect_free == ALWAYS_TRUE`, `nothrow`, concrete inferred names, and the per-port `typeintersect(field_type, Distributed) === Union{}` condition. Do not cache default values, model instances, bindings, references, output-policy results or live membership. Use one current-world cache (clear it when the world changes), a small entry cap, and synchronization if different models can prepare concurrently.

Compare local versus shared certificates with the same instruction/sequence executor and counter detail mode. Count actual inference builds, per-instance hits and shared hits separately. Test two new simulations with different parameter/default values but the same model types; prove that live defaults and RNG stay ordinary. Dynamic-name/effectful declarations must remain rejected without optional evaluation. A method-definition change must miss/invalidate the shared certificate. Charge the first proof build and cache-management allocations to setup; report a first simulation separately from subsequent fresh simulations. This is a repeated-preparation hypothesis, not a cold-first-simulation optimization or a runtime-kernel claim.

## Recommendation

If sequence runtime remains weak, run the direct-scalar private micro check next. It has a short behavioral proof, no reflection, no new cache and broader scalar coverage than the current certified instruction path. Consider the shared certificate cache afterward only if preparation remains material; it can remove repeated inference work but cannot fix runtime overhead.
