# Final independent newborn-binding audit

Source/result review only; no Julia execution and no archive creation by this agent. Initial detail is in `/private/tmp/pse-newborn-binding-initial-audit.md`. The new archiver is `benchmark/execution_program/summarize_newborn_bindings.py`; root's check-only validation reports eight qualified warm screens, 22 structured checks, 356 exact source blobs and zero excluded warm screens. All three qualification entries' artifact/CPU/script/receipt SHA bindings were independently checked with no mismatch.

## Evidence and protocol

- Initial per-binding cohort: `small-screens.json`, SHA e9b20d6940a05801ff8f7c7e51338470c1128ba51595237ded2759046aa0daf5; recorded source epoch 8b84435d4589273570909b466df9ebda2797630c844fa2e5f97cae57630defe0. Changed code bytes resolve exactly to `source-before-sequence`, rather than being replaced by the later implementation.
- Consumer-sequence small cohort: `sequence-small-screens.json`, SHA 1891d594b310a8eda741da3cacbd223b1cc6a56ccf5124cead652ba4a040c02d.
- Consumer-sequence moderate cohort: `sequence-moderate-screens.json`, SHA 960f49115bec58fd62fa1535d976655bd9fc1797866b75acf0c02eca1a21c182. Both sequence cohorts share recorded source epoch 8d556937e9403b192be1452548566fa0e73654afbda7fb4778fb38166a0cba74 and checkpoint d970069d1199f724f3c9d1835e37b4b092069fed.
- Julia 1.13.1/PID 68508 is a warm reused worker throughout. No fresh-process/cold-compilation improvement is established here. Source epochs and per-binding versus sequence protocols stay separate; do not derive incremental percentages by subtracting results from different epochs.
- Source checks resolved every required PSE/PB/XP/experimental byte. The sequence-small manifest has 146 PSE, 38 PB, 112 XP and 159 experimental files, all exact current bytes at review. Historical initial bytes are separately preserved. Root froze Julia source before the moderate screen.
- All fingerprints, full serialized scientific state/history/topology/numeric types/model RNGs, configurations and work agree within every case across warmups and samples. Recorded AB/BA orders match every sample; preparation/enablement/certification/lowering are included in complete phase sums. Forcing is read at registration and copied per independent scenario.
- The explicit whole-RPC CPU records are qualified, with no observed competing Julia process above the configured 5% threshold. They have 9/4/3 observations and maximum gaps 5.079982/5.066526/5.083694s. This is sampled quietness, not continuous zero-interference proof; do not present their coverage as continuous CPU tracing.

## Small sequence cohort

The strongest four-day XP comparison is bounded+sequence against bounded-only:

| Metric | Paired median | Range | Wins |
| --- | ---: | ---: | ---: |
| Execution | 0.871597 | 0.835552–0.904111 | 4/4 |
| Preparation | 1.080503 | 1.047656–1.142474 | 0/4 |
| Complete | 0.989602 | 0.942911–1.016004 | 3/4 |

This is a promising ~12.8% execution signal on four days; complete cost is only near parity. Compared with ordinary, bounded+sequence is 0.895656 execution/0.990992 complete. Every sequence sample actually completes 171 instructions, including 124 newborn (116 producer+8 status); 12 targeted/112 global refresh. Its separate base runtime counters do not supply sequence credit. Details dictionaries are empty with details=false; fixed aggregate partitions reconcile exactly. Twelve additions yield 20 final objects and 34 retained temporal streams.

PB remains a static negative control: zero binding instructions, 128 numerical driver entries. Typed+sequence versus typed has 1.04235 execution/1.05900 complete paired ratios; previous driver gains must not be credited to this binding experiment.

## Moderate six-cycle cohort

Generic has 128 initial units plus one controller root, adds 128 units in the first step and ends with 257 objects. Sequence samples actually construct 256 instruction bindings: 128 initial + 128 newborn producer bindings. All counter values and partitions are stable across the six samples for each arm.

| Generic contrast | Execution | Execution wins | Complete | Complete wins |
| --- | ---: | ---: | ---: | ---: |
| Sequence / ordinary | 0.955267 | 6/6 | 0.969647 | 4/6 |
| Bounded+sequence / ordinary | 0.930298 | 6/6 | 0.958783 | 5/6 |
| Bounded+sequence / bounded | 0.968048 | 6/6 | 0.977035 | 5/6 |

For the final contrast, execution ratios span 0.889135–0.993628; complete ratios 0.888917–1.048004. This supports a narrow generic growth candidate (~3.2% execution and 2.3% complete improvement over bounded-only), not million-organ or general-model qualification. Execution allocation barely changes against bounded (3,867,888 ->3,867,120 bytes), and complete allocation rises 7,391,488 ->7,426,912 bytes, so the time result is not evidence of a large allocation mechanism or lower retained memory.

XP 12-day work is 36 additions/44 final objects/82 retained streams. Every sequence candidate completes 419 instructions: 47 initial + 372 newborn, including 348 newborn producer and 24 newborn status completions. Base and sequence namespaces, initial/existing/newborn, producer/status and targeted/global partitions all reconcile; no prepared count or empty consumer is used as execution credit.

| XP 12-day contrast | Execution | Execution wins | Complete | Complete wins |
| --- | ---: | ---: | ---: | ---: |
| Sequence / ordinary | 0.970042 | 4/6 | 1.030239 | 0/6 |
| Bounded+sequence / ordinary | 1.045837 | 2/6 | 1.082130 | 1/6 |
| Sequence / bounded | 0.992607 | 3/6 | 1.049624 | 1/6 |
| Bounded+sequence / bounded | 1.005461 | 3/6 | 1.053591 | 1/6 |

For bounded+sequence versus bounded, execution ratios span 0.938206–1.179952; complete 0.974390–1.105985. Preparation is 1.143434, losing all six preparation pairs. The four-day runtime result does not persist at twelve days; no robust XP runtime or complete-cost improvement is established. Execution allocation reductions are real (ordinary 38.286 MB ->sequence 34.461 MB; bounded 21.809 MB ->bounded+sequence 20.622 MB), but do not establish a net runtime gain or peak-memory benefit.

All timed execution phases have zero recorded compilation, recompilation and GC. All timed phases have zero GC. There are small preparation compiler events: moderate generic up to 0.333 microseconds and XP up to 75.129 microseconds compilation/5.208 microseconds recompilation. Small-sequence PB additionally records 107.792 microseconds preparation compilation in its typed control. Do not say every warm phase has zero JIT. These counters do not account for the much larger additional preparation time by themselves.

## Readiness and limits

No evidence-blocking issue found for freezing/archive. Keep initial negative data, failed test expectations/startup receipts, source-before versions and exact qualification bindings. The archiver validates source/counter protocols and preserves bytes; it does not rerun Julia's effect inference. The stricter declaration/header/world/ownership guards address the source issues found during review, with ordinary fallbacks for uncertain cases.

The report should describe a generic candidate and an XP limitation, with no cold/production/full-suite/million-organ claim. Describe generic dimensions as units plus the controller root. Additional preparation/bookkeeping costs are measured jointly; exclusive attribution to declaration inference, dictionary accounting or a particular guard is not established.

No further Julia is recommended in this round. If another focused follow-up is authorized later, use a small separate instrumented XP companion to attribute binding construction versus status/view/environment/group-refresh costs at 4 versus 12 days, with the same source, original science and independent actual counters. Avoid another broad timing/cold matrix until that attribution supplies a new falsifiable mechanism.
