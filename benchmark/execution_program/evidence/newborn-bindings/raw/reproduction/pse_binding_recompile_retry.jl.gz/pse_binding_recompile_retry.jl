include(joinpath(pwd(),"benchmark/native_downstream/newborn_binding_program_checks.jl"))
Base.invokelatest() do
    checks=Any[NewbornBindingProgramChecks.newborn_binding_recompile_checks()]
    for case in (:initializer,:mixed_cadence,:distributed)
        push!(checks,NewbornBindingProgramChecks.newborn_binding_feature_checks(case))
    end
    open(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/recompile-and-features.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
    end
    (;passed=true,cases=length(checks))
end
