include(joinpath(pwd(),"benchmark/native_downstream/growth_input_reuse_checks.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/newborn_binding_program.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/newborn_binding_program_checks.jl"))
Base.invokelatest() do
    checks=Any[]
    push!(checks,NewbornBindingProgramChecks.newborn_binding_generic_checks())
    push!(checks,NewbornBindingProgramChecks.newborn_binding_guard_checks())
    open(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/small-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
    end
    (;passed=true,cases=length(checks))
end
