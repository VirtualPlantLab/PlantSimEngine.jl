Base.invokelatest() do
    reports=Any[]
    for (name,kind,steps,nobjects,arms) in (
        (:sequence_generic_small,:generic,2,32,NewbornBindingSequenceMeasurements.SEQUENCE_ARMS),
        (:sequence_xp_small,:xp,4,2,NewbornBindingSequenceMeasurements.SEQUENCE_ARMS),
        (:sequence_pb_control,:pb,128,32,(:reference_executor,:typed_driver,:typed_sequence)),
    )
        case=NewbornBindingSequenceMeasurements.register_newborn_sequence_case!(name,kind;steps,nobjects,arms)
        DirectPlannerMeasurements._stage(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/sequence-small-stages.tsv"),kind,:sequence,"before_screen")
        screen=NativeDownstreamMeasurements.screen_case(case;repetitions=4,measure_retained=false)
        DirectPlannerMeasurements._stage(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/sequence-small-stages.tsv"),kind,:sequence,"after_screen")
        push!(reports,(;kind,screen,summary=NativeDownstreamMeasurements.summarize_screen(screen)))
    end
    open(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/sequence-small-screens.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),reports),2)
    end
    (;passed=true,cases=length(reports))
end
