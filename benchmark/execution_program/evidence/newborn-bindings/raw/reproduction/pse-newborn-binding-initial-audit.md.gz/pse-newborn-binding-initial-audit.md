# Independent initial reusable-binding screen audit

Audited `results/newborn-binding/small-screens.json` (SHA e9b20d6940a05801ff8f7c7e51338470c1128ba51595237ded2759046aa0daf5) and `binding-small-20261031T183724-cpu.json` (SHA eab50632d072b8be6710ccff8f71953243f75900ade4c2f441c39c62647d4e43). No Julia execution. These are the BASE instruction cohort, before NewbornBindingSequence; later sequence data must have a separate source epoch/protocol.

## Verification

All three four-cycle screens have exact digest, serialized scientific snapshot/RNG, config and work equality across samples and warmups; one independent warmup per arm; recorded forward/reverse order matches every sample. Complete seconds and allocation bytes equal construction + normal PSE preparation + lowering + execution. Original forcing is copied into fresh scenarios; this audit checks the stored/source protocol and does not infer extra freshness from matching digests alone.

All cases use Julia 1.13.1/PID 68508 and the same recorded source epoch (71220e64495224a881fdcd98a68339f23bf3c6be; PSE source aggregate e82776187b451fd33e5132b35eca690615f35e91c87e2a3983296b8f9dd5125c). Every recorded PSE/PB/XP and experimental-source byte is available exactly: 143 PSE files, 38 PB files, 112 XP files and 156 experimental files per provenance. Changed NBP/core compiler bytes resolve to `source-before-sequence`; none are silently replaced by the new implementation. All other bytes match current files.

The CPU record is qualified with nine observations and no observed competing Julia process >=5% CPU. Maximum gap is 5.079982 s and observations bracket the screen operation. This is sampled CPU qualification; root's explicit hash-bound qualification manifest remains the final promotion mechanism.

## Actual work and conclusions

| Case/contrast | Paired execution ratio | Paired complete ratio | Complete wins |
| --- | ---: | ---: | ---: |
| Generic instructions / ordinary | 1.1197 | 1.0514 | 2/4 |
| Generic bounded+instructions / ordinary | 0.9512 | 1.0354 | 2/4 |
| Generic bounded+instructions / bounded | 0.8159 | 0.9580 | 3/4 |
| XP instructions / ordinary | 1.0100 | 1.0605 | 0/4 |
| XP bounded+instructions / ordinary | 0.9604 | 1.0524 | 1/4 |
| XP bounded+instructions / bounded | 1.0331 | 1.0885 | 0/4 |
| PB typed / ordinary | 0.6879 | 1.0704 | 1/4 |
| PB typed+instructions / typed | 0.9858 | 1.0170 | 1/4 |

Generic is only ~0.36 ms ordinary execution and noisy across four cycles; the one small bounded-combination signal is not a general win. Each instruction sample actually completes 35 instructions: 32 initial and three newborn producer bindings. It adds exactly three units and ends with 36 objects. No metadata operation is credited as a numerical driver entry.

Every XP instruction sample completes 171 instructions: 47 initial +124 newborn. The newborn split is 116 producer-bound +8 from-status, with 12 targeted and 112 global-refresh completions. All splits/per-input totals reconcile. There are 12 additions, 20 final objects and 34 retained temporal streams at outputs none. Disabled controls have zero counters, and bounded flags are independent. This is real newborn producer coverage, rather than merely initial preparation or four from-status fields.

The base operation reduces ordinary XP execution allocations only 12,356,144 ->12,263,200 bytes, while complete allocations rise 24,461,816 ->26,990,176 bytes. With bounded metadata, execution allocations rise 7,071,664 ->7,097,952 and complete allocations rise 13,646,272 ->15,211,256. Bounded-only remains the better XP anchor here.

PB has ZERO binding instruction executions in every candidate sample. Both typed arms enter 128 actual numerical batches and allocate 114,800 execution bytes versus ordinary 1,487,056; that is the earlier numerical driver gain. Its small typed+instruction fluctuation cannot be called a binding optimization. The instruction flag adds preparation cost without eligible binding work in this case.

All timed execution phases report zero compilation/recompilation/GC, and all timed phases report zero GC. Instruction preparation has nonzero compiler counters: up to137.792 microseconds compilation and 6.749 microseconds recompilation in XP, plus smaller events elsewhere. Therefore “all warm phases have zero JIT” would be false. These tiny recorded events do not explain the ~2ms additional XP preparation by themselves; type/effect proof work, guards and per-binding bookkeeping remain hypotheses for attribution.

## Stronger next measurement

The sequence cohort should retain ordinary and base-instruction controls and a bounded-only anchor, while moving world/program lookup and inferred-group interpretation to one consumer boundary. Keep exact per-binding fallback ordering and source/reference validation. Require its own actual newborn PRODUCER counters and expose base certificate construction separately. Include all sequence compilation/certification in preparation and complete cost. A short same-source XP4-day/four-cycle test should decide whether execution beats bounded-only without worsening complete cost before any larger/cold expansion. CPU sampling is too sparse for a single ~15ms run; if attribution is still needed, use repeated fresh companions and separate preparation from growth refresh, with details-on counters outside normal timing. Do not attribute a gain solely to fewer per-binding guards without such a comparison.
