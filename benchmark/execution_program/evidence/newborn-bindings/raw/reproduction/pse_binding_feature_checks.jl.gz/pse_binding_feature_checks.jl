include(joinpath(pwd(),"benchmark/native_downstream/newborn_preparation.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/newborn_preparation_checks.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/newborn_distributed_checks.jl"))
Base.invokelatest() do
    checks=Any[]
    for case in (:initializer,:mixed_cadence,:distributed)
        @info "Binding program feature gate" case
        push!(checks,NewbornBindingProgramChecks.newborn_binding_feature_checks(case))
    end
    push!(checks,NewbornBindingProgramChecks.newborn_binding_recompile_checks())
    for kind in (:pb,:xp)
        push!(checks,NewbornBindingProgramChecks.newborn_binding_downstream_checks(kind))
        arm=kind===:pb ? :typed_instructions : :bounded_instructions
        push!(checks,NewbornBindingMeasurements.newborn_binding_checks(kind;arm,steps=2,outputs=:all))
    end
    open(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/feature-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
    end
    (;passed=true,cases=length(checks))
end
