include(joinpath(pwd(),"benchmark/native_downstream/newborn_binding_program.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/newborn_binding_program_checks.jl"))
include(joinpath(pwd(),"benchmark/native_downstream/newborn_binding_measurements.jl"))
Base.invokelatest() do
    checks=Any[]
    for fn in (NewbornBindingProgramChecks.newborn_binding_generic_checks,
        NewbornBindingProgramChecks.newborn_binding_guard_checks,
        NewbornBindingProgramChecks.newborn_binding_declaration_checks,
        NewbornBindingProgramChecks.newborn_binding_header_checks)
        push!(checks,fn())
    end
    open(joinpath(pwd(),"benchmark/native_downstream/results/newborn-binding/proof-checks.json"),"w") do io
        PlantSimEngine.JSON.print(io,(;pid=getpid(),checks),2)
    end
    (;passed=true,cases=length(checks))
end
