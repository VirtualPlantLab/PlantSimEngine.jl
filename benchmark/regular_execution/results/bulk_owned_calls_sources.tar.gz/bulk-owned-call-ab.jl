# Include through an existing Kaimon PSE session only, outside accepted timing.
# This host-only experiment defines two independent benchmark functions. It
# never replaces production methods and has no JuliaC/dependency requirement.
module BulkOwnedCallAB
using Dates, Statistics, Test, InteractiveUtils
import PlantSimEngine as PSE

include(joinpath(@__DIR__, "bulk-owned-call-functions.jl"))

PSE.@process "bulk_barrier_owner" verbose=false
PSE.@process "bulk_barrier_leaf" verbose=false
struct Owner{C} <: AbstractBulk_Barrier_OwnerModel
    capture::C
end
PSE.outputs_(::Owner) = (visits=0,)
function PSE.run!(model::Owner, status, environment, constants, context)
    model.capture[] = context
    status.visits += 1
    return nothing
end
struct Leaf{T} <: AbstractBulk_Barrier_LeafModel
    coefficient::T
end
PSE.environment_inputs_(model::Leaf) = (driver=zero(model.coefficient),)
PSE.outputs_(model::Leaf) = (total=zero(model.coefficient), seen=zero(model.coefficient), visits=0)
function PSE.run!(model::Leaf, status, environment, constants, context)
    status.total += model.coefficient * environment.driver
    status.seen = environment.driver
    status.visits += 1
    return nothing
end

function fixture(::Type{T}, count; outputs=:none) where {T}
    capture=Ref{Any}()
    objects=PSE.Object[PSE.Object(:owner; scale=:Scene)]
    append!(objects, [PSE.Object(Symbol("leaf_", index); scale=:Leaf, parent=:owner)
        for index in 1:count])
    model=PSE.CompositeModel(objects...; applications=(
        PSE.ModelSpec(Owner(capture); name=:owner, on=PSE.One(scale=:Scene),
            calls=(leaves=PSE.Many(scale=:Leaf, within=PSE.SceneScope(), application=:leaves),)),
        PSE.ModelSpec(Leaf(T(2)); name=:leaves, on=PSE.Many(scale=:Leaf)),
    ), environment=(duration=Hour(1), driver=T(3)))
    simulation=PSE.run!(model; steps=1, outputs)
    targets=PSE.call_targets(capture[], :leaves)
    batches=PSE._materialize_call_execution_batches!(targets)
    raw=[(targets, batch.application, target, false,
        PSE._UNSPECIFIED_SCENE_ENVIRONMENT, PSE._NO_ENVIRONMENT_OVERRIDE, nothing)
        for batch in batches for target in batch.targets]
    @assert length(raw)==count
    Args=typeof(first(raw))
    @assert all(args -> typeof(args)===Args, raw)
    return (;simulation, args=Args[args for args in raw])
end

function loop!(runner::F, args::A, iterations) where {F,A}
    for _ in 1:iterations, call in args
        runner(call...)
    end
    return nothing
end
function reset!(data)
    empty!(data.simulation.environment_bindings.sample_cache)
    for call in data.args
        target=call[3]
        target.status.total=zero(target.status.total)
        target.status.seen=zero(target.status.seen)
        target.status.visits=0
    end
    return nothing
end
snapshot(data)=[(id=call[3].object_id, total=call[3].status.total,
    seen=call[3].status.seen, visits=call[3].status.visits) for call in data.args]

function validate(data, iterations, ::Type{T}) where {T}
    result=snapshot(data)
    @test all(row -> row.total===T(6)*iterations && row.seen===T(3) && row.visits==iterations, result)
    @test all(call -> !call[3].call_context_cache.in_use, data.args)
    return result
end

function ir_summary(runner, call)
    entry=only(code_typed(runner, Base.typesof(call...); optimize=true))
    ir, result_type=first(entry),last(entry)
    generic_run=0; generic_owner=0; invokes_owner=0
    for statement in ir.code
        statement isa Expr || continue
        if statement.head===:call && !isempty(statement.args)
            callee=first(statement.args)
            if callee isa GlobalRef
                generic_run += callee.name===:run!
                generic_owner += callee.name===:_run_materialized_call_kernel!
            end
        elseif statement.head===:invoke && !isempty(statement.args)
            method=first(statement.args)
            if method isa Core.MethodInstance
                invokes_owner += method.def.name===:_run_materialized_call_kernel!
            end
        end
    end
    return (statements=length(ir.code), any_ssa=count(type -> type===Any, ir.ssavaluetypes),
        return_type=string(result_type), generic_scientific_run_calls=generic_run,
        generic_owned_barrier_calls=generic_owner, specialized_owned_barrier_invokes=invokes_owner)
end

"""A/B the old/new bulk-call boundary on one fresh homogeneous ordinary fixture.

Both functions use the same model, contexts, carriers, samplers and publication
machinery. State/cache resets, GC, full scalar validation and IR inspection are
outside timers. Trials alternate order. The model is deliberately small: this
isolates call overhead and cannot establish a full-MAESPA speedup.
The measured path is the original GlobalConstant per-target cache (Any-valued),
with publish=false and no evaluation frame. Acceptance/framed publication still
requires the ordinary hard-call regression suite if the hunk is adopted.
"""
function compare(; T=Float64, count=64, iterations=1000, repeats=7)
    count>=1 && iterations>=1 && repeats>=3 || throw(ArgumentError("positive work and at least3trials required"))
    data=fixture(T,count)
    for call in data.args
        @test PSE._materialize_model_inputs!(call[3].status, call[3].input_bindings,
            call[1].compiled,call[2],call[1].temporal_streams,call[1].time) === call[3].status
    end
    reset!(data); loop!(old_target!,data.args,iterations); before=validate(data,iterations,T)
    reset!(data); loop!(new_target!,data.args,iterations); after=validate(data,iterations,T)
    @test isequal(before,after)
    before=nothing; after=nothing
    ir=(before=ir_summary(old_target!,first(data.args)),after=ir_summary(new_target!,first(data.args)))
    trials=(before=NamedTuple[],after=NamedTuple[])
    for index in 1:repeats
        order=isodd(index) ? (:before,:after) : (:after,:before)
        for arm in order
            reset!(data); GC.gc()
            runner=arm===:before ? old_target! : new_target!
            sample=@timed loop!(runner,data.args,iterations)
            validate(data,iterations,T)
            @test iszero(sample.compile_time) && iszero(sample.recompile_time)
            push!(getproperty(trials,arm),(trial=index,seconds=sample.time,bytes=sample.bytes,
                gc_seconds=sample.gctime,compile_seconds=sample.compile_time,
                recompile_seconds=sample.recompile_time))
        end
    end
    summarize(rows)=(median_seconds=median(getproperty.(rows,:seconds)),
        min_seconds=minimum(getproperty.(rows,:seconds)),median_bytes=median(getproperty.(rows,:bytes)),
        min_bytes=minimum(getproperty.(rows,:bytes)),median_gc_seconds=median(getproperty.(rows,:gc_seconds)))
    return (configuration=(T=string(T),count,iterations,repeats,
        boundary=:prepared_bulk_calls_only,publish=false,evaluation_frame=:none),
        before=summarize(trials.before),after=summarize(trials.after),trials,ir,
        status_same_object=true,exact_scalar_state_parity=true)
end
end
