@inline function old_target!(
    targets::PSE.CallTargets,
    application::PSE.CompiledModelApplication,
    target::PSE.CompiledExecutionTarget,
    publish::Bool,
    sampled_environment,
    environment,
    frame,
)
    cache = target.call_context_cache
    PSE._record_call_execution!(cache, frame)
    status = PSE._materialize_model_inputs!(
        target.status,
        target.input_bindings,
        targets.compiled,
        application,
        targets.temporal_streams,
        targets.time,
    )
    environment_value = sampled_environment isa PSE.UnspecifiedModelEnvironment ?
                        PSE._model_environment_for_binding(
        targets.environment_bindings,
        application,
        target.environment_binding,
        targets.time,
        environment,
    ) : sampled_environment
    publication_allowed = publish && targets.publication_allowed
    acquired = !cache.in_use
    acquired && (cache.in_use = true)
    try
        # The compiled bulk target already owns this typed default context.
        # Preserve its original preparation path, with the same lease as the
        # transient cache; materialized views still check captured metadata.
        context = if acquired && target.context isa PSE.RunContext &&
                     typeof(target.context.environment) === typeof(environment)
            PSE._prepare_model_execution_context!(
                target.context, targets.compiled, targets.environment_bindings,
                application, target.object_id, target.bound_inputs, target.output_targets,
                targets.temporal_streams, targets.output_retention, targets.time,
                targets.constants, publication_allowed, environment,
            )
        else
            PSE._prepare_cached_call_context!(
                cache, acquired, targets.compiled, targets.environment_bindings,
                application, target.object_id, target.bound_inputs, target.output_targets,
                targets.temporal_streams, targets.output_retention, targets.time,
                targets.constants, publication_allowed, environment,
            )
        end
        if frame === nothing
            PSE._run_call_kernel!(
                target.model, status, environment_value, context, target.output_bindings,
            )
        else
            PSE._run_evaluated_call_kernel!(
                target.model, status, environment_value, context, target.output_bindings, frame,
            )
        end
    finally
        acquired && (cache.in_use = false)
    end
    return nothing
end

@inline function new_target!(
    targets::PSE.CallTargets,
    application::PSE.CompiledModelApplication,
    target::PSE.CompiledExecutionTarget,
    publish::Bool,
    sampled_environment,
    environment,
    frame,
)
    cache = target.call_context_cache
    PSE._record_call_execution!(cache, frame)
    PSE._materialize_model_inputs!(
        target.status,
        target.input_bindings,
        targets.compiled,
        application,
        targets.temporal_streams,
        targets.time,
    )
    environment_value = sampled_environment isa PSE.UnspecifiedModelEnvironment ?
                        PSE._model_environment_for_binding(
        targets.environment_bindings,
        application,
        target.environment_binding,
        targets.time,
        environment,
    ) : sampled_environment
    publication_allowed = publish && targets.publication_allowed
    acquired = !cache.in_use
    acquired && (cache.in_use = true)
    try
        # The compiled bulk target already owns this typed default context.
        # Preserve its original preparation path, with the same lease as the
        # transient cache; materialized views still check captured metadata.
        context = if acquired && target.context isa PSE.RunContext &&
                     typeof(target.context.environment) === typeof(environment)
            PSE._prepare_model_execution_context!(
                target.context, targets.compiled, targets.environment_bindings,
                application, target.object_id, target.bound_inputs, target.output_targets,
                targets.temporal_streams, targets.output_retention, targets.time,
                targets.constants, publication_allowed, environment,
            )
        else
            PSE._prepare_cached_call_context!(
                cache, acquired, targets.compiled, targets.environment_bindings,
                application, target.object_id, target.bound_inputs, target.output_targets,
                targets.temporal_streams, targets.output_retention, targets.time,
                targets.constants, publication_allowed, environment,
            )
        end
        PSE._run_materialized_call_kernel!(target, environment_value, context, frame)
    finally
        acquired && (cache.in_use = false)
    end
    return nothing
end

